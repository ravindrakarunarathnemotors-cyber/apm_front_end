/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
        domains: [
      "box1.ozonedesk.info",
      "d8y1.c2.e2-9.dev",
      "example.com", 
      "lh3.googleusercontent.com",             // for logo-white, logo-dark, logo-light, favicon, etc.
     
    ], // Add the external image domain here
  },
};

export default nextConfig;
