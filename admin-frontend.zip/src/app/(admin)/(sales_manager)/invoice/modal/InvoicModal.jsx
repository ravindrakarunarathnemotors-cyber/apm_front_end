'use client'

import React, { useEffect, useState } from 'react'
import Image from 'next/image'
import { Modal, Button, Card, CardBody, Col, Row } from 'react-bootstrap'
import {
  useGetBrandingSettingsQuery,
  useGetOrderDetailsQuery,
  useGetInvoiceDetailsQuery,
  useGetAllPaymentMethodsQuery,
  useGetDiscountCurrencyQuery,
  useRevokePaidInvoiceMutation,
  useGetOrderInvoicePaymentHistoryQuery,
} from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'
import DOMPurify from 'dompurify'
import { useGetSubPaymentMethodsQuery } from '@/store/features/sandoSlice'
import Swal from 'sweetalert2'
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'
import axiosInstance from '@/lib/axiosInstance';

export default function InvoiceModal({ show, onClose, order = {}, fetchLogs }) {
  console.log('Customer ID:', order?.customer_id)
  console.log('tax_value:', order?.tax_value)
  console.log("order",order)

  const { data, isLoading, isError } = useGetOrderDetailsQuery(order?.order_id)
  const { data: historyData, refetch: refetchInvoice } = useGetOrderInvoicePaymentHistoryQuery(order?.order_id, {
    skip: !order?.order_id,
  })
  // const { data: orders, isLoading, error, refetch } =
  // useGetOrderDetailsQuery(order?.order_id, { skip: !show });

  const { data: branding } = useGetBrandingSettingsQuery()
  const [details, setDetails] = useState(null)
  const [note, setNote] = React.useState(order?.note || '')
  const [paymentForm, setPaymentForm] = useState({
    paymentMethod: '',
    subMethod: '',
    amount: '',
    reference: '',
    file: null,
  })
  const [uploading, setUploading] = useState(false)
  const [loading, setLoading] = useState(false)
  // const { data: currencyResp } = useGetDiscountCurrencyQuery()
  const { data: currency = '' } = useGetDiscountCurrencyQuery()

  const { data: paymentData, isLoading: loadingPayment, error: paymentError } = useGetAllPaymentMethodsQuery()

  const {
    data: subPaymentData,
    isLoading: loadingSubPayment,
    error: subPaymentError,
  } = useGetSubPaymentMethodsQuery(paymentForm.paymentMethod, {
    skip: !paymentForm.paymentMethod,
  })

  const [revokePaidInvoice, { isLoading: revoking }] = useRevokePaidInvoiceMutation()

 

  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()
  const invoiceNumber = order?.order_id ? `O-${order.order_id}` : '-'

  const items = historyData?.rows ?? []
  const invoiceDetails = data?.order_items ?? []
  const orderDiscount = Number(order?.discount) ?? 0
  const delivery_fee = order?.delivery_fee || 0
  const subTotal = order?.total_value || 0
  const payment_status = order?.payment_status
  const transaction_fee = order?.transaction_fee
  const taxAmount = Number(order?.tax?.value || 0)
  const tax_percentage = order?.tax_percentage
  const taxName = order?.tax?.name || '-'

  

  const now = new Date()
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Colombo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  })
    .formatToParts(now)
    .reduce((acc, part) => {
      acc[part.type] = part.value
      return acc
    }, {})

  const issueDate = `${parts.year}/${parts.month}/${parts.day} \u00A0\u00A0\u00A0\u00A0\u00A0 ${parts.hour}.${parts.minute} ${parts.dayPeriod}`

  const validateDate = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    if (isNaN(date)) return 'Invalid Date'
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  useEffect(() => {
    if (data) {
      setDetails(data)
    }
  }, [data])

  const from = details?.fromdetails
  const customer = details?.customer_address
  const brandingSetting = branding?.data

  const handleChange = (e) => {
    const { name, value, files } = e.target

   
    if (name === 'amount') {
      const intRegex = /^\d+$/

      // allow empty input (so user can delete)
      if (value !== '' && !intRegex.test(value)) return
    }
    setPaymentForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
      ...(name === 'paymentMethod' && { subMethod: '' }), // reset 2nd select
    }))
  }

  const handleSubMethodChange = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    console.log(file)
    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'invoice_slip') // staging group/tag
    setUploading(true)
    try {
      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const uploaded = res?.data?.media?.[0]
      if (!uploaded?.media_url) throw new Error('Upload failed or no media returned.')
      setPaymentForm((prev) => ({ ...prev, file: uploaded.media_url }))
    } catch (e) {
      console.log(e)
    } finally {
      setUploading(false)
    }
  }

  const handleAddpayment = () => {
    const { amount, paymentMethod, subMethod, reference, file } = paymentForm

    if (!amount || !paymentMethod || !subMethod) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Required Fields',
        text: 'Amount, Payment Method and Sub Method are required.',
      })
      return
    }

    // 🔴 Reference OR File must exist
    if (!reference && !file) {
      Swal.fire({
        icon: 'error',
        title: 'Missing Reference',
        text: 'Please provide either a reference number or upload a file.',
      })
      return
    }

    console.log('Submitting payment:', paymentForm)
    Swal.fire({
      title: 'Invoice Payment',
      text: 'Are you sure you want to add this payment?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true,
    }).then(async (result) => {
      if (result.isConfirmed) {
        setLoading(true)
        try {
          const response = await axiosInstance.post(
            `/order/partiallyPayment`,
            { amount, paymentMethod, subMethod, reference, file, invoice_id: order?.id },
            
          )

          if (response.status === 200) {
            Swal.fire({
              title: 'Success',
              text: 'Order added successfully',
              icon: 'success',
              confirmButtonText: 'OK',
            })
            fetchLogs(1)
            setLoading(false)
            onClose()
          }
        } catch (error) {
          setLoading(false)
          Swal.fire({
            title: 'Error',
            text: error?.response?.data?.message,
            icon: 'error',
            confirmButtonText: 'OK',
          })
        }
      } else if (result.isDismissed) {
        //  NO clicked
        console.log('User clicked NO')
      }
    })
  }

  const handleRevoke = async (payment) => {
    Swal.fire({
      title: 'Revoke Payment?',
      text: 'Are you sure you want this payment to be revoked?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, revoke',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    }).then(async (result) => {
      if (!result.isConfirmed) return
      try {
        await revokePaidInvoice({
          invoice_id: payment.invoice_id,
          payment_id: payment.id,
        }).unwrap()
        await refetchInvoice()
        Swal.fire({
          icon: 'success',
          title: 'Payment revoked',
          timer: 1500,
          showConfirmButton: false,
        })
      } catch (err) {
        Swal.fire({
          icon: 'error',
          title: 'Failed',
          text: err?.data?.message || 'Unable to revoke payment',
        })
      }
    })
  }
  const recipientAddress = details?.recipient_address
  const recipientContact = details?.recipient_contact_info

  return (
    <Modal show={show} onHide={onClose} size="lg" dialogClassName="modal-90w" centered>
      <Modal.Header closeButton>
        <Modal.Title>Invoice #{invoiceNumber}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="print-area">
          <Row>
            <Col xs={12}>
              {isLoading ? (
                <div className="d-flex justify-content-center mt-2">
                  <div class="spinner-border" role="status">
                    <span class="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <Card>
                  <CardBody className="border-bottom py-3 shadow-sm">
                    <Row className="align-items-center">
                      {/* Company Info */}
                      <Col className="d-flex align-items-center">
                        <Image
                          src={brandingSetting?.logo_url_white || ''}
                          alt="logo-small"
                          className="me-2"
                          height={200}
                          width={500}
                          style={{ width: '120px', height: 'auto' }}
                        />
                      </Col>

                      {/* Right Corner Info (Aligned to Table End) */}
                      <Col className="ms-auto text-end">
                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Invoice:</span> {invoiceNumber}
                        </div>

                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Date:</span> {issueDate}
                        </div>

                        <div className="mt-1 d-inline-block">
                          <span
                            className="rounded text-uppercase"
                            style={{
                              fontSize: '0.8rem',
                              fontWeight: 600,
                              lineHeight: '1rem',
                              backgroundColor: payment_status === 'paid' ? '#198754' : payment_status === 'partially paid' ? '#ffc107' : '#dc3545',
                              color: payment_status === 'partially paid' ? '#000' : '#fff',
                              padding: '2px 12px',
                            }}>
                            {payment_status}
                          </span>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>

                  <CardBody>
                    <Row className="row-cols-3 d-flex justify-content-md-between">
                      <Col md={7} className="d-print-flex align-self-center">
                        <div>
                          <address className="fs-13">
                            <strong className="fs-14">From :</strong>
                            <div className="fw-bold">{from?.company_name}</div>
                            <div>{from?.address_1}</div>
                            {from?.address_2 && <div>{from?.address_2}</div>}
                            <div>Hotline: {from?.hotline}</div>
                          </address>
                        </div>
                      </Col>
                      <Col md={5} className="d-print-flex align-self-center">
                        <div>
                          <address className="fs-13">
                            <strong className="fs-14">Invoice to :</strong>
                            <br />
                            <div className="fw-bold">{details?.recipient_address?.name}</div>
                            <div> {details?.recipient_contact_info?.email}</div>

                            <div>Hotline: {details?.recipient_contact_info?.contact}</div>
                          </address>
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={12}>
                        <div className="table-responsive project-invoice">
                          <table className="table table-bordered mb-0">
                            <thead className="table-light">
                              <tr>
                                <th>Order Details</th>
                                <th>Quantity</th>
                                <th className="text-end">Unit Price ({currency})</th>
                                <th className="text-end">Subtotal ({currency})</th>
                              </tr>
                            </thead>

                            <tbody>
                              {invoiceDetails.map((it, idx) => (
                                <tr key={idx}>
                                  <td>
                                    <h5 className="mb-1 fs-12">
                                      #{it.product_id} - {it.name}
                                    </h5>

                                    {it.variant_value && it.variant_value !== 'Default' && <div className="text-muted fs-10">{it.variant_value}</div>}
                                  </td>

                                  <td>
                                    {it.unit_type == 1 ? it.quantity : it.quantity * Number(it.amount_per_unit)}
                                    {it.unit_type != 1 && it.measurement_value}

                                    {it.free_quantity >= 1 && (
                                      <span style={{ color: 'green', fontWeight: 'bold' }}>
                                        {' + '}
                                        {it.unit_type == 1 ? it.free_quantity : it.free_quantity * Number(it.amount_per_unit)}
                                        {it.unit_type != 1 && it.measurement_value} FREE
                                      </span>
                                    )}
                                  </td>

                                  <td className="text-end">{Number(it.unit_price).toFixed(2)}</td>
                                  <td className="text-end">{Number(it.total_price).toFixed(2)}</td>
                                </tr>
                              ))}
                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Sub Total
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{Number(subTotal).toFixed(2)}</b>
                                </td>
                              </tr>

                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Delivery Fee
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{Number(delivery_fee).toFixed(2)}</b>
                                </td>
                              </tr>

                              {Number(taxAmount) > 0 && (
                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    {taxName} ({Number(tax_percentage)}%)
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{Number(taxAmount).toFixed(2)}</b>
                                </td>
                              </tr>
                               )}
                              
                               {Number(orderDiscount) > 0 && (
                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Discount
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{orderDiscount.toFixed(2)}</b>
                                </td>
                              </tr>
                                )}

                                 {Number(transaction_fee) > 0 && (
                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Transaction Fee
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{transaction_fee}</b>
                                </td>
                              </tr>
                                )}

                              {Number(order?.loyalty_points_spent) > 0 && (
                                <tr>
                                  <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '65px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      Loyalty Points Redeemed
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end">
                                    <b>{Number(order?.loyalty_points_spent).toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}

                              <tr>
                                <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '65px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Total
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end">
                                  <b>{Number(order?.full_amount).toFixed(2)}</b>
                                </td>
                              </tr>

                              {payment_status === 'partially paid' && (
                                <>
                                  <tr>
                                    <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                      <b
                                        style={{
                                          display: 'inline-block',
                                          width: '65px',
                                          textAlign: 'left',
                                          marginRight: '4px',
                                          whiteSpace: 'nowrap',
                                        }}>
                                        Total Paid
                                      </b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end">
                                      <b>{Number(order?.amount_paid || 0).toFixed(2)}</b>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td colSpan={3} className="border-0 fs-12 text-dark text-end">
                                      <b
                                        style={{
                                          display: 'inline-block',
                                          width: '65px',
                                          textAlign: 'left',
                                          marginRight: '4px',
                                          whiteSpace: 'nowrap',
                                        }}>
                                        Total Due
                                      </b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end">
                                      <b>{(Number(order?.full_amount || 0) - Number(order?.amount_paid || 0)).toFixed(2)}</b>
                                    </td>
                                  </tr>
                                </>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </Row>

                    <div className="w-full mt-4">
                      <h6 className="mb-2 text-sm font-semibold">Terms And Conditions :</h6>
                      <ul className="pl-4 text-xs space-y-1 list-disc">
                        <li>All accounts are to be paid within 7 days from receipt of invoice.</li>
                        <li>To be paid by cheque, credit card, or direct payment online.</li>
                        <li>
                          If account is not paid within 7 days, the credit details supplied as confirmation of work undertaken will be charged the
                          agreed quoted fee noted above.
                        </li>
                      </ul>
                    </div>

                    <hr />
                    <Row className="d-flex justify-content-center">
                      <Col className="d-flex justify-content-center">
                        <div className="text-center white-space-nowrap">
                          <small className="fs-12">Thank you very much for doing business with us.</small>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                  <style jsx global>{`
                    /* =========================
   SCREEN ONLY
========================= */
                    .modal-footer {
                      display: flex;
                      justify-content: flex-end;
                      gap: 8px;
                    }

                    /* =========================
   PRINT SETUP
========================= */
                    @media print {
                      @page {
                        size: A4;
                        margin: 0;
                      }

                      html,
                      body {
                        width: 210mm;
                        height: 297mm;
                        margin: 0 !important;
                        padding: 0 !important;
                        background: #fff !important;
                        overflow: hidden !important;
                      }

                      /* Hide everything except modal */
                      body > *:not(.modal) {
                        display: none !important;
                      }

                      /* Modal becomes document */
                      .modal {
                        position: fixed !important;
                        inset: 0 !important;
                        display: block !important;
                        background: #fff !important;
                        margin: 0 !important;
                        padding: 0 !important;
                      }

                      .modal-dialog,
                      .modal-content {
                        width: 100% !important;
                        height: 100% !important;
                        max-width: 100% !important;
                        margin: 0 !important;
                        padding: 0 !important;
                        border: none !important;
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      /* Remove modal chrome */
                      .modal-header,
                      .modal-footer {
                        display: none !important;
                      }

                      /* Printable area */
                      .print-area {
                        width: 100% !important;
                        height: 100% !important;
                        margin: 0 !important;
                        padding: 16px !important;
                        background: #fff !important;
                      }

                      /* Remove UI effects */
                      .card,
                      .shadow,
                      .shadow-sm,
                      .rounded,
                      .border {
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      .card {
                        border: none !important;
                      }

                      .card-body {
                        padding: 0 !important;
                      }

                      .row {
                        margin: 0 !important;
                      }

                      [class*='col-'] {
                        padding: 0 !important;
                      }

                      /* =========================
     TOTALS – LABELS CLOSER
  ========================= */
                      .project-invoice tbody tr td {
                        padding-top: 4px !important;
                        padding-bottom: 4px !important;
                      }

                      .project-invoice tbody tr td:nth-child(3) {
                        padding-right: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      .project-invoice tbody tr td:nth-child(4) {
                        padding-left: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      /* =========================
     TABLE SAFETY
  ========================= */
                      table {
                        width: 100% !important;
                        page-break-inside: auto;
                      }

                      tr {
                        page-break-inside: avoid;
                      }

                      thead {
                        display: table-header-group;
                      }

                      /* =========================
     HIDE ADD PAYMENT (PRINT)
  ========================= */
                      .print-area .fs-14.fw-bold.mb-1,
                      .print-area .fs-14.fw-bold.mb-1 + .row {
                        display: none !important;
                      }

                      /* =========================
     NO-PRINT UTILITY
  ========================= */
                      .no-print {
                        display: none !important;
                      }

                      /* Hide form controls */
                      button,
                      input,
                      select {
                        display: none !important;
                      }

                      .modal-backdrop {
                        display: none !important;
                      }
                    }
                    .action-badge {
                      display: inline-flex;
                      align-items: center;
                      justify-content: center;
                      font-size: 0.7rem;
                      padding: 4px 8px;
                      min-width: 50px;
                      height: 22px;
                      line-height: 1;
                      font-weight: 600;
                      border-radius: 5px;
                      user-select: none;
                      transition:
                        background-color 0.2s ease,
                        box-shadow 0.2s ease;
                    }
                    .action-inline {
                      display: inline-flex;
                      gap: 3px;
                      white-space: nowrap;
                    }
                    .view-badge {
                      background-color: #134c92ff;
                      color: #ffffff;
                      text-decoration: none;
                    }
                    .view-badge:hover {
                      background-color: #082e5c;
                    }
                    .revoke-badge {
                      background-color: #6d1818ff;
                      color: #ffffff;
                    }
                    .revoke-badge:hover {
                      background-color: #111827;
                    }
                    .disabled-badge {
                      background-color: #6b7280;
                      color: #ffffff;
                      opacity: 0.6;
                      cursor: not-allowed;
                    }
                    .view-badge,
                    .revoke-badge {
                      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
                    }
                  `}</style>
                </Card>
              )}
            </Col>
          </Row>
        </div>
      </Modal.Body>
      <Modal.Footer className="no-print">
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
        <Button variant="primary" onClick={() => window.print()}>
          Print
        </Button>
      </Modal.Footer>
    </Modal>
  )
}
