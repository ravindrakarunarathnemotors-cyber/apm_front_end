'use client'

import React, { useEffect, useState } from 'react'
import Image from 'next/image'
import { Modal, Button, Card, CardBody, Col, Row } from 'react-bootstrap'
import {
  useGetBrandingSettingsQuery,
  useGetInvoiceDetailsQuery,
  useGetAllPaymentMethodsQuery,
  useGetDiscountCurrencyQuery,
  useRevokePaidInvoiceMutation,
} from '@/store/features/apiSlice'
import { useGetSubPaymentMethodsQuery } from '@/store/features/sandoSlice'
import Swal from 'sweetalert2'
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'
import { Icon } from '@iconify/react'
import DOMPurify from 'dompurify'
import axiosInstance from '@/lib/axiosInstance';

export default function InvoiceModal({ show, onClose, order = {}, fetchLogs }) {
  console.log('Order:', order)
  console.log('Customer ID:', order?.customer_id)
  const { data, isLoading, isError, refetch } = useGetInvoiceDetailsQuery(order?.id)

  const { data: branding } = useGetBrandingSettingsQuery()
  const [revokePaidInvoice, { isLoading: revoking }] = useRevokePaidInvoiceMutation()

  const [details, setDetails] = useState(null)
  const [note, setNote] = React.useState(order?.note || '')
  const [paymentForm, setPaymentForm] = useState({
    paymentMethod: '',
    subMethod: '',
    amount: '',
    reference: '',
    file: null,
  })
  const [uploading, setUploading] = useState(false)
  const [loading, setLoading] = useState(false)
  const [printLoading, setPrintLoading] = useState(false)

  // const { data: currencyResp } = useGetDiscountCurrencyQuery()
  const { data: currency = '' } = useGetDiscountCurrencyQuery()

  const { data: paymentData, isLoading: loadingPayment, error: paymentError } = useGetAllPaymentMethodsQuery()

  const {
    data: subPaymentData,
    isLoading: loadingSubPayment,
    error: subPaymentError,
  } = useGetSubPaymentMethodsQuery(paymentForm.paymentMethod, {
    skip: !paymentForm.paymentMethod,
  })

  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()

  const invoiceNumber = order?.id
  const items = data?.order_payment_history ?? []
  const invoiceDetails = data?.order_items ?? []

  const orderDiscount = Number(order?.discount) ?? 0
  const subTotal = order?.total_value || 0
  const payment_status = order?.payment_status
  const tax_percentage = order?.tax_percentage
  const taxAmount = Number(order?.tax?.value || 0)
  const taxName = order?.tax?.name || 'Tax'
  const order_interface = order?.interface
  const payments = order?.payments || []
  const balance = Number(order?.balance) ?? 0
  const add_to_points = Number(order?.add_to_points) ?? 0

  const invoice_link = data?.url ? data?.url : ''

  // const currency = currencyResp?.currency || ''

  const hasItemDiscount = invoiceDetails.some((it) => Number(it.discount || 0) > 0)

  console.log('Tax Name:', invoice_link)
  // console.log('Tax Amount:', branding)

  const validateDate = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    if (isNaN(date)) return 'Invalid Date'
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  useEffect(() => {
    if (data) {
      setDetails(data)
    }
  }, [data])

  const handleRevoke = async (payment) => {
    Swal.fire({
      title: 'Revoke Payment?',
      text: 'Are you sure you want this payment to be revoked?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, revoke',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    }).then(async (result) => {
      if (!result.isConfirmed) return

      try {
        await revokePaidInvoice({
          invoice_id: payment.invoice_id,
          payment_id: payment.id, // ✅ REQUIRED
        }).unwrap()

        await refetch()

        Swal.fire({
          icon: 'success',
          title: 'Payment revoked',
          timer: 1500,
          showConfirmButton: false,
        })
      } catch (err) {
        Swal.fire({
          icon: 'error',
          title: 'Failed',
          text: err?.data?.message || 'Unable to revoke payment',
        })
      }
    })
  }

  const from = details?.fromdetails
  const customer = details?.customer_address
  const brandingSetting = branding?.data

  const handleChange = (e) => {
    const { name, value, files } = e.target

    // ✅ Only allow integers for amount
    if (name === 'amount') {
      const intRegex = /^\d+$/

      // allow empty input (so user can delete)
      if (value !== '' && !intRegex.test(value)) return
    }
    setPaymentForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
      ...(name === 'paymentMethod' && { subMethod: '' }), // reset 2nd select
    }))
  }

  const handleSubMethodChange = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    console.log(file)
    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'invoice_slip') // staging group/tag
    setUploading(true)
    try {
      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const uploaded = res?.data?.media?.[0]
      if (!uploaded?.media_url) throw new Error('Upload failed or no media returned.')
      setPaymentForm((prev) => ({ ...prev, file: uploaded.media_url }))
    } catch (e) {
      console.log(e)
    } finally {
      setUploading(false)
    }
  }

  const handleAddpayment = () => {
    const { amount, paymentMethod, subMethod, reference, file } = paymentForm

    if (!amount || !paymentMethod || !subMethod) {
      Swal.fire({
        icon: 'warning',
        title: 'Missing Required Fields',
        text: 'Amount, Payment Method and Sub Method are required.',
      })
      return
    }

    // 🔴 Reference OR File must exist
    if (paymentForm.paymentMethod == 4) {
      if (!reference && !file) {
        Swal.fire({
          icon: 'error',
          title: 'Missing Reference',
          text: 'Please provide either a reference number or upload a file.',
        })
        return
      }
    }
    // if (!reference && !file) {
    //   Swal.fire({
    //     icon: 'error',
    //     title: 'Missing Reference',
    //     text: 'Please provide either a reference number or upload a file.',
    //   })
    //   return
    // }

    console.log('Submitting payment:', paymentForm)
    Swal.fire({
      title: 'Invoice Payment',
      text: 'Are you sure you want to add this payment?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true,
    }).then(async (result) => {
      if (result.isConfirmed) {
        setLoading(true)
        try {
          const response = await axiosInstance.post(
            `/order/partiallyPayment`,
            { amount, paymentMethod, subMethod, reference, file, invoice_id: order?.id },
            
          )

          if (response.status === 200) {
            await refetch() // ✅ refresh invoice details immediately
            setPaymentForm({
              paymentMethod: '',
              subMethod: '',
              amount: '',
              reference: '',
              file: null,
            })

            Swal.fire({
              title: 'Success',
              text: 'Order added successfully',
              icon: 'success',
              confirmButtonText: 'OK',
            })

            fetchLogs(1)
            setLoading(false)
          }
        } catch (error) {
          setLoading(false)
          Swal.fire({
            title: 'Error',
            text: error?.response?.data?.message,
            icon: 'error',
            confirmButtonText: 'OK',
          })
        }
      } else if (result.isDismissed) {
        // ✅ NO clicked
        console.log('User clicked NO')
      }
    })
  }

  const handleCopyUrl = async () => {
    if (!invoice_link) return
    try {
      await navigator.clipboard.writeText(invoice_link)
      Swal.fire({
        toast: true,
        icon: 'success',
        title: 'Link copied!',
        position: 'top-end',
        showConfirmButton: false,
        timer: 1600,
        timerProgressBar: true,
      })
    } catch (err) {
      // Fallback for older browsers / non-HTTPS
      const ta = document.createElement('textarea')
      ta.value = invoice_link
      ta.style.position = 'fixed'
      ta.style.top = '-9999px'
      document.body.appendChild(ta)
      ta.select()
      try {
        document.execCommand('copy')
      } finally {
        document.body.removeChild(ta)
      }
      Swal.fire({
        toast: true,
        icon: 'success',
        title: 'Link copied!',
        position: 'top-end',
        showConfirmButton: false,
        timer: 1600,
        timerProgressBar: true,
      })
    }
  }

  const handlePrint = async () => {
    if (printLoading) return
    setPrintLoading(true)
    try {
      const response = await axiosInstance.post(
        `/order/print-catelog`,
        { id: invoiceNumber },
        
      )

      if (response.status === 200) {
        printcatelog(response.data.details)
      }
    } catch (error) {
      setLoading(false)
      console.log(error)
      Swal.fire({
        title: 'Error',
        text: error?.response?.data?.message || 'Something went wrong',
        icon: 'error',
        confirmButtonText: 'OK',
      })
    } finally {
      setPrintLoading(false)
    }
  }

  const printcatelog = (dataArray) => {
    const printWindow = window.open('', '_blank')

    const productsHTML = dataArray
      .map((item) => {
        // Sanitize description and handle potential nulls
        const descriptionText = typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize(item.description || '') : item.description || ''

        return `
      <div class="product-block">
        <div class="product-title">
          ${item.title || 'N/A'} <span class="product-id">(ID: ${item.product_id || '-'})</span>
        </div>

        <div class="content">
          <div class="description">
            ${descriptionText ? descriptionText : '<span class="no-data">No description available</span>'}
          </div>

          <div class="image">
            ${item.main_img ? `<img src="${item.main_img}" alt="Product Image" />` : ''}
          </div>
        </div>
      </div>
    `
      })
      .join('')

    const htmlContent = `
  <!DOCTYPE html>
  <html>
    <head>
      <title>Catalog Print</title>
      <style>
        @page {
          size: A4;
          margin: 15mm;
        }

        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 2.5rem;
          color: #333;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 2px solid #000;
          padding-bottom: 10px;
          margin-bottom: 20px;
          /* Prevents the header from being lonely on a page */
          page-break-after: avoid;
        }

        .logo img {
          max-width: 150px;
          max-height: 60px;
          object-fit: contain;
        }

        .company {
          text-align: right;
          font-size: 13px;
        }

        .product-block {
          margin-bottom: 30px;
          padding-bottom: 20px;
          border-bottom: 1px solid #eee;
          /* Key fix: prevents a product from being split across two pages */
          page-break-inside: avoid;
          break-inside: avoid;
        }

        .product-title {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 12px;
          color: #000;
        }

        .product-id {
          font-weight: normal;
          font-size: 14px;
          color: #666;
        }

        .content {
          display: flex;
          gap: 25px;
          align-items: flex-start;
        }

        .description {
          flex: 2;
          font-size: 14px;
          line-height: 1.5;
          /* Preserves line breaks from your text editor */
          white-space: pre-line;
        }

        .image {
          flex: 1;
          text-align: right;
        }

        .image img {
          max-width: 100%;
          max-height: 180px; /* Increased for better visibility */
          object-fit: contain;
          border: 1px solid #f0f0f0;
          border-radius: 4px;
        }

        .no-image {
          border: 1px dashed #ccc;
          padding: 20px;
          font-size: 12px;
          color: #999;
          text-align: center;
        }

        .no-data {
          color: #999;
          font-style: italic;
        }

        .tile{
          background: 'linear-gradient(315deg, #000000 0%, var(--bs-primary) 50%, var(--bs-primary) 80%, white 100%)',
          color: '#fff',
          padding: '8px 40px 8px 70px',
          fontWeight: 'bold',
          fontSize: '1.2rem',
          letterSpacing: '2px',
          textTransform: 'uppercase',
          clipPath: 'polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%)',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
        }

        /* Hide the print button if it existed, though not used in this script */
        @media print {
          button { display: none; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="logo">
          ${brandingSetting?.logo_url_white ? `<img src="${brandingSetting.logo_url_white}" />` : '<div></div>'}
        </div>
        <div class="company"> 
          <div><strong>${brandingSetting?.company_name || 'Company Name'}</strong></div>
          <div class="tile">Product Catalog</div>
        </div>
      </div>

      <div class="catalog-container">
        ${productsHTML}
      </div>

      <script>
        // Wait for all images to load before opening the print dialog
        window.onload = () => {
          setTimeout(() => {
            window.print();
            // Optional: window.close(); 
            // Note: window.close() might trigger before printing finishes in some browsers.
          }, 500);
        };
      </script>
    </body>
  </html>
  `

    printWindow.document.write(htmlContent)
    printWindow.document.close()
  }

  useEffect(() => {
    if (subPaymentData?.rows?.length === 1) {
      setPaymentForm((prev) => ({
        ...prev,
        subMethod: subPaymentData.rows[0].value,
      }))
    }
  }, [subPaymentData])

  return (
    <Modal show={show} onHide={onClose} size="lg" dialogClassName="modal-90w" centered>
      <Modal.Header closeButton>
        <Modal.Title>Invoice # {invoiceNumber}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="print-area">
          <Row>
            <Col xs={12}>
              {isLoading ? (
                <div className="d-flex justify-content-center mt-2">
                  <div className="spinner-border" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <Card>
                  <CardBody className="border-bottom pb-2 py-0 ">
                    <Row className="align-items-center border-bottom pb-1 mb-1">
                      {/* Company Info */}
                      <Col className="d-flex align-items-center">
                        <Image
                          src={brandingSetting?.logo_url_white || ''}
                          alt="logo-small"
                          className="me-2"
                          height={200}
                          width={500}
                          style={{ width: '120px', height: 'auto' }}
                        />
                      </Col>

                      {/* Right Corner Info (Aligned to Table End) */}
                      <Col className="ms-auto text-end">
                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Invoice:</span> #{invoiceNumber}
                        </div>

                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Date:</span>
                          {new Date(order.created_at).toLocaleString('en-LK', {
                            timeZone: 'Asia/Colombo',
                            year: 'numeric',
                            month: 'short',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>

                        {payment_status && (
                          <div className="mt-1 d-inline-block">
                            <span
                              className="rounded text-uppercase"
                              style={{
                                fontSize: '0.8rem',
                                fontWeight: 600,
                                lineHeight: '1rem',
                                backgroundColor: payment_status === 'paid' ? '#198754' : payment_status === 'partially paid' ? '#ffc107' : '#dc3545',
                                color: payment_status === 'partially paid' ? '#000' : '#fff',
                                padding: '2px 12px',
                              }}>
                              {payment_status}
                            </span>
                          </div>
                        )}
                      </Col>
                    </Row>

                    <Row className="row-cols-3 d-flex justify-content-md-between">
                      <Col md={7} className="d-print-flex align-self-center">
                        <div>
                          <address className="fs-13">
                            <span className="fs-12 text-muted">From :</span>
                            <div className="fw-bold">{from?.company_name}</div>
                            <div>{from?.address_1}</div>
                            {from?.address_2 && <div>{from?.address_2}</div>}
                            <div>Hotline: {from?.hotline}</div>
                          </address>
                        </div>
                      </Col>
                      <Col md={5} className="d-print-flex align-self-center">
                        <div>
                          {order_interface === 'pos' ? (
                            <address className="fs-13">
                              <span className="fs-12 text-muted">Invoice to :</span>
                              <br />
                              <div className="fw-bold">{order.customer_id ? `${order.customer_name} (${order.customer_id})` : 'POS Client'}</div>
                              {/* <div>{order?.sender_email}</div>

                              <div>Hotline: {order?.sender_phone}</div> */}
                            </address>
                          ) : (
                            <address className="fs-13">
                              <span className="fs-12 text-muted">Invoice to :</span>
                              <br />
                              <div className="fw-bold">{order?.sender_name}</div>
                              <div>{order?.sender_email}</div>
                              <div>{order?.sender_address}</div>
                              <div>{order?.sender_addrees_2}</div>
                              <div>Hotline: {order?.sender_phone}</div>
                            </address>
                          )}
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={12}>
                        <div className="table-responsive project-invoice">
                          <table className="table table-bordered mb-0">
                            <thead className="table-light">
                              <tr>
                                <th>Order Details</th>
                                <th className="text-center">Quantity</th>
                                <th className="text-end">Unit Price ({currency})</th>
                                {hasItemDiscount && <th> Discount </th>}
                                <th className="text-end">Amount ({currency})</th>
                              </tr>
                            </thead>

                            <tbody>
                              {invoiceDetails.map((it, idx) => (
                                <tr key={idx}>
                                  <td>
                                    <h5 className="mb-1 fs-12">
                                      #{it.product_id} - {it.name}
                                    </h5>

                                    {it.variant_value && it.variant_value !== 'Default' && <div className="text-muted fs-10">{it.variant_value}</div>}
                                  </td>

                                  <td className="text-center">
                                    {it.unit_type == 1 ? it.quantity : it.quantity * Number(it.amount_per_unit)}
                                    {it.unit_type != 1 && it.measurement_value}

                                    {it.free_quantity >= 1 && (
                                      <span style={{ color: 'green', fontWeight: 'bold' }}>
                                        {' + '}
                                        {it.unit_type == 1 ? it.free_quantity : it.free_quantity * Number(it.amount_per_unit)}
                                        {it.unit_type != 1 && it.measurement_value} FREE
                                      </span>
                                    )}
                                  </td>

                                  <td className="text-end">{Number(it.unit_price).toFixed(2)}</td>

                                  {hasItemDiscount && <td className="text-end">{Number(it.discount).toFixed(2)}</td>}
                                  <td className="text-end">
                                    {/* {Number(it.total_price).toFixed(2)} */}
                                    {Number(it.discount) > 0 ? (
                                      <div>
                                        <div
                                          style={{
                                            textDecoration: 'line-through',
                                            color: '#6b7280',
                                            fontSize: 11,
                                            fontWeight: 500,
                                          }}>
                                          {Number(it.total_price).toFixed(2)}
                                        </div>
                                        <div style={{ color: '#111827', fontWeight: 700 }}>
                                          {(Number(it.total_price) - Number(it.discount)).toFixed(2)}
                                        </div>
                                      </div>
                                    ) : (
                                      Number(it.total_price).toFixed(2)
                                    )}
                                  </td>
                                </tr>
                              ))}
                              {Number(subTotal) !== Number(order?.full_amount) && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      Sub Total
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{Number(subTotal).toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}

                              {Number(orderDiscount) > 0 &&
                                order?.discount_type != 'product' &&
                                order?.discount_type != 'buyx' &&
                                order?.discount_type != 'manual_product' && (
                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                      <b
                                        style={{
                                          display: 'inline-block',
                                          width: '120px',
                                          textAlign: 'left',
                                          marginRight: '4px',
                                          whiteSpace: 'nowrap',
                                        }}>
                                        {{
                                          order: 'Order Discount',
                                          product: 'Product Discount',
                                          payment_method: 'Payment Method Discount',
                                          shipping: 'Delivery Fee Discount',
                                          buyxgety: 'BuyXGetY Discount',
                                        }[order?.discount_type] || 'Discount'}
                                      </b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end p-1">
                                      <b>{orderDiscount.toFixed(2)}</b>
                                    </td>
                                  </tr>
                                )}

                              {Number(taxAmount) > 0 && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      {taxName} ({Number(tax_percentage)}%)
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{Number(taxAmount).toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}

                              <tr>
                                <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                  <b
                                    style={{
                                      display: 'inline-block',
                                      width: '120px',
                                      textAlign: 'left',
                                      marginRight: '4px',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    Total
                                  </b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end p-1">
                                  {/* <b>{(Number(order?.full_amount) + Number(order?.loyalty_points_spent)).toFixed(2)}</b> */}
                                  <b>{Number(order?.full_amount).toFixed(2)}</b>
                                </td>
                              </tr>

                              {Number(order?.loyalty_points_spent) > 0 && order_interface != 'pos' && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      Loyalty Points Redeemed
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{Number(order?.loyalty_points_spent).toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}

                              {payment_status === 'partially paid' && (
                                <>
                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-success text-end p-1">
                                      <b
                                        style={{
                                          display: 'inline-block',
                                          width: '120px',
                                          textAlign: 'left',
                                          marginRight: '4px',
                                          whiteSpace: 'nowrap',
                                        }}>
                                        Paid Amount
                                      </b>
                                    </td>
                                    <td className="border-0 fs-12 text-success text-end p-1">
                                      <b>{Number(order?.amount_paid || 0).toFixed(2)}</b>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-danger text-end p-1">
                                      <b
                                        style={{
                                          display: 'inline-block',
                                          width: '120px',
                                          textAlign: 'left',
                                          marginRight: '4px',
                                          whiteSpace: 'nowrap',
                                        }}>
                                        Total Due
                                      </b>
                                    </td>
                                    <td className="border-0 fs-12 text-danger text-end p-1">
                                      <b>{(Number(order?.full_amount || 0) - Number(order?.amount_paid || 0)).toFixed(2)}</b>
                                    </td>
                                  </tr>
                                </>
                              )}

                              {payments.map((payment, index) => (
                                <tr key={index}>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                        textTransform: 'capitalize',
                                      }}>
                                      {payment.type}
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{Number(payment?.total_amount).toFixed(2)}</b>
                                  </td>
                                </tr>
                              ))}

                              {add_to_points > 0 && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      Add To Points
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{add_to_points.toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}
                              {balance > 0 && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b
                                      style={{
                                        display: 'inline-block',
                                        width: '120px',
                                        textAlign: 'left',
                                        marginRight: '4px',
                                        whiteSpace: 'nowrap',
                                      }}>
                                      Balance
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{balance.toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </Row>

                    {order_interface != 'pos' && (
                      <div className=" mt-2 rounded">
                        {payment_status !== 'paid' && (
                          <div className="border shadow-sm rounded p-2 ">
                            <div className="fs-14 fw-bold mb-1">Add Payment</div>
                            <Row className="g-1 p-0 m-0">
                              <Col xs={12} md={6}>
                                <select className="form-select" name="paymentMethod" value={paymentForm.paymentMethod} onChange={handleChange}>
                                  <option value="">Select Payment Method</option>
                                  {paymentData?.result?.map((method) => (
                                    <option key={method.value} value={method.value}>
                                      {method.label}
                                    </option>
                                  ))}
                                </select>
                              </Col>

                              {paymentForm.paymentMethod && (
                                <Col xs={12} md={6}>
                                  {subPaymentData?.rows?.length === 1 ? (
                                    // ✅ SHOW TEXT (like your image)
                                    <div className="form-control d-flex align-items-center border-0 d-flex align-items-center">
                                      <span
                                        className="text-warning fw-bold me-1 border border-warning rounded-circle d-flex align-items-center justify-content-center"
                                        style={{ width: '18px', height: '18px' }}>
                                        !
                                      </span>
                                      Amount Collect to ➡ <strong>{subPaymentData.rows[0].label}</strong>
                                    </div>
                                  ) : (
                                    // ✅ SHOW DROPDOWN
                                    <select
                                      className="form-select"
                                      name="subMethod"
                                      value={paymentForm.subMethod}
                                      onChange={handleChange}
                                      disabled={loadingSubPayment}>
                                      <option value="">
                                        {loadingSubPayment ? 'Loading...' : subPaymentError ? 'Failed to load' : 'Select Option'}
                                      </option>

                                      {subPaymentData?.rows?.map((item) => (
                                        <option key={item.value} value={item.value}>
                                          {item.label}
                                        </option>
                                      ))}
                                    </select>
                                  )}
                                </Col>
                              )}
                            </Row>
                            <Row className="g-1 p-0 m-0">
                              <Col xs={12} md={4}>
                                <input
                                  type="text"
                                  className="form-control"
                                  name="amount"
                                  placeholder="Amount"
                                  value={paymentForm.amount}
                                  onChange={handleChange}
                                />
                              </Col>

                              <Col xs={12} md={4}>
                                <input
                                  type="text"
                                  className="form-control"
                                  name="reference"
                                  placeholder="Reference/note"
                                  value={paymentForm.reference}
                                  onChange={handleChange}
                                />
                              </Col>
                              {paymentForm.paymentMethod == 4 && (
                                <Col xs={12} md={4}>
                                  <input type="file" className="form-control" name="file" onChange={handleSubMethodChange} disabled={uploading} />
                                </Col>
                              )}

                              <Col xs={12} md={4} className="d-flex justify-content-end">
                                <Button onClick={handleAddpayment} disabled={uploading || loading} className="flex-grow-1" variant="primary">
                                  Add payment
                                </Button>
                              </Col>
                            </Row>
                          </div>
                        )}

                        {/* Top: Table */}
                        {items.length > 0 && (
                          <div className="mt-3">
                            <div className="table-responsive">
                              <table className="table table-bordered w-100 mb-0" style={{ tableLayout: 'fixed' }}>
                                <thead className="table-light fs-12 fw-bold">
                                  <tr>
                                    <th className="px-2 py-1 text-start">Date</th>
                                    <th className="px-2 py-1 text-start">Method</th>
                                    <th className="px-2 py-1 text-start">Reference</th>
                                    <th className="px-2 py-1 text-end">Amount ({currency})</th>
                                    <th className="px-2 py-1 text-start no-print">Status</th>
                                    <th className="px-2 py-1 text-start no-print">Action</th>
                                  </tr>
                                </thead>

                                <tbody className="text-[0.7rem]">
                                  {items.map((it, idx) => (
                                    <tr key={idx} className="odd:bg-gray-50">
                                      <td className="px-2 py-1 border">{validateDate(it.date)}</td>
                                      <td className="px-2 py-1 border">{it.method_name}</td>
                                      <td className="px-2 py-1 border">{it.reference || '-'}</td>
                                      <td className="px-2 py-1 border text-end">{Number(it.amount).toFixed(2)}</td>
                                      <td className="px-2 py-1 border text-capitalize no-print">{it.status}</td>

                                      <td className="px-1 py-1 border no-print text-center">
                                        <span className="action-inline">
                                          {/* VIEW */}
                                          {it.doc ? (
                                            <a href={it.doc} target="_blank" rel="noopener noreferrer" className="badge action-badge view-badge">
                                              View
                                            </a>
                                          ) : (
                                            <span className="badge action-badge disabled-badge">View</span>
                                          )}

                                          {/* REVOKE */}
                                          {it.status === 'revoked' ? (
                                            <span className="badge action-badge disabled-badge">Revoke</span>
                                          ) : (
                                            <span className="badge action-badge revoke-badge" role="button" onClick={() => handleRevoke(it)}>
                                              Revoke
                                            </span>
                                          )}
                                        </span>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="w-full mt-4">
                      <h6 className="mb-2 text-sm font-semibold">Terms And Conditions :</h6>
                      <ul className="pl-4 text-xs space-y-1 list-disc">
                        <li>All accounts are to be paid within 7 days from receipt of invoice.</li>
                        <li>To be paid by cheque, credit card, or direct payment online.</li>
                        <li>
                          If account is not paid within 7 days, the credit details supplied as confirmation of work undertaken will be charged the
                          agreed quoted fee noted above.
                        </li>
                      </ul>
                    </div>

                    <hr />
                    <Row className="d-flex justify-content-center">
                      <Col className="d-flex justify-content-center">
                        <div className="text-center white-space-nowrap">
                          <small className="fs-12">Thank you very much for doing business with us.</small>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                  <style jsx global>{`
                    /* =========================
   SCREEN ONLY
========================= */
                    .modal-footer {
                      display: flex;
                      justify-content: flex-end;
                      gap: 8px;
                    }

                    /* =========================
   PRINT SETUP
========================= */
                    @media print {
                      @page {
                        size: A4;
                        margin: 0;
                      }

                      html,
                      body {
                        width: 210mm;
                        height: 297mm;
                        margin: 0 !important;
                        padding: 0 !important;
                        background: #fff !important;
                        overflow: hidden !important;
                      }

                      /* Hide everything except modal */
                      body > *:not(.modal) {
                        display: none !important;
                      }

                      /* Modal becomes document */
                      .modal {
                        position: fixed !important;
                        inset: 0 !important;
                        display: block !important;
                        background: #fff !important;
                        margin: 0 !important;
                        padding: 0 !important;
                      }

                      .modal-dialog,
                      .modal-content {
                        width: 100% !important;
                        height: 100% !important;
                        max-width: 100% !important;
                        margin: 0 !important;
                        padding: 0 !important;
                        border: none !important;
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      /* Remove modal chrome */
                      .modal-header,
                      .modal-footer {
                        display: none !important;
                      }

                      /* Printable area */
                      .print-area {
                        width: 100% !important;
                        height: 100% !important;
                        margin: 0 !important;
                        padding: 16px !important;
                        background: #fff !important;
                      }

                      /* Remove UI effects */
                      .card,
                      .shadow,
                      .shadow-sm,
                      .rounded,
                      .border {
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      .card {
                        border: none !important;
                      }

                      .card-body {
                        padding: 10px !important;
                      }

                      .row {
                        margin: 0 !important;
                      }

                      [class*='col-'] {
                        padding: 0 !important;
                      }

                      /* =========================
     TOTALS – LABELS CLOSER
  ========================= */
                      .project-invoice tbody tr td {
                        padding-top: 4px !important;
                        padding-bottom: 4px !important;
                      }

                      .project-invoice tbody tr td:nth-child(3) {
                        padding-right: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      .project-invoice tbody tr td:nth-child(4) {
                        padding-left: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      /* =========================
     TABLE SAFETY
  ========================= */
                      table {
                        width: 100% !important;
                        page-break-inside: auto;
                      }

                      tr {
                        page-break-inside: avoid;
                      }

                      thead {
                        display: table-header-group;
                      }

                      /* =========================
     HIDE ADD PAYMENT (PRINT)
  ========================= */
                      .print-area .fs-14.fw-bold.mb-1,
                      .print-area .fs-14.fw-bold.mb-1 + .row {
                        display: none !important;
                      }

                      /* =========================
     NO-PRINT UTILITY
  ========================= */
                      .no-print {
                        display: none !important;
                      }

                      /* Hide form controls */
                      button,
                      input,
                      select {
                        display: none !important;
                      }

                      .modal-backdrop {
                        display: none !important;
                      }
                    }
                    /* =========================
   ACTION BADGES
========================= */
                    .action-badge {
                      font-size: 0.7rem;
                      padding: 4px 8px;
                      font-weight: 600;
                      border-radius: 4px;
                      transition: all 0.2s ease;
                      user-select: none;
                    }

                    /* View */
                    .view-badge {
                      background-color: rgba(13, 110, 253, 0.1);
                      color: #0d6efd;
                      text-decoration: none;
                    }

                    .view-badge:hover {
                      background-color: #0d6efd;
                      color: #fff;
                    }

                    /* Revoke */
                    .revoke-badge {
                      background-color: rgba(220, 53, 69, 0.1);
                      color: #dc3545;
                    }

                    .revoke-badge:hover {
                      background-color: #dc3545;
                      color: #fff;
                    }

                    /* Disabled */
                    .disabled-badge {
                      background-color: rgba(108, 117, 125, 0.15);
                      color: #6c757d;
                      opacity: 0.6;
                      cursor: not-allowed;
                    }
                    /* =========================
   COMPACT ACTION BUTTONS
========================= */
                    .action-inline {
                      display: inline-flex;
                      gap: 3px;
                      max-width: 100%;
                      white-space: nowrap;
                    }

                    /* =========================
   ACTION BADGES – DARK BLUE / BLACK
========================= */

                    /* Base – KEEP sizing unchanged */
                    .action-badge {
                      display: inline-flex;
                      align-items: center;
                      justify-content: center;

                      font-size: 0.7rem;
                      padding: 4px 8px;
                      min-width: 50px;
                      height: 22px;
                      line-height: 1;

                      font-weight: 600;
                      border-radius: 5px;
                      user-select: none;
                      transition:
                        background-color 0.2s ease,
                        box-shadow 0.2s ease;
                    }

                    /* VIEW – Dark Blue */
                    .view-badge {
                      background-color: #134c92ff; /* deep navy blue */
                      color: #ffffff;
                    }

                    .view-badge:hover {
                      background-color: #082e5c;
                    }

                    /* REVOKE – Soft Black */
                    .revoke-badge {
                      background-color: #6d1818ff; /* charcoal black */
                      color: #ffffff;
                    }

                    .revoke-badge:hover {
                      background-color: #111827;
                    }

                    /* DISABLED */
                    .disabled-badge {
                      background-color: #6b7280; /* muted gray */
                      color: #ffffff;
                      opacity: 0.6;
                      cursor: not-allowed;
                    }

                    /* Subtle premium depth */
                    .view-badge,
                    .revoke-badge {
                      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
                    }
                  `}</style>
                </Card>
              )}
            </Col>
          </Row>
        </div>
      </Modal.Body>
      <Modal.Footer className="no-print">
        <div className="d-flex justify-content-between w-100">
          <div className="d-flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Close
            </Button>
            <Button
              className="d-inline-flex align-items-center gap-1"
              style={{
                padding: '0.45rem 0.9rem',
                borderRadius: '9999px',
              }}
              variant="dark"
              onClick={handleCopyUrl}
              disabled={!invoice_link}
              title="Copy link to clipboard">
              <Icon icon="mdi:content-copy" width={18} height={18} />
              <span className="d-none d-sm-inline">Copy Link</span>
            </Button>
          </div>
          <div className="d-flex gap-2">
            <Button variant="primary" disabled={printLoading} onClick={handlePrint}>
              Print catelog
            </Button>
            <Button variant="primary" onClick={() => window.print()}>
              Print
            </Button>
          </div>
        </div>
      </Modal.Footer>
    </Modal>
  )
}
