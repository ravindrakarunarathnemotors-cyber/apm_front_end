import dynamic from 'next/dynamic'

export const metadata = {
  title: 'All Order Invoices',
}

const AllOrders = dynamic(() => import('./AllOrders'), { ssr: false })

export default function AllOrdersPage() {
  return <AllOrders />
}