'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
// import Link from 'next/link'
// import IconifyIcon from '@/components/wrappers/IconifyIcon'
//import EditOrderModal from './EditOrderModal'

import { useRouter } from 'next/navigation'

import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  //FormControl,
  Button,
  Table,
  Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import Swal from 'sweetalert2'

import InvoiceModal from './modal/InvoicModal'
import Paymentmodal from '@/components/Order/paymentmodal'
//import Paymentmodal from '@/components/Order/InlineAddPayment'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import CancelModal from '@/components/Order/cancelModal'
import {
  useGetFilteredAllOrdersMutation,
  useGetRecipientnameQuery,
  // useGetActiveDeliveryPartnersQuery,
  // useAssignOrderMutation,
  // useProcessingOrdersOrderMutation,
  useCancelOrderMutation,

} from '@/store/features/apiSlice'

function AllOrders() {

  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })

  const [orderStatuses, setOrderStatuses] = useState([])
  const [fetchFilteredOrders, { isLoading, error }] = useGetFilteredAllOrdersMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [orders, setLogs] = useState([])
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [loading, setLoading] = useState(false)
  //const [showViewModal, setShowViewModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showEditModal, setShowEditModal] = useState(false)
  const [editOrderData, setEditOrderData] = useState(null)
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrderId, setCancelOrderId] = useState(null)
  const [paymentMode, setPaymentMode] = useState('add')
  const printSectionRef = useRef()
  const [currency, setCurrency] = useState('')
  const router = useRouter()

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })
  // const [assignOrder] = useAssignOrderMutation()
  // const [processingOrder] = useProcessingOrdersOrderMutation()
  const [cancelOrder] = useCancelOrderMutation()
  // const [markOrderAsDispatched] = useMarkOrderAsDispatchedMutation()
  //const [deliverdOrder] = useDeliverdOrderMutation()
  // const [confirmOrder] = useConfirmOrdersOrderMutation()

  // const { data: activePartnersData = [], isLoading: loadingPartners } = useGetActiveDeliveryPartnersQuery()
  // const orderStatusOptions = [
  //   { label: 'Pending', value: 'pending' },
  //   { label: 'Confirmed', value: 'confirmed' },
  //   { label: 'Processing', value: 'processing' },
  //   { label: 'Dispatched', value: 'dispatched' },
  //   { label: 'Completed', value: 'completed' },
  //   { label: 'Cancelled', value: 'cancelled' },
  //   { label: 'Returned', value: 'returned' },
  // ]
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  // const handleView = (order) => {
  //   setSelectedOrderId(order)
  //   setShowViewModal(true)
  // }

  const handlePayment = (order, mode = 'add') => {
    setSelectedOrderId(order)
    setPaymentMode(mode)
    setShowPaymentModal(true)
  }

  // const handleUnpaidClick = (order_id) => {
  //   setSelectedOrderId(order_id)
  //   setShowUnpaidModal(true)
  // }

  // const handleUnpaidCloseModal = () => {
  //   setShowUnpaidModal(false)
  //   setSelectedOrderId(null)
  // }

  const fetchLogs = async (page) => {
    setLoading(true)
    try {

      const res = await fetchFilteredOrders({
        page,
        limit,
        keyword: filters.keyword,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        payment_status: paymentStatus,
        date: date,
        todate: todate,
        order_status: orderStatuses.map((s) => s.value),
      }).unwrap()

      setLogs(res.orders || [])
      setTotalPages(res.totalPages || 1)
      setCurrency(res.currency || res.orders?.[0]?.currency || '')
      setTotalEntries(res.total || 0)
      setCurrency(res.orders?.[0]?.currency || '')
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch orders:', err)

    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage, limit])

  // const handleConfirm = (orderId) => {
  //   setSelectedOrderId(orderId)
  //   setShowModal(true)
  // }
  const paymentStatusBadge5 = (status) => {
    const colorMap = {
      processing: '#fd7e14',
      pending: '#6c757d',
      completed: '#198754',
      dispatched: '#0d6efd',
      returned: '#6f42c1',
      confirmed: '#20c997',
      cancelled: '#dc3545',
    }

    const backgroundColor = colorMap[status?.toLowerCase()] || '#adb5bd'

    return (
      <span
        style={{
          backgroundColor,
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        {status}
      </span>
    )
  }

  // const paymentStatusBadge = (status) => {
  //   const colorMap = {
  //     paid: 'success',
  //     unpaid: 'danger',
  //     refund: 'secondary',
  //     failed: 'danger',
  //   }

  //   const color = colorMap[status] || 'secondary'
  //   const capitalizedStatus = status.charAt(0).toUpperCase() + status.slice(1)

  //   return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  // }

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  const handleConfirmCancelFromModal = async (orderIdToCancel, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelOrder({
        order_id: orderIdToCancel,
        status: 'cancelled',
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh list
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await fetchLogs(currentPage)
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const [selectedOrder, setSelectedOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)

  const handleView = (order) => {
    setSelectedOrder(order) // store the full order object
    setShowViewModal(true)
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  All Order Invoices
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-4">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>Payment</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="paid">Paid</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="partially paid">Partially Paid</option>
                </Form.Select>
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button variant="primary" className="flex-grow-1 bg-primary border-primary" onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>
            {isLoading ? (
              <p>Loading Orders...</p>
            ) : error ? (
              <p>Error Loading Orders.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <div className="table-responsive">
                    <Table striped className="table mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>Invoice ID</th>
                          <th>Date</th>
                          <th>Client</th>

                          <td>Payment Method</td>
                          {/* <th>Courier</th>
                        <th>Tracking</th> */}
                          <th>Payment Status</th>
                          <th className="text-end">Total ({currency})</th>

                          <th className="text-center no-print">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.length === 0 ? (
                          <tr>
                            <td colSpan="5" className="text-center">
                              No Orders found.
                            </td>
                          </tr>
                        ) : (
                          orders.map((order) => (
                            <tr key={order.order_id}>
                              <td>{order.order_id ? `O-${order.order_id}` : '-'}</td>
                              <td>{new Date(order.created_at).toLocaleDateString()}</td>
                              <td>
                                {order.customer_name}
                                <br />
                                <small>{order.contact_number}</small>
                              </td>

                              <td>{order.method_name}</td>
                              {/* //<td> {order.delivery_partner_name || '-'}</td> */}
                              {/* <td>{order.tracking_id || '-'}</td> */}
                              <td>
                                {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}

                                {hasSlip(order) && (
                                  <div className="mt-1 no-print">
                                    <Button
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.2rem 0.1rem',
                                        fontSize: '0.55rem',
                                        height: '20px',
                                        borderRadius: '15px',
                                        backgroundColor: '#3d3642ff',
                                        borderColor: '#3d3642ff',
                                        color: '#fff',
                                      }}
                                      variant="outline-primary"
                                      onClick={() => openSlip(order)}
                                      title="Open bank slip"
                                      className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                      <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                      Slip
                                    </Button>
                                  </div>
                                )}
                              </td>
                              {/* <td>{paymentStatusBadge(order.payment_status)}</td> */}

                              <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>

                              <td className="text-end no-print">
                                <div className="d-flex flex-row align-items-center justify-content-end gap-2">
                                  {order.payment_status?.toLowerCase() === 'unpaid' && (
                                    <>
                                      <Button
                                        className="d-flex align-items-center"
                                        style={{
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#dc3545',
                                          borderColor: '#dc3545',
                                          color: '#fff',
                                        }}
                                        onClick={() => {
                                          setCancelOrderId(order.order_id)
                                          setShowCancelModal(true)
                                        }}>
                                        <Icon icon="mdi:close" width={18} className="me-1" />
                                        Cancel
                                      </Button>
                                    </>
                                  )}
                                  {(order.payment_status?.toLowerCase() === 'unpaid' || order.payment_status?.toLowerCase() === 'partially paid') &&
                                    order.order_status?.toLowerCase() === 'pending' && (
                                      <Button
                                        className="d-flex align-items-center"
                                        style={{
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#5dbbd3ff',
                                          borderColor: '#5dbbd3ff',
                                          color: '#fff',
                                        }}
                                        onClick={() => handlePayment(order, 'add')}>
                                        <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                        <span>Add Payment</span>
                                      </Button>
                                    )}

                                  {(order.payment_status?.toLowerCase() === 'unpaid' || order.payment_status?.toLowerCase() === 'partially paid') &&
                                    order.order_status?.toLowerCase() !== 'pending' && (
                                      <Button
                                        className="d-flex align-items-center"
                                        style={{
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#035f1c',
                                          borderColor: '#035f1c',
                                          color: '#fff',
                                        }}
                                        onClick={() => handlePayment(order, 'markPaid')}>
                                        <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                        <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                                      </Button>
                                    )}

                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#007bff',
                                      borderColor: '#007bff',
                                      color: '#fff',
                                    }}
                                    onClick={() => handleView(order)}>
                                    <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>View</span>
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </Table>
                  </div>
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalEntries={totalEntries}
                  limit={limit}
                  onPageChange={(page) => {
                    setCurrentPage(page)
                  }}
                  onLimitChange={(val) => {
                    setLimit(val)
                    setCurrentPage(1)
                  }}
                  showingFrom={
                    orders.length === 0 ? 0 : (currentPage - 1) * limit + 1
                  }
                  showingTo={
                    orders.length === 0
                      ? 0
                      : (currentPage - 1) * limit + orders.length
                  }
                />
              </>
            )}
          </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <InvoiceModal
          show={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedOrder(null)
          }}
          order={selectedOrder} // <-- pass the selected order here
        />
      )}
      {showPaymentModal && selectedOrderId && (
        <Paymentmodal
          show={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          order={selectedOrderId}
          order_id={selectedOrderId.order_id}
          payment_method_id={selectedOrderId.payment_method_id}
          mode={paymentMode}
        />
      )}

      {showUnpaidModal && selectedOrderId && (
        <UnpaidModal show={showUnpaidModal} onClose={() => setShowUnpaidModal(false)} order_id={selectedOrderId.order_id} />
      )}
      <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      />
    </Row>
  )
}

export default AllOrders
