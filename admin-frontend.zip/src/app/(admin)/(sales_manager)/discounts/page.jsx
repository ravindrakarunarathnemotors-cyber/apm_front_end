import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Discounts',
}

// Dynamically import the Discounts component
const Discounts = dynamic(() => import('./DiscountList.jsx'), { ssr: false })

export default function DiscountsPage() {
  return <Discounts />
}
