'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import Swal from 'sweetalert2'
import Router from 'next/router'
import { Icon } from '@iconify/react'
import { useGetDiscountByIdQuery, useUpdateProductDiscountSelectiveMutation, useGetDiscountTargetsMutation } from '@/store/features/apiSlice'

export default function BuyXGetY({
  discountId, // id to load (edit mode)
  onDirty,
  prefill = null, // optional fallback object (shape like response.data)
  targetProducts = [],
  targetBrands = [],
  targetCollections = [],
  targetCategories = [],
}) {
  // -------------------- Form state (start BLANK; only fill from response) --------------------
  const [title, setTitle] = useState('')

  const [buyQty, setBuyQty] = useState('') // '' until response/user
  const [getQty, setGetQty] = useState('') // '' until response/user

  const [limitMaxGet, setLimitMaxGet] = useState(false)
  const [maxGetPerOrder, setMaxGetPerOrder] = useState('') // '' unless response/user

  const [eligibility, setEligibility] = useState('all') // radios OK to default to 'all'
  const [guestIncluded, setGuestIncluded] = useState(false)

  const [limitPerUserOnce, setLimitPerUserOnce] = useState(false)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('') // '' unless response/user

  // Dates
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // -------------------- Hooks --------------------
  const numericId = Number(discountId)
  const { data: fetched, isLoading: loading, isFetching, error: fetchError } = useGetDiscountByIdQuery(numericId, { skip: !numericId })

  const [errors, setErrors] = useState({})

  // Update mutation only
  const [updateProductSelective, { isLoading: saving }] = useUpdateProductDiscountSelectiveMutation()

  // ----- RTKQ fetch targets mutation hook (trigger) -----
  // returns [trigger, result]
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult

  // store fetched target objects
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  // Track the currently-hydrated prefill so Discard can restore to it
  const lastPrefillRef = useRef(null)

  // ---------- minimal time helpers/state ----------
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    const hh = String(d.getHours()).padStart(2, '0')
    const mm = String(d.getMinutes()).padStart(2, '0')
    return `${hh}:${mm}`
  }

  const timeToMinutes = (t) => {
    if (!t) return NaN
    const parts = String(t).split(':').map(Number)
    if (parts.length < 2 || !Number.isFinite(parts[0]) || !Number.isFinite(parts[1])) return NaN
    return parts[0] * 60 + parts[1]
  }

  const minutesToTime = (m) => {
    if (!Number.isFinite(m)) return ''
    const hh = Math.floor(m / 60) % 24
    const mm = m % 60
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
  }

  // -------------------- Unsaved Changes Guard (pleasant modal) --------------------
  const RouterEvents = Router?.events
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    setDirty(true)
    onDirty?.()
  }
  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'router' | 'link' | 'history' | 'reload'
  const allowNavRef = useRef(false)

  const cancelNavigation = () => {
    setShowPrompt(false)
    pendingActionRef.current = null
    setPendingHref(null)
  }
  const proceedNavigation = () => {
    setShowPrompt(false)
    allowNavRef.current = true
    const action = pendingActionRef.current
    const href = pendingHref
    pendingActionRef.current = null
    setPendingHref(null)

    if (action === 'router' && href) {
      Router.push(href)
      return
    }
    if (action === 'link' && href) {
      window.location.href = href
      return
    }
    if (action === 'history') {
      history.back()
      return
    }
    if (action === 'reload') {
      location.reload()
      return
    }
  }

  // (2) Intercept route changes
  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => {
      RouterEvents.off('routeChangeStart', onRouteChangeStart)
    }
  }, [dirty, RouterEvents])

  // if startDate is today, make startTime min = now, and bump startTime if it's earlier
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      // if currently selected startTime is earlier than now, bump to now
      if (startTime && Number.isFinite(timeToMinutes(startTime)) && timeToMinutes(startTime) < timeToMinutes(now)) {
        setStartTime(now)
      }
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'

    // if same day end, end must be strictly after startTime -> set min to startTime + 1 minute
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        const minMinutes = s + 1 // require end > start
        min = minutesToTime(minMinutes)
      }
    } else if (hasEnd && endDate === todayISO()) {
      // if end is today (but not same as start), disallow past times — min = now
      min = nowTimeRounded()
    }

    setEndTimeMin(min)

    // if current endTime is now less than min, clear it so user re-selects
    if (endTime && Number.isFinite(timeToMinutes(endTime)) && Number.isFinite(timeToMinutes(min)) && timeToMinutes(endTime) < timeToMinutes(min)) {
      setEndTime('')
    }
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // (3) Intercept anchor clicks
  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  // (4) Intercept browser back/forward
  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  // (5) Intercept keyboard reload
  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const isReloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!isReloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setShowPrompt(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  // (6) Hard refresh/tab close
  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  // ----- Fetch targets for the discount when discountId changes -----
  useEffect(() => {
    let mounted = true
    const fetchTargets = async (discountId) => {
      if (!discountId) return
      try {
        // trigger the mutation which calls POST /discount-module/discount-targets
        const data = await getDiscountTargets({ discount_id: discountId }).unwrap()
        if (!mounted) return
        // data shape expected:
        // { discount_id, products: [...], collections: [...], categories: [...], brands: [...] }
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // keep silent in UI; you can log if desired
        // console.error('Failed to fetch discount targets', err)
      }
    }

    if (numericId) fetchTargets(numericId)
    return () => {
      mounted = false
    }
  }, [numericId, getDiscountTargets])

  // -------------------- Helpers --------------------
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  const validate = () => {
    const e = {}
    if (!title.trim()) e.title = 'Title is required.'
    if (title.length > 100) e.title = 'Title must be 100 characters or fewer.'
    if (!buyQty || Number(buyQty) < 1) e.buyQty = 'Buy quantity is required.'
    if (!getQty || Number(getQty) < 1) e.getQty = 'Get quantity is required.'
    if (limitMaxGet && (!maxGetPerOrder || Number(maxGetPerOrder) < 1)) e.maxGet = 'Maximum limit is required.'
    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Usage per account is required.'
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < todayISO()) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // when same day, ensure endTime > startTime, and ensure startTime not in past if startDate is today
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        // if startDate is today, ensure startTime is not in the past
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        // if end date is today (but not same as start), ensure endTime not before now
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  const combineDateTimeToISO = (d, t) => {
    if (!d || !t) return null
    return new Date(`${d}T${t}:00`).toISOString()
  }

  const toIntArray = (arr) => (Array.isArray(arr) ? arr : []).map(Number).filter(Number.isFinite)

  const isoToLocalDateTimeParts = (iso) => {
    if (!iso) return { date: '', time: '' }
    try {
      const d = new Date(iso)
      const pad = (n) => String(n).padStart(2, '0')
      return {
        date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
        time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      }
    } catch {
      return { date: '', time: '' }
    }
  }

  // ---------- Diff helpers (send only changed fields) ----------
  const normalize = (v) =>
    Array.isArray(v)
      ? v
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => a - b)
      : v
  const isEqual = (a, b) => JSON.stringify(normalize(a)) === JSON.stringify(normalize(b))

  const buildCurrentSnapshot = () => {
    // targets: prefer target props (authoritative), otherwise use fetched targets' ids
    const tp = toIntArray(targetProducts && targetProducts.length ? targetProducts : (fetchedProducts || []).map((p) => p.id))
    const tc = toIntArray(targetCollections && targetCollections.length ? targetCollections : (fetchedCollections || []).map((c) => c.id))
    const tcat = toIntArray(targetCategories && targetCategories.length ? targetCategories : (fetchedCategories || []).map((c) => c.id))
    const tb = toIntArray(targetBrands && targetBrands.length ? targetBrands : (fetchedBrands || []).map((b) => b.id))

    return {
      main_discount_type: 'product',
      prod_discount_method: 'buyxgety',
      discount_title: title.trim(),

      // targets
      target_products: tp,
      target_collections: tc,
      target_categories: tcat,
      target_brands: tb,

      // eligibility
      customer_eligibility: eligibility,
      is_guest_allowed: !!guestIncluded,

      // usage limits (NO total-usage)
      unlimited_usage: !!limitPerUserOnce,
      usage_limit_per_account: limitPerAccount ? Number(perAccountUses) : null,

      // dates
      start_date: combineDateTimeToISO(startDate, startTime),
      end_date: hasEnd ? combineDateTimeToISO(endDate, endTime) : null,

      // BXGY specifics
      discount_code: null,
      customer_buys_qty: buyQty === '' ? null : Number(buyQty),
      customer_gets_qty: getQty === '' ? null : Number(getQty),
      bxgy_max_limit: limitMaxGet ? Number(maxGetPerOrder) : null,

      // order scope not used
      order_discount_method: null,
      payment_method: null,
    }
  }

  const diffAgainst = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      const cur = current[k]
      const orig = original[k]
      if (!isEqual(cur, orig)) changes[k] = cur
    })

    // ensure explicit clears
    if (!isEqual(original.end_date ?? null, current.end_date ?? null) && current.end_date === null) {
      changes.end_date = null
    }
    if (!isEqual(original.bxgy_max_limit ?? null, current.bxgy_max_limit ?? null) && current.bxgy_max_limit === null) {
      changes.bxgy_max_limit = null
    }
    if (!isEqual(original.usage_limit_per_account ?? null, current.usage_limit_per_account ?? null) && current.usage_limit_per_account === null) {
      changes.usage_limit_per_account = null
    }

    return changes
  }
  // -------------------------------------------------------------

  // -------------------- Prefill resolution --------------------
  const activePrefill = useMemo(() => {
    if (fetched?.data && typeof fetched.data === 'object') return fetched.data
    if (fetched && typeof fetched === 'object') return fetched
    if (prefill && typeof prefill === 'object') return prefill
    return null
  }, [fetched, prefill])

  const hydrateFrom = (p) => {
    if (!p) return

    lastPrefillRef.current = p

    // Title
    setTitle(p.discount_title ?? '')

    // Quantities (blank if not present)
    setBuyQty(p.customer_buys_qty != null ? String(p.customer_buys_qty) : '')
    setGetQty(p.customer_gets_qty != null ? String(p.customer_gets_qty) : '')

    // Optional per-order max limit
    if (p.bxgy_max_limit != null) {
      setLimitMaxGet(true)
      setMaxGetPerOrder(String(p.bxgy_max_limit))
    } else {
      setLimitMaxGet(false)
      setMaxGetPerOrder('')
    }

    // Eligibility + guest
    setEligibility(p.customer_eligibility || 'all')
    setGuestIncluded(!!p.is_guest_allowed)

    // One-time per user
    setLimitPerUserOnce(!!p.unlimited_usage)

    // Per-account usage
    if (p.usage_limit_per_account != null) {
      setLimitPerAccount(true)
      setPerAccountUses(String(p.usage_limit_per_account))
    } else {
      setLimitPerAccount(false)
      setPerAccountUses('')
    }

    // Dates
    const { date: sd, time: st } = isoToLocalDateTimeParts(p.start_date)
    setStartDate(sd)
    setStartTime(st)

    if (p.end_date) {
      const { date: ed, time: et } = isoToLocalDateTimeParts(p.end_date)
      setHasEnd(true)
      setEndDate(ed)
      setEndTime(et)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // clear previously fetched targets when hydrating from new prefill (we'll refetch)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])

    setDirty(false)
  }

  // Hydrate when data arrives
  useEffect(() => {
    if (activePrefill) hydrateFrom(activePrefill)
  }, [activePrefill])

  // ---------- ORIGINAL snapshot derived from activePrefill (used to compute hasChanges) ----------
  const originalSnapshot = useMemo(() => {
    // build target arrays: prefer prefill's arrays, else fallback to fetched target ids, else fallback to incoming props
    const origTP =
      toIntArray(activePrefill?.target_products) ||
      (fetchedProducts.length ? fetchedProducts.map((p) => Number(p.id)).filter(Number.isFinite) : toIntArray(targetProducts))
    const origTC =
      toIntArray(activePrefill?.target_collections) ||
      (fetchedCollections.length ? fetchedCollections.map((c) => Number(c.id)).filter(Number.isFinite) : toIntArray(targetCollections))
    const origTCat =
      toIntArray(activePrefill?.target_categories) ||
      (fetchedCategories.length ? fetchedCategories.map((c) => Number(c.id)).filter(Number.isFinite) : toIntArray(targetCategories))
    const origTB =
      toIntArray(activePrefill?.target_brands) ||
      (fetchedBrands.length ? fetchedBrands.map((b) => Number(b.id)).filter(Number.isFinite) : toIntArray(targetBrands))

    const orig = {
      main_discount_type: activePrefill?.main_discount_type ?? 'product',
      prod_discount_method: activePrefill?.prod_discount_method ?? 'buyxgety',
      discount_title: activePrefill?.discount_title ?? '',

      target_products: origTP,
      target_collections: origTC,
      target_categories: origTCat,
      target_brands: origTB,

      customer_eligibility: activePrefill?.customer_eligibility ?? 'all',
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill?.usage_limit_per_account) : null,

      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      discount_code: null,
      customer_buys_qty: activePrefill?.customer_buys_qty != null ? Number(activePrefill.customer_buys_qty) : null,
      customer_gets_qty: activePrefill?.customer_gets_qty != null ? Number(activePrefill.customer_gets_qty) : null,
      bxgy_max_limit: activePrefill?.bxgy_max_limit != null ? Number(activePrefill.bxgy_max_limit) : null,

      order_discount_method: null,
      payment_method: null,
    }
    return orig
  }, [
    activePrefill,
    fetchedProducts,
    fetchedCollections,
    fetchedCategories,
    fetchedBrands,
    targetProducts,
    targetCollections,
    targetCategories,
    targetBrands,
  ])

  // ---------- CURRENT snapshot derived from current state/props ----------
  const currentSnapshot = useMemo(
    () => buildCurrentSnapshot(),
    [
      title,
      buyQty,
      getQty,
      limitMaxGet,
      maxGetPerOrder,
      eligibility,
      guestIncluded,
      limitPerUserOnce,
      limitPerAccount,
      perAccountUses,
      startDate,
      startTime,
      hasEnd,
      endDate,
      endTime,
      // targets / fetched
      targetProducts,
      targetCollections,
      targetCategories,
      targetBrands,
      fetchedProducts,
      fetchedCollections,
      fetchedCategories,
      fetchedBrands,
    ],
  )

  // ---------- Whether there are changes compared to original ----------
  const hasChanges = useMemo(() => {
    const changes = diffAgainst(originalSnapshot, currentSnapshot)
    return Object.keys(changes).length > 0
  }, [originalSnapshot, currentSnapshot])

  // Keep navigation guard in sync with real change status.
  useEffect(() => {
    setDirty(hasChanges)
    if (hasChanges) onDirty?.()
    // note: we intentionally don't call onDirty when hasChanges becomes false
  }, [hasChanges, onDirty])

  // -------------------- Actions --------------------
  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes ?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  const onSave = async () => {
    if (!validate()) {
      await Swal.fire({
        title: 'Fix form errors',
        text: 'Please review highlighted fields.',
        icon: 'warning',
        confirmButtonColor: '#111827',
      })
      return
    }

    if (!Number.isFinite(numericId) || numericId <= 0) {
      await Swal.fire({
        title: 'Missing ID',
        text: 'Cannot update: discount_id not provided.',
        icon: 'error',
        confirmButtonColor: '#111827',
      })
      return
    }

    // short-circuit if no changes
    if (!hasChanges) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
      return
    }

    const current = buildCurrentSnapshot()
    const original = {
      main_discount_type: activePrefill?.main_discount_type ?? 'product',
      prod_discount_method: activePrefill?.prod_discount_method ?? 'buyxgety',
      discount_title: activePrefill?.discount_title ?? '',

      target_products: toIntArray(activePrefill?.target_products),
      target_collections: toIntArray(activePrefill?.target_collections),
      target_categories: toIntArray(activePrefill?.target_categories),
      target_brands: toIntArray(activePrefill?.target_brands),

      customer_eligibility: activePrefill?.customer_eligibility ?? 'all',
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill?.usage_limit_per_account) : null,

      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      discount_code: null, // not used
      customer_buys_qty: activePrefill?.customer_buys_qty != null ? Number(activePrefill.customer_buys_qty) : null,
      customer_gets_qty: activePrefill?.customer_gets_qty != null ? Number(activePrefill.customer_gets_qty) : null,
      bxgy_max_limit: activePrefill?.bxgy_max_limit != null ? Number(activePrefill.bxgy_max_limit) : null,

      order_discount_method: null,
      payment_method: null,
    }

    const changes = diffAgainst(original, current)
    if (Object.keys(changes).length === 0) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
      return
    }

    Swal.fire({
      title: 'Saving…',
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })
    try {
      await updateProductSelective({ id: numericId, changes }).unwrap()
      Swal.close()
      setDirty(false)

      // success alert (wait for user confirmation)
      await Swal.fire({
        title: 'Updated',
        text: 'Discount updated successfully.',
        icon: 'success',
        confirmButtonColor: '#111827',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // 🔥 notify global listeners that a discount was updated
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      Swal.close()
      await Swal.fire({
        title: 'Update failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
        icon: 'error',
        confirmButtonColor: '#111827',
      })
      setErrors((prev) => ({ ...prev, submit: err?.data?.error || err?.message || 'Update failed' }))
    }
  }

  // ----- Summaries -----
  const qtySummary = useMemo(() => {
    return `${buyQty || '—'} buy → ${getQty || '—'} get`
  }, [buyQty, getQty])

  const maxGetSummary = useMemo(() => {
    return limitMaxGet ? `Max ${maxGetPerOrder || '—'} per order` : 'No max'
  }, [limitMaxGet, maxGetPerOrder])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerUserOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerUserOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // ----- Helper to render pills for items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items)) return placeholder
    if (items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }



  // ---------- NEW: expanded state per target type ----------
  const [productsExpanded, setProductsExpanded] = useState(false)
  const [collectionsExpanded, setCollectionsExpanded] = useState(false)
  const [categoriesExpanded, setCategoriesExpanded] = useState(false)
  const [brandsExpanded, setBrandsExpanded] = useState(false)

  // ----- NEW: Render targets inside a fixed-size scrollable box; if >3 items show bullets, else pills.
  //          Adds expand/collapse chevron when items > 3 using Icon (Iconify).
  //          For 'products' we apply a fixed width + height; other types remain full-width.
  const renderTargetsBox = (items, idKey = 'id', labelKey = 'name', placeholder = '—', type = 'products') => {
    const expanded =
      type === 'products'
        ? productsExpanded
        : type === 'collections'
          ? collectionsExpanded
          : type === 'categories'
            ? categoriesExpanded
            : brandsExpanded

    const setExpanded =
      type === 'products'
        ? setProductsExpanded
        : type === 'collections'
          ? setCollectionsExpanded
          : type === 'categories'
            ? setCategoriesExpanded
            : setBrandsExpanded

    if (!Array.isArray(items) || items.length === 0) {
      return <div className="targets-box targets-box-empty">—</div>
    }

    const many = items.length > 3

    return (
      <div className="targets-wrapper">
        <div
          className={`targets-box fixed ${expanded ? 'expanded' : 'collapsed'} ${type === 'products' ? 'products' : ''}`}
          role="region"
          aria-label={type + '-targets'}
          title={Array.isArray(items) ? `${items.length} items` : undefined}>
          {many ? (
            expanded ? (
              <ul className="targets-list">
                {items.map((it) => (
                  <li key={String(it[idKey]) + '-' + (it[labelKey] ?? '')}>{it[labelKey] ?? '—'}</li>
                ))}
              </ul>
            ) : (
              // collapsed but many -> show first 3 as list so user sees example rows, full box remains scrollable
              <ul className="targets-list">
                {items.slice(0, 3).map((it) => (
                  <li key={String(it[idKey]) + '-' + (it[labelKey] ?? '')}>{it[labelKey] ?? '—'}</li>
                ))}
              </ul>
            )
          ) : (
            // <= 3 -> show pills (existing behavior)
            renderPills(items, idKey, labelKey, placeholder)
          )}
        </div>

        {many && (
          <button
            type="button"
            onClick={() => setExpanded((s) => !s)}
            aria-expanded={expanded}
            aria-label={expanded ? 'Collapse targets' : 'Expand targets'}
            title={expanded ? 'Collapse' : 'Expand'}
            style={{
              width: '32px',
              height: '32px',
              border: 'none',
              background: 'transparent',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              padding: 0,
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.2)')} // darker
            onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
            <Icon icon={expanded ? 'solar:alt-arrow-up-linear' : 'solar:alt-arrow-down-linear'} width={18} />
          </button>
        )}
      </div>
    )
  }

  // -------------------- Render (UI unchanged except targets boxes) --------------------
  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">Buy X Get Y Offer</Card.Title>
          <small className="text-muted">Reward customers when they buy certain items/quantities.</small>
        </div>
        <span />
      </Card.Header>

      <Card.Body>
        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {(loading || isFetching) && (
              <div className="d-flex align-items-center gap-2 mb-2">
                <Spinner animation="border" size="sm" />
                <small className="text-muted">Loading discount…</small>
              </div>
            )}
            {fetchError && <div className="text-danger small mb-2">Failed to load discount details.</div>}

            {/* Title */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Title</span>
              </div>
              <div className="section-body">
                <Form.Control
                  placeholder="e.g. Buy 2 Tees, Get 1 Free"
                  value={title}
                  maxLength={100}
                  required
                  onChange={(e) => {
                    setTitle(e.target.value)
                    markDirty()
                  }}
                />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">{title.length}/100</small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Quantities */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Buys and Customer Gets</span>
              </div>

              <div className="section-body">
                <Row className="g-3 align-items-center">
                  <Col md={6}>
                    <InputGroup className="equal-input">
                      <InputGroup.Text className="fw-semibold nowrap">Buy Quantity</InputGroup.Text>
                      <Form.Control
                        type="number"
                        min="1"
                        step="1"
                        required
                        value={buyQty}
                        onChange={(e) => {
                          setBuyQty(e.target.value)
                          markDirty()
                        }}
                      />
                    </InputGroup>
                    {errors.buyQty && <div className="text-danger small mt-1 nowrap">{errors.buyQty}</div>}
                  </Col>

                  <Col md={6}>
                    <InputGroup className="equal-input">
                      <InputGroup.Text className="fw-semibold nowrap">Get Quantity</InputGroup.Text>
                      <Form.Control
                        type="number"
                        min="1"
                        step="1"
                        required
                        value={getQty}
                        onChange={(e) => {
                          setGetQty(e.target.value)
                          markDirty()
                        }}
                      />
                    </InputGroup>
                    {errors.getQty && <div className="text-danger small mt-1 nowrap">{errors.getQty}</div>}
                  </Col>

                  {/* Optional per-order max limit */}
                  <Col md={12} className="mt-2">
                    <Form.Check
                      id="limit-max-get"
                      type="checkbox"
                      checked={limitMaxGet}
                      onChange={(e) => {
                        setLimitMaxGet(e.target.checked)
                        markDirty()
                      }}
                      label={<span className="fw-semibold nowrap">Set Maximum Limit</span>}
                    />
                    {limitMaxGet && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={maxGetPerOrder}
                          onChange={(e) => {
                            setMaxGetPerOrder(e.target.value)
                            markDirty()
                          }}
                        />
                        {errors.maxGet && <div className="text-danger small mt-1 nowrap">{errors.maxGet}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        markDirty()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        markDirty()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        markDirty()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        markDirty()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Maximum Discount Uses (NO total-usage control) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Maximum Discount Uses</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-once-user"
                      checked={limitPerUserOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent deselecting if BOTH would become false
                        if (!checked && !limitPerAccount) return

                        setLimitPerUserOnce(checked)

                        if (checked) {
                          setLimitPerAccount(false)
                        }

                        markDirty()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent deselecting if BOTH would become false
                        if (!checked && !limitPerUserOnce) return

                        setLimitPerAccount(checked)

                        if (checked) {
                          setLimitPerUserOnce(false)
                        } else {
                          // your existing behavior
                          setPerAccountUses('')
                        }

                        markDirty()
                      }}
                      label="Set usage limit per account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(e.target.value)
                            markDirty()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Dates */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Dates</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        const newStartDate = e.target.value
                        setStartDate(newStartDate)
                        markDirty()

                        // if start date becomes today and current startTime is before allowed min, bump it
                        if (newStartDate === todayISO() && startTime && typeof timeToMinutes === 'function') {
                          const now = nowTimeRounded()
                          if (timeToMinutes(startTime) < timeToMinutes(now)) {
                            setStartTime(now)
                          }
                        }
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>

                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      min={startTimeMin} // ensures if startDate is today you can't pick earlier than now
                      onChange={(e) => {
                        const newStart = e.target.value
                        setStartTime(newStart)
                        markDirty()

                        // if end is same-day and endTime is not strictly after newStart, clear endTime so user re-selects
                        if (hasEnd && endDate && startDate && endDate === startDate && endTime && typeof timeToMinutes === 'function') {
                          if (timeToMinutes(endTime) <= timeToMinutes(newStart)) {
                            setEndTime('')
                          }
                        }
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                    {startTimeMin !== '00:00' && (
                      <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>
                    )}
                  </Col>

                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        const checked = e.target.checked
                        setHasEnd(checked)
                        markDirty()

                        // when enabling 'hasEnd' auto-fill endDate/endTime if possible:
                        if (checked) {
                          // default endDate to startDate if we have one, else today
                          const proposedEndDate = startDate || todayISO()
                          setEndDate(proposedEndDate)

                          // pick a friendly endTime: startTime + 1 hour (fallback to now+1h or '01:00')
                          let suggested = ''
                          if (startTime && Number.isFinite(timeToMinutes(startTime))) {
                            suggested = minutesToTime(timeToMinutes(startTime) + 60)
                          } else {
                            // if startTime missing, use now + 1h
                            suggested = minutesToTime(timeToMinutes(nowTimeRounded()) + 60)
                          }
                          // only set suggested if it's >= endTimeMin (endTimeMin effect will run after state changes)
                          setEndTime(suggested)
                        } else {
                          // disabling end: clear end fields
                          setEndDate('')
                          setEndTime('')
                        }
                      }}
                      label="Set End Date"
                    />
                  </Col>

                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            const newEnd = e.target.value
                            setEndDate(newEnd)
                            markDirty()

                            // if endDate becomes same as startDate, ensure endTime respects endTimeMin; clear if invalid
                            if (newEnd && startDate && newEnd === startDate && endTime && typeof timeToMinutes === 'function') {
                              if (timeToMinutes(endTime) < timeToMinutes(endTimeMin)) {
                                setEndTime('')
                              }
                            }
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>

                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          min={endTimeMin}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            markDirty()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                        {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                          <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                        )}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button variant="outline-secondary" onClick={onDiscard} disabled={saving}>
                Discard
              </Button>
              {/* Save button is now disabled unless there are actual changes compared to prefill */}
              <Button onClick={onSave} disabled={saving || !hasChanges}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>

            {errors.submit && <div className="text-danger mt-2 small">{errors.submit}</div>}
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>

              <div className="sum-row">
                <div className="sum-label">Category</div>
                <div className="sum-value">Buy X Get Y</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Quantities</div>
                <div className="sum-value">{qtySummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Max Limit</div>
                <div className="sum-value">{maxGetSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* ---------- NEW: Targets display (scrollable boxes) ---------- */}
              <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
                {targetsLoading && (
                  <span style={{ marginLeft: 8 }}>
                    <Spinner animation="border" size="sm" />
                  </span>
                )}
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">{renderTargetsBox(fetchedProducts, 'id', 'title', '—', 'products')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">{renderTargetsBox(fetchedCollections, 'id', 'name', '—', 'collections')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">{renderTargetsBox(fetchedCategories, 'id', 'name', '—', 'categories')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">{renderTargetsBox(fetchedBrands, 'id', 'name', '—', 'brands')}</div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Leave-without-saving Modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>

      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .equal-input :global(input.form-control) {
          height: 40px;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
          /* ensure internal overflow is clipped so child boxes don't overflow the card */
          box-sizing: border-box;
          overflow: hidden;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 150px 1fr;
          gap: 10px;
          padding: 8px 2px;
          align-items: center;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
          /* prevent contents from overflowing the summary column */
          min-width: 0;
        }

        /* pills */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .targets-head {
          font-size: 13px;
        }

        /* Targets wrapper + boxes (fixed-size scrollable) */
        .targets-wrapper {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          position: relative;
        }

        /* FIXED size box (collapsed) and larger fixed box when expanded.
           Both are scrollable if contents exceed the height. */
        .targets-box.fixed {
          width: 100%;
          height: 140px; /* fixed box height for non-product boxes */
          overflow-y: auto;
          padding: 6px;
          background: transparent;
          border-radius: 8px;
          box-sizing: border-box;
        }

        /* Product-specific fixed width/height */
        .targets-box.fixed.products {
          width: 220px; /* fixed width for product box */
          height: 140px; /* fixed height (collapsed) */
        }

        /* when expanded, use larger fixed height */
        .targets-box.fixed.expanded {
          height: 240px; /* expanded fixed height */
        }

        /* when expanded and product type, keep same width but larger height */
        .targets-box.fixed.products.expanded {
          width: 220px;
          height: 240px;
        }

        .targets-box.collapsed {
          /* visually same height as fixed (no extra effect) but kept for clarity */
        }

        .targets-box-empty {
          color: #6b7280;
          padding: 8px;
          border-radius: 8px;
          border: 1px dashed rgba(0, 0, 0, 0.04);
          background: #fafafa;
        }

        .targets-list {
          margin: 0;
          padding-left: 18px; /* show bullets */
        }
        .targets-list li {
          margin-bottom: 6px;
          line-height: 1.25;
          word-break: break-word;
        }

        /* toggle chevron button */
        .targets-toggle {
          border: none;
          background: transparent;
          padding: 4px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #6b7280;
        }
        .targets-toggle:focus {
          outline: none;
        }

        /* small responsive tweak so the toggle doesn't overlap */
        @media (max-width: 575px) {
          .sum-row {
            grid-template-columns: 120px 1fr;
          }
          /* allow product box to shrink on very small screens while keeping scroll */
          .targets-box.fixed.products {
            width: 160px;
          }
        }
      `}</style>
    </Card>
  )
}
