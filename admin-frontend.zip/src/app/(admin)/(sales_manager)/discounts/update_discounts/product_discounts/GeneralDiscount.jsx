'use client'

import { useMemo, useState, useEffect, useRef } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import Router from 'next/router'

// RTK Query: UPDATED to include the new hook
import { useUpdateProductDiscountSelectiveMutation, useGetDiscountTargetsMutation } from '@/store/features/apiSlice'

export default function GeneralDiscount({
  onDirty,
  prefill = null,
  targetProducts = [],
  targetBrands = [],
  targetCollections = [],
  targetCategories = [],
  onBack = () => {},
}) {
  // ----- Title -----
  const [title, setTitle] = useState('')
  const TITLE_MAX = 100

  // ----- Discount value -----
  const [valueType, setValueType] = useState('percentage') // 'percentage' | 'fixed'
  const [value, setValue] = useState(10)

  // ----- Min purchase / Max discount amount (always enabled) -----
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  // ----- Customer eligibility -----
  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  // ----- Usage limits (no total usage; mutually exclusive) -----
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false)
  const [limitPerAccount, setLimitPerAccount] = useState(true)
  const [perAccountUses, setPerAccountUses] = useState(2)

  // ----- Active period -----
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ----- Validation / Actions -----
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  // ----- RTKQ update mutation (ONLY) -----
  const [updateProductSelective] = useUpdateProductDiscountSelectiveMutation()

  // ----- RTKQ fetch targets mutation hook (trigger) -----
  // returns [trigger, result]
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult

  // store fetched target objects (these are used for display and also as fallback when comparison needs IDs)
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  // minimal time helpers/state
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  }
  const timeToMinutes = (t) => {
    if (!t) return NaN
    const [hh, mm] = String(t).split(':').map(Number)
    return Number.isFinite(hh) && Number.isFinite(mm) ? hh * 60 + mm : NaN
  }

  // currency from prefill (maps common codes -> symbols optionally)
  const currency = useMemo(() => {
    const c = prefill?.currency ?? ''
    if (!c) return '' // keep empty until API fills it
    // optional mapping: return symbol for known codes
    if (c === 'USD') return '$'
    if (c === 'EUR') return '€'
    if (c === 'GBP') return '£'
    // for local codes you may want to keep the code (e.g. "LKR")
    return c
  }, [prefill])

  // ===== Unsaved Changes (pleasant UI modal) =====
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    // call this from any onChange to show immediate guard behavior;
    // final truth of "dirty" will be synchronized with hasChanges below.
    onDirty?.()
  }

  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'router' | 'link' | 'history' | 'reload' | 'component-back'
  const allowNavRef = useRef(false)
  const RouterEvents = Router?.events

  const cancelNavigation = () => {
    setShowPrompt(false)
    pendingActionRef.current = null
    setPendingHref(null)
  }
  const proceedNavigation = () => {
    setShowPrompt(false)
    allowNavRef.current = true
    const action = pendingActionRef.current
    const href = pendingHref
    pendingActionRef.current = null
    setPendingHref(null)

    if (action === 'component-back') {
      setDirty(false)
      onBack()
      return
    }
    if (action === 'router' && href) {
      Router.push(href)
      return
    }
    if (action === 'link' && href) {
      window.location.href = href
      return
    }
    if (action === 'history') {
      history.back()
      return
    }
    if (action === 'reload') {
      location.reload()
      return
    }
  }

  // if startDate is today, make startTime min = now
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      if (startTime && timeToMinutes(startTime) < timeToMinutes(now)) setStartTime(now)
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      // set end min to startTime + 1 minute
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        const hh = Math.floor((s + 1) / 60) % 24
        const mm = (s + 1) % 60
        min = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
      }
    } else if (hasEnd && endDate === todayISO()) {
      min = nowTimeRounded()
    }
    setEndTimeMin(min)
    if (endTime && timeToMinutes(endTime) < timeToMinutes(min)) setEndTime('')
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // (2) Intercept route changes
  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => {
      RouterEvents.off('routeChangeStart', onRouteChangeStart)
    }
  }, [dirty, RouterEvents])

  // (3) Intercept anchor clicks
  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  // (4) Intercept browser back/forward
  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  // (5) Intercept keyboard reload
  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const isReloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!isReloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setShowPrompt(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  // (6) Hard refresh/tab close
  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  // ----- Helpers -----
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  const toISO = (d, t) => {
    if (!d || !t) return null
    try {
      return new Date(`${d}T${t}`).toISOString()
    } catch {
      return null
    }
  }
  const uniqNums = (arr) => [...new Set((arr || []).map(Number).filter(Number.isFinite))]

  const isoToLocalParts = (iso) => {
    if (!iso) return { date: '', time: '' }
    try {
      const d = new Date(iso)
      const pad = (n) => String(n).padStart(2, '0')
      return {
        date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
        time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      }
    } catch {
      return { date: '', time: '' }
    }
  }

  // Track latest prefill so Discard can restore
  const lastPrefillRef = useRef(null)
  const hydrateFrom = (p) => {
    if (!p) return
    lastPrefillRef.current = p

    // Title
    setTitle(p.discount_title || '')

    // Value type & value
    const vt = p.discount_value_type === 'fixed' ? 'fixed' : 'percentage'
    setValueType(vt)
    const v = Number(p.discount_value ?? 0)
    setValue(Number.isFinite(v) ? v : 0)

    // Amount fields (always enabled)
    setMinPurchase(p.min_purchase_amount != null ? String(Number(p.min_purchase_amount)) : '')
    setMaxDiscountAmount(vt === 'percentage' && p.max_discount_amount != null ? String(Number(p.max_discount_amount)) : '')

    // Eligibility
    setEligibility(p.customer_eligibility || 'all')
    setGuestIncluded(!!p.is_guest_allowed)

    // Usage limits (mutually exclusive)
    const once = !!p.unlimited_usage
    const perAcc = p.usage_limit_per_account != null
    setLimitPerCustomerOnce(once && !perAcc)
    setLimitPerAccount(perAcc && !once)
    setPerAccountUses(perAcc ? Number(p.usage_limit_per_account) || 1 : 2)

    // Dates
    const s = isoToLocalParts(p.start_date)
    setStartDate(s.date)
    setStartTime(s.time)

    if (p.end_date) {
      const e = isoToLocalParts(p.end_date)
      setHasEnd(true)
      setEndDate(e.date)
      setEndTime(e.time)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // clear previously fetched targets when hydrating from new prefill (we'll refetch)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])

    // mark clean baseline
    setDirty(false)
    setErrors({})
  }

  // ===== PREFILL MAPPING =====
  useEffect(() => {
    if (!prefill || typeof prefill !== 'object') return
    hydrateFrom(prefill)
  }, [prefill]) // eslint-disable-line react-hooks/exhaustive-deps
  // =================================

  // ----- Fetch targets for the discount when prefill.discount_id changes -----
  useEffect(() => {
    let mounted = true
    const fetchTargets = async (discountId) => {
      if (!discountId) return
      try {
        // trigger the mutation which calls POST /discount-module/discount-targets
        const data = await getDiscountTargets({ discount_id: discountId }).unwrap()
        if (!mounted) return
        // data shape expected:
        // { discount_id, products: [...], collections: [...], categories: [...], brands: [...] }
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // silent
      }
    }

    const id = prefill?.discount_id
    if (id) fetchTargets(id)
    return () => {
      mounted = false
    }
  }, [prefill?.discount_id, getDiscountTargets])

  // ----- Summaries -----
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    return `$${Number(value || 0).toFixed(2)}`
  }, [valueType, value])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const amountSummary = useMemo(() => {
    const prefix = currency ? `${currency}` : '$' // fallback if needed

    const minStr = minPurchase === '' ? '—' : `${prefix}${Number(minPurchase).toFixed(2)}`

    const maxStr = valueType === 'percentage' ? (maxDiscountAmount === '' ? '—' : `${prefix}${Number(maxDiscountAmount).toFixed(2)}`) : '—'

    return `Min: ${minStr} • Max Disc: ${maxStr}`
  }, [minPurchase, maxDiscountAmount, valueType, currency])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // ----- Validation -----
  const validate = () => {
    const e = {}
    const today = todayISO()

    if (!title.trim()) e.title = 'Discount title is required.'
    if (title.length > TITLE_MAX) e.title = `Title must be ${TITLE_MAX} characters or fewer.`

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) < 0) {
        e.maxDiscountAmount = 'Maximum discount must be 0 or more.'
      }
    } else {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    // amounts are always enabled
   if (minPurchase !== '' && Number(minPurchase) < 0) {
  e.minPurchase = 'Minimum purchase must be 0 or more.'
}

    if (valueType === 'percentage' && maxDiscountAmount !== '' && Number(maxDiscountAmount) < 0) {
      e.maxDiscountAmount = 'Maximum discount must be 0 or more.'
    }

    // USAGE LIMIT REQUIRED (one of the two must be selected)
    if (!limitPerCustomerOnce && !limitPerAccount) {
      e.usage = 'Select a usage limit.'
    }
    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Usage per account is required.'

    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // if same day, ensure endTime > startTime
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        // if startDate is today, ensure startTime is not in the past
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        // if end date is today (but not same as start), ensure endTime not before now
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ---------- Diff helpers (send only changed fields) ----------
  const normalize = (v) =>
    Array.isArray(v)
      ? v
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => a - b)
      : v
  const isEqual = (a, b) => {
    const x = normalize(a),
      y = normalize(b)
    return JSON.stringify(x) === JSON.stringify(y)
  }

  const buildCurrentSnapshot = () => {
    // targets: prefer target props (these are the authoritative arrays passed in),
    // fallback to fetched arrays' ids if props are empty.
    const tp = uniqNums(targetProducts && targetProducts.length ? targetProducts : (fetchedProducts || []).map((p) => p.id))
    const tb = uniqNums(targetBrands && targetBrands.length ? targetBrands : (fetchedBrands || []).map((b) => b.id))
    const tc = uniqNums(targetCollections && targetCollections.length ? targetCollections : (fetchedCollections || []).map((c) => c.id))
    const tcat = uniqNums(targetCategories && targetCategories.length ? targetCategories : (fetchedCategories || []).map((c) => c.id))

    return {
      // scope/method/title/value
      main_discount_type: 'product',
      prod_discount_method: 'general',
      discount_title: title.trim(),
      discount_value_type: valueType,
      discount_value: Number(value),

      // purchase limits (ALWAYS enabled)
      min_max_purchase_discount_limits: true,
    min_purchase_amount:
  minPurchase === '' ? null : Number(minPurchase),

      max_discount_amount: valueType === 'percentage' ? (maxDiscountAmount === '' ? null : Number(maxDiscountAmount)) : null,

      // eligibility
      customer_eligibility: eligibility,
      is_guest_allowed: Boolean(guestIncluded),

      // usage limits (no total usage)
      unlimited_usage: Boolean(limitPerCustomerOnce),
      usage_limit_per_account: limitPerAccount ? Number(perAccountUses || 0) : null,

      // period
      start_date: toISO(startDate, startTime),
      end_date: hasEnd ? toISO(endDate, endTime) : null,

      // targets
      target_products: tp,
      target_brands: tb,
      target_collections: tc,
      target_categories: tcat,
    }
  }

  const diffAgainst = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      const cur = current[k]
      const orig = original[k]
      if (!isEqual(cur, orig)) {
        changes[k] = cur
      }
    })

    // Explicit nulls to clear
    const origPerAcc = original.usage_limit_per_account ?? null
    const curPerAcc = current.usage_limit_per_account ?? null
    if (!isEqual(origPerAcc, curPerAcc) && curPerAcc === null) {
      changes.usage_limit_per_account = null
    }

    const origEnd = original.end_date ?? null
    const curEnd = current.end_date ?? null
    if (!isEqual(origEnd, curEnd) && curEnd === null) {
      changes.end_date = null
    }

    const origMaxDisc = original.max_discount_amount ?? null
    const curMaxDisc = current.max_discount_amount ?? null
    if (!isEqual(origMaxDisc, curMaxDisc) && curMaxDisc === null) {
      changes.max_discount_amount = null
    }

    return changes
  }
  // -------------------------------------------------------------

  // ---------- ORIGINAL snapshot derived from prefill (used to compute hasChanges) ----------
  const originalSnapshot = useMemo(() => {
    // Mirror the same original building logic used in onSave
    // Use prefill values where available. For targets, if prefill doesn't have them,
    // fall back to fetched arrays (which were loaded for that prefill).
    const origTargetProducts =
      uniqNums(prefill?.target_products) ||
      uniqNums((fetchedProducts || []).map((p) => Number(p.id)).filter(Number.isFinite)) ||
      uniqNums(targetProducts)
    const origTargetBrands =
      uniqNums(prefill?.target_brands) || uniqNums((fetchedBrands || []).map((b) => Number(b.id)).filter(Number.isFinite)) || uniqNums(targetBrands)
    const origTargetCollections =
      uniqNums(prefill?.target_collections) ||
      uniqNums((fetchedCollections || []).map((c) => Number(c.id)).filter(Number.isFinite)) ||
      uniqNums(targetCollections)
    const origTargetCategories =
      uniqNums(prefill?.target_categories) ||
      uniqNums((fetchedCategories || []).map((c) => Number(c.id)).filter(Number.isFinite)) ||
      uniqNums(targetCategories)

    const orig = {
      main_discount_type: prefill?.main_discount_type ?? 'product',
      prod_discount_method: prefill?.prod_discount_method ?? 'general',
      discount_title: prefill?.discount_title ?? '',
      discount_value_type: prefill?.discount_value_type ?? 'percentage',
      discount_value: prefill?.discount_value != null ? Number(prefill.discount_value) : 0,

      // Treat amounts as always-on in new UI; we still diff with what was loaded
      min_max_purchase_discount_limits: !!prefill?.min_max_purchase_discount_limits,
      min_purchase_amount: prefill?.min_purchase_amount != null ? Number(prefill.min_purchase_amount) : null,
      max_discount_amount: prefill?.max_discount_amount != null ? Number(prefill.max_discount_amount) : null,

      customer_eligibility: prefill?.customer_eligibility ?? 'all',
      is_guest_allowed: !!prefill?.is_guest_allowed,

      unlimited_usage: !!prefill?.unlimited_usage,
      usage_limit_per_account: prefill?.usage_limit_per_account != null ? Number(prefill.usage_limit_per_account) : null,

      start_date: prefill?.start_date || null,
      end_date: prefill?.end_date || null,

      target_products: origTargetProducts,
      target_brands: origTargetBrands,
      target_collections: origTargetCollections,
      target_categories: origTargetCategories,
    }
    return orig
  }, [
    prefill,
    // also depend on fetched arrays so originalSnapshot will incorporate fetched target ids for comparison
    fetchedProducts,
    fetchedCollections,
    fetchedCategories,
    fetchedBrands,
    // and the props as last resort
    targetProducts,
    targetBrands,
    targetCollections,
    targetCategories,
  ])

  // ---------- CURRENT snapshot derived from current state/props ----------
  // buildCurrentSnapshot reads current state + props target arrays
  const currentSnapshot = useMemo(
    () => buildCurrentSnapshot(),
    [
      title,
      valueType,
      value,
      minPurchase,
      maxDiscountAmount,
      eligibility,
      guestIncluded,
      limitPerCustomerOnce,
      limitPerAccount,
      perAccountUses,
      startDate,
      startTime,
      hasEnd,
      endDate,
      endTime,
      // include target props + fetched targets since they affect snapshot
      targetProducts,
      targetBrands,
      targetCollections,
      targetCategories,
      fetchedProducts,
      fetchedCollections,
      fetchedCategories,
      fetchedBrands,
    ],
  )

  // ---------- Whether there are changes compared to original ----------
  const hasChanges = useMemo(() => {
    const changes = diffAgainst(originalSnapshot, currentSnapshot)
    return Object.keys(changes).length > 0
  }, [originalSnapshot, currentSnapshot])

  // Keep navigation guard in sync with real change status.
  useEffect(() => {
    setDirty(hasChanges)
    if (hasChanges) onDirty?.()
    // note: we intentionally don't call onDirty when hasChanges becomes false
  }, [hasChanges, onDirty])

  // ----- Save handler (UPDATE only) -----
  const onSave = async () => {
    if (!validate()) return
    setSaving(true)

    const current = buildCurrentSnapshot()
    const id = Number(prefill?.discount_id)

    try {
      if (!Number.isFinite(id) || id <= 0) {
        setSaving(false)
        await Swal.fire({ icon: 'error', title: 'Missing ID', text: 'Cannot update: discount_id not provided.' })
        return
      }

      const original = {
        main_discount_type: prefill.main_discount_type ?? 'product',
        prod_discount_method: prefill.prod_discount_method ?? 'general',
        discount_title: prefill.discount_title ?? '',
        discount_value_type: prefill.discount_value_type ?? 'percentage',
        discount_value: prefill.discount_value != null ? Number(prefill.discount_value) : 0,

        // Treat amounts as always-on in new UI; we still diff with what was loaded
        min_max_purchase_discount_limits: !!prefill?.min_max_purchase_discount_limits,
        min_purchase_amount: prefill?.min_purchase_amount != null ? Number(prefill.min_purchase_amount) : null,
        max_discount_amount: prefill?.max_discount_amount != null ? Number(prefill.max_discount_amount) : null,

        customer_eligibility: prefill?.customer_eligibility ?? 'all',
        is_guest_allowed: !!prefill?.is_guest_allowed,

        unlimited_usage: !!prefill?.unlimited_usage,
        usage_limit_per_account: prefill?.usage_limit_per_account != null ? Number(prefill.usage_limit_per_account) : null,

        start_date: prefill?.start_date || null,
        end_date: prefill?.end_date || null,

        target_products: uniqNums(prefill.target_products),
        target_brands: uniqNums(prefill.target_brands),
        target_collections: uniqNums(prefill.target_collections),
        target_categories: uniqNums(prefill.target_categories),
      }

      const changes = diffAgainst(original, current)

      if (Object.keys(changes).length === 0) {
        setSaving(false)
        await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
        return
      }

      await updateProductSelective({ id, changes }).unwrap()
      setDirty(false)

      await Swal.fire({
        icon: 'success',
        title: 'Updated',
        text: 'Discount updated successfully.',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // 🔥 exactly same behavior as your addProductDiscount flow
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      const msg = err?.data?.error || err?.error || 'Failed to update'
      await Swal.fire({ icon: 'error', title: 'Error', text: String(msg) })
    } finally {
      setSaving(false)
    }
  }

  // ----- Discard -> reset to prefilled values (SweetAlert) -----
  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  // ----- Back button (guarded to go back to previous component) -----
  const onBackRequested = () => {
    if (!dirty) {
      history.back()
      return
    }
    pendingActionRef.current = 'history'
    setShowPrompt(true)
  }

  // ----- Helper to render pills for items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items)) return placeholder
    if (items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }

  // ---------- NEW: expanded state per target type ----------
  const [productsExpanded, setProductsExpanded] = useState(false)
  const [collectionsExpanded, setCollectionsExpanded] = useState(false)
  const [categoriesExpanded, setCategoriesExpanded] = useState(false)
  const [brandsExpanded, setBrandsExpanded] = useState(false)

  // ----- NEW: Render targets inside a fixed-size scrollable box; if >3 items show bullets, else pills.
  const renderTargetsBox = (items, idKey = 'id', labelKey = 'name', placeholder = '—', type = 'products') => {
    const expanded =
      type === 'products'
        ? productsExpanded
        : type === 'collections'
          ? collectionsExpanded
          : type === 'categories'
            ? categoriesExpanded
            : brandsExpanded

    const setExpanded =
      type === 'products'
        ? setProductsExpanded
        : type === 'collections'
          ? setCollectionsExpanded
          : type === 'categories'
            ? setCategoriesExpanded
            : setBrandsExpanded

    if (!Array.isArray(items) || items.length === 0) {
      return <div className="targets-box targets-box-empty">—</div>
    }

    const many = items.length > 3

    return (
      <div className="targets-wrapper">
        <div
          className={`targets-box fixed ${expanded ? 'expanded' : 'collapsed'} ${type === 'products' ? 'products' : ''}`}
          role="region"
          aria-label={type + '-targets'}
          title={Array.isArray(items) ? `${items.length} items` : undefined}>
          {many ? (
            expanded ? (
              <ul className="targets-list">
                {items.map((it) => (
                  <li key={String(it[idKey]) + '-' + (it[labelKey] ?? '')}>{it[labelKey] ?? '—'}</li>
                ))}
              </ul>
            ) : (
              // collapsed but many -> show first 3 as list so user sees example rows, full box remains scrollable
              <ul className="targets-list">
                {items.slice(0, 3).map((it) => (
                  <li key={String(it[idKey]) + '-' + (it[labelKey] ?? '')}>{it[labelKey] ?? '—'}</li>
                ))}
              </ul>
            )
          ) : (
            // <= 3 -> show pills (existing behavior)
            renderPills(items, idKey, labelKey, placeholder)
          )}
        </div>

        {many && (
          <button
            type="button"
            onClick={() => setExpanded((s) => !s)}
            aria-expanded={expanded}
            aria-label={expanded ? 'Collapse targets' : 'Expand targets'}
            title={expanded ? 'Collapse' : 'Expand'}
            style={{
              width: '32px',
              height: '32px',
              border: 'none',
              background: 'transparent',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              padding: 0,
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.2)')} // darker
            onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
            <Icon icon={expanded ? 'solar:alt-arrow-up-linear' : 'solar:alt-arrow-down-linear'} width={18} />
          </button>
        )}
      </div>
    )
  }

  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">Products General Discount</Card.Title>
          <small className="text-muted">Create a sitewide or targeted automatic discount.</small>
        </div>
      </Card.Header>

      <Card.Body>
        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Title */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Title</span>
              </div>
              <div className="section-body">
                <Form.Control
                  placeholder="e.g. Summer Storewide 10% Off"
                  value={title}
                  maxLength={TITLE_MAX}
                  required
                  onChange={(e) => {
                    setTitle(e.target.value)
                    markDirty()
                  }}
                />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">
                    {title.length}/{TITLE_MAX}
                  </small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="1"
                            max="100"
                            step="1"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                          />
                        </>
                      ) : (
                        <>
                          {/* currency prefix from API prefill */}
                          <InputGroup.Text className="fw-semibold nowrap">{currency || '$'}</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                          />
                        </>
                      )}
                    </InputGroup>
                    {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Options (checkbox removed; always enabled) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase and Maximum Discount Amount</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={valueType === 'percentage' ? 6 : 7}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap">Min Purchase Amount {currency ? `(${currency})` : ''}</InputGroup.Text>

                   <Form.Control
  type="number"
  min="0"
  step="0.01"
  value={minPurchase}
  onChange={(e) => {
    setMinPurchase(e.target.value)
    markDirty()
  }}
  placeholder="Optional"
/>

                    </InputGroup>

                    {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                  </Col>

                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap">Max Discount Amount {currency ? `(${currency})` : ''}</InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0"
                          step="0.01"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            setMaxDiscountAmount(e.target.value)
                            markDirty()
                          }}
                          placeholder="Optional"
                        />
                      </InputGroup>

                      {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        markDirty()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        markDirty()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        markDirty()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        markDirty()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Usage Limit (mutually exclusive, required) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Usage Limit</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent making both false (don't allow deselecting the only checked one)
                        if (!checked && !limitPerAccount) return

                        setLimitPerCustomerOnce(checked)

                        // If this becomes checked, turn off the other option and keep prefill
                        if (checked) {
                          setLimitPerAccount(false)
                          setPerAccountUses(2)
                        }

                        markDirty()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent making both false (don't allow deselecting the only checked one)
                        if (!checked && !limitPerCustomerOnce) return

                        setLimitPerAccount(checked)

                        // If this becomes checked, turn off the other option
                        if (checked) {
                          setLimitPerCustomerOnce(false)
                        } else {
                          // preserve your prefill behavior when turning it off
                          setPerAccountUses(2)
                        }

                        markDirty()
                      }}
                      label="Set usage limit per account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(Number(e.target.value || 1))
                            markDirty()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>

                {errors.usage && <div className="text-danger small mt-2">{errors.usage}</div>}
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Period</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        const newStartDate = e.target.value
                        setStartDate(newStartDate)
                        markDirty()

                        // if start date becomes today and current startTime is before allowed min, bump it
                        if (newStartDate === todayISO() && startTime && typeof timeToMinutes === 'function' && typeof startTimeMin === 'string') {
                          if (timeToMinutes(startTime) < timeToMinutes(startTimeMin)) {
                            setStartTime(startTimeMin)
                          }
                        }
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>

                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      min={startTimeMin} // ensures if startDate is today you can't pick earlier than now
                      onChange={(e) => {
                        const newStart = e.target.value
                        setStartTime(newStart)
                        markDirty()

                        // if end is same-day and endTime is not strictly after newStart, clear endTime so user re-selects
                        if (hasEnd && endDate && startDate && endDate === startDate && endTime && typeof timeToMinutes === 'function') {
                          if (timeToMinutes(endTime) <= timeToMinutes(newStart)) {
                            setEndTime('')
                          }
                        }
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                    {startTimeMin !== '00:00' && (
                      <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>
                    )}
                  </Col>

                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        markDirty()
                      }}
                      label="Set End Date"
                    />
                  </Col>

                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            const newEnd = e.target.value
                            setEndDate(newEnd)
                            markDirty()

                            // if endDate becomes same as startDate, ensure endTime respects endTimeMin; clear if invalid
                            if (
                              newEnd &&
                              startDate &&
                              newEnd === startDate &&
                              endTime &&
                              typeof timeToMinutes === 'function' &&
                              typeof endTimeMin === 'string'
                            ) {
                              if (timeToMinutes(endTime) < timeToMinutes(endTimeMin)) {
                                setEndTime('')
                              }
                            }

                            // if endDate is today (and not same as startDate), ensure endTime not before now (handled by effect)
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>

                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          min={endTimeMin} // prevents selecting <= startTime when same-day (endTimeMin computed by effect)
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            markDirty()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                        {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                          <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                        )}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button variant="outline-secondary" onClick={onDiscard}>
                Discard
              </Button>
              {/* Save button disabled unless there are actual changes compared to prefill values */}
              <Button onClick={onSave} disabled={saving || !hasChanges}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>

              <div className="sum-row">
                <div className="sum-label">Category</div>
                <div className="sum-value">General Discount</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Amount Limits</div>
                <div className="sum-value">{amountSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* ---------- NEW: Targets display ---------- */}
              {/* ---------- Targets display (replacement: wraps long phrases) ---------- */}
              {/* ---------- Targets display ---------- */}
              <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
                {targetsLoading && (
                  <span style={{ marginLeft: 8 }}>
                    <Spinner animation="border" size="sm" />
                  </span>
                )}
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">
                  <div
                    style={{
                      display: 'block',
                      width: '100%',
                      overflowWrap: 'anywhere',
                    }}>
                    {renderTargetsBox(fetchedProducts, 'id', 'title', '—', 'products')}
                  </div>
                </div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">
                  <div
                    style={{
                      display: 'block',
                      width: '100%',
                      overflowWrap: 'anywhere',
                    }}>
                    {renderTargetsBox(fetchedCollections, 'id', 'name', '—', 'collections')}
                  </div>
                </div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">
                  <div
                    style={{
                      display: 'block',
                      width: '100%',
                      overflowWrap: 'anywhere',
                    }}>
                    {renderTargetsBox(fetchedCategories, 'id', 'name', '—', 'categories')}
                  </div>
                </div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">
                  <div
                    style={{
                      display: 'block',
                      width: '100%',
                      overflowWrap: 'anywhere',
                    }}>
                    {renderTargetsBox(fetchedBrands, 'id', 'name', '—', 'brands')}
                  </div>
                </div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Leave-without-saving Modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 150px 1fr;
          gap: 10px;
          padding: 8px 2px;
          align-items: center;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
        }

        /* pills (general, non-target version) */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        @media (max-width: 575px) {
          .sum-row {
            grid-template-columns: 120px 1fr;
          }
        }
      `}</style>
    </Card>
  )
}
