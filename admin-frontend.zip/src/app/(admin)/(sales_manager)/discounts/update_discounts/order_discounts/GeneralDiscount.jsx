'use client'

import { useMemo, useState, useEffect, useRef } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

// RTK Query (edit mode only)
import { useGetDiscountByIdQuery, useUpdateOrderDiscountSelectiveMutation, useGetDiscountTargetsMutation } from '@/store/features/apiSlice'

export default function GeneralDiscountEdit({
  discountId, // number | string — ID to load & update
  onDirty,
  prefill = null, // optional fallback object if you already have it
}) {
  // ===== Unsaved Changes Guard =====
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    setDirty(true)
    onDirty?.()
  }

  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'router' | 'link' | 'history'
  const allowNavRef = useRef(false)

  // Handle both pages router and app router
  let RouterEvents = null
  let nextRouter = null
  try {
    const pages = require('next/router')
    nextRouter = pages.useRouter?.()
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }

  // Intercept route changes
  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  // Intercept anchor clicks
  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  // Intercept browser back/forward
  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  const proceedNavigation = () => {
    const action = pendingActionRef.current
    const href = pendingHref
    setShowPrompt(false)
    setDirty(false)
    allowNavRef.current = true

    if (action === 'link' && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }
    if (action === 'router' && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }
    if (action === 'history') {
      history.back()
      return
    }
  }
  const cancelNavigation = () => {
    setShowPrompt(false)
    setPendingHref(null)
    pendingActionRef.current = null
    allowNavRef.current = false
  }

  // ===== Core form state (start BLANK; only fill from response) =====
  const [title, setTitle] = useState('') // no default text

  const [valueType, setValueType] = useState('') // '' | 'fixed' | 'percentage'
  const [value, setValue] = useState('') // '' until response/user

  const [setAmountLimits, setSetAmountLimits] = useState(false)
  const [minPurchase, setMinPurchase] = useState('') // '' until response/user
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('') // '' unless % + response/user

  const [eligibility, setEligibility] = useState('') // '' | 'all' | 'new' | 'existing'
  const [guestIncluded, setGuestIncluded] = useState(false)

  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('') // '' until response/user

  // Active period
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // Actions / validation
  const [errors, setErrors] = useState({})

  // ===== RTK Query (fetch + update) =====
  const numericId = Number(discountId)
  const {
    data: fetched,
    isLoading: loading,
    isFetching,
    error: fetchError,
  } = useGetDiscountByIdQuery(Number.isFinite(numericId) ? numericId : 0, { skip: !Number.isFinite(numericId) })

  const [updateOrderSelective, { isLoading: saving }] = useUpdateOrderDiscountSelectiveMutation()

  // ----- RTKQ fetch targets mutation hook (trigger) -----
  // returns [trigger, result]
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult

  // store fetched target objects
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  // Keep last loaded prefill to restore on Discard
  const lastPrefillRef = useRef(null)

  // ===== Helpers =====
  const isoToLocalParts = (iso) => {
    if (!iso) return { date: '', time: '' }
    try {
      const d = new Date(iso)
      const pad = (n) => String(n).padStart(2, '0')
      return {
        date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
        time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      }
    } catch {
      return { date: '', time: '' }
    }
  }
  const joinDateTime = (d, t) => {
    if (!d || !t) return null
    return `${d}T${t}:00`
  }
  const toNumOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v))

  // Build current snapshot for diff
  const buildCurrentSnapshot = () => ({
    main_discount_type: 'order',
    order_discount_method: 'general',
    discount_title: title.trim(),

    discount_value_type: valueType || null,
    discount_value: value === '' ? null : Number(value),

    min_max_purchase_discount_limits: !!setAmountLimits,
    min_purchase_amount: setAmountLimits ? toNumOrNull(minPurchase) : null,
    max_discount_amount: valueType === 'percentage' ? toNumOrNull(maxDiscountAmount) : null,

    customer_eligibility: eligibility || null,
    is_guest_allowed: !!guestIncluded,

    unlimited_usage: !!limitPerCustomerOnce,
    usage_limit_per_account: limitPerAccount ? toNumOrNull(perAccountUses) : null,

    start_date: joinDateTime(startDate, startTime),
    end_date: hasEnd ? joinDateTime(endDate, endTime) : null,

    discount_code: null,
    payment_method: null,
    status: 'active',
  })

  const normalize = (v) =>
    Array.isArray(v)
      ? v
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => a - b)
      : v
  const isEqual = (a, b) => JSON.stringify(normalize(a)) === JSON.stringify(normalize(b))

  const diffAgainst = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      const cur = current[k]
      const orig = original[k]
      if (!isEqual(cur, orig)) changes[k] = cur
    })

    // explicit clears for nullable fields
    if (!isEqual(original.end_date ?? null, current.end_date ?? null) && current.end_date === null) {
      changes.end_date = null
    }
    if (!isEqual(original.max_discount_amount ?? null, current.max_discount_amount ?? null) && current.max_discount_amount === null) {
      changes.max_discount_amount = null
    }
    if (!isEqual(original.usage_limit_per_account ?? null, current.usage_limit_per_account ?? null) && current.usage_limit_per_account === null) {
      changes.usage_limit_per_account = null
    }
    if (!isEqual(original.min_purchase_amount ?? null, current.min_purchase_amount ?? null) && current.min_purchase_amount === null) {
      changes.min_purchase_amount = null
    }

    return changes
  }

  // ===== Prefill resolution =====
  const activePrefill = useMemo(() => {
    if (fetched?.data && typeof fetched.data === 'object') return fetched.data
    if (fetched && typeof fetched === 'object') return fetched
    if (prefill && typeof prefill === 'object') return prefill
    return null
  }, [fetched, prefill])

  // currency derived from prefill/active response (maps some common codes -> symbols)
  const currency = useMemo(() => {
    const c = (activePrefill?.currency ?? '').toString().trim()
    if (!c) return '' // empty until API fills it

    // Map known currency codes to symbols; otherwise return the code itself
    if (c === 'USD' || c === '$') return '$'
    if (c === 'EUR' || c === '€') return '€'
    if (c === 'GBP' || c === '£') return '£'

    // For local codes (e.g. 'LKR') just show the code
    return c
  }, [activePrefill])

  const hydrateFrom = (p) => {
    if (!p) return
    lastPrefillRef.current = p

    setTitle(p.discount_title ?? '')

    const vt = p.discount_value_type === 'percentage' || p.discount_value_type === 'fixed' ? p.discount_value_type : ''
    setValueType(vt)
    setValue(p.discount_value != null ? String(Number(p.discount_value)) : '')

    const enable = !!p.min_max_purchase_discount_limits
    setSetAmountLimits(enable)
    setMinPurchase(enable && p.min_purchase_amount != null ? String(Number(p.min_purchase_amount)) : '')
    setMaxDiscountAmount(enable && vt === 'percentage' && p.max_discount_amount != null ? String(Number(p.max_discount_amount)) : '')

    setEligibility(p.customer_eligibility || '')
    setGuestIncluded(!!p.is_guest_allowed)

    const once = !!p.unlimited_usage
    const perAcc = p.usage_limit_per_account != null
    setLimitPerCustomerOnce(once && !perAcc)
    setLimitPerAccount(perAcc && !once)
    setPerAccountUses(perAcc ? String(Number(p.usage_limit_per_account)) : '')

    const s = isoToLocalParts(p.start_date)
    setStartDate(s.date)
    setStartTime(s.time)

    if (p.end_date) {
      const e = isoToLocalParts(p.end_date)
      setHasEnd(true)
      setEndDate(e.date)
      setEndTime(e.time)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // clear previously fetched targets when hydrating from new prefill (we'll refetch)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])

    setDirty(false)
  }

  useEffect(() => {
    if (activePrefill) hydrateFrom(activePrefill)
  }, [activePrefill])

  // ----- Fetch targets for the discount when discountId changes -----
  useEffect(() => {
    let mounted = true
    const fetchTargets = async (discountId) => {
      if (!discountId) return
      try {
        // trigger the mutation which calls POST /discount-module/discount-targets
        const data = await getDiscountTargets({ discount_id: discountId }).unwrap()
        if (!mounted) return
        // data shape expected:
        // { discount_id, products: [...], collections: [...], categories: [...], brands: [...] }
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // keep silent in UI; you can log if desired
        // console.error('Failed to fetch discount targets', err)
      }
    }

    if (numericId) fetchTargets(numericId)
    return () => {
      mounted = false
    }
  }, [numericId, getDiscountTargets])

  // Derived summaries
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    if (valueType === 'fixed') {
      return value === '' ? '—' : `${currency || '$'}${Number(value || 0).toFixed(2)}`
    }
    return '—'
  }, [valueType, value, currency])

  const eligibilitySummary = useMemo(() => {
    if (!eligibility) return '—'
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // Keep endDate >= startDate
  useEffect(() => {
    if (!startDate) return
    if (hasEnd && endDate && endDate < startDate) setEndDate(startDate)
  }, [startDate, hasEnd, endDate])

  // Validation
  const validate = () => {
    const e = {}
    const trimmed = (title || '').trim()
    if (!trimmed) e.title = 'Discount title is required.'
    if (trimmed.length > 100) e.title = 'Title must be 100 characters or fewer.'

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) <= 0) e.maxDiscountAmount = 'Maximum discount must be greater than 0.'
    } else if (valueType === 'fixed') {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (setAmountLimits) {
      if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase amount is required.'
    }

    if (limitPerCustomerOnce && limitPerAccount) {
      e.usage = 'Select either Unlimited Discount Usage OR per-account limit, not both.'
    }
    if (limitPerAccount && (perAccountUses === '' || Number(perAccountUses) < 1)) {
      e.perAccount = 'Usage per account is required.'
    }

    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // Mutual exclusion handlers
  const togglePerCustomerOnce = (checked) => {
    setLimitPerCustomerOnce(checked)
    markDirty()
    if (checked) {
      setLimitPerAccount(false)
      setPerAccountUses('')
    }
  }
  const togglePerAccount = (checked) => {
    if (limitPerCustomerOnce && checked) return
    setLimitPerAccount(checked)
    markDirty()
    if (!checked) setPerAccountUses('')
  }

  // Discard → restore to prefilled values

  // Discard -> reset to prefilled values (SweetAlert)
  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  // Save -> UPDATE (send only changed fields)
  const onSave = async () => {
    if (!validate()) return
    if (!Number.isFinite(numericId) || numericId <= 0) {
      await Swal.fire({ icon: 'error', title: 'Missing ID', text: 'Cannot update: discount_id not provided.' })
      return
    }

    const current = buildCurrentSnapshot()
    const original = {
      main_discount_type: activePrefill?.main_discount_type ?? 'order',
      order_discount_method: activePrefill?.order_discount_method ?? 'general',
      discount_title: activePrefill?.discount_title ?? '',

      discount_value_type: activePrefill?.discount_value_type ?? null,
      discount_value: activePrefill?.discount_value != null ? Number(activePrefill.discount_value) : null,

      min_max_purchase_discount_limits: !!activePrefill?.min_max_purchase_discount_limits,
      min_purchase_amount: activePrefill?.min_purchase_amount != null ? Number(activePrefill.min_purchase_amount) : null,
      max_discount_amount: activePrefill?.max_discount_amount != null ? Number(activePrefill.max_discount_amount) : null,

      customer_eligibility: activePrefill?.customer_eligibility ?? null,
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill.usage_limit_per_account) : null,

      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      discount_code: null,
      payment_method: null,
      status: activePrefill?.status ?? 'active',
    }

    const changes = diffAgainst(original, current)
    if (Object.keys(changes).length === 0) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
      return
    }

    Swal.fire({
      title: 'Saving…',
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      await useUpdateOrderDiscountSelectiveMutation.prototype // keep this line as-is
      await updateOrderSelective({ id: numericId, changes }).unwrap()
      Swal.close()
      setDirty(false)

      // success alert (user must click OK)
      await Swal.fire({
        title: 'Updated',
        text: 'Order discount updated successfully.',
        icon: 'success',
        confirmButtonColor: '#111827',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // 🔥 notify global listeners (same behavior as all other updated blocks)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      Swal.close()
      await Swal.fire({
        title: 'Update failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
        icon: 'error',
        confirmButtonColor: '#111827',
      })
    }
  }

  // ----- Helper to render pills for items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items)) return placeholder
    if (items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }

  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">General Discount (Order)</Card.Title>
          <small className="text-muted">Edit an order-level automatic discount.</small>
        </div>
        {/* <Button variant="outline-secondary" className="rounded-pill d-inline-flex align-items-center gap-2 nowrap" onClick={() => history.back()}>
          <Icon icon="solar:arrow-left-linear" width={18} />
          Go Back
        </Button> */}
      </Card.Header>

      <Card.Body>
        {(loading || isFetching) && (
          <div className="d-flex align-items-center gap-2 mb-2">
            <Spinner animation="border" size="sm" />
            <small className="text-muted">Loading discount…</small>
          </div>
        )}
        {fetchError && <div className="text-danger small mb-2">Failed to load discount details.</div>}

        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Discount Title */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Title</span>
              </div>
              <div className="section-body">
                <Form.Control
                  placeholder="e.g. New Customer Welcome 10%"
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value.slice(0, 100))
                    markDirty()
                  }}
                  required
                />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">{title.length}/100</small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="1"
                            max="100"
                            step="1"
                            value={value}
                            onChange={(e) => {
                              setValue(e.target.value)
                              markDirty()
                            }}
                            required
                          />
                        </>
                      ) : valueType === 'fixed' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">{currency || '$'}</InputGroup.Text>

                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={value}
                            onChange={(e) => {
                              setValue(e.target.value)
                              markDirty()
                            }}
                            required
                          />
                        </>
                      ) : (
                        <Form.Control disabled placeholder="Choose a discount type first" />
                      )}
                    </InputGroup>
                    {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    {errors.valueType && <div className="text-danger small mt-1 nowrap">{errors.valueType}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Limits */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase Amount</span>
              </div>
              <div className="section-body">
                <Form.Check
                  className="mb-3"
                  type="checkbox"
                  id="amount-limits"
                  checked={setAmountLimits}
                  onChange={(e) => {
                    setSetAmountLimits(e.target.checked)
                    markDirty()
                  }}
                  label="Set Minimum Purchase Amount"
                />
                <Row className="g-3 align-items-center">
                  <Col md={valueType === 'percentage' ? 6 : 7}>
                    <InputGroup>
                      <InputGroup.Text
                        className="fw-semibold nowrap"
                        style={{ fontSize: '12px', minWidth: '180px' }} // <-- smaller text + wider label
                      >
                        Minimum Purchase Amount {currency ? `(${currency})` : ''}
                      </InputGroup.Text>

                      <Form.Control
                        type="number"
                        min="0"
                        step="0.01"
                        value={minPurchase}
                        onChange={(e) => {
                          setMinPurchase(e.target.value)
                          markDirty()
                        }}
                        required={setAmountLimits}
                        disabled={!setAmountLimits}
                      />
                    </InputGroup>

                    {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                  </Col>

                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text
                          className="fw-semibold nowrap"
                          style={{ fontSize: '12px', minWidth: '180px' }} // <-- smaller text + wider label
                        >
                          Maximum Discount Amount {currency ? `(${currency})` : ''}
                        </InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0.01"
                          step="0.01"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            setMaxDiscountAmount(e.target.value)
                            markDirty()
                          }}
                          placeholder="Optional"
                          disabled={!setAmountLimits}
                        />
                      </InputGroup>

                      {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        markDirty()
                      }}
                      label="All Customers"
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        markDirty()
                      }}
                      label="New Customers"
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        markDirty()
                      }}
                      label="Existing Customers"
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        markDirty()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>
            {/* Usage Limit (instant switch; never both unchecked; no error msg) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Usage Limit</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  {/* LEFT OPTION */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        if (checked) {
                          // User selects this → instantly switch to this option
                          setLimitPerCustomerOnce(true)
                          setLimitPerAccount(false)
                        } else {
                          // User tries to uncheck this while it's the only active option → switch to the other option
                          if (!limitPerAccount) {
                            setLimitPerCustomerOnce(false)
                            setLimitPerAccount(true)
                          } else {
                            // Safe to uncheck because right is true
                            setLimitPerCustomerOnce(false)
                          }
                        }

                        markDirty?.()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  {/* RIGHT OPTION */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        if (checked) {
                          // User selects this → instantly switch to this option
                          setLimitPerAccount(true)
                          setLimitPerCustomerOnce(false)
                        } else {
                          // User tries to uncheck while it's the only active option → switch to the other
                          if (!limitPerCustomerOnce) {
                            setLimitPerAccount(false)
                            setLimitPerCustomerOnce(true)
                          } else {
                            // Safe to uncheck because left is true
                            setLimitPerAccount(false)
                          }
                        }

                        markDirty?.()
                      }}
                      label="Set Usage Limit Per Account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(e.target.value)
                            markDirty?.()
                          }}
                          required
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Dates</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value)
                        markDirty()
                      }}
                      required
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      value={startTime}
                      onChange={(e) => {
                        setStartTime(e.target.value)
                        markDirty()
                      }}
                      required
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                  </Col>
                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        markDirty()
                      }}
                      label="Set End Date"
                    />
                  </Col>
                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            setEndDate(e.target.value)
                            markDirty()
                          }}
                          required
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          value={endTime}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            markDirty()
                          }}
                          required
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button variant="outline-secondary" onClick={onDiscard} disabled={saving}>
                Discard
              </Button>
              <Button onClick={onSave} disabled={saving}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>
              <div className="sum-row">
                <div className="sum-label">Discount Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Amount Rules</div>
                <div className="sum-value">Min Purchase: {minPurchase === '' ? '—' : `${currency || '$'}${Number(minPurchase).toFixed(2)}`}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* ---------- NEW: Targets display ---------- */}
              {/* <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
                {targetsLoading && (
                  <span style={{ marginLeft: 8 }}>
                    <Spinner animation="border" size="sm" />
                  </span>
                )}
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">{renderPills(fetchedProducts, 'id', 'title', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">{renderPills(fetchedCollections, 'id', 'name', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">{renderPills(fetchedCategories, 'id', 'name', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">{renderPills(fetchedBrands, 'id', 'name', '—')}</div>
              </div> */}
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Leave-without-saving Modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 170px 1fr;
          gap: 10px;
          padding: 8px 2px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
        }

        /* pills */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .targets-head {
          font-size: 13px;
        }
      `}</style>
    </Card>
  )
}
