'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useRouter } from 'next/navigation'
import Swal from 'sweetalert2'
import { useGetDiscountByIdQuery, useUpdateOrderDiscountSelectiveMutation, useGetDiscountTargetsMutation } from '@/store/features/apiSlice'

export default function ShippingDiscountEdit({
  discountId, // required for edit
  prefill = null, // optional fallback object shaped like API response.data
  onDirty,
}) {
  const router = useRouter()

  // ===================== Unsaved changes guard =====================
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    setDirty(true)
    onDirty?.()
  }

  const [confirmOpen, setConfirmOpen] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'link' | 'router' | 'history' | 'reload'
  const allowNavRef = useRef(false)

  let RouterEvents = null
  try {
    const pages = require('next/router')
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}

  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setConfirmOpen(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setConfirmOpen(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setConfirmOpen(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const reloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!reloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setConfirmOpen(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  useEffect(() => {
    const handler = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [dirty])

  const attemptNavigate = (action) => {
    if (!dirty) {
      if (action === 'history') history.back()
      else if (typeof action === 'string') router.push(action)
      return
    }
    if (action === 'history') {
      pendingActionRef.current = 'history'
      setPendingHref(null)
    } else if (typeof action === 'string') {
      pendingActionRef.current = 'router'
      setPendingHref(action)
    }
    setConfirmOpen(true)
  }

  const discardAndGo = () => {
    setConfirmOpen(false)
    setDirty(false)
    allowNavRef.current = true
    const action = pendingActionRef.current
    const href = pendingHref
    if (action === 'history') history.back()
    else if ((action === 'router' || action === 'link') && href) router.push(href)
    else if (action === 'reload') window.location.reload()
  }

  // ===================== Helpers =====================
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }
  // RETURN EXACT WALL-CLOCK STRING (no timezone conversions)
  // returns "YYYY-MM-DD HH:MM:SS" or null
  const joinISO = (d, t) => {
    if (!d || !t) return null
    // d = "YYYY-MM-DD", t = "HH:MM"
    // return plain wall-clock timestamp string (no Z, no timezone offset)
    return `${d} ${t}:00`
  }

  /*
  PARSE incoming timestamp values into { date, time } fields for the form.
  - If server returns an ISO (e.g. "2025-11-24T21:13:00Z" or "2025-11-25T02:43:00+05:30"),
    we convert that instant to the LOCAL date/time for the user's browser.
  - If server returns a plain wall-clock string (e.g. "2025-11-25 02:43:00" or "2025-11-25T02:43:00"),
    we parse it as-is (no timezone conversion) and return the same date/time tokens.
*/
  const isoToLocal = (val) => {
    if (!val) return { date: '', time: '' }

    // If value looks like an ISO instant (contains 'Z' or an offset like +05:30 or contains 'T' and a timezone)
    const looksLikeZonedISO = /Z$|[+-]\d{2}:\d{2}$/.test(String(val)) || /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(String(val))

    // If looks like a zoned ISO (has timezone/UTC), parse into a Date and output local tokens
    if (looksLikeZonedISO) {
      try {
        const d = new Date(val)
        if (Number.isNaN(d.getTime())) throw new Error('invalid date')
        const pad = (n) => String(n).padStart(2, '0')
        return {
          date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
          time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
        }
      } catch {
        return { date: '', time: '' }
      }
    }

    // Otherwise treat as a plain wall-clock string (no conversions).
    // Accept formats: "YYYY-MM-DD HH:MM:SS" or "YYYY-MM-DDTHH:MM:SS" or "YYYY-MM-DD HH:MM" etc.
    try {
      const s = String(val).trim()
      // normalize separator: replace 'T' with space
      const normalized = s.replace('T', ' ')
      const [datePart, timePart = ''] = normalized.split(' ')
      if (!datePart) return { date: '', time: '' }

      // time may include seconds; take first two segments HH:MM
      const timeTokens = (timePart || '').split(':')
      const hh = timeTokens[0] ? timeTokens[0].padStart(2, '0') : '00'
      const mm = timeTokens[1] ? timeTokens[1].padStart(2, '0') : '00'

      // Basic sanity check on date format (YYYY-MM-DD)
      const dateOk = /^\d{4}-\d{2}-\d{2}$/.test(datePart)
      if (!dateOk) return { date: '', time: '' }

      return { date: datePart, time: `${hh}:${mm}` }
    } catch {
      return { date: '', time: '' }
    }
  }

  const normalize = (v) => v
  const isEqual = (a, b) => JSON.stringify(normalize(a)) === JSON.stringify(normalize(b))

  // ===================== Data Hooks (edit mode) =====================
  const idNum = Number(discountId)
  const {
    data: fetched,
    isLoading: loading,
    isFetching,
    error: fetchError,
  } = useGetDiscountByIdQuery(Number.isFinite(idNum) ? idNum : 0, { skip: !Number.isFinite(idNum) })
  const [updateSelective, { isLoading: saving }] = useUpdateOrderDiscountSelectiveMutation()

  // ----- Fetch discount targets (products, collections, etc.) -----
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  // ===================== Form =====================
  const [title, setTitle] = useState('')

  const [valueType, setValueType] = useState('percentage')
  const [value, setValue] = useState(10)

  const [enableAmounts, setEnableAmounts] = useState(true)
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('')

  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  const [errors, setErrors] = useState({})
  const lastPrefillRef = useRef(null)

  // ============ Prefill / Hydration ============
  const activePrefill = useMemo(() => {
    if (fetched?.data && typeof fetched.data === 'object') return fetched.data
    if (fetched && typeof fetched === 'object') return fetched
    if (prefill && typeof prefill === 'object') return prefill
    return null
  }, [fetched, prefill])

  const hydrateFrom = (p) => {
    if (!p) return
    lastPrefillRef.current = p

    setTitle(p.discount_title ?? '')

    const vt = p.discount_value_type === 'fixed' ? 'fixed' : 'percentage'
    setValueType(vt)
    setValue(p.discount_value != null ? Number(p.discount_value) : 0)

    const limits = !!p.min_max_purchase_discount_limits
    setEnableAmounts(limits)
    setMinPurchase(limits && p.min_purchase_amount != null ? String(Number(p.min_purchase_amount)) : '')
    setMaxDiscountAmount(limits && vt === 'percentage' && p.max_discount_amount != null ? String(Number(p.max_discount_amount)) : '')

    setEligibility(p.customer_eligibility || 'all')
    setGuestIncluded(!!p.is_guest_allowed)

    const once = !!p.unlimited_usage
    const perAcc = p.usage_limit_per_account != null
    setLimitPerCustomerOnce(once && !perAcc)
    setLimitPerAccount(perAcc && !once)
    setPerAccountUses(perAcc ? String(Number(p.usage_limit_per_account)) : '')

    const s = isoToLocal(p.start_date)
    setStartDate(s.date)
    setStartTime(s.time)
    if (p.end_date) {
      const e = isoToLocal(p.end_date)
      setHasEnd(true)
      setEndDate(e.date)
      setEndTime(e.time)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // Reset targets when rehydrating (will be refetched)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])

    setDirty(false)
  }

  useEffect(() => {
    if (activePrefill) hydrateFrom(activePrefill)
  }, [activePrefill])

  // Extract currency from prefill (or keep empty)
  const currency = useMemo(() => {
    const c = activePrefill?.currency ?? ''
    if (!c) return ''

    // Optional mappings (remove if you want codes only)
    if (c === 'USD') return '$'
    if (c === 'EUR') return '€'
    if (c === 'GBP') return '£'
    if (c === 'INR') return '₹'

    // Default: show code (example: LKR)
    return c
  }, [activePrefill])

  // Fetch discount targets when discountId is valid
  useEffect(() => {
    let mounted = true
    const fetchTargets = async () => {
      if (!idNum) return
      try {
        const data = await getDiscountTargets({ discount_id: idNum }).unwrap()
        if (!mounted) return
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // silent fail
      }
    }
    fetchTargets()
    return () => {
      mounted = false
    }
  }, [idNum, getDiscountTargets])

  // Keep endDate >= startDate when end is enabled
  useEffect(() => {
    if (!hasEnd || !startDate || !endDate) return
    if (endDate < startDate) setEndDate(startDate)
  }, [startDate, endDate, hasEnd])

  // ===================== Derived summaries =====================
  const valueSummary = useMemo(
    () => (valueType === 'percentage' ? `${Number(value || 0)}%` : `${currency} ${Number(value || 0).toFixed(2)}`),
    [valueType, value, currency],
  )

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])
  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])
  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // ===================== Validation =====================
  const validate = () => {
    const e = {}
    const trimmed = title.trim()
    if (!trimmed) e.title = 'Title is required.'
    if (trimmed.length > 100) e.title = 'Title must be 100 characters or fewer.'

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
    } else {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (enableAmounts) {
      if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase is required.'
      if (valueType === 'percentage' && (maxDiscountAmount === '' || Number(maxDiscountAmount) <= 0)) {
        e.maxDiscountAmount = 'Maximum discount amount is required.'
      }
    }

    if (limitPerAccount && (perAccountUses === '' || Number(perAccountUses) < 1)) {
      e.perAccount = 'Usage per account is required.'
    }

    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    // if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ===================== Build snapshot & diff =====================
  const buildCurrent = () => ({
    main_discount_type: 'order',
    order_discount_method: 'shipping',

    discount_title: title.trim(),
    discount_value_type: valueType,
    discount_value: Number(value),

    min_max_purchase_discount_limits: !!enableAmounts,
    min_purchase_amount: enableAmounts ? Number(minPurchase) : null,
    max_discount_amount: enableAmounts && valueType === 'percentage' ? Number(maxDiscountAmount) : null,

    customer_eligibility: eligibility,
    is_guest_allowed: !!guestIncluded,

    unlimited_usage: !!limitPerCustomerOnce,
    usage_limit_per_account: limitPerAccount ? Number(perAccountUses) : null,

    start_date: joinISO(startDate, startTime),
    end_date: hasEnd ? joinISO(endDate, endTime) : null,

    status: 'active',
    discount_code: null,
  })

  const diff = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      if (!isEqual(current[k], original[k])) changes[k] = current[k]
    })
    if ((original.end_date ?? null) !== (current.end_date ?? null) && current.end_date === null) changes.end_date = null
    if ((original.max_discount_amount ?? null) !== (current.max_discount_amount ?? null) && current.max_discount_amount === null)
      changes.max_discount_amount = null
    if ((original.min_purchase_amount ?? null) !== (current.min_purchase_amount ?? null) && current.min_purchase_amount === null)
      changes.min_purchase_amount = null
    if ((original.usage_limit_per_account ?? null) !== (current.usage_limit_per_account ?? null) && current.usage_limit_per_account === null)
      changes.usage_limit_per_account = null
    return changes
  }

  // ===================== Save =====================
  const onSave = async () => {
    if (!validate()) return
    if (!Number.isFinite(idNum) || idNum <= 0) {
      await Swal.fire({ icon: 'error', title: 'Missing ID', text: 'Cannot update: discount_id not provided.' })
      return
    }

    const original = {
      main_discount_type: activePrefill?.main_discount_type ?? 'order',
      order_discount_method: activePrefill?.order_discount_method ?? 'shipping',

      discount_title: activePrefill?.discount_title ?? '',
      discount_value_type: activePrefill?.discount_value_type ?? 'percentage',
      discount_value: activePrefill?.discount_value != null ? Number(activePrefill.discount_value) : 0,

      min_max_purchase_discount_limits: !!activePrefill?.min_max_purchase_discount_limits,
      min_purchase_amount: activePrefill?.min_purchase_amount != null ? Number(activePrefill.min_purchase_amount) : null,
      max_discount_amount: activePrefill?.max_discount_amount != null ? Number(activePrefill.max_discount_amount) : null,

      customer_eligibility: activePrefill?.customer_eligibility ?? 'all',
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill.usage_limit_per_account) : null,

      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      status: activePrefill?.status ?? 'active',
      discount_code: activePrefill?.discount_code ?? null,
    }

    const current = buildCurrent()
    const changes = diff(original, current)
    if (Object.keys(changes).length === 0) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
      return
    }

    const loadingSwal = Swal.fire({
      title: 'Saving…',
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      await updateSelective({ id: idNum, changes }).unwrap()
      Swal.close()
      setDirty(false)

      // show success and wait for user to dismiss
      await Swal.fire({
        icon: 'success',
        title: 'Updated',
        text: 'Shipping discount updated successfully.',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // notify any listeners in the app that a discount was saved (same pattern as addProductDiscount)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      Swal.close()
      await Swal.fire({
        icon: 'error',
        title: 'Update failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
      })
    } finally {
      loadingSwal.then(() => {})
    }
  }

  // ===================== Discard -> restore prefilled via SweetAlert =====================

  // Discard -> reset to prefilled values (SweetAlert)
  const onDiscardToPrefill = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  // ===================== UI =====================
  const disabled = saving || loading || isFetching

  // ----- Render pills for target items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items) || items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }

  return (
    <>
      <Card className="soft-card">
        <Card.Header className="bg-white d-flex align-items-start justify-content-between">
          <div>
            <Card.Title className="mb-0">Shipping Discount (Edit)</Card.Title>
            <small className="text-muted">Reduce or waive shipping cost based on conditions.</small>
          </div>
          <div className="d-flex gap-2">
            {/* <Button
              variant="outline-secondary"
              className="rounded-pill d-inline-flex align-items-center gap-2 nowrap"
              onClick={() => attemptNavigate('history')}>
              <Icon icon="solar:arrow-left-linear" width={18} />
              Go Back
            </Button>
            <Button
              variant="outline-secondary"
              className="rounded-pill d-inline-flex align-items-center gap-2 nowrap"
              onClick={() => attemptNavigate('/admin/sales_manager/discounts')}>
              <Icon icon="solar:logout-2-linear" width={18} />
              Exit
            </Button> */}
          </div>
        </Card.Header>

        <Card.Body>
          {(loading || isFetching) && (
            <div className="d-flex align-items-center gap-2 mb-2">
              <Spinner animation="border" size="sm" />
              <small className="text-muted">Loading discount…</small>
            </div>
          )}
          {fetchError && <div className="text-danger small mb-2">Failed to load discount details.</div>}

          <Row className="g-3">
            {/* LEFT: Form */}
            <Col lg={8}>
              {/* Title */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Title</span>
                </div>
                <div className="section-body">
                  <Form.Control
                    placeholder="e.g. Free Shipping over $50"
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value.slice(0, 100))
                      markDirty()
                    }}
                    required
                    disabled={disabled}
                  />
                  <div className="d-flex justify-content-between mt-1">
                    <small className="text-muted">{title.length}/100</small>
                    {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                  </div>
                </div>
              </section>

              {/* Discount Value */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Value</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-perc"
                          name="val-type"
                          checked={valueType === 'percentage'}
                          onChange={() => {
                            setValueType('percentage')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Percentage</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-fixed"
                          name="val-type"
                          checked={valueType === 'fixed'}
                          onChange={() => {
                            setValueType('fixed')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <InputGroup>
                        {valueType === 'percentage' ? (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="1"
                              max="100"
                              step="1"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              disabled={disabled}
                            />
                          </>
                        ) : (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">{currency || '$'}</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="0.01"
                              step="0.01"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              disabled={disabled}
                            />
                          </>
                        )}
                      </InputGroup>
                      {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Amount Limits */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Set Minimum Purchase &amp; Maximum Discount Amount</span>
                </div>

                <div className="section-body">
                  <Row className="g-3">
                    <Col md={valueType === 'percentage' ? 6 : 7}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap">Minimum Purchase Amount {currency ? `(${currency})` : ''}</InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0"
                          step="0.01"
                          value={minPurchase}
                          onChange={(e) => {
                            setMinPurchase(e.target.value)
                            markDirty()
                          }}
                          required
                          disabled={disabled}
                        />
                      </InputGroup>

                      {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                    </Col>

                    {valueType === 'percentage' && (
                      <Col md={6}>
                        <InputGroup>
                          <InputGroup.Text className="fw-semibold nowrap">Maximum Discount Amount {currency ? `(${currency})` : ''}</InputGroup.Text>

                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={maxDiscountAmount}
                            onChange={(e) => {
                              setMaxDiscountAmount(e.target.value)
                              markDirty()
                            }}
                            required
                            disabled={disabled}
                          />
                        </InputGroup>

                        {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                      </Col>
                    )}
                  </Row>
                </div>
              </section>

              {/* Customer Eligibility */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Customer Eligibility</span>
                </div>
                <div className="section-body">
                  <Row className="g-2 align-items-center">
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-all"
                        checked={eligibility === 'all'}
                        onChange={() => {
                          setEligibility('all')
                          markDirty()
                        }}
                        label="All Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-new"
                        checked={eligibility === 'new'}
                        onChange={() => {
                          setEligibility('new')
                          markDirty()
                        }}
                        label="New Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-existing"
                        checked={eligibility === 'existing'}
                        onChange={() => {
                          setEligibility('existing')
                          markDirty()
                        }}
                        label="Existing Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="checkbox"
                        id="elig-guest"
                        checked={!!guestIncluded}
                        onChange={(e) => {
                          setGuestIncluded(e.target.checked)
                          markDirty()
                        }}
                        label="Guest Customers"
                        disabled={disabled}
                      />
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Usage Limit (mutually exclusive, always one selected) */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Usage Limit</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-customer"
                        checked={limitPerCustomerOnce}
                        disabled={disabled}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Block unchecking if it would leave both unchecked
                          if (!checked && !limitPerAccount) return

                          setLimitPerCustomerOnce(checked)

                          // Since this block has no prefill logic, only handle exclusivity
                          if (checked) {
                            setLimitPerAccount(false)
                          }

                          markDirty()
                        }}
                        label="Unlimited Discount Usage"
                      />
                    </Col>

                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-account"
                        checked={limitPerAccount}
                        disabled={disabled}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Block unchecking if it would leave both unchecked
                          if (!checked && !limitPerCustomerOnce) return

                          setLimitPerAccount(checked)

                          if (checked) {
                            setLimitPerCustomerOnce(false)
                          }

                          markDirty()
                        }}
                        label="Set Usage Limit Per Account"
                      />

                      {limitPerAccount && (
                        <div className="mt-2" style={{ maxWidth: 220 }}>
                          <Form.Control
                            type="number"
                            min="1"
                            step="1"
                            required
                            value={perAccountUses}
                            disabled={disabled}
                            onChange={(e) => {
                              setPerAccountUses(e.target.value)
                              markDirty()
                            }}
                          />
                          {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                        </div>
                      )}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Active Dates */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Active Dates</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Date <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        required
                        value={startDate}
                        onChange={(e) => {
                          setStartDate(e.target.value)
                          markDirty()
                        }}
                        disabled={disabled}
                      />
                      {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                    </Col>
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Time <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="time"
                        required
                        value={startTime}
                        onChange={(e) => {
                          setStartTime(e.target.value)
                          markDirty()
                        }}
                        disabled={disabled}
                      />
                      {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                    </Col>
                    <Col md={12}>
                      <Form.Check
                        id="has-end"
                        type="checkbox"
                        className="mt-2"
                        checked={hasEnd}
                        onChange={(e) => {
                          setHasEnd(e.target.checked)
                          markDirty()
                        }}
                        label="Set End Date"
                        disabled={disabled}
                      />
                    </Col>
                    {hasEnd && (
                      <>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Date <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="date"
                            required
                            min={startDate || todayISO()}
                            value={endDate}
                            onChange={(e) => {
                              setEndDate(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                        </Col>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Time <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="time"
                            required
                            value={endTime}
                            onChange={(e) => {
                              setEndTime(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                        </Col>
                      </>
                    )}
                  </Row>
                </div>
              </section>

              {/* Footer actions */}
              <div className="footer-actions">
                <Button variant="outline-secondary" onClick={onDiscardToPrefill} disabled={disabled}>
                  Discard
                </Button>
                <Button onClick={onSave} disabled={disabled}>
                  {disabled ? (
                    <>
                      <Spinner animation="border" size="sm" className="me-2" /> Saving…
                    </>
                  ) : (
                    'Save'
                  )}
                </Button>
              </div>
            </Col>

            {/* RIGHT: Summary */}
            <Col lg={4}>
              <aside className="summary-card">
                <div className="sum-head">Discount Summary</div>
                <div className="sum-row">
                  <div className="sum-label">Title</div>
                  <div className="sum-value">{title || '—'}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Discount Value</div>
                  <div className="sum-value">{valueSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Eligibility</div>
                  <div className="sum-value">{eligibilitySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Amount Rules</div>
                  <div className="sum-value">
                    Min Purchase:
                    {minPurchase === '' ? '—' : `${currency} ${Number(minPurchase).toFixed(2)}`}
                    <br />
                    {valueType === 'percentage' ? (
                      <>
                        Max Discount:
                        {maxDiscountAmount === '' ? '—' : `${currency} ${Number(maxDiscountAmount).toFixed(2)}`}
                      </>
                    ) : (
                      <>Max Discount: —</>
                    )}
                  </div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Usage Limits</div>
                  <div className="sum-value">{usageSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Active Period</div>
                  <div className="sum-value">{periodSummary}</div>
                </div>

                {/* NEW: Targets Section */}
                {/* <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                  Targets
                  {targetsLoading && (
                    <span style={{ marginLeft: 8 }}>
                      <Spinner animation="border" size="sm" />
                    </span>
                  )}
                </div>

                <div className="sum-row">
                  <div className="sum-label">Products</div>
                  <div className="sum-value">{renderPills(fetchedProducts, 'id', 'title', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Collections</div>
                  <div className="sum-value">{renderPills(fetchedCollections, 'id', 'name', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Categories</div>
                  <div className="sum-value">{renderPills(fetchedCategories, 'id', 'name', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Brands</div>
                  <div className="sum-value">{renderPills(fetchedBrands, 'id', 'name', '—')}</div>
                </div> */}
              </aside>
            </Col>
          </Row>
        </Card.Body>

        <style jsx>{`
          .section + .section {
            margin-top: 16px;
          }
          .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            background: #f5f7fb;
          }
          .section-title {
            font-weight: 700;
            color: #111827;
          }
          .section-body {
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 0 0 12px 12px;
            background: #fff;
          }
          .stacked-choice {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 10px;
            padding: 10px 12px;
            background: #fff;
          }
          .footer-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 18px;
          }
          .summary-card {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            background: #fff;
            padding: 12px;
          }
          .sum-head {
            font-weight: 700;
            color: #111827;
            background: #f5f7fb;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 10px;
            padding: 10px 12px;
            margin-bottom: 10px;
          }
          .sum-row {
            display: grid;
            grid-template-columns: 170px 1fr;
            gap: 10px;
            padding: 8px 2px;
          }
          .sum-label {
            color: #6b7280;
            font-weight: 600;
          }
          .sum-value {
            color: #111827;
          }
          .nowrap {
            white-space: nowrap;
          }

          /* Pills */
          .pills-wrap {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
          }
          .pill {
            display: inline-flex;
            align-items: center;
            padding: 6px 8px;
            border-radius: 999px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            background: #fafafa;
            font-size: 12px;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          .pill-label {
            display: inline-block;
            max-width: 160px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .targets-head {
            font-size: 13px;
          }
        `}</style>
      </Card>

      {/* Unsaved changes modal */}
      <Modal show={confirmOpen} onHide={() => setConfirmOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Unsaved changes</Modal.Title>
        </Modal.Header>
        <Modal.Body>You have unsaved changes. If you leave this page, your edits will be lost.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setConfirmOpen(false)}>
            Stay on page
          </Button>
          <Button variant="danger" onClick={discardAndGo}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
