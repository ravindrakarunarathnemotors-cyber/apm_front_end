'use client'

import { useMemo, useState, useEffect, useRef } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

// RTK Query (edit mode)
import { useGetDiscountByIdQuery, useUpdateOrderDiscountSelectiveMutation, useGetDiscountTargetsMutation } from '@/store/features/apiSlice' // adjust path if needed

export default function DiscountCodeEdit({
  discountId, // required for edit mode
  onDirty,
  prefill = null, // optional fallback object
}) {
  // ----- Core form state (start BLANK; hydrate from server) -----
  const [code, setCode] = useState('') // max 10 chars
  const [valueType, setValueType] = useState('') // 'percentage' | 'fixed' | ''
  const [value, setValue] = useState('') // '' until hydrated

  // Customer eligibility
  const [eligibility, setEligibility] = useState('') // '' | 'all' | 'new' | 'existing'
  const [guestIncluded, setGuestIncluded] = useState(false)

  // Usage limit (mutually exclusive between these two)
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false) // unlimited_usage (true = one-time)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('') // '' until hydrated

  // Amount rules
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('') // only when percentage

  // Active period
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // Actions / validation
  const [errors, setErrors] = useState({})

  // --- NEW: currency from server/prefill (default to empty; will hydrate)
  const [currency, setCurrency] = useState('') // e.g. "LKR"

  // RTK hooks
  const idNum = Number(discountId)
  const {
    data: fetched,
    isLoading,
    isFetching,
    error: fetchError,
  } = useGetDiscountByIdQuery(Number.isFinite(idNum) ? idNum : 0, { skip: !Number.isFinite(idNum) })

  const [updateOrderSelective, { isLoading: saving }] = useUpdateOrderDiscountSelectiveMutation()

  // ----- RTKQ fetch targets mutation hook (trigger) -----
  // returns [trigger, result]
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult

  // store fetched target objects
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  // Keep last loaded prefill so Discard can restore
  const lastPrefillRef = useRef(null)

  // ----- Helpers -----
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  const isoToLocalParts = (iso) => {
    if (!iso) return { date: '', time: '' }
    try {
      const d = new Date(iso)
      const pad = (n) => String(n).padStart(2, '0')
      return {
        date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
        time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      }
    } catch {
      return { date: '', time: '' }
    }
  }

  const joinDateTime = (d, t) => (d && t ? `${d}T${t}:00` : null)
  const toNumOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v))

  const normalize = (v) =>
    Array.isArray(v)
      ? v
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => a - b)
      : v
  const isEqual = (a, b) => JSON.stringify(normalize(a)) === JSON.stringify(normalize(b))

  const buildCurrentSnapshot = () => ({
    main_discount_type: 'order',
    order_discount_method: 'code',
    discount_title: null,

    discount_value_type: valueType || null,
    discount_value: value === '' ? null : Number(value),

    // purchase limits (code form always sends a min; follows your previous create shape)
    min_max_purchase_discount_limits: true,
    min_purchase_amount: toNumOrNull(minPurchase),
    max_discount_amount: valueType === 'percentage' ? toNumOrNull(maxDiscountAmount) : null,

    // eligibility
    customer_eligibility: eligibility || null,
    is_guest_allowed: !!guestIncluded,

    // usage limits
    unlimited_usage: !!limitPerCustomerOnce,
    usage_limit_per_account: limitPerAccount ? toNumOrNull(perAccountUses) : null,

    status: 'active',
    start_date: joinDateTime(startDate, startTime),
    end_date: hasEnd ? joinDateTime(endDate, endTime) : null,

    discount_code: (code || '').toUpperCase().slice(0, 10),
    payment_method: null,
  })

  const diffAgainst = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      const cur = current[k]
      const orig = original[k]
      if (!isEqual(cur, orig)) changes[k] = cur
    })

    // explicit clears / nullables
    if (!isEqual(original.end_date ?? null, current.end_date ?? null) && current.end_date === null) {
      changes.end_date = null
    }
    if (!isEqual(original.max_discount_amount ?? null, current.max_discount_amount ?? null) && current.max_discount_amount === null) {
      changes.max_discount_amount = null
    }
    if (!isEqual(original.usage_limit_per_account ?? null, current.usage_limit_per_account ?? null) && current.usage_limit_per_account === null) {
      changes.usage_limit_per_account = null
    }
    if (!isEqual(original.min_purchase_amount ?? null, current.min_purchase_amount ?? null) && current.min_purchase_amount === null) {
      changes.min_purchase_amount = null
    }
    return changes
  }

  // ----- Prefill resolution & hydration -----
  const activePrefill = useMemo(() => {
    if (fetched?.data && typeof fetched.data === 'object') return fetched.data
    if (fetched && typeof fetched === 'object') return fetched
    if (prefill && typeof prefill === 'object') return prefill
    return null
  }, [fetched, prefill])

  const hydrateFrom = (p) => {
    if (!p) return
    lastPrefillRef.current = p

    // Code & value
    setCode(p.discount_code ? String(p.discount_code).toUpperCase().slice(0, 10) : '')
    const vt = p.discount_value_type === 'percentage' || p.discount_value_type === 'fixed' ? p.discount_value_type : ''
    setValueType(vt)
    setValue(p.discount_value != null ? String(Number(p.discount_value)) : '')

    // Amount rules
    setMinPurchase(p.min_purchase_amount != null ? String(Number(p.min_purchase_amount)) : '')
    setMaxDiscountAmount(vt === 'percentage' && p.max_discount_amount != null ? String(Number(p.max_discount_amount)) : '')

    // set currency from response (try several common property names, fallback to 'LKR')
    setCurrency(p?.currency || p?.currency_code || p?.currencySymbol || p?.currency_symbol || p?.currencyIso || 'LKR')

    // Eligibility
    setEligibility(p.customer_eligibility || '')
    setGuestIncluded(!!p.is_guest_allowed)

    // Usage limits
    const once = !!p.unlimited_usage
    const perAcc = p.usage_limit_per_account != null
    setLimitPerCustomerOnce(once && !perAcc)
    setLimitPerAccount(perAcc && !once)
    setPerAccountUses(perAcc ? String(Number(p.usage_limit_per_account)) : '')

    // Dates
    const s = isoToLocalParts(p.start_date)
    setStartDate(s.date)
    setStartTime(s.time)
    if (p.end_date) {
      const e = isoToLocalParts(p.end_date)
      setHasEnd(true)
      setEndDate(e.date)
      setEndTime(e.time)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // clear previously fetched targets when hydrating from new prefill (we'll refetch)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])
  }

  useEffect(() => {
    if (activePrefill) hydrateFrom(activePrefill)
  }, [activePrefill])

  // near the top of hydrateFrom
  // --- set currency from response (try multiple common property names)
  // set currency from response (try several common property names, fallback to 'LKR')

  // ----- Fetch targets for the discount when discountId changes -----
  useEffect(() => {
    let mounted = true
    const fetchTargets = async (discountId) => {
      if (!discountId) return
      try {
        // trigger the mutation which calls POST /discount-module/discount-targets
        const data = await getDiscountTargets({ discount_id: discountId }).unwrap()
        if (!mounted) return
        // data shape expected:
        // { discount_id, products: [...], collections: [...], categories: [...], brands: [...] }
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // keep silent in UI; you can log if desired
        // console.error('Failed to fetch discount targets', err)
      }
    }

    if (idNum) fetchTargets(idNum)
    return () => {
      mounted = false
    }
  }, [idNum, getDiscountTargets])

  // keep endDate >= startDate
  useEffect(() => {
    if (!startDate) return
    if (hasEnd && endDate && endDate < startDate) setEndDate(startDate)
  }, [startDate, hasEnd, endDate])

  // Enforce mutual exclusivity between the two usage toggles
  const togglePerCustomerOnce = (checked) => {
    setLimitPerCustomerOnce(checked)
    if (checked) {
      setLimitPerAccount(false)
      setPerAccountUses('')
    }
    onDirty?.()
  }
  const togglePerAccount = (checked) => {
    setLimitPerAccount(checked)
    if (checked) {
      setLimitPerCustomerOnce(false)
    } else {
      setPerAccountUses('')
    }
    onDirty?.()
  }

  // --- Derived summary bits ---
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    if (valueType === 'fixed') return `${Number(value || 0).toLocaleString()} ${currency || 'LKR'}`
    return '—'
  }, [valueType, value, currency])

  const eligibilitySummary = useMemo(() => {
    if (!eligibility) return '—'
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // --- Validation ---
  const validate = () => {
    const e = {}
    // code
    if (!code.trim()) e.code = 'Discount code is required.'
    if (code.trim().length > 10) e.code = 'Code must be 10 characters or fewer.'

    // value type & value
    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) <= 0) e.maxDiscountAmount = 'Maximum discount must be greater than 0.'
    } else if (valueType === 'fixed') {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    // amounts
    if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase is required.'

    // usage limits
    if (limitPerAccount) {
      if (perAccountUses === '' || Number(perAccountUses) < 1) e.perAccount = 'Usage per account is required.'
    }

    // dates
    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // Submit (UPDATE only — send diff)
  const onSave = async () => {
    if (!validate()) return
    if (!Number.isFinite(idNum) || idNum <= 0) {
      await Swal.fire({ icon: 'error', title: 'Missing ID', text: 'Cannot update: discount_id not provided.' })
      return
    }

    const current = buildCurrentSnapshot()
    const original = {
      main_discount_type: activePrefill?.main_discount_type ?? 'order',
      order_discount_method: activePrefill?.order_discount_method ?? 'code',
      discount_title: activePrefill?.discount_title ?? null,

      discount_value_type: activePrefill?.discount_value_type ?? null,
      discount_value: activePrefill?.discount_value != null ? Number(activePrefill.discount_value) : null,

      min_max_purchase_discount_limits: activePrefill?.min_max_purchase_discount_limits ?? true,
      min_purchase_amount: activePrefill?.min_purchase_amount != null ? Number(activePrefill.min_purchase_amount) : null,
      max_discount_amount: activePrefill?.max_discount_amount != null ? Number(activePrefill.max_discount_amount) : null,

      customer_eligibility: activePrefill?.customer_eligibility ?? null,
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill.usage_limit_per_account) : null,

      status: activePrefill?.status ?? 'active',
      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      discount_code: activePrefill?.discount_code ? String(activePrefill.discount_code).toUpperCase().slice(0, 10) : '',
      payment_method: null,
    }

    const changes = diffAgainst(original, current)
    if (Object.keys(changes).length === 0) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'There is nothing to update.' })
      return
    }

    Swal.fire({
      title: 'Saving…',
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      await updateOrderSelective({ id: idNum, changes }).unwrap()
      Swal.close()

      // wait for success alert
      await Swal.fire({
        title: 'Updated',
        text: 'Discount code updated successfully.',
        icon: 'success',
        confirmButtonColor: '#111827',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // 🔥 notify any listeners (same behavior as addProductDiscount)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      Swal.close()
      await Swal.fire({
        title: 'Update failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
        icon: 'error',
        confirmButtonColor: '#111827',
      })
    }
  }

  // --- Handlers ---
  const handleCodeInput = (v) => {
    const cleaned = v
      .toUpperCase()
      .replace(/\s+/g, '')
      .replace(/[^A-Z0-9_-]/g, '')
      .slice(0, 10)
    setCode(cleaned)
    onDirty?.()
  }
  const generateCode = () => {
    const c = randomCode(10)
    setCode(c)
    onDirty?.()
  }

  // Discard -> reset to prefilled values (SweetAlert)
  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  // ----- Helper to render pills for items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items)) return placeholder
    if (items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }

  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">Discount Code (Edit)</Card.Title>
          <small className="text-muted">Edit a code that customers enter at checkout.</small>
        </div>
        <span />
      </Card.Header>

      <Card.Body>
        {(isLoading || isFetching) && (
          <div className="d-flex align-items-center gap-2 mb-2">
            <Spinner animation="border" size="sm" />
            <small className="text-muted">Loading discount…</small>
          </div>
        )}
        {fetchError && <div className="text-danger small mb-2">Failed to load discount details.</div>}

        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Code */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Code</span>
                <Button size="sm" variant="link" className="p-0 fw-semibold" onClick={generateCode}>
                  Generate Random Code
                </Button>
              </div>
              <div className="section-body">
                <InputGroup>
                  <InputGroup.Text className="fw-semibold">Code</InputGroup.Text>
                  <Form.Control value={code} required maxLength={10} onChange={(e) => handleCodeInput(e.target.value)} />
                </InputGroup>
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">{code.length}/10</small>
                  {errors.code && <small className="text-danger nowrap">{errors.code}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          onDirty?.()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          onDirty?.()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="1"
                            max="100"
                            step="1"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(e.target.value)
                              onDirty?.()
                            }}
                          />
                        </>
                      ) : valueType === 'fixed' ? (
                        <>
                          <InputGroup.Text className="fw-semibold small-label nowrap">{currency || '-'}</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(e.target.value)
                              onDirty?.()
                            }}
                          />
                        </>
                      ) : (
                        <Form.Control disabled placeholder="Choose a discount type first" />
                      )}
                    </InputGroup>
                    {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    {errors.valueType && <div className="text-danger small mt-1 nowrap">{errors.valueType}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Limits */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase and Maximum Discount Amount</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap" style={{ fontSize: '12px', minWidth: '180px' }}>
                        Minimum Purchase Amount {currency ? `(${currency})` : ''}
                      </InputGroup.Text>

                      <Form.Control
                        type="number"
                        min="0"
                        step="0.01"
                        value={minPurchase}
                        onChange={(e) => {
                          setMinPurchase(e.target.value)
                          onDirty?.()
                        }}
                        required
                      />
                    </InputGroup>

                    {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                  </Col>

                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap" style={{ fontSize: '12px', minWidth: '180px' }}>
                          Maximum Discount Amount {currency ? `(${currency})` : ''}
                        </InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0.01"
                          step="0.01"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            setMaxDiscountAmount(e.target.value)
                            onDirty?.()
                          }}
                          placeholder="Optional"
                        />
                      </InputGroup>

                      {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        onDirty?.()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        onDirty?.()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        onDirty?.()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        onDirty?.()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Maximum Discount Uses (mutually exclusive, always one selected) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Maximum Discount Uses</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent deselecting if it would leave both unchecked
                        if (!checked && !limitPerAccount) return

                        // Call the provided handler
                        togglePerCustomerOnce(checked)

                        // If this becomes checked, ensure the other is off
                        if (checked && limitPerAccount) togglePerAccount(false)
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent deselecting if it would leave both unchecked
                        if (!checked && !limitPerCustomerOnce) return

                        // Call the provided handler
                        togglePerAccount(checked)

                        // If this becomes checked, ensure the other is off
                        if (checked && limitPerCustomerOnce) togglePerCustomerOnce(false)
                      }}
                      label="Set usage limit per account"
                    />
                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Dates</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => {
                        setStartTime(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                  </Col>
                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        onDirty?.()
                      }}
                      label="Set End Date"
                    />
                  </Col>
                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            setEndDate(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button variant="outline-secondary" onClick={onDiscard} disabled={saving}>
                Discard
              </Button>
              <Button onClick={onSave} disabled={saving || isLoading || isFetching}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>
              <div className="sum-row">
                <div className="sum-label">Discount Code</div>
                <div className="sum-value code">{code || '—'}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Amount Rules</div>
                <div className="sum-value">
                  Min Purchase: {minPurchase === '' ? '—' : `${Number(minPurchase).toLocaleString()} ${currency || 'LKR'}`}
                  <br />
                  {valueType === 'percentage' ? (
                    <>Max Discount: {maxDiscountAmount === '' ? '—' : `${Number(maxDiscountAmount).toLocaleString()} ${currency || 'LKR'}`}</>
                  ) : (
                    <>Max Discount: —</>
                  )}
                </div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* ---------- NEW: Targets display ---------- */}
              {/* <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
                {targetsLoading && (
                  <span style={{ marginLeft: 8 }}>
                    <Spinner animation="border" size="sm" />
                  </span>
                )}
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">{renderPills(fetchedProducts, 'id', 'title', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">{renderPills(fetchedCollections, 'id', 'name', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">{renderPills(fetchedCategories, 'id', 'name', '—')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">{renderPills(fetchedBrands, 'id', 'name', '—')}</div>
              </div> */}
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 140px 1fr;
          gap: 10px;
          padding: 8px 2px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
        }
        .sum-value.code {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
        }

        /* pills */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .targets-head {
          font-size: 13px;
        }
      `}</style>
    </Card>
  )
}

function randomCode(len = 10) {
  const alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let s = ''
  for (let i = 0; i < len; i++) s += alpha[Math.floor(Math.random() * alpha.length)]
  return s
}
