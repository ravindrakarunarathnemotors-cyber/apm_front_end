'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import {
  useGetActivePaymentMethodsQuery,
  useGetDiscountByIdQuery,
  useUpdateOrderDiscountSelectiveMutation,
  useGetDiscountTargetsMutation,
} from '@/store/features/apiSlice'

export default function PaymentMethodEdit({
  discountId, // required for edit mode
  prefill = null, // optional fallback object
  onDirty,
}) {
  /* ================= Unsaved Changes (same UX) ================= */
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    setDirty(true)
    onDirty?.()
  }

  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'link' | 'router' | 'history' | 'reload'
  const allowNavRef = useRef(false)

  let RouterEvents = null
  let nextRouter = null
  try {
    const pages = require('next/router')
    nextRouter = pages.useRouter?.()
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }

  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const isReloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!isReloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setShowPrompt(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  const proceedNavigation = () => {
    const action = pendingActionRef.current
    const href = pendingHref
    setShowPrompt(false)
    setDirty(false)
    allowNavRef.current = true

    if ((action === 'link' || action === 'router') && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }
    if (action === 'history') {
      history.back()
      return
    }
    if (action === 'reload') {
      window.location.reload()
    }
  }
  const cancelNavigation = () => {
    setShowPrompt(false)
    setPendingHref(null)
    pendingActionRef.current = null
    allowNavRef.current = false
  }

  /* ================= Helpers ================= */
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }
  const isoToLocalParts = (iso) => {
    if (!iso) return { date: '', time: '' }
    try {
      const d = new Date(iso)
      const pad = (n) => String(n).padStart(2, '0')
      return {
        date: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
        time: `${pad(d.getHours())}:${pad(d.getMinutes())}`,
      }
    } catch {
      return { date: '', time: '' }
    }
  }
  const makeISO = (d, t) => (d && t ? new Date(`${d}T${t}:00`).toISOString() : null)
  const normalize = (v) =>
    Array.isArray(v)
      ? v
          .map(Number)
          .filter(Number.isFinite)
          .sort((a, b) => a - b)
      : v
  const isEqual = (a, b) => JSON.stringify(normalize(a)) === JSON.stringify(normalize(b))

  /* ================= Hooks (RTK) ================= */
  const { data: pmResp, isLoading: pmLoading, isError: pmError } = useGetActivePaymentMethodsQuery()
  const idNum = Number(discountId)
  const {
    data: fetched,
    isLoading: dLoading,
    isFetching: dFetching,
    error: dError,
  } = useGetDiscountByIdQuery(Number.isFinite(idNum) ? idNum : 0, { skip: !Number.isFinite(idNum) })
  const [updateOrderSelective, { isLoading: saving }] = useUpdateOrderDiscountSelectiveMutation()

  // ----- RTKQ fetch targets mutation hook (trigger) -----
  // returns [trigger, result]
  const [getDiscountTargets, getTargetsResult] = useGetDiscountTargetsMutation()
  const { isLoading: targetsLoading } = getTargetsResult

  // store fetched target objects
  const [fetchedProducts, setFetchedProducts] = useState([])
  const [fetchedCollections, setFetchedCollections] = useState([])
  const [fetchedCategories, setFetchedCategories] = useState([])
  const [fetchedBrands, setFetchedBrands] = useState([])

  const activeMethods = useMemo(
    () =>
      (pmResp?.data || []).map((m) => ({
        id: Number(m.payment_method_id),
        name: m.method_name,
      })),
    [pmResp],
  )

  /* ================= Form state ================= */
  const [title, setTitle] = useState('')
  const [selectedMethodIds, setSelectedMethodIds] = useState([]) // number[]
  const toggleMethod = (id) => {
    setSelectedMethodIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
    markDirty()
  }

  const [valueType, setValueType] = useState('percentage')
  const [value, setValue] = useState(10)

  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('')

  const [enableAmounts, setEnableAmounts] = useState(true)
  const [maxPurchase, setMaxPurchase] = useState('') // this is "Minimum Purchase Amount"
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  const [errors, setErrors] = useState({})
  const lastPrefillRef = useRef(null)

  /* ================= Hydration ================= */
  const activePrefill = useMemo(() => {
    if (fetched?.data && typeof fetched.data === 'object') return fetched.data
    if (fetched && typeof fetched === 'object') return fetched
    if (prefill && typeof prefill === 'object') return prefill
    return null
  }, [fetched, prefill])

  // currency derived from prefill/fetched discount object (keeps code like "LKR" if that's what API returns)
  const currency = useMemo(() => {
    const c = activePrefill?.currency ?? ''
    if (!c) return ''
    // optional mapping to common symbols — keep codes for local currencies like "LKR"
    if (c === 'USD') return '$'
    if (c === 'EUR') return '€'
    if (c === 'GBP') return '£'
    return c
  }, [activePrefill])

  const hydrateFrom = (p) => {
    if (!p) return
    lastPrefillRef.current = p

    setTitle(p.discount_title ?? '')

    // Payment method ids (array)
    const pm = Array.isArray(p.payment_method) ? p.payment_method : []
    setSelectedMethodIds(pm.map(Number).filter(Number.isFinite))

    // Value
    const vt = p.discount_value_type === 'fixed' ? 'fixed' : 'percentage'
    setValueType(vt)
    setValue(p.discount_value != null ? Number(p.discount_value) : 0)

    // Amounts
    const hasLimits = !!p.min_max_purchase_discount_limits
    setEnableAmounts(hasLimits)
    setMaxPurchase(hasLimits && p.min_purchase_amount != null ? String(Number(p.min_purchase_amount)) : '')
    setMaxDiscountAmount(hasLimits && vt === 'percentage' && p.max_discount_amount != null ? String(Number(p.max_discount_amount)) : '')

    // Eligibility
    setEligibility(p.customer_eligibility || 'all')
    setGuestIncluded(!!p.is_guest_allowed)

    // Usage
    const once = !!p.unlimited_usage
    const perAcc = p.usage_limit_per_account != null
    setLimitPerCustomerOnce(once && !perAcc)
    setLimitPerAccount(perAcc && !once)
    setPerAccountUses(perAcc ? String(Number(p.usage_limit_per_account)) : '')

    // Dates
    const s = isoToLocalParts(p.start_date)
    setStartDate(s.date)
    setStartTime(s.time)
    if (p.end_date) {
      const e = isoToLocalParts(p.end_date)
      setHasEnd(true)
      setEndDate(e.date)
      setEndTime(e.time)
    } else {
      setHasEnd(false)
      setEndDate('')
      setEndTime('')
    }

    // clear previously fetched targets when hydrating from new prefill (we'll refetch)
    setFetchedProducts([])
    setFetchedCollections([])
    setFetchedCategories([])
    setFetchedBrands([])

    setDirty(false)
  }

  useEffect(() => {
    if (activePrefill) hydrateFrom(activePrefill)
  }, [activePrefill])

  // ----- Fetch targets for the discount when discountId changes -----
  useEffect(() => {
    let mounted = true
    const fetchTargets = async (discountId) => {
      if (!discountId) return
      try {
        // trigger the mutation which calls POST /discount-module/discount-targets
        const data = await getDiscountTargets({ discount_id: discountId }).unwrap()
        if (!mounted) return
        // data shape expected:
        // { discount_id, products: [...], collections: [...], categories: [...], brands: [...] }
        setFetchedProducts(Array.isArray(data.products) ? data.products : [])
        setFetchedCollections(Array.isArray(data.collections) ? data.collections : [])
        setFetchedCategories(Array.isArray(data.categories) ? data.categories : [])
        setFetchedBrands(Array.isArray(data.brands) ? data.brands : [])
      } catch (err) {
        // keep silent in UI; you can log if desired
        // console.error('Failed to fetch discount targets', err)
      }
    }

    if (idNum) fetchTargets(idNum)
    return () => {
      mounted = false
    }
  }, [idNum, getDiscountTargets])

  // end date guard
  useEffect(() => {
    if (!hasEnd || !startDate || !endDate) return
    if (endDate < startDate) setEndDate(startDate)
  }, [startDate, endDate, hasEnd])

  /* ================= Derived summaries ================= */
  const valueSummary = useMemo(
    () => (valueType === 'percentage' ? `${Number(value || 0)}%` : `$${Number(value || 0).toFixed(2)}`),
    [valueType, value],
  )

  const gatewaySummary = useMemo(() => {
    if (!activeMethods.length) return 'None available'
    const selected = activeMethods.filter((m) => selectedMethodIds.includes(m.id)).map((m) => m.name)
    return selected.length ? selected.join(' • ') : 'None selected'
  }, [activeMethods, selectedMethodIds])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} • Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  /* ================= Validate & Diff/Save ================= */
  const validate = () => {
    const e = {}
    const t = title.trim()
    if (!t) e.title = 'Discount title is required.'
    if (t.length > 100) e.title = 'Title must be 100 characters or fewer.'

    if (selectedMethodIds.length === 0) e.payment_method = 'Select at least one payment method.'

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
    } else if (value === '' || Number(value) <= 0) {
      e.value = 'Amount must be greater than 0.'
    }

    if (enableAmounts) {
      if (maxPurchase === '' || Number(maxPurchase) < 0) e.maxPurchase = 'Minimum purchase is required.'
      if (valueType === 'percentage' && (maxDiscountAmount === '' || Number(maxDiscountAmount) <= 0)) {
        e.maxDiscountAmount = 'Maximum discount is required.'
      }
    }

    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Per-account uses is required.'

    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  const buildCurrentSnapshot = () => ({
    main_discount_type: 'order',
    order_discount_method: 'payment_method',
    payment_method: selectedMethodIds, // array of ids

    discount_title: title.trim(),
    discount_value_type: valueType,
    discount_value: Number(value),

    min_max_purchase_discount_limits: !!enableAmounts,
    min_purchase_amount: enableAmounts ? Number(maxPurchase) : null,
    max_discount_amount: enableAmounts && valueType === 'percentage' ? Number(maxDiscountAmount) : null,

    customer_eligibility: eligibility,
    is_guest_allowed: !!guestIncluded,

    unlimited_usage: !!limitPerCustomerOnce,
    usage_limit_per_account: limitPerAccount ? Number(perAccountUses) : null,

    start_date: makeISO(startDate, startTime),
    end_date: hasEnd ? makeISO(endDate, endTime) : null,

    status: 'active',
    discount_code: null,
  })

  const diffAgainst = (original = {}, current = {}) => {
    const changes = {}
    Object.keys(current).forEach((k) => {
      if (!isEqual(current[k], original[k])) changes[k] = current[k]
    })

    // Explicit clears for nullables
    if (!isEqual(original.end_date ?? null, current.end_date ?? null) && current.end_date === null) changes.end_date = null
    if (!isEqual(original.max_discount_amount ?? null, current.max_discount_amount ?? null) && current.max_discount_amount === null)
      changes.max_discount_amount = null
    if (!isEqual(original.usage_limit_per_account ?? null, current.usage_limit_per_account ?? null) && current.usage_limit_per_account === null)
      changes.usage_limit_per_account = null
    if (!isEqual(original.min_purchase_amount ?? null, current.min_purchase_amount ?? null) && current.min_purchase_amount === null)
      changes.min_purchase_amount = null

    return changes
  }

  const onSave = async () => {
    if (!validate()) return
    if (!Number.isFinite(idNum) || idNum <= 0) {
      await Swal.fire({ icon: 'error', title: 'Missing ID', text: 'Cannot update: discount_id not provided.' })
      return
    }

    const current = buildCurrentSnapshot()
    const original = {
      main_discount_type: activePrefill?.main_discount_type ?? 'order',
      order_discount_method: activePrefill?.order_discount_method ?? 'payment_method',
      payment_method: Array.isArray(activePrefill?.payment_method) ? activePrefill.payment_method.map(Number).filter(Number.isFinite) : [],

      discount_title: activePrefill?.discount_title ?? '',
      discount_value_type: activePrefill?.discount_value_type ?? 'percentage',
      discount_value: activePrefill?.discount_value != null ? Number(activePrefill.discount_value) : 0,

      min_max_purchase_discount_limits: !!activePrefill?.min_max_purchase_discount_limits,
      min_purchase_amount: activePrefill?.min_purchase_amount != null ? Number(activePrefill.min_purchase_amount) : null,
      max_discount_amount: activePrefill?.max_discount_amount != null ? Number(activePrefill.max_discount_amount) : null,

      customer_eligibility: activePrefill?.customer_eligibility ?? 'all',
      is_guest_allowed: !!activePrefill?.is_guest_allowed,

      unlimited_usage: !!activePrefill?.unlimited_usage,
      usage_limit_per_account: activePrefill?.usage_limit_per_account != null ? Number(activePrefill.usage_limit_per_account) : null,

      start_date: activePrefill?.start_date || null,
      end_date: activePrefill?.end_date || null,

      status: activePrefill?.status ?? 'active',
      discount_code: activePrefill?.discount_code ?? null,
    }

    const changes = diffAgainst(original, current)
    if (Object.keys(changes).length === 0) {
      await Swal.fire({ icon: 'info', title: 'No changes', text: 'No New field Changes to Update.' })
      return
    }

    const loading = Swal.fire({
      title: 'Saving…',
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      await updateOrderSelective({ id: idNum, changes }).unwrap()
      Swal.close()
      setDirty(false)

      // wait for success alert
      await Swal.fire({
        icon: 'success',
        title: 'Updated',
        text: 'Payment method discount updated successfully.',
        confirmButtonText: 'OK',
        allowOutsideClick: false,
      })

      // 🔥 trigger global event (same as addProductDiscount)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      Swal.close()
      await Swal.fire({
        icon: 'error',
        title: 'Update failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
      })
    } finally {
      loading.then(() => {})
    }
  }

  // Discard -> reset to prefilled values

  // Discard -> reset to prefilled values (SweetAlert)
  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      hydrateFrom(lastPrefillRef.current || activePrefill)

      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  const disabled = saving || dLoading || dFetching

  // ----- Helper to render pills for items -----
  const renderPills = (items, idKey = 'id', labelKey = 'name', placeholder = '—') => {
    if (!Array.isArray(items)) return placeholder
    if (items.length === 0) return placeholder
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={it[idKey] + '-' + (it[labelKey] ?? '')} className="pill">
            <span className="pill-label">{it[labelKey] ?? '—'}</span>
          </span>
        ))}
      </div>
    )
  }

  return (
    <>
      <Card className="soft-card">
        <Card.Header className="bg-white d-flex align-items-start justify-content-between">
          <div>
            <Card.Title className="mb-0">Payment Method (Edit)</Card.Title>
            <small className="text-muted">Edit discounts applied to selected payment gateways.</small>
          </div>
          {/* <Button
            variant="outline-secondary"
            className="rounded-pill d-inline-flex align-items-center gap-2 nowrap"
            onClick={() => {
              pendingActionRef.current = 'history'
              setShowPrompt(true)
            }}>
            <Icon icon="solar:arrow-left-linear" width={18} />
            Go Back
          </Button> */}
        </Card.Header>

        <Card.Body>
          {(dLoading || dFetching) && (
            <div className="d-flex align-items-center gap-2 mb-2">
              <Spinner animation="border" size="sm" />
              <small className="text-muted">Loading discount…</small>
            </div>
          )}
          {dError && <div className="text-danger small mb-2">Failed to load discount details.</div>}

          <Row className="g-3">
            {/* ---------- LEFT: Form ---------- */}
            <Col lg={8}>
              {/* Discount Title */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Title</span>
                </div>
                <div className="section-body">
                  <Form.Control
                    placeholder="e.g. 2% off for selected payment methods"
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value.slice(0, 100))
                      markDirty()
                    }}
                    required
                    disabled={disabled}
                  />
                  <div className="d-flex justify-content-between mt-1">
                    <small className="text-muted">{title.length}/100</small>
                    {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                  </div>
                </div>
              </section>

              {/* Applicable Payment Gateway */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Applicable Payment Gateway</span>
                </div>
                <div className="section-body">
                  {pmLoading && <div className="small text-muted">Loading payment methods…</div>}
                  {pmError && <div className="small text-danger">Failed to load payment methods.</div>}
                  {!pmLoading && !pmError && (
                    <>
                      {activeMethods.length === 0 ? (
                        <div className="small text-muted">No active payment methods.</div>
                      ) : (
                        <div className="d-flex flex-column gap-2">
                          {activeMethods.map((m) => (
                            <Form.Check
                              key={m.id}
                              type="checkbox"
                              id={`pm-${m.id}`}
                              checked={selectedMethodIds.includes(m.id)}
                              onChange={() => toggleMethod(m.id)}
                              label={m.name}
                              disabled={disabled}
                            />
                          ))}
                        </div>
                      )}
                    </>
                  )}
                  {errors.payment_method && <div className="text-danger small mt-2">{errors.payment_method}</div>}
                </div>
              </section>

              {/* Discount Value */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Value</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-perc"
                          name="val-type"
                          checked={valueType === 'percentage'}
                          onChange={() => {
                            setValueType('percentage')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Percentage</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-fixed"
                          name="val-type"
                          checked={valueType === 'fixed'}
                          onChange={() => {
                            setValueType('fixed')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <InputGroup>
                        {valueType === 'percentage' ? (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="1"
                              max="100"
                              step="1"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              disabled={disabled}
                            />
                          </>
                        ) : (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">{currency || '$'}</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="0.01"
                              step="0.01"
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              required
                              disabled={disabled}
                            />
                          </>
                        )}
                      </InputGroup>
                      {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Amount Limits */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Set Minimum Purchase Amount and Max Discount Amount</span>
                </div>
                <div className="section-body">
                  <Form.Check
                    className="mb-3"
                    type="checkbox"
                    id="enable-amounts"
                    checked={enableAmounts}
                    onChange={(e) => {
                      setEnableAmounts(e.target.checked)
                      markDirty()
                    }}
                    label="Set  Maximum  Purchase Amount and Max Discount Amount"
                    disabled={disabled}
                  />
                  <Row className="g-3">
                    <Col md={valueType === 'percentage' ? 6 : 7}>
                      <InputGroup>
                        <InputGroup.Text
                          className="fw-semibold nowrap"
                          style={{ fontSize: '12px', minWidth: '180px' }} // smaller label + more width for input
                        >
                          Minimum Purchase Amount {currency ? `(${currency})` : ''}
                        </InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0"
                          step="0.01"
                          value={maxPurchase}
                          onChange={(e) => {
                            setMaxPurchase(e.target.value)
                            markDirty()
                          }}
                          required={enableAmounts}
                          disabled={disabled}
                        />
                      </InputGroup>

                      {errors.maxPurchase && <div className="text-danger small mt-1 nowrap">{errors.maxPurchase}</div>}
                    </Col>

                    {valueType === 'percentage' && (
                      <Col md={6}>
                        <InputGroup>
                          <InputGroup.Text className="fw-semibold nowrap" style={{ fontSize: '12px', minWidth: '180px' }}>
                            Maximum Discount Amount {currency ? `(${currency})` : ''}
                          </InputGroup.Text>

                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={maxDiscountAmount}
                            onChange={(e) => {
                              setMaxDiscountAmount(e.target.value)
                              markDirty()
                            }}
                            required={enableAmounts}
                            disabled={disabled}
                          />
                        </InputGroup>

                        {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                      </Col>
                    )}
                  </Row>
                </div>
              </section>

              {/* Customer Eligibility */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Customer Eligibility</span>
                </div>
                <div className="section-body">
                  <Row className="g-2 align-items-center">
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-all"
                        checked={eligibility === 'all'}
                        onChange={() => {
                          setEligibility('all')
                          markDirty()
                        }}
                        label="All Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-new"
                        checked={eligibility === 'new'}
                        onChange={() => {
                          setEligibility('new')
                          markDirty()
                        }}
                        label="New Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-existing"
                        checked={eligibility === 'existing'}
                        onChange={() => {
                          setEligibility('existing')
                          markDirty()
                        }}
                        label="Existing Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="checkbox"
                        id="elig-guest"
                        checked={!!guestIncluded}
                        onChange={(e) => {
                          setGuestIncluded(e.target.checked)
                          markDirty()
                        }}
                        label="Guest Customers"
                        disabled={disabled}
                      />
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Usage Limit */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Usage Limit</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-customer"
                        checked={limitPerCustomerOnce}
                        onChange={(e) => {
                          setLimitPerCustomerOnce(e.target.checked)
                          markDirty()
                        }}
                        label="Unlimited Discount Usage"
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-account"
                        checked={limitPerAccount}
                        onChange={(e) => {
                          setLimitPerAccount(e.target.checked)
                          markDirty()
                        }}
                        label="Set Usage Limit Per Account"
                        disabled={disabled}
                      />
                      {limitPerAccount && (
                        <div className="mt-2" style={{ maxWidth: 220 }}>
                          <Form.Control
                            type="number"
                            min="1"
                            step="1"
                            required
                            value={perAccountUses}
                            onChange={(e) => {
                              setPerAccountUses(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                        </div>
                      )}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Active Period */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Active Period</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Date <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        required
                        min={todayISO()}
                        value={startDate}
                        onChange={(e) => {
                          setStartDate(e.target.value)
                          markDirty()
                        }}
                        disabled={disabled}
                      />
                      {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                    </Col>
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Time <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="time"
                        required
                        value={startTime}
                        onChange={(e) => {
                          setStartTime(e.target.value)
                          markDirty()
                        }}
                        disabled={disabled}
                      />
                      {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                    </Col>
                    <Col md={12}>
                      <Form.Check
                        id="has-end"
                        type="checkbox"
                        className="mt-2"
                        checked={hasEnd}
                        onChange={(e) => {
                          setHasEnd(e.target.checked)
                          markDirty()
                        }}
                        label="Set End Date"
                        disabled={disabled}
                      />
                    </Col>
                    {hasEnd && (
                      <>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Date <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="date"
                            required
                            min={startDate || todayISO()}
                            value={endDate}
                            onChange={(e) => {
                              setEndDate(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                        </Col>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Time <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="time"
                            required
                            value={endTime}
                            onChange={(e) => {
                              setEndTime(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                        </Col>
                      </>
                    )}
                  </Row>
                </div>
              </section>

              {/* Footer actions */}
              <div className="footer-actions">
                <Button variant="outline-secondary" onClick={onDiscard} disabled={disabled}>
                  Discard
                </Button>
                <Button onClick={onSave} disabled={disabled}>
                  {disabled ? (
                    <>
                      <Spinner animation="border" size="sm" className="me-2" /> Saving…
                    </>
                  ) : (
                    'Save'
                  )}
                </Button>
              </div>
            </Col>

            {/* ---------- RIGHT: Summary ---------- */}
            <Col lg={4}>
              <aside className="summary-card">
                <div className="sum-head">Discount Summary</div>
                <div className="sum-row">
                  <div className="sum-label">Title</div>
                  <div className="sum-value">{title || '—'}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Gateways</div>
                  <div className="sum-value">{gatewaySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Discount Value</div>
                  <div className="sum-value">{valueSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Eligibility</div>
                  <div className="sum-value">{eligibilitySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Usage Limits</div>
                  <div className="sum-value">{usageSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Amount Rules</div>
                  <div className="sum-value">
                    Min Purchase: {enableAmounts ? (maxPurchase === '' ? '—' : `${Number(maxPurchase).toLocaleString()} ${currency || 'LKR'}`) : '—'}
                    <br />
                    {valueType === 'percentage' ? (
                      <>
                        Max Discount:{' '}
                        {enableAmounts
                          ? maxDiscountAmount === ''
                            ? '—'
                            : `${Number(maxDiscountAmount).toLocaleString()} ${currency || 'LKR'}`
                          : '—'}
                      </>
                    ) : (
                      <>Max Discount: —</>
                    )}
                  </div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Active Period</div>
                  <div className="sum-value">{periodSummary}</div>
                </div>

                {/* ---------- NEW: Targets display ---------- */}
                {/* <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                  Targets
                  {targetsLoading && (
                    <span style={{ marginLeft: 8 }}>
                      <Spinner animation="border" size="sm" />
                    </span>
                  )}
                </div>

                <div className="sum-row">
                  <div className="sum-label">Products</div>
                  <div className="sum-value">{renderPills(fetchedProducts, 'id', 'title', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Collections</div>
                  <div className="sum-value">{renderPills(fetchedCollections, 'id', 'name', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Categories</div>
                  <div className="sum-value">{renderPills(fetchedCategories, 'id', 'name', '—')}</div>
                </div>

                <div className="sum-row">
                  <div className="sum-label">Brands</div>
                  <div className="sum-value">{renderPills(fetchedBrands, 'id', 'name', '—')}</div>
                </div> */}
              </aside>
            </Col>
          </Row>
        </Card.Body>

        {/* Styles */}
        <style jsx>{`
          .section + .section {
            margin-top: 16px;
          }
          .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            background: #f5f7fb;
          }
          .section-title {
            font-weight: 700;
            color: #111827;
          }
          .section-body {
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 0 0 12px 12px;
            background: #fff;
          }
          .stacked-choice {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 10px;
            padding: 10px 12px;
            background: #fff;
          }
          .footer-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 18px;
          }
          .summary-card {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            background: #fff;
            padding: 12px;
          }
          .sum-head {
            font-weight: 700;
            color: #111827;
            background: #f5f7fb;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 10px;
            padding: 10px 12px;
            margin-bottom: 10px;
          }
          .sum-row {
            display: grid;
            grid-template-columns: 170px 1fr;
            gap: 10px;
            padding: 8px 2px;
          }
          .sum-label {
            color: #6b7280;
            font-weight: 600;
          }
          .sum-value {
            color: #111827;
          }

          /* pills */
          .pills-wrap {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
          }
          .pill {
            display: inline-flex;
            align-items: center;
            padding: 6px 8px;
            border-radius: 999px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            background: #fafafa;
            font-size: 12px;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          .pill-label {
            display: inline-block;
            max-width: 160px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .targets-head {
            font-size: 13px;
          }
        `}</style>
      </Card>

      {/* Unsaved-changes modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
