'use client'

import { useMemo, useState, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'

import { Card, Row, Col, Button, Table, Dropdown, Form, Badge, Spinner, CardHeader, CardTitle } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import CreateProductDiscount from './CreateProductDiscount'
import OrderDiscountSelection from '@/app/(admin)/(sales_manager)/discounts/order_discount/OrderDiscountSelection'
import Pagination from '@/components/Pagination'

// ⬇️ RTK hooks
import {
  useFetchDiscountsTableQuery,
  useUpdateDiscountStatusMutation,
  useGetDiscountByIdQuery, // <-- added
  useDuplicateDiscountMutation, // ⬅️ NEW
} from '@/store/features/apiSlice'

// ⬇️ SweetAlert2
import Swal from 'sweetalert2'
const SKIP_CONFIRM = true
/* ----------------------------- Prefilled Editor ----------------------------- */
function PrefilledEditor({ id, onBack }) {
  const numericId = Number(id)

  // Fetch data FIRST (must be before using it)
  const { data, isLoading, error } = useGetDiscountByIdQuery(numericId, {
    skip: !numericId,
  })

  // Unwrap possible { success, data: {...} } or just {...}
  const payload = data && typeof data === 'object' && 'data' in data ? data.data : data

  // Early loading state
  if (isLoading) {
    return (
      <div className="d-flex align-items-center justify-content-center py-5">
        <Spinner animation="border" />
      </div>
    )
  }

  // Early error state
  if (error || !data) {
    return (
      <div className="py-5 text-center text-danger">
        <Icon icon="solar:danger-triangle-linear" width={24} className="mb-2 d-block mx-auto" />
        {error?.data?.error || 'Failed to load discount for editing.'}
      </div>
    )
  }

  // Safe field extraction
  const scope = String(payload?.main_discount_type || '').toLowerCase()
  const prodMethod = String(payload?.prod_discount_method || '').toLowerCase()
  const orderMethod = String(payload?.order_discount_method || '').toLowerCase()

  // Decide editor component based on your rules (UNCHANGED LOGIC)
  let Editor = null

  if (scope === 'product') {
    if (prodMethod === 'general') Editor = ProductGeneralEdit
    else if (prodMethod === 'buyxgety') Editor = ProductBxGyEdit
  } else if (scope === 'order') {
    if (orderMethod === 'payment_method') Editor = OrderPaymentMethodEdit
    else if (orderMethod === 'shipping') Editor = OrderShippingEdit
    else if (orderMethod === 'code') Editor = OrderCodeEdit
    else if (orderMethod === 'general' || !orderMethod) Editor = OrderGeneralEdit
  }

  return (
    <div className="discount-page">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h4 className="mb-0">Edit Discount #{payload?.discount_id}</h4>

        <Button variant="outline-secondary" className="d-inline-flex align-items-center" onClick={onBack}>
          <Icon icon="mdi:arrow-left" className="me-2" width={18} />
          Back to Discounts
        </Button>
      </div>

      {Editor ? (
        <Editor mode="edit" discountId={numericId} prefill={payload} />
      ) : (
        <Card className="p-4">
          <div className="text-muted">
            No matching editor found for this discount configuration.
            <br />
            <code>main_discount_type</code>: <strong>{scope || '—'}</strong>{' '}
            {scope === 'product' ? (
              <>
                • <code>prod_discount_method</code>: <strong>{prodMethod || '—'}</strong>
              </>
            ) : scope === 'order' ? (
              <>
                • <code>order_discount_method</code>: <strong>{orderMethod || '—'}</strong>
              </>
            ) : null}
          </div>
        </Card>
      )}
    </div>
  )
}

// PRODUCT editors
import ProductGeneralEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/product_discounts/GeneralDiscount'
import ProductBxGyEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/product_discounts/BuyXGetY'

// ORDER editors
import OrderGeneralEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/order_discounts/GeneralDiscount'
import OrderPaymentMethodEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/order_discounts/PaymentMethod'
import OrderShippingEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/order_discounts/ShippingDiscount'
import OrderCodeEdit from '@/app/(admin)/(sales_manager)/discounts/update_discounts/order_discounts/DiscountCode'

/* -------------------------------- Main Page -------------------------------- */
export default function DiscountModule() {
  // ---------------------------------------
  // Local UI state
  // ---------------------------------------
  const [activeTab, setActiveTab] = useState('All') // All | Active | Scheduled | Expired | Inactive
  const [typeTab, setTypeTab] = useState('All') // All | Order | Product
  const [query, setQuery] = useState('')
  // local input that's typed by the user; clicking Search copies this into `query`
  const [searchInput, setSearchInput] = useState(query)

  // run the client-side page search (also reset to first page)
  const doSearch = () => {
    setQuery((prev) => {
      const newQ = (searchInput || '').toString().trim()
      return newQ
    })
    setPage(1)
  }

  const [view, setView] = useState('list') // 'list' | 'chooser' | 'product' | 'order' | 'edit'
  const [page, setPage] = useState(1) // pagination page
  const [editId, setEditId] = useState(null) // current editing id
  const [limit, setLimit] = useState(10)
  // ⬅️ NEW: Keep track of newly created duplicate IDs to badge them "New" until refresh
  const [newBadges, setNewBadges] = useState({}) // { [id: string]: true }

  const tabs = ['All', 'Active', 'Scheduled', 'Expired', 'Inactive']
  const typeTabs = ['All', 'Order', 'Product']
  const PER_PAGE = 25

  // ---------------------------------------
  // Backend query params (respect “only two filters” rule)
  // ---------------------------------------
  const filters = useMemo(() => {
    const f = {}
    if (typeTab !== 'All') f.type = typeTab.toLowerCase() // 'order' | 'product'
    if (activeTab !== 'All') f.state = activeTab.toLowerCase() // 'active' | 'scheduled' | 'expired' | 'inactive'
    return f
  }, [typeTab, activeTab])

  const queryArgs = useMemo(
    () => ({
      page,
      per_page: PER_PAGE,
      filters,
    }),
    [page, filters],
  )

  // ---------------------------------------
  // Fetch data from backend
  // ---------------------------------------
  const { data, error, isLoading, isFetching, refetch } = useFetchDiscountsTableQuery(queryArgs)

  // API response shape: { ok, page, per_page, total, total_pages, filters, counts, data: rows[] }
  const apiRows = data?.data ?? []
  const totalPages = data?.total_pages ?? 1
  const totalEntries = data?.total || 0
  const countsFromApi = {
    all: data?.counts?.all ?? 0,
    active: data?.counts?.active ?? 0,
    scheduled: data?.counts?.scheduled ?? 0,
    expired: data?.counts?.expired ?? 0,
    inactive: data?.counts?.inactive ?? 0,
  }

  // ---------------------------------------
  // Transform rows for the table
  // ---------------------------------------
  const normalizedRows = useMemo(() => {
    return apiRows.map((r) => {
      const rawType = (r.main_discount_type || '').toString().toLowerCase()
      const category = rawType === 'order' ? 'Order Discount' : rawType === 'product' ? 'Product Discount' : 'N/A'

      // NEW: determine display method using either order_discount_method OR prod_discount_method
      const rawMethod = (r.order_discount_method || r.prod_discount_method || '').toString().trim().toLowerCase()

      let methodLabel = 'N/A'
      switch (rawMethod) {
        case 'buyxgety':
          methodLabel = 'Buy X Get Y'
          break
        case 'code':
          methodLabel = 'Discount Code'
          break
        case 'general':
          methodLabel = 'General Discount'
          break
        case 'payment_method':
          methodLabel = 'Payment Methods'
          break
        case 'shipping':
          methodLabel = 'Shipping Discount'
          break
        default:
          methodLabel = 'N/A'
      }

      const rawStatus = (r.status ?? '').toString().toLowerCase()
      const computedStatus =
        rawStatus === 'active' || rawStatus === 'true' || rawStatus === 't' || rawStatus === '1'
          ? 'Active'
          : rawStatus === 'scheduled'
            ? 'Scheduled'
            : rawStatus === 'expired'
              ? 'Expired'
              : 'Inactive'

      let valueType = r.discount_value_type
      if (!valueType) valueType = 'N/A'
      else {
        valueType = valueType
          .toString()
          .replace(/_/g, ' ')
          .replace(/\b\w/g, (m) => m.toUpperCase())
      }

      return {
        id: String(r.discount_id ?? ''), // keep as string for safe search match
        title: r.discount_title || 'N/A',
        category, // Order Discount / Product Discount / N/A
        status: computedStatus, // Active / Scheduled / Expired / Inactive
        method: methodLabel, // ← mapped, per your rules
        type: valueType, // Percentage / Fixed / N/A
        mainType: rawType, // order | product | ''
        rawValueType: (r.discount_value_type || '').toString().toLowerCase(), // percentage | fixed | ...
      }
    })
  }, [apiRows])

  // Client-side search on the fetched page (Discount ID + Title only)
  const filteredData = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return normalizedRows
    return normalizedRows.filter((r) => r.id.toString().toLowerCase().includes(q) || r.title.toLowerCase().includes(q))
  }, [normalizedRows, query])

  // Helpers
  const StatusBadge = ({ status }) => {
    const m = { Active: 'success', Scheduled: 'info', Expired: 'secondary', Inactive: 'secondary' }
    return (
      <Badge bg={m[status] || 'secondary'} className="rounded-pill fw-medium">
        {status || 'N/A'}
      </Badge>
    )
  }

  // UPDATED: color map for your new method labels
  const MethodBadge = ({ method }) => {
    const colorMap = {
      'Buy X Get Y': 'primary', // bg-primary, text-white
      'Discount Code': 'danger', // bg-warning, text-dark (highlighted)
      'General Discount': 'secondary', // bg-secondary, text-white
      'Payment Methods': 'warning', // bg-info, text-dark
      'Shipping Discount': 'success', // bg-success, text-white
      'N/A': 'danger', // bg-danger, text-white
    }
    return (
      <Badge bg={colorMap[method] || 'secondary'} className="rounded-pill fw-medium">
        {method || 'N/A'}
      </Badge>
    )
  }

  const TypeChip = ({ type }) => {
    const val = type || 'N/A'
    const tl = val.toString().toLowerCase()
    const tone = tl.includes('percent') ? 'purple' : tl.includes('fixed') ? 'teal' : 'orange'
    return <span className={`type-chip type-${tone}`}>{val}</span>
  }

  useEffect(() => {
    const onSaved = () => {
      setView('list')
      // 🔄 refresh discounts table immediately
      if (typeof refetch === 'function') {
        refetch()
      }
    }

    if (typeof window !== 'undefined') {
      window.addEventListener('discount:saved', onSaved)
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('discount:saved', onSaved)
      }
    }
  }, [refetch])

  const filtersLabel = useMemo(() => {
    const bits = []
    if (typeTab !== 'All') bits.push(`type: ${typeTab}`)
    if (activeTab !== 'All') bits.push(`state: ${activeTab}`)
    return bits.join(', ')
  }, [typeTab, activeTab])

  const showNoDiscountsAdded = !isLoading && !isFetching && countsFromApi.all === 0 && query.trim() === '' && activeTab === 'All' && typeTab === 'All'

  const showNoRecordsForFilters = !isLoading && !isFetching && !showNoDiscountsAdded && filteredData.length === 0

  // Pagination handlers
  const goPrev = () => setPage((p) => Math.max(1, p - 1))
  const goNext = () => setPage((p) => Math.min(totalPages || 1, p + 1))

  // Reset page when filters change
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useMemo(() => setPage(1), [activeTab, typeTab])

  /* ------------------------------ View Switching ------------------------------ */

  if (view === 'chooser') {
    return (
      <div className="discount-page">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h4 className="mb-0">Select Discount Type</h4>
          <Button variant="outline-secondary" className="d-inline-flex align-items-center" onClick={() => setView('list')}>
            <Icon icon="mdi:arrow-left" className="me-2" width={18} />
            Back to Discounts
          </Button>
        </div>

        <Card
          className="p-3"
          style={{
            borderRadius: '16px',
            border: '1px solid rgba(0,0,0,0.06)',
            boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
            background: 'linear-gradient(180deg, #fff 0%, #f9fafb 100%)',
          }}>
          <div className="d-flex flex-direction-column gap-3" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {/* Product Discount */}
            <button
              type="button"
              onClick={() => setView('product')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '14px',
                borderRadius: '14px',
                border: '1px solid rgba(0,0,0,0.08)',
                background: '#fff',
                padding: '18px 16px',
                textAlign: 'left',
                transition: 'all 0.2s ease',
                cursor: 'pointer',
                boxShadow: '0 0 0 rgba(0,0,0,0)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.border = '1px solid #4f46e5'
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(79,70,229,0.18)'
                e.currentTarget.style.transform = 'translateY(-3px)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.border = '1px solid rgba(0,0,0,0.08)'
                e.currentTarget.style.boxShadow = '0 0 0 rgba(0,0,0,0)'
                e.currentTarget.style.transform = 'translateY(0)'
              }}>
              <div
                className="chooser-icon"
                style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: '14px',
                  background: 'linear-gradient(135deg, #ede9fe, #c7d2fe)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Icon icon="ph:gift-duotone" width={30} color="#4f46e5" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: '#111827', fontSize: '1rem', marginBottom: '4px' }}>Product Discount</div>
                <div style={{ color: '#6b7280', fontSize: '0.9rem' }}>Apply discounts to specific products, collections, or variants.</div>
              </div>
              <Icon icon="mdi:chevron-right" width={22} color="#9ca3af" />
            </button>

            {/* Order Discount */}
            <button
              type="button"
              onClick={() => setView('order')}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '14px',
                borderRadius: '14px',
                border: '1px solid rgba(0,0,0,0.08)',
                background: '#fff',
                padding: '18px 16px',
                textAlign: 'left',
                transition: 'all 0.2s ease',
                cursor: 'pointer',
                boxShadow: '0 0 0 rgba(0,0,0,0)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.border = '1px solid #059669'
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(5,150,105,0.18)'
                e.currentTarget.style.transform = 'translateY(-3px)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.border = '1px solid rgba(0,0,0,0.08)'
                e.currentTarget.style.boxShadow = '0 0 0 rgba(0,0,0,0)'
                e.currentTarget.style.transform = 'translateY(0)'
              }}>
              <div
                className="chooser-icon"
                style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: '14px',
                  background: 'linear-gradient(135deg, #d1fae5, #a7f3d0)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Icon icon="ph:shopping-cart-duotone" width={30} color="#047857" />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: '#111827', fontSize: '1rem', marginBottom: '4px' }}>Order Discount</div>
                <div style={{ color: '#6b7280', fontSize: '0.9rem' }}>Discounts that apply to the whole order (code or automatic).</div>
              </div>
              <Icon icon="mdi:chevron-right" width={22} color="#9ca3af" />
            </button>
          </div>
        </Card>
      </div>
    )
  }

  if (view === 'product') {
    return (
      <div className="discount-page">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h4 className="mb-0">Create Discount</h4>
          <Button variant="outline-secondary" className="d-inline-flex align-items-center" onClick={() => setView('list')}>
            <Icon icon="mdi:arrow-left" className="me-2" width={18} />
            Back to Discounts
          </Button>
        </div>
        <CreateProductDiscount />
      </div>
    )
  }

  if (view === 'order') {
    return (
      <div className="discount-page">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h4 className="mb-0">Create Discount</h4>
          <Button variant="outline-secondary" className="d-inline-flex align-items-center" onClick={() => setView('list')}>
            <Icon icon="mdi:arrow-left" className="me-2" width={18} />
            Back to Discounts
          </Button>
        </div>
        <OrderDiscountSelection />
      </div>
    )
  }

  if (view === 'edit' && editId) {
    return <PrefilledEditor id={editId} onBack={() => setView('list')} />
  }

  // ---------------------------------------
  // ✅ Default (Discount List view)
  // ---------------------------------------
  return (
    <div className="discount-page">
      <CardHeader>
        <Row className="align-items-center mb-3">
          <Col>
            <div
              className="d-flex"
              style={{
                backgroundColor: status === 'receive' ? '#eab02b' : status === 'transfer' ? '#003366' : status === 'return' ? '#8B0000' : '#e5e8ed',
                color: ['receive', 'transfer', 'return'].includes(status) ? 'white' : 'black',
                borderRadius: '17px',
                padding: '10px 16px',
                alignItems: 'center', // ⭐ ensures perfect vertical alignment
                gap: 16,
              }}>
              {/* ---------- LEFT: TITLE ---------- */}
              <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                <CardTitle
                  as="h4"
                  className="mb-0"
                  style={{
                    fontSize: '1.1rem',
                    margin: 0,
                    display: 'flex',
                    alignItems: 'center',
                  }}>
                  Discount List
                </CardTitle>
              </div>

              {/* ---------- CENTER: ORIGINAL SEARCH BAR ---------- */}
              <div
                style={{
                  flex: 1,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center', // ⭐ vertical alignment fix
                }}>
                <Card
                  className="p-0 mb-0"
                  style={{
                    border: '1px solid rgba(0,0,0,0.08)',
                    borderRadius: '10px',
                    background: '#ffffff',
                    overflow: 'hidden',
                    width: '100%',
                    maxWidth: 520,
                    boxShadow: '0 2px 6px rgba(0,0,0,0.05)',
                    display: 'flex',
                    alignItems: 'center', // ⭐ keeps internal height centered
                  }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center', // ⭐ centers search vertically
                      height: 35, // equal to button height & title height
                      width: '100%',
                    }}>
                    {/* Search Field (unchanged) */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        padding: '6px 10px',
                        flex: 1,
                      }}>
                      <Icon icon="solar:magnifier-linear" width={14} />

                      <Form.Control
                        size="sm"
                        type="search"
                        placeholder="Search discounts by ID or title"
                        value={searchInput}
                        onChange={(e) => setSearchInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            doSearch()
                          }
                        }}
                        style={{
                          border: 'none',
                          boxShadow: 'none',
                          height: '26px',
                          padding: 0,
                          fontSize: '0.9rem',
                          background: 'transparent',
                        }}
                      />
                    </div>

                    {/* Search Button (unchanged) */}
                    <Button
                      size="sm"
                      onClick={doSearch}
                      style={{
                        backgroundColor: '#059669',
                        borderColor: '#059669',
                        color: 'white',
                        fontWeight: 600,
                        borderRadius: '0px',
                        padding: '0 18px',
                        height: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = '#047857'
                        e.currentTarget.style.borderColor = '#047857'
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = '#059669'
                        e.currentTarget.style.borderColor = '#059669'
                      }}>
                      <Icon icon="solar:magnifier-linear" width={15} />
                      Search
                    </Button>
                  </div>
                </Card>
              </div>

              {/* ---------- RIGHT: ADD DISCOUNT ---------- */}
              <div
                style={{
                  flexShrink: 0,
                  display: 'flex',
                  alignItems: 'center', // ⭐ forces same baseline
                }}>
                <Button
                  variant="primary"
                  className="btn-raised d-inline-flex align-items-center"
                  onClick={() => setView('chooser')}
                  style={{
                    padding: '8px 14px',
                    borderRadius: 10,
                  }}>
                  <Icon icon="solar:tag-price-bold-duotone" className="me-1 mt-1" width={15} />
                  Add Discount
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </CardHeader>

      {/* Tabs + Type Filter */}
      <div className="d-flex flex-wrap align-items-center justify-content-between mb-3">
        {/* State tabs with API counts on the left */}
        <div className="tabs mb-2 mb-md-0">
          {tabs.map((t) => {
            const active = activeTab === t
            const count =
              t === 'All'
                ? countsFromApi.all
                : t === 'Active'
                  ? countsFromApi.active
                  : t === 'Scheduled'
                    ? countsFromApi.scheduled
                    : t === 'Expired'
                      ? countsFromApi.expired
                      : /* Inactive */ countsFromApi.inactive
            return (
              <button
                key={t}
                className={`tab-btn ${active ? 'active' : ''}`}
                onClick={() => setActiveTab(t)}
                type="button"
                disabled={isFetching && activeTab !== t}>
                {t}
                <span className="count">{count}</span>
              </button>
            )
          })}
        </div>

        {/* Type selector (right side) */}
        <div className="tabs">
          {typeTabs.map((tt) => {
            const active = typeTab === tt
            return (
              <button
                key={tt}
                className={`tab-btn ${active ? 'active' : ''}`}
                onClick={() => setTypeTab(tt)}
                type="button"
                disabled={isFetching && typeTab !== tt}
                title="Filter by discount type">
                {tt}
              </button>
            )
          })}
        </div>
      </div>

      {/* List Card */}
      <Card className="list-card position-relative">
        {(isLoading || isFetching) && (
          <div
            className="position-absolute w-100 h-100 d-flex align-items-center justify-content-center"
            style={{ background: 'rgba(255,255,255,0.6)', backdropFilter: 'blur(2px)', zIndex: 2 }}>
            <Spinner animation="border" />
          </div>
        )}

        <Card.Body className="p-0 mt-0">
          <div className="table-responsive position-relative">
            <Table hover borderless className="mb-0 align-middle">
              <thead>
                <tr className="table-head">
                  <th style={{ width: 90 }}>ID</th>
                  <th style={{ width: '32%' }}>Title</th>
                  <th>Discount Category</th>
                  <th>Status</th>
                  <th>Method</th>
                  <th>Type</th>
                  <th style={{ width: 72 }} className="text-end">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {error && (
                  <tr>
                    <td colSpan={7} className="py-5 text-center text-danger">
                      <Icon icon="solar:danger-triangle-linear" width={22} className="mb-2 d-block mx-auto" />
                      {(error?.data?.error || error?.error || 'Failed to fetch discounts').toString()}
                    </td>
                  </tr>
                )}

                {!error && showNoDiscountsAdded && (
                  <tr>
                    <td colSpan={7} className="py-5 text-center text-muted">
                      <Icon icon="solar:tag-price-linear" width={28} className="mb-2 d-block mx-auto" />
                      No Discounts Added.
                    </td>
                  </tr>
                )}

                {!error && showNoRecordsForFilters && (
                  <tr>
                    <td colSpan={7} className="py-5 text-center text-muted">
                      <Icon icon="solar:tag-price-linear" width={28} className="mb-2 d-block mx-auto" />
                      {filtersLabel ? (
                        <>
                          No Discounts Found for <strong>{filtersLabel}</strong>.
                        </>
                      ) : (
                        'No Discounts Found.'
                      )}
                    </td>
                  </tr>
                )}

                {!error &&
                  filteredData.map((row) => {
                    const isCode = row.order_discount_method === 'code'
                    const methodWord = isCode ? 'Code-based' : row.method === 'N/A' ? 'N/A' : 'Automatic'
                    const typeWord = (row.rawValueType || row.type || '').toString().toLowerCase()
                    const scopeWord = (row.category || 'N/A').toString().toLowerCase()
                    const statusWord = (row.status || 'N/A').toString()
                    const phrase =
                      row.method === 'N/A' && row.type === 'N/A' && scopeWord === 'n/a'
                        ? 'N/A'
                        : `${methodWord} ${typeWord || ''} ${scopeWord || ''}`.replace(/\s+/g, ' ').trim() + (statusWord ? ` • ${statusWord}` : '')

                    const isNew = !!newBadges[row.id]

                    return (
                      <tr key={row.id || Math.random()} className="row-hover">
                        <td className="fw-semibold">{row.id || 'N/A'}</td>

                        <td>
                          <div className="d-flex flex-column">
                            <span className="fw-semibold d-flex align-items-center" style={{ color: isCode ? '#0d6efd' : 'inherit' }}>
                              {isCode ? row.discount_code : row.title || 'N/A'}
                              {isNew && (
                                <Badge bg="warning" pill className="ms-2 badge-new">
                                  New
                                </Badge>
                              )}
                            </span>
                            <small className="text-muted">{phrase || 'N/A'}</small>
                          </div>
                        </td>

                        <td className="text-body">{row.category || 'N/A'}</td>
                        <td>
                          <StatusBadge status={row.status || 'N/A'} />
                        </td>
                        <td>
                          <MethodBadge method={row.method || 'N/A'} />
                        </td>
                        <td>
                          <TypeChip type={row.type || 'N/A'} />
                        </td>
                        <td className="text-end pe-3">
                          <RowActions
                            id={row.id}
                            status={row.status}
                            mainType={row.mainType}
                            onEdit={(id) => {
                              setEditId(id)
                              setView('edit')
                            }}
                            onDone={refetch}
                            onDuplicated={(newId) => {
                              if (!newId) return
                              setNewBadges((prev) => ({ ...prev, [String(newId)]: true }))
                            }}
                          />
                        </td>
                      </tr>
                    )
                  })}
              </tbody>
            </Table>

            {/* ================= NEW PAGINATION ================= */}
            {totalPages > 1 && (
              <Pagination
                currentPage={page}
                totalPages={totalPages}
                totalEntries={totalEntries}
                limit={limit}
                onPageChange={(newPage) => setPage(newPage)}
                onLimitChange={(newLimit) => {
                  setLimit(newLimit)
                  setPage(1)
                }}
                showingFrom={data.length === 0 ? 0 : (page - 1) * limit + 1}
                showingTo={data.length === 0 ? 0 : (page - 1) * limit + data.length}
              />
            )}
          </div>
        </Card.Body>
      </Card>

      {/* Styles */}
      <style jsx>{`
        .discount-page {
          --card-radius: 16px;
          --border: 1px solid rgba(0, 0, 0, 0.06);
          --shadow: 0 1px 0 rgba(22, 29, 37, 0.05), 0 8px 24px rgba(22, 29, 37, 0.06);
        }
        .btn-raised {
          border-radius: 10px;
          padding: 0.55rem 0.9rem;
          box-shadow: 0 2px 0 rgba(0, 0, 0, 0.06);
        }
        .search-card {
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          max-width: 3150px;
        }
        .search-inline {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 10px;
          height: 36px;
        }
        :global(.search-input.form-control) {
          border: none !important;
          box-shadow: none !important;
          height: 28px;
          padding: 0;
          font-size: 0.9rem;
        }

        .tabs {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }
        .tab-btn {
          background: #fff;
          border: var(--border);
          border-radius: 999px;
          padding: 6px 12px;
          font-weight: 600;
          font-size: 0.9rem;
          color: #111827;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          transition: all 0.15s ease.;
        }
        .tab-btn:hover {
          transform: translateY(-1px);
        }
        .tab-btn.active {
          background: #111827;
          color: #fff;
          border-color: #111827;
        }
        .tab-btn .count {
          background: rgba(0, 0, 0, 0.06);
          border-radius: 999px;
          padding: 2px 8px;
          font-size: 0.75rem;
          font-weight: 700;
        }
        .tab-btn.active .count {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
        }

        .list-card {
          border: var(--border);
          border-radius: var(--card-radius);
          box-shadow: var(--shadow);
          overflow: hidden;
          position: relative;
          min-height: 220px;
        }
        .table-head th {
          background: #fafafa;
          text-transform: none;
          font-weight: 700;
          color: #111827;
          font-size: 0.9rem;
          border-bottom: var(--border);
        }
        .row-hover td {
          border-top: var(--border);
        }
        .row-hover:hover {
          background: #fbfbfd;
        }

        .type-chip {
          font-size: 0.82rem;
          font-weight: 700;
          padding: 4px 10px;
          border-radius: 999px;
          border: 1px solid transparent;
          display: inline-block;
          line-height: 1;
        }
        .type-purple {
          background: #f5f3ff;
          color: #4c1d95;
          border-color: #e9e5ff;
        }
        .type-teal {
          background: #ecfeff;
          color: #115e59;
          border-color: #d6fbfd;
        }
        .type-orange {
          background: #fff7ed;
          color: #9a3412;
          border-color: #ffecd5;
        }
        .badge-new {
          font-size: 0.65rem;
          font-weight: 800;
          letter-spacing: 0.2px;
        }
      `}</style>
    </div>
  )
}
function RowActions({ id, status, mainType, onEdit, onDone, onDuplicated }) {
  const isActive = (status || '').toLowerCase() === 'active'
  const actionLabel = isActive ? 'Deactivate' : 'Activate'
  const actionIcon = isActive ? 'solar:shield-cross-line-duotone' : 'solar:shield-check-line-duotone'

  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState({ top: 0, left: 0 })

  const btnRef = useRef(null)
  const menuRef = useRef(null)

  const [updateStatus, { isLoading: isMutating }] = useUpdateDiscountStatusMutation()
  const [duplicateDiscount, { isLoading: isDuping }] = useDuplicateDiscountMutation()

  // -------------------------------
  // Position calculation
  // -------------------------------
  const updatePosition = () => {
    if (!btnRef.current) return
    const rect = btnRef.current.getBoundingClientRect()

    setPos({
      top: rect.bottom + 6,
      left: rect.right - 180, // menu width
    })
  }

  const openMenu = () => {
    updatePosition()
    setOpen((v) => !v)
  }

  // -------------------------------
  // Close on outside click / scroll
  // -------------------------------
  useEffect(() => {
    if (!open) return

    const handleClickAway = (e) => {
      if (btnRef.current?.contains(e.target) || menuRef.current?.contains(e.target)) {
        return
      }
      setOpen(false)
    }

    const handleScroll = () => updatePosition()
    const handleResize = () => updatePosition()

    document.addEventListener('mousedown', handleClickAway)
    window.addEventListener('scroll', handleScroll, true)
    window.addEventListener('resize', handleResize)

    return () => {
      document.removeEventListener('mousedown', handleClickAway)
      window.removeEventListener('scroll', handleScroll, true)
      window.removeEventListener('resize', handleResize)
    }
  }, [open])

  // -------------------------------
  // Actions
  // -------------------------------
  const handleToggle = async () => {
    const discount_id = Number(id)
    if (!discount_id) return

    await updateStatus({
      discount_id,
      status: isActive ? 'inactive' : 'active',
    }).unwrap()

    onDone?.()
    setOpen(false)
  }

  const handleDuplicate = async () => {
    const discount_id = Number(id)
    if (!discount_id) return

    const res = await duplicateDiscount({ discount_id }).unwrap()
    const newId = res?.new_id ?? null

    onDuplicated?.(newId)
    onDone?.()
    setOpen(false)
  }

  // -------------------------------
  // Render
  // -------------------------------
  return (
    <>
      {/* Toggle button — EXACT SAME LOOK */}
      <button ref={btnRef} onClick={openMenu} className="btn btn-light btn-sm border-0" style={{ padding: '4px 8px' }}>
        <Icon icon="solar:menu-dots-bold" width={18} />
      </button>

      {/* Floating menu (portal) */}
      {open &&
        createPortal(
          <div
            ref={menuRef}
            className="dropdown-menu show"
            style={{
              position: 'fixed',
              top: pos.top,
              left: pos.left,
              zIndex: 999999,
              minWidth: 180,
            }}>
            <button
              className="dropdown-item d-flex align-items-center gap-2"
              onClick={() => {
                onEdit?.(id)
                setOpen(false)
              }}>
              <Icon icon="solar:pen-2-line-duotone" width={16} />
              Edit
            </button>

            {isActive && (
              <button className="dropdown-item d-flex align-items-center gap-2" disabled={isDuping} onClick={handleDuplicate}>
                <Icon icon="solar:copy-line-duotone" width={16} />
                {isDuping ? 'Duplicating…' : 'Duplicate'}
              </button>
            )}

            <div className="dropdown-divider" />

            <button className="dropdown-item d-flex align-items-center gap-2" disabled={isMutating} onClick={handleToggle}>
              <Icon icon={actionIcon} width={16} />
              {actionLabel}
            </button>
          </div>,
          document.body,
        )}
    </>
  )
}
