// 'use client'

// import { useMemo, useRef, useState } from 'react'
// import { Card, Row, Col, Form, Button, Spinner, InputGroup } from 'react-bootstrap'
// import { Icon } from '@iconify/react'

// export default function DiscountCode({ onDirty }) {
//   // ----- Core form state -----
//   const [code, setCode] = useState('WELCOME10') // max 10 chars
//   const [valueType, setValueType] = useState('percentage') // 'percentage' | 'fixed'
//   const [value, setValue] = useState(10)

//   // Customer eligibility (same style as BXGY)
//   const [eligibility, setEligibility] = useState('all') // 'all' | 'new' | 'existing'
//   const [guestIncluded, setGuestIncluded] = useState(false)
//   const guestDisabled = eligibility === 'all'
//   const guestChecked = guestDisabled ? true : guestIncluded

//   // Usage limit
//   const [limitTotalUses, setLimitTotalUses] = useState(true)
//   const [totalUses, setTotalUses] = useState(200)
//   const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(false)
//   const [limitPerAccount, setLimitPerAccount] = useState(true)
//   const [perAccountUses, setPerAccountUses] = useState(2)

//   // Amount rules
//   const [minPurchase, setMinPurchase] = useState('')
//   const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

//   // Active period
//   const [startDate, setStartDate] = useState('')
//   const [startTime, setStartTime] = useState('')
//   const [hasEnd, setHasEnd] = useState(false)
//   const [endDate, setEndDate] = useState('')
//   const [endTime, setEndTime] = useState('')

//   // Actions / validation
//   const [errors, setErrors] = useState({})
//   const [saving, setSaving] = useState(false)

//   // --- Derived summary bits ---
//   const valueSummary = useMemo(() => {
//     if (valueType === 'percentage') return `${Number(value || 0)}%`
//     return `$${Number(value || 0).toFixed(2)}`
//   }, [valueType, value])

//   const eligibilitySummary = useMemo(() => {
//     const base =
//       eligibility === 'all'
//         ? 'All customers'
//         : eligibility === 'new'
//         ? 'New customers'
//         : 'Existing customers'
//     return guestChecked ? `${base} + Guests` : base
//   }, [eligibility, guestChecked])

//   const usageSummary = useMemo(() => {
//     const parts = []
//     if (limitTotalUses) parts.push(`Total uses: ${totalUses || 0}`)
//     if (limitPerCustomerOnce) parts.push('One use per customer')
//     if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
//     return parts.length ? parts.join(' • ') : 'No limits'
//   }, [limitTotalUses, totalUses, limitPerCustomerOnce, limitPerAccount, perAccountUses])

//   const periodSummary = useMemo(() => {
//     if (!startDate || !startTime) return 'Start date/time required'
//     const start = `${startDate} ${startTime}`
//     if (!hasEnd) return `${start} → (no end)`
//     if (!endDate || !endTime) return `${start} → (end date/time required)`
//     return `${start} → ${endDate} ${endTime}`
//   }, [startDate, startTime, hasEnd, endDate, endTime])

//   // --- Validation ---
//   const validate = () => {
//     const e = {}
//     if (!code.trim()) e.code = 'Discount code is required.'
//     if (code.trim().length > 10) e.code = 'Code must be 10 characters or fewer.'
//     if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
//     if (valueType === 'percentage') {
//       if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
//     } else {
//       if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
//     }
//     if (limitTotalUses && (!totalUses || Number(totalUses) < 1)) e.totalUses = 'Total uses is required.'
//     if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Usage per account is required.'
//     if (!startDate) e.startDate = 'Start date is required.'
//     if (!startTime) e.startTime = 'Start time is required.'
//     if (hasEnd) {
//       if (!endDate) e.endDate = 'End date is required.'
//       if (!endTime) e.endTime = 'End time is required.'
//     }
//     if (minPurchase !== '' && Number(minPurchase) < 0) e.minPurchase = 'Cannot be negative.'
//     if (maxDiscountAmount !== '' && Number(maxDiscountAmount) < 0) e.maxDiscountAmount = 'Cannot be negative.'
//     setErrors(e)
//     return Object.keys(e).length === 0
//   }

//   const onSave = () => {
//     if (!validate()) return
//     setSaving(true)
//     // TODO: submit to API
//     setTimeout(() => setSaving(false), 900)
//   }

//   // --- Handlers ---
//   const handleCodeInput = (v) => {
//     // Uppercase, strip spaces, limit 10, alnum + - _
//     const cleaned = v.toUpperCase().replace(/\s+/g, '').replace(/[^A-Z0-9_-]/g, '').slice(0, 10)
//     setCode(cleaned)
//     onDirty?.()
//   }

//   const generateCode = () => {
//     const c = randomCode(10)
//     setCode(c)
//     onDirty?.()
//   }

//   return (
//     <Card className="soft-card">
//       <Card.Header className="bg-white d-flex align-items-start justify-content-between">
//         <div>
//           <Card.Title className="mb-0">Discount Code</Card.Title>
//           <small className="text-muted">Customers must enter a code at checkout.</small>
//         </div>
//         <Button
//           variant="outline-secondary"
//           className="rounded-pill d-inline-flex align-items-center gap-2 nowrap"
//           onClick={() => history.back()}
//         >
//           <Icon icon="solar:arrow-left-linear" width={18} />
//           Go Back
//         </Button>
//       </Card.Header>

//       <Card.Body>
//         <Row className="g-3">
//           {/* ---------- LEFT: Form ---------- */}
//           <Col lg={8}>
//             {/* Code */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Discount Code</span>
//                 <Button size="sm" variant="link" className="p-0 fw-semibold" onClick={generateCode}>
//                   Generate Random Code
//                 </Button>
//               </div>
//               <div className="section-body">
//                 <InputGroup>
//                   <InputGroup.Text className="fw-semibold">Code</InputGroup.Text>
//                   <Form.Control
//                     value={code}
//                     required
//                     maxLength={10}
//                     onChange={(e) => handleCodeInput(e.target.value)}
//                   />
//                 </InputGroup>
//                 <div className="d-flex justify-content-between mt-1">
//                   <small className="text-muted">{code.length}/10</small>
//                   {errors.code && <small className="text-danger nowrap">{errors.code}</small>}
//                 </div>
//               </div>
//             </section>

//             {/* Discount Value */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Discount Value</span>
//               </div>
//               <div className="section-body">
//                 <Row className="g-3">
//                   <Col md={4}>
//                     <div className="stacked-choice">
//                       <Form.Check
//                         type="radio"
//                         id="val-type-perc"
//                         name="val-type"
//                         checked={valueType === 'percentage'}
//                         onChange={() => { setValueType('percentage'); onDirty?.() }}
//                         label={<span className="fw-semibold nowrap">Percentage</span>}
//                         required
//                       />
//                     </div>
//                   </Col>
//                   <Col md={4}>
//                     <div className="stacked-choice">
//                       <Form.Check
//                         type="radio"
//                         id="val-type-fixed"
//                         name="val-type"
//                         checked={valueType === 'fixed'}
//                         onChange={() => { setValueType('fixed'); onDirty?.() }}
//                         label={<span className="fw-semibold nowrap">Fixed Amount</span>}
//                         required
//                       />
//                     </div>
//                   </Col>
//                   <Col md={4}>
//                     <InputGroup>
//                       {valueType === 'percentage' ? (
//                         <>
//                           <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
//                           <Form.Control
//                             type="number" min="1" max="100" step="1" required
//                             value={value}
//                             onChange={(e) => { setValue(Number(e.target.value || 0)); onDirty?.() }}
//                           />
//                         </>
//                       ) : (
//                         <>
//                           <InputGroup.Text className="fw-semibold nowrap">$</InputGroup.Text>
//                           <Form.Control
//                             type="number" min="0.01" step="0.01" required
//                             value={value}
//                             onChange={(e) => { setValue(Number(e.target.value || 0)); onDirty?.() }}
//                           />
//                         </>
//                       )}
//                     </InputGroup>
//                     {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
//                   </Col>
//                 </Row>
//               </div>
//             </section>

//             {/* Customer Eligibility */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Customer Eligibility</span>
//               </div>
//               <div className="section-body">
//                 <Row className="g-2 align-items-center">
//                   <Col md={3}>
//                     <Form.Check
//                       type="radio" name="elig"
//                       id="elig-all"
//                       checked={eligibility === 'all'}
//                       onChange={() => { setEligibility('all'); onDirty?.() }}
//                       label="All Customers"
//                       required
//                     />
//                   </Col>
//                   <Col md={3}>
//                     <Form.Check
//                       type="radio" name="elig"
//                       id="elig-new"
//                       checked={eligibility === 'new'}
//                       onChange={() => { setEligibility('new'); onDirty?.() }}
//                       label="New Customers"
//                       required
//                     />
//                   </Col>
//                   <Col md={3}>
//                     <Form.Check
//                       type="radio" name="elig"
//                       id="elig-existing"
//                       checked={eligibility === 'existing'}
//                       onChange={() => { setEligibility('existing'); onDirty?.() }}
//                       label="Existing Customers"
//                       required
//                     />
//                   </Col>
//                   <Col md={3}>
//                     <Form.Check
//                       type="checkbox"
//                       id="elig-guest"
//                       checked={guestChecked}
//                       disabled={guestDisabled}
//                       onChange={(e) => { setGuestIncluded(e.target.checked); onDirty?.() }}
//                       label="Guest Customers"
//                     />
//                   </Col>
//                 </Row>
//               </div>
//             </section>

//             {/* Usage Limit */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Usage Limit</span>
//               </div>
//               <div className="section-body">
//                 <Row className="g-3">
//                   <Col md={6}>
//                     <Form.Check
//                       type="checkbox"
//                       id="limit-total"
//                       checked={limitTotalUses}
//                       onChange={(e) => { setLimitTotalUses(e.target.checked); onDirty?.() }}
//                       label="Limit number of times this discount can be used in total"
//                     />
//                     {limitTotalUses && (
//                       <div className="mt-2" style={{ maxWidth: 220 }}>
//                         <Form.Control
//                           type="number" min="1" step="1" required
//                           value={totalUses}
//                           onChange={(e) => { setTotalUses(Number(e.target.value || 1)); onDirty?.() }}
//                         />
//                         {errors.totalUses && <div className="text-danger small mt-1 nowrap">{errors.totalUses}</div>}
//                       </div>
//                     )}
//                   </Col>
//                   <Col md={6}>
//                     <Form.Check
//                       type="checkbox"
//                       id="limit-per-customer"
//                       checked={limitPerCustomerOnce}
//                       onChange={(e) => { setLimitPerCustomerOnce(e.target.checked); onDirty?.() }}
//                       label="No Usage Limit "
//                     />
//                     <div className="mt-3">
//                       <Form.Check
//                         type="checkbox"
//                         id="limit-per-account"
//                         checked={limitPerAccount}
//                         onChange={(e) => { setLimitPerAccount(e.target.checked); onDirty?.() }}
//                         label="Set usage limit per account"
//                       />
//                       {limitPerAccount && (
//                         <div className="mt-2" style={{ maxWidth: 220 }}>
//                           <Form.Control
//                             type="number" min="1" step="1" required
//                             value={perAccountUses}
//                             onChange={(e) => { setPerAccountUses(Number(e.target.value || 1)); onDirty?.() }}
//                           />
//                           {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
//                         </div>
//                       )}
//                     </div>
//                   </Col>
//                 </Row>
//               </div>
//             </section>

//             {/* Amount Limits */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Set Minimum Purchase and Maximum Discount Amount</span>
//               </div>
//               <div className="section-body">
//                 <Row className="g-3">
//                   <Col md={6}>
//                     <InputGroup>
//                       <InputGroup.Text className="fw-semibold nowrap">Min Purchase</InputGroup.Text>
//                       <Form.Control
//                         type="number" min="0" step="0.01"
//                         value={minPurchase}
//                         onChange={(e) => { setMinPurchase(e.target.value); onDirty?.() }}
//                         required
//                       />
//                     </InputGroup>
//                     {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
//                   </Col>
//                   <Col md={6}>
//                     <InputGroup>
//                       <InputGroup.Text className="fw-semibold nowrap">Max Discount</InputGroup.Text>
//                       <Form.Control
//                         type="number" min="0" step="0.01"
//                         value={maxDiscountAmount}
//                         onChange={(e) => { setMaxDiscountAmount(e.target.value); onDirty?.() }}
//                         required
//                       />
//                     </InputGroup>
//                     {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
//                   </Col>
//                 </Row>
//               </div>
//             </section>

//             {/* Active Period */}
//             <section className="section">
//               <div className="section-head">
//                 <span className="section-title">Active Period</span>
//               </div>
//               <div className="section-body">
//                 <Row className="g-3">
//                   <Col md={3}>
//                     <Form.Label className="fw-semibold">Start Date <span className="text-danger">*</span></Form.Label>
//                     <Form.Control
//                       type="date" required
//                       value={startDate}
//                       onChange={(e) => { setStartDate(e.target.value); onDirty?.() }}
//                     />
//                     {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
//                   </Col>
//                   <Col md={3}>
//                     <Form.Label className="fw-semibold">Start Time <span className="text-danger">*</span></Form.Label>
//                     <Form.Control
//                       type="time" required
//                       value={startTime}
//                       onChange={(e) => { setStartTime(e.target.value); onDirty?.() }}
//                     />
//                     {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
//                   </Col>
//                   <Col md={12}>
//                     <Form.Check
//                       id="has-end"
//                       type="checkbox"
//                       className="mt-2"
//                       checked={hasEnd}
//                       onChange={(e) => { setHasEnd(e.target.checked); onDirty?.() }}
//                       label="Set End Date"
//                     />
//                   </Col>
//                   {hasEnd && (
//                     <>
//                       <Col md={3}>
//                         <Form.Label className="fw-semibold">End Date <span className="text-danger">*</span></Form.Label>
//                         <Form.Control
//                           type="date" required
//                           value={endDate}
//                           onChange={(e) => { setEndDate(e.target.value); onDirty?.() }}
//                         />
//                         {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
//                       </Col>
//                       <Col md={3}>
//                         <Form.Label className="fw-semibold">End Time <span className="text-danger">*</span></Form.Label>
//                         <Form.Control
//                           type="time" required
//                           value={endTime}
//                           onChange={(e) => { setEndTime(e.target.value); onDirty?.() }}
//                         />
//                         {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
//                       </Col>
//                     </>
//                   )}
//                 </Row>
//               </div>
//             </section>

//             {/* Footer actions */}
//             <div className="footer-actions">
//               <Button variant="outline-secondary" onClick={() => window.history.back()}>
//                 Discard
//               </Button>
//               <Button onClick={onSave} disabled={saving}>
//                 {saving ? (
//                   <>
//                     <Spinner animation="border" size="sm" className="me-2" /> Saving…
//                   </>
//                 ) : (
//                   'Save'
//                 )}
//               </Button>
//             </div>
//           </Col>

//           {/* ---------- RIGHT: Summary ---------- */}
//           <Col lg={4}>
//             <aside className="summary-card">
//               <div className="sum-head">Discount Summary</div>
//               <div className="sum-row">
//                 <div className="sum-label">Discount Code</div>
//                 <div className="sum-value code">{code || '—'}</div>
//               </div>
//               <div className="sum-row">
//                 <div className="sum-label">Discount Value</div>
//                 <div className="sum-value">{valueSummary}</div>
//               </div>
//               <div className="sum-row">
//                 <div className="sum-label">Eligibility</div>
//                 <div className="sum-value">{eligibilitySummary}</div>
//               </div>
//               <div className="sum-row">
//                 <div className="sum-label">Usage Limits</div>
//                 <div className="sum-value">{usageSummary}</div>
//               </div>
//               <div className="sum-row">
//                 <div className="sum-label">Amount Rules</div>
//                 <div className="sum-value">
//                   Min Purchase: {minPurchase === '' ? '—' : `$${Number(minPurchase).toFixed(2)}`}<br/>
//                   Max Discount: {maxDiscountAmount === '' ? '—' : `$${Number(maxDiscountAmount).toFixed(2)}`}
//                 </div>
//               </div>
//               <div className="sum-row">
//                 <div className="sum-label">Active Period</div>
//                 <div className="sum-value">{periodSummary}</div>
//               </div>
//             </aside>
//           </Col>
//         </Row>
//       </Card.Body>

//       {/* Styles (match module theme) */}
//       <style jsx>{`
//         .section + .section { margin-top: 16px; }
//         .section-head {
//           display: flex; align-items: center; justify-content: space-between; gap: 12px;
//           padding: 10px 12px;
//           border: 1px solid rgba(0,0,0,0.06);
//           border-bottom: none;
//           border-radius: 12px 12px 0 0;
//           background: #f5f7fb;
//         }
//         .section-title { font-weight: 700; color: #111827; }
//         .section-body {
//           padding: 12px;
//           border: 1px solid rgba(0,0,0,0.06);
//           border-radius: 0 0 12px 12px;
//           background: #fff;
//         }
//         .stacked-choice {
//           border: 1px solid rgba(0,0,0,0.08);
//           border-radius: 10px;
//           padding: 10px 12px;
//           background: #fff;
//         }
//         .footer-actions {
//           display: flex; gap: 10px; justify-content: flex-end; margin-top: 18px;
//         }
//         :global(.btn-dark) { background-color: #111827; border-color: #111827; }
//         .nowrap { white-space: nowrap; }

//         .summary-card {
//           border: 1px solid rgba(0,0,0,0.08);
//           border-radius: 12px;
//           background: #fff;
//           padding: 12px;
//         }
//         .sum-head {
//           font-weight: 700; color: #111827;
//           background: #f5f7fb;
//           border: 1px solid rgba(0,0,0,0.06);
//           border-radius: 10px;
//           padding: 10px 12px;
//           margin-bottom: 10px;
//         }
//         .sum-row { display: grid; grid-template-columns: 140px 1fr; gap: 10px; padding: 8px 2px; }
//         .sum-label { color: #6b7280; font-weight: 600; }
//         .sum-value { color: #111827; }
//         .sum-value.code { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
//       `}</style>
//     </Card>
//   )
// }

// function randomCode(len = 10) {
//   const alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' // no ambiguous chars
//   let s = ''
//   for (let i = 0; i < len; i++) s += alpha[Math.floor(Math.random() * alpha.length)]
//   return s
// }
