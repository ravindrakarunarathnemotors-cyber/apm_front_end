'use client'

import { useMemo, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useAddProductDiscountMutation } from '@/store/features/apiSlice'
import { useRouter } from 'next/navigation'

export default function BuyXGetY({ onDirty, targetProducts = [], targetBrands = [], targetCollections = [], targetCategories = [] }) {
  const router = useRouter()

  // ----- Title -----
  const [title, setTitle] = useState('')
  const TITLE_MAX = 100

  // ----- Quantities -----
  const [buyQty, setBuyQty] = useState(1)
  const [getQty, setGetQty] = useState(1)

  // Optional BXGY cap per order (kept but not in UI)
  const [limitMaxGet, setLimitMaxGet] = useState(false)
  const [maxGetPerOrder, setMaxGetPerOrder] = useState(100)

  // ----- Customer Eligibility -----
  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  // ----- Usage Limits (mutually exclusive) -----
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState()

  // ----- Active Dates -----
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ----- RTK Mutation -----
  const [addDiscount, { isLoading: saving }] = useAddProductDiscountMutation()

  // ----- Validation / Errors -----
  const [errors, setErrors] = useState({})

  const validate = () => {
    const e = {}
    if (!title.trim()) e.title = 'Title is required.'
    if (title.length > TITLE_MAX) e.title = `Title must be ${TITLE_MAX} characters or fewer.`
    if (!buyQty || Number(buyQty) < 1) e.buyQty = 'Buy quantity is required.'
    if (!getQty || Number(getQty) < 1) e.getQty = 'Get quantity is required.'
    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Usage per account is required.'
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < todayISO()) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const toISO = (d, t) => (d && t ? new Date(`${d}T${t}:00`).toISOString() : null)
  const uniqNums = (arr) => [...new Set((arr || []).map(Number).filter(Number.isFinite))]

  // keep uniqNums (used elsewhere) — add a robust extractor for object-shaped targets
  const extractIds = (items) => {
    if (!Array.isArray(items)) return []
    const ids = items
      .map((it) => {
        if (it == null) return null
        if (typeof it === 'object') {
          // try common id fields used in codebase
          return it.id ?? it.product_id ?? it.collection_id ?? it.category_id ?? it.brand_id ?? it?.sku ?? null
        }
        return it // primitive (number|string)
      })
      .filter((v) => v != null)

    // normalize purely-numeric strings to numbers, keep non-numeric primitives as-is
    const normalized = ids.map((v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v))

    // dedupe while preserving type
    return Array.from(new Set(normalized))
  }

  // ----- Summaries -----
  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('One use per customer')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // ----------------- Targets display helpers -----------------
  // normalize incoming target arrays into objects with { id, label } for display
  // Prefers 'title' for products and 'name' for others. Accepts primitives (id) or objects.
  const normalizeTargetsForUI = (items, type = 'generic') => {
    if (!Array.isArray(items)) return []
    return items.map((it) => {
      if (it && typeof it === 'object') {
        // support shapes: { id, product_id, collection_id, category_id, brand_id, title, name, label }
        const id = it.id ?? it.product_id ?? it.collection_id ?? it.category_id ?? it.brand_id ?? it?.sku ?? null
        let label = ''
        if (type === 'products') {
          label = it.title ?? it.product_title ?? it.name ?? it.label ?? ''
        } else {
          label = it.name ?? it.title ?? it.label ?? ''
        }
        if (!label) label = it.title ?? it.name ?? it.label ?? ''
        if (!label) label = String(id ?? JSON.stringify(it))
        return { id: id ?? label, label }
      } else {
        // primitive (number/string) — present as string label
        return { id: it, label: String(it) }
      }
    })
  }

  // Expansion states for each target type
  const [productsExpanded, setProductsExpanded] = useState(false)
  const [collectionsExpanded, setCollectionsExpanded] = useState(false)
  const [categoriesExpanded, setCategoriesExpanded] = useState(false)
  const [brandsExpanded, setBrandsExpanded] = useState(false)

  const uiProducts = normalizeTargetsForUI(targetProducts, 'products')
  const uiCollections = normalizeTargetsForUI(targetCollections, 'collections')
  const uiCategories = normalizeTargetsForUI(targetCategories, 'categories')
  const uiBrands = normalizeTargetsForUI(targetBrands, 'brands')

  // render pills (<=3 items)
  const renderPills = (items, placeholder = '—') => {
    if (!Array.isArray(items) || items.length === 0) return <span>{placeholder}</span>
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={String(it.id) + '-' + it.label} className="pill">
            <span className="pill-label">{it.label}</span>
          </span>
        ))}
      </div>
    )
  }

  // Expand toggle button (small circular)
  const ExpandToggleButton = ({ expanded, onToggle, title }) => {
    return (
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-label={expanded ? 'Collapse targets' : 'Expand targets'}
        title={title}
        style={{
          width: '32px',
          height: '32px',
          border: 'none',
          background: 'transparent',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          padding: 0,
          transition: 'background 0.2s ease',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.2)')}
        onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
        <Icon icon={expanded ? 'solar:alt-arrow-up-linear' : 'solar:alt-arrow-down-linear'} width={18} />
      </button>
    )
  }

  // render targets box identical UX as your other form
  const renderTargetsBox = (items, placeholder = '—', type = 'products') => {
    const expanded =
      type === 'products'
        ? productsExpanded
        : type === 'collections'
          ? collectionsExpanded
          : type === 'categories'
            ? categoriesExpanded
            : brandsExpanded

    const setExpanded =
      type === 'products'
        ? setProductsExpanded
        : type === 'collections'
          ? setCollectionsExpanded
          : type === 'categories'
            ? setCategoriesExpanded
            : setBrandsExpanded

    if (!Array.isArray(items) || items.length === 0) {
      return <div className="targets-box targets-box-empty">—</div>
    }

    const many = items.length > 3

    return (
      <div className="targets-wrapper">
        <div
          className={`targets-box fixed ${expanded ? 'expanded' : 'collapsed'} ${type === 'products' ? 'products' : ''}`}
          role="region"
          aria-label={type + '-targets'}
          title={`${items.length} items`}>
          {many ? (
            expanded ? (
              <ul className="targets-list">
                {items.map((it) => (
                  <li key={String(it.id) + '-' + it.label}>{it.label}</li>
                ))}
              </ul>
            ) : (
              <ul className="targets-list">
                {items.slice(0, 3).map((it) => (
                  <li key={String(it.id) + '-' + it.label}>{it.label}</li>
                ))}
              </ul>
            )
          ) : (
            renderPills(items)
          )}
        </div>

        {many && <ExpandToggleButton expanded={expanded} onToggle={() => setExpanded((s) => !s)} title={expanded ? 'Collapse' : 'Expand'} />}
      </div>
    )
  }

  // ----- Save -----
  const onSave = async () => {
    if (!validate()) return

    const payload = {
      main_discount_type: 'product',
      prod_discount_method: 'buyxgety',
      discount_title: title.trim(),
      target_products: extractIds(targetProducts),
      target_collections: extractIds(targetCollections),
      target_categories: extractIds(targetCategories),
      target_brands: extractIds(targetBrands),

      customer_eligibility: eligibility,
      is_guest_allowed: !!guestIncluded,

      usage_limit_total: null,
      unlimited_usage: !!limitPerCustomerOnce,
      usage_limit_per_account: limitPerAccount ? Number(perAccountUses) : null,

      start_date: toISO(startDate, startTime),
      end_date: hasEnd ? toISO(endDate, endTime) : null,

      discount_code: null,
      customer_buys_qty: Number(buyQty),
      customer_gets_qty: Number(getQty),
      bxgy_max_limit: limitMaxGet ? Number(maxGetPerOrder) : null,

      order_discount_method: null,
      payment_method: null,
    }

    try {
      await addDiscount(payload).unwrap()
      const result = await Swal.fire({
        icon: 'success',
        title: 'Saved',
        text: 'Buy X Get Y discount created successfully.',
        confirmButtonColor: '#111827',
      })
      if (result.isConfirmed) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('discount:saved'))
        }
      }
    } catch (err) {
      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: err?.data?.error || err?.message || 'Failed to save discount',
        confirmButtonColor: '#111827',
      })
    }
  }

  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">Buy X Get Y Offer</Card.Title>
          <small className="text-muted">Reward customers when they buy certain items/quantities.</small>
        </div>
      </Card.Header>

      <Card.Body>
        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Title */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Title</span>
              </div>
              <div className="section-body">
                <Form.Control
                  placeholder="e.g. Buy 2 Tees, Get 1 Free"
                  value={title}
                  maxLength={TITLE_MAX}
                  required
                  onChange={(e) => {
                    setTitle(e.target.value)
                    onDirty?.()
                  }}
                />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">
                    {title.length}/{TITLE_MAX}
                  </small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Quantities */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Buys and Gets</span>
              </div>
              <div className="section-body">
                <Row className="g-3 align-items-center">
                  <Col md={6}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap">Buy Quantity</InputGroup.Text>
                      <Form.Control
                        type="number"
                        min="1"
                        step="1"
                        required
                        value={buyQty}
                        onChange={(e) => {
                          setBuyQty(Number(e.target.value || 1))
                          onDirty?.()
                        }}
                      />
                    </InputGroup>
                    {errors.buyQty && <div className="text-danger small mt-1 nowrap">{errors.buyQty}</div>}
                  </Col>
                  <Col md={6}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap">Get Quantity</InputGroup.Text>
                      <Form.Control
                        type="number"
                        min="1"
                        step="1"
                        required
                        value={getQty}
                        onChange={(e) => {
                          setGetQty(Number(e.target.value || 1))
                          onDirty?.()
                        }}
                      />
                    </InputGroup>
                    {errors.getQty && <div className="text-danger small mt-1 nowrap">{errors.getQty}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        onDirty?.()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        onDirty?.()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        onDirty?.()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        onDirty?.()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Usage Limit (mutually exclusive, always one selected) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Usage Limit</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-once-user"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent unchecking if it would leave both unchecked
                        if (!checked && !limitPerAccount) return

                        setLimitPerCustomerOnce(checked)

                        // Exclusivity
                        if (checked) setLimitPerAccount(false)

                        onDirty?.()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent unchecking if it would leave both unchecked
                        if (!checked && !limitPerCustomerOnce) return

                        setLimitPerAccount(checked)

                        // Exclusivity
                        if (checked) setLimitPerCustomerOnce(false)

                        onDirty?.()
                      }}
                      label="Set usage limit per account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(Number(e.target.value || 1))
                            onDirty?.()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Dates */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Period</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => {
                        setStartTime(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                  </Col>
                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        onDirty?.()
                      }}
                      label="Set End Date"
                    />
                  </Col>
                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            setEndDate(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer */}
            <div className="footer-actions">
              <Button
                variant="outline-secondary"
                onClick={async () => {
                  const res = await Swal.fire({
                    title: 'Discard changes?',
                    text: 'Do you want to discard the changes?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Discard',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#111827',
                  })

                  if (res.isConfirmed) {
                    // 🔥 notify global listeners (same event as save)
                    if (typeof window !== 'undefined') {
                      window.dispatchEvent(new CustomEvent('discount:saved'))
                    }
                  }
                }}>
                Discard
              </Button>

              <Button onClick={onSave} disabled={saving}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary (with targets) ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>

              <div className="sum-row">
                <div className="sum-label">Category</div>
                <div className="sum-value">Buy X Get Y</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Offer</div>
                <div className="sum-value">
                  Buy {buyQty}, Get {getQty} Free
                </div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* ---------- TARGETS SUMMARY SECTION ---------- */}
              <div className="targets-head" style={{ marginTop: 12, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">{renderTargetsBox(uiProducts, '—', 'products')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">{renderTargetsBox(uiBrands, '—', 'brands')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">{renderTargetsBox(uiCollections, '—', 'collections')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">{renderTargetsBox(uiCategories, '—', 'categories')}</div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        .nowrap {
          white-space: nowrap;
        }

        /* ---------- MATCHED SUMMARY STYLES ---------- */
        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
          box-sizing: border-box;
          overflow: hidden;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 140px 1fr;
          gap: 10px;
          padding: 8px 2px;
          font-size: 12px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
          min-width: 0;
        }

        .targets-head {
          font-size: 13px;
        }

        /* pills */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Targets wrapper + boxes (fixed-size scrollable) */
        .targets-wrapper {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          position: relative;
        }

        .targets-box.fixed {
          width: 100%;
          height: 140px;
          overflow-y: auto;
          padding: 6px;
          background: transparent;
          border-radius: 8px;
          box-sizing: border-box;
        }

        .targets-box.fixed.products {
          width: 220px;
          height: 140px;
        }

        .targets-box.fixed.expanded {
          height: 240px;
        }

        .targets-box.fixed.products.expanded {
          width: 220px;
          height: 240px;
        }

        .targets-box-empty {
          color: #6b7280;
          padding: 8px;
          border-radius: 8px;
          border: 1px dashed rgba(0, 0, 0, 0.04);
          background: #fafafa;
        }

        .targets-list {
          margin: 0;
          padding-left: 18px;
        }
        .targets-list li {
          margin-bottom: 6px;
          line-height: 1.25;
          word-break: break-word;
        }

        @media (max-width: 575px) {
          .sum-row {
            grid-template-columns: 120px 1fr;
          }
          .targets-box.fixed.products {
            width: 160px;
          }
        }
      `}</style>
    </Card>
  )
}
