'use client'

import { useMemo, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useRouter } from 'next/navigation'

// RTK Query: add-discount mutation + currency query
import { useAddProductDiscountMutation, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice'

export default function GeneralDiscount({
  onDirty,
  targetProducts = [],
  targetBrands = [],
  targetCollections = [],
  targetCategories = [], // <-- make sure parent passes this (objects with title/name preferred)
}) {
  // ----- Title -----
  const [title, setTitle] = useState('')
  const TITLE_MAX = 100

  // ----- Discount value (store as strings to avoid forced 0 on clear) -----
  const [valueType, setValueType] = useState('percentage') // 'percentage' | 'fixed'
  const [value, setValue] = useState('10') // keep string to allow '' while typing

  // ----- Min purchase / Max discount amount (no enable checkbox) -----
  const [minPurchase, setMinPurchase] = useState('') // optional; '' treated as null
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('') // only for percentage; '' treated as null

  // ----- Customer eligibility -----
  const [eligibility, setEligibility] = useState('all') // 'all' | 'new' | 'existing'
  const [guestIncluded, setGuestIncluded] = useState(false)

  // ----- Usage limits (only per-customer/per-account) -----
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true) // <-- default to Unlimited
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState()

  const nextRouter = useRouter()

  // ----- Active period -----
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ----- Validation / Actions -----
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  // ----- RTKQ mutation -----
  const [addProductDiscount] = useAddProductDiscountMutation()

  // ----- Currency: query from backend and default to 'LKR' -----
  const { data: currencyFromApi } = useGetDiscountCurrencyQuery()
  const currency = typeof currencyFromApi === 'string' && currencyFromApi ? currencyFromApi : 'LKR'

  // ----- Helpers -----
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  const toISO = (d, t) => {
    if (!d || !t) return null
    try {
      return new Date(`${d}T${t}`).toISOString()
    } catch {
      return null
    }
  }
  const uniqNums = (arr) => [...new Set((arr || []).map(Number).filter(Number.isFinite))]

  // keep uniqNums for numeric-only use — add a robust extractor for object-shaped targets
  const extractIds = (items) => {
    if (!Array.isArray(items)) return []
    const ids = items
      .map((it) => {
        if (it == null) return null
        if (typeof it === 'object') {
          // try common id fields used in codebase
          return it.id ?? it.product_id ?? it.collection_id ?? it.category_id ?? it.brand_id ?? it?.sku ?? null
        }
        return it // primitive (number|string)
      })
      .filter((v) => v != null)

    // normalize purely-numeric strings to numbers, keep other primitives as-is
    const normalized = ids.map((v) => (typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : v))

    // dedupe while preserving types
    return Array.from(new Set(normalized))
  }

  // ----- Summaries -----
  const valueSummary = useMemo(() => {
    const n = Number(value || 0)
    if (valueType === 'percentage') return `${Number.isFinite(n) ? n : 0}%`
    return `${currency}${Number.isFinite(n) ? n.toFixed(2) : '0.00'}`
  }, [valueType, value, currency])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('One use per customer')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const amountSummary = useMemo(() => {
    const minStr = minPurchase === '' ? '—' : `${currency}${Number(minPurchase).toFixed(2)}`
    const maxStr = valueType === 'percentage' ? (maxDiscountAmount === '' ? '—' : `${currency}${Number(maxDiscountAmount).toFixed(2)}`) : '—'
    return `Min: ${minStr} • Max Disc: ${maxStr}`
  }, [minPurchase, maxDiscountAmount, valueType, currency])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // ----- Validation -----
  const validate = () => {
    const e = {}
    const today = todayISO()

    if (!title.trim()) e.title = 'Discount title is required.'
    if (title.length > TITLE_MAX) e.title = `Title must be ${TITLE_MAX} characters or fewer.`

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'

    // sanitize value from string
    const nVal = value === '' ? NaN : Number(value)

    if (valueType === 'percentage') {
      // allow only 1-100 inclusive
      if (!Number.isFinite(nVal) || nVal < 1 || nVal > 100) e.value = 'Enter % between 1 and 100.'
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) < 0) {
        e.maxDiscountAmount = 'Maximum discount must be 0 or more.'
      }
    } else {
      if (!Number.isFinite(nVal) || nVal <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (minPurchase !== '' && Number(minPurchase) < 0) {
      e.minPurchase = 'Enter a valid minimum purchase (0 or more).'
    }

    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Usage per account is required.'

    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'

    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ----- Save handler -----
  const onSave = async () => {
    if (!validate()) return
    setSaving(true)

    // targets
    // targets: handle arrays that may contain objects or primitives
    const tp = extractIds(targetProducts)
    const tb = extractIds(targetBrands)
    const tc = extractIds(targetCollections)
    const tcat = extractIds(targetCategories)

    // coerce on save
    const numericValue = Number(value)
    const payload = {
      main_discount_type: 'product',
      prod_discount_method: 'general',
      discount_title: title.trim(),

      // value
      discount_value_type: valueType,
      discount_value: numericValue,

      // purchase limits (no enable toggle; send only if user filled)
      min_max_purchase_discount_limits: minPurchase !== '' || (valueType === 'percentage' && maxDiscountAmount !== ''),
      min_purchase_amount: minPurchase === '' ? null : Number(minPurchase),
      // Only send max_discount_amount when Percentage is selected; otherwise null
      max_discount_amount: valueType === 'percentage' ? (maxDiscountAmount === '' ? null : Number(maxDiscountAmount)) : null,

      // eligibility
      customer_eligibility: eligibility,
      is_guest_allowed: Boolean(guestIncluded),

      // usage limits (no total-usage control anymore)
      usage_limit_total: null,
      unlimited_usage: Boolean(limitPerCustomerOnce),
      usage_limit_per_account: limitPerAccount ? Number(perAccountUses || 0) : null,

      // date range
      start_date: toISO(startDate, startTime),
      end_date: hasEnd ? toISO(endDate, endTime) : null,

      // targets
      target_products: tp,
      target_brands: tb,
      target_collections: tc,
      target_categories: tcat,
    }

    try {
      await addProductDiscount(payload).unwrap()

      await Swal.fire({
        icon: 'success',
        title: 'Saved',
        text: 'General discount created successfully.',
      })

      // notify any listeners in the app that a discount was saved
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    } catch (err) {
      const msg = err?.data?.error || err?.data?.message || err?.error || err?.message || 'Failed to save discount'

      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: String(msg),
      })
    } finally {
      setSaving(false)
    }
  }

  // ----- Input guards for numbers stored as strings -----
  const onPercentChange = (e) => {
    const raw = e.target.value
    if (raw === '') {
      setValue('')
      onDirty?.()
      return
    }
    const cleaned = raw.replace(/[^\d]/g, '')
    setValue(cleaned)
    onDirty?.()
  }
  const onPercentBlur = () => {
    if (value === '') return
    let n = Number(value)
    if (!Number.isFinite(n)) return
    if (n < 1) n = 1
    if (n > 100) n = 100
    setValue(String(n))
  }

  const onMoneyChange = (e) => {
    const raw = e.target.value
    if (raw === '') {
      setValue('')
      onDirty?.()
      return
    }
    const cleaned = raw
      .replace(/,/g, '')
      .replace(/[^\d.]/g, '')
      .replace(/(\..*)\./g, '$1')
    setValue(cleaned)
    onDirty?.()
  }

  // ----------------- Targets display helpers (BuyXGetY style UI/UX) -----------------

  // Expansion states for each target type (products have a fixed narrower box)
  const [productsExpanded, setProductsExpanded] = useState(false)
  const [collectionsExpanded, setCollectionsExpanded] = useState(false)
  const [categoriesExpanded, setCategoriesExpanded] = useState(false)
  const [brandsExpanded, setBrandsExpanded] = useState(false)

  // Helper: try to find a label for a primitive id by searching the provided target arrays (if they contain full objects)
  const findLabelForId = (id) => {
    if (id == null) return ''
    const tryMatch = (arr, keys = ['title', 'name', 'label']) => {
      if (!Array.isArray(arr)) return null
      for (const it of arr) {
        if (!it) continue
        // check numeric/string equality tolerant
        const itId = it.id ?? it.product_id ?? it.collection_id ?? it.category_id ?? it.brand_id ?? null
        if (itId !== null && `${itId}` === `${id}`) {
          for (const k of keys) {
            if (it[k]) return String(it[k])
          }
          // fallback to stringify some known fields
          if (it.title) return String(it.title)
          if (it.name) return String(it.name)
          if (it.label) return String(it.label)
        }
      }
      return null
    }

    // try product list first (use title/name)
    let found = tryMatch(targetProducts, ['title', 'name', 'label'])
    if (found) return found
    // collections/ categories/ brands
    found = tryMatch(targetCollections, ['name', 'title', 'label'])
    if (found) return found
    found = tryMatch(targetCategories, ['name', 'title', 'label'])
    if (found) return found
    found = tryMatch(targetBrands, ['name', 'title', 'label'])
    if (found) return found

    return null
  }

  // normalize incoming target arrays into objects with { id, label } for display
  // This prefers 'title' for products and 'name' for others. If parent provides primitives (ids),
  // we will attempt to resolve labels by scanning the other provided arrays (best-effort).
  const normalizeTargetsForUI = (items, type = 'generic') => {
    if (!Array.isArray(items)) return []
    return items.map((it) => {
      if (it && typeof it === 'object') {
        const id = it.id ?? it.product_id ?? it.collection_id ?? it.category_id ?? it.brand_id ?? null
        let label = ''
        if (type === 'products') {
          label = it.title ?? it.name ?? it.label ?? it.product_title ?? ''
        } else {
          label = it.name ?? it.title ?? it.label ?? ''
        }
        if (!label) {
          // try some common fields
          label = it.title ?? it.name ?? it.label ?? ''
        }
        if (!label) label = String(id ?? JSON.stringify(it))
        return { id: id ?? label, label }
      } else {
        // primitive (number/string) — try to resolve a friendly title from other arrays
        const resolved = findLabelForId(it)
        return { id: it, label: resolved ?? String(it) }
      }
    })
  }

  const uiProducts = normalizeTargetsForUI(targetProducts, 'products')
  const uiCollections = normalizeTargetsForUI(targetCollections, 'collections')
  const uiCategories = normalizeTargetsForUI(targetCategories, 'categories')
  const uiBrands = normalizeTargetsForUI(targetBrands, 'brands')

  // render pills (<=3 items)
  const renderPills = (items, placeholder = '—') => {
    if (!Array.isArray(items) || items.length === 0) return <span>{placeholder}</span>
    return (
      <div className="pills-wrap">
        {items.map((it) => (
          <span key={String(it.id) + '-' + it.label} className="pill">
            <span className="pill-label">{it.label}</span>
          </span>
        ))}
      </div>
    )
  }

  // Use exact expand icon style & button behavior like BuyXGetY (inline-styled circular button with hover)
  const ExpandToggleButton = ({ expanded, onToggle, title }) => {
    return (
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-label={expanded ? 'Collapse targets' : 'Expand targets'}
        title={title}
        style={{
          width: '32px',
          height: '32px',
          border: 'none',
          background: 'transparent',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          padding: 0,
          transition: 'background 0.2s ease',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.2)')}
        onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}>
        <Icon icon={expanded ? 'solar:alt-arrow-up-linear' : 'solar:alt-arrow-down-linear'} width={18} />
      </button>
    )
  }

  // render targets box identical UX as BuyXGetY
  const renderTargetsBox = (items, placeholder = '—', type = 'products') => {
    const expanded =
      type === 'products'
        ? productsExpanded
        : type === 'collections'
          ? collectionsExpanded
          : type === 'categories'
            ? categoriesExpanded
            : brandsExpanded

    const setExpanded =
      type === 'products'
        ? setProductsExpanded
        : type === 'collections'
          ? setCollectionsExpanded
          : type === 'categories'
            ? setCategoriesExpanded
            : setBrandsExpanded

    if (!Array.isArray(items) || items.length === 0) {
      return <div className="targets-box targets-box-empty">—</div>
    }

    const many = items.length > 3

    return (
      <div className="targets-wrapper">
        <div
          className={`targets-box fixed ${expanded ? 'expanded' : 'collapsed'} ${type === 'products' ? 'products' : ''}`}
          role="region"
          aria-label={type + '-targets'}
          title={`${items.length} items`}>
          {many ? (
            expanded ? (
              <ul className="targets-list">
                {items.map((it) => (
                  <li key={String(it.id) + '-' + it.label}>{it.label}</li>
                ))}
              </ul>
            ) : (
              <ul className="targets-list">
                {items.slice(0, 3).map((it) => (
                  <li key={String(it.id) + '-' + it.label}>{it.label}</li>
                ))}
              </ul>
            )
          ) : (
            renderPills(items)
          )}
        </div>

        {many && <ExpandToggleButton expanded={expanded} onToggle={() => setExpanded((s) => !s)} title={expanded ? 'Collapse' : 'Expand'} />}
      </div>
    )
  }

  // -------------------- Render --------------------
  return (
    <Card className="soft-card mb-3">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between ">
        <div>
          <Card.Title className="mb-0">Products General Discount</Card.Title>
          <small className="text-muted">Create a sitewide or targeted automatic discount.</small>
        </div>
      </Card.Header>

      <Card.Body>
        <Row className="g-3 mt-0">
          {/* ---------- LEFT: Form (unchanged) ---------- */}
          <Col lg={8}>
            {/* Title */}
            <section className="section ">
              <div className="section-head">
                <span className="section-title ">Discount Title</span>
              </div>
              <div className="section-body">
                <Form.Control
                  placeholder="e.g. Summer Storewide 10% Off"
                  value={title}
                  maxLength={TITLE_MAX}
                  required
                  onChange={(e) => {
                    setTitle(e.target.value)
                    onDirty?.()
                  }}
                />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">
                    {title.length}/{TITLE_MAX}
                  </small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          /* keep value as-is */ onDirty?.()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          /* keep value as-is */ onDirty?.()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            inputMode="numeric"
                            pattern="[0-9]*"
                            value={value}
                            onChange={onPercentChange}
                            onBlur={onPercentBlur}
                            aria-label="Percentage discount (1-100)"
                            placeholder="e.g. 10"
                            required
                          />
                        </>
                      ) : (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">{currency}</InputGroup.Text>
                          <Form.Control
                            inputMode="decimal"
                            value={value}
                            onChange={onMoneyChange}
                            aria-label="Fixed amount"
                            placeholder={`e.g. 10.00 (${currency})`}
                            required
                          />
                        </>
                      )}
                    </InputGroup>
                    {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Options (no enable toggle) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase and Maximum Discount Amount</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={valueType === 'percentage' ? 6 : 7}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap">Min Purchase Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                      <Form.Control
                        inputMode="decimal"
                        value={minPurchase}
                        onChange={(e) => {
                          const raw = e.target.value
                          if (raw === '') {
                            setMinPurchase('')
                            onDirty?.()
                            return
                          }
                          const cleaned = raw
                            .replace(/,/g, '')
                            .replace(/[^\d.]/g, '')
                            .replace(/(\..*)\./g, '$1')
                          setMinPurchase(cleaned)
                          onDirty?.()
                        }}
                        placeholder="Optional"
                      />
                    </InputGroup>
                    {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                  </Col>

                  {/* Max Discount Amount appears ONLY when valueType === 'percentage' */}
                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap">Max Discount Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                        <Form.Control
                          inputMode="decimal"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            const raw = e.target.value
                            if (raw === '') {
                              setMaxDiscountAmount('')
                              onDirty?.()
                              return
                            }
                            const cleaned = raw
                              .replace(/,/g, '')
                              .replace(/[^\d.]/g, '')
                              .replace(/(\..*)\./g, '$1')
                            setMaxDiscountAmount(cleaned)
                            onDirty?.()
                          }}
                          placeholder="Optional"
                        />
                      </InputGroup>
                      {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        onDirty?.()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        onDirty?.()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        onDirty?.()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        onDirty?.()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Usage Limit (mutually exclusive, always one selected) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Usage Limit</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Block unchecking if both would become false
                        if (!checked && !limitPerAccount) return

                        setLimitPerCustomerOnce(checked)

                        // Exclusivity
                        if (checked) {
                          setLimitPerAccount(false)
                        }

                        onDirty?.()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Block unchecking if both would become false
                        if (!checked && !limitPerCustomerOnce) return

                        setLimitPerAccount(checked)

                        // Exclusivity
                        if (checked) {
                          setLimitPerCustomerOnce(false)
                        }

                        onDirty?.()
                      }}
                      label="Set usage limit per account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(Number(e.target.value || 1))
                            onDirty?.()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Period</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      onChange={(e) => {
                        setStartTime(e.target.value)
                        onDirty?.()
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                  </Col>
                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        onDirty?.()
                      }}
                      label="Set End Date"
                    />
                  </Col>
                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            setEndDate(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            onDirty?.()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button
                variant="outline-secondary"
                onClick={async () => {
                  const res = await Swal.fire({
                    title: 'Discard changes?',
                    text: 'Do you want to discard the changes?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Discard',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#111827',
                  })

                  if (res.isConfirmed) {
                    // 🔥 notify global listeners (same event as save)
                    if (typeof window !== 'undefined') {
                      window.dispatchEvent(new CustomEvent('discount:saved'))
                    }
                  }
                }}>
                Discard
              </Button>

              <Button onClick={onSave} disabled={saving}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary (targets box UI like BuyXGetY) ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>

              <div className="sum-row">
                <div className="sum-label">Category</div>
                <div className="sum-value">General Discount</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Amount Limits</div>
                <div className="sum-value">{amountSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>

              {/* Targets header */}
              <div className="targets-head" style={{ marginTop: 10, marginBottom: 6, fontWeight: 700, color: '#111827' }}>
                Targets
              </div>

              <div className="sum-row">
                <div className="sum-label">Products</div>
                <div className="sum-value">{renderTargetsBox(uiProducts, '—', 'products')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Brands</div>
                <div className="sum-value">{renderTargetsBox(uiBrands, '—', 'brands')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Collections</div>
                <div className="sum-value">{renderTargetsBox(uiCollections, '—', 'collections')}</div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Categories</div>
                <div className="sum-value">{renderTargetsBox(uiCategories, '—', 'categories')}</div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
          box-sizing: border-box;
          overflow: hidden;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 150px 1fr;
          gap: 10px;
          padding: 8px 2px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
          min-width: 0;
        }

        /* pills */
        .pills-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .pill {
          display: inline-flex;
          align-items: center;
          padding: 6px 8px;
          border-radius: 999px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
          font-size: 12px;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .pill-label {
          display: inline-block;
          max-width: 160px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .targets-head {
          font-size: 13px;
        }

        /* Targets wrapper + boxes (fixed-size scrollable) */
        .targets-wrapper {
          display: flex;
          align-items: flex-start;
          gap: 8px;
          position: relative;
        }

        .targets-box.fixed {
          width: 100%;
          height: 140px;
          overflow-y: auto;
          padding: 6px;
          background: transparent;
          border-radius: 8px;
          box-sizing: border-box;
        }

        .targets-box.fixed.products {
          width: 220px;
          height: 140px;
        }

        .targets-box.fixed.expanded {
          height: 240px;
        }

        .targets-box.fixed.products.expanded {
          width: 220px;
          height: 240px;
        }

        .targets-box-empty {
          color: #6b7280;
          padding: 8px;
          border-radius: 8px;
          border: 1px dashed rgba(0, 0, 0, 0.04);
          background: #fafafa;
        }

        .targets-list {
          margin: 0;
          padding-left: 18px;
        }
        .targets-list li {
          margin-bottom: 6px;
          line-height: 1.25;
          word-break: break-word;
        }

        .targets-toggle {
          border: none;
          background: transparent;
          padding: 4px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #6b7280;
        }
        .targets-toggle:focus {
          outline: none;
        }

        @media (max-width: 575px) {
          .sum-row {
            grid-template-columns: 120px 1fr;
          }
          .targets-box.fixed.products {
            width: 160px;
          }
        }
      `}</style>
    </Card>
  )
}
