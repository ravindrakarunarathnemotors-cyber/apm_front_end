'use client'

import { useEffect, useMemo, useState, useRef } from 'react'
import { Card, Row, Col, Form, Badge, Tabs, Tab, Button, Spinner, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

// === RTK Query hooks ===
import {
  useSearchDiscountProductsMutation,
  useGetDiscountCollectionsQuery,
  useGetDiscountBrandsQuery,
  useGetCategoriesQuery,
} from '@/store/features/apiSlice'

// Import the 3 method forms
import GeneralDiscount from './DiscountSelection/GeneralDiscount'
import DiscountCode from './DiscountSelection/DiscountCode'
import BuyXGetY from './DiscountSelection/BuyXGetY'

export default function CreateProductDiscount() {
  // ----- Step machine: 'target' -> 'method' -> 'form' -----
  const [step, setStep] = useState('target') // 'target' | 'method' | 'form'
  const [selectedMethod, setSelectedMethod] = useState(null) // 'general' | 'code' | 'bxgy'

  // ===== Unsaved Changes (pleasant UI modal) =====
  const [dirty, setDirty] = useState(false)
  const markDirty = () => setDirty(true)

  const [showPrompt, setShowPrompt] = useState(false)
  const [isNavigating, setIsNavigating] = useState(false)

  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null)
  const allowNavRef = useRef(false)

  const goToDiscountHome = () => {
    allowNavRef.current = true
    setDirty(false)

    // force reload even if same route
    window.location.href = '/discounts'
  }

  // --- (1) Wire up Next.js router (Pages + App Router compat)
  let RouterEvents = null
  let nextRouter = null
  try {
    const pages = require('next/router')
    nextRouter = pages.useRouter?.()
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }

  // --- (2) Intercept route changes
  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      // ✅ ignore while navigating programmatically
      if (allowNavRef.current || isNavigating) return

      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }

    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  // --- (3) Intercept anchor clicks
  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  // --- (4) Intercept browser back/forward
  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  // --- (5) Intercept keyboard reload
  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const isReloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!isReloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setShowPrompt(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  // --- (6) Hard refresh/tab close
  // useEffect(() => {
  //   const onBeforeUnload = (e) => {
  //     if (!dirty) return
  //     e.preventDefault()
  //     e.returnValue = ''
  //   }
  //   window.addEventListener('beforeunload', onBeforeUnload)
  //   return () => window.removeEventListener('beforeunload', onBeforeUnload)
  // }, [dirty])

  // --- (7) Modal handlers
  const proceedNavigation = () => {
    const action = pendingActionRef.current
    const href = pendingHref
    setShowPrompt(false)
    setDirty(false)
    allowNavRef.current = true
    setIsNavigating(true) // ✅ show navigating overlay

    if (action === 'link' && href) {
      if (href === '/discounts') {
        goToDiscountHome()
        return
      }

      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }

    if (action === 'router' && href) {
      if (href === '/discounts') {
        allowNavRef.current = true
        setDirty(false)
        setIsNavigating(true)

        // 🔒 avoid router + history loops
        window.location.replace('/discounts')
        return
      }

      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }

    if (action === 'history') {
      history.back()
      return
    }
    if (action === 'reload') {
      window.location.reload()
    }
  }
  const cancelNavigation = () => {
    setShowPrompt(false)
    setPendingHref(null)

    pendingActionRef.current = null
    allowNavRef.current = false

    // 🔥 CRITICAL: stop the navigating overlay + loop
    setIsNavigating(false)
  }

  // ====== BACKEND SEARCH (RTK Query) ======
  const [searchProducts, { isLoading: isSearching }] = useSearchDiscountProductsMutation()
  const [searchResults, setSearchResults] = useState([]) // [{id, title}]
  const [searchError, setSearchError] = useState(null)

  // ----- Tabs -----
  const [activeKey, setActiveKey] = useState('product')

  // ----- Specific Product selection -----
  const [prodQuery, setProdQuery] = useState('')
  const [debouncedQ, setDebouncedQ] = useState('')
  const [selectedProductIds, setSelectedProductIds] = useState(new Set())

  // NEW: Map of id -> title for selected products so UI shows titles
  const [selectedProductMap, setSelectedProductMap] = useState(new Map())

  // Store the "payload" that will later go to your discount API
  const [discountPayload, setDiscountPayload] = useState({
    target_products: [], // numeric product IDs
  })

  // Debounce query
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(prodQuery.trim()), 300)
    return () => clearTimeout(t)
  }, [prodQuery])

  // Query backend on debouncedQ
  useEffect(() => {
    const q = debouncedQ
    const isNumeric = /^[0-9]+$/.test(q)
    if (!q) {
      setSearchResults([])
      setSearchError(null)
      return
    }
    if (!isNumeric && q.length < 2) {
      setSearchResults([])
      setSearchError(null)
      return
    }

    let alive = true
    ;(async () => {
      try {
        setSearchError(null)
        const res = await searchProducts({ q }).unwrap()
        const items = Array.isArray(res?.data) ? res.data : []
        const mapped = items.map((r) => ({
          id: r.product_id,
          title: r.title || '',
        }))
        if (alive) setSearchResults(mapped)
      } catch (e) {
        if (alive) {
          setSearchResults([])
          setSearchError(e?.data?.error || 'Search failed')
        }
      }
    })()

    return () => {
      alive = false
    }
  }, [debouncedQ, searchProducts])

  const filteredProducts = useMemo(() => {
    if (!debouncedQ) return []
    return searchResults
  }, [debouncedQ, searchResults])

  const syncTargetProducts = (nextSet) => {
    const arr = [...nextSet]
      .map((v) => {
        const n = Number(v)
        return Number.isFinite(n) ? n : v
      })
      .filter((v) => Number.isFinite(v))
    setDiscountPayload((prev) => ({ ...prev, target_products: arr }))
  }

  // Toggle product: update both selectedProductIds and selectedProductMap
  const toggleProduct = (id, title = '') => {
    setSelectedProductIds((prev) => {
      const next = new Set(prev)
      const isRemoving = next.has(id)
      if (isRemoving) {
        next.delete(id)
        setSelectedProductMap((mPrev) => {
          const m = new Map(mPrev)
          m.delete(id)
          return m
        })
      } else {
        next.add(id)
        // if we have a title available (from current results) store it
        if (title) {
          setSelectedProductMap((mPrev) => {
            const m = new Map(mPrev)
            m.set(id, title)
            return m
          })
        }
      }
      syncTargetProducts(next)
      return next
    })
    markDirty()
  }

  // Select all filtered: add all ids and map titles when available
  const selectAllFiltered = () => {
    if (!filteredProducts.length) return
    setSelectedProductIds((prev) => {
      const next = new Set(prev)
      const mapCopy = new Map(selectedProductMap)
      filteredProducts.forEach((p) => {
        next.add(p.id)
        if (p.title) mapCopy.set(p.id, p.title)
      })
      setSelectedProductMap(mapCopy)
      syncTargetProducts(next)
      return next
    })
    markDirty()
  }
  const clearAllFiltered = () => {
    if (!filteredProducts.length) return
    setSelectedProductIds((prev) => {
      const next = new Set(prev)
      const mapCopy = new Map(selectedProductMap)
      filteredProducts.forEach((p) => {
        next.delete(p.id)
        mapCopy.delete(p.id)
      })
      setSelectedProductMap(mapCopy)
      syncTargetProducts(next)
      return next
    })
    markDirty()
  }

  // ----- Product Groups State -----
  const [selBrands, setSelBrands] = useState(new Set()) // stores NAMES for UI
  const [selCollections, setSelCollections] = useState(new Set()) // stores NAMES for UI

  // ===== Brands from backend (paginated, single Show more in footer) =====
  const brandLimit = 20
  const [brandPage, setBrandPage] = useState(1)
  const { data: brandData, isFetching: isFetchingBrands } = useGetDiscountBrandsQuery({ page: brandPage, limit: brandLimit })

  const [brandList, setBrandList] = useState([]) // [{id, name}]
  const [brandTotal, setBrandTotal] = useState(0)
  const [brandLoaded, setBrandLoaded] = useState(0)

  useEffect(() => {
    if (!brandData) return
    const items = (brandData.items || []).map((b) => ({ id: b.brand_id ?? b.id, name: b.name || '' }))
    setBrandTotal(brandData.total ?? items.length)
    setBrandList((prev) => {
      const map = new Map(prev.map((x) => [x.id, x]))
      items.forEach((it) => map.set(it.id, it))
      const arr = Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name))
      setBrandLoaded(arr.length)
      return arr
    })
  }, [brandData])

  // name -> id map for submit
  const brandNameToId = useMemo(() => {
    const m = new Map()
    brandList.forEach((b) => m.set(b.name, b.id))
    return m
  }, [brandList])

  const brands = useMemo(() => brandList.map((b) => b.name), [brandList])
  const showBrandFooter = brandTotal > 10 && brandLoaded < brandTotal

  const onShowMoreBrands = () => {
    if (isFetchingBrands) return
    if (brandLoaded < brandTotal) setBrandPage((p) => p + 1)
  }

  // ===== Collections from backend (paginated, single Show more in footer) =====
  const collectionLimit = 20
  const [collectionPage, setCollectionPage] = useState(1)
  const { data: collectionsData, isFetching: isFetchingCollections } = useGetDiscountCollectionsQuery({
    page: collectionPage,
    limit: collectionLimit,
  })

  const [collectionList, setCollectionList] = useState([]) // [{id, name}]
  const [collectionTotal, setCollectionTotal] = useState(0)
  const [collectionLoaded, setCollectionLoaded] = useState(0)

  useEffect(() => {
    if (!collectionsData) return
    const items = (collectionsData.items || []).map((c) => ({ id: c.collection_id ?? c.id, name: c.name || '' }))
    setCollectionTotal(collectionsData.total ?? items.length)
    setCollectionList((prev) => {
      const map = new Map(prev.map((x) => [x.id, x]))
      items.forEach((it) => map.set(it.id, it))
      const arr = Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name))
      setCollectionLoaded(arr.length)
      return arr
    })
  }, [collectionsData])

  // name -> id map for submit
  const collectionNameToId = useMemo(() => {
    const m = new Map()
    collectionList.forEach((c) => m.set(c.name, c.id))
    return m
  }, [collectionList])

  const collections = useMemo(() => collectionList.map((c) => c.name), [collectionList])
  const showCollectionFooter = collectionTotal > 10 && collectionLoaded < collectionTotal

  const onShowMoreCollections = () => {
    if (isFetchingCollections) return
    if (collectionLoaded < collectionTotal) setCollectionPage((p) => p + 1)
  }

  // ===== Categories from backend (map into existing 3-level UI) =====
  const { data: categoriesData } = useGetCategoriesQuery()

  // Build a fast lookup: parentId -> children[]
  const categoryByParent = useMemo(() => {
    const byParent = new Map()
    const list = Array.isArray(categoriesData) ? categoriesData : []
    list.forEach((c) => {
      const p = c.category_under == null ? null : Number(c.category_under)
      const id = Number(c.category_id)
      const name = c.name || ''
      if (!byParent.has(p)) byParent.set(p, [])
      byParent.get(p).push({ id, label: name })
    })
    for (const arr of byParent.values()) arr.sort((a, b) => a.label.localeCompare(b.label))
    return byParent
  }, [categoriesData])

  // Derive mains, subsByMain, childrenBySub, and lineage maps from API
  const { mains, subsByMain, childrenBySub, subToMain, childToSub } = useMemo(() => {
    const mains = categoryByParent.get(null) || []
    const subsByMain = new Map()
    const childrenBySub = new Map()
    const subToMain = new Map()
    const childToSub = new Map()
    mains.forEach((m) => {
      const subs = categoryByParent.get(m.id) || []
      subsByMain.set(m.id, subs)
      subs.forEach((s) => {
        subToMain.set(s.id, m.id)
        const kids = categoryByParent.get(s.id) || []
        childrenBySub.set(s.id, kids)
        kids.forEach((c) => childToSub.set(c.id, s.id))
      })
    })
    return { mains, subsByMain, childrenBySub, subToMain, childToSub }
  }, [categoryByParent])

  // ----- Loading effect (fake for groups) -----
  const [loadingGroups, setLoadingGroups] = useState(true)
  useEffect(() => {
    const t2 = setTimeout(() => setLoadingGroups(false), 600)
    return () => {
      clearTimeout(t2)
    }
  }, [])

  // Helpers for sets (brands/collections)
  const toggleSet = (setter) => (value) => {
    setter((prev) => {
      const next = new Set(prev)
      if (next.has(value)) next.delete(value)
      else next.add(value)
      return next
    })
    markDirty()
  }
  const selectAll = (arr, setter) => () => {
    setter(new Set(arr))
    markDirty()
  }
  const clearAll = (setter) => () => {
    setter(new Set())
    markDirty()
  }

  // Categories selections (store NUMERIC IDs for payload)
  const [selMainCats, setSelMainCats] = useState(new Set()) // number IDs
  const [selSubCats, setSelSubCats] = useState(new Set()) // number IDs
  const [selChildCats, setSelChildCats] = useState(new Set()) // number IDs

  const toggleMain = (mid) => {
    setSelMainCats((prev) => {
      const next = new Set(prev)
      if (next.has(mid)) {
        next.delete(mid)
        const subs = subsByMain.get(mid) || []
        setSelSubCats((prevSubs) => {
          const ns = new Set(prevSubs)
          subs.forEach((s) => {
            if (ns.has(s.id)) ns.delete(s.id)
            const ch = childrenBySub.get(s.id) || []
            setSelChildCats((prevCh) => {
              const nch = new Set(prevCh)
              ch.forEach((c) => nch.delete(c.id))
              return nch
            })
          })
          return ns
        })
      } else {
        next.add(mid)
      }
      return next
    })
    markDirty()
  }

  const toggleSub = (sid) => {
    setSelSubCats((prev) => {
      const next = new Set(prev)
      if (next.has(sid)) {
        next.delete(sid)
        const ch = childrenBySub.get(sid) || []
        setSelChildCats((prevCh) => {
          const nch = new Set(prevCh)
          ch.forEach((c) => nch.delete(c.id))
          return nch
        })
      } else {
        const main = subToMain.get(sid)
        if (main != null) setSelMainCats((mPrev) => new Set([...mPrev, main]))
        next.add(sid)
      }
      return next
    })
    markDirty()
  }

  const toggleChild = (cid) => {
    setSelChildCats((prev) => {
      const next = new Set(prev)
      if (next.has(cid)) next.delete(cid)
      else {
        const sid = childToSub.get(cid)
        const mid = sid != null ? subToMain.get(sid) : null
        if (sid != null) setSelSubCats((sPrev) => new Set([...sPrev, sid]))
        if (mid != null) setSelMainCats((mPrev) => new Set([...mPrev, mid]))
        next.add(cid)
      }
      return next
    })
    markDirty()
  }

  // Visible lists & flags
  const visibleSubs = useMemo(() => [...selMainCats].flatMap((mid) => subsByMain.get(mid) || []), [selMainCats, subsByMain])
  const hasVisibleSubs = visibleSubs.length > 0

  const visibleChildren = useMemo(() => [...selSubCats].flatMap((sid) => childrenBySub.get(sid) || []), [selSubCats, childrenBySub])
  const hasVisibleChildren = visibleChildren.length > 0

  // Derived counts
  const selectedCount = selectedProductIds.size
  const groupsCount = selBrands.size + selCollections.size + selMainCats.size + selSubCats.size + selChildCats.size

  const canProceedTarget = selectedCount > 0 || groupsCount > 0
  const canProceedMethod = !!selectedMethod

  // Step handlers
  const goForward = () => {
    if (step === 'target' && canProceedTarget) setStep('method')
    else if (step === 'method' && canProceedMethod) setStep('form')
  }
  const goBackFromMethod = () => setStep('target')
  const goBackFromForm = () => setStep('method')

  // Fixed-height + expand controls (per card footer only)
  const [catExpanded, setCatExpanded] = useState(false)
  const [brandExpanded, setBrandExpanded] = useState(false)
  const [colExpanded, setColExpanded] = useState(false)

  // Category footer visibility (only if >10 total items across visible columns)
  const totalCatCount = (mains?.length || 0) + visibleSubs.length + visibleChildren.length
  const showCategoryFooter = totalCatCount > 10

  // ---------- Build arrays of selected target IDs to pass to child ----------
  // Keep numeric ID arrays for payload
  const targetProducts = useMemo(() => [...selectedProductIds].map(Number).filter(Number.isFinite), [selectedProductIds])

  const targetBrands = useMemo(
    () => [...selBrands].map((name) => Number(brandNameToId.get(name))).filter(Number.isFinite),
    [selBrands, brandNameToId],
  )

  const targetCollections = useMemo(
    () => [...selCollections].map((name) => Number(collectionNameToId.get(name))).filter(Number.isFinite),
    [selCollections, collectionNameToId],
  )

  // === FIXED: Only send deepest selected category level ===
  const targetCategories = useMemo(() => {
    // If any child is selected → return only children
    if (selChildCats.size > 0) {
      return Array.from(selChildCats).map(Number).filter(Number.isFinite)
    }
    // Else if any sub is selected → return only subs
    if (selSubCats.size > 0) {
      return Array.from(selSubCats).map(Number).filter(Number.isFinite)
    }
    // Else return mains
    return Array.from(selMainCats).map(Number).filter(Number.isFinite)
  }, [selChildCats, selSubCats, selMainCats])

  // Helper to get category label by id (to show labels instead of ids)
  const catIdToLabel = useMemo(() => {
    const m = new Map()
    ;(mains || []).forEach((x) => m.set(x.id, x.label))
    for (const [k, arr] of subsByMain.entries()) {
      arr.forEach((s) => m.set(s.id, s.label))
    }
    for (const [k, arr] of childrenBySub.entries()) {
      arr.forEach((c) => m.set(c.id, c.label))
    }
    return m
  }, [mains, subsByMain, childrenBySub])

  // ------------------ NEW: Build target objects (id + title/name) for UI ------------------
  // Products (use selectedProductMap when available, fallback to ID string)
  const targetProductsForUI = useMemo(() => {
    return [...selectedProductIds].map((id) => {
      const title = selectedProductMap.get(id) || String(id)
      return { id, title }
    })
  }, [selectedProductIds, selectedProductMap])

  // Brands: selBrands contains names; we have brandNameToId map and brandList
  const targetBrandsForUI = useMemo(() => {
    return [...selBrands].map((name) => {
      const id = brandNameToId.get(name)
      return { id: id ?? name, name }
    })
  }, [selBrands, brandNameToId])

  // Collections
  const targetCollectionsForUI = useMemo(() => {
    return [...selCollections].map((name) => {
      const id = collectionNameToId.get(name)
      return { id: id ?? name, name }
    })
  }, [selCollections, collectionNameToId])

  // Categories: prefer label from catIdToLabel
  const targetCategoriesForUI = useMemo(() => {
    // mirror logic used for payload: deepest-level only
    const ids = selChildCats.size > 0 ? Array.from(selChildCats) : selSubCats.size > 0 ? Array.from(selSubCats) : Array.from(selMainCats)
    return ids.map((id) => ({ id, name: catIdToLabel.get(Number(id)) || String(id) }))
  }, [selChildCats, selSubCats, selMainCats, catIdToLabel])

  // -------------------- Render --------------------
  return (
    <div className="create-mid">
      {/* {isNavigating && (
  <div className="nav-overlay">
    <div className="nav-box">
      <div className="dot-loader">
        <span />
        <span />
        <span />
      </div>
      <div className="nav-text">Navigating…</div>
    </div>
  </div>
)} */}

      {/* STEP 1: TARGET SELECTION */}
      {step === 'target' && (
        <Card className="soft-card">
          <Card.Header className="bg-white d-flex flex-wrap align-items-center justify-content-between">
            <div className="header-left">
              <Card.Title className="mb-0">Target Selection</Card.Title>
              <small className="text-muted">Choose products directly or define product groups.</small>
            </div>
            <div className="header-right d-flex gap-2">
              <Badge bg="light" text="dark" className="border">
                Products: <strong className="ms-1">{selectedCount}</strong>
              </Badge>
              <Badge bg="light" text="dark" className="border">
                Groups: <strong className="ms-1">{groupsCount}</strong>
              </Badge>
            </div>
          </Card.Header>

          <Card.Body className="pt-0">
            <Tabs
              activeKey={activeKey}
              onSelect={(k) => setActiveKey(k || 'product')}
              className="pt-3 nav-sections"
              mountOnEnter
              unmountOnExit={false}>
              {/* SPECIFIC PRODUCT */}
              <Tab
                eventKey="product"
                title={
                  <span className="d-inline-flex align-items-center">
                    <Icon icon="solar:package-bold-duotone" className="me-2" width={16} />
                    Specific Product
                  </span>
                }>
                <section className="section-block">
                  <Row className="g-2 align-items-center mb-2">
                    <Col lg={7}>
                      <div className="searchbar">
                        <Icon icon="solar:magnifier-linear" width={18} />
                        <Form.Control
                          type="search"
                          placeholder="Search products by name or ID"
                          value={prodQuery}
                          onChange={(e) => {
                            setProdQuery(e.target.value)
                            markDirty()
                          }}
                        />
                      </div>
                      <small className="text-muted">
                        Type to search. Then tick products from results.
                        {isSearching ? ' Searching…' : ''}
                        {searchError ? ` — ${String(searchError)}` : ''}
                      </small>
                    </Col>
                    <Col lg="auto" className="ms-auto d-flex gap-2">
                      <Button
                        size="sm"
                        variant="outline-secondary"
                        onClick={selectAllFiltered}
                        disabled={!debouncedQ || filteredProducts.length === 0}>
                        Select All (results)
                      </Button>
                      <Button
                        size="sm"
                        variant="outline-secondary"
                        onClick={clearAllFiltered}
                        disabled={!debouncedQ || filteredProducts.length === 0}>
                        Clear (results)
                      </Button>
                    </Col>
                  </Row>

                  {debouncedQ ? (
                    <div className="results-list bordered">
                      {filteredProducts.length === 0 && !isSearching ? (
                        <div className="result-empty text-muted py-4 text-center">
                          <Icon icon="solar:box-linear" width={22} className="mb-2 d-block mx-auto" />
                          No results for “{prodQuery}”.
                        </div>
                      ) : (
                        <ul className="result-ul">
                          {filteredProducts.map((p) => (
                            <li key={p.id} className="result-item">
                              <Form.Check
                                type="checkbox"
                                checked={selectedProductIds.has(p.id)}
                                onChange={() => toggleProduct(p.id, p.title)}
                                label={
                                  <span className="d-inline-flex align-items-center gap-2">
                                    <Badge bg="secondary" className="rounded-pill">
                                      {p.id}
                                    </Badge>
                                    <span className="fw-semibold">{p.title}</span>
                                  </span>
                                }
                              />
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ) : (
                    <div className="text-muted small pt-1">Start typing to see results…</div>
                  )}

                  {selectedProductIds.size > 0 && (
                    <div className="mt-3">
                      <small className="text-muted d-block mb-1">Selected products:</small>
                      <div className="d-flex flex-wrap gap-2">
                        {[...selectedProductIds].map((id) => (
                          <Badge key={id} bg="light" text="dark" className="border fw-normal">
                            {selectedProductMap.get(id) || id}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </section>
              </Tab>

              {/* PRODUCT GROUPS */}
              <Tab
                eventKey="groups"
                title={
                  <span className="d-inline-flex align-items-center">
                    <Icon icon="solar:layers-bold-duotone" className="me-2" width={16} />
                    Product Groups
                  </span>
                }>
                <section className="section-block">
                  {loadingGroups ? (
                    <div className="d-flex align-items-center gap-2 py-4">
                      <Spinner animation="border" size="sm" />
                      <span className="text-muted">Loading groups…</span>
                    </div>
                  ) : (
                    <>
                      {/* ---- Categories (3 levels) ---- */}
                      <div className={`group-card fixed-card ${catExpanded ? 'expanded' : ''} mb-4`}>
                        <div className="group-head">
                          <h6 className="mb-0">Categories (3 levels)</h6>
                          <div className="d-flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                setSelMainCats(new Set(mains.map((m) => m.id)))
                                markDirty()
                              }}>
                              All Main
                            </Button>
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                setSelMainCats(new Set())
                                setSelSubCats(new Set())
                                setSelChildCats(new Set())
                                markDirty()
                              }}>
                              Clear Main
                            </Button>
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                const visibleSubs = [...selMainCats].flatMap((mid) => subsByMain.get(mid) || []).map((s) => s.id)
                                if (!visibleSubs.length) return
                                setSelSubCats(new Set(visibleSubs))
                                markDirty()
                              }}
                              disabled={!hasVisibleSubs}>
                              All Visible Subs
                            </Button>
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                setSelSubCats(new Set())
                                setSelChildCats(new Set())
                                markDirty()
                              }}
                              disabled={!hasVisibleSubs && !selSubCats.size}>
                              Clear Subs
                            </Button>
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                const visibleChildren = [...selSubCats].flatMap((sid) => childrenBySub.get(sid) || []).map((c) => c.id)
                                if (!visibleChildren.length) return
                                setSelChildCats(new Set(visibleChildren))
                                markDirty()
                              }}
                              disabled={!hasVisibleChildren}>
                              All Visible Children
                            </Button>
                            <Button
                              size="sm"
                              variant="outline-secondary"
                              onClick={() => {
                                setSelChildCats(new Set())
                                markDirty()
                              }}
                              disabled={!hasVisibleChildren && !selChildCats.size}>
                              Clear Children
                            </Button>
                          </div>
                        </div>

                        <div className="group-body scrollable">
                          <Row className="g-3">
                            {/* Level 1: Main */}
                            <Col md={hasVisibleSubs || hasVisibleChildren ? 4 : 12}>
                              <div className="level-col">
                                <div className="level-head">
                                  <strong>Main</strong>
                                </div>
                                <div className="level-list">
                                  {mains.map((m) => (
                                    <Form.Check
                                      key={m.id}
                                      type="checkbox"
                                      id={`main-${m.id}`}
                                      label={m.label}
                                      checked={selMainCats.has(m.id)}
                                      onChange={() => toggleMain(m.id)}
                                    />
                                  ))}
                                </div>
                              </div>
                            </Col>

                            {/* Level 2: Subs */}
                            {hasVisibleSubs && (
                              <Col md={hasVisibleChildren ? 4 : 8}>
                                <div className="level-col">
                                  <div className="level-head">
                                    <strong>Sub</strong>
                                  </div>
                                  <div className="level-list">
                                    {visibleSubs.map((s) => (
                                      <Form.Check
                                        key={s.id}
                                        type="checkbox"
                                        id={`sub-${s.id}`}
                                        label={s.label}
                                        checked={selSubCats.has(s.id)}
                                        onChange={() => toggleSub(s.id)}
                                      />
                                    ))}
                                  </div>
                                </div>
                              </Col>
                            )}

                            {/* Level 3: Children */}
                            {hasVisibleChildren && (
                              <Col md={4}>
                                <div className="level-col">
                                  <div className="level-head">
                                    <strong>Child</strong>
                                  </div>
                                  <div className="level-list">
                                    {visibleChildren.map((c) => (
                                      <Form.Check
                                        key={c.id}
                                        type="checkbox"
                                        id={`child-${c.id}`}
                                        label={c.label}
                                        checked={selChildCats.has(c.id)}
                                        onChange={() => toggleChild(c.id)}
                                      />
                                    ))}
                                  </div>
                                </div>
                              </Col>
                            )}
                          </Row>
                        </div>

                        {selMainCats.size || selSubCats.size || selChildCats.size ? (
                          <div className="px-3 py-2">
                            <small className="text-muted d-block mb-1">Selected categories:</small>
                            <div className="d-flex flex-wrap gap-2">
                              {[...selMainCats].map((v) => (
                                <Badge key={`m-${v}`} bg="light" text="dark" className="border">
                                  {catIdToLabel.get(v) ?? String(v)}
                                </Badge>
                              ))}
                              {[...selSubCats].map((v) => (
                                <Badge key={`s-${v}`} bg="light" text="dark" className="border">
                                  {catIdToLabel.get(v) ?? String(v)}
                                </Badge>
                              ))}
                              {[...selChildCats].map((v) => (
                                <Badge key={`c-${v}`} bg="light" text="dark" className="border">
                                  {catIdToLabel.get(v) ?? String(v)}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        ) : null}

                        {showCategoryFooter && (
                          <div className="group-footer">
                            <Button size="sm" variant="outline-secondary" onClick={() => setCatExpanded((v) => !v)}>
                              {catExpanded ? 'Show less' : 'Show more'}
                            </Button>
                          </div>
                        )}
                      </div>

                      {/* ---- Brands & Collections (each card has its own scroll + single Show more) ---- */}
                      <Row className="g-4">
                        {/* Brands */}
                        <Col md={6}>
                          <div className={`group-card fixed-card ${brandExpanded ? 'expanded' : ''}`}>
                            <div className="group-head">
                              <h6 className="mb-0">Brands</h6>
                              <div className="d-flex gap-2">
                                <Button size="sm" variant="outline-secondary" onClick={selectAll(brands, setSelBrands)} disabled={!brands.length}>
                                  All
                                </Button>
                                <Button size="sm" variant="outline-secondary" onClick={clearAll(setSelBrands)}>
                                  Clear
                                </Button>
                              </div>
                            </div>
                            <div className="group-body scrollable">
                              {isFetchingBrands && !brandList.length ? (
                                <div className="d-flex align-items-center gap-2 py-2">
                                  <Spinner animation="border" size="sm" />
                                  <span className="text-muted">Loading…</span>
                                </div>
                              ) : null}

                              {brands.map((b) => (
                                <Form.Check
                                  key={b}
                                  type="checkbox"
                                  id={`brand-${b}`}
                                  label={b}
                                  checked={selBrands.has(b)}
                                  onChange={() => toggleSet(setSelBrands)(b)}
                                />
                              ))}
                            </div>
                            {showBrandFooter && (
                              <div className="group-footer">
                                <Button size="sm" variant="outline-secondary" onClick={onShowMoreBrands} disabled={isFetchingBrands}>
                                  {isFetchingBrands ? 'Loading…' : 'Show more'}
                                </Button>
                              </div>
                            )}
                          </div>
                        </Col>

                        {/* Collections */}
                        <Col md={6}>
                          <div className={`group-card fixed-card ${colExpanded ? 'expanded' : ''}`}>
                            <div className="group-head">
                              <h6 className="mb-0">Collections</h6>
                              <div className="d-flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline-secondary"
                                  onClick={selectAll(collections, setSelCollections)}
                                  disabled={!collections.length}>
                                  All
                                </Button>
                                <Button size="sm" variant="outline-secondary" onClick={clearAll(setSelCollections)}>
                                  Clear
                                </Button>
                              </div>
                            </div>
                            <div className="group-body scrollable">
                              {isFetchingCollections && !collectionList.length ? (
                                <div className="d-flex align-items-center gap-2 py-2">
                                  <Spinner animation="border" size="sm" />
                                  <span className="text-muted">Loading…</span>
                                </div>
                              ) : null}

                              {collections.map((c) => (
                                <Form.Check
                                  key={c}
                                  type="checkbox"
                                  id={`col-${c}`}
                                  label={c}
                                  checked={selCollections.has(c)}
                                  onChange={() => toggleSet(setSelCollections)(c)}
                                />
                              ))}
                            </div>
                            {showCollectionFooter && (
                              <div className="group-footer">
                                <Button size="sm" variant="outline-secondary" onClick={onShowMoreCollections} disabled={isFetchingCollections}>
                                  {isFetchingCollections ? 'Loading…' : 'Show more'}
                                </Button>
                              </div>
                            )}
                          </div>
                        </Col>
                      </Row>

                      {selBrands.size || selCollections.size ? (
                        <div className="mt-3">
                          <small className="text-muted d-block mb-1">Selected:</small>
                          <div className="d-flex flex-wrap gap-2">
                            {[...selBrands].map((v) => (
                              <Badge key={`b-${v}`} bg="light" text="dark" className="border">
                                {v}
                              </Badge>
                            ))}
                            {[...selCollections].map((v) => (
                              <Badge key={`l-${v}`} bg="light" text="dark" className="border">
                                {v}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ) : null}
                    </>
                  )}
                </section>
              </Tab>
            </Tabs>

            {/* Bottom Go for step 1 */}
            <div className="bottom-actions">
              <Button size="lg" className="btn-go" disabled={!canProceedTarget} onClick={goForward}>
                Go
                <Icon icon="solar:arrow-right-linear" width={18} className="ms-2" />
              </Button>
            </div>
          </Card.Body>
        </Card>
      )}

      {/* STEP 2: METHOD SELECTION */}
      {step === 'method' && (
        <Card className="soft-card">
          <Card.Header className="bg-white">
            <Card.Title className="mb-0">Select Discount Method</Card.Title>
            <small className="text-muted">Choose how the discount is applied.</small>
          </Card.Header>

          <Card.Body>
            <div className="method-grid">
              {/* General Discount */}
              <label
                className={`method-card ${selectedMethod === 'general' ? 'active' : ''}`}
                onClick={() => {
                  setSelectedMethod('general')
                  markDirty()
                }}>
                <div className="method-icon">
                  <Icon icon="solar:ticket-sale-bold-duotone" width={28} />
                </div>
                <div className="method-content">
                  <div className="method-title">General Discount</div>
                  <div className="method-desc">Automatic discount without codes. Good for broad promos.</div>
                </div>
                <div className="method-select">
                  <span className={`radio-dot ${selectedMethod === 'general' ? 'on' : ''}`} />
                </div>
              </label>

              {/* Buy X Get Y */}
              <label
                className={`method-card ${selectedMethod === 'bxgy' ? 'active' : ''}`}
                onClick={() => {
                  setSelectedMethod('bxgy')
                  markDirty()
                }}>
                <div className="method-icon">
                  <Icon icon="solar:cart-large-2-bold-duotone" width={28} />
                </div>
                <div className="method-content">
                  <div className="method-title">Buy X Get Y Offer</div>
                  <div className="method-desc">Give free or discounted items when conditions are met.</div>
                </div>
                <div className="method-select">
                  <span className={`radio-dot ${selectedMethod === 'bxgy' ? 'on' : ''}`} />
                </div>
              </label>
            </div>

            <div className="bottom-actions between">
              <Button variant="outline-secondary" onClick={goBackFromMethod}>
                <Icon icon="solar:arrow-left-linear" width={18} className="me-2" />
                Back
              </Button>
              <Button size="lg" className="btn-go" disabled={!canProceedMethod} onClick={goForward}>
                Go
                <Icon icon="solar:arrow-right-linear" width={18} className="ms-2" />
              </Button>
            </div>
          </Card.Body>
        </Card>
      )}

      {/* STEP 3: FORM */}
      {step === 'form' && (
        <>
          {selectedMethod === 'general' && (
            <GeneralDiscount
              onDirty={markDirty}
              // PASS UI-friendly objects (id + title/name) — child normalizer can still accept ids or objects
              targetProducts={targetProductsForUI}
              targetBrands={targetBrandsForUI}
              targetCollections={targetCollectionsForUI}
              targetCategories={targetCategoriesForUI}
            />
          )}

          {selectedMethod === 'bxgy' && (
            <BuyXGetY
              onDirty={markDirty}
              targetProducts={targetProductsForUI}
              targetBrands={targetBrandsForUI}
              targetCollections={targetCollectionsForUI}
              targetCategories={targetCategoriesForUI}
            />
          )}
        </>
      )}

      {/* Leave-without-saving Modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Styles */}
      <style jsx>{`
        .create-mid {
          max-width: 1100px;
          margin: 0 auto;
        }

        .soft-card {
          --border: 1px solid rgba(0, 0, 0, 0.06);
          --shadow: 0 1px 0 rgba(22, 29, 37, 0.05), 0 8px 24px rgba(22, 29, 37, 0.06);
          border: var(--border);
          border-radius: 16px;
          box-shadow: var(--shadow);
          margin-bottom: 16px;
        }
        .header-left .card-title {
          font-weight: 700;
        }
        .nav-sections :global(.nav-link) {
          font-weight: 600;
          border: none;
          color: #111827;
        }
        .nav-sections :global(.nav-link.active) {
          color: #111827;
          position: relative;
        }
        .nav-sections :global(.nav-link.active)::after {
          content: '';
          position: absolute;
          left: 0;
          right: 0;
          bottom: -1px;
          height: 2px;
          background: #111827;
          border-radius: 2px;
        }
        .section-block {
          padding-top: 0.75rem;
        }

        .searchbar {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 12px;
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          background: #fff;
        }
        .searchbar :global(input.form-control) {
          border: none;
          padding: 0;
          box-shadow: none;
        }

        .bordered {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          overflow: hidden;
        }
        .results-list {
          border-radius: 12px;
          background: #fff;
        }
        .result-ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        .result-item {
          padding: 10px 12px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
        }
        .result-item:last-child {
          border-bottom: none;
        }
        .result-empty {
          font-size: 0.95rem;
        }

        .group-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
        }
        .group-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px;
          border-bottom: 1px solid rgba(0, 0, 0, 0.06);
        }
        .group-body {
          padding: 12px;
        }
        .group-footer {
          padding: 10px 12px;
          border-top: 1px solid rgba(0, 0, 0, 0.06);
          background: #fafafa;
        }

        /* Fixed size cards with internal scroll + expandable height */
        .fixed-card {
          --card-fixed-h: 360px;
          --card-expanded-h: 520px;
          height: var(--card-fixed-h);
          display: flex;
          flex-direction: column;
        }
        .fixed-card.expanded {
          height: var(--card-expanded-h);
        }
        .fixed-card .group-head {
          flex: 0 0 auto;
        }
        .fixed-card .group-body {
          flex: 1 1 auto;
        }
        .fixed-card .group-footer {
          flex: 0 0 auto;
        }
        .scrollable {
          overflow: auto;
        }

        .level-col {
          border: 1px dashed rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px;
          background: #fafafa;
        }
        .level-head {
          font-size: 0.9rem;
          margin-bottom: 6px;
          color: #111827;
        }
        .level-list {
          display: grid;
          gap: 6px;
        }

        .bottom-actions {
          display: flex;
          justify-content: flex-end;
          margin-top: 16px;
          gap: 8px;
        }
        .bottom-actions.between {
          justify-content: space-between;
        }
        .btn-go {
          border-radius: 999px;
          padding: 10px 18px;
          font-weight: 700;
        }

        /* ---------- Method Selection ---------- */
        .method-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 12px;
        }
        @media (min-width: 768px) {
          .method-grid {
            grid-template-columns: 1fr;
          }
        }
        .method-card {
          display: grid;
          grid-template-columns: 52px 1fr 28px;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          background: #fff;
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          cursor: pointer;
          transition:
            border-color 0.12s ease,
            box-shadow 0.12s ease,
            background 0.12s ease;
        }
        .method-card:hover {
          border-color: rgba(0, 0, 0, 0.18);
          background: #fafafa;
        }
        .method-card.active {
          border-color: #111827;
          box-shadow: 0 0 0 3px rgba(17, 24, 39, 0.12);
          background: #f7f8fb;
        }
        .method-icon {
          height: 52px;
          width: 52px;
          border-radius: 12px;
          display: grid;
          place-items: center;
          background: #f3f4f6;
        }
        .method-content {
          display: grid;
          gap: 2px;
        }
        .method-title {
          font-weight: 700;
          color: #111827;
        }
        .method-desc {
          font-size: 0.92rem;
          color: #6b7280;
        }

        .method-select {
          display: flex;
          justify-content: flex-end;
        }
        .radio-dot {
          width: 18px;
          height: 18px;
          border-radius: 999px;
          border: 2px solid #9ca3af;
          display: inline-block;
          transition:
            background 0.12s ease,
            border-color 0.12s ease,
            box-shadow 0.12s ease;
        }
        .radio-dot.on {
          background: #111827;
          border-color: #111827;
          box-shadow: 0 0 0 3px rgba(17, 24, 39, 0.15);
        }
        /* ================= Navigating Overlay (No Blur) ================= */

        .nav-overlay {
          position: fixed;
          inset: 0;
          z-index: 99999;

          /* Light dim only — NO blur */
          background: rgba(255, 255, 255, 0.85);

          display: flex;
          align-items: center;
          justify-content: center;

          pointer-events: all;
        }

        .nav-box {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 14px;

          padding: 22px 28px;
          border-radius: 14px;

          background: #ffffff;
          box-shadow:
            0 12px 28px rgba(0, 0, 0, 0.12),
            0 0 0 1px rgba(0, 0, 0, 0.04);

          animation: navFadeIn 0.15s ease-out;
        }

        /* -------- Dotted Blue Loader -------- */
        .dot-loader {
          display: flex;
          gap: 8px;
        }

        .dot-loader span {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background-color: #2563eb; /* Tailwind blue-600 */
          opacity: 0.25;
          animation: dotPulse 1.4s infinite ease-in-out both;
        }

        .dot-loader span:nth-child(1) {
          animation-delay: -0.32s;
        }
        .dot-loader span:nth-child(2) {
          animation-delay: -0.16s;
        }
        .dot-loader span:nth-child(3) {
          animation-delay: 0s;
        }

        @keyframes dotPulse {
          0%,
          80%,
          100% {
            opacity: 0.25;
          }
          40% {
            opacity: 1;
          }
        }

        .nav-text {
          font-size: 0.9rem;
          font-weight: 600;
          color: #1e3a8a; /* blue-800 */
          letter-spacing: 0.02em;
        }

        /* Subtle entrance */
        @keyframes navFadeIn {
          from {
            opacity: 0;
            transform: translateY(4px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  )
}
