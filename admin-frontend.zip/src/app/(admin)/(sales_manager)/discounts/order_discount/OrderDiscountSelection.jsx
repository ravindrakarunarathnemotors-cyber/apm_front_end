'use client'

import { useState } from 'react'
import { Card, Button } from 'react-bootstrap'
import { Icon } from '@iconify/react'

// Import your actual components
import GeneralDiscount from '@/app/(admin)/(sales_manager)/discounts/order_discount/order_discount_types/GeneralDiscount'
import DiscountCode from '@/app/(admin)/(sales_manager)/discounts/order_discount/order_discount_types/DiscountCode'
import ShippingDiscount from '@/app/(admin)/(sales_manager)/discounts/order_discount/order_discount_types/ShippingDiscount'
import PaymentMethod from '@/app/(admin)/(sales_manager)/discounts/order_discount/order_discount_types/PaymentMethod'

export default function OrderDiscountTypeChooser() {
  const [selected, setSelected] = useState(null)
  const [showComponent, setShowComponent] = useState(false)

  const options = [
    {
      key: 'GeneralDiscount',
      title: 'General Discount',
      sub: 'Order-wide conditions or thresholds',
      icon: 'solar:sale-bold-duotone',
      component: <GeneralDiscount />,
    },
    {
      key: 'DiscountCode',
      title: 'Discount Code',
      sub: 'Customers enter a code at checkout',
      icon: 'solar:ticket-bold-duotone',
      component: <DiscountCode />,
    },
    {
      key: 'ShippingDiscount',
      title: 'Shipping Discount',
      sub: 'Reduce / waive shipping fees',
      icon: 'solar:delivery-bold-duotone',
      component: <ShippingDiscount />,
    },
    {
      key: 'PaymentMethod',
      title: 'Payment Method',
      sub: 'Discounts for certain payment types',
      icon: 'solar:card-2-bold-duotone',
      component: <PaymentMethod />,
    },
  ]

  const go = () => {
    if (selected) setShowComponent(true)
  }

  const handleBack = () => {
    setShowComponent(false)
    setSelected(null)
  }

  const selectedOption = options.find((o) => o.key === selected)

  return (
    <Card className="soft-card p-3">
      {!showComponent ? (
        <>
          <h5 className="mb-3 fw-bold text-dark">Select Order Discount Type</h5>
          <div className="chooser-vertical">
            {options.map((o) => (
              <button type="button" key={o.key} className={`chooser-row ${selected === o.key ? 'active' : ''}`} onClick={() => setSelected(o.key)}>
                <div className="chooser-icon">
                  <Icon icon={o.icon} width={28} />
                </div>
                <div className="chooser-body">
                  <div className="chooser-title">{o.title}</div>
                  <div className="chooser-sub">{o.sub}</div>
                </div>
                <Icon icon="solar:arrow-right-linear" width={18} className="ms-auto text-muted" />
              </button>
            ))}
          </div>

          <div className="d-flex justify-content-end mt-3">
            <Button onClick={go} disabled={!selected}>
              Go
            </Button>
          </div>
        </>
      ) : (
        <>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="m-0 fw-semibold">{selectedOption?.title}</h5>
            <Button variant="outline-secondary" size="sm" onClick={handleBack}>
              ← Back
            </Button>
          </div>
          <div className="p-2">{selectedOption?.component}</div>
        </>
      )}

      <style jsx>{`
        .chooser-vertical {
          display: grid;
          gap: 10px;
        }
        .chooser-row {
          display: grid;
          grid-template-columns: 48px 1fr 18px;
          gap: 12px;
          align-items: center;
          padding: 12px;
          border-radius: 12px;
          background: #fff;
          border: 1px solid rgba(0, 0, 0, 0.08);
          text-align: left;
          transition: 0.15s;
        }
        .chooser-row:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 18px rgba(0, 0, 0, 0.06);
        }
        .chooser-row.active {
          border-color: #111827;
          box-shadow: 0 0 0 3px rgba(17, 24, 39, 0.12);
        }
        .chooser-icon {
          height: 48px;
          width: 48px;
          border-radius: 12px;
          display: grid;
          place-items: center;
          background: #f3f4f6;
        }
        .chooser-title {
          font-weight: 700;
          color: #111827;
        }
        .chooser-sub {
          color: #6b7280;
          font-size: 0.92rem;
        }
      `}</style>
    </Card>
  )
}
