'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useRouter } from 'next/navigation'
import Swal from 'sweetalert2'
import { useAddOrderDiscountMutation, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice' // adjust path if needed

export default function ShippingDiscount() {
  const router = useRouter()

  // ===================== Unsaved changes guard =====================
  const [dirty, setDirty] = useState(false)
  const markDirty = () => setDirty(true)

  const [confirmOpen, setConfirmOpen] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'link' | 'router' | 'history' | 'reload'
  const allowNavRef = useRef(false)

  let RouterEvents = null
  try {
    const pages = require('next/router')
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}

  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setConfirmOpen(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setConfirmOpen(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setConfirmOpen(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const reloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!reloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setConfirmOpen(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  useEffect(() => {
    const handler = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [dirty])

  const attemptNavigate = (action) => {
    if (!dirty) {
      if (action === 'history') history.back()
      else if (typeof action === 'string') router.push(action)
      return
    }
    if (action === 'history') {
      pendingActionRef.current = 'history'
      setPendingHref(null)
    } else if (typeof action === 'string') {
      pendingActionRef.current = 'router'
      setPendingHref(action)
    }
    setConfirmOpen(true)
  }

  const discardAndGo = () => {
    setConfirmOpen(false)
    setDirty(false)
    allowNavRef.current = true
    const action = pendingActionRef.current
    const href = pendingHref
    if (action === 'history') history.back()
    else if ((action === 'router' || action === 'link') && href) router.push(href)
    else if (action === 'reload') window.location.reload()
  }

  // ===================== Helpers =====================
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  // ===================== Form (with requested behavior) =====================
  const [title, setTitle] = useState('') // required (limit 100)
  const handleTitleInput = (v) => {
    setTitle(v.slice(0, 100))
    markDirty()
  }

  // Value type: Percentage or Fixed
  const [valueType, setValueType] = useState('percentage')
  const [value, setValue] = useState(10)

  const [enableAmounts, setEnableAmounts] = useState(true)
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  // Customer Eligibility — guest toggle always enabled
  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  // Usage Limit (total-uses removed entirely)
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('')

  // Dates
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ---------- minimal time helpers/state (must be declared after date/time state) ----------
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  }
  const timeToMinutes = (t) => {
    if (!t) return NaN
    const [hh, mm] = String(t).split(':').map(Number)
    return Number.isFinite(hh) && Number.isFinite(mm) ? hh * 60 + mm : NaN
  }
  const minutesToTime = (m) => {
    if (!Number.isFinite(m)) return ''
    const hh = Math.floor(m / 60) % 24
    const mm = m % 60
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
  }

  // if startDate is today, make startTime min = now and bump startTime if earlier
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      if (startTime && timeToMinutes(startTime) < timeToMinutes(now)) {
        setStartTime(now)
      }
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'

    // same-day end: require end > start => min = startTime + 1 minute
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        min = minutesToTime(s + 1)
      }
    } else if (hasEnd && endDate === todayISO()) {
      // end is today (but not same as start): disallow past times
      min = nowTimeRounded()
    }

    setEndTimeMin(min)

    // clear invalid endTime
    if (endTime && Number.isFinite(timeToMinutes(endTime)) && Number.isFinite(timeToMinutes(min)) && timeToMinutes(endTime) < timeToMinutes(min)) {
      setEndTime('')
    }
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // Keep endDate >= startDate when end is enabled
  useEffect(() => {
    if (!hasEnd || !startDate || !endDate) return
    if (endDate < startDate) setEndDate(startDate)
  }, [startDate, endDate, hasEnd])

  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  const validate = () => {
    const e = {}
    if (!title.trim()) e.title = 'Title is required.'
    if (title.trim().length > 100) e.title = 'Title must be 100 characters or fewer.'
    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'

    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
    } else {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (enableAmounts) {
      if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase is required.'
      // Max Discount is only relevant for percentage; make it required when percentage + enabled
      if (valueType === 'percentage') {
        if (maxDiscountAmount === '' || Number(maxDiscountAmount) <= 0) {
          e.maxDiscountAmount = 'Maximum discount amount is required.'
        }
      }
    }

    // Usage limits (no total-uses)
    if (limitPerAccount && (perAccountUses === '' || Number(perAccountUses) < 1)) {
      e.perAccount = 'Usage per account is required.'
    }

    // Dates
    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // same-day end time checks
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        // end date is today (but not same as start) — ensure endTime is not before now
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // ========= RTK hook & helpers =========
  const [addOrderDiscount] = useAddOrderDiscountMutation()
  // move currency hook BEFORE any useMemo that references it
  const { data: currency = 'LKR', isLoading: currencyLoading } = useGetDiscountCurrencyQuery()

  const joinDateTime = (d, t) => (d && t ? `${d}T${t}:00` : null)
  const toNumOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v))

  const valueSummary = useMemo(
    () => (valueType === 'percentage' ? `${Number(value || 0)}%` : `${currency || 'LKR'} ${Number(value || 0).toFixed(2)}`),
    [valueType, value, currency],
  )

  const onSave = async () => {
    if (!validate()) return
    setSaving(true)

    // SweetAlert loading
    Swal.fire({
      title: 'Saving discount…',
      allowEscapeKey: false,
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      // Map UI → backend payload for /discount-module/add-order-discounts
      const payload = {
        main_discount_type: 'order',
        discount_title: title,
        discount_value_type: valueType, // percentage | fixed
        discount_value: Number(value),

        min_max_purchase_discount_limits: !!enableAmounts,
        min_purchase_amount: enableAmounts ? toNumOrNull(minPurchase) : null,
        // Only send max_discount_amount for percentage (backend expects it only then)
        max_discount_amount: enableAmounts && valueType === 'percentage' ? toNumOrNull(maxDiscountAmount) : null,

        customer_eligibility: eligibility, // 'all' | 'new' | 'existing'
        is_guest_allowed: !!guestIncluded, // togglable even when 'all'

        // TOTAL uses removed
        usage_limit_per_customer: !!limitPerCustomerOnce,
        usage_limit_per_account: limitPerAccount ? toNumOrNull(perAccountUses) : null,

        status: 'active',
        start_date: joinDateTime(startDate, startTime),
        end_date: hasEnd ? joinDateTime(endDate, endTime) : null,

        discount_code: null, // shipping discount doesn't use codes
        order_discount_method: 'shipping', // IMPORTANT
        payment_method: null, // not used here
      }

      await addOrderDiscount(payload).unwrap()

      setSaving(false)
      setDirty(false)

      // wait for user to click OK, then notify parent to show list + refetch
      const res = await Swal.fire({
        icon: 'success',
        title: 'Discount saved',
        text: 'Shipping discount has been created successfully.',
        confirmButtonText: 'OK',
      })

      if (res.isConfirmed) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('discount:saved'))
        }
      }
    } catch (err) {
      console.error('Add order discount (shipping) failed:', err)
      setSaving(false)
      Swal.fire({
        icon: 'error',
        title: 'Save failed',
        text: err?.data?.error || err?.error || 'Please try again.',
        confirmButtonText: 'OK',
      })
    }
  }

  return (
    <>
      <Card className="soft-card">
        <Card.Header className="bg-white d-flex align-items-start justify-content-between">
          <div>
            <Card.Title className="mb-0">Shipping Discount</Card.Title>
            <small className="text-muted">Reduce or waive shipping cost based on conditions.</small>
          </div>
          <div className="d-flex gap-2">{/* optional nav buttons */}</div>
        </Card.Header>

        <Card.Body>
          <Row className="g-3">
            {/* LEFT: Form */}
            <Col lg={8}>
              {/* Title */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Title</span>
                </div>
                <div className="section-body">
                  <Form.Control placeholder="e.g. Free Shipping over $50" value={title} onChange={(e) => handleTitleInput(e.target.value)} required />
                  <div className="d-flex justify-content-between mt-1">
                    <small className="text-muted">{title.length}/100</small>
                    {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                  </div>
                </div>
              </section>

              {/* Discount Value (Percentage or Fixed) */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Value</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-perc"
                          name="val-type"
                          checked={valueType === 'percentage'}
                          onChange={() => {
                            setValueType('percentage')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Percentage</span>}
                          required
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-fixed"
                          name="val-type"
                          checked={valueType === 'fixed'}
                          onChange={() => {
                            setValueType('fixed')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                          required
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <InputGroup>
                        {valueType === 'percentage' ? (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="1"
                              max="100"
                              step="1"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                            />
                          </>
                        ) : (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">{currency || '-'}</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="0.01"
                              step="0.01"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                            />
                          </>
                        )}
                      </InputGroup>
                      {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Amount Limits */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Set Minimum Purchase &amp; Maximum Discount Amount</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={valueType === 'percentage' ? 6 : 7}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap">Minimum Purchase Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                        <Form.Control
                          type="number"
                          min="0"
                          step="0.01"
                          value={minPurchase}
                          onChange={(e) => {
                            setMinPurchase(e.target.value)
                            markDirty()
                          }}
                          required
                        />
                      </InputGroup>
                      {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                    </Col>

                    {valueType === 'percentage' && (
                      <Col md={6}>
                        <InputGroup>
                          <InputGroup.Text className="fw-semibold nowrap">Maximum Discount Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            value={maxDiscountAmount}
                            onChange={(e) => {
                              setMaxDiscountAmount(e.target.value)
                              markDirty()
                            }}
                            placeholder="Optional"
                            required
                          />
                        </InputGroup>
                        {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                      </Col>
                    )}
                  </Row>
                </div>
              </section>

              {/* Customer Eligibility (guest toggle always enabled) */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Customer Eligibility</span>
                </div>
                <div className="section-body">
                  <Row className="g-2 align-items-center">
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-all"
                        checked={eligibility === 'all'}
                        onChange={() => {
                          setEligibility('all')
                          markDirty()
                        }}
                        label="All Customers"
                        required
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-new"
                        checked={eligibility === 'new'}
                        onChange={() => {
                          setEligibility('new')
                          markDirty()
                        }}
                        label="New Customers"
                        required
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-existing"
                        checked={eligibility === 'existing'}
                        onChange={() => {
                          setEligibility('existing')
                          markDirty()
                        }}
                        label="Existing Customers"
                        required
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="checkbox"
                        id="elig-guest"
                        checked={!!guestIncluded}
                        onChange={(e) => {
                          setGuestIncluded(e.target.checked)
                          markDirty()
                        }}
                        label="Guest Customers"
                      />
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Usage Limit (mutually exclusive; always one selected; no "total uses") */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Usage Limit</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-customer"
                        checked={limitPerCustomerOnce}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Prevent deselecting if it would leave both unchecked
                          if (!checked && !limitPerAccount) return

                          setLimitPerCustomerOnce(checked)

                          if (checked) {
                            // make it exclusive
                            setLimitPerAccount(false)
                            // keep your prefill behavior intact
                            setPerAccountUses(2)
                          }

                          markDirty()
                        }}
                        label="Unlimited Discount Usage"
                      />
                    </Col>

                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-account"
                        checked={limitPerAccount}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Prevent deselecting if it would leave both unchecked
                          if (!checked && !limitPerCustomerOnce) return

                          setLimitPerAccount(checked)

                          if (checked) {
                            // make it exclusive
                            setLimitPerCustomerOnce(false)
                          } else {
                            // optional: reset when turned off
                            setPerAccountUses(2)
                          }

                          markDirty()
                        }}
                        label="Set Usage Limit Per Account"
                      />

                      {limitPerAccount && (
                        <div className="mt-2" style={{ maxWidth: 220 }}>
                          <Form.Control
                            type="number"
                            min="1"
                            step="1"
                            required
                            value={perAccountUses}
                            onChange={(e) => {
                              const v = Number(e.target.value || 1)
                              setPerAccountUses(v)
                              markDirty()
                            }}
                          />
                          {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                        </div>
                      )}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Active Dates */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Active Dates</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Date <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        required
                        min={todayISO()}
                        value={startDate}
                        onChange={(e) => {
                          const newStart = e.target.value
                          setStartDate(newStart)
                          markDirty()
                          // if start becomes today and startTime is earlier than now, bump it
                          if (newStart === todayISO() && startTime && timeToMinutes(startTime) < timeToMinutes(nowTimeRounded())) {
                            setStartTime(nowTimeRounded())
                          }
                          // ensure endDate not before startDate
                          if (hasEnd && endDate && endDate < newStart) setEndDate(newStart)
                        }}
                      />
                      {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                    </Col>
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Time <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="time"
                        required
                        value={startTime}
                        min={startTimeMin}
                        onChange={(e) => {
                          const newStart = e.target.value
                          setStartTime(newStart)
                          markDirty()
                          // if same-day end and endTime <= newStart, clear endTime so user re-selects
                          if (
                            hasEnd &&
                            endDate &&
                            startDate &&
                            endDate === startDate &&
                            endTime &&
                            timeToMinutes(endTime) <= timeToMinutes(newStart)
                          ) {
                            setEndTime('')
                          }
                        }}
                      />
                      {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                      {startTimeMin !== '00:00' && (
                        <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>
                      )}
                    </Col>
                    <Col md={12}>
                      <Form.Check
                        id="has-end"
                        type="checkbox"
                        className="mt-2"
                        checked={hasEnd}
                        onChange={(e) => {
                          const checked = e.target.checked
                          setHasEnd(checked)
                          markDirty()
                          if (checked) {
                            // suggest endDate and endTime to reduce clicks:
                            const suggestedEndDate = startDate || todayISO()
                            setEndDate(suggestedEndDate)
                            // friendly suggested endTime: startTime +1 hour if available, else now +1h
                            let suggested = ''
                            if (startTime && Number.isFinite(timeToMinutes(startTime))) {
                              suggested = minutesToTime(timeToMinutes(startTime) + 60)
                            } else {
                              suggested = minutesToTime(timeToMinutes(nowTimeRounded()) + 60)
                            }
                            setEndTime(suggested)
                          } else {
                            // clearing
                            setEndDate('')
                            setEndTime('')
                          }
                        }}
                        label="Set End Date"
                      />
                    </Col>
                    {hasEnd && (
                      <>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Date <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="date"
                            required
                            min={startDate || todayISO()}
                            value={endDate}
                            onChange={(e) => {
                              const newEnd = e.target.value
                              setEndDate(newEnd)
                              markDirty()
                              // if new end is same as start, and current endTime is less than allowed min, clear it
                              if (newEnd && startDate && newEnd === startDate && endTime && timeToMinutes(endTime) < timeToMinutes(endTimeMin)) {
                                setEndTime('')
                              }
                            }}
                          />
                          {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                        </Col>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Time <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="time"
                            required
                            value={endTime}
                            min={endTimeMin}
                            onChange={(e) => {
                              setEndTime(e.target.value)
                              markDirty()
                            }}
                          />
                          {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                          {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                            <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                          )}
                        </Col>
                      </>
                    )}
                  </Row>
                </div>
              </section>

              {/* Footer actions */}
              <div className="footer-actions">
                <Button
                  variant="outline-secondary"
                  onClick={async () => {
                    const res = await Swal.fire({
                      title: 'Discard changes?',
                      text: 'Do you want to discard the changes?',
                      icon: 'warning',
                      showCancelButton: true,
                      confirmButtonText: 'Discard',
                      cancelButtonText: 'Cancel',
                      confirmButtonColor: '#111827',
                    })

                    if (res.isConfirmed) {
                      // 🔥 notify global listeners (same event as save)
                      if (typeof window !== 'undefined') {
                        window.dispatchEvent(new CustomEvent('discount:saved'))
                      }
                    }
                  }}>
                  Discard
                </Button>

                <Button onClick={onSave} disabled={saving}>
                  {saving ? (
                    <>
                      <Spinner animation="border" size="sm" className="me-2" /> Saving…
                    </>
                  ) : (
                    'Save'
                  )}
                </Button>
              </div>
            </Col>

            {/* RIGHT: Summary */}
            <Col lg={4}>
              <aside className="summary-card">
                <div className="sum-head">Discount Summary</div>
                <div className="sum-row">
                  <div className="sum-label">Title</div>
                  <div className="sum-value">{title || '—'}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Discount Value</div>
                  <div className="sum-value">{valueSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Eligibility</div>
                  <div className="sum-value">{eligibilitySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Amount Rules</div>
                  <div className="sum-value">
                    Min Purchase: {minPurchase === '' ? '—' : `${currency || 'LKR'} ${Number(minPurchase).toFixed(2)}`}
                    <br />
                    {valueType === 'percentage' ? (
                      <>Max Discount: {maxDiscountAmount === '' ? '—' : `${currency || 'LKR'} ${Number(maxDiscountAmount).toFixed(2)}`}</>
                    ) : (
                      <>Max Discount: —</>
                    )}
                  </div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Usage Limits</div>
                  <div className="sum-value">{usageSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Active Period</div>
                  <div className="sum-value">{periodSummary}</div>
                </div>
              </aside>
            </Col>
          </Row>
        </Card.Body>

        <style jsx>{`
          .section + .section {
            margin-top: 16px;
          }
          .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            background: #f5f7fb;
          }
          .section-title {
            font-weight: 700;
            color: #111827;
          }
          .section-body {
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 0 0 12px 12px;
            background: #fff;
          }
          .stacked-choice {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 10px;
            padding: 10px 12px;
            background: #fff;
          }
          .footer-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 18px;
          }
          .summary-card {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            background: #fff;
            padding: 12px;
          }
          .sum-head {
            font-weight: 700;
            color: #111827;
            background: #f5f7fb;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 10px;
            padding: 10px 12px;
            margin-bottom: 10px;
          }
          .sum-row {
            display: grid;
            grid-template-columns: 170px 1fr;
            gap: 10px;
            padding: 8px 2px;
          }
          .sum-label {
            color: #6b7280;
            font-weight: 600;
          }
          .sum-value {
            color: #111827;
          }
          .nowrap {
            white-space: nowrap;
          }
        `}</style>
      </Card>

      {/* Unsaved changes modal */}
      <Modal show={confirmOpen} onHide={() => setConfirmOpen(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Unsaved changes</Modal.Title>
        </Modal.Header>
        <Modal.Body>You have unsaved changes. If you leave this page, your edits will be lost.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setConfirmOpen(false)}>
            Stay on page
          </Button>
          <Button variant="danger" onClick={discardAndGo}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
