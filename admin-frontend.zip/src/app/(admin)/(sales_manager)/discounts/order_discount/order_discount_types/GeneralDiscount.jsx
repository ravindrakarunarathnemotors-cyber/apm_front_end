'use client'

import { useMemo, useState, useEffect, useRef } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useAddOrderDiscountMutation, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice'

export default function GeneralDiscount({ onDirty }) {
  // ===== Unsaved Changes Guard =====
  const [dirty, setDirty] = useState(false)
  const markDirty = () => {
    setDirty(true)
    onDirty?.()
  }

  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const [isNavigating, setIsNavigating] = useState(false)

  const pendingActionRef = useRef(null) // 'router' | 'link' | 'history'
  const allowNavRef = useRef(false)

  let RouterEvents = null
  let nextRouter = null
  try {
    const pages = require('next/router')
    nextRouter = pages.useRouter?.()
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }

  // Intercept route changes
  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }

    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  // Intercept anchor clicks
  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  // Intercept browser back/forward
  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])
  const proceedNavigation = () => {
    const action = pendingActionRef.current
    const href = pendingHref

    setShowPrompt(false)
    setDirty(false)
    allowNavRef.current = true
    setIsNavigating(true)

    // 🔒 SPECIAL CASE: same-route /discounts
    if (href === '/discounts') {
      window.location.replace('/discounts')
      return
    }

    if (action === 'link' && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }

    if (action === 'router' && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }

    if (action === 'history') {
      history.back()
      return
    }
  }

  const cancelNavigation = () => {
    setShowPrompt(false)
    setPendingHref(null)
    pendingActionRef.current = null
    allowNavRef.current = false
    setIsNavigating(false)
  }

  // ===== Core form state =====
  const [title, setTitle] = useState('')

  // Discount value (Fixed pre-selected)
  const [valueType, setValueType] = useState('fixed') // default to 'fixed'
  const [value, setValue] = useState(10)

  // Amount limits
  const [setAmountLimits, setSetAmountLimits] = useState(true)
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('') // <-- NEW

  // Customer eligibility (guest independent)
  const [eligibility, setEligibility] = useState('all') // 'all' | 'new' | 'existing'
  const [guestIncluded, setGuestIncluded] = useState(false)

  // Usage limit (mutual exclusivity for the first two)
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('')
  // const [limitTotalUses, setLimitTotalUses] = useState(false)
  // const [totalUses, setTotalUses] = useState('')

  // Active period
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ---------- minimal time helpers/state (placed AFTER start/end state) ----------
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  }
  const timeToMinutes = (t) => {
    if (!t) return NaN
    const [hh, mm] = String(t).split(':').map(Number)
    return Number.isFinite(hh) && Number.isFinite(mm) ? hh * 60 + mm : NaN
  }
  const minutesToTime = (m) => {
    if (!Number.isFinite(m)) return ''
    const hh = Math.floor(m / 60) % 24
    const mm = m % 60
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
  }

  // if startDate is today, make startTime min = now and bump startTime if earlier
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      if (startTime && timeToMinutes(startTime) < timeToMinutes(now)) {
        setStartTime(now)
      }
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'

    // same-day end: require end > start => min = startTime + 1 minute
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        min = minutesToTime(s + 1)
      }
    } else if (hasEnd && endDate === todayISO()) {
      // end is today (but not same as start): disallow past times
      min = nowTimeRounded()
    }

    setEndTimeMin(min)

    // clear invalid endTime
    if (endTime && Number.isFinite(timeToMinutes(endTime)) && Number.isFinite(timeToMinutes(min)) && timeToMinutes(endTime) < timeToMinutes(min)) {
      setEndTime('')
    }
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // Actions / validation
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  // RTK Query hook (only once)
  const [addOrderDiscount] = useAddOrderDiscountMutation()

  // fetch currency code once (backend returns { currency: 'LKR' })
  const { data: currencyFromApi = '', isLoading: currencyLoading } = useGetDiscountCurrencyQuery()
  const currency = currencyFromApi || '-'

  // Derived
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    return `${currency}${Number(value || 0).toFixed(2)}`
  }, [valueType, value, currency])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // Keep endDate >= startDate
  useEffect(() => {
    if (!startDate) return
    if (hasEnd && endDate && endDate < startDate) setEndDate(startDate)
  }, [startDate, hasEnd, endDate])

  // Validation
  const validate = () => {
    const e = {}
    const trimmed = title.trim()
    if (!trimmed) e.title = 'Discount title is required.'
    if (trimmed.length > 100) e.title = 'Title must be 100 characters or fewer.'

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
      // optional but must be > 0 if provided
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) <= 0) {
        e.maxDiscountAmount = 'Maximum discount must be greater than 0.'
      }
    } else {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (setAmountLimits) {
      if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase amount is required.'
    }

    // Usage limits
    if (limitPerCustomerOnce && limitPerAccount) {
      e.usage = 'Select either Unlimited Discount Usage OR per-account limit, not both.'
    }
    if (limitPerAccount && (perAccountUses === '' || Number(perAccountUses) < 1)) {
      e.perAccount = 'Usage per account is required.'
    }

    // Dates
    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // same-day: ensure times present and endTime > startTime; also ensure startTime not in past if startDate is today
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        // end date is today (but not same as start) — ensure endTime is not before now
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // Helpers
  const joinDateTime = (d, t) => {
    if (!d || !t) return null
    return `${d}T${t}:00`
  }
  const toNumOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v))

  // Mutual exclusion
  const onTogglePerCustomerOnce = (checked) => {
    setLimitPerCustomerOnce(checked)
    markDirty()
    if (checked) {
      setLimitPerAccount(false)
      setPerAccountUses('')
    }
  }
  const onTogglePerAccount = (checked) => {
    if (limitPerCustomerOnce && checked) return
    setLimitPerAccount(checked)
    markDirty()
    if (!checked) setPerAccountUses('')
  }

  // Discard → confirm + clear
  const resetForm = () => {
    setTitle('New Year Storewide')
    setValueType('fixed')
    setValue(10)
    setSetAmountLimits(true)
    setMinPurchase('')
    setMaxDiscountAmount('')

    setEligibility('all')
    setGuestIncluded(false)

    setLimitPerCustomerOnce(false)
    setLimitPerAccount(false)
    setPerAccountUses('')
    // setLimitTotalUses(false) // left commented because not in state
    // setTotalUses('')

    setStartDate('')
    setStartTime('')
    setHasEnd(false)
    setEndDate('')
    setEndTime('')

    setErrors({})
    setDirty(false)
  }

  const onDiscard = async () => {
    const res = await Swal.fire({
      title: 'Discard changes?',
      text: 'Do you want to discard the changes?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Discard',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#111827',
    })

    if (res.isConfirmed) {
      // 🔥 notify global listeners (same event as save)
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('discount:saved'))
      }
    }
  }

  const onSave = async () => {
    if (!validate()) return
    setSaving(true)

    Swal.fire({
      title: 'Saving discount…',
      allowEscapeKey: false,
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      const payload = {
        main_discount_type: 'order',
        discount_title: title.trim(),
        discount_value_type: valueType,
        discount_value: Number(value),

        // Min purchase + Max discount for percentage
        min_max_purchase_discount_limits: !!setAmountLimits,
        min_purchase_amount: setAmountLimits ? toNumOrNull(minPurchase) : null,
        max_discount_amount: valueType === 'percentage' ? toNumOrNull(maxDiscountAmount) : null,

        // Eligibility
        customer_eligibility: eligibility,
        is_guest_allowed: !!guestIncluded,

        // Usage limits
        unlimited_usage: !!limitPerCustomerOnce,
        usage_limit_per_account: limitPerAccount ? toNumOrNull(perAccountUses) : null,

        status: 'active',
        start_date: joinDateTime(startDate, startTime),
        end_date: hasEnd ? joinDateTime(endDate, endTime) : null,

        discount_code: null,
        order_discount_method: 'general',
        payment_method: null,
      }

      await addOrderDiscount(payload).unwrap()

      setSaving(false)
      setDirty(false)

      // wait for user to confirm the success alert, then notify parent to open list + refetch
      const res = await Swal.fire({
        icon: 'success',
        title: 'Discount saved',
        text: 'Order-level discount has been created successfully.',
        confirmButtonText: 'OK',
      })

      if (res.isConfirmed) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('discount:saved'))
        }
      }
    } catch (err) {
      console.error('Add order discount failed:', err)
      setSaving(false)
      Swal.fire({
        icon: 'error',
        title: 'Save failed',
        text: err?.data?.error || err?.error || 'Please try again.',
        confirmButtonText: 'OK',
      })
    }
  }

  const handleTitleInput = (v) => {
    const limited = v.slice(0, 100)
    setTitle(limited)
    markDirty()
  }

  return (
    <Card className="soft-card">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">General Discount</Card.Title>
          <small className="text-muted">Create a store-wide or criteria-based discount.</small>
        </div>
      </Card.Header>

      <Card.Body>
        <Row className="g-3">
          {/* {isNavigating && (
            <div className="nav-overlay">
              <div className="nav-box">
                <div className="dot-loader">
                  <span />
                  <span />
                  <span />
                </div>
                <div className="nav-text">Navigating…</div>
              </div>
            </div>
          )} */}

          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Discount Title */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Title</span>
              </div>
              <div className="section-body">
                <Form.Control placeholder="e.g. New Customer Welcome 10%" value={title} onChange={(e) => handleTitleInput(e.target.value)} required />
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">{title.length}/100</small>
                  {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value (Fixed pre-selected) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="1"
                            max="100"
                            step="1"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                          />
                        </>
                      ) : (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">{currency}</InputGroup.Text>

                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                          />
                        </>
                      )}
                    </InputGroup>
                    {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Limits (Minimum Purchase + conditional Max Discount) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase Amount</span>
              </div>

              <div className="section-body">
                <Row className="g-3 align-items-center">
                  {/* Left: Minimum Purchase */}
                  <Col md={6}>
                    <InputGroup>
                      <InputGroup.Text
                        className="fw-semibold nowrap"
                        style={{ fontSize: '12px' }} // <-- smaller title
                      >
                        Minimum Purchase Amount {currency ? `(${currency})` : ''}
                      </InputGroup.Text>

                      <Form.Control
                        type="number"
                        min="0"
                        step="0.01"
                        value={minPurchase}
                        onChange={(e) => {
                          setMinPurchase(e.target.value)
                          markDirty()
                        }}
                        required={setAmountLimits}
                      />
                    </InputGroup>

                    {errors.minPurchase && <div className="text-danger small mt-1 nowrap">{errors.minPurchase}</div>}
                  </Col>

                  {/* Right: Maximum Discount (only for percentage) */}
                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text
                          className="fw-semibold nowrap"
                          style={{ fontSize: '12px' }} // <-- smaller title
                        >
                          Maximum Discount Amount {currency ? `(${currency})` : ''}
                        </InputGroup.Text>

                        <Form.Control
                          type="number"
                          min="0.01"
                          step="0.01"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            setMaxDiscountAmount(e.target.value)
                            markDirty()
                          }}
                          placeholder="Optional"
                        />
                      </InputGroup>

                      {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility (guest independent) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        markDirty()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        markDirty()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        markDirty()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={!!guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        markDirty()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Usage Limit (mutually exclusive, always one selected, side-by-side) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Usage Limit</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  {/* LEFT COLUMN — Unlimited Discount */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent both from becoming unchecked
                        if (!checked && !limitPerAccount) return

                        onTogglePerCustomerOnce(checked)

                        // Make exclusive
                        if (checked && limitPerAccount) onTogglePerAccount(false)

                        markDirty?.()
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  {/* RIGHT COLUMN — Per Account Limit */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // Prevent both from becoming unchecked
                        if (!checked && !limitPerCustomerOnce) return

                        onTogglePerAccount(checked)

                        // Make exclusive
                        if (checked && limitPerCustomerOnce) onTogglePerCustomerOnce(false)

                        markDirty?.()
                      }}
                      label="Set Usage Limit Per Account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(e.target.value)
                            markDirty?.()
                          }}
                        />
                        {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                      </div>
                    )}
                  </Col>
                </Row>

                {errors.usage && <div className="text-danger small mt-2">{errors.usage}</div>}
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Dates</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        const newStart = e.target.value
                        setStartDate(newStart)
                        markDirty()
                        // if start becomes today and startTime is earlier than now, bump it
                        if (newStart === todayISO() && startTime && timeToMinutes(startTime) < timeToMinutes(nowTimeRounded())) {
                          setStartTime(nowTimeRounded())
                        }
                        // also ensure endDate not before startDate (existing behaviour kept)
                        if (hasEnd && endDate && endDate < newStart) setEndDate(newStart)
                      }}
                    />
                    {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                  </Col>

                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      min={startTimeMin}
                      onChange={(e) => {
                        const newStart = e.target.value
                        setStartTime(newStart)
                        markDirty()
                        // if same-day end and endTime <= newStart, clear endTime so user re-selects
                        if (hasEnd && endDate && startDate && endDate === startDate && endTime && timeToMinutes(endTime) <= timeToMinutes(newStart)) {
                          setEndTime('')
                        }
                      }}
                    />
                    {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                    {startTimeMin !== '00:00' && (
                      <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>
                    )}
                  </Col>

                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-2"
                      checked={hasEnd}
                      onChange={(e) => {
                        const checked = e.target.checked
                        setHasEnd(checked)
                        markDirty()
                        if (checked) {
                          // suggest endDate and endTime to reduce clicks:
                          const suggestedEndDate = startDate || todayISO()
                          setEndDate(suggestedEndDate)
                          // friendly suggested endTime: startTime +1 hour if available, else now +1h
                          let suggested = ''
                          if (startTime && Number.isFinite(timeToMinutes(startTime))) {
                            suggested = minutesToTime(timeToMinutes(startTime) + 60)
                          } else {
                            suggested = minutesToTime(timeToMinutes(nowTimeRounded()) + 60)
                          }
                          setEndTime(suggested)
                        } else {
                          // clearing
                          setEndDate('')
                          setEndTime('')
                        }
                      }}
                      label="Set End Date"
                    />
                  </Col>

                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            const newEnd = e.target.value
                            setEndDate(newEnd)
                            markDirty()
                            // if new end is same as start, and current endTime is less than allowed min, clear it
                            if (newEnd && startDate && newEnd === startDate && endTime && timeToMinutes(endTime) < timeToMinutes(endTimeMin)) {
                              setEndTime('')
                            }
                          }}
                        />
                        {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          min={endTimeMin}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            markDirty()
                          }}
                        />
                        {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                        {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                          <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                        )}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button variant="outline-secondary" onClick={onDiscard} disabled={saving}>
                Discard
              </Button>
              <Button onClick={onSave} disabled={saving}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>
              <div className="sum-row">
                <div className="sum-label">Discount Title</div>
                <div className="sum-value">{title || '—'}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Amount Rules</div>
                <div className="sum-value">
                  Min Purchase: {minPurchase === '' ? '—' : `${currency}${Number(minPurchase).toFixed(2)}`}
                  {valueType === 'percentage' ? (
                    <>
                      <br />
                      Max Discount: {maxDiscountAmount === '' ? '—' : `${currency}${Number(maxDiscountAmount).toFixed(2)}`}
                    </>
                  ) : null}
                </div>
              </div>

              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Leave-without-saving Modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        :global(.btn-dark) {
          background-color: #111827;
          border-color: #111827;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 170px 1fr;
          gap: 10px;
          padding: 8px 2px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
        }
        /* ================= NAVIGATING OVERLAY (NO BLUR) ================= */

        .nav-overlay {
          position: fixed;
          inset: 0;
          z-index: 99999;

          /* light dim, no blur */
          background: rgba(255, 255, 255, 0.85);

          display: flex;
          align-items: center;
          justify-content: center;

          pointer-events: all;
        }

        .nav-box {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 14px;

          padding: 22px 28px;
          border-radius: 14px;

          background: #ffffff;
          box-shadow:
            0 12px 28px rgba(0, 0, 0, 0.12),
            0 0 0 1px rgba(0, 0, 0, 0.04);

          animation: navFadeIn 0.15s ease-out;
        }

        /* ================= DOTTED BLUE LOADER ================= */

        .dot-loader {
          display: flex;
          gap: 8px;
        }

        .dot-loader span {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background-color: #2563eb; /* blue-600 */
          opacity: 0.25;
          animation: dotPulse 1.4s infinite ease-in-out both;
        }

        .dot-loader span:nth-child(1) {
          animation-delay: -0.32s;
        }
        .dot-loader span:nth-child(2) {
          animation-delay: -0.16s;
        }
        .dot-loader span:nth-child(3) {
          animation-delay: 0s;
        }

        @keyframes dotPulse {
          0%,
          80%,
          100% {
            opacity: 0.25;
          }
          40% {
            opacity: 1;
          }
        }

        /* ================= TEXT ================= */

        .nav-text {
          font-size: 0.9rem;
          font-weight: 600;
          color: #1e3a8a; /* blue-800 */
          letter-spacing: 0.02em;
        }

        /* ================= ENTRY ANIMATION ================= */

        @keyframes navFadeIn {
          from {
            opacity: 0;
            transform: translateY(4px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </Card>
  )
}
