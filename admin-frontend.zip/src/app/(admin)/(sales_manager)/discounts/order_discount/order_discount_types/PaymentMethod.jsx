'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useAddOrderDiscountMutation, useGetActivePaymentMethodsQuery, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice'

export default function PaymentMethod() {
  /* ================= Unsaved Changes (same UX) ================= */
  const [dirty, setDirty] = useState(false)
  const markDirty = () => setDirty(true)

  const [showPrompt, setShowPrompt] = useState(false)
  const [pendingHref, setPendingHref] = useState(null)
  const pendingActionRef = useRef(null) // 'link' | 'router' | 'history' | 'reload'
  const allowNavRef = useRef(false)

  // Detect Pages Router or App Router (safe require)
  let RouterEvents = null
  let nextRouter = null
  try {
    const pages = require('next/router')
    nextRouter = pages.useRouter?.()
    RouterEvents = pages.default?.events || pages.Router?.events || null
  } catch {}
  if (!nextRouter) {
    try {
      const appNav = require('next/navigation')
      nextRouter = appNav.useRouter?.()
    } catch {}
  }

  useEffect(() => {
    if (!RouterEvents) return
    const onRouteChangeStart = (url) => {
      if (allowNavRef.current) return
      if (dirty) {
        RouterEvents.emit('routeChangeError')
        pendingActionRef.current = 'router'
        setPendingHref(url)
        setShowPrompt(true)
        // eslint-disable-next-line no-throw-literal
        throw 'Route change aborted by UnsavedChangesGuard'
      }
    }
    RouterEvents.on('routeChangeStart', onRouteChangeStart)
    return () => RouterEvents.off('routeChangeStart', onRouteChangeStart)
  }, [dirty, RouterEvents])

  useEffect(() => {
    const onDocClickCapture = (e) => {
      if (!dirty) return
      const anchor = e.target?.closest?.('a[href]')
      if (!anchor) return
      const href = anchor.getAttribute('href') || ''
      if (!href || href.startsWith('#') || href.startsWith('javascript:')) return
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return
      e.preventDefault()
      e.stopPropagation()
      setPendingHref(href)
      pendingActionRef.current = 'link'
      setShowPrompt(true)
    }
    document.addEventListener('click', onDocClickCapture, true)
    return () => document.removeEventListener('click', onDocClickCapture, true)
  }, [dirty])

  useEffect(() => {
    const stateKey = '__unsaved_guard__'
    history.replaceState({ ...(history.state || {}), [stateKey]: true }, '')
    const onPopState = () => {
      if (!dirty) return
      history.pushState({ ...(history.state || {}), [stateKey]: true }, '')
      pendingActionRef.current = 'history'
      setShowPrompt(true)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [dirty])

  useEffect(() => {
    const onKeyDown = (e) => {
      if (!dirty) return
      const isReloadKey = e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))
      if (!isReloadKey) return
      e.preventDefault()
      pendingActionRef.current = 'reload'
      setShowPrompt(true)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [dirty])

  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (!dirty) return
      e.preventDefault()
      e.returnValue = ''
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [dirty])

  const proceedNavigation = () => {
    const action = pendingActionRef.current
    const href = pendingHref
    setShowPrompt(false)
    setDirty(false)
    allowNavRef.current = true

    if ((action === 'link' || action === 'router') && href) {
      if (nextRouter?.push) nextRouter.push(href)
      else window.location.assign(href)
      return
    }
    if (action === 'history') {
      history.back()
      return
    }
    if (action === 'reload') {
      window.location.reload()
    }
  }
  const cancelNavigation = () => {
    setShowPrompt(false)
    setPendingHref(null)
    pendingActionRef.current = null
    allowNavRef.current = false
  }

  /* ================= Helpers ================= */
  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  /* ================= Hooks (RTK) ================= */
  const { data: pmResp, isLoading: pmLoading, isError: pmError } = useGetActivePaymentMethodsQuery()
  const [addOrderDiscount, { isLoading: posting }] = useAddOrderDiscountMutation()

  // currency from API (fallback to 'LKR' if API returns nothing)
  const { data: currencyResp, isLoading: currencyLoading } = useGetDiscountCurrencyQuery()
  const currency = (currencyResp && (currencyResp.currency || currencyResp.data?.currency)) || 'LKR'

  // normalize
  const activeMethods = useMemo(
    () =>
      (pmResp?.data || []).map((m) => ({
        id: m.payment_method_id,
        name: m.method_name,
      })),
    [pmResp],
  )

  /* ================= Form state (UI unchanged except sections) ================= */
  const [title, setTitle] = useState('')

  // Dynamic selected IDs from API checkboxes
  const [selectedMethodIds, setSelectedMethodIds] = useState([]) // number[]
  const toggleMethod = (id) => {
    setSelectedMethodIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
    markDirty()
  }

  // Discount value
  const [valueType, setValueType] = useState('percentage')
  const [value, setValue] = useState(10)

  // Eligibility (guest always toggleable)
  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  // Usage limit (removed total-uses)
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState()

  // Amount limits
  const [enableAmounts, setEnableAmounts] = useState(true)
  const [maxPurchase, setMaxPurchase] = useState()
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  // Active period
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // ---------- minimal time helpers/state (declare after date/time state) ----------
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  }
  const timeToMinutes = (t) => {
    if (!t) return NaN
    const [hh, mm] = String(t).split(':').map(Number)
    return Number.isFinite(hh) && Number.isFinite(mm) ? hh * 60 + mm : NaN
  }
  const minutesToTime = (m) => {
    if (!Number.isFinite(m)) return ''
    const hh = Math.floor(m / 60) % 24
    const mm = m % 60
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
  }

  // if startDate is today, make startTime min = now and bump startTime if earlier
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      if (startTime && timeToMinutes(startTime) < timeToMinutes(now)) {
        setStartTime(now)
      }
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'

    // same-day end: require end > start => min = startTime + 1 minute
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        min = minutesToTime(s + 1)
      }
    } else if (hasEnd && endDate === todayISO()) {
      // end is today (but not same as start): disallow past times
      min = nowTimeRounded()
    }

    setEndTimeMin(min)

    // clear invalid endTime
    if (endTime && Number.isFinite(timeToMinutes(endTime)) && Number.isFinite(timeToMinutes(min)) && timeToMinutes(endTime) < timeToMinutes(min)) {
      setEndTime('')
    }
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // keep endDate >= startDate
  useEffect(() => {
    if (!hasEnd || !startDate || !endDate) return
    if (endDate < startDate) setEndDate(startDate)
  }, [startDate, endDate, hasEnd])

  // Actions / validation
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  /* ================= Derived summaries ================= */
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    return `${currency} ${Number(value || 0).toFixed(2)}`
  }, [valueType, value, currency])

  const gatewaySummary = useMemo(() => {
    if (!activeMethods.length) return 'None available'
    const selected = activeMethods.filter((m) => selectedMethodIds.includes(m.id)).map((m) => m.name)
    return selected.length ? selected.join(' • ') : 'None selected'
  }, [activeMethods, selectedMethodIds])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} • Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  /* ================= Validation & Save ================= */
  const validate = () => {
    const e = {}
    const t = title.trim()
    if (!t) e.title = 'Discount title is required.'
    if (t.length > 100) e.title = 'Title must be 100 characters or fewer.'

    // Must pick at least one payment method (dynamic)
    if (selectedMethodIds.length === 0) e.payment_method = 'Select at least one payment method.'

    if (valueType !== 'percentage' && valueType !== 'fixed') e.valueType = 'Select a discount type.'
    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
    } else if (value === '' || Number(value) <= 0) {
      e.value = 'Amount must be greater than 0.'
    }

    if (enableAmounts) {
      if (maxPurchase === '' || Number(maxPurchase) < 0) e.maxPurchase = 'Minimum purchase is required.'
      if (valueType === 'percentage') {
        if (maxDiscountAmount === '' || Number(maxDiscountAmount) <= 0) {
          e.maxDiscountAmount = 'Maximum discount is required.'
        }
      }
    }

    if (limitPerAccount && (!perAccountUses || Number(perAccountUses) < 1)) e.perAccount = 'Per-account uses is required.'

    // Dates
    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // same-day end checks
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  const makeTimestamp = (d, t) => {
    if (!d || !t) return null
    try {
      return new Date(`${d}T${t}:00`).toISOString()
    } catch {
      return null
    }
  }

  const onSave = async () => {
    if (!validate()) return

    setSaving(true)
    Swal.fire({
      title: 'Saving…',
      text: 'Adding order discount',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      const payload = {
        main_discount_type: 'order',
        order_discount_method: 'payment_method',

        payment_method: selectedMethodIds,

        discount_title: title.trim(),
        discount_value_type: valueType,
        discount_value: Number(value),

        // amount limits
        min_max_purchase_discount_limits: !!enableAmounts,
        min_purchase_amount: enableAmounts ? Number(maxPurchase) : null,
        max_discount_amount: enableAmounts && valueType === 'percentage' ? Number(maxDiscountAmount) : null,

        // eligibility
        customer_eligibility: eligibility,
        is_guest_allowed: !!guestIncluded,

        // usage limits
        unlimited_usage: !!limitPerCustomerOnce,
        usage_limit_per_account: limitPerAccount ? Number(perAccountUses) : null,

        // dates
        start_date: makeTimestamp(startDate, startTime),
        end_date: hasEnd ? makeTimestamp(endDate, endTime) : null,

        discount_code: null,
        status: 'active',
      }

      await addOrderDiscount(payload).unwrap()

      // Success modal WITH OK button
      const result = await Swal.fire({
        icon: 'success',
        title: 'Saved',
        text: 'Order discount added successfully.',
        confirmButtonText: 'OK',
        confirmButtonColor: '#111827',
      })

      if (result.isConfirmed) {
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('discount:saved'))
        }
      }

      setDirty(false)
    } catch (err) {
      await Swal.fire({
        icon: 'error',
        title: 'Save failed',
        text: err?.data?.error || err?.message || 'Something went wrong.',
        confirmButtonText: 'OK',
      })
    } finally {
      setSaving(false)
    }
  }

  const disabled = saving || posting

  return (
    <>
      <Card className="soft-card">
        <Card.Header className="bg-white d-flex align-items-start justify-content-between">
          <div>
            <Card.Title className="mb-0">Payment Method</Card.Title>
            <small className="text-muted">Apply discounts based on the selected payment gateways.</small>
          </div>
        </Card.Header>

        <Card.Body>
          <Row className="g-3">
            {/* ---------- LEFT: Form ---------- */}
            <Col lg={8}>
              {/* Discount Title */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Title</span>
                </div>
                <div className="section-body">
                  <Form.Control
                    placeholder="e.g. 2% off for selected payment methods"
                    value={title}
                    onChange={(e) => {
                      setTitle(e.target.value.slice(0, 100))
                      markDirty()
                    }}
                    required
                    disabled={disabled}
                  />
                  <div className="d-flex justify-content-between mt-1">
                    <small className="text-muted">{title.length}/100</small>
                    {errors.title && <small className="text-danger nowrap">{errors.title}</small>}
                  </div>
                </div>
              </section>

              {/* Applicable Payment Gateway (Dynamic checkboxes from API ONLY) */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Applicable Payment Gateways</span>
                </div>
                <div className="section-body">
                  {pmLoading && <div className="small text-muted">Loading payment methods…</div>}
                  {pmError && <div className="small text-danger">Failed to load payment methods.</div>}
                  {!pmLoading && !pmError && (
                    <>
                      {activeMethods.length === 0 ? (
                        <div className="small text-muted">No active payment methods.</div>
                      ) : (
                        <div className="d-flex flex-column gap-2">
                          {activeMethods.map((m) => (
                            <Form.Check
                              key={m.id}
                              type="checkbox"
                              id={`pm-${m.id}`}
                              checked={selectedMethodIds.includes(m.id)}
                              onChange={() => toggleMethod(m.id)}
                              label={m.name}
                              disabled={disabled}
                            />
                          ))}
                        </div>
                      )}
                    </>
                  )}
                  {errors.payment_method && <div className="text-danger small mt-2">{errors.payment_method}</div>}
                </div>
              </section>

              {/* Discount Value */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Discount Value</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-perc"
                          name="val-type"
                          checked={valueType === 'percentage'}
                          onChange={() => {
                            setValueType('percentage')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Percentage</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <div className="stacked-choice">
                        <Form.Check
                          type="radio"
                          id="val-type-fixed"
                          name="val-type"
                          checked={valueType === 'fixed'}
                          onChange={() => {
                            setValueType('fixed')
                            markDirty()
                          }}
                          label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                          required
                          disabled={disabled}
                        />
                      </div>
                    </Col>
                    <Col md={4}>
                      <InputGroup>
                        {valueType === 'percentage' ? (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                            <Form.Control
                              type="number"
                              min="1"
                              max="100"
                              step="1"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              disabled={disabled}
                            />
                          </>
                        ) : (
                          <>
                            <InputGroup.Text className="fw-semibold nowrap">{currency}</InputGroup.Text>

                            <Form.Control
                              type="number"
                              min="0.01"
                              step="0.01"
                              required
                              value={value}
                              onChange={(e) => {
                                setValue(Number(e.target.value || 0))
                                markDirty()
                              }}
                              disabled={disabled}
                            />
                          </>
                        )}
                      </InputGroup>
                      {errors.value && <div className="text-danger small mt-1 nowrap">{errors.value}</div>}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Amount Limits */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Set Minimum Purchase Amount and Max Discount Amount</span>
                </div>

                <div className="section-body">
                  <Row className="g-3">
                    <Col md={valueType === 'percentage' ? 6 : 7}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold px-3" style={{ fontSize: '12px', minWidth: '180px' }}>
                          Minimum Purchase Amount {currency ? `(${currency})` : ''}
                        </InputGroup.Text>

                        <Form.Control
                          as="input"
                          size="lg"
                          type="text"
                          inputMode="decimal"
                          value={maxPurchase || ''}
                          onChange={(e) => {
                            const raw = e.target.value
                            if (raw === '') {
                              setMaxPurchase('')
                              markDirty()
                              return
                            }
                            const cleaned = raw.replace(/,/g, '').replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1')
                            setMaxPurchase(cleaned)
                            markDirty()
                          }}
                          required
                          disabled={disabled}
                        />
                      </InputGroup>

                      {errors.maxPurchase && <div className="text-danger small mt-1 nowrap">{errors.maxPurchase}</div>}
                    </Col>

                    {valueType === 'percentage' && (
                      <Col md={6}>
                        <InputGroup>
                          <InputGroup.Text className="fw-semibold px-3" style={{ fontSize: '12px', minWidth: '180px' }}>
                            Maximum Discount Amount {currency ? `(${currency})` : ''}
                          </InputGroup.Text>

                          <Form.Control
                            as="input"
                            size="lg"
                            type="text"
                            inputMode="decimal"
                            value={maxDiscountAmount || ''}
                            onChange={(e) => {
                              const raw = e.target.value
                              if (raw === '') {
                                setMaxDiscountAmount('')
                                markDirty()
                                return
                              }
                              const cleaned = raw.replace(/,/g, '').replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1')
                              setMaxDiscountAmount(cleaned)
                              markDirty()
                            }}
                            required
                            disabled={disabled}
                          />
                        </InputGroup>

                        {errors.maxDiscountAmount && <div className="text-danger small mt-1 nowrap">{errors.maxDiscountAmount}</div>}
                      </Col>
                    )}
                  </Row>
                </div>
              </section>

              {/* Customer Eligibility (guest always toggleable) */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Customer Eligibility</span>
                </div>
                <div className="section-body">
                  <Row className="g-2 align-items-center">
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-all"
                        checked={eligibility === 'all'}
                        onChange={() => {
                          setEligibility('all')
                          markDirty()
                        }}
                        label="All Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-new"
                        checked={eligibility === 'new'}
                        onChange={() => {
                          setEligibility('new')
                          markDirty()
                        }}
                        label="New Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="radio"
                        name="elig"
                        id="elig-existing"
                        checked={eligibility === 'existing'}
                        onChange={() => {
                          setEligibility('existing')
                          markDirty()
                        }}
                        label="Existing Customers"
                        required
                        disabled={disabled}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Check
                        type="checkbox"
                        id="elig-guest"
                        checked={!!guestIncluded}
                        onChange={(e) => {
                          setGuestIncluded(e.target.checked)
                          markDirty()
                        }}
                        label="Guest Customers"
                        disabled={disabled}
                      />
                    </Col>
                  </Row>
                </div>
              </section>
              {/* Usage Limit (mutually exclusive; always one selected; no "total uses") */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Usage Limit</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    {/* LEFT: Unlimited Discount Usage */}
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-customer"
                        checked={limitPerCustomerOnce}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Prevent both from ending up unchecked
                          if (!checked && !limitPerAccount) return

                          setLimitPerCustomerOnce(checked)

                          if (checked) {
                            // Exclusive behavior
                            setLimitPerAccount(false)
                            // Your prefill/reset logic
                            setPerAccountUses(2)
                          }

                          markDirty()
                        }}
                        label="Unlimited Discount Usage"
                      />
                    </Col>

                    {/* RIGHT: Per-account limit */}
                    <Col md={6}>
                      <Form.Check
                        type="checkbox"
                        id="limit-per-account"
                        checked={limitPerAccount}
                        onChange={(e) => {
                          const checked = e.target.checked

                          // Prevent both from being unchecked
                          if (!checked && !limitPerCustomerOnce) return

                          setLimitPerAccount(checked)

                          if (checked) {
                            // Exclusive behavior
                            setLimitPerCustomerOnce(false)
                          } else {
                            // Reset when turned off (your existing logic)
                            setPerAccountUses(2)
                          }

                          markDirty()
                        }}
                        label="Set Usage Limit Per Account"
                      />

                      {limitPerAccount && (
                        <div className="mt-2" style={{ maxWidth: 220 }}>
                          <Form.Control
                            type="number"
                            min="1"
                            step="1"
                            required
                            value={perAccountUses}
                            onChange={(e) => {
                              const v = Number(e.target.value || 1)
                              setPerAccountUses(v)
                              markDirty()
                            }}
                          />
                          {errors.perAccount && <div className="text-danger small mt-1 nowrap">{errors.perAccount}</div>}
                        </div>
                      )}
                    </Col>
                  </Row>
                </div>
              </section>

              {/* Active Period */}
              <section className="section">
                <div className="section-head">
                  <span className="section-title">Active Period</span>
                </div>
                <div className="section-body">
                  <Row className="g-3">
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Date <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        required
                        min={todayISO()}
                        value={startDate}
                        onChange={(e) => {
                          const newStart = e.target.value
                          setStartDate(newStart)
                          markDirty()
                          // if start becomes today and startTime is earlier than now, bump it
                          if (newStart === todayISO() && startTime && timeToMinutes(startTime) < timeToMinutes(nowTimeRounded())) {
                            setStartTime(nowTimeRounded())
                          }
                          // ensure endDate not before startDate
                          if (hasEnd && endDate && endDate < newStart) setEndDate(newStart)
                        }}
                        disabled={disabled}
                      />
                      {errors.startDate && <div className="text-danger small mt-1 nowrap">{errors.startDate}</div>}
                    </Col>
                    <Col md={3}>
                      <Form.Label className="fw-semibold">
                        Start Time <span className="text-danger">*</span>
                      </Form.Label>
                      <Form.Control
                        type="time"
                        required
                        value={startTime}
                        min={startTimeMin}
                        onChange={(e) => {
                          const newStart = e.target.value
                          setStartTime(newStart)
                          markDirty()
                          // if same-day end and endTime <= newStart, clear endTime so user re-selects
                          if (hasEnd && endDate && startDate && endDate === startDate && endTime && timeToMinutes(endTime) <= timeToMinutes(newStart)) {
                            setEndTime('')
                          }
                        }}
                        disabled={disabled}
                      />
                      {errors.startTime && <div className="text-danger small mt-1 nowrap">{errors.startTime}</div>}
                      {startTimeMin !== '00:00' && <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>}
                    </Col>
                    <Col md={12}>
                      <Form.Check
                        id="has-end"
                        type="checkbox"
                        className="mt-0"
                        checked={hasEnd}
                        onChange={(e) => {
                          const checked = e.target.checked
                          setHasEnd(checked)
                          markDirty()
                          if (checked) {
                            const suggestedEndDate = startDate || todayISO()
                            setEndDate(suggestedEndDate)
                            // friendly suggested endTime: startTime +1 hour if available, else now +1h
                            let suggested = ''
                            if (startTime && Number.isFinite(timeToMinutes(startTime))) {
                              suggested = minutesToTime(timeToMinutes(startTime) + 60)
                            } else {
                              suggested = minutesToTime(timeToMinutes(nowTimeRounded()) + 60)
                            }
                            setEndTime(suggested)
                          } else {
                            setEndDate('')
                            setEndTime('')
                          }
                        }}
                        label="Set End Date"
                        disabled={disabled}
                      />
                    </Col>
                    {hasEnd && (
                      <>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Date <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="date"
                            required
                            min={startDate || todayISO()}
                            value={endDate}
                            onChange={(e) => {
                              const newEnd = e.target.value
                              setEndDate(newEnd)
                              markDirty()
                              // if new end is same as start, and current endTime is less than allowed min, clear it
                              if (newEnd && startDate && newEnd === startDate && endTime && timeToMinutes(endTime) < timeToMinutes(endTimeMin)) {
                                setEndTime('')
                              }
                            }}
                            disabled={disabled}
                          />
                          {errors.endDate && <div className="text-danger small mt-1 nowrap">{errors.endDate}</div>}
                        </Col>
                        <Col md={3}>
                          <Form.Label className="fw-semibold">
                            End Time <span className="text-danger">*</span>
                          </Form.Label>
                          <Form.Control
                            type="time"
                            required
                            value={endTime}
                            min={endTimeMin}
                            onChange={(e) => {
                              setEndTime(e.target.value)
                              markDirty()
                            }}
                            disabled={disabled}
                          />
                          {errors.endTime && <div className="text-danger small mt-1 nowrap">{errors.endTime}</div>}
                          {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                            <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                          )}
                        </Col>
                      </>
                    )}
                  </Row>
                </div>
              </section>

              {/* Footer actions */}
              <div className="footer-actions">
                <Button
                  variant="outline-secondary"
                  onClick={async () => {
                    const res = await Swal.fire({
                      title: 'Discard changes?',
                      text: 'Do you want to discard the changes?',
                      icon: 'warning',
                      showCancelButton: true,
                      confirmButtonText: 'Discard',
                      cancelButtonText: 'Cancel',
                      confirmButtonColor: '#111827',
                    })

                    if (res.isConfirmed) {
                      // 🔥 notify global listeners (same event as save)
                      if (typeof window !== 'undefined') {
                        window.dispatchEvent(new CustomEvent('discount:saved'))
                      }
                    }
                  }}>
                  Discard
                </Button>

                <Button onClick={onSave} disabled={disabled}>
                  {disabled ? (
                    <>
                      <Spinner animation="border" size="sm" className="me-2" /> Saving…
                    </>
                  ) : (
                    'Save'
                  )}
                </Button>
              </div>
            </Col>

            {/* ---------- RIGHT: Summary ---------- */}
            <Col lg={4}>
              <aside className="summary-card">
                <div className="sum-head">Discount Summary</div>
                <div className="sum-row">
                  <div className="sum-label">Title</div>
                  <div className="sum-value">{title || '—'}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Gateways</div>
                  <div className="sum-value">{gatewaySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Discount Value</div>
                  <div className="sum-value">{valueSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Eligibility</div>
                  <div className="sum-value">{eligibilitySummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Usage Limits</div>
                  <div className="sum-value">{usageSummary}</div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Amount Rules</div>
                  <div className="sum-value">
                    Min Purchase: {enableAmounts ? (maxPurchase === '' ? '—' : `${currency} ${Number(maxPurchase).toLocaleString()}`) : '—'}
                    <br />
                    {valueType === 'percentage' ? (
                      <>
                        Max Discount:{' '}
                        {enableAmounts ? (maxDiscountAmount === '' ? '—' : `${currency} ${Number(maxDiscountAmount).toLocaleString()}`) : '—'}
                      </>
                    ) : (
                      <>Max Discount: —</>
                    )}
                  </div>
                </div>
                <div className="sum-row">
                  <div className="sum-label">Active Period</div>
                  <div className="sum-value">{periodSummary}</div>
                </div>
              </aside>
            </Col>
          </Row>
        </Card.Body>

        {/* Styles (shared look & feel) */}
        <style jsx>{`
          .section + .section {
            margin-top: 16px;
          }
          .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-bottom: none;
            border-radius: 12px 12px 0 0;
            background: #f5f7fb;
          }
          .section-title {
            font-weight: 700;
            color: #111827;
          }
          .section-body {
            padding: 12px;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 0 0 12px 12px;
            background: #fff;
          }
          .stacked-choice {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 10px;
            padding: 10px 12px;
            background: #fff;
          }
          .footer-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 18px;
          }
          .summary-card {
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            background: #fff;
            padding: 12px;
          }
          .sum-head {
            font-weight: 700;
            color: #111827;
            background: #f5f7fb;
            border: 1px solid rgba(0, 0, 0, 0.06);
            border-radius: 10px;
            padding: 10px 12px;
            margin-bottom: 10px;
          }
          .sum-row {
            display: grid;
            grid-template-columns: 170px 1fr;
            gap: 10px;
            padding: 8px 2px;
          }
          .sum-label {
            color: #6b7280;
            font-weight: 600;
          }
          .sum-value {
            color: #111827;
          }
        `}</style>
      </Card>

      {/* Unsaved-changes modal */}
      <Modal show={showPrompt} onHide={cancelNavigation} centered>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="solar:warning-triangle-linear" width={20} />
            Unsaved changes
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>You have changes that haven’t been saved yet. If you leave this page, your changes will be lost.</Modal.Body>
        <Modal.Footer className="d-flex justify-content-between">
          <Button variant="secondary" onClick={cancelNavigation}>
            Stay on this page
          </Button>
          <Button variant="danger" onClick={proceedNavigation}>
            Leave without saving
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}
