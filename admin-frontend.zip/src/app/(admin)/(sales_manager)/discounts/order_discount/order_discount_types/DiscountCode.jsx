'use client'

import { useMemo, useState, useEffect, useRef } from 'react'

import { Card, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'

import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useAddOrderDiscountMutation, useCheckDiscountCodeMutation, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice'
import debounce from 'lodash/debounce'

export default function DiscountCode({ onDirty }) {
  // ----- Core form state -----
  const [code, setCode] = useState('') // max 10 chars
  const [valueType, setValueType] = useState('percentage') // 'percentage' | 'fixed'
  const [value, setValue] = useState(10)

  // ===== Unsaved changes guard =====
  const [dirty, setDirty] = useState(false)
  const [showPrompt, setShowPrompt] = useState(false)
  const pendingHrefRef = useRef(null)
  const allowNavRef = useRef(false)

  const markDirty = () => {
    setDirty(true)
  }

  // Customer eligibility
  const [eligibility, setEligibility] = useState('all')
  const [guestIncluded, setGuestIncluded] = useState(false)

  // Usage limit (mutually exclusive)
  const [limitPerCustomerOnce, setLimitPerCustomerOnce] = useState(true)
  const [limitPerAccount, setLimitPerAccount] = useState(false)
  const [perAccountUses, setPerAccountUses] = useState('')

  // Amount rules
  const [minPurchase, setMinPurchase] = useState('')
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('')

  // Active period
  const [startDate, setStartDate] = useState('')
  const [startTime, setStartTime] = useState('')
  const [hasEnd, setHasEnd] = useState(false)
  const [endDate, setEndDate] = useState('')
  const [endTime, setEndTime] = useState('')

  // Actions / validation
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)

  // Intercept browser back
  useEffect(() => {
    const handler = () => {
      if (!dirty || allowNavRef.current) return
      history.pushState({}, '')
      setShowPrompt(true)
    }

    window.addEventListener('popstate', handler)
    return () => window.removeEventListener('popstate', handler)
  }, [dirty])

  // RTK mutations
  const [addOrderDiscount] = useAddOrderDiscountMutation()
  const [checkDiscountCode, { isLoading: checkingCode }] = useCheckDiscountCodeMutation()

  // Get currency (single call)
  const { data: currency = '-', isLoading: currencyLoading } = useGetDiscountCurrencyQuery()

  const todayISO = () => {
    const now = new Date()
    const y = now.getFullYear()
    const m = String(now.getMonth() + 1).padStart(2, '0')
    const d = String(now.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }

  // keep endDate >= startDate
  useEffect(() => {
    if (!startDate) return
    if (hasEnd && endDate && endDate < startDate) setEndDate(startDate)
  }, [startDate, hasEnd, endDate])

  // Enforce mutual exclusivity
  const togglePerCustomerOnce = (checked) => {
    setLimitPerCustomerOnce(checked)
    if (checked) {
      setLimitPerAccount(false)
      setPerAccountUses('')
    }
    markDirty()
  }
  const togglePerAccount = (checked) => {
    setLimitPerAccount(checked)
    if (checked) {
      setLimitPerCustomerOnce(false)
    } else {
      setPerAccountUses('')
    }
    markDirty()
  }

  // ---------- minimal time helpers/state (placed after date/time state) ----------
  const [startTimeMin, setStartTimeMin] = useState('00:00')
  const [endTimeMin, setEndTimeMin] = useState('00:00')

  const nowTimeRounded = () => {
    const d = new Date()
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  }
  const timeToMinutes = (t) => {
    if (!t) return NaN
    const [hh, mm] = String(t).split(':').map(Number)
    return Number.isFinite(hh) && Number.isFinite(mm) ? hh * 60 + mm : NaN
  }
  const minutesToTime = (m) => {
    if (!Number.isFinite(m)) return ''
    const hh = Math.floor(m / 60) % 24
    const mm = m % 60
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`
  }

  // if startDate is today, make startTime min = now and bump startTime if earlier
  useEffect(() => {
    if (!startDate) {
      setStartTimeMin('00:00')
      return
    }
    const today = todayISO()
    if (startDate === today) {
      const now = nowTimeRounded()
      setStartTimeMin(now)
      if (startTime && timeToMinutes(startTime) < timeToMinutes(now)) {
        setStartTime(now)
      }
    } else {
      setStartTimeMin('00:00')
    }
  }, [startDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // compute endTimeMin when end is enabled and dates/times change
  useEffect(() => {
    let min = '00:00'

    // same-day end: require end > start => min = startTime + 1 minute
    if (hasEnd && startDate && endDate && startDate === endDate && startTime) {
      const s = timeToMinutes(startTime)
      if (Number.isFinite(s)) {
        min = minutesToTime(s + 1)
      }
    } else if (hasEnd && endDate === todayISO()) {
      // end is today (but not same as start): disallow past times
      min = nowTimeRounded()
    }

    setEndTimeMin(min)

    // clear invalid endTime
    if (endTime && Number.isFinite(timeToMinutes(endTime)) && Number.isFinite(timeToMinutes(min)) && timeToMinutes(endTime) < timeToMinutes(min)) {
      setEndTime('')
    }
  }, [hasEnd, startDate, startTime, endDate]) // eslint-disable-line react-hooks/exhaustive-deps

  // --- Derived summary bits ---
  const valueSummary = useMemo(() => {
    if (valueType === 'percentage') return `${Number(value || 0)}%`
    return `${currency || '$'}${Number(value || 0).toFixed(2)}`
  }, [valueType, value, currency])

  const eligibilitySummary = useMemo(() => {
    const base = eligibility === 'all' ? 'All customers' : eligibility === 'new' ? 'New customers' : 'Existing customers'
    return guestIncluded ? `${base} + Guests` : base
  }, [eligibility, guestIncluded])

  const usageSummary = useMemo(() => {
    const parts = []
    if (limitPerCustomerOnce) parts.push('Unlimited Discount Usage')
    if (limitPerAccount) parts.push(`Per account: ${perAccountUses || 0}`)
    return parts.length ? parts.join(' • ') : 'No limits'
  }, [limitPerCustomerOnce, limitPerAccount, perAccountUses])

  const periodSummary = useMemo(() => {
    if (!startDate || !startTime) return 'Start date/time required'
    const start = `${startDate} ${startTime}`
    if (!hasEnd) return `${start} → (no end)`
    if (!endDate || !endTime) return `${start} → (end date/time required)`
    return `${start} → ${endDate} ${endTime}`
  }, [startDate, startTime, hasEnd, endDate, endTime])

  // --- Validation ---
  const validate = () => {
    const e = {}
    if (!code.trim()) e.code = 'Discount code is required.'
    if (code.trim().length > 10) e.code = 'Code must be 10 characters or fewer.'
    if (errors.codeBackend) e.code = errors.codeBackend

    if (valueType === 'percentage') {
      if (value === '' || Number(value) < 1 || Number(value) > 100) e.value = 'Enter % between 1 and 100.'
      if (maxDiscountAmount !== '' && Number(maxDiscountAmount) <= 0) {
        e.maxDiscountAmount = 'Maximum discount must be greater than 0.'
      }
    } else {
      if (value === '' || Number(value) <= 0) e.value = 'Amount must be greater than 0.'
    }

    if (minPurchase === '' || Number(minPurchase) < 0) e.minPurchase = 'Minimum purchase is required.'

    if (limitPerAccount) {
      if (perAccountUses === '' || Number(perAccountUses) < 1) e.perAccount = 'Usage per account is required.'
    }

    const today = todayISO()
    if (!startDate) e.startDate = 'Start date is required.'
    if (!startTime) e.startTime = 'Start time is required.'
    if (startDate && startDate < today) e.startDate = 'Start date cannot be in the past.'
    if (hasEnd) {
      if (!endDate) e.endDate = 'End date is required.'
      if (!endTime) e.endTime = 'End time is required.'
      if (endDate && startDate && endDate < startDate) e.endDate = 'End date cannot be before start date.'

      // same-day: ensure times present and endTime > startTime; also ensure startTime not in past if startDate is today
      if (endDate && startDate && endDate === startDate) {
        const s = timeToMinutes(startTime)
        const en = timeToMinutes(endTime)
        if (!startTime) e.startTime = 'Start time is required.'
        if (!endTime) e.endTime = 'End time is required.'
        if (Number.isFinite(s) && Number.isFinite(en) && en <= s) e.endTime = 'End time must be after start time.'
        if (startDate === todayISO()) {
          const nowM = timeToMinutes(nowTimeRounded())
          if (Number.isFinite(s) && s < nowM) e.startTime = 'Start time cannot be in the past.'
        }
      } else if (endDate === todayISO()) {
        // end date is today (but not same as start) — ensure endTime is not before now
        const nowM = timeToMinutes(nowTimeRounded())
        const en = timeToMinutes(endTime)
        if (Number.isFinite(en) && en < nowM) e.endTime = 'End time cannot be in the past.'
      }
    }

    setErrors(e)
    return Object.keys(e).length === 0
  }

  // Intercept anchor navigation
  useEffect(() => {
    const handler = (e) => {
      if (!dirty || allowNavRef.current) return
      const a = e.target.closest?.('a[href]')
      if (!a) return

      e.preventDefault()
      pendingHrefRef.current = a.getAttribute('href')
      setShowPrompt(true)
    }

    document.addEventListener('click', handler, true)
    return () => document.removeEventListener('click', handler, true)
  }, [dirty])

  // --- Backend code check ---
  const debouncedCheckCode = useMemo(
    () =>
      debounce(async (value) => {
        if (value.length < 2) {
          setErrors((prev) => ({ ...prev, codeBackend: undefined }))
          return
        }
        try {
          const res = await checkDiscountCode({ discount_code: value }).unwrap()
          setErrors((prev) => ({
            ...prev,
            codeBackend: res.matched ? 'This discount code is already used.' : undefined,
          }))
        } catch (err) {
          console.error('Discount code check failed:', err)
        }
      }, 500),
    [checkDiscountCode],
  )

  // --- Handlers ---
  const handleCodeInput = (v) => {
    const cleaned = v
      .toUpperCase()
      .replace(/\s+/g, '')
      .replace(/[^A-Z0-9_-]/g, '')
      .slice(0, 10)
    setCode(cleaned)
    markDirty()
    debouncedCheckCode(cleaned)
  }

  const generateCode = () => {
    const c = randomCode(10)
    setCode(c)
    markDirty()
    debouncedCheckCode(c)
  }

  // Helpers
  const joinDateTime = (d, t) => (d && t ? `${d}T${t}:00` : null)
  const toNumOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v))

  // Submit
  const onSave = async () => {
    if (!validate()) return
    setSaving(true)

    Swal.fire({
      title: 'Saving discount…',
      allowEscapeKey: false,
      allowOutsideClick: false,
      showConfirmButton: false,
      didOpen: () => Swal.showLoading(),
    })

    try {
      const payload = {
        main_discount_type: 'order',
        discount_title: null,
        discount_value_type: valueType,
        discount_value: Number(value),
        min_max_purchase_discount_limits: true,
        min_purchase_amount: toNumOrNull(minPurchase),
        max_discount_amount: valueType === 'percentage' ? toNumOrNull(maxDiscountAmount) : null,
        customer_eligibility: eligibility,
        is_guest_allowed: !!guestIncluded,
        unlimited_usage: !!limitPerCustomerOnce,
        usage_limit_per_account: limitPerAccount ? toNumOrNull(perAccountUses) : null,
        status: 'active',
        start_date: joinDateTime(startDate, startTime),
        end_date: hasEnd ? joinDateTime(endDate, endTime) : null,
        discount_code: code.toUpperCase().slice(0, 10),
        order_discount_method: 'code',
        payment_method: null,
      }

      await addOrderDiscount(payload).unwrap()

      setSaving(false)

      const res = await Swal.fire({
        icon: 'success',
        title: 'Discount saved',
        text: 'Discount code has been created successfully.',
        confirmButtonText: 'OK',
      })

      if (res.isConfirmed) {
        allowNavRef.current = true
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('discount:saved'))
        }
      }
    } catch (err) {
      console.error('Add order discount (code) failed:', err)
      setSaving(false)
      Swal.fire({
        icon: 'error',
        title: 'Save failed',
        text: err?.data?.error || err?.error || 'Please try again.',
        confirmButtonText: 'OK',
      })
    }
  }

  return (
    <Card className="soft-card mb-0">
      <Card.Header className="bg-white d-flex align-items-start justify-content-between">
        <div>
          <Card.Title className="mb-0">Discount Code</Card.Title>
          <small className="text-muted">Customers must enter a code at checkout.</small>
        </div>
      </Card.Header>

      <Card.Body>
        <Row className="g-3">
          {/* ---------- LEFT: Form ---------- */}
          <Col lg={8}>
            {/* Code */}
            <section className="section mt-">
              <div className="section-head mt-0">
                <span className="section-title">Discount Code</span>
                <Button size="sm" variant="link" className="p-0 fw-semibold" onClick={generateCode}>
                  Generate Random Code
                </Button>
              </div>
              <div className="section-body">
                <InputGroup>
                  <InputGroup.Text className="fw-semibold">Code</InputGroup.Text>
                  <Form.Control
                    value={code}
                    required
                    maxLength={10}
                    onChange={(e) => handleCodeInput(e.target.value)}
                    isInvalid={!!errors.code || !!errors.codeBackend}
                    disabled={checkingCode}
                  />
                  {checkingCode && (
                    <Spinner
                      animation="border"
                      size="sm"
                      className="position-absolute"
                      style={{ right: '10px', top: '50%', transform: 'translateY(-50%)' }}
                    />
                  )}
                  <Form.Control.Feedback type="invalid">{errors.code || errors.codeBackend}</Form.Control.Feedback>
                </InputGroup>
                <div className="d-flex justify-content-between mt-1">
                  <small className="text-muted">{code.length}/10</small>
                  {errors.code && <small className="text-danger nowrap">{errors.code}</small>}
                </div>
              </div>
            </section>

            {/* Discount Value */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Discount Value</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-perc"
                        name="val-type"
                        checked={valueType === 'percentage'}
                        onChange={() => {
                          setValueType('percentage')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Percentage</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <div className="stacked-choice">
                      <Form.Check
                        type="radio"
                        id="val-type-fixed"
                        name="val-type"
                        checked={valueType === 'fixed'}
                        onChange={() => {
                          setValueType('fixed')
                          markDirty()
                        }}
                        label={<span className="fw-semibold nowrap">Fixed Amount</span>}
                        required
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <InputGroup>
                      {valueType === 'percentage' ? (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">%</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="1"
                            max="100"
                            step="1"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                            isInvalid={!!errors.value}
                          />
                        </>
                      ) : (
                        <>
                          <InputGroup.Text className="fw-semibold nowrap">{currency || 'LKR'}</InputGroup.Text>
                          <Form.Control
                            type="number"
                            min="0.01"
                            step="0.01"
                            required
                            value={value}
                            onChange={(e) => {
                              setValue(Number(e.target.value || 0))
                              markDirty()
                            }}
                            isInvalid={!!errors.value}
                          />
                        </>
                      )}
                      <Form.Control.Feedback type="invalid">{errors.value}</Form.Control.Feedback>
                    </InputGroup>
                  </Col>
                </Row>
              </div>
            </section>

            {/* Amount Limits */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Set Minimum Purchase and Maximum Discount Amount</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={6}>
                    <InputGroup>
                      <InputGroup.Text className="fw-semibold nowrap">Minimum Purchase Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                      <Form.Control
                        type="number"
                        min="0"
                        step="0.01"
                        value={minPurchase}
                        onChange={(e) => {
                          setMinPurchase(e.target.value)
                          markDirty()
                        }}
                        required
                        isInvalid={!!errors.minPurchase}
                      />
                      <Form.Control.Feedback type="invalid">{errors.minPurchase}</Form.Control.Feedback>
                    </InputGroup>
                  </Col>

                  {valueType === 'percentage' && (
                    <Col md={6}>
                      <InputGroup>
                        <InputGroup.Text className="fw-semibold nowrap">Max Discount Amount {currency ? `(${currency})` : ''}</InputGroup.Text>
                        <Form.Control
                          type="number"
                          min="0.01"
                          step="0.01"
                          value={maxDiscountAmount}
                          onChange={(e) => {
                            setMaxDiscountAmount(e.target.value)
                            markDirty()
                          }}
                          placeholder="Optional"
                          isInvalid={!!errors.maxDiscountAmount}
                        />
                        <Form.Control.Feedback type="invalid">{errors.maxDiscountAmount}</Form.Control.Feedback>
                      </InputGroup>
                    </Col>
                  )}
                </Row>
              </div>
            </section>

            {/* Customer Eligibility */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Customer Eligibility</span>
              </div>
              <div className="section-body">
                <Row className="g-2 align-items-center">
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-all"
                      checked={eligibility === 'all'}
                      onChange={() => {
                        setEligibility('all')
                        markDirty()
                      }}
                      label="All Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-new"
                      checked={eligibility === 'new'}
                      onChange={() => {
                        setEligibility('new')
                        markDirty()
                      }}
                      label="New Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="radio"
                      name="elig"
                      id="elig-existing"
                      checked={eligibility === 'existing'}
                      onChange={() => {
                        setEligibility('existing')
                        markDirty()
                      }}
                      label="Existing Customers"
                      required
                    />
                  </Col>
                  <Col md={3}>
                    <Form.Check
                      type="checkbox"
                      id="elig-guest"
                      checked={guestIncluded}
                      onChange={(e) => {
                        setGuestIncluded(e.target.checked)
                        markDirty()
                      }}
                      label="Guest Customers"
                    />
                  </Col>
                </Row>
              </div>
            </section>

            {/* Maximum Discount Uses (mutually exclusive, always one selected) */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Maximum Discount Uses</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  {/* LEFT COLUMN — Unlimited Discount */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-customer"
                      checked={limitPerCustomerOnce}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // prevent both from being off
                        if (!checked && !limitPerAccount) return

                        // call your existing handler
                        togglePerCustomerOnce(checked)

                        // exclusivity
                        if (checked && limitPerAccount) {
                          togglePerAccount(false)
                        }
                      }}
                      label="Unlimited Discount Usage"
                    />
                  </Col>

                  {/* RIGHT COLUMN — Per Account Usage Limit */}
                  <Col md={6}>
                    <Form.Check
                      type="checkbox"
                      id="limit-per-account"
                      checked={limitPerAccount}
                      onChange={(e) => {
                        const checked = e.target.checked

                        // prevent both from being off
                        if (!checked && !limitPerCustomerOnce) return

                        // call your existing handler
                        togglePerAccount(checked)

                        // exclusivity
                        if (checked && limitPerCustomerOnce) {
                          togglePerCustomerOnce(false)
                        }
                      }}
                      label="Set usage limit per account"
                    />

                    {limitPerAccount && (
                      <div className="mt-2" style={{ maxWidth: 220 }}>
                        <Form.Control
                          type="number"
                          min="1"
                          step="1"
                          required
                          value={perAccountUses}
                          onChange={(e) => {
                            setPerAccountUses(e.target.value)
                            markDirty()
                          }}
                          isInvalid={!!errors.perAccount}
                        />
                        <Form.Control.Feedback type="invalid">{errors.perAccount}</Form.Control.Feedback>
                      </div>
                    )}
                  </Col>
                </Row>
              </div>
            </section>

            {/* Active Period */}
            <section className="section">
              <div className="section-head">
                <span className="section-title">Active Dates</span>
              </div>
              <div className="section-body">
                <Row className="g-3">
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Date <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="date"
                      required
                      min={todayISO()}
                      value={startDate}
                      onChange={(e) => {
                        setStartDate(e.target.value)
                        markDirty()
                        // if start becomes today and startTime is earlier than now, bump it (extra safety)
                        if (e.target.value === todayISO() && startTime && timeToMinutes(startTime) < timeToMinutes(nowTimeRounded())) {
                          setStartTime(nowTimeRounded())
                        }
                        // also ensure endDate not before startDate
                        if (hasEnd && endDate && endDate < e.target.value) setEndDate(e.target.value)
                      }}
                      isInvalid={!!errors.startDate}
                    />
                    <Form.Control.Feedback type="invalid">{errors.startDate}</Form.Control.Feedback>
                  </Col>
                  <Col md={3}>
                    <Form.Label className="fw-semibold">
                      Start Time <span className="text-danger">*</span>
                    </Form.Label>
                    <Form.Control
                      type="time"
                      required
                      value={startTime}
                      min={startTimeMin}
                      onChange={(e) => {
                        setStartTime(e.target.value)
                        markDirty()
                        // if same-day end and endTime <= new start, clear endTime so user re-selects
                        if (
                          hasEnd &&
                          endDate &&
                          startDate &&
                          endDate === startDate &&
                          endTime &&
                          timeToMinutes(endTime) <= timeToMinutes(e.target.value)
                        ) {
                          setEndTime('')
                        }
                      }}
                      isInvalid={!!errors.startTime}
                    />
                    <Form.Control.Feedback type="invalid">{errors.startTime}</Form.Control.Feedback>
                    {startTimeMin !== '00:00' && (
                      <small className="text-muted d-block">Earliest selectable time for chosen date: {startTimeMin}</small>
                    )}
                  </Col>
                  <Col md={12}>
                    <Form.Check
                      id="has-end"
                      type="checkbox"
                      className="mt-0"
                      checked={hasEnd}
                      onChange={(e) => {
                        setHasEnd(e.target.checked)
                        markDirty()
                        if (e.target.checked) {
                          // suggest endDate and endTime to reduce clicks:
                          const suggestedEndDate = startDate || todayISO()
                          setEndDate(suggestedEndDate)
                          // friendly suggested endTime: startTime +1 hour if available, else now +1h
                          let suggested = ''
                          if (startTime && Number.isFinite(timeToMinutes(startTime))) {
                            suggested = minutesToTime(timeToMinutes(startTime) + 60)
                          } else {
                            suggested = minutesToTime(timeToMinutes(nowTimeRounded()) + 60)
                          }
                          setEndTime(suggested)
                        } else {
                          setEndDate('')
                          setEndTime('')
                        }
                      }}
                      label="Set End Date"
                    />
                  </Col>
                  {hasEnd && (
                    <>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Date <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="date"
                          required
                          min={startDate || todayISO()}
                          value={endDate}
                          onChange={(e) => {
                            setEndDate(e.target.value)
                            markDirty()
                            // if new end is same as start, and current endTime is less than allowed min, clear it
                            if (
                              e.target.value &&
                              startDate &&
                              e.target.value === startDate &&
                              endTime &&
                              timeToMinutes(endTime) < timeToMinutes(endTimeMin)
                            ) {
                              setEndTime('')
                            }
                          }}
                          isInvalid={!!errors.endDate}
                        />
                        <Form.Control.Feedback type="invalid">{errors.endDate}</Form.Control.Feedback>
                      </Col>
                      <Col md={3}>
                        <Form.Label className="fw-semibold">
                          End Time <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          type="time"
                          required
                          value={endTime}
                          min={endTimeMin}
                          onChange={(e) => {
                            setEndTime(e.target.value)
                            markDirty()
                          }}
                          isInvalid={!!errors.endTime}
                        />
                        <Form.Control.Feedback type="invalid">{errors.endTime}</Form.Control.Feedback>
                        {hasEnd && startDate && endDate && startDate === endDate && startTime && (
                          <small className="text-muted d-block">End time must be after start time ({startTime})</small>
                        )}
                      </Col>
                    </>
                  )}
                </Row>
              </div>
            </section>

            {/* Footer actions */}
            <div className="footer-actions">
              <Button
                variant="outline-secondary"
                onClick={async () => {
                  const res = await Swal.fire({
                    title: 'Discard changes?',
                    text: 'Do you want to discard the changes?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Discard',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#111827',
                  })

                  if (res.isConfirmed) {
                    if (typeof window !== 'undefined') {
                      window.dispatchEvent(new CustomEvent('discount:saved'))
                    }
                  }
                }}>
                Discard
              </Button>

              <Button onClick={onSave} disabled={saving || checkingCode}>
                {saving ? (
                  <>
                    <Spinner animation="border" size="sm" className="me-2" /> Saving…
                  </>
                ) : (
                  'Save'
                )}
              </Button>
            </div>
          </Col>

          {/* ---------- RIGHT: Summary ---------- */}
          <Col lg={4}>
            <aside className="summary-card">
              <div className="sum-head">Discount Summary</div>
              <div className="sum-row">
                <div className="sum-label">Discount Code</div>
                <div className="sum-value code">{code || '—'}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Discount Value</div>
                <div className="sum-value">{valueSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Eligibility</div>
                <div className="sum-value">{eligibilitySummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Usage Limits</div>
                <div className="sum-value">{usageSummary}</div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Amount Rules</div>
                <div className="sum-value">
                  Min Purchase: {minPurchase === '' ? '—' : `${currency || 'LKR'} ${Number(minPurchase).toFixed(2)}`}
                  <br />
                  {valueType === 'percentage' ? (
                    <>Max Discount: {maxDiscountAmount === '' ? '—' : `${currency || 'LKR'} ${Number(maxDiscountAmount).toFixed(2)}`}</>
                  ) : (
                    <>Max Discount: —</>
                  )}
                </div>
              </div>
              <div className="sum-row">
                <div className="sum-label">Active Period</div>
                <div className="sum-value">{periodSummary}</div>
              </div>
            </aside>
          </Col>
        </Row>
      </Card.Body>

      {/* Styles */}
      <style jsx>{`
        .section + .section {
          margin-top: 16px;
        }
        .section-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 10px 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-bottom: none;
          border-radius: 12px 12px 0 0;
          background: #f5f7fb;
        }
        .section-title {
          font-weight: 700;
          color: #111827;
        }
        .section-body {
          padding: 12px;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 0 0 12px 12px;
          background: #fff;
        }
        .stacked-choice {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 10px;
          padding: 10px 12px;
          background: #fff;
        }
        .footer-actions {
          display: flex;
          gap: 10px;
          justify-content: flex-end;
          margin-top: 18px;
        }
        .nowrap {
          white-space: nowrap;
        }

        .summary-card {
          border: 1px solid rgba(0, 0, 0, 0.08);
          border-radius: 12px;
          background: #fff;
          padding: 12px;
        }
        .sum-head {
          font-weight: 700;
          color: #111827;
          background: #f5f7fb;
          border: 1px solid rgba(0, 0, 0, 0.06);
          border-radius: 10px;
          padding: 10px 12px;
          margin-bottom: 10px;
        }
        .sum-row {
          display: grid;
          grid-template-columns: 140px 1fr;
          gap: 10px;
          padding: 8px 2px;
        }
        .sum-label {
          color: #6b7280;
          font-weight: 600;
        }
        .sum-value {
          color: #111827;
        }
        .sum-value.code {
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;
        }
      `}</style>
      <Modal show={showPrompt} onHide={() => setShowPrompt(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Unsaved changes</Modal.Title>
        </Modal.Header>
        <Modal.Body>You have unsaved changes. Leave without saving?</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowPrompt(false)}>
            Stay
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              allowNavRef.current = true
              setShowPrompt(false)
              if (pendingHrefRef.current) {
                window.location.href = pendingHrefRef.current
              } else {
                history.back()
              }
            }}>
            Leave
          </Button>
        </Modal.Footer>
      </Modal>
    </Card>
  )
}

function randomCode(len = 10) {
  const alpha = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let s = ''
  for (let i = 0; i < len; i++) s += alpha[Math.floor(Math.random() * alpha.length)]
  return s
}
