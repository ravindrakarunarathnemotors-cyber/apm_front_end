
import React from 'react';
import dynamic from 'next/dynamic';

export const metadata = {
  title: 'All Quotations',
}

const AllQuotations = dynamic(() => import('./AllQuotations'), { ssr: false })

const AllQuotationsPage = () => {
  return (
    <div>
      <AllQuotations />
    </div>
  );
};

export default AllQuotationsPage;
