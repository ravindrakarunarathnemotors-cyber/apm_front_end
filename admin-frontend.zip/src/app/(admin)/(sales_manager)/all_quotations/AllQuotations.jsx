'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  Button,
  Table,
  Pagination,
  Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import InvoiceModal from '../invoice/modal/InvoiceModal'
import QutationView from './component/quotationView'
import axios from 'axios'

import {
  useGetFilteredQuotationsMutation,
  useGetRecipientnameQuery,
  useSendQutationMutation,
  useRejectQutationMutation,
  useApprovedQutationMutation,
  useCancelQutationMutation,
  useRefreshTokenMutation,
} from '@/store/features/apiSlice'

function AllQuotations() {
  const Logout = () => {
    sessionStorage.clear()
    localStorage.clear()
    window.location.href = '/auth/login'
  }
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })

  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [refreshtoken] = useRefreshTokenMutation()
  const [orderStatuses, setOrderStatuses] = useState([])
  const [fetchFilteredOrders, { isLoading, error }] = useGetFilteredQuotationsMutation()
  const [sendQutation, { isLoading: sendingQuotation }] = useSendQutationMutation();
  const [rejectQutation, { isLoading: rejectQuotation }] = useRejectQutationMutation();
  const [approveQuotation, { isLoading: approveQuotations }] = useApprovedQutationMutation();
  const [cancelQuotation, { isLoading: cancelQuotations }] = useCancelQutationMutation();

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [orders, setOrders] = useState([])
  const logsPerPage = 25
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')

  const [selectedOrderId, setSelectedOrderId] = useState(null)

  const [loading, setLoading] = useState(false)
  //const [showViewModal, setShowViewModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')

  const [searchRecipient, setSearchRecipient] = useState('')

  const [cancelOrder, setCancelOrder] = useState(null)

  const [currency, setCurrency] = useState('');
  const printSectionRef = useRef()
  const router = useRouter()


  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handlePayment = (order) => {
    setSelectedOrderId(order)
    setShowPaymentModal(true)
  }

  const handleUnpaidClick = (order_id) => {
    setSelectedOrderId(order_id)
    setShowUnpaidModal(true)
  }

  const handleUnpaidCloseModal = () => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
  }

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const token = sessionStorage.getItem('access_token')
      const res = await fetchFilteredOrders({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        status: paymentStatus,
        date: date,
        todate: todate,
        order_status: orderStatuses.map((s) => s.value),
      }).unwrap()

      setOrders(res.orders || [])
      setTotalPages(res.totalPages || 1)
      setCurrency(res.currency || res.orders?.[0]?.currency || ''); setCurrency(res.orders?.[0]?.currency || '');
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch orders:', err)
      // Handle 401/403 → try refresh → retry once
      const status = err?.status || err?.originalStatus || err?.data?.status
      if (status === 401 || status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const refreshed = await refreshtoken(refreshToken).unwrap()
            // Save new access token and retry the same call
            if (refreshed?.access_token) {
              sessionStorage.setItem('access_token', refreshed.access_token)
            }
            const retry = await fetchFilteredOrders({
              page,
              limit: logsPerPage,
              keyword: filters.keyword,
              order_id: orderId,
              recipient_name: recipientName,
              mobile: mobileNo,
              payment_status: paymentStatus,
              date: date,
              todate: todate,
              order_status: orderStatuses.map((s) => s.value),
            }).unwrap()

            setOrders(retry.orders || [])
            setTotalPages(retry.totalPages || 1)
            setCurrentPage(page)
          } catch (refreshErr) {
            console.error('Refresh failed:', refreshErr)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        console.error('Failed to fetch orders:', err)
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])




  const handleCancel = async (orderId) => {
    try {
      // Show confirmation dialog
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to mark Quotation ${orderId} as Cancel?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'No, cancel',
      });

      if (!isConfirmed) return;

      // Get user id
      const user_id = sessionStorage.getItem('user_id');
      if (!user_id) {
        await Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error');
        return;
      }

      // Call backend API to update order status
      await cancelQuotation({
        order_id: orderId,
        status: 'cancelled',
        user_id,
      }).unwrap();

      // Success message
      await Swal.fire('Sent', `Quotation ${orderId} was send successfully.`, 'success');

      // Optional: refresh logs or order list
      await fetchLogs(currentPage);

    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while sending the order.';
      await Swal.fire('Error', msg, 'error');
    }
  };
  const handleTransfer = async (orderId) => {
    try {
      // Show confirmation dialog
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to convert this Quotation ${orderId}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, convert it!',
        cancelButtonText: 'No, cancel',
      });

      if (!isConfirmed) return;

      let token = sessionStorage.getItem('access_token')

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/quotation/transfer-quotation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          id: orderId
        }),
      })

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return handleTransfer(orderId)
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json()

      if (response.status === 200) {
       
        await Swal.fire('Sent', `Quotation ${orderId} was Transferred successfully.`, 'success');
        setShowViewModal(false)
      } else {
        Swal.fire('Error', data.message || 'Something went wrong.', 'error');
      }

      // Optional: refresh logs or order list
      await fetchLogs(currentPage);

    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong.';
      await Swal.fire('Error', msg, 'error');
    }
  };


  const handleRejected = async (orderId) => {
    try {
      // Show confirmation dialog
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to mark Quotation ${orderId} as Rejected?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Rejected it!',
        cancelButtonText: 'No, cancel',
      });

      if (!isConfirmed) return;

      // Get user id
      const user_id = sessionStorage.getItem('user_id');
      if (!user_id) {
        await Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error');
        return;
      }

      // Call backend API to update order status
      await rejectQutation({
        quotation_id: orderId,
        status: 'rejected',

      }).unwrap();

      // Success message
      await Swal.fire('Sent', `Quotation ${orderId} was rejected successfully.`, 'success');

      // Optional: refresh logs or order list
      await fetchLogs(currentPage);

    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while sending the Quotation.';
      await Swal.fire('Error', msg, 'error');
    }
  };


  const handleSendInvoice = async (order) => {
    try {
      setSelectedOrder({
        ...order,
        autoOpenSend: true,
      })
      setShowViewModal(true)
    } catch (err) {
      console.error(err)
    }
  }



  const handleapproved = async (orderId) => {
    try {
      // Show confirmation dialog
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to mark Quotation ${orderId} as Approved?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Approve it!',
        cancelButtonText: 'No, cancel',
      });

      if (!isConfirmed) return;

      // Get user id
      const user_id = sessionStorage.getItem('user_id');
      if (!user_id) {
        await Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error');
        return;
      }

      // Call backend API to update order status
      await approveQuotation({
        quotation_id: orderId,
        status: 'approved',

      }).unwrap();

      // Success message
      await Swal.fire('Sent', `Quotation ${orderId} was approved successfully.`, 'success');

      // Optional: refresh logs or order list
      await fetchLogs(currentPage);

    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while sending the Quotation.';
      await Swal.fire('Error', msg, 'error');
    }
  };


  // const handleBacktoSend = async (orderId) => {
  //   try {
  //     // Show confirmation dialog
  //     const { isConfirmed } = await Swal.fire({
  //       title: 'Are you sure?',
  //       text: `Do you want to mark Quotation ${orderId} as Back to Send?`,
  //       icon: 'warning',
  //       showCancelButton: true,
  //       confirmButtonText: 'Yes, Back to Send it!',
  //       cancelButtonText: 'No, cancel',
  //     });

  //     if (!isConfirmed) return;

  //     // Get user id
  //     const user_id = sessionStorage.getItem('user_id');
  //     if (!user_id) {
  //       await Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error');
  //       return;
  //     }

  //     // Call backend API to update order status
  //     await sendQutation({
  //       quotation_id: orderId,
  //       status: 'sent',
  //     }).unwrap();

  //     // Success message
  //     await Swal.fire('Sent', `Quotation ${orderId} was Back to Send successfully.`, 'success');

  //     // Optional: refresh logs or order list
  //     await fetchLogs(currentPage);

  //   } catch (err) {
  //     const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while Back to Send the Quotation.';
  //     await Swal.fire('Error', msg, 'error');
  //   }
  // };




  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }


  const [selectedOrder, setSelectedOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)


  const handleView = (order) => {
    setSelectedOrder(order)
    setShowViewModal(true)
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader
            className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Ongoing Quotations
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Keyword</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {

                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}

                />
              </FormGroup>
              <FormGroup className="col-md-4">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                    />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={todate}
                      onChange={(e) => setToDate(e.target.value)}
                    />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-4">
                <FormLabel>Status</FormLabel>
                <Form.Select
                  value={paymentStatus}
                  onChange={(e) => setPaymentStatus(e.target.value)}
                >
                  <option value="">All</option>
                  <option value="pending">Pending</option>
                  <option value="sent">Sent</option>
                  <option value="approved">Approved</option>
                  <option value="expired">Expired</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>
            {isLoading ? (
              <p>Loading Orders...</p>
            ) : error ? (
              <p>Error Loading Orders.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <Table striped className="table my-2">
                    <thead className="table-light">
                      <tr>
                        <th>Quotation ID</th>
                        <th>Start Date</th>
                        <td>Expired Date</td>
                        <th>Client</th>

                        <th>Status</th>
                        <th className="text-end">Total ({currency})</th>
                        <th className="text-center no-print">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="text-center">
                            No Orders found.
                          </td>
                        </tr>
                      ) : (
                        orders.map((order) => (
                          <tr key={order.id}>
                            <td>
                              {order.id}

                            </td>
                            <td>{new Date(order.quotation_date).toLocaleDateString()}</td>
                            <td>
                              {(() => {
                                const createdDate = new Date(order.quotation_date);
                                const expiryDate = new Date(createdDate);
                                expiryDate.setDate(createdDate.getDate() + order.time_period);
                                return expiryDate.toLocaleDateString();
                              })()}
                            </td>
                            <td>
                              {order.customer_name} ({order.customer_id})
                              <br />
                              <small>{order.contact_number}</small>
                            </td>




                            <td>

                              {order.status
                                ? order.status.charAt(0).toUpperCase() + order.status.slice(1)
                                : ''}

                              {hasSlip(order) && (
                                <div className="mt-1 no-print">
                                  <Button
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.2rem 0.1rem',
                                      fontSize: '0.55rem',
                                      height: '20px',
                                      borderRadius: '15px',
                                      backgroundColor: '#3d3642ff',
                                      borderColor: '#3d3642ff',
                                      color: '#fff',
                                    }}
                                    variant="outline-primary"
                                    onClick={() => openSlip(order)}
                                    title="Open bank slip"
                                    className="d-inline-flex align-items-center gap-1 px-2 py-1"
                                  >
                                    <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                    Slip
                                  </Button>
                                </div>
                              )}
                            </td>

                            <td className="text-end">
                              {Number(order.full_amount).toFixed(2)}
                            </td>

                            <td className="text-center no-print">
                              <div className="d-flex flex-row align-items-center justify-content-end gap-2">
                                {order.status?.toLowerCase() === 'pending' && (
                                  <>


                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#3d0a36ff',
                                        borderColor: '#3d0a36ff',
                                        color: '#fff',
                                      }}

                                      onClick={() => handleSendInvoice(order)}

                                    >
                                      <Icon icon="mdi:send" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Send</span>
                                    </Button>


                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#fd7e14',
                                        borderColor: '#fd7e14',
                                        color: '#fff',
                                      }}
                                      onClick={() => router.push(`/update_quotations?qutation_id=${order.id}`)}
                                    >
                                      <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Edit</span>
                                    </Button>
                                  </>
                                )}
                                {order.status?.toLowerCase() === 'approved' && (
                                  <>
                                    {/* <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#70185f',
                                        borderColor: '#70185f',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleBacktoSend(order.id)}
                                    >
                                      <Icon icon="mdi:send-clock" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Back to Send</span>
                                    </Button> */}


                                  </>
                                )}

                                {['sent', 'approved'].includes(
                                  order.status?.toLowerCase()
                                ) && (
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#74190d',
                                        borderColor: '#74190d',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleRejected(order.id)}
                                    >
                                      <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Reject</span>
                                    </Button>
                                  )}

                                {['pending', 'approved', 'rejected'].includes(
                                  order.status?.toLowerCase()
                                ) && (
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#dc3545',
                                        borderColor: '#dc3545',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleCancel(order.id)}
                                    >
                                      <Icon icon="mdi:close" width={16} className="me-1" />
                                      Cancel
                                    </Button>
                                  )}

                                {order.status?.toLowerCase() === 'approved' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#06a8f3',
                                      borderColor: '#06a8f3',
                                      color: '#fff',
                                    }}
                                  onClick={() => handleTransfer(order.id)}
                                  >
                                    <Icon icon="mdi:transfer" width={16} className="me-1" />
                                    Invoice
                                  </Button>
                                )}


                                {order.status?.toLowerCase() === 'sent' && (
                                  <>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#2e4d57',
                                        borderColor: '#2e4d57',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleSendInvoice(order)}
                                    >
                                      <Icon icon="mdi:repeat" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Resend</span>
                                    </Button>




                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#042a57',
                                        borderColor: '#042a57',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleapproved(order.id)}
                                    >
                                      <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Approve</span>
                                    </Button>

                                  </>
                                )}

                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#007bff',
                                    borderColor: '#007bff',
                                    color: '#fff',
                                  }}
                                  onClick={() => handleView(order)}>
                                  <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span style={{ fontSize: '0.65rem' }}>View</span>
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>
                {totalPages > 1 && (
                  <nav aria-label="Page navigation" className="mt-3">
                    <ul className="pagination justify-content-end mb-0">
                      <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>
                          Previous
                        </button>
                      </li>

                      {getPageWindow(currentPage, totalPages, 5).map((page) => (
                        <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                          <button className="page-link" onClick={() => setCurrentPage(page)}>
                            {page}
                          </button>
                        </li>
                      ))}

                      <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                        <button
                          className="page-link"
                          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                          disabled={currentPage === totalPages}>
                          Next
                        </button>
                      </li>
                    </ul>
                  </nav>
                )}
              </>
            )}
          </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <QutationView
          show={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedOrder(null)
          }}
          order={selectedOrder}
          fetchLogs={fetchLogs}
          handleTransfer={handleTransfer}
        />
      )}


      {/* {showInvoiceModal && selectedOrder && (
        <QuotationModal
          show={showInvoiceModal}
          onClose={() => {
            setShowInvoiceModal(false)
            setSelectedOrder(null)
          }} order={selectedOrder} fetchLogs={fetchLogs} />)} */}





    </Row>
  )
}

export default AllQuotations
