'use client'

import React, { useEffect, useState } from 'react'
import Image from 'next/image'
import { Icon } from '@iconify/react'
import { Modal, Button, Card, CardBody, Col, Row, Table } from 'react-bootstrap'
import QuotationModal from './QuotationModal'
import {
  useGetBrandingSettingsQuery,
  useGetQuotationDetailsQuery,
  useGetAllPaymentMethodsQuery,
  useGetDiscountCurrencyQuery,
  useCancelQutationMutation,
  useSendQutationMutation,
} from '@/store/features/apiSlice'
import { useGetSubPaymentMethodsQuery } from '@/store/features/sandoSlice'
import Swal from 'sweetalert2'
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'
import DOMPurify from 'dompurify'

export default function InvoiceModal({ show, onClose, order = {}, fetchLogs, handleTransfer }) {
  console.log('Customer ID:', order?.customer_id)
  console.log('Order details:', order)
  const { data, isLoading, isError, refetch } = useGetQuotationDetailsQuery(order?.id)
  const autoOpenSend = order?.autoOpenSend === true
  const { data: branding } = useGetBrandingSettingsQuery()
  const [sendInvoice, { isLoading: sending }] = useSendQutationMutation()
  const [pdfFile, setPdfFile] = useState(null)

  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [printLoading, setPrintLoading] = useState(false)
  const [details, setDetails] = useState(null)
  const [note, setNote] = React.useState(order?.note || '')
  const [paymentForm, setPaymentForm] = useState({
    paymentMethod: '',
    subMethod: '',
    amount: '',
    reference: '',
    file: null,
  })
  const [uploading, setUploading] = useState(false)
  const [loading, setLoading] = useState(false)
  // const { data: currencyResp } = useGetDiscountCurrencyQuery()
  const { data: currency = '' } = useGetDiscountCurrencyQuery()

  const { data: paymentData, isLoading: loadingPayment, error: paymentError } = useGetAllPaymentMethodsQuery()

  const parsedTax = React.useMemo(() => {
    try {
      return typeof order?.tax === 'string' ? JSON.parse(order.tax) : order?.tax
    } catch (e) {
      console.error('Invalid tax JSON:', order?.tax)
      return null
    }
  }, [order?.tax])

  const {
    data: subPaymentData,
    isLoading: loadingSubPayment,
    error: subPaymentError,
  } = useGetSubPaymentMethodsQuery(paymentForm.paymentMethod, {
    skip: !paymentForm.paymentMethod,
  })

  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  const [refreshtoken] = useRefreshTokenMutation()
  const [cancelQuotation, { isLoading: cancelQuotations }] = useCancelQutationMutation()
  const { Logout } = useLogout()

  const invoiceNumber = order?.id
  const items = data?.order_payment_history ?? []
  const invoiceDetails = data?.order_items ?? []
  const [existingQuotationLink, setExistingQuotationLink] = useState(null)
  const orderDiscount = Number(order?.discount) ?? 0
  const subTotal = order?.total_value || 0
  const payment_status = order?.status
  // const tax_percentage = order?.tax_percentage
  // const taxAmount = Number(order?.tax?.value || 0)
  // const taxName = order?.tax?.name || 'Tax'
  const adminNote = details?.order_items?.[0]?.note

  const taxAmount = Number(parsedTax?.value ?? 0)
  const taxName = parsedTax?.name ?? 'Tax'
  const tax_percentage = Number(order?.tax_percentage ?? 0)

  // const currency = currencyResp?.currency || ''

  const hasItemDiscount = invoiceDetails.some((it) => Number(it.discount || 0) > 0)

  const quotationDateRaw = details?.order_items?.[0]?.quotation_date
  const discountType = details?.order_items?.[0]?.discount_type

  const quotationDate = React.useMemo(() => {
    if (!quotationDateRaw) return '-'

    const date = new Date(quotationDateRaw)

    return new Intl.DateTimeFormat('en-US', {
      timeZone: 'Asia/Colombo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    })
      .formatToParts(date)
      .reduce((acc, part) => {
        acc[part.type] = part.value
        return acc
      }, {})
  }, [quotationDateRaw])

  const expiryDateFormatted = React.useMemo(() => {
  const { quotation_date, time_period } = order;

 

  if (!quotation_date || time_period == null) {
    console.log('❌ Missing data');
    return '-';
  }

  const createdDate = new Date(quotation_date);


  if (isNaN(createdDate)) {
    console.log('❌ Invalid Date');
    return 'Invalid Date';
  }

  const expiryDate = new Date(createdDate);
  expiryDate.setDate(expiryDate.getDate() + Number(time_period));



  const formatted = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Colombo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(expiryDate);

  

  return formatted;
}, [order]);

  const issueDate = React.useMemo(() => {
    const raw = details?.order_items?.[0]?.quotation_date
    if (!raw) return '-'

    const date = new Date(raw)

    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Colombo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    }).format(date)
  }, [details])

  const validateDate = (dateString) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    if (isNaN(date)) return 'Invalid Date'
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  useEffect(() => {
    if (data) {
      setDetails(data)
    }
  }, [data])

  useEffect(() => {
    if (!show) return
    if (!autoOpenSend) return

    // ⏳ WAIT 5 SECONDS BEFORE OPENING SEND MODAL
    const timer = setTimeout(() => {
      setShowInvoiceModal(true) // open QuotationModal
    }, 1000) // ✅ 5 seconds

    return () => clearTimeout(timer)
  }, [show, autoOpenSend])

  const handleSendInvoice = async () => {
    if (!showInvoiceModal) {
      setShowInvoiceModal(true) // just open modal
      return
    }
  }

  const from = details?.fromdetails
  const customer = details?.customer_address
  const brandingSetting = branding?.data

  const termsConditions = React.useMemo(() => {
    try {
      // 1️⃣ Item-level terms (first item)
      const itemTerms = details?.order_items?.[0]?.recipent_note
      if (itemTerms) return JSON.parse(itemTerms)

      // 2️⃣ System-level fallback
      const systemTerms = details?.system_settings?.terms_conditions_quotations
      if (systemTerms) return JSON.parse(systemTerms)

      return []
    } catch (e) {
      console.error('Invalid Terms JSON', e)
      return []
    }
  }, [details])

  const handleCancel = async (orderId) => {
    try {
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you want to mark Quotation ${orderId} as Cancel?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'No',
      })

      if (!isConfirmed) return

      const user_id = sessionStorage.getItem('user_id')
      if (!user_id) {
        await Swal.fire('Error', 'User not logged in.', 'error')
        return
      }

      await cancelQuotation({
        order_id: orderId,
        status: 'cancelled',
        user_id,
      }).unwrap()

      await Swal.fire('Cancelled', `Quotation ${orderId} has been cancelled.`, 'success')

      // ✅ 1. Refresh quotation details (status updates instantly)
      await refetch()

      // ✅ 2. Refresh quotation list/logs
      fetchLogs(1)

      // ✅ 3. Close modal (optional but recommended)
      onClose()
    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while cancelling.'
      await Swal.fire('Error', msg, 'error')
    }
  }

  const handleChange = (e) => {
    const { name, value, files } = e.target

    // ✅ Only allow integers for amount
    if (name === 'amount') {
      const intRegex = /^\d+$/

      // allow empty input (so user can delete)
      if (value !== '' && !intRegex.test(value)) return
    }
    setPaymentForm((prev) => ({
      ...prev,
      [name]: files ? files[0] : value,
      ...(name === 'paymentMethod' && { subMethod: '' }), // reset 2nd select
    }))
  }

  const handleSubMethodChange = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    console.log(file)
    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'invoice_slip') // staging group/tag
    setUploading(true)
    try {
      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const uploaded = res?.data?.media?.[0]
      if (!uploaded?.media_url) throw new Error('Upload failed or no media returned.')
      setPaymentForm((prev) => ({ ...prev, file: uploaded.media_url }))
    } catch (e) {
      console.log(e)
    } finally {
      setUploading(false)
    }
  }

  const handlePrint = async () => {
    if (printLoading) return
    setPrintLoading(true)
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/quotation/print-catelog`,
        { id: invoiceNumber },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      if (response.status === 200) {
        printcatelog(response.data.details)
      }
    } catch (error) {
      setLoading(false)
      Swal.fire({
        title: 'Error',
        text: error.response.data.message,
        icon: 'error',
        confirmButtonText: 'OK',
      })
    } finally {
      setPrintLoading(false)
    }
  }

  const stripHtml = (html) => {
    if (!html) return ''
    const temp = document.createElement('div')
    temp.innerHTML = html
    return temp.innerText || temp.textContent || ''
  }

  const printcatelog = (dataArray) => {
    const printWindow = window.open('', '_blank')  

    const productsHTML = dataArray
      .map((item) => {
        // Sanitize description and handle potential nulls
        const descriptionText = typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize(item.description || '') : item.description || ''

        return `
      <div class="product-block">
        <div class="product-title">
          ${item.title || 'N/A'} <span class="product-id">(ID: ${item.product_id || '-'})</span>
        </div>

        <div class="content">
          <div class="description">
            ${descriptionText ? descriptionText : '<span class="no-data">No description available</span>'}
          </div>

          <div class="image">
            ${item.main_img ? `<img src="${item.main_img}" alt="Product Image" />` : ''}
          </div>
        </div>
      </div>
    `
      })
      .join('')

    const htmlContent = `
  <!DOCTYPE html>
  <html>
    <head>
      <title>Catalog Print</title>
      <style>
        @page {
          size: A4;
          margin: 15mm;
        }

        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 2.5rem;
          color: #333;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 2px solid #000;
          padding-bottom: 10px;
          margin-bottom: 20px;
          /* Prevents the header from being lonely on a page */
          page-break-after: avoid;
        }

        .logo img {
          max-width: 150px;
          max-height: 60px;
          object-fit: contain;
        }

        .company {
          text-align: right;
          font-size: 13px;
        }

        .product-block {
          margin-bottom: 30px;
          padding-bottom: 20px;
          border-bottom: 1px solid #eee;
          /* Key fix: prevents a product from being split across two pages */
          page-break-inside: avoid;
          break-inside: avoid;
        }

        .product-title {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 12px;
          color: #000;
        }

        .product-id {
          font-weight: normal;
          font-size: 14px;
          color: #666;
        }

        .content {
          display: flex;
          gap: 25px;
          align-items: flex-start;
        }

        .description {
          flex: 2;
          font-size: 14px;
          line-height: 1.5;
          /* Preserves line breaks from your text editor */
          white-space: pre-line;
        }

        .image {
          flex: 1;
          text-align: right;
        }

        .image img {
          max-width: 100%;
          max-height: 180px; /* Increased for better visibility */
          object-fit: contain;
          border: 1px solid #f0f0f0;
          border-radius: 4px;
        }

        .no-image {
          border: 1px dashed #ccc;
          padding: 20px;
          font-size: 12px;
          color: #999;
          text-align: center;
        }

        .no-data {
          color: #999;
          font-style: italic;
        }

        /* Hide the print button if it existed, though not used in this script */
        @media print {
          button { display: none; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="logo">
          ${brandingSetting?.logo_url_white ? `<img src="${brandingSetting.logo_url_white}" />` : '<div></div>'}
        </div>
        <div class="company">
          <div><strong>${brandingSetting?.company_name || 'Company Name'}</strong></div>
          <div>Product Catalog</div>
        </div>
      </div>

      <div class="catalog-container">
        ${productsHTML}
      </div>

      <script>
        // Wait for all images to load before opening the print dialog
        window.onload = () => {
          setTimeout(() => {
            window.print();
            // Optional: window.close(); 
            // Note: window.close() might trigger before printing finishes in some browsers.
          }, 500);
        };
      </script>
    </body>
  </html>
  `

    printWindow.document.write(htmlContent)
    printWindow.document.close()
  }

  return (
    <Modal show={show} onHide={onClose} size="lg" dialogClassName="modal-90w" centered>
      <Modal.Header closeButton>
        <Modal.Title>Quotation # {invoiceNumber}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="print-area">
          <Row>
            <Col xs={12}>
              {isLoading ? (
                <div className="d-flex justify-content-center mt-2">
                  <div class="spinner-border" role="status">
                    <span class="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <Card>
                  <CardBody className="border-bottom py-1 mb-1">
                    <Row className="align-items-start">
                      {/* Company Info */}
                      <Col className="d-flex flex-column px-0">
                        <Image
                          src={brandingSetting?.logo_url_white || ''}
                          alt="logo-small"
                          className="me-2"
                          height={300}
                          width={600}
                          style={{ width: '150px', height: 'auto' }}
                        />
                      </Col>

                      {/* Right Corner Info (Aligned to Table End) */}
                      <Col className="ms-auto text-end px-0">
                        {/* <div className="fs-13 fw-semibold">
                          <span className="text-muted">Quotation Number: </span> #{invoiceNumber}
                        </div> */}
                        {/* <div className="fs-13 fw-semibold">
                          {issueDate}
                        </div> */}
                        <div className="mb-1 d-flex justify-content-end">
                          <div
                            style={{
                              background: 'linear-gradient(315deg, #000000 0%, var(--bs-primary) 50%, var(--bs-primary) 80%, white 100%)',
                              color: '#fff',
                              padding: '8px 40px 8px 70px',
                              fontWeight: 'bold',
                              fontSize: '1.2rem',
                              letterSpacing: '2px',
                              textTransform: 'uppercase',
                              // This creates the slanted edge on the left
                              clipPath: 'polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%)',
                              boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
                            }}>
                            Quotation
                          </div>
                        </div>
                        {/* <div className="fs-13 fw-semibold">{brandingSetting?.company_name || ''}</div>
                        <div className="fs-13 fw-semibold">{brandingSetting?.address_1 || ''}</div> */}
                      </Col>
                    </Row>
                    <Row className='mb-3 pb-2 border-bottom'>
                      <Col className="d-flex flex-column px-0">
                        <div className="fs-13 fw-semibold">{brandingSetting?.address_1 || ''}</div>
                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Tel: </span> {brandingSetting?.customer_support_phone || ''}
                        </div>
                        <div className="fs-13 fw-semibold">
                          <span className="text-muted">Email: </span> {brandingSetting?.support_email || ''}
                        </div>
                      </Col>
                      <Col className="d-flex flex-column px-0">
                        <div className="fs-13 fw-semibold text-end">{order?.sender_name}</div>
                        <div className="fs-13 fw-semibold text-end">
                          <span className="text-muted">Tel: </span> {order?.sender_phone}
                        </div>
                        <div className="fs-13 fw-semibold text-end">
                          <span className="text-muted">Email: </span> {order?.sender_email || ''}
                        </div>
                      </Col>
                    </Row>
                    {/* <Row className="mt-1 d-flex align-items-center">
                      <Col>
                        <div className=" fw-semibold d-flex flex-column">
                          <span className="fs-12 text-muted">Quotation No: </span>
                          <span className='fs-14'>#{invoiceNumber}</span> 
                        </div>
                      </Col>
                      <Col>
                        <div className="fs-13 fw-semibold d-flex flex-column">
                          <span className="fs-12 text-muted">Quotation Date: </span>
                          <span className='fs-14'> {issueDate}</span> 
                        </div>
                      </Col>
                      <Col>
                        <div className="fs-13 fw-semibold d-flex flex-column">
                          <span className="fs-12 text-muted">Expire Date: </span>
                          <span className='fs-14'> {issueDate}</span> 
                        </div>
                      </Col>
                      <Col>
                        <div className="mt-1 d-inline-block">
                          <span
                            className="rounded text-uppercase"
                            style={{
                              fontSize: '0.8rem',
                              fontWeight: 600,
                              lineHeight: '1rem',
                              padding: '2px 12px',
                              backgroundColor: (() => {
                                switch (payment_status) {
                                  case 'pending':
                                    return '#ffc107' // yellow
                                  case 'approved':
                                    return '#198754' // green
                                  case 'sent':
                                    return '#0d6efd' // blue
                                  case 'expired':
                                    return '#6c757d' // gray
                                  case 'rejected':
                                    return '#dc3545' // red
                                  default:
                                    return '#adb5bd' // fallback
                                }
                              })(),
                              color: payment_status === 'pending' ? '#000' : '#fff',
                            }}>
                            {payment_status}
                          </span>
                        </div>
                      </Col>
                    </Row> */}

                    <Table className="py-2 my-2"
                      bordered
                      style={{
                        marginBottom: '8px',
                        borderRadius:'5px',
                        overflow: 'hidden',
                      }}>
                      <thead >
                        <tr >
                          <th  className="fs-12 text-muted"
                            style={{
                              border: '2px solid #5b5b5b29',
                              padding: '5px 10px',
                              textAlign: 'left',
                            }}>
                            Quotation No:
                            <div className='fs-14 fw-semibold text-dark' >#{invoiceNumber}</div>
                          </th>

                          <th className="fs-12 text-muted"
                            style={{
                              border: '2px solid #5b5b5b29',
                              padding: '5px 10px',
                              textAlign: 'left',
                            }}>
                            Quotation Date:
                            <div className='fs-14 fw-semibold text-dark' >{issueDate}</div>
                          </th>

                          <th className="fs-12 text-muted"
                            style={{
                              border: '2px solid #5b5b5b29',
                              padding: '5px 10px',
                              textAlign: 'left',
                            }}>
                            Expire Date:
                            <div className='fs-14 fw-semibold text-dark' >{expiryDateFormatted}</div>
                          </th>
                          <th className="fs-12 text-muted"
                            style={{
                              border: '2px solid #5b5b5b29',
                              padding: '5px 10px',
                              textAlign: 'left',
                            }}>
                            <div className="d-flex align-items-center justify-content-center">
                          <span
                            className="rounded text-uppercase"
                            style={{
                              fontSize: '0.8rem',
                              fontWeight: 600,
                              lineHeight: '1rem',
                              padding: '2px 12px',
                              backgroundColor: (() => {
                                switch (payment_status) {
                                  case 'pending':
                                    return '#ffc107' // yellow
                                  case 'approved':
                                    return '#198754' // green
                                  case 'sent':
                                    return '#0d6efd' // blue
                                  case 'expired':
                                    return '#6c757d' // gray
                                  case 'rejected':
                                    return '#dc3545' // red
                                  default:
                                    return '#adb5bd' // fallback
                                }
                              })(),
                              color: payment_status === 'pending' ? '#000' : '#fff',
                            }}>
                            {payment_status}
                          </span>
                        </div>
                          </th>
                        </tr>
                      </thead>
                      {/* <tbody>
                        <tr>
                          <td
                            colSpan={3} // This will stretch across all 3 columns
                            style={{
                              border: '2px solid #0d6efd',
                              textAlign: 'left', // horizontal align
                              verticalAlign: 'top',
                              padding: '10px',
                            }}>
                            <address className="fs-13 mb-0">
                              <strong className="fs-14">Invoice to:</strong>
                              <br />
                              <div className="fw-bold">{order?.sender_name}</div>
                              <div>{order?.sender_email}</div>
                              <div>Hotline: {order?.sender_phone}</div>
                            </address>
                          </td>
                        </tr>
                      </tbody> */}
                    </Table>

                    {/* <CardBody style={{ paddingTop: '6px', paddingBottom: '6px' }}> */}
                    <Row>
                      <Col lg={12}>
                        <div className="table-responsive project-invoice">
                          <table className="table table-bordered mb-0">
                            <thead className="table-light">
                              <tr>
                                <th>Order Details</th>
                                <th>Quantity</th>
                                <th className="text-end">Unit Price ({currency})</th>

                                {hasItemDiscount && <th className="text-end">Discount</th>}

                                <th className="text-end">Amount ({currency})</th>
                              </tr>
                            </thead>

                            <tbody>
                              {invoiceDetails.map((it, idx) => {
                                const hasDiscount = Number(it.discount) > 0

                                const displayQty = it.unit_type == 1 ? it.quantity : it.quantity * Number(it.amount_per_unit || 1)

                                const freeQty = it.unit_type == 1 ? it.free_quantity : it.free_quantity * Number(it.amount_per_unit || 1)

                                const lineTotal = Number(it.total_price)
                                const finalAmount = hasDiscount ? lineTotal - Number(it.discount) : lineTotal

                                return (
                                  <tr key={idx}>
                                    {/* PRODUCT DETAILS */}
                                    <td>
                                      <h5 className="mb-1 fs-12">{it.product_id ? `#${it.product_id} - ${it.name}` : it.name}</h5>

                                      {it.variant_value && it.variant_value !== 'Default' && (
                                        <div className="text-muted fs-10">{it.variant_value}</div>
                                      )}
                                    </td>

                                    {/* QUANTITY */}
                                    <td>
                                      {displayQty}
                                      {it.unit_type != 1 && it.measurement_value}

                                      {it.free_quantity >= 1 && (
                                        <span style={{ color: 'green', fontWeight: 'bold' }}>
                                          {' + '}
                                          {freeQty}
                                          {it.unit_type != 1 && it.measurement_value} FREE
                                        </span>
                                      )}
                                    </td>

                                    {/* UNIT PRICE */}
                                    <td className="text-end">{Number(it.unit_price).toFixed(2)}</td>

                                    {/* DISCOUNT COLUMN (ALWAYS RENDERED IF HEADER EXISTS) */}
                                    {hasItemDiscount && <td className="text-end">{hasDiscount ? Number(it.discount).toFixed(2) : '-'}</td>}

                                    {/* AMOUNT */}
                                    <td className="text-end">{finalAmount.toFixed(2)}</td>
                                  </tr>
                                )
                              })}

                              {/* SUBTOTAL */}
                              <tr>
                                <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                  <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>Subtotal</b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end p-1">
                                  <b>{Number(subTotal).toFixed(2)}</b>
                                </td>
                              </tr>

                              {/* ORDER DISCOUNT */}
                              {Number(orderDiscount) > 0 &&
                                discountType !== 'product' &&
                                discountType !== 'buyx' &&
                                discountType !== 'manual_product' && (
                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                      <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>Discount</b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end p-1">
                                      <b>{Number(orderDiscount).toFixed(2)}</b>
                                    </td>
                                  </tr>
                                )}

                              {/* TAX */}
                              {taxAmount > 0 && (
                                <tr>
                                  <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                    <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>
                                      {taxName} ({tax_percentage}%)
                                    </b>
                                  </td>
                                  <td className="border-0 fs-12 text-dark text-end p-1">
                                    <b>{taxAmount.toFixed(2)}</b>
                                  </td>
                                </tr>
                              )}

                              {/* TOTAL */}
                              <tr>
                                <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                  <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>Total</b>
                                </td>
                                <td className="border-0 fs-12 text-dark text-end p-1">
                                  <b>{Number(order?.full_amount).toFixed(2)}</b>
                                </td>
                              </tr>

                              {/* PARTIAL PAYMENT */}
                              {payment_status === 'partially paid' && (
                                <>
                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                      <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>Total Paid</b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end p-1">
                                      <b>{Number(order?.amount_paid || 0).toFixed(2)}</b>
                                    </td>
                                  </tr>

                                  <tr>
                                    <td colSpan={hasItemDiscount ? 4 : 3} className="border-0 fs-12 text-dark text-end p-1">
                                      <b style={{ display: 'inline-block', width: '65px', textAlign: 'left' }}>Total Due</b>
                                    </td>
                                    <td className="border-0 fs-12 text-dark text-end p-1">
                                      <b>{(Number(order?.full_amount || 0) - Number(order?.amount_paid || 0)).toFixed(2)}</b>
                                    </td>
                                  </tr>
                                </>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </Row>

                    <div className="w-full mt-4">
                      <h6 className="mb-2 text-sm font-semibold">Terms And Conditions :</h6>

                      {termsConditions.length > 0 ? (
                        <ul className="pl-4 text-xs space-y-1 list-disc">
                          {termsConditions.map((term, index) => (
                            <li key={index}>{term}</li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-xs text-muted">No terms and conditions available.</p>
                      )}
                    </div>

                    {/* Admin Note – VIEW ONLY */}
                    {adminNote && (
                      <div className="mt-3 no-print pdf-hide">
                        <h6 className="mb-2 text-sm font-semibold">Admin Note :</h6>
                        <div
                          style={{
                            border: '1px solid #ebe7db',
                            borderRadius: '6px',
                            backgroundColor: '#fffbe6',
                            padding: '10px 12px',
                          }}>
                          <p className="text-xs mb-0" style={{ whiteSpace: 'pre-wrap' }}>
                            {adminNote.charAt(0).toUpperCase() + adminNote.slice(1)}
                          </p>
                        </div>
                      </div>
                    )}

                    <hr />
                    <Row className="d-flex justify-content-center">
                      <Col className="d-flex justify-content-center">
                        <div className="text-center white-space-nowrap">
                          <small className="fs-12">Thank you very much for doing business with us.</small>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                  <style jsx global>{`
                    /* =========================
   SCREEN ONLY
========================= */
                    .modal-footer {
                      display: flex;
                      justify-content: flex-end;
                      gap: 8px;
                    }

                    /* =========================
   PRINT SETUP
========================= */
                    @media print {
                      @page {
                        size: A4;
                        margin: 0;
                      }

                      html,
                      body {
                        width: 210mm;
                        height: 297mm;
                        margin: 0 !important;
                        padding: 0 !important;
                        background: #fff !important;
                        overflow: hidden !important;
                      }

                      /* Hide everything except modal */
                      body > *:not(.modal) {
                        display: none !important;
                      }

                      /* Modal becomes document */
                      .modal {
                        position: fixed !important;
                        inset: 0 !important;
                        display: block !important;
                        background: #fff !important;
                        margin: 0 !important;
                        padding: 0 !important;
                      }

                      .modal-dialog,
                      .modal-content {
                        width: 100% !important;
                        height: 100% !important;
                        max-width: 100% !important;
                        margin: 0 !important;
                        padding: 0 !important;
                        border: none !important;
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      /* Remove modal chrome */
                      .modal-header,
                      .modal-footer {
                        display: none !important;
                      }

                      /* Printable area */
                      .print-area {
                        width: 100% !important;
                        height: 100% !important;
                        margin: 0 !important;
                        padding: 16px !important;
                        background: #fff !important;
                      }

                      /* Remove UI effects */
                      .card,
                      .shadow,
                      .shadow-sm,
                      .rounded,
                      .border {
                        border-radius: 0 !important;
                        box-shadow: none !important;
                      }

                      .card {
                        border: none !important;
                      }

                      .card-body {
                        padding: 10px !important;
                      }

                      .row {
                        margin: 0 !important;
                      }

                      [class*='col-'] {
                        padding: 0 !important;
                      }

                      /* =========================
     TOTALS – LABELS CLOSER
  ========================= */
                      .project-invoice tbody tr td {
                        padding-top: 4px !important;
                        padding-bottom: 4px !important;
                      }

                      .project-invoice tbody tr td:nth-child(3) {
                        padding-right: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      .project-invoice tbody tr td:nth-child(4) {
                        padding-left: 6px !important;
                        text-align: right !important;
                        white-space: nowrap;
                      }

                      /* =========================
     TABLE SAFETY
  ========================= */
                      table {
                        width: 100% !important;
                        page-break-inside: auto;
                      }

                      tr {
                        page-break-inside: avoid;
                      }

                      thead {
                        display: table-header-group;
                      }

                      /* =========================
     HIDE ADD PAYMENT (PRINT)
  ========================= */
                      .print-area .fs-14.fw-bold.mb-1,
                      .print-area .fs-14.fw-bold.mb-1 + .row {
                        display: none !important;
                      }

                      /* =========================
     NO-PRINT UTILITY
  ========================= */
                      .no-print {
                        display: none !important;
                      }

                      /* Hide form controls */
                      button,
                      input,
                      select {
                        display: none !important;
                      }

                      .modal-backdrop {
                        display: none !important;
                      }
                    }
                    /* =========================
   ACTION BADGES
========================= */
                    .action-badge {
                      font-size: 0.7rem;
                      padding: 4px 8px;
                      font-weight: 600;
                      border-radius: 4px;
                      transition: all 0.2s ease;
                      user-select: none;
                    }

                    /* View */
                    .view-badge {
                      background-color: rgba(13, 110, 253, 0.1);
                      color: #0d6efd;
                      text-decoration: none;
                    }

                    .view-badge:hover {
                      background-color: #0d6efd;
                      color: #fff;
                    }

                    /* Revoke */
                    .revoke-badge {
                      background-color: rgba(220, 53, 69, 0.1);
                      color: #dc3545;
                    }

                    .revoke-badge:hover {
                      background-color: #dc3545;
                      color: #fff;
                    }

                    /* Disabled */
                    .disabled-badge {
                      background-color: rgba(108, 117, 125, 0.15);
                      color: #6c757d;
                      opacity: 0.6;
                      cursor: not-allowed;
                    }
                    /* =========================
   COMPACT ACTION BUTTONS
========================= */
                    .action-inline {
                      display: inline-flex;
                      gap: 3px;
                      max-width: 100%;
                      white-space: nowrap;
                    }

                    /* =========================
   ACTION BADGES – DARK BLUE / BLACK
========================= */

                    /* Base – KEEP sizing unchanged */
                    .action-badge {
                      display: inline-flex;
                      align-items: center;
                      justify-content: center;

                      font-size: 0.7rem;
                      padding: 4px 8px;
                      min-width: 50px;
                      height: 22px;
                      line-height: 1;

                      font-weight: 600;
                      border-radius: 5px;
                      user-select: none;
                      transition:
                        background-color 0.2s ease,
                        box-shadow 0.2s ease;
                    }

                    /* VIEW – Dark Blue */
                    .view-badge {
                      background-color: #134c92ff; /* deep navy blue */
                      color: #ffffff;
                    }

                    .view-badge:hover {
                      background-color: #082e5c;
                    }

                    /* REVOKE – Soft Black */
                    .revoke-badge {
                      background-color: #6d1818ff; /* charcoal black */
                      color: #ffffff;
                    }

                    .revoke-badge:hover {
                      background-color: #111827;
                    }

                    /* DISABLED */
                    .disabled-badge {
                      background-color: #6b7280; /* muted gray */
                      color: #ffffff;
                      opacity: 0.6;
                      cursor: not-allowed;
                    }

                    /* Subtle premium depth */
                    .view-badge,
                    .revoke-badge {
                      box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
                    }
                  `}</style>
                </Card>
              )}
            </Col>
          </Row>
        </div>
      </Modal.Body>
      <Modal.Footer className="no-print d-flex justify-content-between">
        {/* Left side buttons */}
        <div className="d-flex gap-1">
          <Button
            variant="danger"
            onClick={() => handleCancel(order.id)}>
            <Icon icon="mdi:close" width={16} className="me-1" />
            Cancel Quotation
          </Button>

          <Button
            variant="secondary"
            onClick={onClose}>
            Close
          </Button>

          {payment_status.toLowerCase() === 'approved' && (
            <Button
              className=""
              onClick={() => handleTransfer(invoiceNumber)}>
              <Icon icon="mdi:transfer" width={16} className="me-1" />
              Invoice
            </Button>
          )}
        </div>

        {/* Right side buttons */}
        <div className="d-flex gap-1">
          <Button
            variant="success"
            onClick={handleSendInvoice}
            disabled={sending}
>
            Send
          </Button>

          <Button
            variant="primary"
            disabled={printLoading}
            onClick={handlePrint}
>
            Print catelog
          </Button>
          <Button
            variant="primary"
            onClick={() => window.print()}
>
            Print
          </Button>
        </div>

        {/* 🔹 MODAL OPENS ONLY WHEN NO LINK */}
        {showInvoiceModal && (
          <QuotationModal
            show={showInvoiceModal}
            onClose={() => setShowInvoiceModal(false)}
            order={order}
            fetchLogs={fetchLogs}
            quotationLink={existingQuotationLink}
          />
        )}
      </Modal.Footer>
    </Modal>
  )
}
