'use client'

import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Modal, Button } from 'react-bootstrap'
import Swal from 'sweetalert2'
import html2pdf from 'html2pdf.js'

import { useSendQutationMutation } from '@/store/features/apiSlice'

const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL

export default function InvoiceModal({
  show,
  onClose,
  order = {},
  fetchLogs,
  quotationLink,
}) {
  const invoiceNumber = order?.id
  const defaultEmail = order?.sender_email || ''
  const defaultPhone = order?.sender_phone || ''
  const customerName = order?.sender_name || ''

  const [sendInvoice, { isLoading: sending }] = useSendQutationMutation()

  /* ================= STATE ================= */
  const [pdfBlob, setPdfBlob] = useState(null)
  const [pdfFile, setPdfFile] = useState(null)
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState(null)
  const [showPreview, setShowPreview] = useState(false)
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)

  const [sendEmail, setSendEmail] = useState(!!defaultEmail)
  const [sendMobile, setSendMobile] = useState(!!defaultPhone)
  const [email, setEmail] = useState(defaultEmail)
  const [phone, setPhone] = useState(defaultPhone)

  /* ================= AUTO PDF GENERATION ================= */
  useEffect(() => {
    if (!show || !invoiceNumber) return

    // ✅ PDF already exists
    if (quotationLink) {
      setPdfFile({
        name: `Quotation_${invoiceNumber}.pdf`,
        size: 'Already generated',
      })
      setPdfPreviewUrl(quotationLink)
      return
    }

    const run = async () => {
      try {
        setIsGeneratingPdf(true)

        // hide unwanted elements
        const hiddenEls = document.querySelectorAll('.pdf-hide')
        hiddenEls.forEach(el => {
          el.dataset.prevDisplay = el.style.display
          el.style.display = 'none'
        })

        const element = document.querySelector('.print-area')
        if (!element) throw new Error('print-area not found')

        // 🔥 force PDF styles
        element.classList.add('pdf-mode')

        const blob = await html2pdf()
          .from(element)
          .set({
            margin: 5,
            filename: `Quotation_${invoiceNumber}.pdf`,
            html2canvas: {
              scale: 2,
              useCORS: true,
              backgroundColor: '#ffffff',
            },
            jsPDF: { unit: 'mm', format: 'a4' },
          })
          .outputPdf('blob')

        element.classList.remove('pdf-mode')

        const url = URL.createObjectURL(blob)

        setPdfBlob(blob)
        setPdfFile({
          name: `Quotation_${invoiceNumber}.pdf`,
          size: `${(blob.size / 1024).toFixed(1)} KB`,
        })
        setPdfPreviewUrl(url)

        // restore hidden elements
        hiddenEls.forEach(el => {
          el.style.display = el.dataset.prevDisplay || ''
          delete el.dataset.prevDisplay
        })
      } catch (err) {
        console.error('PDF generation failed:', err)
        Swal.fire('Error', 'Failed to generate PDF', 'error')
      } finally {
        setIsGeneratingPdf(false)
      }
    }

    const timer = setTimeout(run, 300)
    return () => clearTimeout(timer)
  }, [show, invoiceNumber, quotationLink])

  /* ================= PDF UPLOAD ================= */
  const uploadPdfToServer = async (blob) => {
    try {
      const file = new File([blob], `Quotation_${invoiceNumber}.pdf`, {
        type: 'application/pdf',
      })

      const formData = new FormData()
      formData.append('files', file)
      formData.append('product_id', 'quotation-pdf')

      const res = await axios.post(
        `${API_BASE_URL}/product-media/upload-stagingQU`,
        formData,
        { headers: { 'Content-Type': 'multipart/form-data' } }
      )

      return res?.data?.media?.[0]?.media_url || null
    } catch (err) {
      console.error('PDF upload failed:', err)
      return null
    }
  }

  /* ================= SEND ================= */
  // const handleSendInvoice = async () => {
  //   if (!sendEmail && !sendMobile) {
  //     Swal.fire('Select Email or Mobile', '', 'warning')
  //     return
  //   }

  //   try {
  //     let pdfUrl = quotationLink

  //     if (!quotationLink && pdfBlob) {
  //       pdfUrl = await uploadPdfToServer(pdfBlob)
  //       if (!pdfUrl) throw new Error('Upload failed')
  //     }

  //     await sendInvoice({
  //       quotation_id: invoiceNumber,
  //       send_email: sendEmail,
  //       send_mobile: sendMobile,
  //       email: sendEmail ? email : null,
  //       phone: sendMobile ? phone : null,
  //       quotation_link: pdfUrl,
  //       customer_name: customerName,
  //     }).unwrap()

  //     fetchLogs?.(1)
  //     onClose()
  //   } catch (err) {
  //     Swal.fire('Failed', err?.data?.message || 'Error', 'error')
  //   }
  // }

  const handleSendInvoice = async () => {
  if (!sendEmail && !sendMobile) {
    Swal.fire('Select Email or Mobile', '', 'warning')
    return
  }

  try {
    let pdfUrl = quotationLink

    // Upload PDF only if not already uploaded
    if (!quotationLink && pdfBlob) {
      pdfUrl = await uploadPdfToServer(pdfBlob)
      if (!pdfUrl) {
        Swal.fire('Error', 'PDF upload failed', 'error')
        return
      }
    }

    // 🔥 API CALL
    const response = await sendInvoice({
      quotation_id: invoiceNumber,
      send_email: sendEmail,
      send_mobile: sendMobile,
      email: sendEmail ? email : null,
      phone: sendMobile ? phone : null,
      quotation_link: pdfUrl,
      customer_name: customerName,
    }).unwrap()

    // ✅ SUCCESS HANDLING
    if (response?.success === true) {
      Swal.fire(
        'Success',
        response?.message || 'Quotation sent successfully!',
        'success'
      )

      fetchLogs?.(1)
      onClose()
    } else {
      Swal.fire('Error', 'Failed to send quotation', 'error')
    }
  } catch (err) {
    Swal.fire(
      'Failed',
      err?.data?.message || 'Something went wrong',
      'error'
    )
  }
}


  /* ================= RENDER ================= */
  return (
    <>
      <Modal show={show} onHide={onClose} centered backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>Quotation #{invoiceNumber}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {/* ===== SEND TO ===== */}
          <div className="border rounded p-3 mb-3">
            <h6 className="fw-semibold mb-2">Send To</h6>

            <div className="mb-2">
              <input
                type="checkbox"
                checked={sendEmail}
                onChange={e => setSendEmail(e.target.checked)}
                className="me-2"
              />
              Email
              <input
                className="form-control form-control-sm mt-1"
                value={email}
                disabled={!sendEmail}
                onChange={e => setEmail(e.target.value)}
              />
            </div>

            <div>
              <input
                type="checkbox"
                checked={sendMobile}
                onChange={e => setSendMobile(e.target.checked)}
                className="me-2"
              />
              Mobile
              <input
                className="form-control form-control-sm mt-1"
                value={phone}
                disabled={!sendMobile}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
          </div>

          {/* ===== PDF STATUS ===== */}
          {isGeneratingPdf && (
            <div className="border rounded p-3 text-center">
              <div className="spinner-border text-primary mb-2" />
              <div className="fw-semibold">Generating PDF…</div>
              <small className="text-muted">Please wait</small>
            </div>
          )}

          {!isGeneratingPdf && pdfFile && (
            <div className="border rounded p-2 d-flex justify-content-between align-items-center">
              <div>
                📄 {pdfFile.name}
                <div className="text-muted fs-11">{pdfFile.size}</div>
              </div>
              <Button size="sm" onClick={() => setShowPreview(true)}>
                View
              </Button>
            </div>
          )}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          <Button
            variant="success"
            onClick={handleSendInvoice}
            disabled={sending || isGeneratingPdf}
          >
            {sending ? 'Sending…' : 'Send'}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* ===== PDF PREVIEW ===== */}
      <Modal show={showPreview} onHide={() => setShowPreview(false)} size="xl">
        <Modal.Header closeButton>
          <Modal.Title>PDF Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ height: '80vh', padding: 0 }}>
          <iframe
            src={pdfPreviewUrl}
            style={{ width: '100%', height: '100%', border: 'none' }}
          />
        </Modal.Body>
      </Modal>
    </>
  )
}
