
import React from 'react';
import AddInvoice from './AddInvoice';

const AddInvoicePage = () => {
  return (
    <div>
      <AddInvoice />
    </div>
  );
};

export default AddInvoicePage;
