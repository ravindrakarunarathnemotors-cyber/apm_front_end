import dynamic from 'next/dynamic'
import DeletedInvoices from '@/components/Invoices/DeletedInvoices'

export const metadata = {
  title: 'Deleted Invoices',
}

export default function DeletedInvoicesPage() {
  return <DeletedInvoices />
}