
import React from 'react';
import dynamic from 'next/dynamic';

export const metadata = {
  title: 'Rejected Quatations',
}

const RejectedQuotations = dynamic(() => import('./RejectedQuotations'), { ssr: false })

const RejectedQuotationsPage = () => {
  return (
    <div>
      <RejectedQuotations />
    </div>
  );
};

export default RejectedQuotationsPage;
