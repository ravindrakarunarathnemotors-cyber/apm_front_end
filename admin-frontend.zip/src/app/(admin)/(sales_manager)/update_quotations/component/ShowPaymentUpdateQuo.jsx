'use client'

import React, { useEffect, useMemo, useState, useRef } from 'react'
import { Modal, ModalBody, ModalHeader, ModalFooter, Button, FormControl, ProgressBar, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'
import useRefreshToken from '@/hooks/useRefreshToken'
import { useRouter } from 'next/navigation'
import { useGetSubPaymentMethodsQuery } from '@/store/features/sandoSlice'
import axiosInstance from '@/lib/axiosInstance';

const MAX_FILE_MB = 5
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'application/pdf']

const ShowPaymentUpdate = ({
    open,
    setOpen,
    allPaymentMethod,
    selectedPaymentMethod,
    setSelectedPaymentMethod,
    fullAmount,
    addedproducts,
    selectClient,
    clientDetails,
    taxManualEnable,
    billingaddress,
    deliveryFee,
    discount,
    taxValue,
    totalTax,
    discountType,
    selected,
    taxname,
    currency,
    totalAmount,
    setPaymentMethodDiscount,
    getDiscountDetails,
    orderId,
    note,
    recipient_note,
    orderDetails,
    lastSubTotal
}) => {
    const [refference, setRefference] = useState('')
    const [loading, setLoading] = useState(false)
    const [loading1, setLoading1] = useState(false)
    const [paymentMethodLoading, setPaymentMethodLoading] = useState(false)
    const [loyaltiPoints, setLoyaltiPoints] = useState('')
    const [selectAccount, setSelectAccount] = useState('')
    const [amount, setAmount] = useState('')

    //bank slip
    const [bankSlipFile, setBankSlipFile] = useState(null)
    const [bankSlipPreview, setBankSlipPreview] = useState(null)
    const [bankSlipError, setBankSlipError] = useState('')
    const [bankSlipUrl, setBankSlipUrl] = useState('')
    const [uploading, setUploading] = useState(false)
    const [uploadProgress, setUploadProgress] = useState(0)
    const fileInputRef = useRef(null)

    console.log("note", note)
    console.log("recipient_note", recipient_note)
    console.log("orderId", orderId)


    const {
        data: subPaymentData,
        isLoading: loadingSubPayment,
        error: subPaymentError,
    } = useGetSubPaymentMethodsQuery(selectedPaymentMethod?.value, {
        skip: !selectedPaymentMethod?.value,
    });

    // console.log("discount", orderDetails?.payment_status)
    console.log("selectedPaymentMethod", selectedPaymentMethod)

    const [refreshtoken] = useRefreshTokenMutation()
    const { Logout } = useLogout()
    const { refresh } = useRefreshToken()

    const router = useRouter()

    useEffect(() => {
        if (!orderDetails) return
        const usedLoaylity = selectClient.value == orderDetails.customer_id ? (Number(orderDetails.loyalty_points_spent) || 0) : 0
        setLoyaltiPoints(usedLoaylity)
        autoPaymentMethodDiscount(orderDetails.payment_method_id)
        const method = allPaymentMethod.find(pm => pm.value == orderDetails.payment_method_id)
        setSelectedPaymentMethod(method)
        setRefference(orderDetails.payment_reference)
        setBankSlipUrl(orderDetails.bank_slip ? orderDetails.bank_slip : '')
    }, [orderDetails])

    const hanldeClose = () => {
        setOpen(false)
        setPaymentMethodDiscount(null)
        setSelectedPaymentMethod(null)
    }

    const fastAmount = useMemo(() => {
        const fullDiscount = parseFloat(fullAmount) || 0
        const points = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

        return fullDiscount - points
    }, [fullAmount, loyaltiPoints])

    const handleSubmit = async () => {
        // check if all the required fields are filled
        const discountDetails = getDiscountDetails()
        console.log(discountDetails)

        const fullTax = {
            name: taxname,
            value: totalTax
        }

        const order = {
            products: addedproducts,
            client: selectClient,
            clientDetails: clientDetails,
            taxManualEnable: taxManualEnable,
            selectedPaymentMethod: selectedPaymentMethod,
            refference: refference,
            deliveryFee: 0,
            discountvalue: discount,
            taxValue: taxValue,
            totalTax: fullTax,
            discountType: discountType,
            selected: selected,
            discountDetails: discountDetails,
            loyaltiPoints: loyaltiPoints,
            bankSlipUrl: bankSlipUrl,
            selectAccount: selectAccount,
            amount: amount,
            lastSubTotal: lastSubTotal,
            fastAmount: fastAmount,
            recipient_note: recipient_note,
            note: note,
        }
        setLoading(true)
        try {
            const response = await axiosInstance.put(`/order/updateQuotation/${orderId}`, order)

            if (response.status === 200) {
                Swal.fire({ title: 'Success', text: 'Order updated successfully', icon: 'success' })
                router.push('/all_quotations')
            }
        } catch (error) {
            setLoading(false)
            Swal.fire({
                title: 'Error',
                text: error?.response?.data?.message,
                icon: 'error',
                confirmButtonText: 'OK',
            })
        }

        hanldeClose()
    }

    const autoPaymentMethodDiscount = async (id) => {
        try {

            setPaymentMethodLoading(true)
            const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/invoice-discount/autodpmethoddiscount`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: 'include',
                body: JSON.stringify({
                    cart_products: addedproducts,
                    id: id,
                    user_id: selectClient.value,
                }),
            });

            if (response.status === 401 || response.status === 403) {
                try {
                    await refresh()
                    return autoPaymentMethodDiscount(id)
                } catch (refreshError) {
                    console.error('Error refreshing token:', refreshError)
                    Logout()
                }
            }

            const data = await response.json();

            if (response.status === 200) {
                setPaymentMethodDiscount(data.data ? data.data : null)
                setPaymentMethodLoading(false)
            }

        } catch (error) {
            console.log(error)
            setPaymentMethodLoading(false)
        }

    }

    const handleChange = (e) => {
        let value = e.target.value;
        const max = selectClient.value == orderDetails.customer_id ? (parseFloat(selectClient?.loyalty_point) || 0) + Number(orderDetails.loyalty_points_spent || 0) - Number(orderDetails.loyalty_points_earned || 0) : (parseFloat(selectClient?.loyalty_point) || 0)

        console.log(max)

        // Allow empty value
        if (value === "") {
            setLoyaltiPoints("");
            return;
        }

        // Allow only: digits + optional single decimal point
        if (!/^\d*\.?\d*$/.test(value)) {
            return;
        }

        // If value is only "." → treat as "0."
        if (value === ".") {
            setLoyaltiPoints("0.");
            return;
        }

        // Convert to number for comparison
        const numericValue = Number(value);

        // If exceeds max → block update
        if (numericValue > max) {
            return;
        }

        setLoyaltiPoints(value);
    };



    const uploadBankSlip = async (file) => {
        const err = validateFile(file)

        if (err) {
            setBankSlipError(err)
            resetBankSlip()
            return
        }

        setBankSlipError('')
        setBankSlipFile(file)

        if (file.type.startsWith('image/')) {
            const url = URL.createObjectURL(file)
            setBankSlipPreview(url)
        } else {
            setBankSlipPreview(null)
        }

        const formData = new FormData()
        formData.append('files', file)
        formData.append('product_id', 'order-bank-slip') // staging group/tag

        try {
            setUploading(true)
            setUploadProgress(0)

            const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
                onUploadProgress: (evt) => {
                    const percent = Math.round((evt.loaded * 100) / (evt.total || 1))
                    setUploadProgress(percent)
                },
            })

            const uploaded = res?.data?.media?.[0]
            if (!uploaded?.media_url) throw new Error('Upload failed or no media returned.')

            setBankSlipUrl(uploaded.media_url)
        } catch (e) {
            setBankSlipError(e?.response?.data?.error || e.message || 'Upload failed')
            resetBankSlip()
        } finally {
            setUploading(false)
            setUploadProgress(0)
        }
    }

    const onDrop = (e) => {
        e.preventDefault()
        e.stopPropagation()
        const file = e.dataTransfer.files?.[0]
        if (file) uploadBankSlip(file)
    }

    const onInputChange = (e) => {
        const file = e.target.files?.[0]
        if (file) uploadBankSlip(file)
    }

    const validateFile = (file) => {
        if (!file) return 'No file selected.'
        if (!ACCEPTED_TYPES.includes(file.type)) return 'Invalid file type. Only JPG, PNG, or PDF are allowed.'
        if (file.size > MAX_FILE_MB * 1024 * 1024) return `File is too large. Max ${MAX_FILE_MB} MB.`
        return ''
    }

    const resetBankSlip = () => {
        setBankSlipError('')
        if (bankSlipPreview) URL.revokeObjectURL(bankSlipPreview)
        setBankSlipPreview(null)
        setBankSlipFile(null)
        setBankSlipUrl('')
        setUploading(false)
        setUploadProgress(0)
        if (fileInputRef.current) fileInputRef.current.value = '';
    }

    const handleAmountChange = (e) => {
        let value = e.target.value;

        // Allow empty value
        if (value === "") {
            setAmount("");
            return;
        }

        // Allow only: digits + optional single decimal point
        if (!/^\d*\.?\d*$/.test(value)) {
            return;
        }

        setAmount(value);
    };

    const handlePaymentMethodSelect = (e) => {
        autoPaymentMethodDiscount(e.target.value)
        const method = allPaymentMethod.find(pm => pm.value == e.target.value)
        setSelectedPaymentMethod(method)
    }

    console.log(bankSlipUrl)
    return (
        <Modal show={open} onHide={hanldeClose} centered size="md">
            <ModalHeader closeButton className="bg-light">
                <h6 className="modal-title m-0 text-black">Update Quotation Confirmation {orderDetails?.id}</h6>
            </ModalHeader>
            <ModalBody>
                <div>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                        <div className="fw-semibold">Subtotal</div>
                        <div className="fw-semibold">{currency}{' '}
                            {lastSubTotal.toFixed(2)}
                        </div>
                    </div>
                    {discount > 0 && (discountType != 'product' && discountType != 'buyx') && (
                        <div className="d-flex justify-content-between align-items-center mb-2">
                            <div className="fw-semibold">  {{
                                order: 'Order Discount',
                                product: 'Product Discount',
                                payment_method: 'Payment Method Discount',
                                shipping: 'Delivery Fee Discount',
                                buyxgety: 'BuyXGetY Discount'
                            }[discountType] || 'Discount'}</div>
                            <div className="fw-semibold">{currency} -{discount.toFixed(2)}</div>
                        </div>
                    )}


                    {taxManualEnable && (
                        <div className="d-flex justify-content-between align-items-center mb-2">
                            <div className="fw-semibold">{taxname} ({taxValue}%)</div>
                            <div className="fw-semibold">{currency} {totalTax.toFixed(2)}</div>
                        </div>
                    )}
                    {/* <div className="d-flex justify-content-between align-items-center mb-2">
                        <div className="fw-semibold">Loyalty Points ({(Number(selectClient?.loyalty_point) + Number(orderDetails.loyalty_points_spent)- Number(orderDetails.loyalty_points_earned)).toFixed(2)})</div>
                        <div className="" style={{ maxWidth: '100px' }}>
                            <input
                                type="text"
                                placeholder="Enter number"
                                value={loyaltiPoints}
                                onChange={handleChange}
                                className="form-control-sm text-center"
                                style={{ width: "100%" }}
                                disabled={Number(selectClient?.loyalty_point) === 0}
                            />
                        </div>
                    </div> */}
                    <div className="d-flex justify-content-between align-items-center mb-2">
                        <div className="fw-semibold">Total</div>
                        <div className="fw-semibold">{currency} {fastAmount.toFixed(2)}</div>
                    </div>

                    {/* <Row className="g-1 mb-2">
                        <Col xs={12} md={6}>
                            <select
                                className="form-select"
                                name="paymentMethod"
                                value={selectedPaymentMethod?.value}
                                onChange={handlePaymentMethodSelect}
                            >
                                <option value="">Select Payment Method</option>
                                {allPaymentMethod.map((method) => (
                                    <option key={method.value} value={method.value}>
                                        {method.label}
                                    </option>
                                ))}
                            </select>
                        </Col>

                        {selectedPaymentMethod?.value && (
                            <Col xs={12} md={6}>
                                <select
                                    className="form-select"
                                    name="subMethod"
                                    value={selectAccount}
                                    onChange={(e) => setSelectAccount(e.target.value)}
                                    disabled={loadingSubPayment}
                                >
                                    <option value="">
                                        {loadingSubPayment
                                            ? "Loading..."
                                            : subPaymentError
                                                ? "Failed to load"
                                                : "Select Option"}
                                    </option>

                                    {subPaymentData?.rows?.map((item) => (
                                        <option key={item.value} value={item.value}>
                                            {item.label}
                                        </option>
                                    ))}
                                </select>
                            </Col>
                        )}

                    </Row> */}

                    {/* <Row className="g-1">
                        <Col xs={12} md={6}>
                            <input
                                type="text"
                                className="form-control"
                                value={amount}
                                placeholder="Amount"
                                onChange={handleAmountChange}
                            />
                        </Col>

                        {selectedPaymentMethod?.label != 'COD' && (
                            <Col xs={12} md={6}>
                                <FormControl
                                    type="text"
                                    placeholder="Reference"
                                    onChange={(e) => setRefference(e.target.value)}
                                    style={{ maxWidth: '100%' }}
                                />
                            </Col>
                        )}
                    </Row> */}

                    {/* {selectedPaymentMethod?.value == 4 && (
                        <div className="mt-3">
                            <div className="fw-semibold mb-2">Bank Slip (JPG/PNG/PDF, max {MAX_FILE_MB}MB)</div>

                            <div
                                onDragOver={(e) => {
                                    e.preventDefault()
                                    e.stopPropagation()
                                }}
                                onDrop={onDrop}
                                className="border rounded p-3 text-center"
                                style={{ borderStyle: 'dashed', cursor: 'pointer' }}
                                onClick={() => fileInputRef.current?.click()}
                            >
                                <div className="mb-2">Drag & drop here or click to upload</div>

                                <input
                                    ref={fileInputRef}
                                    type="file"
                                    accept=".png,.jpg,.jpeg,.pdf"
                                    style={{ display: 'none' }}
                                    onChange={onInputChange}
                                />

                                {uploading && (
                                    <div className="mt-2">
                                        <ProgressBar now={uploadProgress} label={`${uploadProgress}%`} />
                                    </div>
                                )}

                                {bankSlipError && <div className="text-danger small mt-2">{bankSlipError}</div>}

                                {(bankSlipFile || bankSlipUrl) && !uploading && (
                                    <div className="mt-2 d-flex align-items-center justify-content-center gap-3">
                                        {bankSlipPreview ? (
                                            <img
                                                src={bankSlipPreview}
                                                alt="Bank slip preview"
                                                style={{ maxWidth: 160, maxHeight: 120, objectFit: 'contain', borderRadius: 6 }}
                                            />
                                        ) : (
                                            <div className="small text-muted">
                                                {bankSlipFile?.name || bankSlipUrl?.split('/').pop() || 'bank-slip.pdf'}
                                            </div>
                                        )}
                                        <Button variant="outline-secondary" size="sm" onClick={resetBankSlip}>
                                            Remove
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    )} */}
                </div>

            </ModalBody>
            <ModalFooter>
                <Button variant="secondary" onClick={hanldeClose}>
                    Close
                </Button>
                <Button variant="primary" onClick={handleSubmit} disabled={loading || paymentMethodLoading} className="d-flex align-items-center justify-content-center gap-1">
                    {loading && <span className="spinner-border spinner-border-sm" role="status"></span>}
                    Update Quotation
                </Button>

            </ModalFooter>
        </Modal>
    )
}

export default ShowPaymentUpdate
