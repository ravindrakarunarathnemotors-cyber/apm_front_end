'use client'

import React, { useEffect, useState, useMemo, useRef } from 'react'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import {
  Table,
  Button,
  Form,
  Spinner,
  Badge,
  Row,
  Col,
  Card,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  CardBody,
  FormControl,
  CardHeader,
  CardTitle,
} from 'react-bootstrap'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import RedCard from '@/components/Redcard'
import Link from 'next/link'
import useLogout from '@/hooks/useLogout'
// import { timeFormate } from '@/utils/date'
import Select from 'react-select'
import { debounce } from 'lodash'
import axios from 'axios'
import Image from 'next/image'
import ShowProduct from '@/components/Invoices/ShowProduct'
import EditCustomer from '@/components/CreateOrder/EditCustomer'
import defaultimage from '@/assets/product-default.jpg'
import CreateCustomer from '@/components/CreateOrder/CreateCustomer'
import ShowPayment from './ShowPaymentUpdateQuo'
import { useGetSystemSettingsQuery, useUpdateSystemSettingsMutation } from '@/store/features/apiSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'
import ProductMeasurementQuantity from '@/components/CreateOrder/ProductMeasurementQyantity'
import NewProduct from '@/components/Invoices/NewProduct'
import { useGetSubPaymentMethodsQuery } from '@/store/features/sandoSlice'

const UpdateQuotation = ({ order_id}) => {
  
  const [search, setSearch] = useState('')
  const [showProductModal, setShowProductModal] = useState(false)
  const [addedproducts, setAddedproducts] = useState([])
  const [allClient, setAllClient] = useState([])
  const [selectClient, setSelectClient] = useState(null)
  const [showEdit, setShowEdit] = useState(false)
  const [loading, setLoading] = useState(true)
  const [orderDetails, setOrderDetails] = useState(null)
  const [clientDetails, setClientDetails] = useState({
    value: 0,
    first_name: '',
    last_name: '',
    contact_number_1: '',
    address: '',
    apartment: '',
    city: '',
    postal_code: '',
    saveInfo: false,
    email: '',
    country: '',
  })
  const [taxManualEnable, setTaxManualEnable] = useState(true)

  const [showCreateCustomer, setShowCreateCustomer] = useState(false)
  const [allPaymentMethod, setAllPaymentMethod] = useState([])
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null)
  const [deliveryFee, setDeliveryFee] = useState(0)
  const [showPayment, setShowPayment] = useState(false)
  // const [timePeriod, setTimePeriod] = useState('')
  const [note, setNote] = useState('')

  const [taxFields, setTaxFields] = useState({ key: '', value: '' })
  const [taxEnabled, setTaxEnabled] = useState(false)
  const [countries, setCountries] = useState([])
  const [deliveryFeeDetails, setDeliveryFeeDetails] = useState({
    fee: 0,
    additional_fee: 0,
  })
  const [sellInternational, setSellInternational] = useState(false)

  const [createItemOpen, setCreateItemOpen] = useState(false)

  //discount
  const [discount, setDiscount] = useState('')
  const [discountManualType, setDiscountManualType] = useState('fixed')
  const [discountType, setDiscountType] = useState('none')
  const [orderDiscount, setOrderDiscount] = useState(null)
  const [productDiscount, setProductDiscount] = useState(null)
  const [finalDiscount, setFinalDiscount] = useState(null)
  const [deliveryDiscount, setDeliveryDiscount] = useState(null)
  const [paymentMethodDiscount, setPaymentMethodDiscount] = useState(null)
  const [buyxDiscont, setBuyxDiscont] = useState(null)
  const [timePeriod, setTimePeriod] = useState('')
  const [termsConditions, setTermsConditions] = useState([])
  const [backendDiscountType, setBackendDiscountType] = useState(null)
  


  const tempCounterRef = useRef(800)
  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  const { data, isLoading, error } = useGetSystemSettingsQuery()

  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()
  const { currency } = useCurrencySymbol()





  useEffect(() => {
    if (search.length > 1) {
      setShowProductModal(true)
    }
  }, [search])

  useEffect(() => {
    if (!order_id) return
    fetchOrderData()
  }, [order_id])

  useEffect(() => {
    if (data?.data) {
      const Taxdata = data.data
      setTaxEnabled(Taxdata.tax)
      setSellInternational(Taxdata.sell_international)
      setTimePeriod(Taxdata.time_period ?? 0)
      const key = Object.keys(Taxdata.tax_value)[0]
      const value = Taxdata.tax_value[key]
      setTaxFields({ key, value })
    }
  }, [data?.data])

  useEffect(() => {
    fetchPaymentMethod()
    fetchCountries()
  }, [])

  const totalAmount = useMemo(() => {
    return addedproducts.reduce((total, item) => total + item.price * item.selectedQty, 0)
  }, [addedproducts])

  //discount parts .................................................................

  useEffect(() => {
    if (addedproducts.length > 0 && selectClient) {
      autoBuyxDiscount()
      autoDiscount()
    }
  }, [addedproducts, selectClient])

  useEffect(() => {
    if (addedproducts.length === 0 || parseFloat(deliveryFee) === 0) return
    autoDeliveryDiscount()
  }, [addedproducts, deliveryFee, selectClient])

  const manualProductDiscountValue = useMemo(() => {
    return addedproducts.reduce((sum, item) => {
      if (!item.discount || Number(item.discount) <= 0) return sum

      const qty = item.selectedQty || 1
      const price = Number(item.price) || 0
      const d = Number(item.discount)

      if (item.discountType === 'percent') {
        return sum + (price * qty * d) / 100
      }

      // fixed discount
      return sum + d
    }, 0)
  }, [addedproducts])

  const fetchOrderData = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/order/oneQuotationUpdateDetails/${order_id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const orderProducts = response.data.result || []
      console.log(orderProducts)
      //add all order details
      setOrderDetails(orderProducts ? orderProducts : null)

      // Flatten variant list with product info
      setAddedproducts(orderProducts.variants)

      setNote(orderProducts.note || '')
      setBackendDiscountType(orderProducts.discount_type)
      try {
        const parsedTerms = orderProducts.recipent_note ? JSON.parse(orderProducts.recipent_note) : []
        setTermsConditions(parsedTerms)
      } catch (err) {
        console.error('Invalid recipent_note JSON', err)
        setTermsConditions([])
      }

      //discount
      if (orderProducts?.discount_type == 'manual') setDiscount(Number(orderProducts?.discount))

      // client and recipient details
      const [first_name = '', last_name = ''] = orderProducts.sender_name?.split(' ') || []
      setSelectClient((prev) => ({
        ...prev,
        first_name: first_name || '',
        last_name: last_name || '',
        contact_number_1: orderProducts.sender_phone || '',
        address: orderProducts.sender_address || '',
        city: orderProducts.sender_city || '',
        value: orderProducts.customer_id || 0,
        country: orderProducts.sender_country_id ? orderProducts.sender_country_id : '',
        country_name: orderProducts.sender_country_name || '',
        email: orderProducts.sender_email || '',
        loyalty_point: orderProducts.loyalty_point || 0,
      }))
    } catch (error) {
      console.error('Failed to fetch order data:', error)
    } finally {
      setLoading(false)
    }
  }

  const isBackendDiscountNull = backendDiscountType === null
  const totalDiscount = useMemo(() => {
    const num = (v) => {
      const n = Number(v)
      return Number.isFinite(n) ? n : 0
    }
    // console.log("first")
    const orderValue = num(orderDiscount?.discount_value)
    const deliveryValue = num(deliveryDiscount?.discount_value)
    const productValue = num(productDiscount?.total_discount_value)
    const buyxValue = num(buyxDiscont?.total_discount_value)
    const paymentValue = num(paymentMethodDiscount?.discount_value)

    // If appliedCode is true, only use finalDiscount, but still keep object shape
    if (discount || manualProductDiscountValue > 0) {
      const manualOrderValue = discount ? (discountManualType === 'fixed' ? parseFloat(discount) : (parseFloat(discount) * totalAmount) / 100) : 0

      const bestManualValue = Math.max(manualOrderValue, manualProductDiscountValue)

      if (Number.isFinite(bestManualValue)) {
        return {
          discountValue: bestManualValue,
          orderValue: 0,
          deliveryValue: 0,
          productValue: 0,
          buyxValue: 0,
          paymentValue: 0,
        }
      }
    }

    const discountValue = Math.max(orderValue, paymentValue, deliveryValue, productValue, buyxValue, 0)

    return {
      discountValue,
      orderValue,
      deliveryValue,
      productValue,
      buyxValue,
      paymentValue,
    }
  }, [
    discount,
    discountManualType,
    finalDiscount,
    orderDiscount,
    productDiscount,
    paymentMethodDiscount,
    deliveryDiscount,
    buyxDiscont,
    selectClient,
    manualProductDiscountValue,
  ])

  useEffect(() => {
    const { discountValue, orderValue, paymentValue, deliveryValue, productValue, buyxValue } = totalDiscount

    if (discountValue === 0) {
      setDiscountType('none')
      return
    }

    const manualOrderValue = discount ? (discountManualType === 'fixed' ? Number(discount) : (Number(discount) * totalAmount) / 100) : 0

    if (manualProductDiscountValue > 0 || manualOrderValue > 0) {
      if (manualProductDiscountValue >= manualOrderValue) {
        setDiscountType('manual_product')
      } else {
        setDiscountType('manual')
      }
      return
    }

    if (discountValue === orderValue) return setDiscountType('order')
    if (discountValue === paymentValue) return setDiscountType('payment_method')
    if (discountValue === deliveryValue) return setDiscountType('shipping')
    if (discountValue === productValue) return setDiscountType('product')
    if (discountValue === buyxValue) return setDiscountType('buyx')

    setDiscountType('none')
  }, [totalDiscount, discount, manualProductDiscountValue])

  //........................................................................

  const fetchCountries = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/system/all-country`,
        {},
        {
          headers: {},
        },
      )
      if (response.status == 200) {
        setCountries(response.data.result)
      }
    } catch (error) {
      console.error('Error fetching countries:', error)
    }
  }

  useEffect(() => {
    const fetchDeliveryFee = async () => {
      if (!selectClient) return

      const country = clientDetails.country
      console.log('first', country)

      if (!country) return
      let delCountry = country

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/system/get-delivery-fee`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ country: delCountry }),
      })

      const data = await response.json()

      if (response.status === 200) {
        // setDeliveryFeeDetails(data.result)
      }
    }

    // fetchDeliveryFee();
  }, [clientDetails.country])

  const handleSearchChange = (e) => {
    const value = e.target.value
    setSearch(value)
  }

  useEffect(() => {
    if (selectClient) {
      setClientDetails((prev) => ({
        ...prev,
        first_name: selectClient.first_name || '',
        last_name: selectClient.last_name || '',
        contact_number_1: selectClient.contact_number_1 || '',
        address: selectClient.address || '',
        apartment: selectClient.apartment || '',
        city: selectClient.city || '',
        postal_code: selectClient.postal_code || '',
        value: selectClient.value || 0,
        country: selectClient.country || '',
        country_name: selectClient.country_name || '',
        email: selectClient.email || '',
      }))
    }
  }, [selectClient])

  const handleQtyInput = (variant_id, newVal) => {
    setAddedproducts((prev) =>
      prev.map((item) =>
        item.variant_id === variant_id
          ? {
              ...item,
              selectedQty: Math.max(1, Number(newVal) || 1),
            }
          : item,
      ),
    )
  }

  const handleRemove = (variant_id) => {
    setAddedproducts((prev) => prev.filter((item) => item.variant_id !== variant_id))
  }

  const handleClientSearch = async (value) => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/common/getAllCustomerUpdate?customer=${value}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.status === 200) {
        setAllClient(response.data.result)
      }
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return handleClientSearch(value)
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        console.error('Search failed:', error)
      }
    }
  }

  const fetchPaymentMethod = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/ordersmange/payment_methods`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      if (response.status === 200) {
        setAllPaymentMethod(response.data.result)
      }
    } catch (error) {
      console.error('Error fetching payment methods:', error)
    }
  }

  const customAddOption = { label: '➕ Add Customer', value: 'add_customer' }
  const clientOptions = [...allClient, customAddOption]

  //calculate quantity
  const totalQty = useMemo(() => {
    return addedproducts.reduce((total, item) => total + item.selectedQty, 0)
  }, [addedproducts])

  //calculate  totalamount

  const totalWight = useMemo(() => {
    return addedproducts.reduce((total, item) => total + item.weight * item.selectedQty, 0)
  }, [addedproducts])

  const totalTax = useMemo(() => {
    const Discount = discountType == 'buyx' ? 0 : parseFloat(totalDiscount?.discountValue) || 0
    const beforetaxAmount = parseFloat(totalAmount) - Discount + parseFloat(deliveryFee)

    return beforetaxAmount * (parseFloat(taxFields.value) / 100)
  }, [addedproducts, deliveryFee, totalDiscount?.discountValue, discountType])

  // delivery fee
  useEffect(() => {
    if (!deliveryFeeDetails) return
    const roundedWeight = Math.ceil(parseFloat(totalWight))
    if (roundedWeight > 1) {
      setDeliveryFee(parseFloat(deliveryFeeDetails.fee) + parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
    } else {
      setDeliveryFee(deliveryFeeDetails.fee)
    }
  }, [totalWight, deliveryFeeDetails])

  const lastSubTotal = useMemo(() => {
    const totalValue = parseFloat(totalAmount) || 0
    const discountValue = parseFloat(totalDiscount?.discountValue) || 0

    return discountType == 'product' || discountType == 'manual_product' ? totalValue - discountValue : totalValue
  }, [totalAmount, totalDiscount?.discountValue, discountType])

  const fullAmount = useMemo(() => {
    const fullDiscount =
      discountType == 'buyx' || discountType == 'product' || discountType == 'manual_product' ? 0 : parseFloat(totalDiscount?.discountValue) || 0
    const parsedDeliveryFee = parseFloat(deliveryFee) || 0

    if (taxEnabled && taxManualEnable) {
      return lastSubTotal - fullDiscount + parsedDeliveryFee + totalTax
    } else {
      return lastSubTotal - fullDiscount + parsedDeliveryFee
    }
  }, [lastSubTotal, discount, deliveryFee, discountType, taxManualEnable, totalDiscount])

  const countryName = (id) => {
    const country = countries.find((country) => country.id == id)
    return country ? country.country_name : ''
  }

  //discount modules ............................................................................................................
  const autoDiscount = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/invoice-discount/autodiscountcheck`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value,
        }),
      })

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json()

      if (response.status === 200) {
        // setDiscountType(data.final)
        setOrderDiscount(data.data.order ? data.data.order : null)
        setProductDiscount(data.data.product ? data.data.product : null)
      }
    } catch (error) {
      console.log(error)
    }
  }

  const termsConditionsPayload = useMemo(() => {
    return JSON.stringify(termsConditions.filter((term) => term.trim() !== ''))
  }, [termsConditions])

  const autoBuyxDiscount = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/invoice-discount/autodbuyxdiscount`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value,
        }),
      })

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoBuyxDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json()

      if (response.status === 200) {
        setBuyxDiscont(data.data ? data.data : null)
      }
    } catch (error) {
      console.log(error)
    }
  }

  const autoDeliveryDiscount = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/invoice-discount/autodeliverdiscount`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value,
          deliverFee: deliveryFee,
        }),
      })

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoDeliveryDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json()

      if (response.status === 200) {
        setDeliveryDiscount(data.data ? data.data : null)
      }
    } catch (error) {
      console.log(error)
    }
  }

  function getDiscountDetails() {
    console.log('Discount Type:', discountType)

    // 🚫 No discount at all
    if (discountType === 'none' && !discount && !finalDiscount) {
      return null
    }

    /**
     * ============================
     * 🔥 MANUAL DISCOUNTS
     * ============================
     */

    // Manual ORDER discount
    if (discountType === 'manual' && discount) {
      const value = discountManualType === 'fixed' ? Number(discount) : (Number(discount) * totalAmount) / 100

      return {
        discount_id: null,
        discount_value: Number.isFinite(value) ? value : 0,
        type: 'manual',
      }
    }

    // Manual PRODUCT discount
    if (discountType === 'manual_product' && manualProductDiscountValue > 0) {
      return {
        discount_id: null,
        discount_value: manualProductDiscountValue,
        type: 'manual_product',
      }
    }

    /**
     * ============================
     * 🎯 SYSTEM DISCOUNTS
     * ============================
     */

    if (discountType === 'order' && orderDiscount) {
      return {
        discount_id: orderDiscount.discount_id,
        discount_value: Number(orderDiscount.discount_value) || 0,
        type: 'order',
      }
    }

    if (discountType === 'payment_method' && paymentMethodDiscount) {
      return {
        discount_id: paymentMethodDiscount.discount_id,
        discount_value: Number(paymentMethodDiscount.discount_value) || 0,
        type: 'payment_method',
      }
    }

    if (discountType === 'shipping' && deliveryDiscount) {
      return {
        discount_id: deliveryDiscount.discount_id,
        discount_value: Number(deliveryDiscount.discount_value) || 0,
        type: 'shipping',
      }
    }

    if (discountType === 'product' && productDiscount) {
      return {
        discount_id: productDiscount.discount_id,
        discount_value: Number(productDiscount.total_discount_value) || 0,
        type: 'product',
        discont_product: productDiscount.applicableProducts,
      }
    }

    if (discountType === 'buyx' && buyxDiscont) {
      return {
        discount_id: buyxDiscont.discount_id,
        discount_value: buyxDiscont.applicableProducts,
        type: 'buyx',
      }
    }

    return null
  }

  const handleAddProduct = async () => {
    if (addedproducts.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please add products to the order',
      })
      return
    }

    if (!selectClient) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please select a customer',
      })
      return
    }

    if (!clientDetails.first_name || !clientDetails.last_name || !clientDetails.address || !clientDetails.city) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please fill all the required customer fields',
      })
      return
    }

    if (!clientDetails.contact_number_1 && !clientDetails.email) {
      Swal.fire({
        title: 'Error',
        text: 'Please fill at least one contact number or email',
        icon: 'error',
        confirmButtonText: 'OK',
      })
      return
    }
    setShowPayment(true)
  }

  const handleProductDescription = (variant_id, newText) => {
    setAddedproducts((prev) => prev.map((item) => (item.variant_id === variant_id ? { ...item, description: newText } : item)))
  }
  const handleProductDiscountAmount = (variant_id, newText) => {
    const value = newText

    // Allow empty input
    if (value === '') {
      setAddedproducts((prev) => prev.map((item) => (item.variant_id === variant_id ? { ...item, discount: '' } : item)))
      return
    }

    // Only integers allowed
    const intRegex = /^\d+$/
    if (!intRegex.test(value)) return

    const numericValue = Number(value)

    // If type is percent, max 100
    if (discountManualType === 'percent' && numericValue > 100) return

    setAddedproducts((prev) => prev.map((item) => (item.variant_id === variant_id ? { ...item, discount: value } : item)))
  }

  const handleProductDiscountType = (variant_id, newText) => {
    const value = newText

    setAddedproducts((prev) => prev.map((item) => (item.variant_id === variant_id ? { ...item, discountType: value, discount: '' } : item)))
  }

  const handleDiscount = (e) => {
    const value = e.target.value

    // Allow empty input
    if (value === '') {
      setDiscount('')
      return
    }

    // Only integers allowed
    const intRegex = /^\d+$/
    if (!/^\d*\.?\d*$/.test(value)) return

    const numericValue = Number(value)

    // If type is percent, max 100
    if (discountManualType === 'percent' && numericValue > 100) return

    if (discountManualType === 'fixed' && numericValue > (parseFloat(totalAmount) || 0)) return

    setDiscount(value)
  }

  return (
    <div>
      {/* <ComponentContainerCard title=""> */}
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center justify-content-between">
            <Col>
              <CardTitle as="h4" className="mb-0">
                Update Quotation
              </CardTitle>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          <Row>
            <Col md={12}>
              <Row className="g-3">
                {/* Left Side - 2/3 */}
                <Col xs={12} lg={12}>
                  {/* Customer Details Card */}
                  <Card className="border">
                    {/* Card Header */}
                    <CardHeader
                      className="d-flex justify-content-between align-items-center py-2"
                      style={{
                        backgroundColor: '#f3f7faee', // soft grey
                        borderBottom: '1px solid #dee2e6',
                      }}>
                      <div className="d-flex align-items-center gap-2">
                        <strong className="fs-6">Quotations Details</strong>
                      </div>

                      {selectClient && (
                        <Button size="sm" variant="outline-primary" onClick={() => setShowEdit(true)}>
                          <Icon icon="akar-icons:edit" width="14" className="me-1" />
                          Edit Details
                        </Button>
                      )}
                    </CardHeader>

                    {/* Card Body */}
                    <CardBody>
                      {selectClient ? (
                        <div className="d-flex justify-content-between align-items-center">
                          {/* Customer Info */}
                          <div className="d-flex align-items-center gap-3">
                            <Icon icon="mdi:account" width="40" />
                            <div>
                              <div className="fw-semibold">
                                #{clientDetails?.value} {clientDetails?.first_name} {clientDetails?.last_name}
                              </div>
                              <small className="text-muted">Selected Customer</small>
                            </div>
                          </div>

                          {/* Actions */}
                          <Dropdown>
                            <DropdownToggle variant="light" className="border-0 p-1">
                              <Icon icon="mage:dots" width="20" />
                            </DropdownToggle>
                            <DropdownMenu align="end">
                              <DropdownItem onClick={() => setShowEdit(true)}>Edit Customer</DropdownItem>
                              <DropdownItem
                                className="text-danger"
                                onClick={() => {
                                  setSelectClient(null)
                                  setClientDetails({
                                    first_name: '',
                                    last_name: '',
                                    contact_number_1: '',
                                    address: '',
                                    apartment: '',
                                    city: '',
                                    postal_code: '',
                                    email: '',
                                    country: '',
                                  })
                                }}>
                                Remove Customer
                              </DropdownItem>
                            </DropdownMenu>
                          </Dropdown>
                        </div>
                      ) : (
                        <>
                          <Select
                            options={clientOptions}
                            value={clientOptions.find((option) => option.value === selectClient?.value) || null}
                            onChange={(selectedOption) => {
                              if (selectedOption?.value === 'add_customer') {
                                setShowCreateCustomer(true)
                                setSelectClient(null)
                              } else {
                                setSelectClient(selectedOption || null)
                              }
                            }}
                            placeholder="Select Or Add New Customer.."
                            isClearable
                            onInputChange={(inputValue, actionMeta) => {
                              if (actionMeta.action === 'input-change') {
                                handleClientSearch(inputValue)
                              }
                            }}
                            filterOption={() => true}
                            styles={{
                              control: (base, state) => ({
                                ...base,
                                borderRadius: '999px',
                                borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                                boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                              }),
                            }}
                          />
                        </>
                      )}
                    </CardBody>
                  </Card>

                  {/* Add Items Card */}
                  <Card className="border">
                    {/* Card Header */}
                    <CardHeader
                      className="py-2 d-flex align-items-center"
                      style={{
                        backgroundColor: '#f1f3f5',
                        borderBottom: '1px solid #dee2e6',
                      }}>
                      <div className="d-flex align-items-center gap-2">
                        <Icon icon="mdi:package-variant" width="20" color="#495057" />
                        <strong>Add Items</strong>
                      </div>
                    </CardHeader>

                    <CardBody className="p-2 d-flex flex-column">
                      <div className="d-flex align-items-center gap-2 py-2">
                        <div className="flex-grow-1">
                          <div className="d-flex border rounded overflow-hidden">
                            <input
                              type="search"
                              name="search"
                              className="form-control border-0 shadow-none"
                              placeholder="Search products"
                              value={search}
                              onChange={handleSearchChange}
                              autoComplete="off"
                            />
                            <button className="btn border-0 bg-white">
                              <Icon icon="iconoir:search" />
                            </button>
                          </div>
                        </div>

                        <Button
                          variant="outline"
                          className=" d-flex btn-outline-primary align-items-center justify-content-center gap-1 btn-sm"
                          style={{ borderRadius: '10px', minHeight: '36px' }}
                          onClick={() => setCreateItemOpen(true)}>
                          <Icon icon="ic:baseline-plus" width="40" height="20" />
                          <span>Add Temporary Item</span>
                        </Button>
                      </div>
                      <div className="mt-2">
                        {addedproducts.length > 0 && (
                          <Table responsive striped style={{ tableLayout: 'fixed', width: '100%' }}>
                            <thead>
                              <tr className="bg-light my-2">
                                <th style={{ width: '40px', textAlign: 'center' }}></th>
                                <th style={{ textAlign: 'left', width: 'auto' }}>Product</th>
                                <th style={{ width: '160px', textAlign: 'center' }}>Quantity</th>
                                <th style={{ width: '180px', textAlign: 'right' }}>Discount</th>
                                <th style={{ width: '120px', textAlign: 'right' }}>Amount ({currency})</th>
                              </tr>
                            </thead>
                            <tbody>
                              {addedproducts.map((item) => {
                                const qty = Number(item.selectedQty ?? 1)
                                const originalTotal = Number(item.price || 0) * qty

                                let totalDiscountAmount = 0

                                /*
                                 *auto product discount
                                 */

                                if (discountType === 'product') {
                                  const productDiscForItem = (productDiscount?.applicableProducts || []).find((d) => d.variant_id === item.variant_id)

                                  if (productDiscForItem) {
                                    const unitDiscount = Number(productDiscForItem.discount_value || 0)
                                    totalDiscountAmount = unitDiscount
                                  }
                                }

                                //....................................................................................

                                if (discountType === 'manual_product' && item.discount && Number(item.discount) > 0) {
                                  totalDiscountAmount =
                                    item.discountType == 'fixed' ? Number(item.discount) : (Number(item.discount) * originalTotal) / 100
                                }

                                const totalafterDisocunt = originalTotal - totalDiscountAmount
                                const finalTotal = Math.max(0, totalafterDisocunt)
                                const hasLineDiscount = totalDiscountAmount > 0
                                return (
                                  <tr key={item.variant_id}>
                                    <td className="text-end d-flex align-items-start">
                                      <Button variant="link" className="text-danger p-0" onClick={() => handleRemove(item.variant_id)}>
                                        <Icon icon="material-symbols:delete" width="20" height="20" style={{ color: '#ff2626' }} />
                                      </Button>
                                    </td>
                                    <td>
                                      <div className="d-flex gap-2">
                                        <Image
                                          src={item.main_img || item.first_extra_img || defaultimage}
                                          rounded
                                          width={48}
                                          height={48}
                                          style={{ objectFit: 'cover', border: '1px solid #ebebeb', borderRadius: '8px' }}
                                        />
                                        <div>
                                          <div className="fw-semibold ">
                                            #{item.variant_id} - {item.title}
                                          </div>

                                          {/* {(item.option_values?.join(' ') || item.variant_value).split('/').map((val, idx) => (
                                                                                        <span key={idx} className="badge badge-pill bg-dark text-light me-1">
                                                                                            {val.trim()}
                                                                                        </span>
                                                                                    ))} */}
                                          {String(item.option_values?.length ? item.option_values.join(' ') : item.variant_value || '')
                                            .split('/')
                                            .map((val, idx) => (
                                              <span key={idx} className="badge badge-pill bg-dark text-light me-1">
                                                {val.trim()}
                                              </span>
                                            ))}

                                          {/* ⭐ Added FREE badge — only when discountType is 'buyx' */}
                                          {discountType === 'buyx' &&
                                            buyxDiscont?.applicableProducts
                                              ?.filter((d) => d.variant_id === item.variant_id)
                                              .map((d, i) => (
                                                <div key={i}>
                                                  <span className="badge bg-success text-light me-1">FREE × {d.free_count || 1}</span>
                                                </div>
                                              ))}

                                          {/* <div className="text-primary mt-1">
                                                                                        {currency} {Number(item.price).toFixed(2)}
                                                                                    </div> */}
                                        </div>
                                      </div>
                                      <div className="mt-1">
                                        <textarea
                                          class="form-control"
                                          aria-label="With textarea"
                                          placeholder="Product Description"
                                          onChange={(e) => handleProductDescription(item.variant_id, e.target.value)}
                                          value={item.description}></textarea>
                                      </div>
                                    </td>
                                    {/* <td className="text-end">{item.weight}</td> */}
                                    <td className="text-end">
                                      <div className="d-flex align-items-center gap-2">
                                        {item.measurement_needed ? (
                                          <div className="d-flex gap-1 align-items-center">
                                            <ProductMeasurementQuantity
                                              setAddedproducts={setAddedproducts}
                                              item={item}
                                              count={item.count}
                                              value={item.amount_per_unit}
                                            />
                                            <span>{item.measurement_needed ? item.measurement_value : ''}</span>
                                          </div>
                                        ) : (
                                          <div className="d-flex gap-1 align-items-center">
                                            <Form.Control
                                              type="number"
                                              size="sm"
                                              min={1}
                                              value={item.selectedQty ?? 1}
                                              onChange={(e) => handleQtyInput(item.variant_id, e.target.value)}
                                              style={{ width: 80, textAlign: 'end' }}
                                            />
                                            <span>{item.measurement_needed ? item.measurement_value : ''}</span>
                                          </div>
                                        )}
                                      </div>
                                    </td>

                                    <td className="">
                                      <div className="d-flex gap-1">
                                        <FormControl
                                          type="text"
                                          placeholder={item.discountType === 'percent' ? '0%' : '0.00'}
                                          value={item.discount}
                                          onChange={(e) => handleProductDiscountAmount(item.variant_id, e.target.value)}
                                          className="text-end"
                                          style={{ maxWidth: '80px', height: 30 }}
                                        />
                                        <Form.Select
                                          size="sm"
                                          style={{ maxWidth: 90, height: 30 }}
                                          value={item.discountType}
                                          onChange={(e) => {
                                            handleProductDiscountType(item.variant_id, e.target.value)
                                          }}>
                                          <option value="fixed">{currency}</option>
                                          <option value="percent">%</option>
                                        </Form.Select>
                                      </div>
                                    </td>
                                    <td className="text-end">
                                      <div className="d-flex align-items-center justify-content-end">
                                        {(discountType === 'product' || discountType === 'manual_product') && hasLineDiscount ? (
                                          <div className="me-2 text-end">
                                            <div style={{ textDecoration: 'line-through', opacity: 0.6 }}>{originalTotal.toFixed(2)}</div>
                                            <div style={{ fontWeight: 600 }}>{finalTotal.toFixed(2)}</div>
                                          </div>
                                        ) : (
                                          <div className="me-2">{originalTotal.toFixed(2)}</div>
                                        )}
                                      </div>
                                    </td>
                                  </tr>
                                )
                              })}
                            </tbody>
                            {addedproducts.length > 0 && (
                              <tfoot>
                                {/* SUBTOTAL FIRST when discount_type is null */}

                                <tr className="border-top">
                                  <td></td>
                                  <td colSpan={2}>
                                    <strong>Subtotal</strong>
                                    <div className="text-muted small">{totalQty} items</div>
                                  </td>
                                  <td></td>
                                  <td className="text-end fw-semibold">{lastSubTotal.toFixed(2)}</td>
                                </tr>

                                {/* DISCOUNT ROW */}
                                <tr className="border-top">
                                  <td></td>
                                  <td colSpan={2}>
                                    {{
                                      order: 'Order Discount',
                                      product: 'Product Discount',
                                      payment_method: 'Payment Method Discount',
                                      buyx: 'BuyXGetY Discount',
                                    }[discountType] || 'Discount'}
                                  </td>
                                  <td className="text-end">
                                    <div className="d-flex justify-content-end gap-1">
                                      <FormControl
                                        type="text"
                                        size="sm"
                                        placeholder={discountManualType === 'percent' ? '0%' : '0.00'}
                                        value={discount}
                                        onChange={handleDiscount}
                                        style={{ maxWidth: 80 }}
                                      />
                                      <Form.Select
                                        size="sm"
                                        value={discountManualType}
                                        onChange={(e) => {
                                          setDiscountManualType(e.target.value)
                                          setDiscount('')
                                        }}
                                        style={{ maxWidth: 90 }}>
                                        <option value="fixed">{currency}</option>
                                        <option value="percent">%</option>
                                      </Form.Select>
                                    </div>
                                  </td>
                                  <td className="text-end fw-semibold">{parseFloat(totalDiscount.discountValue || 0).toFixed(2)}</td>
                                </tr>

                                {/* TAX */}
                                {taxEnabled && (
                                  <tr>
                                    <td></td>
                                    <td colSpan={3}>
                                      {taxFields.key} ({taxFields.value}%)
                                    </td>
                                    <td className="text-end">{totalTax.toFixed(2)}</td>
                                  </tr>
                                )}

                                {/* TOTAL */}
                                <tr className="border-top">
                                  <td></td>
                                  <td colSpan={3} className="fw-bold fs-5">
                                    Total
                                  </td>
                                  <td className="text-end fw-bold fs-5">{fullAmount.toFixed(2)}</td>
                                </tr>

                                {/* TERMS */}
                                <tr>
                                  <td colSpan={5}>
                                    <label className="form-label fw-semibold mb-1">Terms And Conditions</label>
                                    <FormControl
                                      as="textarea"
                                      rows={7}
                                      className="text-xs"
                                      style={{ resize: 'vertical' }}
                                      placeholder="Enter each term on a new line"
                                      value={termsConditions.join('\n')}
                                      onChange={(e) => setTermsConditions(e.target.value.split('\n'))}
                                    />
                                  </td>
                                </tr>

                                {/* NOTE */}
                                {selectedPaymentMethod?.label !== 'COD' && (
                                  <tr>
                                    <td colSpan={5}>
                                      <label className="form-label fw-semibold mb-1">Note</label>
                                      <FormControl
                                        as="textarea"
                                        rows={3}
                                        placeholder="Add reference or note"
                                        value={note}
                                        onChange={(e) => setNote(e.target.value)}
                                      />
                                    </td>
                                  </tr>
                                )}
                              </tfoot>
                            )}
                          </Table>
                        )}
                      </div>

                    </CardBody>
                  </Card>
                </Col>
              </Row>

              {addedproducts.length > 0 && (
                <div className="text-end mt-2">
                  <Button variant="primary" className="bg-primary border-primary px-4" onClick={handleAddProduct}>
                    Update Quotation
                  </Button>
                </div>
              )}
            </Col>
          </Row>
          
        </CardBody>
      </Card>

      {showProductModal && (
        <ShowProduct
          open={showProductModal}
          setOpen={setShowProductModal}
          search={search}
          setAddedproducts={setAddedproducts}
          addedproducts={addedproducts}
          setSearch={setSearch}
        />
      )}

      {showEdit && (
        <EditCustomer open={showEdit} setOpen={setShowEdit} clientDetails={clientDetails} setClientDetails={setClientDetails} countries={countries} />
      )}

      {showCreateCustomer && (
        <CreateCustomer
          open={showCreateCustomer}
          setOpen={setShowCreateCustomer}
          clientDetails={clientDetails}
          setClientDetails={setClientDetails}
          countries={countries}
           onCustomerCreated={(customer) => {
      // 1️⃣ add to select options
      setAllClient((prev) => [...prev, customer])

      // 2️⃣ auto select
      setSelectClient(customer)
    }}
        />
      )}

      {createItemOpen && (
        <NewProduct open={createItemOpen} setOpen={setCreateItemOpen} setAddedproducts={setAddedproducts} tempCounterRef={tempCounterRef} />
      )}

      {showPayment && (
        <ShowPayment
          open={showPayment}
          setOpen={setShowPayment}
          allPaymentMethod={allPaymentMethod}
          selectedPaymentMethod={selectedPaymentMethod}
          setSelectedPaymentMethod={setSelectedPaymentMethod}
          fullAmount={fullAmount}
          addedproducts={addedproducts}
          selectClient={selectClient}
          clientDetails={clientDetails}
          taxManualEnable={taxManualEnable}
          deliveryFee={deliveryFee}
          discount={totalDiscount.discountValue}
          totalTax={totalTax}
          taxValue={taxFields.value}
          discountType={discountType}
          taxname={taxFields.key}
          currency={currency}
          totalAmount={totalAmount}
          setPaymentMethodDiscount={setPaymentMethodDiscount}
          getDiscountDetails={getDiscountDetails}
          timePeriod={timePeriod}
          note={note}
          recipient_note={termsConditionsPayload}
          lastSubTotal={lastSubTotal}
          orderId={order_id}
        />
      )}
    </div>
  )
}

export default UpdateQuotation
