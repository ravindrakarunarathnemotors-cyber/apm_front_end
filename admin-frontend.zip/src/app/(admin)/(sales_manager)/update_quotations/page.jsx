import React from 'react'
import UpdateQuotation from './component/Update_qutation';


function UpdateQuotationPage({ searchParams }) {
  const order_id = searchParams?.qutation_id || null;
  return (
    <>
      <UpdateQuotation order_id={order_id} />
    </>
  )
}

export default UpdateQuotationPage