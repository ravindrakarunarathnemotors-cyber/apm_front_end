
import React from 'react';
import dynamic from 'next/dynamic';

export const metadata = {
  title: 'All Invoices',
}

const AllOrders = dynamic(() => import('./AllOrders'), { ssr: false })

const AllOrdersPage = () => {
  return (
    <div>
      <AllOrders />
    </div>
  );
};

export default AllOrdersPage;
