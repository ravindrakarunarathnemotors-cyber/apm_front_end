'use client'

import React, { useState } from 'react'
import { Modal, Button, Spinner, Alert } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useCancelInvoiceMutation, useGetInvoiceDetailsQuery } from '@/store/features/apiSlice'

export default function CancelInvoiceModal({ show, onClose, order, onSuccess }) {
  // ✅ SAFE access BEFORE hooks
  const invoiceId = order?.id
  const currency = order?.currency || ''

  const [expanded, setExpanded] = useState(false)

  /* =========================
     FETCH INVOICE DETAILS
  ========================= */
  const { data, isLoading } = useGetInvoiceDetailsQuery(invoiceId, {
    skip: !invoiceId || !show,
  })

  const [cancelInvoice, { isLoading: cancelling }] = useCancelInvoiceMutation()

  // ✅ EARLY RETURN MOVED HERE (ONLY REQUIRED FIX)
  if (!order) return null

  const invoiceDetails = data?.order_items || []
  const invoiceTo = data?.fromdetails || null

  /* =========================
     ORIGINAL CALCULATIONS (UNCHANGED)
  ========================= */
  const subTotal = Number(order.total_value || 0)
  const tax_percentage = Number(order.tax_percentage || 0)
  const taxName = order.tax?.name || 'VAT & Tax'
  const taxAmount = Number(order.tax?.value || 0)
  const orderDiscount = Number(order.discount || 0)
  const loyalty = Number(order.loyalty_points_spent || 0)

  const total = Number(order.full_amount || 0)
  const paid = Number(order.amount_paid || 0)
  const due = total - paid
  const payment_status = order.payment_status

  const issueDate = order.created_at
    ? new Date(order.created_at).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })
    : '-'

  /* =========================
     Cancel Handler
  ========================= */
  const handleCancel = async () => {
    const { isConfirmed } = await Swal.fire({
      title: 'Cancel Invoice?',
      html: `
        <p><strong>Invoice #${invoiceId}</strong></p>
        <p>Total: <strong>${total.toFixed(2)} ${currency}</strong></p>
        <p style="color:#b91c1c">This action cannot be undone.</p>
      `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Cancel',
      cancelButtonText: 'No',
      reverseButtons: true,
    })

    if (!isConfirmed) return

    await cancelInvoice({ invoice_id: invoiceId }).unwrap()

    Swal.fire('Cancelled', 'Invoice cancelled successfully.', 'success')
    onSuccess?.()
  }

  /* =========================
     UI
  ========================= */
  return (
    <Modal show={show} onHide={onClose} size="md" centered backdrop="static">
      {/* ===== Header ===== */}
      <Modal.Header closeButton className="pb-2 border-bottom">
        <div>
          <Modal.Title className="fs-5 fw-bold">Cancel Invoice</Modal.Title>
          <div className="small">
            Invoice #{invoiceId} · {issueDate}
          </div>
        </div>
      </Modal.Header>

      <Modal.Body className="pt-2">
        {/* 🔴 Warning */}
        <Alert variant="danger" className="py-2 mb-3">
          <strong>Do you want to cancel this invoice?</strong>
          <div className="small">This action is permanent and cannot be undone.</div>
        </Alert>

        {isLoading ? (
          <div className="text-center py-4">
            <Spinner />
          </div>
        ) : (
          <>
            {/* ===== Invoice To ===== */}
            {invoiceTo && (
              <div className="mb-2">
                <div className="fw-bold mb-1">INVOICE TO</div>
                <div className="border rounded-3 px-3 py-2">
                  <div className="fw-semibold">{invoiceTo.company_name}</div>
                  {invoiceTo.address_1 && <div>{invoiceTo.address_1}</div>}
                  {invoiceTo.address_2 && <div>{invoiceTo.address_2}</div>}
                  {invoiceTo.hotline && <div>📞 {invoiceTo.hotline}</div>}
                </div>
              </div>
            )}

            {/* ===== Items (Expandable) ===== */}
            <div className="mb-3">
              <div className="fw-bold mb-1">ITEMS</div>

              <div
                className="border rounded-3 overflow-hidden"
                style={{
                  maxHeight: expanded ? '1000px' : '160px',
                  transition: 'max-height 0.35s ease',
                }}>
                {invoiceDetails.map((it, idx) => (
                  <div key={idx} className="px-3 py-2 border-bottom">
                    <div className="fw-semibold">{it.name}</div>
                    <div style={{ fontSize: '12px' }}>
                      ID: #{it.product_id} · Qty: {it.unit_type == 1 ? it.quantity : it.quantity * Number(it.amount_per_unit)}
                      {it.unit_type != 1 && it.measurement_value}
                    </div>
                  </div>
                ))}
              </div>

              {invoiceDetails.length > 3 && (
                <div className="text-center mt-1">
                  <Button variant="link" size="sm" className="text-decoration-none" onClick={() => setExpanded(!expanded)}>
                    {expanded ? '▲ Show less' : '▼ Show more'}
                  </Button>
                </div>
              )}
            </div>

            {/* ===== Totals (UNCHANGED) ===== */}
            <div className="bg-light rounded-3 p-2">
              <div className="d-flex justify-content-between small mb-1">
                <span>Sub Total</span>
                <span>
                  {subTotal.toFixed(2)} {currency}
                </span>
              </div>

              <div className="d-flex justify-content-between small mb-1">
                <span>
                  {taxName} ({tax_percentage}%)
                </span>
                <span>
                  {taxAmount.toFixed(2)} {currency}
                </span>
              </div>

              <div className="d-flex justify-content-between small mb-1">
                <span>Discount</span>
                <span>
                  -{orderDiscount.toFixed(2)} {currency}
                </span>
              </div>

              {loyalty > 0 && (
                <div className="d-flex justify-content-between small mb-1">
                  <span>Loyalty</span>
                  <span>
                    -{loyalty.toFixed(2)} {currency}
                  </span>
                </div>
              )}

              <hr className="my-2" />

              <div className="d-flex justify-content-between fw-bold">
                <span>Total</span>
                <span>
                  {total.toFixed(2)} {currency}
                </span>
              </div>

              {payment_status === 'partially paid' && (
                <>
                  <div className="d-flex justify-content-between small mt-1">
                    <span>Paid</span>
                    <span>
                      {paid.toFixed(2)} {currency}
                    </span>
                  </div>
                  <div className="d-flex justify-content-between small text-danger">
                    <span>Due</span>
                    <span>
                      {due.toFixed(2)} {currency}
                    </span>
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </Modal.Body>

      {/* ===== Footer ===== */}
      <Modal.Footer className="py-2 border-top">
        <Button variant="outline-secondary" size="sm" onClick={onClose}>
          Close
        </Button>
        <Button variant="danger" size="sm" onClick={handleCancel} disabled={cancelling}>
          {cancelling ? 'Cancelling…' : 'Confirm Cancel'}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}
