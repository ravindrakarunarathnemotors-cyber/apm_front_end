'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import { useRouter } from 'next/navigation'
import CancelInvoiceModal from './CancelInvoiceModal'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Pagination, Badge } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import InvoiceModal from '../invoice/modal/InvoiceModal'
import Paymentmodal from '@/components/Order/InlineAddPayment'
import {
  useGetFilteredInvoiceOrdersMutation,
  useGetRecipientnameQuery,
  useRefreshTokenMutation,
  useGetUsersListQuery
} from '@/store/features/apiSlice'
import axios from 'axios'

function AllOrders() {
  const Logout = () => {
    sessionStorage.clear()
    localStorage.clear()
    window.location.href = '/auth/login'
  }
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })
  const [refreshtoken] = useRefreshTokenMutation()
  const [orderStatuses, setOrderStatuses] = useState([])
  const [fetchFilteredOrders, { isLoading, error }] = useGetFilteredInvoiceOrdersMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [orders, setOrders] = useState([])
  const logsPerPage = 25
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [byFilter, setByFilter] = useState('')
  const [posFilter, setPosFilter] = useState('')
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [loading, setLoading] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrder, setCancelOrder] = useState(null)
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [currency, setCurrency] = useState('')
  const [searchUser, setSearchUser] = useState('')
  const [selectedUserName, setSelectedUserName] = useState('')
  const [showDelete, setShowDelete] = useState(false)
  const [deleteLoading, setDeleteLoading] = useState(false)


  const printSectionRef = useRef()
  const router = useRouter()


  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const { data: userResults } = useGetUsersListQuery(searchUser, {
    skip: searchUser.length < 2,
  })

  const userOptions =
    userResults?.map((user) => ({
      label: `${user.first_name} ${user.last_name}`,
      value: user.user_id,
    })) || []

  const debouncedSearchUser = debounce((value) => {
    setSearchUser(value)
  }, 300)

  const handlePayment = (order) => {
    setSelectedOrderId(order)
    setShowPaymentModal(true)
  }


  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const token = sessionStorage.getItem('access_token')
      const res = await fetchFilteredOrders({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        payment_status: paymentStatus,
        date: date,
        todate: todate,
        user_id: byFilter,
        type: posFilter,
        order_status: orderStatuses.map((s) => s.value),
      }).unwrap()

      setOrders(res.orders || [])
      setTotalPages(res.totalPages || 1)
      setCurrency(res.currency || res.orders?.[0]?.currency || '')
      setCurrency(res.orders?.[0]?.currency || '')
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch orders:', err)
      // Handle 401/403 → try refresh → retry once
      const status = err?.status || err?.originalStatus || err?.data?.status
      if (status === 401 || status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const refreshed = await refreshtoken(refreshToken).unwrap()
            // Save new access token and retry the same call
            if (refreshed?.access_token) {
              sessionStorage.setItem('access_token', refreshed.access_token)
            }
            const retry = await fetchFilteredOrders({
              page,
              limit: logsPerPage,
              keyword: filters.keyword,
              order_id: orderId,
              recipient_name: recipientName,
              mobile: mobileNo,
              payment_status: paymentStatus,
              date: date,
              todate: todate,
              user_id: byFilter,
              type: posFilter,
              order_status: orderStatuses.map((s) => s.value),
            }).unwrap()

            setOrders(retry.orders || [])
            setTotalPages(retry.totalPages || 1)
            setCurrentPage(page)
          } catch (refreshErr) {
            console.error('Refresh failed:', refreshErr)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        console.error('Failed to fetch orders:', err)
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
    handlepermission()
  }, [])

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const handleView = (order) => {
    setSelectedOrder(order)
    setShowViewModal(true)
  }


  const handleDelete = async (order) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Confirm',
    });

    if (!result.isConfirmed) return;
    setDeleteLoading(true)
    try {
      let accessToken = token;

      const makeRequest = async (tokenToUse) => {
        return await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/order/deleteInvoice`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${tokenToUse}`,
          },
          body: JSON.stringify({
            order_id: order.id,
          }),
        });
      };

      let response = await makeRequest(accessToken);

      // 🔁 Handle token expiration
      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token');

        if (!refreshToken) {
          Logout();
          return;
        }

        try {
          const refreshRes = await refreshtoken(refreshToken).unwrap();
          accessToken = refreshRes.access_token;

          sessionStorage.setItem('access_token', accessToken);

          // retry request
          response = await makeRequest(accessToken);
        } catch (err) {
          console.error('Error refreshing token:', err);
          Logout();
          return;
        }
      }

      const data = await response.json();

      if (response.status === 200) {
        Swal.fire('Success', data.message, 'success');
        fetchLogs(currentPage);
      } else {
        Swal.fire('Error', data.message || 'Something went wrong', 'error');
      }

    } catch (error) {
      console.error('Delete error:', error);
      Swal.fire('Error', 'Request failed', 'error');
    } finally {
      setDeleteLoading(false)
    }
  };

  const handlebackofficeDelete = async (order) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Confirm',
    });

    if (!result.isConfirmed) return;
    setDeleteLoading(true)
    try {
      let accessToken = token;

      const makeRequest = async (tokenToUse) => {
        return await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/order/deleteBackOfficeInvoice`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${tokenToUse}`,
          },
          body: JSON.stringify({
            order_id: order.id,
          }),
        });
      };

      let response = await makeRequest(accessToken);

      // 🔁 Handle token expiration
      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token');

        if (!refreshToken) {
          Logout();
          return;
        }

        try {
          const refreshRes = await refreshtoken(refreshToken).unwrap();
          accessToken = refreshRes.access_token;

          sessionStorage.setItem('access_token', accessToken);

          // retry request
          response = await makeRequest(accessToken);
        } catch (err) {
          console.error('Error refreshing token:', err);
          Logout();
          return;
        }
      }

      const data = await response.json();

      if (response.status === 200) {
        Swal.fire('Success', data.message, 'success');
        fetchLogs(currentPage);
      } else {
        Swal.fire('Error', data.message || 'Something went wrong', 'error');
      }

    } catch (error) {
      console.error('Delete error:', error);
      Swal.fire('Error', 'Request failed', 'error');
    } finally {
      setDeleteLoading(false)
    }
  };

  const handlepermission = async (order) => {

    try {

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/common/getPermissionforuser`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        }
      });

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return handlepermission()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json();

      if (response.status === 200) {
        const newarray = data.data
        const check = newarray.includes(138)
        setShowDelete(check)
      }

    } catch (error) {
      console.log(error)
    }
  };

  const handleSendInvoice = async (id) => {

    try {

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/invoice/sendinvoice`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          id: id,
        }),
      });

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return handleSendInvoice()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json();

      if (response.status === 200) {

      }

    } catch (error) {
      console.log(error)
    }
  };

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  All Invoices
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>Payment</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="paid">Paid</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="partially paid">Partially Paid</option>
                </Form.Select>
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>By</FormLabel>
                <Select
                  options={userOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchUser(value)
                      setSelectedUserName(value)
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      setByFilter(option.value) // 👈 user_id
                      setSelectedUserName(option.label)
                    } else {
                      setByFilter('')
                      setSelectedUserName('')
                    }
                  }}
                  placeholder="Search User"
                  isClearable
                  isSearchable
                  value={
                    selectedUserName
                      ? { label: selectedUserName, value: byFilter }
                      : null
                  }
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused
                        ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)'
                        : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-1">
                <FormLabel>Interface</FormLabel>
                <Form.Select value={posFilter} onChange={(e) => {
                  const value = e.target.value
                  setPosFilter(value)
                }}>
                  <option value="">All</option>
                  <option value="pos">POS</option>
                  <option value="back_office">Back Office</option>
                </Form.Select>
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button variant="primary" className="bg-primary border-primary flex-grow-1" onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>
            {isLoading ? (
              <p>Loading Orders...</p>
            ) : error ? (
              <p>Error Loading Orders.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <Table striped className="table mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th> 
                        <th>Date</th>
                        <th>Client</th>
                        {/* <td>Payment Method</td> */}
                        <th>Payment Status</th>
                        <th className="text-end">Total ({currency})</th>
                        <th className="text-end">By</th>

                        <th className="text-center no-print">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="text-center">
                            No Orders found.
                          </td>
                        </tr>
                      ) : (
                        orders.map((order) => (
                          <tr key={order.id}>
                            <td>
                              {order.id}{' '}
                              {order.interface === 'pos' && <Icon icon="mdi:network-pos" width={15} height={20} style={{ marginLeft: '4px' }} />}
                            </td>
                            <td>
                              {new Date(order.created_at).toLocaleString('en-LK', {
                                timeZone: 'Asia/Colombo',
                                year: 'numeric',
                                month: 'short',
                                day: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </td>
                            <td>
                              {order.customer_id ? `${order.customer_id} - ${order.customer_name}` : 'POS Client'}
                              <br />
                              <small>{order.contact_number}</small>
                            </td>

                            {/* <td>{order.payment_method_id ? order.method_name : order.payment_status == "unpaid" ? "-" :  'Mixed'}</td> */}

                            <td>
                              {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}

                              {hasSlip(order) && (
                                <div className="mt-1 no-print">
                                  <Button
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.2rem 0.1rem',
                                      fontSize: '0.55rem',
                                      height: '20px',
                                      borderRadius: '15px',
                                      backgroundColor: '#3d3642ff',
                                      borderColor: '#3d3642ff',
                                      color: '#fff',
                                    }}
                                    variant="outline-primary"
                                    onClick={() => openSlip(order)}
                                    title="Open bank slip"
                                    className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                    <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                    Slip
                                  </Button>
                                </div>
                              )}
                            </td>

                            <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>
                            <td className="text-end">
                              {order.user_id} - {order.user_name}
                            </td>

                            <td className="text-end no-print">

                              <div className="d-flex flex-row align-items-center justify-content-end gap-2">
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#5f5f5f',
                                    borderColor: '#5f5f5f',
                                    color: '#fff',
                                  }}
                                  onClick={() => handleView(order)}>
                                  <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>View</span>
                                </Button>
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#3d0a36ff',
                                    borderColor: '#3d0a36ff',
                                    color: '#fff',
                                  }}
                                  
                                  onClick={() => handleSendInvoice(order.id)}

                                >
                                  <Icon icon="mdi:send" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>Send</span>
                                </Button>
                                {showDelete && order.interface === 'pos' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#fc0000',
                                      borderColor: '#fc0000',
                                      color: '#fff',
                                    }}
                                    onClick={() => handleDelete(order)}
                                    disabled={deleteLoading}
                                  >
                                    <Icon icon="mdi:delete" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>Delete</span>
                                  </Button>
                                )}
                                {showDelete && order.interface === 'back_office' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#fc0000',
                                      borderColor: '#fc0000',
                                      color: '#fff',
                                    }}
                                    onClick={() => handlebackofficeDelete(order)}
                                    disabled={deleteLoading}
                                  >
                                    <Icon icon="mdi:delete" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>Delete</span>
                                  </Button>
                                )}
                                {order.payment_status === 'unpaid' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#fd7e14',
                                      borderColor: '#fd7e14',
                                      color: '#fff',
                                    }}
                                    onClick={() => router.push(`/update-invoice?invoice_id=${order.id}`)}>
                                    <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>Edit</span>
                                  </Button>
                                )}

                                {order.payment_status?.toLowerCase() === 'unpaid' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#dc3545',
                                      borderColor: '#dc3545',
                                      color: '#fff',
                                    }}
                                    onClick={() => {
                                      setCancelOrder(order)
                                      setShowCancelModal(true)
                                    }}>
                                    <Icon icon="mdi:close" width={18} className="me-1" />
                                    Cancel
                                  </Button>
                                )}

                                {['unpaid', 'partially paid', 'partially_paid'].includes(order.payment_status?.toLowerCase()) && (
                                  <>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#5dbbd3ff',
                                        borderColor: '#5dbbd3ff',
                                        color: '#fff',
                                      }}
                                      onClick={() => handlePayment(order)}>
                                      <Icon icon="mdi:plus-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Pay</span>
                                    </Button>
                                  </>
                                )}


                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>
                {/* ================= NEW PAGINATION ================= */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <ul className="pagination mb-0">
                      {(() => {
                        const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                        const pages = []

                        let start = safeCurrent - 2
                        let end = safeCurrent + 2

                        if (totalPages <= 5) {
                          start = 1
                          end = totalPages
                        } else {
                          if (start < 1) {
                            start = 1
                            end = 5
                          }
                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }
                        }

                        for (let i = start; i <= end; i++) {
                          pages.push(
                            <li key={i} className={`page-item ${i === safeCurrent ? 'active' : ''}`}>
                              <button className="page-link" onClick={() => setCurrentPage(i)}>
                                {i}
                              </button>
                            </li>,
                          )
                        }

                        return (
                          <>
                            {/* FIRST */}
                            <li className={`page-item ${safeCurrent === 1 ? 'disabled' : ''}`}>
                              <button className="page-link" onClick={() => setCurrentPage(1)}>
                                First
                              </button>
                            </li>

                            {/* PREV (<) */}
                            <li className={`page-item ${safeCurrent === 1 ? 'disabled' : ''}`}>
                              <button className="page-link" onClick={() => setCurrentPage(safeCurrent - 1)}>
                                {'<'}
                              </button>
                            </li>

                            {pages}

                            {/* NEXT (>) */}
                            <li className={`page-item ${safeCurrent === totalPages ? 'disabled' : ''}`}>
                              <button className="page-link" onClick={() => setCurrentPage(safeCurrent + 1)}>
                                {'>'}
                              </button>
                            </li>

                            {/* LAST */}
                            <li className={`page-item ${safeCurrent === totalPages ? 'disabled' : ''}`}>
                              <button className="page-link" onClick={() => setCurrentPage(totalPages)}>
                                Last
                              </button>
                            </li>
                          </>
                        )
                      })()}
                    </ul>
                  </div>
                )}
              </>
            )}
          </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <InvoiceModal
          show={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedOrder(null)
          }}
          order={selectedOrder}
          fetchLogs={fetchLogs}
        />
      )}
      {showPaymentModal && selectedOrderId && (
        <Paymentmodal
          show={showPaymentModal}
          onClose={() => {
            setShowPaymentModal(false)
            setSelectedOrderId(null)
          }}
          order={selectedOrderId} // 🔥 FULL ORDER OBJECT
          order_id={selectedOrderId.id} // optional (keep if modal expects it)
          storepickup={selectedOrderId.storepickup}
          payment_method_id={selectedOrderId.payment_method_id}
        />
      )}

      {/* {showUnpaidModal && selectedOrderId && (
        <UnpaidModal show={showUnpaidModal} onClose={() => setShowUnpaidModal(false)} order_id={selectedOrderId.order_id} />
      )} */}
      {/* <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      /> */}
      <CancelInvoiceModal
        show={showCancelModal}
        order={cancelOrder}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrder(null)
        }}
        onSuccess={() => {
          setShowCancelModal(false)
          setCancelOrder(null)
          fetchLogs(currentPage)
        }}
      />
    </Row>
  )
}

export default AllOrders