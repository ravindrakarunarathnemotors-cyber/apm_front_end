
import React from 'react';
import dynamic from 'next/dynamic';

export const metadata = {
  title: 'New Quatation',
}

const AddQuotation = dynamic(() => import('./AddQuotation'), { ssr: false })

const AddQuotationPage = () => {
  return (
    <div>
      <AddQuotation />
    </div>
  );
};

export default AddQuotationPage;
