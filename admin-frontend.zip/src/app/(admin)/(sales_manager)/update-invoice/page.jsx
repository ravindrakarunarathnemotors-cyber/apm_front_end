import React from 'react'
import dynamic from 'next/dynamic' 

export const metadata = {
  title: 'Update Invoice',
}

const UpdateInvoice = dynamic(() => import('@/components/Invoices/UpdateInvoice'), { ssr: false })

function UpdateInvoicePage({ searchParams }) {
  const order_id = searchParams?.invoice_id || null;
  return (
    <>
      <UpdateInvoice order_id={order_id} />
    </>
  )
}

export default UpdateInvoicePage