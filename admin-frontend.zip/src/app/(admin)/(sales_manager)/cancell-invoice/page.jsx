import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Cancelled Invoices',
}

const CancelInvoices = dynamic(() => import('./CancelInvoices'), { ssr: false })

export default function CancelInvoicesPage() {
  return <CancelInvoices />
}