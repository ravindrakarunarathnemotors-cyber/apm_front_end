'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
//import CancelInvoiceModal from './CancelInvoiceModal'

import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Badge } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import InvoiceModal from '../invoice/modal/InvoiceModal'

import Paymentmodal from '@/components/Order/InlineAddPayment'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'

import {
  useGetFilteredCancelledInvoiceOrdersMutation,
  useGetRecipientnameQuery,
} from '@/store/features/apiSlice'

function CancelInvoices() {

  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })

  const [orderStatuses, setOrderStatuses] = useState([])
  const [fetchFilteredOrders, { isLoading, error }] = useGetFilteredCancelledInvoiceOrdersMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [orders, setOrders] = useState([])
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const logsPerPage = limit
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [loading, setLoading] = useState(false)
  //const [showViewModal, setShowViewModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showEditModal, setShowEditModal] = useState(false)
  const [editOrderData, setEditOrderData] = useState(null)
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrder, setCancelOrder] = useState(null)

  const [currency, setCurrency] = useState('')
  const printSectionRef = useRef()
  const router = useRouter()

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderStatusOptions = [
    { label: 'Pending', value: 'pending' },
    { label: 'Confirmed', value: 'confirmed' },
    { label: 'Processing', value: 'processing' },
    { label: 'Dispatched', value: 'dispatched' },
    { label: 'Completed', value: 'completed' },
    { label: 'Cancelled', value: 'cancelled' },
    { label: 'Returned', value: 'returned' },
  ]
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  // const handleView = (order) => {
  //   setSelectedOrderId(order)
  //   setShowViewModal(true)
  // }

  const handlePayment = (order) => {
    setSelectedOrderId(order)
    setShowPaymentModal(true)
  }

  const handleUnpaidClick = (order_id) => {
    setSelectedOrderId(order_id)
    setShowUnpaidModal(true)
  }

  const handleUnpaidCloseModal = () => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
  }

  const fetchLogs = async (page) => {
    setLoading(true)
    try {

      const res = await fetchFilteredOrders({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        payment_status: paymentStatus,
        date: date,
        todate: todate,
        order_status: orderStatuses.map((s) => s.value),
      }).unwrap()

      setOrders(res.orders || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
      setCurrency(res.currency || res.orders?.[0]?.currency || '')
      setCurrency(res.orders?.[0]?.currency || '')
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch orders:', err)

    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage, limit])

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  const handleLimitChange = (e) => {
    const newLimit = Number(e.target.value)
    setLimit(newLimit)
    setCurrentPage(1)
  }

  const handleCancel1 = async (orderId) => {
    try {
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you really want to cancel order ${orderId}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'No, keep it',
      })

      if (!isConfirmed) return



      await cancelOrder({
        order_id: orderId,
        status: 'cancelled',
      }).unwrap()

      await Swal.fire('Cancelled', `Order ${orderId} was cancelled successfully.`, 'success')
      await fetchLogs(currentPage)
    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while cancelling the order.'
      await Swal.fire('Error', msg, 'error')
    }
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])

  const handleConfirmCancelFromModal = async (orderIdToCancel, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelOrder({
        order_id: orderIdToCancel,
        status: 'cancelled',
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh list
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await fetchLogs(currentPage)
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const [selectedOrder, setSelectedOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)

  const handleView = (order) => {
    setSelectedOrder(order)
    setShowViewModal(true)
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Cancelled Invoices
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-5">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-1">
                <Button variant="primary" className='flex-grow-1 bg-primary border-primary' onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>
            {isLoading ? (
              <p>Loading Orders...</p>
            ) : error ? (
              <p>Error Loading Orders.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <div className="table-responsive">
                    <Table striped className="table mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>Invoice ID</th>
                          <th>Date</th>
                          <th>Client</th>

                          <td>Payment Method</td>

                          <th>Payment Status</th>
                          <th className="text-end">Total ({currency})</th>

                          <th className="text-center no-print">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.length === 0 ? (
                          <tr>
                            <td colSpan="5" className="text-center">
                              No Orders found.
                            </td>
                          </tr>
                        ) : (
                          orders.map((order) => (
                            <tr key={order.id}>
                              <td>{order.id}</td>
                              <td>{new Date(order.created_at).toLocaleDateString()}</td>
                              <td>
                                {order.customer_name}
                                <br />
                                <small>{order.contact_number}</small>
                              </td>

                              <td>{order.method_name}</td>

                              <td>
                                {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}

                                {hasSlip(order) && (
                                  <div className="mt-1 no-print">
                                    <Button
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.2rem 0.1rem',
                                        fontSize: '0.55rem',
                                        height: '20px',
                                        borderRadius: '15px',
                                        backgroundColor: '#3d3642ff',
                                        borderColor: '#3d3642ff',
                                        color: '#fff',
                                      }}
                                      variant="outline-primary"
                                      onClick={() => openSlip(order)}
                                      title="Open bank slip"
                                      className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                      <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                      Slip
                                    </Button>
                                  </div>
                                )}
                              </td>

                              <td className="text-end">{order.full_amount}</td>

                              <td className="text-end no-print">
                                <div className="d-flex flex-row align-items-center justify-content-end gap-2">
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#007bff',
                                      borderColor: '#007bff',
                                      color: '#fff',
                                    }}
                                    onClick={() => handleView(order)}>
                                    <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>View</span>
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </Table>
                    </div>
                  </div>
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    totalEntries={totalEntries}
                    limit={limit}
                    onPageChange={(page) => {
                      setCurrentPage(page)
                    }}
                    onLimitChange={(val) => {
                      setLimit(val)
                      setCurrentPage(1)

                      // If you already have handleLimitChange:
                      handleLimitChange({
                        target: { value: val }
                      })
                    }}
                    showingFrom={
                      orders.length === 0
                        ? 0
                        : (currentPage - 1) * limit + 1
                    }
                    showingTo={
                      orders.length === 0
                        ? 0
                        : (currentPage - 1) * limit + orders.length
                    }
                  />
                </>
            )}
              </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <InvoiceModal
          show={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedOrder(null)
          }}
          order={selectedOrder}
          fetchLogs={fetchLogs}
        />
      )}
      {showPaymentModal && selectedOrderId && (
        <Paymentmodal
          show={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          order_id={selectedOrderId.id}
          storepickup={selectedOrderId.storepickup}
          payment_method_id={selectedOrderId.payment_method_id}
        />
      )}

      {showUnpaidModal && selectedOrderId && (
        <UnpaidModal show={showUnpaidModal} onClose={() => setShowUnpaidModal(false)} order_id={selectedOrderId.order_id} />
      )}

      {/* <CancelInvoiceModal
                show={showCancelModal}
                order={cancelOrder}
                onClose={() => {
                    setShowCancelModal(false)
                    setCancelOrder(null)
                }}
                onSuccess={() => {
                    setShowCancelModal(false)
                    setCancelOrder(null)
                    fetchLogs(currentPage)
                }}
            /> */}
    </Row>
  )
}

export default CancelInvoices
