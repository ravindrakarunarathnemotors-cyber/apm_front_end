import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Cancelled Order Invoices',
}

const CancelOrders = dynamic(() => import('./CancelOrders'), { ssr: false })

export default function CancelOrdersPage() {
  return <CancelOrders />
}