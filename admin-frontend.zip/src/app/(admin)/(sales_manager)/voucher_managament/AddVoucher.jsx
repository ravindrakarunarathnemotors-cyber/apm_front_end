'use client'

import React, { useEffect, useState } from 'react'
import { Card, Form, Button, Alert, Row, Col, ListGroup, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'

import VoucherHistory from './VoucherHistory'
import { useCheckVoucherRangeAvailabilityMutation, useCreateVoucherRangeFinalMutation, useGetVoucherStatsQuery } from '@/store/features/apiSlice'

export default function AddVoucher() {
  // Range
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [amount, setAmount] = useState('')

  // UI state
  const [rangeError, setRangeError] = useState('')
  const [checkedOnce, setCheckedOnce] = useState(false)

  // Availability
  const [usedVoucherIds, setUsedVoucherIds] = useState([])
  const [rangeAvailable, setRangeAvailable] = useState(false)
  const [skippedIds, setSkippedIds] = useState([])
  const [amountError, setAmountError] = useState('')
  // History
  const [history, setHistory] = useState([])

  // Creating UX
  const [creatingText, setCreatingText] = useState('Hang tight…')

  // RTK hooks
  const [checkAvailability, { isLoading: checkingAvailability }] = useCheckVoucherRangeAvailabilityMutation()

  const [createVoucherRangeFinal, { isLoading: creating }] = useCreateVoucherRangeFinalMutation()

  const { data: voucherStats, isLoading: statsLoading, isError: statsError } = useGetVoucherStatsQuery()

  /* ---------------- Live validation ---------------- */
  useEffect(() => {
    setCheckedOnce(false)
    setUsedVoucherIds([])
    setSkippedIds([])
    setRangeAvailable(false)

    if (!from || !to) {
      setRangeError('')
      return
    }

    if (Number(to) < Number(from)) {
      setRangeError('End number must be equal to or greater than start number')
      return
    }

    if (Number(to) === Number(from)) {
      setRangeError('From and To cannot be the same')
      return
    }
    if (Number(to) - Number(from) > 500) {
      setRangeError('Maximum voucher range is 500')
      return
    }

    setRangeError('')
  }, [from, to])

  /* ---------------- Creating text switch ---------------- */
  useEffect(() => {
    if (!creating) return

    const texts = ['Hang tight…', 'Creating vouchers…']
    let index = 0

    const interval = setInterval(() => {
      index = (index + 1) % texts.length
      setCreatingText(texts[index])
    }, 2000)

    return () => clearInterval(interval)
  }, [creating])

  /* ---------------- Availability ---------------- */
  const handleCheckAvailability = async () => {
    if (rangeError || !from || !to || !amount) return

    setCheckedOnce(true)
    setUsedVoucherIds([])
    setSkippedIds([])
    setRangeAvailable(false)

    try {
      const res = await checkAvailability({
        from: Number(from),
        to: Number(to),
      }).unwrap()

      if (res.status === 'USED_FOUND') {
        setUsedVoucherIds(res.usedVoucherIds || [])
      }

      if (res.status === 'AVAILABLE') {
        setRangeAvailable(true)
      }
    } catch (e) {
      setRangeError(e?.data?.message || 'Failed to check availability')
    }
  }

  /* ---------------- Skip ---------------- */
  const skipAllUsed = () => {
    setSkippedIds(usedVoucherIds)
    setUsedVoucherIds([])
    setRangeAvailable(true)
  }

  /* ---------------- Amount formatting ---------------- */
  const handleAmountBlur = () => {
    if (!amount) return
    const num = Number(amount)
    if (!isNaN(num)) {
      setAmount(num.toFixed(2))
    }
  }

  /* ---------------- Create ---------------- */
  const handleCreate = async () => {
    if (!amount) {
      setAmountError('Please enter the voucher amount')
      return
    }

    setAmountError('')

    const confirm = await Swal.fire({
      title: 'Confirm Voucher Creation',
      icon: 'question',
      html: `
        <div style="text-align:left">
          <p><b>Range:</b> ${from} - ${to}</p>
          <p><b>Amount:</b> ${Number(amount).toFixed(2)}</p>
          <p><b>Skipped IDs:</b> ${skippedIds.length}</p>
        </div>
      `,
      showCancelButton: true,
      confirmButtonText: 'Create',
    })

    if (!confirm.isConfirmed) return

    try {
      const res = await createVoucherRangeFinal({
        from: Number(from),
        to: Number(to),
        amount: Number(amount),
        skipIds: skippedIds,
      }).unwrap()
      if (res.status === 'SUCCESS') {
        const ids = res.insertedIds || []
        const showLimit = 10
        const isCollapsed = ids.length > showLimit

        const visibleIds = isCollapsed ? ids.slice(0, showLimit) : ids

        const htmlContent = `
  <div style="text-align:left; font-family:system-ui, sans-serif;">

    <div style="margin-bottom:12px;">
      <div style="font-size:14px; color:#6c757d;">Range</div>
      <div style="font-size:18px; font-weight:600;">${res.range}</div>
    </div>

    <div style="display:flex; gap:20px; margin-bottom:12px;">
      <div>
        <div style="font-size:13px; color:#6c757d;">Amount</div>
        <div style="font-weight:600;">${res.amount}</div>
      </div>

      <div>
        <div style="font-size:13px; color:#6c757d;">Inserted</div>
        <div style="font-weight:600; color:#198754;">${res.insertedCount}</div>
      </div>

      <div>
        <div style="font-size:13px; color:#6c757d;">Skipped</div>
        <div style="font-weight:600; color:#dc3545;">${res.skippedCount}</div>
      </div>
    </div>

    <div style="margin-top:14px;">
      <div style="font-size:14px; font-weight:600; margin-bottom:6px;">
        Voucher IDs
      </div>

      <div id="voucher-id-container"
        style="
          display:flex;
          flex-wrap:wrap;
          gap:6px;
          max-height:140px;
          overflow:auto;
          padding:8px;
          border-radius:8px;
          background:#f8f9fa;
        ">
        ${visibleIds
          .map(
            (id) => `
          <span style="
            font-size:12px;
            padding:4px 8px;
            background:#e7f1ff;
            color:#0d6efd;
            border-radius:20px;
            font-weight:500;
          ">
            ${id}
          </span>
        `,
          )
          .join('')}
      </div>

      ${
        isCollapsed
          ? `
          <div style="margin-top:10px; text-align:center;">
            <button id="toggle-ids"
              style="
                border:none;
                background:#0d6efd;
                color:white;
                padding:6px 14px;
                font-size:13px;
                border-radius:20px;
                cursor:pointer;
                box-shadow:0 2px 6px rgba(0,0,0,0.1);
              ">
              Show All (${ids.length})
            </button>
          </div>
        `
          : ''
      }
    </div>
  </div>
`
        Swal.fire({
          icon: 'success',
          title: 'Vouchers Created',
          html: htmlContent,
          width: 600,
          didOpen: () => {
            if (isCollapsed) {
              const btn = document.getElementById('toggle-ids')
              const container = document.getElementById('voucher-id-container')

              let expanded = false

              btn.addEventListener('click', () => {
                expanded = !expanded

                if (expanded) {
                  container.innerHTML = ids
                    .map(
                      (id) =>
                        `<span style="display:inline-block; margin:2px 6px; padding:2px 6px; background:#e9f7ef; border-radius:6px;">${id}</span>`,
                    )
                    .join('')
                  btn.innerText = 'Show Less'
                } else {
                  container.innerHTML = visibleIds
                    .map(
                      (id) =>
                        `<span style="display:inline-block; margin:2px 6px; padding:2px 6px; background:#e9f7ef; border-radius:6px;">${id}</span>`,
                    )
                    .join('')
                  btn.innerText = `Show All (${ids.length})`
                }
              })
            }
          },
        })
        resetForm()
      }
    } catch (e) {
      Swal.fire('Error', e?.data?.message || 'Creation failed', 'error')
    }
  }

  const resetForm = () => {
    setFrom('')
    setTo('')
    setAmount('')
    setSkippedIds([])
    setCheckedOnce(false)
    setUsedVoucherIds([])
    setRangeAvailable(false)
  }
  const nextVoucherNo = voucherStats?.max_voucher_id ? Number(voucherStats.max_voucher_id) + 1 : 1

  const totalInRange = from && to ? Number(to) - Number(from) : 0
  const allUsed = usedVoucherIds.length > 0 && usedVoucherIds.length === totalInRange

  useEffect(() => {
    if (nextVoucherNo && (from === '' || from === '1')) {
      setFrom(nextVoucherNo.toString())
    }
  }, [nextVoucherNo])

  return (
    <div className="container mt-4">
      <Card className="mb-4">
        <Card.Header className="py-3 bg-light">
          <Card.Title as="h4" className="mb-0">
            Create New Voucher Batch
          </Card.Title>
        </Card.Header>

        <Card.Body>
          <div className="">
            {/* INPUTS */}
            <Row className="d-flex g-1">
              <Col md={3}>
                <Form.Label>From</Form.Label>
                <div className="d-flex align-items-center">
                  <Form.Control type="number" value={from} onChange={(e) => setFrom(e.target.value)} />
                  <span className="mx-2">→</span>
                </div>
              </Col>
              <Col md={3} className="pe-3">
                <Form.Label>To</Form.Label>
                <Form.Control type="number" value={to} onChange={(e) => setTo(e.target.value)} />
              </Col>
              <Col md={3}>
                <Form.Label>Voucher Amount</Form.Label>
                {amountError && <div className="text-danger small mt-1">{amountError}</div>}
                <Form.Control
                  type="number"
                  value={amount}
                  placeholder="0.00"
                  onChange={(e) => {
                    setAmount(e.target.value)
                    if (amountError) setAmountError('')
                  }}
                  onBlur={handleAmountBlur}
                />
              </Col>
              <Col md={3} className="d-flex align-items-end">
                <Button className="w-100" disabled={checkedOnce || checkingAvailability || !!rangeError} onClick={handleCheckAvailability}>
                  Check Availability
                </Button>
              </Col>
            </Row>
            {rangeError && <div className="text-danger small ms-1">{rangeError}</div>}
          </div>

          {checkingAvailability && (
            <div className="text-center mt-2">
              <Spinner animation="border" />
              <div className="mt-2">Checking availability…</div>
            </div>
          )}

          {/* ALL USED MESSAGE */}
          {!checkingAvailability && allUsed && (
            <Alert variant="danger" className="mt-2">
              <div className="fs-5 fw-semibold">ID range already used.</div>
              <div className="fs-6">
                All voucher IDs from {from} to {to} already exist.
              </div>
            </Alert>
          )}

          {/* USED FOUND (PARTIAL) */}
          {!checkingAvailability && usedVoucherIds.length > 0 && !allUsed && (
            <>
              <Alert variant="warning" className="mt-4">
                <div className="fs-5 fw-semibold">{usedVoucherIds.length} voucher IDs already exist</div>
              </Alert>

              <Button variant="outline-danger" onClick={skipAllUsed}>
                Skip All Used
              </Button>
            </>
          )}

          {/* AVAILABLE */}
          {!checkingAvailability && rangeAvailable && !allUsed && (
            <>
              <Alert variant="success" className="mt-4">
                <div className="fs-5">
                  <strong>
                    Range {from} - {to}
                  </strong>{' '}
                  is available to create vouchers
                </div>
                <div className="d-flex justify-content-between">
                  <div>
                    <div className="mt-2 fs-6">
                      <span className="text-muted">Voucher Amount:</span> <strong>{Number(amount).toFixed(2)}</strong>
                    </div>
                    {skippedIds.length > 0 && <div className="mt-1 text-muted fs-6">Skipping voucher IDs: {skippedIds.join(', ')}</div>}
                  </div>
                  <div className="d-flex justify-content-end">
                    <Button variant="success" disabled={creating} onClick={handleCreate}>
                      {creating ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          {creatingText}
                        </>
                      ) : (
                        'Create Voucher Range'
                      )}
                    </Button>
                  </div>
                </div>
              </Alert>
            </>
          )}
        </Card.Body>

        <hr className="my-2 mx-3 opacity-25" />

        {/* NEXT VOUCHER NO – ALWAYS VISIBLE */}
        <Row className="mb-3 px-3">
          <Col md={4}>
            <Card className="border-primary">
              <Card.Body className="py-2">
                <div className="text-muted small">⬆ Next Voucher Starting No</div>
                {statsLoading ? (
                  <Spinner size="sm" />
                ) : statsError ? (
                  <div className="text-danger small">Failed to load</div>
                ) : (
                  <div className="fw-bold fs-4 text-success">{nextVoucherNo}</div>
                )}
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="border-primary">
              <Card.Body className="py-2">
                <div className="text-muted small">Generated Highest Voucher No</div>
                {statsLoading ? (
                  <Spinner size="sm" />
                ) : statsError ? (
                  <div className="text-danger small">Failed to load</div>
                ) : (
                  <div className="fw-bold fs-4 text-success">{voucherStats?.max_voucher_id ?? '—'}</div>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Card>

      <VoucherHistory history={history} />
    </div>
  )
}
