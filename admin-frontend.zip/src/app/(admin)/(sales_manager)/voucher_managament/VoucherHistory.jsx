'use client'

import React, { useState } from 'react'
import { Card, Form, Table, Row, Col, Spinner, Alert, Modal, Button } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useGetVoucherHistoryQuery, useGetVoucherStatsQuery, useUpdateVoucherStatusMutation } from '@/store/features/apiSlice'
import Pagination from '@/components/Pagination'

export default function VoucherHistory() {
  /* ---------------- UI filter inputs ---------------- */
  const [usage, setUsage] = useState('all')
  const [voucherId, setVoucherId] = useState('')
  const [voucherFrom, setVoucherFrom] = useState('')
  const [voucherTo, setVoucherTo] = useState('')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState('')
  const [page, setPage] = useState(1)
  const [hasSearched, setHasSearched] = useState(false)

  /* ---------------- Search trigger params ---------------- */
  const [searchParams, setSearchParams] = useState({
    page: 1,
    usage: 'all',
  })

  /* ---------------- Modal ---------------- */
  const [showModal, setShowModal] = useState(false)
  const [selectedUsedInv, setSelectedUsedInv] = useState([])
  const [selectedVoucherId, setSelectedVoucherId] = useState(null)
  const [updatingId, setUpdatingId] = useState(null)

  const [updateVoucherStatus, { isLoading: isUpdating }] = useUpdateVoucherStatusMutation()

  const handleToggleStatus = async (row) => {
    const nextStatus = row.status === 'active' ? 'inactive' : 'active'

    try {
      setUpdatingId(row.voucher_id)

      await updateVoucherStatus({
        id: row.voucher_id,
        status: nextStatus,
      }).unwrap()
    } catch (err) {
      console.error('Failed to update voucher status', err)
    } finally {
      setUpdatingId(null)
    }
  }

  /* ---------------- API ---------------- */
  const { data, isLoading, isFetching, isError, error } = useGetVoucherHistoryQuery(searchParams)

  const { data: voucherStats } = useGetVoucherStatsQuery()

  const currency = data?.currency || ''
  const rows = data?.data || []
  const pagination = data?.pagination
  const uniqueAmounts = data?.uniqueAmounts || []
  const currentPage = pagination?.page || 1
  const totalPages = pagination?.totalPages || 1
  const totalEntries = pagination?.total || 0
  const limit = pagination?.pageSize || 25

  /* ---------------- Search handler ---------------- */
  const handleSearch = () => {
    setPage(1)
    setHasSearched(true)

    setSearchParams({
      page: 1,
      usage,
      ...(voucherId && { voucher_id: voucherId }),
      ...(voucherFrom && voucherTo && { from: voucherFrom, to: voucherTo }),
      ...(amount && { amount_from: amount, amount_to: amount }),
      ...(date && { date_from: date, date_to: date }),
    })
  }

  /* ---------------- Reset handler ---------------- */
  const handleReset = () => {
    setUsage('all')
    setVoucherId('')
    setVoucherFrom('')
    setVoucherTo('')
    setAmount('')
    setDate('')
    setPage(1)
    setHasSearched(false)

    setSearchParams({
      page: 1,
      usage: 'all',
    })
  }

  /* ---------------- Pagination ---------------- */
  const changePage = (nextPage) => {
    setPage(nextPage)
    setSearchParams((prev) => ({
      ...prev,
      page: nextPage,
    }))
  }

  /* ---------------- Modal open ---------------- */
  const openUsedInvModal = (row) => {
    if (!row.used_inv_id || row.used_amount <= 0) return

    setSelectedVoucherId(row.voucher_id)
    setSelectedUsedInv(row.used_inv_id)
    setShowModal(true)
  }

  return (
    <>
      <Card>
        <Card.Header className="bg-light">
          <Card.Title as="h4" className="mb-0">
            Voucher History
          </Card.Title>
        </Card.Header>

        {/* ================= FILTERS ================= */}
        <Card.Body className="border-bottom">
          <Row className="g-2 align-items-end">
            <Col>
              <Form.Label>Usage</Form.Label>
              <Form.Select
                value={usage}
                onChange={(e) => {
                  setUsage(e.target.value)
                  setHasSearched(false)
                }}>
                <option value="all">All</option>
                <option value="used">Used</option>
                <option value="in-use">In Use</option>
                <option value="to-be-used">To Be Used</option>
              </Form.Select>
            </Col>
            <Col>
              <Form.Label className={voucherFrom || voucherTo ? 'text-muted' : ''}>Voucher ID</Form.Label>
              <Form.Control
                type="number"
                value={voucherId}
                disabled={!!voucherFrom || !!voucherTo}
                onChange={(e) => {
                  setVoucherId(e.target.value)
                  setHasSearched(false)
                }}
              />
            </Col>

            <Col>
              <Form.Label className={voucherId ? 'text-muted' : ''}>From</Form.Label>
              <Form.Control
                type="number"
                value={voucherFrom}
                disabled={!!voucherId}
                onChange={(e) => {
                  setVoucherFrom(e.target.value)
                  setHasSearched(false)
                }}
              />
            </Col>

            <Col>
              <Form.Label className={voucherId ? 'text-muted' : ''}>To</Form.Label>
              <Form.Control
                type="number"
                value={voucherTo}
                disabled={!!voucherId}
                onChange={(e) => {
                  setVoucherTo(e.target.value)
                  setHasSearched(false)
                }}
              />
            </Col>

            <Col>
              <Form.Label>Amount</Form.Label>
              <Form.Select
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value)
                  setHasSearched(false)
                }}>
                <option value="">All</option>
                {uniqueAmounts.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </Form.Select>
            </Col>

            <Col>
              <Form.Label>Date</Form.Label>
              <Form.Control
                type="date"
                value={date}
                onChange={(e) => {
                  setDate(e.target.value)
                  setHasSearched(false)
                }}
              />
            </Col>

            <Col>
              <Form.Label>&nbsp;</Form.Label>
              <Button
                className="w-100"
                onClick={hasSearched ? handleReset : handleSearch}
                disabled={isFetching}
                variant={hasSearched ? 'outline-secondary' : 'primary'}>
                {isFetching ? (
                  <>
                    <Spinner size="sm" className="me-2" />
                    Searching…
                  </>
                ) : hasSearched ? (
                  'Reset'
                ) : (
                  'Search'
                )}
              </Button>
            </Col>
          </Row>
        </Card.Body>

        {/* ================= TABLE ================= */}
        {isError && <Alert variant="danger">{error?.data?.message || 'Failed to load vouchers'}</Alert>}

        {!isLoading && !isFetching && rows.length === 0 && <div className="text-center text-muted my-4">No vouchers found</div>}

        {!isLoading && rows.length > 0 && (
          <Card.Body>
            <Table bordered hover responsive>
              <thead className="table-light">
                <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Created By</th>
                  <th className="text-center">Amount ({currency})</th>
                  <th className="text-center" style={{ width: '140px', whiteSpace: 'nowrap' }}>
                    Used Amount ({currency})
                  </th>

                  <th className="text-center" style={{ width: '220px', whiteSpace: 'nowrap' }}>
                    Actions
                  </th>
                </tr>
              </thead>

              <tbody>
                {rows.map((row) => (
                  <tr key={row.voucher_id}>
                    <td>{row.voucher_id}</td>
                    <td>{new Date(row.date).toLocaleString()}</td>
                    <td>
                      {row.first_name} {row.last_name} <span className="text-muted">(ID: {row.by})</span>
                    </td>

                    <td className="text-end">{Number(row.amount).toFixed(2)}</td>

                    {/* USED AMOUNT COLUMN (unchanged UI, minus View button) */}
                    <td className="text-end align-middle" style={{ width: '140px', whiteSpace: 'nowrap' }}>
                      {row.used_amount > 0 ? (
                        <span className="fw-semibold">{Number(row.used_amount).toFixed(2)}</span>
                      ) : (
                        <span className="text-muted d-block text-center">N/A</span>
                      )}
                    </td>

                    {/* ACTIONS COLUMN (View + Status toggle, same UI) */}
                    <td className="text-center align-middle" style={{ width: '220px', whiteSpace: 'nowrap' }}>
                      <div className="d-inline-flex align-items-center gap-3">
                        {/* SAME View button, same conditions */}
                        <Button
                          size="sm"
                          variant={row.used_inv_id && row.used_amount > 0 ? 'outline-success' : 'outline-secondary'}
                          disabled={!row.used_inv_id || row.used_amount <= 0}
                          onClick={() => openUsedInvModal(row)}>
                          <Icon icon="mdi:eye-outline" className="me-1" />
                          View
                        </Button>

                        {/* Status toggle (unchanged) */}
                        {row.status != 'used' && (
                          <Form.Check
                            type="switch"
                            id={`voucher-status-${row.voucher_id}`}
                            checked={row.status === 'active'}
                            disabled={isUpdating && updatingId === row.voucher_id}
                            onChange={() => handleToggleStatus(row)}
                            className="mb-0"
                          />
                        )}

                        {isUpdating && updatingId === row.voucher_id ? (
                          <Spinner size="sm" />
                        ) : (
                          <span
                            className={`small fw-semibold ${row.status === 'active' ? 'text-success' : row.status === 'used' ? 'text-danger' : 'text-muted'}`}>
                            {row.status === 'active' ? 'Active' : row.status === 'used' ? 'Used' : 'Inactive'}
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>

            {pagination?.totalPages > 1 && (
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalEntries={totalEntries}
                limit={limit}

                onPageChange={(newPage) => {
                  changePage(newPage)
                }}

                onLimitChange={(val) => {
                  setSearchParams((prev) => ({
                    ...prev,
                    page: 1,
                    pageSize: val, // important: match backend naming if needed
                  }))
                }}

                showingFrom={
                  rows.length === 0
                    ? 0
                    : (currentPage - 1) * limit + 1
                }

                showingTo={
                  rows.length === 0
                    ? 0
                    : (currentPage - 1) * limit + rows.length
                }
              />
            )}
          </Card.Body>
        )}
        {/* ================= STATS ================= */}
        <Card.Body className="border-bottom">
          <div className="fw-semibold mb-3">Voucher Stats</div>
          <hr></hr>
          <Row className="g-3">
            {[
              {
                label: 'Max Used Voucher Limit',
                value: voucherStats?.max_voucher_id,
                border: 'primary',
              },
              {
                label: 'Total Vouchers',
                value: voucherStats?.total_voucher_count,
                border: 'secondary',
              },
              {
                label: 'In Use',
                value: voucherStats?.in_use_count,
                border: 'warning',
                text: 'text-warning',
              },
              {
                label: 'To Be Used',
                value: voucherStats?.to_be_used_count,
                border: 'info',
                text: 'text-info',
              },
              {
                label: 'Fully Used',
                value: voucherStats?.used_count,
                border: 'success',
                text: 'text-success',
              },
            ].map((stat, i) => (
              <Col md={i === 0 || i === 1 ? 3 : 2} key={stat.label}>
                <Card
                  className={`border-${stat.border} h-100`}
                  style={{
                    transition: 'all 0.2s ease-in-out',
                    cursor: 'default',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-4px)'
                    e.currentTarget.style.boxShadow = '0 0.5rem 1rem rgba(0,0,0,0.15)'
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)'
                    e.currentTarget.style.boxShadow = 'none'
                  }}>
                  <Card.Body className="py-2">
                    <div className="text-muted small">{stat.label}</div>
                    <div className={`fw-semibold fs-5 ${stat.text ?? ''}`}>{stat.value ?? '—'}</div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Card.Body>
      </Card>

      {/* ================= MODAL ================= */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Used Voucher Details – Voucher #{selectedVoucherId}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Table bordered size="sm" hover className="mb-0" style={{ borderRadius: '8px', overflow: 'hidden' }}>
            <thead
              className="bg-light"
              style={{
                backgroundColor: '#f1f3f5', // slightly darker than default
              }}>
              <tr>
                <th className="fw-semibold text-muted">Invoice ID</th>
                <th className="fw-semibold text-end text-muted">Amount ({currency})</th>
              </tr>
            </thead>

            <tbody>
              {selectedUsedInv.map((inv, i) => (
                <tr key={i}>
                  <td className="align-middle">
                    <span className="fw-semibold">{inv.id}</span>
                  </td>
                  <td className="text-end align-middle">
                    <span className="fw-semibold">{Number(inv.amount).toFixed(2)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
      </Modal>
    </>
  )
}
