import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Vouchers',
}

// Dynamically import the client component
const AddVoucherComponent = dynamic(() => import('./AddVoucher'), {
  ssr: false,
})

export default function Page() {
  return <AddVoucherComponent />
}
