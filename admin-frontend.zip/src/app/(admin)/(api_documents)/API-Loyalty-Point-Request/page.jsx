import dynamic from 'next/dynamic'

export const metadata = {
  title: 'API Loyalty Point Request - API Documents',
}

const ApiLoyaltyPointRequest = dynamic(
  () => import('./ApiLoyaltyPointRequest'),
  { ssr: false }
)

export default function Page() {
  return <ApiLoyaltyPointRequest />
}