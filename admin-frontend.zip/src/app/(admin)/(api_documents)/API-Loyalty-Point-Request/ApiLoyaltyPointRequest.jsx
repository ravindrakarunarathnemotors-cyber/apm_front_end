'use client'

import React, { useState } from 'react'
import { Card, CardHeader, CardTitle, CardBody, Row, Col, Badge } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

// ── FIX: Static imports so jspdf-autotable properly patches jsPDF prototype ──
import html2pdf from 'html2pdf.js'
// ─────────────────────────────────────────────────────────────────────────────

import {
  useToggleApiStatusMutation,
  useRegenerateApiKeyMutation,
  useUpdateClientIdMutation,
  useGetApiDetailsQuery,
} from '@/store/features/apidocumentsSlice'

const baseURL = process.env.NEXT_PUBLIC_BASE_URL

// ─── Helpers ──────────────────────────────────────────────────────────────────
function SectionHeading({ icon, title, badge }) {
  return (
    <div className="d-flex align-items-center gap-2 mb-3" style={{ borderBottom: '1.5px solid #e9ecef', paddingBottom: '10px' }}>
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: '8px',
          background: 'rgba(var(--bs-primary-rgb), 0.10)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}>
        <Icon icon={icon} width={17} style={{ color: 'var(--bs-primary)' }} />
      </div>
      <span style={{ fontWeight: 700, fontSize: '0.88rem', color: '#111827' }}>{title}</span>
      {badge !== undefined && badge > 0 && (
        <Badge bg="primary" style={{ fontSize: '0.68rem', borderRadius: '20px', marginLeft: 2 }}>
          {badge}
        </Badge>
      )}
    </div>
  )
}

// ─── Code Tab Component ───────────────────────────────────────────────────────
const TABS = ['JS-Fetch', 'JS-Axios', 'PHP', 'Python', 'cURL']

function CodeSample({ clientId, apiKey }) {
  const [activeTab, setActiveTab] = useState('JS-Fetch')

  const samples = {
    'JS-Fetch': `const response = await fetch('${baseURL}/apidocuments/loyalty', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    client_id:     '${clientId}',
    api_key:       '${apiKey}',
    action:        '1',
    email:         'jonathon@gmail.com',
    mobile_number: '94771234567',
    order_id:      'ORD-1001',
    order_value:   250000,  
  })
});
const data = await response.json();
console.log(data.code);         // 201
console.log(data.points_added); // 2500
console.log(data.total_points); // 7350`,

    'JS-Axios': `import axios from 'axios';

const { data } = await axios.post(
  '${baseURL}/apidocuments/loyalty',
  {
    client_id:     '${clientId}',
    api_key:       '${apiKey}',
    action:        '1',
    email:         'jonathon@gmail.com',
    mobile_number: '94771234567',
    order_id:      'ORD-1001',
    order_value:   250000,
  }
);
console.log(data.code);         // 201
console.log(data.points_added); // 2500
console.log(data.total_points); // 7350`,

    PHP: `<?php
$curl = curl_init();
curl_setopt_array($curl, [
  CURLOPT_URL            => '${baseURL}/apidocuments/loyalty',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST  => 'POST',
  CURLOPT_POSTFIELDS     => json_encode([
    'client_id'     => '${clientId}',
    'api_key'       => '${apiKey}',
    'action'        => '1',
    'email'         => 'jonathon@gmail.com',
    'mobile_number' => '94771234567',
    'order_id'      => 'ORD-1001',
    'order_value'   => 250000,
  ]),
  CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
]);
$response = curl_exec($curl);
$data = json_decode($response, true);
echo $data['code'];          // 201
echo $data['points_added'];  // 2500
echo $data['total_points'];  // 7350`,

    Python: `import requests

response = requests.post(
    '${baseURL}/apidocuments/loyalty',
    json={
        'client_id':     '${clientId}',
        'api_key':       '${apiKey}',
        'action':        '1',
        'email':         'jonathon@gmail.com',
        'mobile_number': '94771234567',
        'order_id':      'ORD-1001',
        'order_value':   250000,
    }
)
data = response.json()
print(data['code'])          # 201
print(data['points_added'])  # 2500
print(data['total_points'])  # 7350`,

    cURL: `curl -X POST ${baseURL}/apidocuments/loyalty \\
  -H "Content-Type: application/json" \\
  -d '{
    "client_id":     "${clientId}",
    "api_key":       "${apiKey}",
    "action":        "1",
    "email":         "jonathon@gmail.com",
    "mobile_number": "94771234567",
    "order_id":      "ORD-1001",
    "order_value":   250000
  }'`,
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(samples[activeTab])
    Swal.fire({ icon: 'success', title: 'Copied!', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
  }

  return (
    <div style={{ border: '1px solid #e9ecef', borderRadius: 10, overflow: 'hidden' }}>
      <div
        className="d-flex align-items-center justify-content-between"
        style={{ borderBottom: '1px solid #e9ecef', background: '#f8f9fa', overflowX: 'auto' }}>
        <div className="d-flex" style={{ overflowX: 'auto' }}>
          {TABS.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              style={{
                padding: '8px 14px',
                fontSize: '0.75rem',
                fontWeight: 600,
                cursor: 'pointer',
                border: 'none',
                background: 'none',
                color: activeTab === tab ? 'var(--bs-primary)' : '#6b7280',
                borderBottom: activeTab === tab ? '2px solid var(--bs-primary)' : '2px solid transparent',
                whiteSpace: 'nowrap',
                transition: 'all 0.15s',
              }}>
              {tab}
            </button>
          ))}
        </div>
        <button
          onClick={handleCopy}
          title="Copy code"
          style={{
            border: 'none',
            background: 'none',
            cursor: 'pointer',
            padding: '6px 14px',
            color: '#6b7280',
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            fontSize: '0.75rem',
            flexShrink: 0,
          }}>
          <Icon icon="mdi:content-copy" width={15} />
          Copy
        </button>
      </div>
      <div style={{ background: '#1e1e2e', padding: '18px 20px', overflowX: 'auto' }}>
        <pre
          style={{
            margin: 0,
            fontFamily: "'SFMono-Regular', Consolas, monospace",
            fontSize: '0.77rem',
            lineHeight: 1.65,
            color: '#cdd6f4',
            whiteSpace: 'pre',
          }}>
          {samples[activeTab]}
        </pre>
      </div>
    </div>
  )
}

// ─── Status Code List ─────────────────────────────────────────────────────────
const STATUS_CODES = [
  { code: 200, type: 'success', label: 'OK', description: 'Request was successful. Also returned for CHECK and BALANCE actions.' },
  { code: 201, type: 'success', label: 'Points Awarded', description: 'Loyalty points awarded successfully for the completed order.' },
  { code: 202, type: 'success', label: 'Points Redeemed', description: 'Loyalty points redeemed successfully and applied to the order discount.' },
  { code: 203, type: 'success', label: 'Points Reversed', description: 'Loyalty points reversed successfully for a cancelled or returned order.' },
  { code: 400, type: 'error', label: 'Bad Request', description: 'Missing or invalid parameters in the request body.' },
  { code: 401, type: 'error', label: 'Unauthorized', description: 'Invalid client_id or api_key. Authentication failed.' },
  { code: 403, type: 'error', label: 'Forbidden', description: 'API access is not activated for this account. Contact admin.' },
  { code: 404, type: 'error', label: 'Not Found', description: 'Endpoint not found or customer account does not exist.' },
  { code: 500, type: 'error', label: 'Server Error', description: 'Internal server error. Please try again later.' },
  { code: 210, type: 'warning', label: 'Invalid Order Value', description: 'Order value must be a positive number greater than 0.' },
  { code: 211, type: 'warning', label: 'Duplicate Order', description: 'Loyalty points have already been awarded for this order_id.' },
  { code: 212, type: 'warning', label: 'Insufficient Points', description: 'Customer does not have enough loyalty points to redeem.' },
  { code: 213, type: 'warning', label: 'Points Expired', description: 'Customer loyalty points have expired and cannot be redeemed.' },
  { code: 214, type: 'warning', label: 'Mobile Required', description: 'Customer mobile number is required and cannot be empty.' },
  { code: 215, type: 'warning', label: 'Invalid Mobile', description: 'Customer mobile number format is invalid.' },
  { code: 216, type: 'warning', label: 'Email Required', description: 'Customer email address is required and cannot be empty.' },
  { code: 217, type: 'warning', label: 'Invalid Email', description: 'Customer email address format is invalid.' },
  { code: 218, type: 'warning', label: 'Name Required', description: 'Customer name is required for first-time loyalty account registration.' },
  { code: 219, type: 'warning', label: 'Redemption Limit', description: 'Redemption amount exceeds the maximum points allowed per transaction.' },
  { code: 220, type: 'warning', label: 'Minimum Order Value', description: 'Order value does not meet the minimum required to earn loyalty points.' },
  {
    code: 221,
    type: 'warning',
    label: 'Account Suspended',
    description: 'Customer loyalty account is suspended. Points cannot be awarded or redeemed.',
  },
  {
    code: 223,
    type: 'warning',
    label: 'Non-Reversible Order',
    description: 'Loyalty points for this order are not eligible for reversal or have already been reversed.',
  },
]

const STATUS_BADGE_STYLES = {
  success: { background: '#d1fae5', color: '#065f46' },
  warning: { background: '#fef3c7', color: '#92400e' },
  error: { background: '#fee2e2', color: '#991b1b' },
}

const formatParameters = (paramStr, actionType) => {
  if (!paramStr) return null

  const params = paramStr.split(',')

  // 🔥 Dynamic action number mapping
  const getActionNo = () => {
    if (actionType === 'AWARD') return 1
    if (actionType === 'REDEEM') return 2
    if (actionType === 'CHECK / BALANCE') return 3
    return ''
  }

  const sampleMap = {
    api_key: 'YOUR_API_KEY',
    client_id: 'YOUR_CLIENT_ID',
    order_id: 'ORD-1001',
    order_value: '2500.00',
    redeem_points: '200.00',
    mobile_number: '94771234567',
    email: 'customer@example.com',
    action: getActionNo(), // ✅ dynamic here
  }

  return params.map((p, index) => {
    const clean = p.trim().replace('or ', '').replace(',or', '')

    return (
      <div key={index} style={{ marginBottom: 2 }}>
        <span style={{ fontWeight: 600, fontSize: 13 }}>{clean}</span>
        {sampleMap[clean] && <span style={{ color: '#6b7280' }}> : {sampleMap[clean]}</span>}
      </div>
    )
  })
}

const htmlformatParameters = (paramStr, actionType) => {
  if (!paramStr) return ''

  const params = paramStr.split(',')

  const getActionNo = () => {
    if (actionType === 'AWARD') return 1
    if (actionType === 'REDEEM') return 2
    if (actionType === 'CHECK / BALANCE') return 3
    return ''
  }

  const sampleMap = {
    api_key: 'YOUR_API_KEY',
    client_id: 'YOUR_CLIENT_ID',
    order_id: 'ORD-1001',
    order_value: '2500.00',
    redeem_points: '200.00',
    mobile_number: '94771234567',
    email: 'customer@example.com',
    action: getActionNo(),
  }

  return params
    .map((p) => {
      const clean = p.trim().replace('or ', '').replace(',or', '')

      return `
        <div style="margin-bottom:2px;">
          <span style="font-weight:600;font-size:11px;">${clean}</span>
          ${
            sampleMap[clean]
              ? `<span style="color:#6b7280;"> : ${sampleMap[clean]}</span>`
              : ''
          }
        </div>
      `
    })
    .join('')
}

// ─── Action List ──────────────────────────────────────────────────────────────
const ACTIONS = [
  {
    action: 'AWARD',
    badgeStyle: { background: '#d1fae5', color: '#065f46' },
    label: 'Order completed',
    description: 'Customer finishes a purchase. Points calculated from order_value (optional) and added to their balance.',
    parameters: 'api_key, client_id, order_id, order_value, mobile_number ,or, email, action',
    successCodes: [{ code: 201, label: 'Points Awarded', type: 'success' }],
    errorCodes: [
      { code: 401, label: 'Unauthorized', type: 'error' },
      { code: 403, label: 'Forbidden', type: 'error' },
      { code: 210, label: 'Invalid Order Value', type: 'warning' },
      { code: 211, label: 'Duplicate Order', type: 'warning' },
      { code: 214, label: 'Mobile Required', type: 'warning' },
      { code: 216, label: 'Email Required', type: 'warning' },
      { code: 218, label: 'Name Required', type: 'warning' },
      { code: 220, label: 'Minimum Order Value', type: 'warning' },
    ],
  },
  {
    action: 'REDEEM',
    badgeStyle: { background: '#dbeafe', color: '#1e40af' },
    label: 'Customer uses points',
    description: 'Apply loyalty points as a discount at checkout. Pass redeem_points to deduct from balance.',
    parameters: 'api_key, client_id, order_id, redeem_points, mobile_number ,or, email, action',
    successCodes: [{ code: 202, label: 'Points Redeemed', type: 'success' }],
    errorCodes: [
      { code: 401, label: 'Unauthorized', type: 'error' },
      { code: 403, label: 'Forbidden', type: 'error' },
      { code: 210, label: 'Invalid Value', type: 'warning' },
      { code: 212, label: 'Insufficient Points', type: 'warning' },
      { code: 213, label: 'Points Expired', type: 'warning' },
      { code: 219, label: 'Redemption Limit', type: 'warning' },
      { code: 221, label: 'Account Suspended', type: 'warning' },
    ],
  },
  // {
  //   action: 'REVERSE',
  //   badgeStyle: { background: '#fef3c7', color: '#92400e' },
  //   label: 'Order cancelled / returned',
  //   description: 'Roll back previously awarded points when an order is cancelled or refunded. Pass the original order_id and order_value.',
  //   successCodes: [{ code: 203, label: 'Points Reversed', type: 'success' }],
  //   errorCodes: [
  //     { code: 401, label: 'Unauthorized', type: 'error' },
  //     { code: 403, label: 'Forbidden', type: 'error' },
  //     { code: 210, label: 'Invalid Order Value', type: 'warning' },
  //     { code: 223, label: 'Non-Reversible Order', type: 'warning' },
  //   ],
  // },
  {
    action: 'CHECK / BALANCE',
    badgeStyle: { background: '#f3f4f6', color: '#374151' },
    label: 'Verify customer & check balance',
    description:
      'Use CHECK to confirm a loyalty account exists and retrieve full customer data with current balance. Use BALANCE to fetch only the point balance without full customer details.',
    parameters: 'api_key, client_id, mobile_number ,or, email, action',
    successCodes: [{ code: 200, label: 'OK', type: 'success' }],
    errorCodes: [
      { code: 401, label: 'Unauthorized', type: 'error' },
      { code: 403, label: 'Forbidden', type: 'error' },
      { code: 214, label: 'Mobile Required', type: 'warning' },
      { code: 215, label: 'Invalid Mobile', type: 'warning' },
      { code: 216, label: 'Email Required', type: 'warning' },
      { code: 217, label: 'Invalid Email', type: 'warning' },
      { code: 218, label: 'Name Required', type: 'warning' },
      { code: 221, label: 'Account Suspended', type: 'warning' },
    ],
  },
]

// ─── Code Samples HTML Generator ─────────────────────────────────────────────
const generateCodeHTML = (clientId, apiKey) => {
  const maskedClientId = 'xxxxx'
  const maskedApiKey = 'xxxxx'

  const samples = [
    {
      lang: 'JavaScript — Fetch',
      icon: 'JS',
      code: `fetch('${baseURL}/apidocuments/loyalty', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id:   '${maskedClientId}',   // replace with your Client ID
          api_key:     '${maskedApiKey}',     // replace with your API Key
          mobile_number : '94XXXXXXXXX',
          email : 'sample@gmail.com'
          action:      '1',
          order_id:    'ORD-1001',
          order_value: 250000
        })
      })
      .then(r => r.json())
      .then(data => {
        console.log(data.code)          // 201
        console.log(data.points_added)  // 2500
        console.log(data.total_points)  // 7350
      })`,
    },
    {
      lang: 'JavaScript — Axios',
      icon: 'AX',
      code: `import axios from 'axios';

      const { data } = await axios.post('${baseURL}/apidocuments/loyalty', {
        client_id:   '${maskedClientId}',   // replace with your Client ID
        api_key:     '${maskedApiKey}',     // replace with your API Key
        mobile_number : '94XXXXXXXXX',
        email : 'sample@gmail.com'
        action:      '1',
        order_id:    'ORD-1001',
        order_value: 250000
      });

      console.log(data.code)          // 201
      console.log(data.points_added)  // 2500
      console.log(data.total_points)  // 7350`,
    },
    {
      lang: 'PHP — cURL',
      icon: 'PHP',
      code: `<?php
      $curl = curl_init();
      curl_setopt_array($curl, [
        CURLOPT_URL            => '${baseURL}/apidocuments/loyalty',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'POST',
        CURLOPT_POSTFIELDS     => json_encode([
          'client_id'   => '${maskedClientId}',   // replace with your Client ID
          'api_key'     => '${maskedApiKey}',     // replace with your API Key
          'mobile_number' : '94XXXXXXXXX',
          'email' : 'sample@gmail.com'
          'action'      => '1',
          'order_id'    => 'ORD-1001',
          'order_value' => 250000,
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
      ]);
      $data = json_decode(curl_exec($curl), true);
      echo $data['code'];          // 201
      echo $data['points_added'];  // 2500
      echo $data['total_points'];  // 7350`,
    },
    {
      lang: 'Python — requests',
      icon: 'PY',
      code: `import requests

      response = requests.post(
          '${baseURL}/apidocuments/loyalty',
          json={
              'client_id':   '${maskedClientId}',   # replace with your Client ID
              'api_key':     '${maskedApiKey}',     # replace with your API Key
              'mobile_number': '94XXXXXXXXX',
              'email': 'sample@gmail.com',
              'action':      '1',
              'order_id':    'ORD-1001',
              'order_value': 250000,
          }
      )
      data = response.json()
      print(data['code'])          # 201
      print(data['points_added'])  # 2500
      print(data['total_points'])  # 7350`,
    },
    {
      lang: 'cURL',
      icon: 'cURL',
      code: `curl -X POST ${baseURL}/apidocuments/loyalty \\
      -H "Content-Type: application/json" \\
      -d '{
        "client_id":   "${maskedClientId}",
        "api_key":     "${maskedApiKey}",
        "mobile_number": "94XXXXXXXXX",
        "email": "sample@gmail.com",
        "action":      "1",
        "order_id":    "ORD-1001",
        "order_value": 250000
      }'`,
    },
  ]

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Loyalty API — Code Samples (AWARD ACTION)</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background: #f1f5f9;
      color: #1e293b;
      min-height: 100vh;
      padding: 0 0 60px 0;
    }

    /* ── Top bar ── */
    .topbar {
      background: #0f172a;
      color: #fff;
      padding: 20px 32px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      flex-wrap: wrap;
    }
    .topbar-left h1 { font-size: 16px; font-weight: 800; margin-bottom: 3px; }
    .topbar-left p  { font-size: 11px; color: #94a3b8; line-height: 1.5; }
    .topbar-meta { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .topbar-meta span {
      background: #1e293b; color: #94a3b8;
      border-radius: 4px; padding: 3px 10px;
      font-size: 10px; font-weight: 700; font-family: monospace;
    }
    .topbar-meta span.highlight { background: #334155; color: #e2e8f0; }

    /* ── Notice banner ── */
    .notice {
      background: #fefce8;
      border-left: 4px solid #ca8a04;
      padding: 12px 32px;
      font-size: 11.5px;
      color: #713f12;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .notice strong { font-weight: 700; }
    .notice code {
      background: #fef9c3;
      border: 1px solid #fde047;
      border-radius: 3px;
      padding: 1px 6px;
      font-family: monospace;
      font-size: 11px;
      font-weight: 700;
    }

    /* ── Tab bar ── */
    .tab-bar {
      background: #fff;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      overflow-x: auto;
      padding: 0 28px;
      gap: 2px;
      position: sticky;
      top: 0;
      z-index: 10;
      box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    }
    .tab-btn {
      padding: 12px 18px;
      font-size: 12px;
      font-weight: 600;
      border: none;
      background: none;
      color: #64748b;
      cursor: pointer;
      border-bottom: 2.5px solid transparent;
      white-space: nowrap;
      transition: all 0.15s;
      display: flex;
      align-items: center;
      gap: 7px;
    }
    .tab-btn:hover { color: #1e293b; }
    .tab-btn.active {
      color: #0f172a;
      border-bottom-color: #0f172a;
    }
    .tab-icon {
      background: #e2e8f0;
      color: #475569;
      font-size: 9px;
      font-weight: 800;
      font-family: monospace;
      border-radius: 3px;
      padding: 1px 5px;
    }
    .tab-btn.active .tab-icon { background: #0f172a; color: #fff; }

    /* ── Content panels ── */
    .content { padding: 28px 32px; max-width: 900px; margin: 0 auto; }

    .panel { display: none; }
    .panel.active { display: block; }

    .panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 14px;
      flex-wrap: wrap;
      gap: 10px;
    }
    .panel-title {
      font-size: 14px;
      font-weight: 700;
      color: #0f172a;
    }
    .panel-subtitle {
      font-size: 11px;
      color: #64748b;
      margin-top: 2px;
    }

    /* ── Copy button ── */
    .copy-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #1e293b;
      color: #e2e8f0;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      flex-shrink: 0;
    }
    .copy-btn:hover { background: #334155; }
    .copy-btn.copied { background: #14532d; color: #bbf7d0; }

    /* ── Code card ── */
    .code-card {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .code-card-header {
      background: #1e293b;
      padding: 10px 18px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .code-card-lang {
      font-family: monospace;
      font-size: 10.5px;
      font-weight: 700;
      color: #94a3b8;
      text-transform: uppercase;
      letter-spacing: 0.07em;
    }
    .code-copy-btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: #334155;
      color: #cbd5e1;
      border: none;
      border-radius: 4px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
    }
    .code-copy-btn:hover { background: #475569; color: #fff; }
    .code-copy-btn.copied { background: #14532d; color: #bbf7d0; }

    pre.code {
      background: #0f172a;
      color: #e2e8f0;
      font-family: 'Courier New', Consolas, monospace;
      font-size: 12.5px;
      line-height: 1.7;
      padding: 22px 24px;
      overflow-x: auto;
      margin: 0;
      white-space: pre;
    }

    /* ── Response reference ── */
    .ref-title {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      color: #94a3b8;
      margin: 24px 0 10px 0;
    }
    .ref-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11.5px;
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      overflow: hidden;
    }
    .ref-table thead tr { background: #0f172a; color: #fff; }
    .ref-table thead th { padding: 9px 14px; text-align: left; font-weight: 700; font-size: 11px; }
    .ref-table tbody tr:nth-child(even) { background: #f8fafc; }
    .ref-table tbody td { padding: 8px 14px; border-bottom: 1px solid #f1f5f9; color: #374151; }
    .ref-table tbody tr:last-child td { border-bottom: none; }
    .ref-table code {
      font-family: monospace; font-size: 11px;
      background: #f1f5f9; color: #0f172a;
      padding: 1px 5px; border-radius: 3px;
    }

    /* ── Toast ── */
    .toast {
      position: fixed; bottom: 24px; right: 24px;
      background: #0f172a; color: #e2e8f0;
      padding: 10px 18px; border-radius: 6px;
      font-size: 12px; font-weight: 600;
      opacity: 0; transform: translateY(8px);
      transition: all 0.2s; pointer-events: none;
      display: flex; align-items: center; gap: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .toast.show { opacity: 1; transform: translateY(0); }

    /* ── Footer ── */
    .footer {
      text-align: center;
      font-size: 10.5px;
      color: #94a3b8;
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
    }
  </style>
</head>
<body>

  <!-- Top bar -->
  <div class="topbar">
    <div class="topbar-left">
      <h1>Loyalty Points API — Code Samples - (AWARD ACTION)</h1>
      <p>Select a language tab, copy the snippet, and replace the placeholders with your credentials.</p>
      <div class="topbar-meta">
        <span class="highlight">POST</span>
        <span>${baseURL}/apidocuments/loyalty</span>
        <span>JSON</span>
        <span>v1.0</span>
      </div>
    </div>
  </div>

  <!-- Notice -->
  <div class="notice">
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ca8a04" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <span>Replace <code>xxxxx</code> in <code>client_id</code> and <code>api_key</code> with your actual credentials from your dashboard before using.</span>
  </div>

  <!-- Tab bar -->
  <div class="tab-bar">
    ${samples
      .map(
        (s, i) => `
      <button class="tab-btn ${i === 0 ? 'active' : ''}" onclick="switchTab(${i})" id="tab-${i}">
        <span class="tab-icon">${s.icon}</span>
        ${s.lang}
      </button>
    `,
      )
      .join('')}
  </div>

  <!-- Panels -->
  <div class="content">
    ${samples
      .map(
        (s, i) => `
      <div class="panel ${i === 0 ? 'active' : ''}" id="panel-${i}">

        <div class="panel-header">
          <div>
            <div class="panel-title">${s.lang}</div>
            <div class="panel-subtitle">Copy the snippet below and paste it into your project.</div>
          </div>
          <button class="copy-btn" id="main-copy-${i}" onclick="copyCode(${i}, 'main-copy-${i}')">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            Copy Code
          </button>
        </div>

        <div class="code-card">
          <div class="code-card-header">
            <span class="code-card-lang">${s.lang}</span>
            <button class="code-copy-btn" id="inline-copy-${i}" onclick="copyCode(${i}, 'inline-copy-${i}')">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              Copy
            </button>
          </div>
          <pre class="code" id="code-block-${i}">${s.code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
        </div>

        <div class="ref-title">Response Fields</div>
        <table class="ref-table">
          <thead><tr><th>Field</th><th>Type</th><th>Description</th></tr></thead>
          <tbody>
            <tr><td><code>success</code></td><td>Boolean</td><td>Whether the request was processed without error.</td></tr>
            <tr><td><code>code</code></td><td>Integer</td><td>Status code — 201 AWARD · 202 REDEEM · 203 REVERSE · 200 CHECK/BALANCE.</td></tr>
            <tr><td><code>label</code></td><td>String</td><td>Human-readable label for the status code.</td></tr>
            <tr><td><code>message</code></td><td>String</td><td>Descriptive result message.</td></tr>
            <tr><td><code>points_added</code></td><td>Integer</td><td>Points awarded. Returned for AWARD only.</td></tr>
            <tr><td><code>redeemed_points</code></td><td>Integer</td><td>Points deducted. Returned for REDEEM only.</td></tr>
            <tr><td><code>total_points</code></td><td>Integer</td><td>Updated total balance. Returned for AWARD and REVERSE.</td></tr>
            <tr><td><code>loyalty_point</code></td><td>Integer</td><td>Current balance. Returned for CHECK and BALANCE.</td></tr>
            <tr><td><code>data</code></td><td>Object</td><td>Full customer record. Returned for CHECK, AWARD, REDEEM, REVERSE.</td></tr>
          </tbody>
        </table>

      </div>
    `,
      )
      .join('')}

    <div class="footer">
      Loyalty Points API Integration Guide &nbsp;·&nbsp;
      Replace <strong>xxxxx</strong> with your credentials from the dashboard
    </div>
  </div>

  <div class="toast" id="toast">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#86efac" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
    Copied to clipboard!
  </div>

  <script>
    const codes = ${JSON.stringify(samples.map((s) => s.code))};

    function switchTab(index) {
      document.querySelectorAll('.tab-btn').forEach((b, i) => b.classList.toggle('active', i === index));
      document.querySelectorAll('.panel').forEach((p, i) => p.classList.toggle('active', i === index));
    }

    function copyCode(index, btnId) {
      navigator.clipboard.writeText(codes[index]).then(() => {
        // update clicked button
        const btn = document.getElementById(btnId);
        const original = btn.innerHTML;
        btn.classList.add('copied');
        btn.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Copied!';
        setTimeout(() => { btn.classList.remove('copied'); btn.innerHTML = original; }, 2000);

        // toast
        const toast = document.getElementById('toast');
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 2000);
      });
    }
  </script>
</body>
</html>`

  const blob = new Blob([htmlContent], { type: 'text/html' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'loyalty_api_code_samples.html'
  a.click()
  URL.revokeObjectURL(url)
}

const generatePDF = (clientId, apiKey, isActive) => {
  const maskedClientId = 'xxxxx'
  const maskedApiKey = 'xxxxx'

  const statusBadge = (type) => {
    const styles = {
      success: 'background:#d1fae5;color:#065f46',
      warning: 'background:#fef3c7;color:#92400e',
      error: 'background:#fee2e2;color:#991b1b',
    }
    return styles[type] || ''
  }

  const html = `
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body { font-family: Arial, sans-serif; font-size: 11px; color: #374151; background: #fff; width: 100%; }

      /* ── Title Block ── */
      .doc-title-block {
        border-left: 5px solid #1e293b;
        padding: 16px 20px;
        margin-bottom: 20px;
        background: #f8fafc;
        border-radius: 4px;
      }
      .doc-title-block h1 {
        font-size: 18px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 5px;
      }
      .doc-title-block p {
        font-size: 10.5px;
        color: #64748b;
        line-height: 1.6;
        margin: 0;
      }
      .doc-title-meta {
        display: flex;
        gap: 8px;
        margin-top: 12px;
        flex-wrap: wrap;
      }
      .doc-title-meta span {
        background: #e2e8f0;
        color: #334155;
        border-radius: 4px;
        padding: 3px 10px;
        font-size: 9.5px;
        font-weight: 700;
      }

      /* ── Section wrapper ── */
      .section-wrap {
        page-break-inside: avoid;
        break-inside: avoid;
        margin-bottom: 14px;
      }

      .section-title {
        background: #1e293b;
        border: 1px solid #e2e8f0;
        color: #fff;
        font-size: 11px;
        font-weight: 700;
        padding: 6px 14px;
        border-radius: 4px 4px 0 0;
        letter-spacing: 0.03em;
        text-transform: uppercase;
      }
      .section-body {
        border: 1px solid #e2e8f0;
        border-top: none;
        border-radius: 0 0 4px 4px;
        overflow: hidden;
      }

      /* ── kv rows ── */
      .kv-row {
        display: flex;
        align-items: center;
        padding: 7px 14px;
        border-bottom: 1px solid #f1f5f9;
        font-size: 10.5px;
      }
      .kv-row:last-child { border-bottom: none; }
      .kv-row:nth-child(even) { background: #f8fafc; }
      .kv-label { font-weight: 700; color: #0f172a; min-width: 130px; flex-shrink: 0; }
      .kv-value { color: #374151; word-break: break-all; font-family: 'Courier New', monospace; font-size: 10px; }

      /* ── Tables ── */
      table { width: 100%; border-collapse: collapse; font-size: 10px; }
      thead tr { background: #1e293b; color: #fff; }
      thead th { padding: 7px 10px; text-align: left; font-weight: 700; white-space: nowrap; }
      tbody tr:nth-child(even) { background: #f8fafc; }
      tbody td { padding: 6px 10px; border-bottom: 1px solid #f1f5f9; vertical-align: top; line-height: 1.5; }
      tbody tr:last-child td { border-bottom: none; }

      code {
        font-family: 'Courier New', monospace;
        font-size: 9.5px;
        color: #0f172a;
        background: #f1f5f9;
        padding: 1px 5px;
        border-radius: 3px;
      }

      .badge {
        display: inline-block;
        font-size: 9px;
        font-weight: 700;
        border-radius: 3px;
        padding: 2px 6px;
        margin: 1px 2px 1px 0;
        font-family: 'Courier New', monospace;
        white-space: nowrap;
      }

      /* ── Code blocks ── */
      .code-label {
        background: #334155;
        color: #94a3b8;
        font-family: 'Courier New', monospace;
        font-size: 9px;
        font-weight: 700;
        padding: 5px 14px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        border-bottom: 1px solid #1e293b;
      }
      .code-block {
        background: #0f172a;
        color: #e2e8f0;
        font-family: 'Courier New', monospace;
        font-size: 9.5px;
        line-height: 1.6;
        padding: 12px 14px;
        white-space: pre-wrap;
        word-break: break-all;
        border-bottom: 1px solid #1e293b;
      }
      .code-block:last-child { border-bottom: none; }

      /* ── Actions table ── */
      .action-label { font-weight: 700; color: #0f172a; font-size: 10px; }
      .action-desc  { color: #64748b; font-size: 9.5px; margin-top: 2px; line-height: 1.4; }
    </style>

    <!-- ══ TITLE ══ -->
    <div class="doc-title-block">
      <h1>Loyalty Points API — Integration Guide</h1>
      <p>Complete reference for integrating the OzoneDesk Loyalty Points API.<br/>
         Use this guide to award, redeem, reverse, and check customer loyalty points in real time.</p>
      <div class="doc-title-meta">
        <span>POST Request</span>
        <span>JSON Response</span>
        <span>API Key Auth</span>
        <span>v1.0</span>
      </div>
    </div>

    <!-- ══ 1. ENDPOINT ══ -->
    <div class="section-wrap">
      <div class="section-title">Endpoint</div>
      <div class="section-body">
        <div class="kv-row"><span class="kv-label">URL</span><span class="kv-value">${baseURL}/apidocuments/loyalty</span></div>
        <div class="kv-row"><span class="kv-label">Method</span><span class="kv-value">POST</span></div>
        <div class="kv-row"><span class="kv-label">Return Type</span><span class="kv-value">JSON</span></div>
      </div>
    </div>

    <!-- ══ 2. PARAMETERS ══ -->
    <div class="section-wrap">
      <div class="section-title">Parameters</div>
      <div class="section-body">
        <table>
          <thead><tr><th>Key</th><th>Description</th></tr></thead>
          <tbody>
            <tr><td><code>client_id</code></td><td>Your unique Client ID provided by OzoneDesk.</td></tr>
            <tr><td><code>api_key</code></td><td>Your secret API key for authentication.</td></tr>
            <tr><td><code>action</code></td><td>Action to perform: AWARD, REDEEM, REVERSE, CHECK, BALANCE.</td></tr>
            <tr><td><code>order_id</code></td><td>Your reference Order ID or Invoice ID.</td></tr>
            <tr><td><code>order_value</code></td><td>Total value of the order in LKR (Number). Used to calculate loyalty points.</td></tr>
            <tr><td><code>redeem_points</code></td><td>Redeem points value of the order in LKR (Number). Used to deduct loyalty points.</td></tr>
            <tr><td><code>mobile_number</code></td><td>Customer mobile number with country code (e.g. 94771234567).</td></tr>
            <tr><td><code>email</code></td><td>Customer email address. Used for loyalty account identification.</td></tr>
          </tbody>
        </table>
      </div> 
    </div>

    <!-- ══ 3. RESPONSE ══ -->
    <div class="section-wrap">
      <div class="section-title">Response — Sample &amp; Parameters</div>
      <div class="section-body">
        <div class="code-label">Sample JSON Response</div>
        <div class="code-block">{
          "success": true,
          "code": 201,
          "label": "Points Awarded",
          "message": "Loyalty points awarded successfully.",
          "points_added": 2500,
          "total_points": 7350,
          "data": { "customer_id": 42, "customer_name": "Jonathon Silva", "loyalty_point": 7350 }
        }</div>
        <table>
          <thead><tr><th style="width:140px">Key</th><th>Description</th></tr></thead>
          <tbody>
            <tr><td><code>success</code></td><td>Boolean — whether the request was processed without a server error.</td></tr>
            <tr><td><code>code</code></td><td>Custom loyalty status code indicating the specific result of the action.</td></tr>
            <tr><td><code>label</code></td><td>Human-readable label matching the status code (e.g. "Points Awarded").</td></tr>
            <tr><td><code>message</code></td><td>Descriptive message explaining the result of the request.</td></tr>
            <tr><td><code>points_added</code></td><td>Points awarded in this transaction. Returned for AWARD action only.</td></tr>
            <tr><td><code>redeemed_points</code></td><td>Points deducted in this transaction. Returned for REDEEM action only.</td></tr>
            <tr><td><code>remaining_points</code></td><td>Remaining balance after redemption. Returned for REDEEM action only.</td></tr>
            <tr><td><code>total_points</code></td><td>Customer's updated total loyalty point balance. Returned for AWARD and REVERSE.</td></tr>
            <tr><td><code>loyalty_point</code></td><td>Customer's current point balance. Returned for CHECK and BALANCE actions.</td></tr>
            <tr><td><code>data</code></td><td>Full customer record object. Returned for CHECK, AWARD, REDEEM, and REVERSE.</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ══ 4. STATUS CODES ══ -->
    <div class="section-wrap">
      <div class="section-title">Status Codes</div>
      <div class="section-body">
        <table>
          <thead><tr><th style="width:60px">Code</th><th style="width:160px">Label</th><th>Description</th></tr></thead>
          <tbody>
            ${STATUS_CODES.map(
              (s) => `
              <tr>
                <td><span class="badge" style="${statusBadge(s.type)}">${s.code}</span></td>
                <td style="font-weight:600;color:#0f172a">${s.label}</td>
                <td style="color:#64748b">${s.description}</td>
              </tr>
            `,
            ).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- ══ 5. ACTIONS ══ -->
    <div class="section-wrap">
      <div class="section-title">Actions</div>
      <div class="section-body">
        <table>
          <thead>
            <tr>
              <th style="width:28px">No</th>
              <th style="width:35px">Action</th>
              <th style="width:120px">When to Use</th>
              <th style="width:200px">Required Parameters</th>
              <th>Possible Error Codes</th>  
            </tr>
          </thead>
          <tbody>
            ${ACTIONS.map(
              (a, i) => `
              <tr>
                <td style="text-align:center;font-weight:700;color:#64748b">${i + 1}</td>
                <td>
                  <span class="badge" style="${Object.entries(a.badgeStyle)
                    .map(([k, v]) => `${k.replace(/([A-Z])/g, '-$1').toLowerCase()}:${v}`)
                    .join(';')}">
                    ${a.action}
                  </span>
                </td>
                <td>
                  <div class="action-label">${a.label}</div>
                  <div class="action-desc">${a.description}</div>
                </td>
                <td style="padding:10px 14px;border-bottom:1px solid #f3f4f6;vertical-align:top;">
                  <div style="font-size:0.60rem;font-weight:600;color:#374151;">
                    ${htmlformatParameters(a.parameters, a.action)}
                  </div>
                </td>
                <td>${a.errorCodes.map((e) => `<span class="badge" style="${statusBadge(e.type)}">${e.code} ${e.label}</span>`).join(' ')}</td>
              </tr>
            `,
            ).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- ══ 6. SAMPLE CODE NOTE ══ -->
    <div class="section-wrap">
      <div class="section-title">Sample Code</div>
      <div class="section-body">
        <div style="display:flex;align-items:flex-start;gap:14px;padding:18px 20px;">
          <div style="flex-shrink:0;width:38px;height:38px;background:#f1f5f9;border-radius:6px;display:flex;align-items:center;justify-content:center;">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#475569" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>
            </svg>
          </div>
          <div>
            <div style="font-size:12px;font-weight:700;color:#0f172a;margin-bottom:5px;">
              Code samples are available in a separate interactive file
            </div>
            <div style="font-size:11px;color:#64748b;line-height:1.7;margin-bottom:10px;">
              Ready-to-use code snippets for JavaScript (Fetch &amp; Axios), PHP, Python, and cURL 
              are provided in a companion HTML file. Open it in any browser to copy snippets directly 
              into your project.
            </div>
            <div style="margin-top:10px;font-size:10px;color:#94a3b8;">
              💡 Tip — Replace <span style="font-family:monospace;background:#f1f5f9;color:#0f172a;padding:1px 5px;border-radius:3px;font-size:10px;">xxxxx</span> 
              in <span style="font-family:monospace;background:#f1f5f9;color:#0f172a;padding:1px 5px;border-radius:3px;font-size:10px;">client_id</span> and 
              <span style="font-family:monospace;background:#f1f5f9;color:#0f172a;padding:1px 5px;border-radius:3px;font-size:10px;">api_key</span> 
              with your actual credentials from your dashboard before using any snippet.
            </div>
          </div>
        </div>
      </div>
    </div>    
  `

  const element = document.createElement('div')
  element.innerHTML = html

  const opt = {
    margin: [12, 12, 12, 12],
    filename: 'loyalty_api_documentation.pdf',
    image: { type: 'jpeg', quality: 0.98 },
    html2canvas: { scale: 2, useCORS: true, logging: false },
    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
    pagebreak: { mode: ['css', 'legacy'], avoid: '.section-wrap' },
  }

  return html2pdf().set(opt).from(element).save()
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function ApiDocumentation() {
  const { data: apiSettings, isLoading, refetch } = useGetApiDetailsQuery()
  const apiData = apiSettings?.data?.[0]
  const isActive = apiData?.is_active ?? false
  const clientId = apiData?.client_id ?? '—'
  const apiKey = apiData?.api_key ?? '—'

  const [isPdfLoading, setIsPdfLoading] = useState(false)
  const [isCodeLoading, setIsCodeLoading] = useState(false)
  const [toggleApiStatus, { isLoading: isToggling }] = useToggleApiStatusMutation()
  const [regenerateApiKey, { isLoading: isRegenerating }] = useRegenerateApiKeyMutation()

  // ── Handlers ────────────────────────────────────────────────────────────────

  // FIX: generatePDF is now synchronous — no async/await needed
  // In handleDownloadPdf — html2pdf returns a Promise
  const handleDownloadPdf = async () => {
    setIsPdfLoading(true)
    try {
      await generatePDF(String(clientId), String(apiKey), isActive)
    } catch (err) {
      console.error('PDF generation failed:', err)
      Swal.fire({ icon: 'error', title: 'PDF Error', text: 'Could not generate PDF. Please try again.' })
    } finally {
      setIsPdfLoading(false)
    }
  }

  const handleDownloadCodeSamples = () => {
    setIsCodeLoading(true)
    try {
      generateCodeHTML(String(clientId), String(apiKey))
      Swal.fire({
        icon: 'success',
        title: 'Code Samples Downloaded!',
        text: 'Open the HTML file in any browser to copy code snippets.',
        toast: true,
        timer: 3000,
        position: 'top-end',
        showConfirmButton: false,
      })
    } catch (err) {
      console.error('Code samples generation failed:', err)
      Swal.fire({ icon: 'error', title: 'Error', text: 'Could not generate code samples.' })
    } finally {
      setIsCodeLoading(false)
    }
  }

  const handleToggle = async () => {
    const result = await Swal.fire({
      title: `${isActive ? 'Deactivate' : 'Activate'} API?`,
      text: isActive ? 'Your API access will be disabled. Existing integrations will stop working.' : 'This will enable API access for your account.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${isActive ? 'deactivate' : 'activate'}`,
      confirmButtonColor: isActive ? '#ef4444' : '#22c55e',
    })
    if (!result.isConfirmed) return
    try {
      await toggleApiStatus({ is_active: !isActive }).unwrap()
      await refetch()
      Swal.fire({
        icon: 'success',
        title: `API ${isActive ? 'deactivated' : 'activated'}`,
        toast: true,
        timer: 1800,
        position: 'top-end',
        showConfirmButton: false,
      })
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Failed', text: err?.data?.message || 'Something went wrong.' })
    }
  }

  const handleRegenerateKey = async () => {
    const result = await Swal.fire({
      title: 'Regenerate API Key?',
      text: 'Your current API key will be invalidated immediately. All existing integrations must be updated.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, regenerate',
      confirmButtonColor: '#f59e0b',
    })
    if (!result.isConfirmed) return
    try {
      await regenerateApiKey().unwrap()
      Swal.fire({ icon: 'success', title: 'API key regenerated', toast: true, timer: 1800, position: 'top-end', showConfirmButton: false })
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Failed', text: err?.data?.message || 'Could not regenerate key.' })
    }
  }

  const handleCopyApiKey = () => {
    if (apiKey === '—') return
    navigator.clipboard.writeText(apiKey)
    Swal.fire({ icon: 'success', title: 'API key copied!', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
  }

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: 300 }}>
        <span className="spinner-border" style={{ color: 'var(--bs-primary)' }} />
      </div>
    )
  }

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div>
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center justify-content-between">
            <Col>
              <CardTitle as="h4" className="mb-0">
                API Documentation
              </CardTitle>
            </Col>
            <Col xs="auto" className="d-flex gap-2">
              <button
                onClick={handleDownloadPdf}
                disabled={isPdfLoading}
                title="Download PDF Documentation"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  background: isPdfLoading ? '#e5e7eb' : '#1e293b',
                  color: isPdfLoading ? '#9ca3af' : '#fff',
                  border: 'none',
                  borderRadius: 8,
                  padding: '7px 14px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: isPdfLoading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.15s',
                  lineHeight: 1,
                }}>
                {isPdfLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} /> Generating...
                  </>
                ) : (
                  <>
                    <Icon icon="mdi:file-pdf-box" width={16} /> Download PDF
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadCodeSamples}
                disabled={isCodeLoading}
                title="Download Interactive Code Samples"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  background: isCodeLoading ? '#e5e7eb' : '#fff',
                  color: isCodeLoading ? '#9ca3af' : '#1e293b',
                  border: '1.5px solid #1e293b',
                  borderRadius: 8,
                  padding: '7px 14px',
                  fontSize: '0.82rem',
                  fontWeight: 600,
                  cursor: isCodeLoading ? 'not-allowed' : 'pointer',
                  transition: 'all 0.15s',
                  lineHeight: 1,
                }}>
                {isCodeLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} /> Generating...
                  </>
                ) : (
                  <>
                    <Icon icon="mdi:code-braces" width={16} /> Code Samples
                  </>
                )}
              </button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          <Row className="g-2">
            {/* ── 1. API SETTINGS ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:api" title="API Settings" />
                  <Row className="g-3">
                    {/* API Status */}
                    <Col md={4}>
                      <div
                        style={{
                          border: '1px solid #e9ecef',
                          borderRadius: 10,
                          padding: '16px 18px',
                          background: isActive ? 'rgba(34,197,94,0.05)' : '#fafafa',
                          borderColor: isActive ? 'rgba(34,197,94,0.25)' : '#e9ecef',
                          transition: 'all 0.2s',
                        }}>
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: '0.78rem',
                            color: '#6b7280',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            marginBottom: 10,
                          }}>
                          API Status
                        </div>
                        <div className="d-flex align-items-center justify-content-between">
                          <div className="d-flex align-items-center gap-2">
                            <div
                              style={{
                                width: 10,
                                height: 10,
                                borderRadius: '50%',
                                background: isActive ? '#22c55e' : '#d1d5db',
                                boxShadow: isActive ? '0 0 0 3px rgba(34,197,94,0.2)' : 'none',
                                flexShrink: 0,
                                transition: 'all 0.3s',
                              }}
                            />
                            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: isActive ? '#15803d' : '#9ca3af' }}>
                              {isActive ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                          {/* <div
                            onClick={!isToggling ? handleToggle : undefined}
                            style={{ width: 44, height: 24, borderRadius: 12, background: isActive ? '#22c55e' : '#d1d5db', position: 'relative', cursor: isToggling ? 'not-allowed' : 'pointer', transition: 'background 0.25s', opacity: isToggling ? 0.6 : 1, flexShrink: 0 }}
                          >
                            <div style={{ position: 'absolute', top: 3, left: isActive ? 23 : 3, width: 18, height: 18, borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'left 0.25s' }} />
                          </div> */}
                        </div>
                        {!isActive && (
                          <div style={{ marginTop: 8, fontSize: '0.72rem', color: '#ef4444', fontWeight: 500 }}>Contact Admin to activate API</div>
                        )}
                      </div>
                    </Col>

                    {/* Client ID */}
                    <Col md={4}>
                      <div style={{ border: '1px solid #e9ecef', borderRadius: 10, padding: '16px 18px' }}>
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: '0.78rem',
                            color: '#6b7280',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            marginBottom: 10,
                          }}>
                          Client ID
                        </div>
                        <div className="d-flex align-items-center gap-2">
                          <span
                            style={{
                              fontFamily: "'SFMono-Regular', Consolas, monospace",
                              fontSize: '0.80rem',
                              color: '#374151',
                              background: '#f3f4f6',
                              borderRadius: 6,
                              padding: '5px 10px',
                              flex: 1,
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              whiteSpace: 'nowrap',
                              minWidth: 0,
                            }}>
                            {clientId}
                          </span>
                        </div>
                      </div>
                    </Col>

                    {/* API Key */}
                    <Col md={4}>
                      <div style={{ border: '1px solid #e9ecef', borderRadius: 10, padding: '16px 18px' }}>
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: '0.78rem',
                            color: '#6b7280',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            marginBottom: 10,
                          }}>
                          API Key
                        </div>
                        <div className="d-flex align-items-center gap-2">
                          <span
                            style={{
                              fontFamily: "'SFMono-Regular', Consolas, monospace",
                              fontSize: '0.80rem',
                              color: '#374151',
                              background: '#f3f4f6',
                              borderRadius: 6,
                              padding: '5px 10px',
                              flex: 1,
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              whiteSpace: 'nowrap',
                              minWidth: 0,
                            }}>
                            {apiKey}
                          </span>
                          <button
                            onClick={handleCopyApiKey}
                            title="Copy API key"
                            style={{
                              border: 'none',
                              background: '#f3f4f6',
                              borderRadius: 6,
                              padding: '6px 8px',
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              color: '#6b7280',
                              flexShrink: 0,
                            }}>
                            <Icon icon="mdi:content-copy" width={15} />
                          </button>
                          <button
                            onClick={handleRegenerateKey}
                            title="Regenerate API key"
                            disabled={isRegenerating}
                            style={{
                              border: 'none',
                              background: '#22c55e',
                              borderRadius: 6,
                              padding: '6px 10px',
                              cursor: isRegenerating ? 'not-allowed' : 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              color: '#fff',
                              flexShrink: 0,
                              opacity: isRegenerating ? 0.7 : 1,
                            }}>
                            {isRegenerating ? (
                              <span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} />
                            ) : (
                              <Icon icon="mdi:refresh" width={16} />
                            )}
                          </button>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>

            {/* ── 2. ENDPOINT INFO ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:web" title="Loyalty Point Request Endpoint" />
                  <div style={{ border: '1px solid #e9ecef', borderRadius: 10, overflow: 'hidden' }}>
                    {[
                      { label: 'Endpoint', value: `${baseURL}/apidocuments/loyalty`, mono: true },
                      { label: 'Type', value: 'POST', badge: 'success' },
                      { label: 'Return Type', value: 'JSON', badge: 'warning' },
                    ].map((row, i) => (
                      <div
                        key={i}
                        className="d-flex align-items-center gap-3 px-3 py-2"
                        style={{ borderBottom: i < 2 ? '1px solid #f3f4f6' : 'none' }}>
                        <span
                          style={{
                            fontWeight: 600,
                            fontSize: '0.78rem',
                            color: '#6b7280',
                            textTransform: 'uppercase',
                            letterSpacing: '0.05em',
                            minWidth: 100,
                          }}>
                          {row.label}
                        </span>
                        {row.badge === 'success' && (
                          <span
                            style={{
                              background: '#d1fae5',
                              color: '#065f46',
                              fontSize: '0.72rem',
                              fontWeight: 700,
                              borderRadius: 6,
                              padding: '3px 10px',
                            }}>
                            {row.value}
                          </span>
                        )}
                        {row.badge === 'warning' && (
                          <span
                            style={{
                              background: '#fef3c7',
                              color: '#92400e',
                              fontSize: '0.72rem',
                              fontWeight: 700,
                              borderRadius: 6,
                              padding: '3px 10px',
                            }}>
                            {row.value}
                          </span>
                        )}
                        {row.mono && (
                          <span style={{ fontFamily: "'SFMono-Regular', Consolas, monospace", fontSize: '0.80rem', color: '#374151' }}>
                            {row.value}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </CardBody>
              </Card>
            </Col>

            {/* ── 3. PARAMETERS ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:table-of-contents" title="Parameters" badge={8} />
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                      <thead>
                        <tr style={{ backgroundColor: '#e5e5f8b4' }}>
                          <th style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 700, color: '#111827', fontSize: '0.8rem' }}>Key</th>
                          <th style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 700, color: '#111827', fontSize: '0.8rem' }}>
                            Description
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { key: 'client_id', desc: 'Your unique Client ID provided.' },
                          { key: 'api_key', desc: 'Your secret API key for authentication.' },
                          { key: 'order_id', desc: 'Your reference Order ID or Invoice ID.' },
                          {
                            key: 'order_value',
                            desc: 'Total value of the order in LKR (Number). Used to calculate loyalty points.',
                          },
                          {
                            key: 'redeem_points',
                            desc: 'Redeem points value of the order in LKR (Number). Used to deduct loyalty points.',
                          },
                          { key: 'mobile_number', desc: 'Customer mobile number with country code (e.g. 94771234567).' },
                          { key: 'email', desc: 'Customer email address. Used for loyalty account identification.' },
                        ].map((row) => (
                          <tr key={row.key}>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6' }}>
                              <span
                                style={{
                                  fontFamily: "'SFMono-Regular', Consolas, monospace",
                                  fontSize: '0.80rem',
                                  color: 'var(--bs-primary)',
                                  fontWeight: 600,
                                }}>
                                {row.key}
                              </span>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', color: '#6b7280', fontSize: '0.80rem' }}>
                              {row.desc}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardBody>
              </Card>
            </Col>

            {/* ── 4. RESPONSE ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:code-json" title="Response" />
                  <Row className="g-3 align-items-stretch">
                    <Col md={5} className="d-flex flex-column flex-grow-1">
                      <div
                        style={{
                          fontWeight: 700,
                          fontSize: '0.78rem',
                          color: '#6b7280',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                          marginBottom: 10,
                        }}>
                        Response Sample
                      </div>
                      <div
                        style={{
                          background: '#1e1e2e',
                          borderRadius: 10,
                          overflow: 'hidden',
                          border: '1px solid rgba(255,255,255,0.06)',
                          height: '100%',
                        }}>
                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                            padding: '8px 14px',
                            borderBottom: '1px solid rgba(255,255,255,0.07)',
                            background: 'rgba(255,255,255,0.03)',
                          }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#ff5f57' }} />
                            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#febc2e' }} />
                            <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#28c840' }} />
                          </div>
                          <span style={{ fontSize: '0.68rem', color: 'rgba(205,214,244,0.4)', fontFamily: 'monospace' }}>JSON</span>
                        </div>
                        <div style={{ padding: '16px 18px', height: '100%' }}>
                          <pre
                            style={{
                              margin: 0,
                              fontFamily: "'SFMono-Regular', Consolas, monospace",
                              fontSize: '0.77rem',
                              lineHeight: 1.75,
                              color: '#cdd6f4',
                              whiteSpace: 'pre-wrap',
                              wordBreak: 'break-all',
                              overflowX: 'hidden',
                            }}>
                            <span style={{ color: '#89dceb' }}>{'{'}</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;success&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'      '}
                            <span style={{ color: '#a6e3a1' }}>true</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;code&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'         '}
                            <span style={{ color: '#fab387' }}>201</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;label&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'        '}
                            <span style={{ color: '#a6e3a1' }}>&quot;Points Awarded&quot;</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;message&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'      '}
                            <span style={{ color: '#a6e3a1' }}>&quot;Loyalty points awarded successfully.&quot;</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;points_added&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span> <span style={{ color: '#fab387' }}>2500</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;total_points&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span> <span style={{ color: '#fab387' }}>7350</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#cba6f7' }}>&quot;data&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span> <span style={{ color: '#89dceb' }}>{'{'}</span>
                            {'\n'}
                            {'    '}
                            <span style={{ color: '#cba6f7' }}>&quot;customer_id&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'    '}
                            <span style={{ color: '#fab387' }}>42</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'    '}
                            <span style={{ color: '#cba6f7' }}>&quot;customer_name&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'     '}
                            <span style={{ color: '#a6e3a1' }}>&quot;Jonathon Silva&quot;</span>
                            <span style={{ color: '#6c7086' }}>,</span>
                            {'\n'}
                            {'    '}
                            <span style={{ color: '#cba6f7' }}>&quot;loyalty_point&quot;</span>
                            <span style={{ color: '#89dceb' }}>:</span>
                            {'  '}
                            <span style={{ color: '#fab387' }}>7350</span>
                            {'\n'}
                            {'  '}
                            <span style={{ color: '#89dceb' }}>{'}'}</span>
                            {'\n'}
                            <span style={{ color: '#89dceb' }}>{'}'}</span>
                          </pre>
                        </div>
                      </div>
                    </Col>
                    <Col md={7}>
                      <div
                        style={{
                          fontWeight: 700,
                          fontSize: '0.78rem',
                          color: '#6b7280',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                          marginBottom: 10,
                        }}>
                        Response Parameters
                      </div>
                      <table
                        style={{
                          width: '100%',
                          borderCollapse: 'collapse',
                          fontSize: '0.83rem',
                          border: '1px solid #e9ecef',
                          borderRadius: 8,
                          overflow: 'hidden',
                        }}>
                        <thead>
                          <tr style={{ backgroundColor: '#e5e5f8b4' }}>
                            <th style={{ padding: '9px 14px', textAlign: 'left', fontWeight: 700, fontSize: '0.8rem', color: '#111827' }}>Key</th>
                            <th style={{ padding: '9px 14px', textAlign: 'left', fontWeight: 700, fontSize: '0.8rem', color: '#111827' }}>
                              Description
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { key: 'success', desc: 'Boolean indicating whether the request was processed without a server error.' },
                            { key: 'code', desc: 'Custom loyalty status code indicating the specific result of the action.' },
                            { key: 'label', desc: 'Label matching the status code.' },
                            { key: 'message', desc: 'Descriptive message explaining the result of the request.' },
                            { key: 'points_added', desc: 'Points awarded in this transaction. Returned for AWARD action only.' },
                            { key: 'redeemed_points', desc: 'Points deducted in this transaction. Returned for REDEEM action only.' },
                            // { key: 'reversed_points', desc: 'Points restored in this transaction. Returned for REVERSE action only.' },
                            { key: 'remaining_points', desc: 'Remaining balance after redemption. Returned for REDEEM action only.' },
                            { key: 'total_points', desc: 'Updated total loyalty point balance.' },
                            { key: 'loyalty_point', desc: 'Current point balance.' },
                            { key: 'data', desc: 'Full customer record object.' },
                          ].map((row, i, arr) => (
                            <tr key={row.key} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                              <td style={{ padding: '9px 14px', borderBottom: i < arr.length - 1 ? '1px solid #f3f4f6' : 'none' }}>
                                <span
                                  style={{
                                    fontFamily: "'SFMono-Regular', Consolas, monospace",
                                    fontSize: '0.80rem',
                                    color: 'var(--bs-primary)',
                                    fontWeight: 600,
                                  }}>
                                  {row.key}
                                </span>
                              </td>
                              <td
                                style={{
                                  padding: '9px 14px',
                                  borderBottom: i < arr.length - 1 ? '1px solid #f3f4f6' : 'none',
                                  color: '#6b7280',
                                  fontSize: '0.80rem',
                                }}>
                                {row.desc}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>

            {/* ── 5. STATUS CODE LIST ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:format-list-numbered" title="Status Code List" badge={STATUS_CODES.length} />
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                      <thead>
                        <tr style={{ backgroundColor: '#e5e5f8b4' }}>
                          <th style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 100 }}>
                            Code
                          </th>
                          <th style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 200 }}>
                            Label
                          </th>
                          <th style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 700, color: '#111827', fontSize: '0.8rem' }}>
                            Description
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {STATUS_CODES.map((row, i) => (
                          <tr key={row.code} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'middle' }}>
                              <span
                                style={{
                                  display: 'inline-block',
                                  fontFamily: "'SFMono-Regular', Consolas, monospace",
                                  fontSize: '0.80rem',
                                  fontWeight: 700,
                                  borderRadius: 6,
                                  padding: '3px 12px',
                                  ...STATUS_BADGE_STYLES[row.type],
                                }}>
                                {row.code}
                              </span>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'middle' }}>
                              <span style={{ fontSize: '0.78rem', fontWeight: 600, color: '#374151' }}>{row.label}</span>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', color: '#6b7280', fontSize: '0.82rem' }}>
                              {row.description}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardBody>
              </Card>
            </Col>

            {/* ── 6. ACTION LIST ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:lightning-bolt" title="Action List" badge={ACTIONS.length} />
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                      <thead>
                        <tr style={{ backgroundColor: '#e5e5f8b4' }}>
                          <th style={{ padding: '10px 14px', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 60 }}>Action_No</th>
                          <th style={{ padding: '10px 14px', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 110 }}>Name</th>
                          <th style={{ padding: '10px 14px', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 220 }}>When to use</th>
                          <th style={{ padding: '10px 14px', fontWeight: 700, color: '#111827', fontSize: '0.8rem', width: 300 }}>
                            Required parameters
                          </th>
                          <th style={{ padding: '10px 14px', fontWeight: 700, color: '#111827', fontSize: '0.8rem' }}>Possible error codes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ACTIONS.map((row, i) => (
                          <tr key={row.action} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'top' }}>
                              <span
                                style={{
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  width: 24,
                                  height: 24,
                                  borderRadius: '50%',
                                  background: 'rgba(var(--bs-primary-rgb), 0.10)',
                                  color: 'var(--bs-primary)',
                                  fontSize: '0.72rem',
                                  fontWeight: 700,
                                }}>
                                {i + 1}
                              </span>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'top' }}>
                              <span
                                style={{
                                  display: 'inline-block',
                                  fontFamily: "'SFMono-Regular', Consolas, monospace",
                                  fontSize: '0.78rem',
                                  fontWeight: 700,
                                  borderRadius: 6,
                                  padding: '3px 12px',
                                  ...row.badgeStyle,
                                }}>
                                {row.action}
                              </span>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'top' }}>
                              <div style={{ fontSize: '0.80rem', fontWeight: 600, color: '#374151', marginBottom: 3 }}>{row.label}</div>
                              <div style={{ fontSize: '0.75rem', color: '#6b7280', lineHeight: 1.5 }}>{row.description}</div>
                            </td>
                            <td
                              style={{
                                padding: '10px 14px',
                                borderBottom: '1px solid #f3f4f6',
                                verticalAlign: 'top',
                              }}>
                              <div
                                style={{
                                  fontSize: '0.70rem',
                                  fontWeight: 600,
                                  color: '#374151',
                                }}>
                                {formatParameters(row.parameters, row.action)}
                              </div>
                            </td>
                            <td style={{ padding: '10px 14px', borderBottom: '1px solid #f3f4f6', verticalAlign: 'top' }}>
                              {row.errorCodes.map((e) => (
                                <span
                                  key={`${row.action}-${e.code}`}
                                  style={{
                                    display: 'inline-block',
                                    fontFamily: "'SFMono-Regular', Consolas, monospace",
                                    fontSize: '0.72rem',
                                    fontWeight: 700,
                                    borderRadius: 6,
                                    padding: '2px 9px',
                                    margin: '2px 2px 2px 0',
                                    ...STATUS_BADGE_STYLES[e.type],
                                  }}>
                                  {e.code} {e.label}
                                </span>
                              ))}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardBody>
              </Card>
            </Col>

            {/* ── 7. SAMPLE CODE ── */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:code-tags" title="Sample Code for AWARD (Action_no = 1)" />
                  <CodeSample clientId={String(clientId)} apiKey={String(apiKey)} />
                </CardBody>
              </Card>
            </Col>
          </Row>
        </CardBody>
      </Card>
    </div>
  )
}
