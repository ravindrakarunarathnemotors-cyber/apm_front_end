'use client'
import React, { useState, useEffect } from 'react'
import {
    Card,
    CardHeader,
    CardBody,
    CardTitle,
    Button,
    Alert,
    Table,
    Badge,
    Row, Col, CardText
} from 'react-bootstrap'
import axiosInstance from '@/lib/axiosInstance';

const KotApi = () => {

    const [restuarentSetting, setRestuarentSetting] = useState(null)

    useEffect(() => {
        fetchData()
    }, [])

    const fetchData = async () => {
        try {
            const response = await axiosInstance.get(`/restaurant/kot/getApiDocuments`)

            if (response.status === 200) {
                setRestuarentSetting(response.data.documents)
            }
        } catch (error) {
            console.error('Search failed:', error)

        }
    }


    return (
        <div>
            <Card>
                <CardHeader className="py-3 bg-light d-flex justify-content-between align-items-center">
                    <CardTitle as="h4" style={{ fontSize: '18px', marginBottom: 0 }}>
                        KOT API Documentation
                    </CardTitle>

                    <Button
                        variant="success"
                        href="YOUR_GOOGLE_DRIVE_LINK"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Download KOT Agent
                    </Button>
                </CardHeader>

                <CardBody>

                    <Alert variant="info">
                        <strong>Overview</strong>
                        <br />
                        The KOT (Kitchen Order Ticket) API enables the KOT Agent to communicate
                        with the restaurant system. It allows the agent to retrieve pending
                        kitchen orders, obtain the list of active kitchens, and notify the system
                        once orders have been printed.
                    </Alert>

                    {/* <h5 className="mb-3">Base URL</h5> */}

                    {/* <Card className="mb-4 border">
                        <CardBody className="py-3">

                            <code>{process.env.NEXT_PUBLIC_BASE_URL}</code>

                            <p className="mt-3 mb-0">
                                Replace <strong>your-domain.com</strong> with your own restaurant
                                system domain. All API endpoints shown below should be prefixed
                                with your configured domain.
                            </p>

                        </CardBody>
                    </Card> */}

                    <h5 className="mb-3">Client Details</h5>

                    <Card className="mb-4 border">
                        <CardBody className="py-3">
                            <Row>
                                <Col md={6}>
                                    <small className="text-muted d-block mb-1">
                                        Client ID
                                    </small>

                                    <code
                                        style={{
                                            display: "block",
                                            fontSize: "16px",
                                            fontWeight: 600,
                                            padding: "8px 10px",
                                            background: "#f8f9fa",
                                            borderRadius: "6px",
                                            border: "1px solid #e9ecef",
                                            color: "#212529",
                                        }}
                                    >
                                        {restuarentSetting?.client_id || "-"}
                                    </code>
                                </Col>

                                <Col md={6}>
                                    <small className="text-muted d-block mb-1">
                                        API Key
                                    </small>

                                    <code
                                        style={{
                                            display: "block",
                                            fontSize: "16px",
                                            fontWeight: 600,
                                            padding: "8px 10px",
                                            background: "#f8f9fa",
                                            borderRadius: "6px",
                                            border: "1px solid #e9ecef",
                                            color: "#212529",
                                            wordBreak: "break-all",
                                        }}
                                    >
                                        {restuarentSetting?.api_key || "-"}
                                    </code>
                                </Col>
                            </Row>
                        </CardBody>
                    </Card>

                    <h5 className="mb-3">Available Endpoints</h5>

                    <Table bordered hover responsive>
                        <thead className="table-light">
                            <tr>
                                <th width="30%">Endpoint</th>
                                <th width="15%">Method</th>
                                <th>Description</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>
                                    <code>{process.env.NEXT_PUBLIC_BASE_URL}/restaurant/kot/getPendingKOTs</code>
                                </td>
                                <td>
                                    <Badge bg="success">GET</Badge>
                                </td>
                                <td>
                                    Returns all pending Kitchen Order Tickets (KOTs) that are
                                    waiting to be printed by the KOT Agent.
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <code>{process.env.NEXT_PUBLIC_BASE_URL}/restaurant/kot/getKitchens</code>
                                </td>
                                <td>
                                    <Badge bg="success">GET</Badge>
                                </td>
                                <td>
                                    Returns all active kitchens configured in the restaurant
                                    system.
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <code>{process.env.NEXT_PUBLIC_BASE_URL}/restaurant/kot/acknowledgeKOT</code>
                                </td>
                                <td>
                                    <Badge bg="warning" text="dark">
                                        POST
                                    </Badge>
                                </td>
                                <td>
                                    Updates printed KOT items by changing their status to
                                    <strong> Printed </strong> and saves the printer ID associated
                                    with each printed item.
                                </td>
                            </tr>
                        </tbody>
                    </Table>

                    <Alert variant="warning" className="mt-4 mb-0">
                        <strong>Note</strong>
                        <br />
                        This page provides a general overview of the available KOT API endpoints.
                        It is intended to help developers understand the purpose of each endpoint.
                        Detailed request and response formats are documented separately.
                    </Alert>

                </CardBody>
            </Card>
        </div>
    )
}

export default KotApi