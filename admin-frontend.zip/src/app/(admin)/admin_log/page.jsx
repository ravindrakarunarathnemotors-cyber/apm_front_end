'use client'

import React, { useState, useEffect, useCallback } from 'react'
import Select from 'react-select'
import {
  Button,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Col,
  Table,
  Row,
  Form,
  FormGroup,
  FormLabel,
} from 'react-bootstrap'
import Pagination from '@/components/Pagination'

import {
  useGetFilteredadminlogMutation,
  useGetAdmincollQuery,
} from '@/store/features/apiSlice'

function CollectionList() {


  // ================= DRAFT FILTERS =================
  const [draftFilters, setDraftFilters] = useState({
    logname: '',
    log_at: '',
    description: '',
    id: '',
  })

  // ================= APPLIED FILTERS =================
  const [appliedFilters, setAppliedFilters] = useState({
    logname: '',
    log_at: '',
    description: '',
    id: '',
  })

  const [selectedOption, setSelectedOption] = useState(null)
  const [products, setProducts] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [limit, setLimit] = useState(25)
  const [totalEntries, setTotalEntries] = useState(0)
  const [searchCollection, setSearchCollection] = useState('')

  const [fetchFilteredCollection, { isLoading }] =
    useGetFilteredadminlogMutation()

  const { data: productColloection } = useGetAdmincollQuery(
    searchCollection,
    { skip: searchCollection.length < 2 },
  )

  // ================= OPTIONS =================
  const productOptions =
    productColloection?.map((collect) => ({
      value: collect.id,
      label: `${collect.module} (${collect.id})`,
    })) || []

  // ================= FETCH =================
  const fetchLogs = useCallback(
    async (page, filters, customLimit = limit) => {
      setLoading(true)
      try {
        const res = await fetchFilteredCollection({
          page,
          limit: customLimit,
          ...filters,
          merchant_id: '20001',
        }).unwrap()

        setProducts(res.collections || [])
        setTotalPages(res.totalPages || 1)
        setCurrentPage(page)
        setTotalEntries(res.total || 0)
      } catch (err) {
        console.error('Fetch error:', err)
      } finally {
        setLoading(false)
      }
    },
    [fetchFilteredCollection, limit],
  )

  // ================= INITIAL LOAD =================
  useEffect(() => {
    fetchLogs(1, appliedFilters)
  }, [])

  // ================= SEARCH BUTTON =================
  const handleSearch = () => {
    setAppliedFilters(draftFilters)
    fetchLogs(1, draftFilters)
  }

  // ================= PAGINATION =================
  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchLogs(page, appliedFilters)
  }

  // ================= PAGINATION UI =================
  const renderPagination = () => {
    if (totalPages <= 1) return null

    let pages = []

    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(
          <Pagination.Item
            key={i}
            active={i === currentPage}
            onClick={() => handlePageChange(i)}
          >
            {i}
          </Pagination.Item>,
        )
      }
    } else {
      let start = currentPage - 2
      let end = currentPage + 2

      if (start < 1) {
        start = 1
        end = 5
      }

      if (end > totalPages) {
        end = totalPages
        start = totalPages - 4
      }

      for (let i = start; i <= end; i++) {
        pages.push(
          <Pagination.Item
            key={i}
            active={i === currentPage}
            onClick={() => handlePageChange(i)}
          >
            {i}
          </Pagination.Item>,
        )
      }
    }

    return (
      <div className="d-flex justify-content-end mt-3">
        <Pagination>

          {/* FIRST */}
          <Pagination.Item
            disabled={currentPage === 1}
            onClick={() => handlePageChange(1)}
          >
            First
          </Pagination.Item>

          {/* PREVIOUS */}
          <Pagination.Prev
            disabled={currentPage === 1}
            onClick={() => handlePageChange(currentPage - 1)}
          />

          {/* PAGES */}
          {pages}

          {/* NEXT */}
          <Pagination.Next
            disabled={currentPage === totalPages}
            onClick={() => handlePageChange(currentPage + 1)}
          />

          {/* LAST */}
          <Pagination.Item
            disabled={currentPage === totalPages}
            onClick={() => handlePageChange(totalPages)}
          >
            Last
          </Pagination.Item>

        </Pagination>
      </div>
    )
  }

  return (
    <Row className="justify-content-center">
      <Col className="rounded-md">
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Admin Logs
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>ID</FormLabel>
                <Form.Control
                  type="text"
                  placeholder="Log ID"
                  value={draftFilters.id}
                  onChange={(e) =>
                    setDraftFilters({
                      ...draftFilters,
                      id: e.target.value,
                    })
                  }
                />
              </FormGroup>

              <FormGroup className="col-md-3">
                <FormLabel>Module:</FormLabel>
                <Select
                  options={productOptions}
                  onInputChange={(v) => setSearchCollection(v)}
                  onChange={(option) => {
                    setSelectedOption(option)
                    setDraftFilters({
                      ...draftFilters,
                      logname:
                        option?.label?.split('(')[0].trim() || '',
                    })
                  }}
                  placeholder="Search Module..."
                  isClearable
                  isSearchable
                  value={selectedOption}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Description:</FormLabel>
                <Form.Control type="text" placeholder="Description" value={draftFilters.description} onChange={(e) =>
                  setDraftFilters({
                    ...draftFilters,
                    description: e.target.value,
                  })
                } />
              </FormGroup>

              <FormGroup className="col-md-2">
                <Form.Label>Log Date</Form.Label>
                <Form.Control type="date" value={draftFilters.log_at} onChange={(e) =>
                  setDraftFilters({
                    ...draftFilters,
                    log_at: e.target.value,
                  })
                } />
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-2">
                <Button
                  variant="primary"
                  className="btn bg-primary border border-primary flex-grow-1"
                  onClick={handleSearch}>
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading Logs...</p>
            ) : (
              <>
                <div className="table-responsive">
                  <Table striped className="table mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Module</th>
                        <th>Log</th>
                        <th>User</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products?.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="text-center">
                            No collections found.
                          </td>
                        </tr>
                      ) : (
                        products.map((collection) => (
                          <tr key={collection.id}>
                            <td>{collection.id}</td>
                            <td>
                              {new Date(collection.date).toLocaleString('en-GB', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true,
                              }).toLowerCase()}
                            </td>
                            <td>{collection.module}</td>
                            <td>{collection.log || '—'}</td>
                            <td>
                              {collection.first_name
                                ? `${collection.first_name} - (${collection.user_id ?? 'N/A'})`
                                : collection.user_id ?? 'N/A'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalEntries={totalEntries}
                  limit={limit}
                  showingFrom={
                    products.length === 0
                      ? 0
                      : (currentPage - 1) * limit + 1
                  }
                  showingTo={
                    products.length === 0
                      ? 0
                      : (currentPage - 1) * limit + products.length
                  }
                  onPageChange={(page) => {
                    if (page < 1 || page > totalPages) return
                    fetchLogs(page, appliedFilters)
                  }}
                  onLimitChange={async (newLimit) => {
                    setLimit(newLimit)
                    await fetchLogs(1, appliedFilters, newLimit)
                  }}
                />
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default CollectionList
