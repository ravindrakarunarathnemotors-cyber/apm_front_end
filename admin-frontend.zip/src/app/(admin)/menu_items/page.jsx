import React from 'react'
import NavigationOrder from '@/components/MenuItems/NavigationOrder'

const page = () => {
  return (
    <div>
        <NavigationOrder />
    </div>
  )
}

export default page