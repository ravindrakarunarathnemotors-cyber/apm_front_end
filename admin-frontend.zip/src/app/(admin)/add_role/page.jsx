import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Add Role',
}

const AddRole = dynamic(() => import('./AddRole'), { ssr: false })

export default function AddRolePage() {
  return <AddRole />
}