'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useEffect } from 'react'

import {
  useAddRoleMutation,
  useGetSidebarMenuItemsQuery,
  useGetActivePortalInterfacesQuery,
} from '../../../store/features/apiSlice'
import { Button, Col, Form, FormControl, FormLabel, FormCheck, Row, Alert } from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import { OverlayTrigger, Tooltip } from 'react-bootstrap'

//test 1
const schema = yup.object({
  roleName: yup.string().required('Role Name is required'),
  accessAreas: yup
    .object()
    .test('at-least-one', 'At least one access must be selected', (value) => Object.keys(value).some((mainId) => value[mainId].length > 0)),
  dashboardAccess: yup.object().shape({
    welcomePage: yup.boolean(),
    dashboard: yup.boolean(),
  }),

  portal_interface_id: yup.string().required('Please select a portal interface'),
})



const AddRole = () => {
  const [addRole, { isLoading }] = useAddRoleMutation()
  const { data: sidebarOptions = [], isLoading: sidebarLoading, isError } = useGetSidebarMenuItemsQuery()


  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm({ resolver: yupResolver(schema) })

  const selectedPortalInterfaceId = watch('portal_interface_id')

  const { data: portalData, isLoading: portalLoading, isError: portalError } = useGetActivePortalInterfacesQuery()

  const portalInterfaces = portalData?.interfaces || []

  const selectedPortal = portalInterfaces.find((p) => String(p.interface_id) === String(selectedPortalInterfaceId))

  const isPOSPortal = selectedPortal?.name?.toLowerCase() === 'pos'

  const accessAreas = watch('accessAreas', {})
  const dashboardAccess = watch('dashboardAccess', {})

  const handleMainCategorySelect = (mainId) => {
    const hasSubcategories = sidebarOptions.find((option) => option.id === mainId)?.subcategories.length > 0

    if (hasSubcategories) {
      const isChecked = !accessAreas[mainId]?.length
      const updatedAccessAreas = {
        ...accessAreas,
        [mainId]: isChecked ? sidebarOptions.find((option) => option.id === mainId)?.subcategories.map((sub) => sub.id) || [] : [],
      }
      setValue('accessAreas', updatedAccessAreas)
    } else {
      const isChecked = !accessAreas[mainId]?.length
      const updatedAccessAreas = {
        ...accessAreas,
        [mainId]: isChecked ? [mainId] : [],
      }
      setValue('accessAreas', updatedAccessAreas)
    }
  }

  useEffect(() => {
    if (!isPOSPortal) return

    const posCategory = sidebarOptions.find((c) => c.name.toLowerCase() === 'pos')

    if (!posCategory) return

    // Keep only POS privileges
    setValue('accessAreas', {
      [posCategory.id]: accessAreas[posCategory.id] || [],
    })
  }, [isPOSPortal, sidebarOptions, accessAreas, setValue])

  // Handle Subcategory Selection
  const handleSubcategorySelect = (mainId, subId) => {
    const updatedSubcategories = accessAreas[mainId] || []
    const isChecked = updatedSubcategories.includes(subId)
    const updatedAccessAreas = {
      ...accessAreas,
      [mainId]: isChecked ? updatedSubcategories.filter((id) => id !== subId) : [...updatedSubcategories, subId],
    }
    setValue('accessAreas', updatedAccessAreas)
  }


  //  Submit Function
  const onSubmit = async (data) => {
    const privilegesArray = Object.entries(data.accessAreas)
      .filter(([_, subIds]) => subIds.length > 0)
      .flatMap(([mainId, subIds]) => [mainId, ...subIds])

    const normalizedPrivilegesArray = privilegesArray.map((id) => String(id))

    const uniquePrivilegesArray = [...new Set(normalizedPrivilegesArray)]

    const roleData = {
      roleName: data.roleName,
      privileges: uniquePrivilegesArray,
      dashboardAccess: Object.entries(data.dashboardAccess)
        .filter(([_, value]) => value)
        .map(([key]) => key),
      portal_interface_id: data.portal_interface_id || null,
      client_id: 1,
    }

    // 🔹 Build readable summaries
    const selectedPortal = portalInterfaces.find((p) => String(p.interface_id) === String(data.portal_interface_id))?.name || 'N/A'

    const privilegeCount = uniquePrivilegesArray.length
    const dashboardSummary = roleData.dashboardAccess.length > 0 ? roleData.dashboardAccess.join(', ') : 'None'

    const confirm = await Swal.fire({
      title: 'Confirm Role Creation',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, Add Role',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      html: `
    <div style="text-align:left;font-size:14px">
      <p><strong>Role Name:</strong> ${data.roleName}</p>
      <p><strong>Portal Interface:</strong> ${selectedPortal}</p>
      <p><strong>Privileges Selected:</strong> ${privilegeCount}</p>
     
    </div>
  `,
    })

    if (!confirm.isConfirmed) return

    try {
      const response = await addRole(roleData).unwrap()

      Swal.fire({
        title: 'Success!',
        text: 'Role added successfully!',
        icon: 'success',
        confirmButtonText: 'OK',
      })

      reset({
        roleName: '',
        accessAreas: {},
        dashboardAccess: { welcomePage: false, dashboard: false },
        portal_interface_id: '',
      })

      setValue('accessAreas', {})

      console.log('Role Added:', response)
    } catch (err) {
      
      console.error('Error adding role:', err)
      Swal.fire({
        title: 'Error',
        text: 'Failed to add role. Please try again.',
        icon: 'error',
        confirmButtonText: 'OK',
      })
    }
  }

  return (
    <>
      <Row className="justify-content-left">
        <Col>
          <ComponentContainerCard title="Add New Role">
            <Form onSubmit={handleSubmit(onSubmit)}>
              <Row>
                <Col lg="12" className="my-2 d-flex flex-column gap-3">
                  {/* Role Name Field */}
                  <Row>
                    <Col sm="7">
                      <FormLabel className="col-sm-2 col-form-label text-start">Role Name</FormLabel>
                      <FormControl type="text" {...register('roleName')} placeholder="Enter role name" />
                      <p className="text-danger">{errors.roleName?.message}</p>
                    </Col>
                  </Row>

                  {/* Portal Interface Selector */}
                  <Row className="mb-3">
                    <Col sm="7">
                      <FormLabel className="col-sm-4 col-form-label text-start d-flex align-items-center gap-1">
                        Portal Interface
                        <OverlayTrigger
                          placement="right"
                          overlay={
                            <Tooltip id="portal-interface-tooltip">Select which portal interface is accessible to users with this role.</Tooltip>
                          }>
                          <span style={{ cursor: 'pointer', display: 'inline-flex' }}>
                            <Icon icon="mdi:alert-circle-outline" width={14} height={14} color="#6c757d" />
                          </span>
                        </OverlayTrigger>
                      </FormLabel>

                      <Form.Select {...register('portal_interface_id')} defaultValue="">
                        <option value="">Select Portal Interface</option>

                        {portalLoading && <option disabled>Loading interfaces...</option>}

                        {portalError && <option disabled>Error loading interfaces</option>}

                        {!portalLoading &&
                          portalInterfaces.map((portal) => (
                            <option key={portal.interface_id} value={portal.interface_id}>
                              {portal.name}
                            </option>
                          ))}
                      </Form.Select>

                      <p className="text-danger">{errors.portal_interface_id?.message}</p>
                    </Col>
                  </Row>

                  {/* Privileges Section */}
                  <Row>
                    <FormLabel className="col-sm-4 col-form-label text-start fw-bold fs-5 text-primary mt-0">Privileges</FormLabel>
                    <Col sm="12">
                      {sidebarLoading ? (
                        <p>Loading privileges...</p>
                      ) : sidebarOptions.length === 0 ? (
                        <Alert variant="danger" className="mt-3">
                          ❌ No sidebar menu items found! Please add data.
                        </Alert>
                      ) : (
                        <>
                          {/* --- DESIGN WRAPPER --- */}
                          <div className="permissions-container">

                            {/* PART 1: CORE ACCESS (Sidebar Style Compact) */}
                            <section className="mb-4">
                              <h6 className="text-primary fw-semibold mb-2">Core Access Areas</h6>

                              <div className="row g-2">
                                {sidebarOptions
                                  .filter((item) => {
                                    if (!isPOSPortal) return item.show === true;
                                    return item.name.toLowerCase() === 'pos' && item.show === true;
                                  })
                                  .map((mainCategory) => (
                                    <div key={mainCategory.id} className="col-12">
                                      <div className="border rounded-3 px-3 py-2 bg-white">

                                        <FormCheck
                                          className="fw-semibold small mb-1"
                                          type="checkbox"
                                          label={mainCategory.name}
                                          checked={accessAreas[mainCategory.id]?.length > 0}
                                          onChange={() => handleMainCategorySelect(mainCategory.id)}
                                        />

                                        {mainCategory.subcategories?.length > 0 && (
                                          <div className="ms-3 d-flex flex-wrap gap-2">
                                            {mainCategory.subcategories.map((sub) => (
                                              <FormCheck
                                                key={sub.id}
                                                type="checkbox"
                                                className="small text-muted"
                                                label={sub.name}
                                                checked={accessAreas[mainCategory.id]?.includes(sub.id)}
                                                onChange={() =>
                                                  handleSubcategorySelect(mainCategory.id, sub.id)
                                                }
                                              />
                                            ))}
                                          </div>
                                        )}

                                      </div>
                                    </div>
                                  ))}
                              </div>
                            </section>

                            {/* PART 2: ADDITIONAL PERMISSIONS (Button Privilege Style Grid) */}
                            {!isPOSPortal && (
                              <section>
                                <h6 className="text-secondary fw-semibold mb-2">
                                  Other Permissions
                                </h6>

                                <div className="row g-2">
                                  {sidebarOptions
                                    .filter((item) => {
                                      if (!isPOSPortal) return item.show === false;
                                      return item.name.toLowerCase() === 'pos' && item.show === false;
                                    })
                                    .map((mainCategory) => (
                                      <div key={mainCategory.id} className="col-6 col-md-4 col-lg-3">

                                        <div className="border rounded-3 p-2 h-100 bg-light-subtle">

                                          <FormCheck
                                            className="fw-semibold small mb-1"
                                            type="checkbox"
                                            label={mainCategory.name}
                                            checked={accessAreas[mainCategory.id]?.length > 0}
                                            onChange={() => handleMainCategorySelect(mainCategory.id)}
                                          />

                                          {mainCategory.subcategories?.length > 0 && (
                                            <div className="ms-2 small text-muted d-flex flex-column gap-1">
                                              {mainCategory.subcategories.map((sub) => (
                                                <FormCheck
                                                  key={sub.id}
                                                  type="checkbox"
                                                  label={sub.name}
                                                  checked={accessAreas[mainCategory.id]?.includes(sub.id)}
                                                  onChange={() =>
                                                    handleSubcategorySelect(mainCategory.id, sub.id)
                                                  }
                                                />
                                              ))}
                                            </div>
                                          )}

                                        </div>
                                      </div>
                                    ))}
                                </div>
                              </section>
                            )}
                          </div>
                        </>
                      )}
                    </Col>
                  </Row>
                  <hr></hr>

                  {/* Submit Button */}
                  <Row className="mb-3">
                    <Col sm="10" className="offset-sm-2 text-end">
                      <Button className="btn bg-primary border border-primary" type="submit" disabled={isLoading}>
                        <div className="d-flex align-items-center gap-1 px-3">
                          <Icon icon="material-symbols:group-add-rounded" width="20" height="20" />
                          <span> {isLoading ? 'Adding...' : 'Add Role'}</span>
                        </div>
                      </Button>
                    </Col>
                  </Row>
                </Col>
              </Row>
            </Form>
          </ComponentContainerCard>
        </Col>
      </Row>
    </>
  )
}

export default AddRole
