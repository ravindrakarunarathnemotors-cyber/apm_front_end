'use client'

import React, { useEffect, useState } from 'react'
import {
  Row,
  Col,
  Card,
  Button,
  Modal,
  Form,
  Container,
} from 'react-bootstrap'
import Image from 'next/image'
import { Icon } from '@iconify/react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import {
  useGetPaymentMethodMutation,
  useTogglePaymentStatusMutation,
  useUpdatePaymentMethodMutation,
  useUpdatePaymentMethodsaveMutation,
  useUpdateCommissionMutation,
} from '@/store/features/apiSlice'

const Payment = () => {
  const [paymentMethods, setLogs] = useState([])
  const logsPerPage = 25
  const [loading, setLoading] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editOrderData, setEditOrderData] = useState(null)

  const [formValues, setFormValues] = useState({
    merchant_id: '',
    merchantSecret: '',
    sandbox: false,
    account_number: '',
    notes: '',
    api_key: '',
    base_url: '',
    public_key: '',
    private_key: '',
  })

  const [commissionState, setCommissionState] = useState({})
  const [commissionData, setCommissionData] = useState({})

  const [fetchFilteredOrders] = useGetPaymentMethodMutation()
  const [togglePaymentStatus] = useTogglePaymentStatusMutation()
  const [updateConfigData] = useUpdatePaymentMethodMutation()
  const [updateConfigData2] = useUpdatePaymentMethodsaveMutation()
  // const [updateCommission] = useUpdateCommissionMutation()
  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredOrders({ page, limit: logsPerPage }).unwrap()
      setLogs(res.paymentMethods || [])
    } catch (err) {
      console.error('Failed to fetch:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  useEffect(() => {
    const commissionStateMap = {};
    const commissionDataMap = {};

    paymentMethods.forEach((m) => {

      commissionStateMap[m.payment_method_id] = m.commission_status ?? false;
      commissionDataMap[m.payment_method_id] = {
        transaction_fixed_fee: m.transaction_fixed_fee || 0,
        transaction_fee: m.transaction_fee || 0,
      };
    });

    setCommissionState(commissionStateMap);
    setCommissionData(commissionDataMap);
  }, [paymentMethods]);

  const handleToggleStatus = async (payment_method_id) => {
    const method = paymentMethods.find((m) => m.payment_method_id === payment_method_id)
    if (!method) return

    const newStatus = method.status === 'active' ? 'inactive' : 'active'
    

    const result = await Swal.fire({
      title: `Confirm ${newStatus === 'active' ? 'Activate' : 'Deactivate'} Status`,
      html: `Are you sure you want to <strong>${newStatus}</strong> <br/><code>${method.method_name}</code>?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus}`,
    })

    if (!result.isConfirmed) return

    try {
      await togglePaymentStatus({ payment_method_id, status: newStatus, user_id: 1 }).unwrap()
      Swal.fire('Success', 'Status updated successfully!', 'success')
      setLogs((prev) =>
        prev.map((m) =>
          m.payment_method_id === payment_method_id ? { ...m, status: newStatus } : m
        )
      )
    } catch (err) {
      console.error('Toggle failed:', err)
      Swal.fire('Error', 'Status update failed.', 'error')
    }
  }

  const handleSaveConfig = async () => {
    const id = editOrderData.payment_method_id

    const hasApiFields =
      id !== 10 && (
        formValues.merchant_id ||
        formValues.merchantSecret ||
        formValues.sandbox
      )

    const payload = {
      payment_method_id: id,
      method_name: editOrderData.method_name,
      status: editOrderData.status,
      

      commission: {
        enabled: commissionState[id] ?? false,
        transaction_fixed_fee: Number(
          commissionData[id]?.transaction_fixed_fee || 0
        ),
        transaction_fee: Number(
          commissionData[id]?.transaction_fee || 0
        ),
      },
    }

    if (id === 10) {
      payload.api_array = {
        api_key: formValues.api_key || '',
        base_url: formValues.base_url || '',
        public_key: formValues.public_key || '',
        merchant_id: formValues.merchant_id || '',
        private_key: formValues.private_key || '',
      }

      payload.payment_intraduction = [
        formValues.notes || ''
      ]
    }

    else if (hasApiFields) {
  if (id === 11) {
    payload.api_array = {
      merchant_id: formValues.merchant_id || '',
      merchantSecret: formValues.merchantSecret || '',
    }
  } else {
    payload.api_array = {
      merchant_id: formValues.merchant_id || '',
      merchantSecret: formValues.merchantSecret || '',
      sandbox: formValues.sandbox === true,
    }
  }
}

    else if (formValues.account_number || formValues.notes) {
      payload.account_number = [
        `details:${formValues.account_number || ''}`,
        `notes:${formValues.notes || ''}`,
      ]
    }

    try {
      await updateConfigData(payload).unwrap()
      Swal.fire('Success', 'Config updated successfully!', 'success')
      setShowEditModal(false)
      fetchLogs(1)
    } catch (err) {
      console.error('Update failed:', err)
      Swal.fire('Error', 'Update failed', 'error')
    }
  }

  const handleSaveConfig2 = async () => {
    const hasApiFields =
      formValues.merchant_id ||
      formValues.merchantSecret ||
      formValues.sandbox

    const id = editOrderData.payment_method_id

    const payload = {
      payment_method_id: id,
      method_name: editOrderData.method_name,
      status: 'active',
      

      // ✅ ADD THIS
      commission: {
        enabled: commissionState[id] ?? false,
        transaction_fixed_fee: Number(
          commissionData[id]?.transaction_fixed_fee || 0
        ),
        transaction_fee: Number(
          commissionData[id]?.transaction_fee || 0
        ),
      },
    }

    if (hasApiFields) {
      payload.api_array = {
        merchant_id: formValues.merchant_id || '',
        merchantSecret: formValues.merchantSecret || '',
        sandbox: formValues.sandbox === true,
      }
    } else if (formValues.account_number) {
      payload.account_number = formValues.account_number
    }

    if (id === 10) {
      payload.payment_intraduction = [
        formValues.notes || ''
      ]
    }

    try {
      await updateConfigData2(payload).unwrap()
      Swal.fire('Success', 'Config updated successfully!', 'success')
      setShowEditModal(false)
      fetchLogs(1)
    } catch (err) {
      console.error('Update failed:', err)
      Swal.fire('Error', 'Update failed', 'error')
    }
  }



  const getPaymentLabel = (methodName) => {
    const name = methodName?.toLowerCase()
    switch (name) {
      case 'payhere':
        return 'Card Payment (PayHere)'
      case 'stripe':
        return 'Credit Card (Stripe)'
      case 'cod':
        return 'COD'
      case 'bank transfer':
        return 'Bank Transfer'
      default:
        return name ? name.charAt(0).toUpperCase() + name.slice(1) : ''
    }
  }

  return (
    <>
      <Container fluid>
        <Row className="mb-3">
          <Col>
            <h4>Payment Gateway</h4>
          </Col>
        </Row>

        <Row className="gy-4">
          {paymentMethods.length === 0 ? (
            <div className="alert alert-warning text-center">No Payment Methods Found</div>
          ) : (
            paymentMethods.map((method) => (
              <Col
                key={method.payment_method_id}
                xs={12}
                sm={6}
                md={6}
                lg={4}
                xl={3}
              >
                <Card className="mb-0 h-100">
                  <Card.Body className="pt-4 pb-3 px-4 d-flex flex-column justify-content-between align-items-center text-center">

                    <div className="mb-3">
                      {method.logo ? (
                        <Image
                          src={method.logo}
                          alt="Logo"
                          width={100}
                          height={80}
                          style={{ objectFit: 'contain', maxHeight: '80px', width: 'auto' }}
                        />
                      ) : (
                        <span className="text-muted">No Image</span>
                      )}
                    </div>

                    <hr style={{ width: '100%', margin: '0 0 1rem 0' }} />

                    <div className="w-100">
                      <h5
                        className="fw-bold mb-3"
                        style={{
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                        }}
                      >
                        {getPaymentLabel(method.method_name)}
                      </h5>
                      <div className="d-flex flex-column gap-2 align-items-center">
                        <span
                          role="button"
                          className="d-flex align-items-center"
                          title={method.status === 'active' ? 'Active' : 'Inactive'}
                          onClick={() => handleToggleStatus(method.payment_method_id)}
                        >
                          <IconifyIcon
                            icon={
                              method.status === 'active'
                                ? 'mdi:toggle-switch'
                                : 'mdi:toggle-switch-off'
                            }
                            style={{ fontSize: '40px' }}
                            className={method.status === 'active' ? 'text-success' : 'text-danger'}
                          />
                          <span className="ms-2 fw-semibold">
                            {method.status.charAt(0).toUpperCase() + method.status.slice(1)}
                          </span>
                        </span>

                        <span
                          role="button"
                          className="d-flex align-items-center"
                          title="API Config"
                          style={{ cursor: 'pointer' }}
                          onClick={() => {
                            const apiMap = {}
                            if (method.api_array && typeof method.api_array === 'object') {
                              Object.entries(method.api_array).forEach(([key, value]) => {
                                apiMap[key] = value
                              })
                            }

                            const introMap = {}
                            let plainDescription = ''

                            if (Array.isArray(method.payment_intraduction)) {
                              method.payment_intraduction.forEach((item) => {
                                const clean = item.replace(/'/g, '').trim()

                                if (clean.includes(':')) {
                                  const [key, ...rest] = clean.split(':')
                                  introMap[key.trim()] = rest.join(':').trim()
                                } else {

                                  plainDescription = clean
                                }
                              })
                            }

                            setEditOrderData(method)
                            setFormValues({
                              merchant_id: apiMap['merchant_id'] || '',
                              merchantSecret: apiMap['merchantSecret'] || '',
                              sandbox: apiMap['sandbox'] === true || apiMap['sandbox'] === 'true',
                              api_key: apiMap['api_key'] || '',
                              base_url: apiMap['base_url'] || '',
                              public_key: apiMap['public_key'] || '',
                              private_key: apiMap['private_key'] || '',

                              account_number: introMap['details'] || '',
                              notes:
                                introMap['notes'] ||
                                plainDescription ||
                                '',
                            })

                            setShowEditModal(true)
                          }}
                        >



                          <IconifyIcon
                            icon="mdi:cog-outline"
                            style={{ fontSize: '28px' }}
                            className="text-primary"
                          />
                          <span className="ms-2 fw-semibold">Config</span>
                        </span>
                      </div>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))
          )}
        </Row>
      </Container>


      {/* ================= CONFIG MODAL ================= */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered scrollable size={editOrderData?.payment_method_id === 10 ? "lg" : undefined}>
        <Modal.Header closeButton>
          <Modal.Title>
            Config - {getPaymentLabel(editOrderData?.method_name)}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>

            {/* ================= API CONFIG ================= */}
            {(editOrderData?.payment_method_id === 1 || editOrderData?.payment_method_id === 2) && (
              <>
                <Form.Group className="mb-3">
                  <Form.Label>Merchant ID</Form.Label>
                  <Form.Control
                    value={formValues.merchant_id}
                    onChange={(e) =>
                      setFormValues({ ...formValues, merchant_id: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Merchant Secret</Form.Label>
                  <Form.Control
                    value={formValues.merchantSecret}
                    onChange={(e) =>
                      setFormValues({ ...formValues, merchantSecret: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Sandbox</Form.Label>
                  <div
                    onClick={() =>
                      setFormValues((prev) => ({
                        ...prev,
                        sandbox: !prev.sandbox,
                      }))
                    }
                    style={{ cursor: 'pointer' }}
                  >
                    <IconifyIcon
                      icon={
                        formValues.sandbox
                          ? 'mdi:toggle-switch'
                          : 'mdi:toggle-switch-off'
                      }
                      className={formValues.sandbox ? 'text-success' : 'text-danger'}
                      style={{ fontSize: 40 }}
                    />
                  </div>
                </Form.Group>
              </>
            )}
            {[11].includes(editOrderData?.payment_method_id) && (
              <>
                <Form.Group className="mb-3">
                  <Form.Label>Merchant ID</Form.Label>
                  <Form.Control
                    value={formValues.merchant_id}
                    onChange={(e) =>
                      setFormValues({ ...formValues, merchant_id: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Merchant Secret</Form.Label>
                  <Form.Control
                    value={formValues.merchantSecret}
                    onChange={(e) =>
                      setFormValues({ ...formValues, merchantSecret: e.target.value })
                    }
                  />
                </Form.Group>
              </>
            )}

            {editOrderData?.payment_method_id === 10 && (
              <>
                <Form.Group className="mb-3">
                  <Form.Label>Merchant ID</Form.Label>
                  <Form.Control
                    value={formValues.merchant_id}
                    onChange={(e) =>
                      setFormValues({ ...formValues, merchant_id: e.target.value })
                    }
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>API Key</Form.Label>
                  <Form.Control
                    value={formValues.api_key || ''}
                    onChange={(e) =>
                      setFormValues({ ...formValues, api_key: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Environment</Form.Label>

                  <div>
                    <Form.Check
                      inline
                      type="radio"
                      label="QA"
                      name="baseUrl"
                      value="qa"
                      checked={formValues.base_url === "qa"}
                      onChange={() =>
                        setFormValues({ ...formValues, base_url: "qa" })
                      }
                    />

                    <Form.Check
                      inline
                      type="radio"
                      label="Production"
                      name="baseUrl"
                      value="production"
                      checked={formValues.base_url === "production"}
                      onChange={() =>
                        setFormValues({ ...formValues, base_url: "production" })
                      }
                    />
                  </div>
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Public Key</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={formValues.public_key || ''}
                    onChange={(e) =>
                      setFormValues({ ...formValues, public_key: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Private Key</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={formValues.private_key || ''}
                    onChange={(e) =>
                      setFormValues({ ...formValues, private_key: e.target.value })
                    }
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Koko Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={formValues.notes || ''}
                    onChange={(e) =>
                      setFormValues({
                        ...formValues,
                        notes: e.target.value,
                      })
                    }
                  />
                </Form.Group>
              </>
            )}



            {/* ================= ACCOUNT DETAILS ================= */}
            {(editOrderData?.payment_method_id === 3 ||
              editOrderData?.payment_method_id === 4 ||
              editOrderData?.payment_method_id === 5) && (
                <>
                  <Form.Group className="mb-3">
                    <Form.Label>Account Details</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={formValues.account_number || ''}
                      onChange={(e) =>
                        setFormValues({ ...formValues, account_number: e.target.value })
                      }
                    />
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>Notes</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={formValues.notes || ''}
                      onChange={(e) =>
                        setFormValues({ ...formValues, notes: e.target.value })
                      }
                    />
                  </Form.Group>
                </>
              )}

            {/* ================= COMMISSION SETTINGS ================= */}
           

          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>

          <Button variant="primary" onClick={handleSaveConfig}>
            Save
          </Button>

          {(editOrderData?.payment_method_id === 1 ||
            editOrderData?.payment_method_id === 2) && (
              <Button variant="success" onClick={handleSaveConfig2}>
                Save & Activate
              </Button>
            )}
        </Modal.Footer>
      </Modal>


    </>
  )
}

export default Payment