'use client'

import { useState, useEffect } from 'react'
import { Row, Col, Form, FormLabel, FormControl, Button, Card, ListGroup } from 'react-bootstrap'

const QuotationSettingsTab = ({ onSubmit, defaultValues }) => {
  const [termsText, setTermsText] = useState('')

  /* ------------------ Load existing data ------------------ */
  useEffect(() => {
    if (!defaultValues?.terms_conditions_quotations) return

    try {
      const parsed =
        typeof defaultValues.terms_conditions_quotations === 'string'
          ? JSON.parse(defaultValues.terms_conditions_quotations)
          : defaultValues.terms_conditions_quotations

      if (Array.isArray(parsed)) {
        setTermsText(parsed.join('\n'))
      }
    } catch (err) {
      console.error('Invalid terms_conditions_quotations JSON', err)
    }
  }, [defaultValues])

  /* ------------------ Derived preview ------------------ */
  const bulletPoints = termsText
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)

  /* ------------------ Submit ------------------ */
  const handleFormSubmit = (e) => {
    e.preventDefault()

    onSubmit({
      terms_conditions_quotations: bulletPoints,
    })
  }

  return (
    <Form onSubmit={handleFormSubmit} className="my-3">
      <Row className="gy-4 gx-4">
        <Col md={12}>
          <Card className="shadow-sm h-100">
            <Card.Header className="fw-semibold p-2 fs-5">Quotation Terms & Conditions</Card.Header>

            <Card.Body className="p-3">
              <FormLabel className="mb-1">Enter Terms & Conditions</FormLabel>

              <FormControl
                as="textarea"
                rows={5}
                placeholder="Write terms and conditions here. Use a new line for each point."
                value={termsText}
                onChange={(e) => setTermsText(e.target.value)}
                style={{  width: '100%' }}
              />

              <small className="text-muted d-block mt-2">Each new line will be saved and shown as a bullet point on quotations.</small>

              <div className="mt-3">
                <strong>Preview:</strong>
                <ListGroup className="mt-2">
                  {bulletPoints.length > 0 ? (
                    bulletPoints.map((term, i) => (
                      <ListGroup.Item key={i} className="py-2">
                        • {term}
                      </ListGroup.Item>
                    ))
                  ) : (
                    <div className="text-muted small">No terms added yet.</div>
                  )}
                </ListGroup>
              </div>
              <div className="text-end mt-3">
                <Button className="btn bg-primary border border-primary px-3"s type="submit">Save Quotation Settings</Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Form>
  )
}

export default QuotationSettingsTab
