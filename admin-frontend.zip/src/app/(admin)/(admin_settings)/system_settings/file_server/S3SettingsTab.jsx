'use client'
import { useState } from 'react'
import { Row, Col, Form, FormLabel, FormControl, Button, InputGroup } from 'react-bootstrap'
import { Icon } from '@iconify/react'

const S3SettingsTab = ({ register, handleSubmit, onSubmit }) => {
  const [showSecret, setShowSecret] = useState(false)

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3 p-2">
        <Col md={6}>
          <FormLabel>Region</FormLabel>
          <FormControl
            type="text"
            placeholder="us-east-1"
            {...register('s3_region')}
          />
        </Col>

        <Col md={6}>
          <FormLabel>Endpoint</FormLabel>
          <FormControl
            type="text"
            placeholder="https://s3.amazonaws.com"
            {...register('s3_endpoint')}
          />
        </Col>

        <Col md={6}>
          <FormLabel>Access Key</FormLabel>
          <FormControl
            type="password"
            placeholder="********"
            {...register('s3_access_key')}
          />
        </Col>

        <Col md={6}>
  <FormLabel>Secret Key</FormLabel>
  <FormControl
    type="password"
    placeholder="********"
    {...register('s3_secret_key')}
  />
</Col>


        <Col md={6}>
          <FormLabel>Bucket Name</FormLabel>
          <FormControl
            type="text"
            placeholder="my-bucket-name"
            {...register('s3_bucket_name')}
          />
        </Col>

        <Col md={6}>
          <FormLabel>Public Key / Public URL</FormLabel>
          <FormControl
            type="text"
            placeholder="https://cdn.example.com"
            {...register('s3_public_key')}
          />
        </Col>

        <div className="text-end mt-4">
          <Button
            className="btn bg-primary border border-primary px-3"
            type="submit"
          >
            Save File Server
          </Button>
        </div>
      </Row>
    </Form>
  )
}

export default S3SettingsTab
