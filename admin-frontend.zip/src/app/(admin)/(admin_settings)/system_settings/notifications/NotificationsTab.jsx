// src/components/settings/NotificationsSettingsPage.jsx
'use client'
import Swal from 'sweetalert2'
import { useEffect, useMemo, useState } from 'react'
import { useForm, useWatch } from 'react-hook-form'
import { Row, Col, FormCheck, FormLabel, Form, Button, FormControl, Alert, Spinner } from 'react-bootstrap'
import { useGetNotificationSettingsQuery, useUpdateNotificationSettingsMutation } from '@/store/features/new_update' // <-- hooks from your RTK Query slice
import useLogout from '@/hooks/useLogout'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'

// at top
const SL_MOBILE_RE = /^94\d{9}$/

const normalizeMobile = (n = '') => {
  let x = String(n).replace(/^\+/, '') // drop leading +
  if (/^0\d{9}$/.test(x)) return '94' + x.slice(1) // 0XXXXXXXXX -> 94XXXXXXXXX
  return x
}

const normalizeMobileList = (v = '') => sanitizeCommaList(v).split(',').filter(Boolean).map(normalizeMobile).join(',')

const sanitizeCommaList = (value) => {
  if (!value) return ''
  return value
    .split(',')
    .map((v) => v.trim())
    .filter((v) => v !== '')
    .join(',')
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const toFormDefaults = (api = {}) => ({
  // toggles
  new_client_sms_status: !!api.new_client_sms_status,
  new_client_email_status: !!api.new_client_email_status,
  new_client_activation_sms_status: !!api.new_client_activation_sms_status,
  new_client_activation_email_status: !!api.new_client_activation_email_status,
  admin_alert_sms_status: !!api.admin_alert_sms_status,
  admin_alert_email_status: !!api.admin_alert_email_status,
  // comma-separated inputs
  notification_mobile_numbers: (api.notification_mobile_numbers || []).join(','),
  notification_emails: (api.notification_emails || []).join(','),
})

const toApiPayload = (values) => {
  const mobilesRaw = sanitizeCommaList(values.notification_mobile_numbers || '')
  const emailsRaw = sanitizeCommaList(values.notification_emails || '')
  return {
    ...values,
    notification_mobile_numbers: mobilesRaw ? mobilesRaw.split(',') : [],
    notification_emails: emailsRaw ? emailsRaw.split(',').filter((e) => emailRegex.test(e)) : [],
  }
}

export default function NotificationsSettingsPage() {
  const { data, isFetching, isError, refetch } = useGetNotificationSettingsQuery()
  const [updateSettings, { isLoading: isSaving }] = useUpdateNotificationSettingsMutation()
  const [flash, setFlash] = useState({ type: '', msg: '' })

  const defaultValues = useMemo(() => toFormDefaults(data), [data])
  const {
    register,
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({ defaultValues })

  // keep form in sync with server data
  useEffect(() => {
    if (data) reset(toFormDefaults(data))
  }, [data, reset])

  // watch toggles (for conditional inputs)
  const admSMS = useWatch({ control, name: 'admin_alert_sms_status' })
  const admEmail = useWatch({ control, name: 'admin_alert_email_status' })

  const onSubmit = async (values, isRetry = false) => {
    setFlash({ type: '', msg: '' })

    try {
      const payload = toApiPayload(values)
      await updateSettings(payload).unwrap()

      // ✅ Show success notification
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Settings saved successfully.',
        timer: 2000,
        timerProgressBar: true,
        showConfirmButton: false,
      })

      // ✅ Refetch the latest settings
      refetch()
    } catch (error) {
      const status = error?.status
      const message = 'Your session has expired!'

      if ((status === 401 || status === 403) && !isRetry) {
        const refreshToken = localStorage.getItem('refresh_token')

        if (refreshToken) {
          try {
            const refreshResponse = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', refreshResponse.access_token)

            // ✅ Retry with refreshed token
            return onSubmit(values, true)
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        Swal.fire({
          title: 'Session Expired',
          text: message,
          icon: 'warning',
          confirmButtonText: 'OK',
        }).then(() => {
          Logout()
        })
      }
    }
  }

  if (isFetching && !data) {
    return (
      <div className="d-flex align-items-center gap-2">
        <Spinner size="sm" /> <span>Loading settings…</span>
      </div>
    )
  }

  if (isError) {
    return <Alert variant="danger">Couldn’t load settings.</Alert>
  }

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      {flash.msg && <Alert variant={flash.type}>{flash.msg}</Alert>}

      <Row className="gy-4 p-2">
        {/* New Client Registration */}
        <Col md={12} className='mb-1'>
          <div className="pb-2  fw-semibold">New Client Registration</div>
          <Row className="g-3 align-items-center">
            <Col sm={6}>
              <FormCheck type="switch" id="new_client_sms_status" label="Enable SMS" {...register('new_client_sms_status')} />
            </Col>
            <Col sm={6}>
              <FormCheck type="switch" id="new_client_email_status" label="Enable Email" {...register('new_client_email_status')} />
            </Col>
          </Row>
        </Col>

        {/* New Client Activation */}
        <Col md={12} className='mb-1'>
          <div className="pb-2 fw-semibold">New Client Activation</div>
          <Row className="g-3 align-items-center">
            <Col sm={6}>
              <FormCheck type="switch" id="new_client_activation_sms_status" label="Enable SMS" {...register('new_client_activation_sms_status')} />
            </Col>
            <Col sm={6}>
              <FormCheck
                type="switch"
                id="new_client_activation_email_status"
                label="Enable Email"
                {...register('new_client_activation_email_status')}
              />
            </Col>
          </Row>
        </Col>

        {/* Admin Alert */}
        <Col md={12} className='mb-1'>
          <div className="pb-2 fw-semibold">Admin Alert</div>
          <Row className="g-3 align-items-center">
            <Col sm={12}>
              <FormCheck type="switch" id="admin_alert_sms_status" label="Enable SMS" {...register('admin_alert_sms_status')} />
              {/* Inputs visible ONLY when Admin toggles are ON */}
              {admSMS && (
                <Col md={12} className="mt-1">
                  <FormLabel>Enter Mobile Number(s)</FormLabel>
                  <FormControl
                    type="text"
                    placeholder="e.g., 9477xxxxxxxx or multiple: 9477xxxxxxxx,9471xxxxxxxx"
                    isInvalid={!!errors.notification_mobile_numbers}
                    {...register('notification_mobile_numbers', {
                      setValueAs: normalizeMobileList, // auto-normalize on change
                      validate: (v) => {
                        if (!admSMS || !v) return true
                        const list = v.split(',').filter(Boolean)
                        const bad = list.find((n) => !SL_MOBILE_RE.test(n))
                        return bad ? 'Each mobile must be exactly 11 digits starting with 94 (e.g., 94773671596).' : true
                      },
                    })}
                  />
                  <div className="invalid-feedback">{errors.notification_mobile_numbers?.message}</div>
                </Col>
              )}
            </Col>
            <Col sm={12}>
              <FormCheck type="switch" id="admin_alert_email_status" label="Enable Email" {...register('admin_alert_email_status')} />
              {admEmail && (
                <Col md={12} className="mt-1">
                  <FormControl
                    type="text"
                    placeholder="Enter emails"
                    isInvalid={!!errors.notification_emails}
                    {...register('notification_emails', {
                      setValueAs: sanitizeCommaList,
                      validate: (v) => {
                        if (!admEmail || !v) return true
                        const list = v.split(',')
                        return list.every((email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) || 'One or more emails are invalid'
                      },
                    })}
                  />

                  <div className="invalid-feedback">{errors.notification_emails?.message}</div>
                </Col>
              )}
            </Col>
          </Row>
        </Col>

        {(admSMS || admEmail) && (
          <Col md={12}>
            <div className="mt-2 fw-bold " style={{ fontSize: '0.85rem' }}>
              ⚠️ Do not use spaces between numbers or emails. Separate multiple entries only with commas.
            </div>
          </Col>
        )}
      <div className="text-end ">
        <Button className="btn bg-primary border border-primary px-3" type="submit" disabled={isSaving}>
          {isSaving ? 'Saving…' : 'Save Notification Settings'}
        </Button>
      </div>
      </Row>

    </Form>
  )
}
