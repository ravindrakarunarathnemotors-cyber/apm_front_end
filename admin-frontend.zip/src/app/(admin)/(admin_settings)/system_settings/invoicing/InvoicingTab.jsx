'use client'

import { useEffect } from 'react'
import { Row, Col, Form, FormLabel, FormControl, Button, Card, ListGroup } from 'react-bootstrap'

/**
 * Props:
 * - register, handleSubmit, onSubmit, watch, defaultValues, setValue
 *
 * Behavior:
 * - On mount / when defaultValues change, convert whatever comes from DB
 *   (array | JSON string | plain string) to textarea lines.
 * - On submit, convert textarea lines back to a JSON array and pass to onSubmit.
 */
const InvoicingSettingsTab = ({ register, handleSubmit, onSubmit, watch, defaultValues, setValue }) => {
  // Normalize DB value into textarea lines
  useEffect(() => {
    if (defaultValues && Object.prototype.hasOwnProperty.call(defaultValues, 'terms_conditions')) {
      const v = defaultValues.terms_conditions
      let textValue = ''

      if (Array.isArray(v)) {
        // jsonb array -> lines
        textValue = v.join('\n')
      } else if (typeof v === 'string') {
        // could be JSON string or plain text
        try {
          const parsed = JSON.parse(v)
          textValue = Array.isArray(parsed) ? parsed.join('\n') : v
        } catch {
          // plain string -> keep as-is
          textValue = v
        }
      } else if (v == null) {
        textValue = ''
      } else {
        // any other type -> stringify safely
        textValue = String(v)
      }

      setValue('terms_conditions', textValue, { shouldDirty: false })
    }
  }, [defaultValues, setValue])

  // Watch current value (may be string or array depending on timing)
  const termsText = watch ? watch('terms_conditions') : ''

  // Coerce to safe string before splitting
  const safeText = Array.isArray(termsText) ? termsText.join('\n') : typeof termsText === 'string' ? termsText : String(termsText ?? '')

  const bulletPoints = safeText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line !== '')

  // We ONLY transform terms_conditions here; all other fields pass through
  const customSubmit = (data) => {
    const raw = data.terms_conditions

    const termsArray = Array.isArray(raw)
      ? raw.map((x) => String(x).trim()).filter(Boolean)
      : String(raw ?? '')
          .split('\n')
          .map((line) => line.trim())
          .filter((line) => line !== '')

    // Send JSON array for jsonb column
    onSubmit({ ...data, terms_conditions: termsArray })
  }

  return (
    <Form onSubmit={handleSubmit(customSubmit)} className="mt-3">
      <Row className="gy-4 gx-4">
        <Col md={12}>
          <Card className="shadow-sm h-100">
            <Card.Header className="fw-semibold p-2 fs-5">Invoice Terms & Conditions</Card.Header>
            <Card.Body className="p-3">
              <FormLabel className="mb-1 text-center">Enter Terms & Conditions</FormLabel>
              <FormControl
                as="textarea"
                rows={5}
                placeholder="Write terms and conditions here. Use a new line for each point."
                {...register('terms_conditions')}
                style={{ width: '100%' }}
              />
              <small className="text-muted d-block mt-2">Each new line will be saved and shown as a bullet point on invoices.</small>

              <div className="mt-3">
                <strong>Preview:</strong>
                <ListGroup className="mt-2">
                  {bulletPoints.length > 0 ? (
                    bulletPoints.map((term, i) => (
                      <ListGroup.Item key={i} className="py-2">
                        • {term}
                      </ListGroup.Item>
                    ))
                  ) : (
                    <div className="text-muted small">No terms added yet.</div>
                  )}
                </ListGroup>
              </div>
              <div className="text-end mt-3">
                <Button className="btn bg-primary border border-primary flex-grow-1" type="submit">
                  Save Invoicing Settings
                </Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Form>
  )
}

export default InvoicingSettingsTab
