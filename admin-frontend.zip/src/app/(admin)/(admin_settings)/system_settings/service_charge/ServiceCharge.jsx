'use client'

import React, { useEffect, useState } from 'react'
import {
  Row,
  Col,
  Form,
  FormCheck,
  FormLabel,
  FormControl,
  Button,
} from 'react-bootstrap'
import Swal from 'sweetalert2'

import {
  useGetServiceChargeQuery,
  useUpdateServiceChargeMutation,
} from '@/store/features/apiSlice'

const ServiceCharge = () => {
  const [serviceEnabled, setServiceEnabled] = useState(false)
  const [serviceCharge, setServiceCharge] = useState('')
  const [loading, setLoading] = useState(false)

  const {
    data,
    isLoading: isFetchLoading,
  } = useGetServiceChargeQuery()

  const [updateServiceCharge] =
    useUpdateServiceChargeMutation()

  useEffect(() => {
    if (data) {
      setServiceEnabled(data.has_service_charge)
      setServiceCharge(data.service_charge || '')
    }
  }, [data])

  const handleToggleChange = async (e) => {
    const checked = e.target.checked

    setServiceEnabled(checked)

    // Immediately update backend when disabled
    if (!checked) {
      try {
        await updateServiceCharge({
          has_service_charge: false,
          service_charge: Number(serviceCharge),
        }).unwrap()

        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Service charge disabled successfully!',
        })
      } catch (error) {
        console.error(error)

        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Failed to update service charge.',
        })
      }
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    setLoading(true)

    try {
      await updateServiceCharge({
        has_service_charge: true,
        service_charge: Number(serviceCharge),
      }).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Service charge updated successfully!',
      })
    } catch (error) {
      console.error(error)

      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to update service charge.',
      })
    }

    setLoading(false)
  }

  if (isFetchLoading) {
    return <p>Loading...</p>
  }

  return (
    <Form onSubmit={handleSubmit}>
      <Row className="gy-4 p-2">
        <Col md={12}>
          <FormLabel>
            <strong>Service Charge</strong>
          </FormLabel>

          <FormCheck
            type="switch"
            label="Enable Service Charge"
            checked={serviceEnabled}
            onChange={handleToggleChange}
            disabled={loading}
          />
        </Col>

        {serviceEnabled && (
          <>
            <Col md={4}>
              <FormLabel>Service Charge (%)</FormLabel>

              <FormControl
                type="number"
                min="0"
                max="100"
                step="0.01"
                value={serviceCharge}
                required
                onChange={(e) =>
                  setServiceCharge(e.target.value)
                }
              />
            </Col>

            <Col md={12}>
              <div className="text-end mt-4">
                <Button
                  type="submit"
                  disabled={loading}
                  className="btn bg-primary border border-primary px-3"
                >
                  {loading
                    ? 'Saving...'
                    : 'Save Service Charge'}
                </Button>
              </div>
            </Col>
          </>
        )}
      </Row>
    </Form>
  )
}

export default ServiceCharge