'use client';

import Swal from 'sweetalert2';
import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import {
  Form,
  FormCheck,
  FormGroup,
  FormControl,
  FormLabel,
  Button,
  Row,
  Col,
} from 'react-bootstrap';

import {
  useGetTrackingSettingsQuery,
  useUpdateTrackingSettingsMutation,
  useRefreshTokenMutation,
} from '@/store/features/new_update'; // adjust path

const defaultValues = {
  enabled_google: false,
  google_mode: 'gtm',
  gtm_container_id: '',
  ga4_measurement_id: '',
  enabled_meta: false,
  meta_pixel_id: '',
  meta_capi_enabled: false,
  meta_capi_access_token: '',
};

export default function TrackingSettingsForm() {
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    setError,
    clearErrors,
    formState: { isSubmitting, errors },
  } = useForm({ defaultValues });

  // RTK Query hooks
 const {
  data: settingsData,
  isLoading,
  isError,
  refetch,
} = useGetTrackingSettingsQuery(); // <-- call the hook


  const [updateSettings, { isLoading: isSaving }] = useUpdateTrackingSettingsMutation();

  const enabledGoogle = watch('enabled_google');
  const googleMode = watch('google_mode');
  const enabledMeta = watch('enabled_meta');
  const metaCapiEnabled = watch('meta_capi_enabled');

  // Reset form when data loaded
  useEffect(() => {
    if (settingsData) {
      reset({ ...defaultValues, ...settingsData });
      clearErrors();
    }
  }, [settingsData, reset, clearErrors]);

  const validateFields = (data) => {
    const ga4Regex = /^G-[A-Z0-9]+$/;
    const gtmRegex = /^GTM-[A-Z0-9]+$/;
    const pixelRegex = /^\d{15,}$/;

    clearErrors();

    if (data.enabled_google) {
      if (data.google_mode === 'gtm' && !gtmRegex.test(data.gtm_container_id?.trim())) {
        setError('gtm_container_id', { type: 'manual', message: 'Invalid GTM Container ID' });
        return false;
      }
      if (data.google_mode === 'ga4' && !ga4Regex.test(data.ga4_measurement_id?.trim())) {
        setError('ga4_measurement_id', { type: 'manual', message: 'Invalid GA4 Measurement ID' });
        return false;
      }
    }

    if (data.enabled_meta && !pixelRegex.test(data.meta_pixel_id?.trim())) {
      setError('meta_pixel_id', { type: 'manual', message: 'Invalid Meta Pixel ID' });
      return false;
    }

    if (data.meta_capi_enabled && !data.meta_capi_access_token?.trim()) {
      setError('meta_capi_access_token', { type: 'manual', message: 'Meta CAPI Access Token is required' });
      return false;
    }

    return true;
  };

const onSubmit = async (data) => {
  // Run client-side validation
  const isValid = validateFields(data);
  if (!isValid) return;

  try {
    // Await the mutation and unwrap for direct access to success response or error throw
    const response = await updateSettings(data).unwrap();

    // ✅ Optional: Log or check response if needed
    console.log('Success response:', response);

    // ✅ Show success notification
    Swal.fire({
      icon: 'success',
      title: 'Success',
      text: response?.message || 'Settings saved successfully.',
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
    });

    // ✅ Refetch the latest settings
    refetch();
  } catch (error) {
    console.error('Error saving settings:', error);

    // ❌ Show error alert if mutation fails
    Swal.fire({
      icon: 'error',
      title: 'Error',
      text: error?.data?.message || 'Error saving settings.',
      confirmButtonText: 'OK',
    });
  }
};


  return (
    <Form  onSubmit={handleSubmit(onSubmit)}>
      {isLoading && <p>Loading settings...</p>}
      {isError && <p className="text-danger">Failed to load settings.</p>}

      <Row className="gy-4 p-2">
        {/* Google Analytics */}
        <Col md={12}>
          <FormCheck
            type="switch"
            id="enabled_google"
            label="Enable Google Analytics"
            {...register('enabled_google')}
            onChange={(e) => setValue('enabled_google', e.target.checked)}
            checked={enabledGoogle}
          />

          {enabledGoogle && (
            <div className="mt-2 ms-2">
              <FormGroup className="mb-2">
                <FormLabel>Google Mode</FormLabel>
                <FormControl
                  as="select"
                  {...register('google_mode')}
                  value={googleMode}
                  onChange={(e) => setValue('google_mode', e.target.value)}
                >
                  <option value="gtm">GTM</option>
                  <option value="ga4">GA4</option>
                </FormControl>
              </FormGroup>

              {googleMode === 'gtm' && (
                <FormGroup className="mb-2">
                  <FormLabel>GTM Container ID</FormLabel>
                  <FormControl
                    type="text"
                    placeholder="e.g. GTM-XXXXXX"
                    {...register('gtm_container_id')}
                    isInvalid={!!errors.gtm_container_id}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.gtm_container_id?.message}
                  </Form.Control.Feedback>
                </FormGroup>
              )}

              {googleMode === 'ga4' && (
                <FormGroup className="mb-2">
                  <FormLabel>GA4 Measurement ID</FormLabel>
                  <FormControl
                    type="text"
                    placeholder="e.g. G-XXXXXX"
                    {...register('ga4_measurement_id')}
                    isInvalid={!!errors.ga4_measurement_id}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.ga4_measurement_id?.message}
                  </Form.Control.Feedback>
                </FormGroup>
              )}
            </div>
          )}
        </Col>

        {/* Meta Pixel */}
        <Col md={12}>
          <FormCheck
            type="switch"
            id="enabled_meta"
            label="Enable Meta Pixel"
            {...register('enabled_meta')}
            onChange={(e) => setValue('enabled_meta', e.target.checked)}
            checked={enabledMeta}
          />

          {enabledMeta && (
            <div className="mt-2 ms-2">
              <FormGroup className="mb-2">
                <FormLabel>Meta Pixel ID</FormLabel>
                <FormControl
                  type="text"
                  placeholder="e.g. 123456789012345"
                  {...register('meta_pixel_id')}
                  isInvalid={!!errors.meta_pixel_id}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.meta_pixel_id?.message}
                </Form.Control.Feedback>
              </FormGroup>

              <FormCheck
                type="switch"
                id="meta_capi_enabled"
                label="Enable Meta CAPI (server-side)"
                {...register('meta_capi_enabled')}
                onChange={(e) => setValue('meta_capi_enabled', e.target.checked)}
                checked={metaCapiEnabled}
              />

              {metaCapiEnabled && (
                <FormGroup className="mt-2">
                  <FormLabel>Meta CAPI Access Token</FormLabel>
                  <FormControl
                    type="text"
                    placeholder="Access Token"
                    {...register('meta_capi_access_token')}
                    isInvalid={!!errors.meta_capi_access_token}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.meta_capi_access_token?.message}
                  </Form.Control.Feedback>
                </FormGroup>
              )}
            </div>
          )}
        </Col>
      </Row>

      <div className="text-end my-2">
        <Button className="btn bg-primary border border-primary px-3" variant="primary" type="submit" disabled={isSubmitting || isSaving}>
          {isSubmitting || isSaving ? 'Saving...' : 'Save Tracking Settings'}
        </Button>
      </div>
    </Form>
  );
}
