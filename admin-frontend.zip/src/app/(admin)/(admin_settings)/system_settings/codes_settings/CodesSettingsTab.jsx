// 'use client'

// import { useState } from 'react'
// import { Form, Row, Col, Button, FormLabel, Spinner } from 'react-bootstrap'

// const CodesSettingsTab = ({ register, handleSubmit, errors, onSubmit }) => {
//   const [saving, setSaving] = useState(false)

//   const handleLocalSubmit = async (data) => {
//     try {
//       setSaving(true)
//       await onSubmit(data)
//     } finally {
//       setSaving(false)
//     }
//   }

//   return (
//     <Form onSubmit={handleSubmit(handleLocalSubmit)}>
//       <Row className="gy-4">
//         <Col md={6}>
//           <FormLabel>SKU</FormLabel>
//           <Form.Check type="switch" id="field_config.sku" label="Enable SKU" {...register('field_config.sku')} disabled={saving} />
//         </Col>

//         <Col md={6}>
//           <FormLabel>Barcode</FormLabel>
//           <Form.Check type="switch" id="field_config.barcode" label="Enable Barcode" {...register('field_config.barcode')} disabled={saving} />
//         </Col>

//         <Col md={6}>
//           <FormLabel>Batch Number</FormLabel>
//           <Form.Check type="switch" id="field_config.batch_no" label="Enable Batch Number" {...register('field_config.batch_no')} disabled={saving} />
//         </Col>
//       </Row>

//       <div className="text-end mt-4">
//         <Button type="submit" disabled={saving}>
//           {saving ? (
//             <>
//               <Spinner as="span" animation="border" size="sm" className="me-2" />
//               Saving...
//             </>
//           ) : (
//             'Save Code Settings'
//           )}
//         </Button>
//       </div>
//     </Form>
//   )
// }

// export default CodesSettingsTab
