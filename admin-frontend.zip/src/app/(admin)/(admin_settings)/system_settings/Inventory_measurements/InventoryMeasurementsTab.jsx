'use client'

import { useState, useEffect, useMemo } from 'react'
import { Form, Row, Col, Button, OverlayTrigger, Tooltip, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useGetInventoryStrategiesQuery } from '@/store/features/apiSlice'

const STRATEGY_LABELS = {
  FIFO: 'FIFO (First In First Out)',
  LIFO: 'LIFO (Last In First Out)',
  Manual: 'Manual',
}

const InventoryMeasurementsTab = ({ register, handleSubmit, watch, onSubmit }) => {
  /* ------------------ FETCH STRATEGIES ------------------ */
  const { data, isLoading } = useGetInventoryStrategiesQuery()
  const inventoryStrategies = data?.data || []

  const [saving, setSaving] = useState(false)
  const [selectedId, setSelectedId] = useState(null)

  const [originalState, setOriginalState] = useState(null)

  /* ------------------ DEFAULT STRATEGY ------------------ */
  useEffect(() => {
    if (selectedId || !inventoryStrategies.length) return

    const active = inventoryStrategies.find((s) => s.status === 'Active')
    if (active) setSelectedId(active.inventory_strategy_id)
  }, [inventoryStrategies, selectedId])

  /* ------------------ BUILD CURRENT STATE ------------------ */
  const watchedValues = watch()

  const currentState = useMemo(() => {
    return {
      inventory_strategy_id: selectedId,
      field_config: {
        sku: Boolean(watchedValues?.field_config?.sku),
        barcode: Boolean(watchedValues?.field_config?.barcode),
        batch_no: Boolean(watchedValues?.field_config?.batch_no),
      },
    }
  }, [watchedValues, selectedId])

  /* ------------------ FREEZE ORIGINAL STATE (ONCE) ------------------ */
  useEffect(() => {
    if (!selectedId || originalState) return
    setOriginalState(structuredClone(currentState))
  }, [selectedId, currentState, originalState])

  /* ------------------ DIRTY CHECK ------------------ */
  const isDirty = useMemo(() => {
    if (!originalState) return false
    return JSON.stringify(originalState) !== JSON.stringify(currentState)
  }, [originalState, currentState])

  const selectedStrategy = inventoryStrategies.find((s) => s.inventory_strategy_id === selectedId)

  /* ------------------ SUBMIT ------------------ */
  const handleLocalSubmit = async (data) => {
    if (!isDirty) return

    const confirm = await Swal.fire({
      icon: 'warning',
      title: 'Confirm Inventory Changes',
      html: `
        <strong>Inventory Strategy</strong><br/>
        ${STRATEGY_LABELS[selectedStrategy?.name] ?? selectedStrategy?.name}
        <br/><br/>
        <strong>Codes</strong><br/>
        SKU: ${currentState.field_config.sku ? 'Enabled' : 'Disabled'}<br/>
        Barcode: ${currentState.field_config.barcode ? 'Enabled' : 'Disabled'}<br/>
        Batch Number: ${currentState.field_config.batch_no ? 'Enabled' : 'Disabled'}
      `,
      showCancelButton: true,
      confirmButtonText: 'Apply Changes',
      cancelButtonText: 'Cancel',
    })

    if (!confirm.isConfirmed) return

    try {
      setSaving(true)

      data.inventory_strategy_id = currentState.inventory_strategy_id
      data.field_config = currentState.field_config

      await onSubmit(data)

      // Reset baseline
      setOriginalState(structuredClone(currentState))

      Swal.fire({
        icon: 'success',
        title: 'Saved',
        text: 'Inventory settings updated successfully.',
      })
    } catch {
      Swal.fire({
        icon: 'error',
        title: 'Save Failed',
        text: 'Unable to save inventory settings.',
      })
    } finally {
      setSaving(false)
    }
  }

  if (isLoading) return <div>Loading inventory strategies...</div>

  return (
    <Form onSubmit={handleSubmit(handleLocalSubmit)}>
      {/* ================= Inventory Strategy ================= */}
      <h5 className="mb-2">Inventory Strategy</h5>
      <hr className="soft-divider mt-0" />

      <Row className="gy-3">
        {inventoryStrategies.map((strategy) => {
          const inactive = strategy.status === 'Inactive'
          const label = STRATEGY_LABELS[strategy.name] ?? strategy.name

          return (
            <Col md={12} key={strategy.inventory_strategy_id}>
              <Form.Check
                type="switch"
                checked={selectedId === strategy.inventory_strategy_id}
                disabled={inactive || saving}
                onChange={() => !inactive && setSelectedId(strategy.inventory_strategy_id)}
                label={
                  <OverlayTrigger placement="right" overlay={<Tooltip>{label}</Tooltip>}>
                    <span style={{ opacity: inactive ? 0.45 : 1 }}>{label}</span>
                  </OverlayTrigger>
                }
              />
            </Col>
          )
        })}
      </Row>

      {/* ================= Codes ================= */}
      <h5 className="mt-5 mb-2">Codes</h5>
      <hr className="soft-divider mt-0" />

      <Row className="gy-4">
        <Col md={6}>
          <Form.Label>SKU</Form.Label>
          <Form.Check type="switch" label="Enable SKU" {...register('field_config.sku')} />
        </Col>

        <Col md={6}>
          <Form.Label>Barcode</Form.Label>
          <Form.Check type="switch" label="Enable Barcode" {...register('field_config.barcode')} />
        </Col>

        <Col md={6}>
          <Form.Label>Batch Number</Form.Label>
          <Form.Check type="switch" label="Enable Batch Number" {...register('field_config.batch_no')} />
        </Col>
      </Row>

      {/* ================= SAVE BUTTON ================= */}
      <div className="text-end mt-4">
        <Button
          className="btn bg-primary border border-primary flex-grow-1"
          type="submit"
          disabled={!isDirty || saving}
          variant={isDirty ? 'primary' : 'secondary'}>
          {saving ? (
            <>
              <Spinner size="sm" className="me-2" />
              Saving...
            </>
          ) : (
            'Save Inventory Settings'
          )}
        </Button>
      </div>
    </Form>
  )
}

export default InventoryMeasurementsTab
