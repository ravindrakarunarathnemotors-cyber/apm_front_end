'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Tabs, Tab } from 'react-bootstrap'
import { useEffect, useState } from 'react'
import Swal from 'sweetalert2'
import ComponentContainerCard from '@/components/ComponentContainerCard'

import { useGetSystemSettingsQuery, useUpdateSystemSettingsMutation } from '../../../../../src/store/features/apiSlice'

// Tab components
import GeneralSettingsTab from './general_settings/GeneralSettingsTab'
import MailSettingsTab from './mail_settings/MailSettingsTab'
import MaintenanceSettingsTab from './maintenance_settings/MaintenanceSettingsTab'
import NotificationsTab from './notifications/NotificationsTab'
import SmsSettingsTab from './sms_settings/SmsSettingsTab'
// import CodesSettingsTab from './codes_settings/CodesSettingsTab'
import S3SettingsTab from './file_server/S3SettingsTab'

import TaxTab from './tax/TaxTab'
import Loyalty from './loyalty/Loyalty'
import ServiceCharge from './service_charge/ServiceCharge'
import TrackingSettingsForm from './google_analytics/TrackingSettingsForm'
import InvoicingSettingsTab from './invoicing/InvoicingTab'
import QuotationSettingsTab from './quotation/QuotationsTab'
import InventoryMeasurementsTab from './Inventory_measurements/InventoryMeasurementsTab'

// Yup validation schema (minimal)
const schema = yup.object().shape({
  default_timezone: yup.string().required(),
  date_format: yup.string().required(),
  currency: yup.string().required(),
  default_country: yup.string().required(),
})

// Accepts 60, "60", {minutes:60}, {hours:1} and returns a string of minutes for the <select>
const readAutoLogoutMinutesForSelect = (v) => {
  if (v == null) return '0'
  if (typeof v === 'number') return String(v) // assume minutes
  if (typeof v === 'string') return v // assume already minutes in string
  if (typeof v === 'object') {
    if ('minutes' in v && v.minutes != null) return String(Number(v.minutes) || 0)
    if ('hours' in v && v.hours != null) return String((Number(v.hours) || 0) * 60)
  }
  return '0'
}

// Takes the select value ("5","10","30","60","0") and builds the payload the backend expects
// If your backend expects a plain number of minutes, return Number(minutes) instead.
// Right now we send an object with { minutes: N } to be explicit and unit-safe.
const buildAutoLogoutPayload = (selectValue) => {
  const minutes = Number(selectValue) || 0
  return { minutes }
}

// helper: normalize "enabled"/"disabled", "true"/"false", 1/0, etc. -> boolean
const toBool = (v) => {
  if (typeof v === 'boolean') return v
  if (v == null) return false
  const s = String(v).trim().toLowerCase()
  return s === 'enabled' || s === 'true' || s === '1' || s === 'yes' || s === 'on'
}

const SystemSettingsPage = () => {
  const [activeTab, setActiveTab] = useState('general')

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
  })

  const { data, isLoading, error } = useGetSystemSettingsQuery()
  const [updateSystemSettings] = useUpdateSystemSettingsMutation()

  useEffect(() => {
    if (!data?.data) return

    const normalizedData = {
      ...data.data,
      default_timezone: String(data.data.default_timezone ?? ''),
      inventory_strategy_id: data.data.inventory_strategy_id ?? null,
      date_format: String(data.data.date_format ?? ''),
      currency: String(data.data.currency ?? ''),
      default_country: String(data.data.default_country ?? ''),
      // normalize auto_logout_time into minutes string for the <select>
      auto_logout_time: readAutoLogoutMinutesForSelect(data.data.auto_logout_time),
      field_config: {
        sku: !!data.data.field_config?.sku,
        barcode: !!data.data.field_config?.barcode,
        batch_no: !!data.data.field_config?.batch_no,
      },
      // make sure the email notifications toggle is a boolean for the switch
      email_notification_status: toBool(data.data.email_notification_status),
    }

    reset(normalizedData)
    // optional: console.log to verify
    // console.log('Normalized system settings:', normalizedData);
  }, [data, reset])
  const termsText = watch('terms_conditions_quotations') || ''

  const onSubmit = async (formData) => {
    const fieldConfig = {
      sku: !!formData.field_config?.sku,
      barcode: !!formData.field_config?.barcode,
      batch_no: !!formData.field_config?.batch_no,
    }

    formData.field_config = fieldConfig

    // Convert toggle fields to "enabled"/"disabled"
    const toggledFields = [
      'sms_notification_status',
      'email_notification_status',
      'new_client_sms_status',
      'new_client_email_status',
      'new_client_activation_sms_status',
      'new_client_activation_email_status',
      'backoffice_maintenance_status',
      'webstore_maintenance_status',
      'pos_maintenance_status',
      'full_maintenance_status',
    ]

    toggledFields.forEach((field) => {
      formData[field] = formData[field] === true || formData[field] === 'enabled' ? 'enabled' : 'disabled'
    })

    // Combine maintenance messages into JSON string format
    const msgFields = ['backoffice', 'webstore', 'pos', 'full']
    msgFields.forEach((key) => {
      formData[`${key}_maintenance_msg`] = JSON.stringify({
        title: formData[`${key}_maintenance_msg_title`] || '',
        message: formData[`${key}_maintenance_msg_body`] || '',
      })
      delete formData[`${key}_maintenance_msg_title`]
      delete formData[`${key}_maintenance_msg_body`]
    })

    try {
      formData.auto_logout_time = buildAutoLogoutPayload(formData.auto_logout_time)

      const res = await updateSystemSettings(formData).unwrap()
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'System settings updated successfully!',
      })
    } catch (err) {
      console.error('Error updating system settings:', err)
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: 'Something went wrong while updating system settings.',
      })
    }
  }

  if (isLoading) return <div>Loading system settings...</div>
  if (error) return <div>Error loading system settings.</div>

  return (
    <ComponentContainerCard title="System Settings">
      <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k || 'general')} className="my-3">
        <Tab eventKey="general" title="General">
          <GeneralSettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
        <Tab eventKey="sms" title="SMS">
          <SmsSettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
        <Tab eventKey="mail" title="Mail">
          <MailSettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
        <Tab eventKey="maintenance" title="Maintenance">
          <MaintenanceSettingsTab
            register={register}
            handleSubmit={handleSubmit}
            errors={errors}
            onSubmit={onSubmit}
            setValue={setValue}
            watch={watch}
          />
        </Tab>
        <Tab eventKey="notifications" title="Notifications">
          <NotificationsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
        <Tab eventKey="tax" title="Tax">
          <TaxTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} data={data?.data} />
        </Tab>

        <Tab eventKey="loyalty" title="Loyalty">
          <Loyalty register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} data={data?.data} />
        </Tab>

        {/* <Tab eventKey="codes" title="Codes">
          <CodesSettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab> */}
<Tab eventKey="inventory" title="Inventory">
  <InventoryMeasurementsTab
    register={register}
    handleSubmit={handleSubmit}
    watch={watch}
    onSubmit={onSubmit}
    inventoryStrategies={data?.inventory_strategies ?? []}
  />
</Tab>


        <Tab eventKey="invoicing" title="Invoicing & Quotations">
          <InvoicingSettingsTab
            register={register}
            handleSubmit={handleSubmit}
            watch={watch}
            onSubmit={onSubmit}
            defaultValues={data?.data}
            setValue={setValue} //  Pass it here
          />
          <hr></hr>
          <QuotationSettingsTab
            register={register}
            handleSubmit={handleSubmit}
            watch={watch}
            setValue={setValue}
            defaultValues={data?.data}
            onSubmit={onSubmit}
          />
        </Tab>
        <Tab eventKey="google" title="Google & Meta Pixel">
          <TrackingSettingsForm />
        </Tab>
        <Tab eventKey="File_Server" title="File Server">
          <S3SettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
         <Tab eventKey="service_charge" title="Service Charge">
          <ServiceCharge register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} />
        </Tab>
      </Tabs>
    </ComponentContainerCard>
  )
}

export default SystemSettingsPage
