'use client'
import { useEffect, useMemo } from 'react'
import { Form, Row, Col, FormCheck, FormGroup, FormLabel, FormControl, Button } from 'react-bootstrap'

const MaintenanceSettingsTab = ({ register, setValue, watch, handleSubmit, onSubmit }) => {
  const sections = useMemo(() => [
    { key: 'backoffice', label: 'Back Office Maintenance' },
    { key: 'webstore', label: 'Web Store Maintenance' },
    { key: 'pos', label: 'POS System Maintenance' },
    { key: 'full', label: 'Entire System Maintenance' },
  ], [])
useEffect(() => {
  sections.forEach(({ key }) => {
    const json = watch(`${key}_maintenance_msg`)
    if (json && typeof json === 'string') {
      try {
        const parsed = JSON.parse(json)
        setValue(`${key}_maintenance_msg_title`, parsed.title || '')
        setValue(`${key}_maintenance_msg_body`, parsed.message || '')
      } catch {
        setValue(`${key}_maintenance_msg_title`, '')
        setValue(`${key}_maintenance_msg_body`, '')
      }
    }
  })
}, [sections, watch, setValue])

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-4 p-2">
        {sections.map(({ key, label }) => {
          const toggleValue = watch(`${key}_maintenance_status`) === 'enabled'

          return (
            <Col md={12} key={key}>
              <FormCheck
                type="switch"
                id={`${key}_maintenance_status`}
                label={label}
                checked={toggleValue}
                onChange={(e) =>
                  setValue(`${key}_maintenance_status`, e.target.checked ? 'enabled' : 'disabled')
                }
              />

              {toggleValue && (
                <div className="mt-3 ms-3">
                  <FormGroup className="mb-2">
                    <FormLabel>Message Title</FormLabel>
                    <FormControl
                      type="text"
                      placeholder="Enter title"
                      {...register(`${key}_maintenance_msg_title`)}
                    />
                  </FormGroup>

                  <FormGroup>
                    <FormLabel>Message Body</FormLabel>
                    <FormControl
                      as="textarea"
                      rows={3}
                      placeholder="Enter message body"
                      {...register(`${key}_maintenance_msg_body`)}
                    />
                  </FormGroup>
                </div>
              )}
            </Col>
          )
        })}
      <div className="text-end mt-4">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save Maintenance Settings</Button>
      </div>
      </Row>

    </Form>
  )
}

export default MaintenanceSettingsTab
