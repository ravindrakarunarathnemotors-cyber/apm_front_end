'use client'

import { Form, Row, Col, Button, FormLabel } from 'react-bootstrap'

const GeneralSettingsTab = ({ register, handleSubmit, errors, onSubmit }) => {
  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3 p-2">
        <Col md={6}>
          <FormLabel>Default Timezone</FormLabel>
          <Form.Select {...register('default_timezone')}>
            <option value="Asia/Colombo">Asia/Colombo</option>
            <option value="UTC">UTC</option>
            <option value="America/New_York">America/New York</option>
            <option value="Europe/London">Europe/London</option>
            <option value="Asia/Dubai">Asia/Dubai</option>
            <option value="Asia/Kolkata">Asia/Kolkata</option>
            <option value="Australia/Sydney">Australia/Sydney</option>
          </Form.Select>
          {errors.default_timezone && <p className="text-danger">{errors.default_timezone.message}</p>}
        </Col>

        <Col md={6}>
          <FormLabel>Date Format</FormLabel>
          <Form.Select {...register('date_format')}>
            <option value="YY/MM/DD">YY/MM/DD</option>
            <option value="DD/MM/YY">DD/MM/YY</option>
            <option value="MM/DD/YY">MM/DD/YY</option>
            <option value="MM/DD">MM/DD</option>
            <option value="YY/MM">YY/MM</option>
          </Form.Select>
          {errors.date_format && <p className="text-danger">{errors.date_format.message}</p>}
        </Col>

        <Col md={6}>
          <FormLabel>Currency</FormLabel>
          <Form.Select {...register('currency')}>
            <option value="USD">USD - US Dollar ($)</option>
            <option value="LKR">LKR - Sri Lankan Rupee (Rs.)</option>
            <option value="GBP">GBP - British Pound (£)</option>
            <option value="EUR">EUR - Euro (€)</option>
            <option value="CAD">CAD - Canadian Dollar (C$)</option>
            <option value="INR">INR - Indian Rupee (₹)</option>
            <option value="AUD">AUD - Australian Dollar (A$)</option>
          </Form.Select>
          {errors.currency && <p className="text-danger">{errors.currency.message}</p>}
        </Col>

        <Col md={6}>
          <FormLabel>Auto Logout Time</FormLabel>
          <Form.Select {...register('auto_logout_time')}>
            <option value="5">5 Minutes</option>
            <option value="10">10 Minutes</option>
            <option value="30">30 Minutes</option>
            <option value="60">1 Hour</option>
            <option value="0">Never</option>
          </Form.Select>
          {errors.auto_logout_time && <p className="text-danger">{errors.auto_logout_time.message}</p>}
        </Col>

        <Col md={6}>
          <FormLabel>Default Country</FormLabel>
          <Form.Select {...register('default_country')}>
            <option value="Sri Lanka">Sri Lanka</option>
            <option value="United States">United States</option> {/* USD */}
            {/* LKR */}
            <option value="United Kingdom">United Kingdom</option> {/* GBP */}
            <option value="Germany">Germany</option> {/* EUR */}
            <option value="Canada">Canada</option> {/* CAD */}
            <option value="India">India</option> {/* INR */}
            <option value="Australia">Australia</option> {/* AUD */}
          </Form.Select>
          {errors.default_country && <p className="text-danger">{errors.default_country.message}</p>}
        </Col>
      <div className="text-end mt-4">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save General Settings</Button>
      </div>
      </Row>

    </Form>
  )
}

export default GeneralSettingsTab
