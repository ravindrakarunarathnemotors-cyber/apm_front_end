'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, FormCheck, FormLabel, Form, Button, FormControl } from 'react-bootstrap'
import axios from 'axios'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import RedCard from '@/components/Redcard'
import Link from 'next/link'
import useLogout from '@/hooks/useLogout'
import axiosInstance from '@/lib/axiosInstance';

const TaxTab = ({ data }) => {
    // Tax enabled/disabled state
    const [taxEnabled, setTaxEnabled] = useState(false)
    const [taxWebEnabled, setTaxWebEnabled] = useState(false)
    // Fields for key and value
    const [taxFields, setTaxFields] = useState({ key: '', value: '' })
    // To control loading state for API call
    const [loading, setLoading] = useState(false)

   
    const { Logout } = useLogout()

    useEffect(() => {
        if (data) {
            console.log(data)
            setTaxEnabled(data.tax)
            setTaxWebEnabled(data.tax_on_web)
            const key = Object.keys(data.tax_value)[0]
            const value = data.tax_value[key]
            setTaxFields({ key, value })
        }
    }, [data])
    // Handle switch toggle
    const handleTaxSwitch = async (e) => {
        const enabled = e.target.checked
        setTaxEnabled(enabled)
        // setLoading(true)
        if (enabled) return
        try {
            // Call API to update tax enabled status
            const response = await axiosInstance.post(`/system/tax-enable`,{ enabled })
            // Optionally, show toast or set notification
        } catch (error) {
           console.error('Search failed:', error)
        }
        setLoading(false)
    }

    // Handle input changes for key-value fields
    const handleInputChange = (e) => {
        const { name, value } = e.target
        setTaxFields((prev) => ({
            ...prev,
            [name]: value,
        }))
    }

    // Handle save button (submit form)
    const handleFormSubmit = async (e) => {
        e.preventDefault()
        setLoading(true)
        console.log("first")
        if (parseFloat(taxFields.value) < 0 || parseFloat(taxFields.value) > 100) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Tax value must be between 0 and 100',
            })
            setLoading(false)
            return
        }

        try {
            // Call API to update tax enabled status
            const response = await axiosInstance.post(`/system/tax-value`,
                {
                    tax_data: { [taxFields.key]: taxFields.value },
                    enabled: taxEnabled,
                    tax_on_web: taxWebEnabled
                })

            if (response.status === 200) {

                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'System settings updated successfully!',
                })
            }
        } catch (error) {
            console.error('Search failed:', error)
        }
        setLoading(false)
    }

    return (
        <Form onSubmit={handleFormSubmit}>
            <Row className="gy-4 p-2">
                <Col md={12}>
                    <FormLabel><strong>Tax</strong></FormLabel>
                    <FormCheck
                        type="switch"
                        id="tax-switch"
                        label="Enable Tax"
                        checked={taxEnabled}
                        onChange={handleTaxSwitch}
                        disabled={loading}
                    />
                </Col>

                {taxEnabled && (
                    <>
                        <Col md={12}>
                            <FormLabel><strong>Tax on web</strong></FormLabel>
                            <FormCheck
                                type="switch"
                                id="tax-switch-web"
                                label="Enable Tax"
                                checked={taxWebEnabled}
                                onChange={()=>setTaxWebEnabled(!taxWebEnabled)}
                                
                            />
                        </Col>
                        <Col md={6}>
                            <FormLabel>Tax Label</FormLabel>
                            <FormControl
                                name="key"
                                placeholder="Enter key (e.g. VAT)"
                                value={taxFields.key}
                                onChange={handleInputChange}
                                required
                            />
                        </Col>
                        <Col md={6}>
                            <FormLabel>Tax Value (%)</FormLabel>
                            <FormControl
                                name="value"
                                placeholder="Enter value (e.g. 15%)"
                                value={taxFields.value}
                                onChange={handleInputChange}
                                required
                            />
                        </Col>

                        <div className="text-end mt-4">
                            <Button className="btn bg-primary border border-primary px-3" type="submit" disabled={(taxEnabled && (!taxFields.key || !taxFields.value))}>
                                {loading ? 'Saving...' : 'Save Tax Settings'}
                            </Button>
                        </div>
                    </>
                )}
            </Row>


        </Form>
    )
}

export default TaxTab
