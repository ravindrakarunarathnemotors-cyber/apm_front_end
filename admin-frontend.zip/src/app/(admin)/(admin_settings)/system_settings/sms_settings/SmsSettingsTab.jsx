'use client'

import { Row, Col, Form, FormLabel, FormControl, FormCheck, Button } from 'react-bootstrap'

const SmsSettingsTab = ({ register, handleSubmit, onSubmit }) => {
  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3 p-2">
        <Col md={6}>
          <FormLabel>SMS Gateway</FormLabel>
          <Form.Select {...register('sms_gateway_name')} defaultValue="OZoneSender">
            <option value="oZoneSender">oZoneSender</option>
            <option value="OtherGateway">OtherGateway</option>
          </Form.Select>
        </Col>

        <Col md={6}>
          <FormLabel>User ID</FormLabel>
          <FormControl type="text" {...register('sms_user_id')} defaultValue="1" />
        </Col>

        <Col md={6}>
          <FormLabel>Sender ID</FormLabel>
          <FormControl type="text" {...register('sms_sender_id')} defaultValue="oZoneSender" />
        </Col>

        <Col md={6}>
          <FormLabel>API End Point</FormLabel>
          <FormControl type="text" {...register('sms_api_endpoint')} defaultValue="https://api.ozonesender.com" />
        </Col>

        <Col md={6}>
          <FormLabel>API Key</FormLabel>
          <FormControl type="text" {...register('sms_api_key')} defaultValue="oii7qfm4ompLzuY" />
        </Col>

        <Col md={6} className="d-flex align-items-center">
          <FormCheck type="switch" id="sms_notification_status" label="Enable SMS Notifications" {...register('sms_notification_status')} />
        </Col>

        <div className="text-end mt-4">
          <Button className="btn bg-primary border border-primary px-3" type="submit">
            Save SMS Settings
          </Button>
        </div>
      </Row>
    </Form>
  )
}

export default SmsSettingsTab
