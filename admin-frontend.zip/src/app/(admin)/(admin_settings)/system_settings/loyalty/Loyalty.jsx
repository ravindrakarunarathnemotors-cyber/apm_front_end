'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, FormCheck, FormLabel, Form, Button, FormControl } from 'react-bootstrap'
import { useRefreshTokenMutation, useUpdateLoyalySettingsMutation, useGetLoyaltyPointQuery } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import useLogout from '@/hooks/useLogout'

const Loyalty = () => {
  const [taxEnabled, setTaxEnabled] = useState(false)
  const [taxFields, setTaxFields] = useState({ key: '', value: '' })
  const [loading, setLoading] = useState(false)

  const { data, isLoading: isFetchLoading } = useGetLoyaltyPointQuery()
  const [updateLoyaltySettings] = useUpdateLoyalySettingsMutation()
  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()

  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  useEffect(() => {
    if (data) {
      setTaxEnabled(data.loyalty_point)
      setTaxFields({
        key: data.points_given,
        value: data.amount_spend,
      })
    }
  }, [data])

  const handleInputChange = (e) => {
    const { name, value } = e.target

    if (value.includes('.')) {
      const [int, dec] = value.split('.')
      if (dec && dec.length > 2) {
        return
      }
    }
    setTaxFields((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleFormSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const payload = {
        loyalty_point: taxEnabled,
        points_given: Number(taxFields.key),
        amount_spend: Number(taxFields.value),
      }

      await updateLoyaltySettings(payload).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Loyalty settings updated successfully!',
      })
    } catch (error) {
      if (error?.status === 401 || error?.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')

        if (refreshToken) {
          try {
            const res = await refreshtoken(refreshToken).unwrap()

            token = res.access_token
            sessionStorage.setItem('access_token', res.access_token)

            return handleFormSubmit(e)
          } catch {
            Logout()
          }
        } else {
          Logout()
        }
      }
    }

    setLoading(false)
  }

  if (isFetchLoading) return <p>Loading...</p>

  return (
    <Form onSubmit={handleFormSubmit}>
      <Row className="gy-4 p-2">
        <Col md={12}>
          <FormLabel>
            <strong>Loyalty Points</strong>
          </FormLabel>
          <FormCheck
            type="switch"
            label="Enable Loyalty Points"
            checked={taxEnabled}
            onChange={(e) => setTaxEnabled(e.target.checked)}
            disabled={loading}
          />
        </Col>

        {taxEnabled && (
          <>
            <Col md={4}>
              <FormLabel>Points Given</FormLabel>
              <FormControl type="number" name="key" value={taxFields.key} min="0" step="0.01" onChange={handleInputChange} required />
            </Col>

            <Col md={4}>
              <FormLabel>Amount to Spend ({data.currency})</FormLabel>
              <FormControl type="number" name="value" value={taxFields.value} min="0" step="0.01" onChange={handleInputChange} required />
            </Col>

            <div className="text-end mt-4">
              <Button className="btn bg-primary border border-primary px-3" type="submit" disabled={loading}>
                {loading ? 'Saving...' : 'Save Loyalty Point Setting'}
              </Button>
            </div>
          </>
        )}
      </Row>
    </Form>
  )
}

export default Loyalty
