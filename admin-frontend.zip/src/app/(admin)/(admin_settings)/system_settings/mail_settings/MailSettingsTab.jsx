'use client'

import { Row, Col, FormCheck, FormControl, FormLabel, Form, Button } from 'react-bootstrap'
import React, { useState } from 'react'
const MailSettingsTab = ({ register, errors, handleSubmit, onSubmit }) => {
  // keep token empty unless user types; omit from payload if blank
  const [postmarkToken, setPostmarkToken] = useState('')

  const {
    ref: pmRef,
    onChange: pmOnChange,
    onBlur: pmOnBlur,
    name: pmName,
  } = register('postmark_server_token', {
    setValueAs: (v) => (typeof v === 'string' && v.trim() ? v.trim() : undefined),
  })

  return (
    <Form className="p-2 gy-3" onSubmit={handleSubmit(onSubmit)}>
      <h5>Email Settings</h5>
      <Row className="gy-3 p-2 mb-3">
        <Col md={6}>
          <FormLabel>Billing Email Address</FormLabel>
          <FormControl type="email" {...register('billing_email')} isInvalid={!!errors.billing_email} />
        </Col>
        <Col md={6}>
          <FormLabel>System Email Address</FormLabel>
          <FormControl type="email" {...register('system_email')} isInvalid={!!errors.system_email} />
        </Col>
        <Col md={6}>
          <FormLabel>Support Email Address</FormLabel>
          <FormControl type="email" {...register('support_email')} isInvalid={!!errors.support_email} />
        </Col>
        <Col md={6} className="d-flex align-items-center">
          <FormCheck type="switch" id="email_notification_status" label="Enable Email Notifications" {...register('email_notification_status')} />
        </Col>
      </Row>

      <h5>Postmark Settings</h5>
      <Row className="gy-3 p-2 ">
        <Col md={6}>
          <FormLabel>Postmark Server Token</FormLabel>
          <FormControl
            type="password"
            placeholder="Postmark Server Token"
            autoComplete="new-password"
            name={pmName}
            ref={pmRef}
            onBlur={pmOnBlur}
            value={postmarkToken}
            onChange={(e) => {
              setPostmarkToken(e.target.value)
              pmOnChange(e)
            }}
            isInvalid={!!errors.postmark_server_token}
          />
        </Col>
        <div className="text-end ">
          <Button className="btn bg-primary border border-primary px-3" type="submit">
            Save Mail Settings
          </Button>
        </div>
      </Row>
      {/* 

      <h5>SMTP Settings</h5>
      <Row className="gy-3 mb-4">
        <Col md={6}>
          <FormLabel>SMTP Host</FormLabel>
          <FormControl
            type="text"
            {...register('smtp_host')}
            isInvalid={!!errors.smtp_host}
          />
        </Col>
        <Col md={6}>
          <FormLabel>SMTP Port</FormLabel>
          <FormControl
            type="text"
            {...register('smtp_port')}
            isInvalid={!!errors.smtp_port}
          />
        </Col>
        <Col md={6}>
          <FormLabel>SMTP Username</FormLabel>
          <FormControl
            type="text"
            {...register('smtp_username')}
            isInvalid={!!errors.smtp_username}
          />
        </Col>
        <Col md={6}>
          <FormLabel>SMTP Password</FormLabel>
          <FormControl
            type="password"
            {...register('smtp_password')}
            isInvalid={!!errors.smtp_password}
          />
        </Col>
        <Col md={6}>
          <FormLabel>SMTP Encryption</FormLabel>
          <Form.Select {...register('smtp_encryption')}>
            <option value="SSL">SSL</option>
            <option value="TLS">TLS</option>
            <option value="None">None</option>
          </Form.Select>
        </Col>
      </Row> */}
    </Form>
  )
}

export default MailSettingsTab
