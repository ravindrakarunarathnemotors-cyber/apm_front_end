"use client";

import { Button, Col, FormLabel, FormControl, Row, Card, Table, Pagination, Spinner, Form } from 'react-bootstrap';
import React, { useState, useEffect } from "react";
import { Icon } from "@iconify/react";
import {
    useGetemailTemplogQuery,
    useGetSMSActionsQuery,
} from '@/store/features/new_update';
import Swal from "sweetalert2";

const SMSTemplate = () => {
    const [selectedAction, setSelectedAction] = useState("");
    const [searchAction, setSearchAction] = useState("");
    const [email, setemail] = useState("");
    const [status, setStatus] = useState("");
    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 25;

    // ✅ Fetch SMS Actions for Dropdown
    const { data: smsActions, isLoading: isLoadingActions, error } = useGetSMSActionsQuery();

    // ✅ Fetch SMS Templates filtered by multiple criteria
    const { data, isLoading, refetch } = useGetemailTemplogQuery({
        page: currentPage,
        limit: itemsPerPage,
        action: searchAction,
        email,
        status,
        startDate,
        endDate,
    });

    const totalPages = data?.totalPages || 1;

    // ✅ Handle Search Button Click
    const handleSearch = () => {
        setSearchAction(selectedAction);
        refetch();
    };

    return (
        <>
            <Card >
                <Card.Body>
                    <div className="card p-3">

                        {/* Filter Section */}
                        <div className="row g-2 align-items-center">

                            {/* Start Date Picker */}
                            <div className="col-md-3">
                                <Form.Label className="form-label-sm">Start Date</Form.Label>
                                <Form.Control
                                    type="date"
                                    value={startDate}
                                    onChange={(e) => setStartDate(e.target.value)}
                                    className="form-control-sm"
                                    style={{ height: "40px" }} // Increased height
                                />
                            </div>

                            {/* End Date Picker */}
                            <div className="col-md-3">
                                <Form.Label className="form-label-sm">End Date</Form.Label>
                                <Form.Control
                                    type="date"
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                    className="form-control-sm"
                                    style={{ height: "40px" }} // Increased height
                                />
                            </div>
                            {/* Action Dropdown */}
                            <div className="col-md-3">
                                <Form.Label className="form-label-sm">Action</Form.Label>

                                <Form.Select
                                    name="action"
                                    value={selectedAction}
                                    onChange={(e) => setSelectedAction(e.target.value)}
                                    className="form-control-sm"
                                >
                                    <option value="" disabled hidden>All Actions</option>
                                    {isLoadingActions ? (
                                        <option>Loading...</option>
                                    ) : (
                                        smsActions?.map((action) => (
                                            <option key={action.id} value={action.id}>
                                                {action.name}
                                            </option>
                                        ))
                                    )}
                                </Form.Select>
                            </div>

                            {/* Status Dropdown */}
                            <div className="col-md-3">
                                <Form.Label className="form-label-sm">Status</Form.Label>
                                <Form.Select
                                    name="status"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    className="form-control-sm"
                                >
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Sent">Sent</option>
                                </Form.Select>
                            </div>
                            {/* Mobile Number Input */}
                            <div className="col-md-3">
                                <Form.Label className="form-label-sm">Email</Form.Label>
                                <Form.Control
                                    type="email"
                                    placeholder="Email"
                                    value={email}
                                    onChange={(e) => setemail(e.target.value)}
                                    className="form-control-sm"
                                    style={{ height: "40px" }} // Increased height
                                />
                            </div>



                            {/* Search Button */}
                            {/* Search and Reset Buttons */}
                            <div className="col-md-3 d-flex gap-2 mt-4">
                                <Button
                                    onClick={() => {
                                        setSelectedAction('');
                                        setSearchAction('');
                                        setemail('');
                                        setStatus('');
                                        setStartDate('');
                                        setEndDate('');
                                        setCurrentPage(1);
                                        refetch(); // Re-fetch with cleared filters
                                    }}
                                    variant="danger"
                                    className="w-100"
                                >
                                    <Icon icon="material-symbols:restart-alt-rounded" width="18" height="18" className="me-1" />
                                    Reset
                                </Button>

                                <Button onClick={handleSearch} variant="primary" className="w-100">
                                    <Icon icon="material-symbols:search-rounded" width="18" height="18" className="me-1" />
                                    Search
                                </Button>

                            </div>

                        </div>
                    </div>

                    {/* ✅ Loading Spinner */}
                    {isLoading ? (
                        <div className="d-flex justify-content-center align-items-center">
                            <Spinner animation="border" variant="primary" />
                        </div>
                    ) : (
                        <>
                            {/* ✅ SMS Logs Table */}
                            <Table striped bordered hover responsive>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        {/* <th>Message</th> */}
                                        <th>Date</th>
                                        <th>Sent Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data?.smsTemplates.length > 0 ? (
                                        data.smsTemplates.map((template) => (
                                            <tr key={template.id}>
                                                <td>{template.id}</td>
                                                <td>{template.email}</td>
                                                <td>{template.subject}</td>
                                                {/* <td style={{
                                                    maxWidth: "150px",
                                                    wordBreak: "break-word",
                                                    whiteSpace: "normal",
                                                }}>
                                                    {template.msg}
                                                </td> */}

                                                <td>{new Date(template.date).toLocaleDateString()}</td>
                                                <td>
                                                    {template.sentdate
                                                        ? new Date(template.sentdate).toISOString().slice(0, 19).replace("T", " ")
                                                        : "Not Sent"}
                                                </td>
                                                <td>{template.status}</td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="6" className="text-center">No Email Logs Found</td></tr>
                                    )}
                                </tbody>
                            </Table>
                        </>
                    )}

                    {/* ✅ Pagination */}
                    <div className="d-flex justify-content-end">
                        <Pagination>
                            <Pagination.Prev
                                disabled={currentPage === 1}
                                onClick={() => setCurrentPage(currentPage - 1)}
                            />

                            {Array.from({ length: totalPages }, (_, index) => index + 1)
                                .filter((page) => {
                                    if (totalPages <= 3) return true;
                                    if (currentPage <= 2) return page <= 3;
                                    if (currentPage >= totalPages - 1) return page >= totalPages - 2;
                                    return Math.abs(page - currentPage) <= 1;
                                })
                                .map((page) => (
                                    <Pagination.Item
                                        key={page}
                                        active={page === currentPage}
                                        onClick={() => setCurrentPage(page)}
                                    >
                                        {page}
                                    </Pagination.Item>
                                ))}

                            <Pagination.Next
                                disabled={currentPage === totalPages}
                                onClick={() => setCurrentPage(currentPage + 1)}
                            />
                        </Pagination>

                    </div>
                </Card.Body>
            </Card>
        </>
    );
};

export default SMSTemplate;
