"use client";

import { Button, Col, FormLabel, FormControl, Row, Card, Table, Pagination, Spinner, Form, Modal } from 'react-bootstrap';
import React, { useState, useEffect } from "react";
import { Icon } from "@iconify/react";
import {
    useGetEmailTemplateQuery,
    useGetSMSActionsQuery,
    useUpdateemailtempStatusMutation,
} from '@/store/features/new_update';
import Edittemplate from "./edit_template"; // ✅ Import Edit Modal Component
import Swal from "sweetalert2";
import SMSTemplates from "./sms_log"; // adjust import path if needed


const SMSTemplate = () => {
    const [selectedAction, setSelectedAction] = useState("");
    const [searchAction, setSearchAction] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 25;

    const [showSMSLog, setShowSMSLog] = useState(false);

    const handleOpenSMSLog = () => setShowSMSLog(true);
    const handleCloseSMSLog = () => setShowSMSLog(false);

    // ✅ State for Edit Modal
    const [showEditModal, setShowEditModal] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);

    // ✅ Fetch SMS Actions for Dropdown
    const { data: smsActions, isLoading: isLoadingActions, error } = useGetSMSActionsQuery();
    const [updateClientStatus] = useUpdateemailtempStatusMutation();


    // ✅ Fetch SMS Templates filtered by Action ID
    const { data, isLoading, refetch } = useGetEmailTemplateQuery({
        page: currentPage,
        limit: itemsPerPage,
        action: searchAction,
    });

    const totalPages = data?.totalPages || 1;

    // ✅ Handle Action Selection Change
    const handleActionChange = (e) => {
        setSelectedAction(e.target.value);
    };

    // ✅ Handle Search Button Click
    const handleSearch = () => {
        setSearchAction(selectedAction);
        refetch();
    };

    const handleShowEditModal = (template) => {
        setSelectedTemplate(template);
        setShowEditModal(true);
        refetch();
    };


    // ✅ Close Edit Modal
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setSelectedTemplate(null);
        refetch();

    };

    const handleSetInactive = async (template) => {
       
        // ✅ Determine the new status ("Active" -> "Inactive", "Inactive" -> "Active")
        const newStatus = template.status === "Active" ? "Inactive" : "Active";

        // ✅ Ask for confirmation before updating
        const result = await Swal.fire({
            title: `Are you sure?`,
            text: `Do you want to mark this Email template as ${newStatus}?`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: template.status === "Active" ? "#d33" : "#3085d6", // Red for deactivating, Blue for activating
            cancelButtonColor: "#3085d6",
            confirmButtonText: `Yes, mark as ${newStatus}`,
        });

        if (!result.isConfirmed) return; // Exit early if user cancels

        try {
            await updateClientStatus({
                tempid: template.id, // ✅ Pass correct template ID
                status: newStatus, // ✅ Pass "Active" or "Inactive"
                user_id: 1,
            }).unwrap();

            Swal.fire({
                title: "Updated!",
                text: `The Email template is now marked as ${newStatus}.`,
                icon: "success",
            });

            refetch(); // ✅ Refresh data to reflect status update
        } catch (err) {
            
            Swal.fire({
                icon: "error",
                title: "Update Failed",
                text: "Something went wrong. Please try again!",
            });
        }
    };

    return (
        <>
            <Card className="mt-3">
                <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                        <h5 className="mb-0">Email Template</h5>
                        <div className="d-flex align-items-center" style={{ gap: "8px" }}>

                            {/* ✅ Dropdown for Selecting Action */}
                            <Form.Select
                                name="action"
                                value={selectedAction}
                                onChange={handleActionChange}
                                className="form-control-sm"
                            >
                                <option value="">All</option>
                                {isLoadingActions ? (
                                    <option>Loading...</option>
                                ) : (
                                    smsActions?.map((action) => (
                                        <option key={action.id} value={action.id}>{action.name}</option>
                                    ))
                                )}
                            </Form.Select>

                            {/* ✅ Search Button */}
                            <Button
                                onClick={handleSearch}
                                variant="primary"
                                className="d-flex align-items-center justify-content-center me-2"
                                style={{ width: '250px' }}
                            >
                                <Icon
                                    icon="material-symbols:search-rounded"
                                    width="18"
                                    height="18"
                                    className="me-2"
                                />
                                Search
                            </Button>

                            {/* ✅ SMS Log Button */}
                            <Button
                                onClick={handleOpenSMSLog}
                                variant="secondary"
                                className="d-flex align-items-center justify-content-center me-2"
                                style={{ width: '250px' }}
                            >
                                <Icon
                                    icon="material-symbols:sms"
                                    width="18"
                                    height="18"
                                    className="me-2"
                                />
                                Email Logs
                            </Button>

                            {/* ✅ Modal for SMS Template Log */}
                            <Modal
                                show={showSMSLog}
                                onHide={handleCloseSMSLog}
                                dialogClassName="modal-xl"
                                centered
                            >
                                <Modal.Header closeButton>
                                    <Modal.Title>Email Logs</Modal.Title>
                                </Modal.Header>
                                <Modal.Body>
                                    <SMSTemplates />
                                </Modal.Body>
                            </Modal>

                        </div>
                    </div>

                    {isLoading ? (
                        <div className="d-flex justify-content-center align-items-center">
                            <Spinner animation="border" variant="primary" />
                        </div>
                    ) : (
                        <>
                            <Table striped bordered hover responsive>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th style={{ width: "15%" }}>Subject</th>

                                        {/* <th style={{ width: "30%" }}>Message</th> */}
                                        <th>Action</th>
                                        <th>Admin</th>
                                        <th>Client</th>
                                        <th>Employee</th>
                                        <th>Status</th>
                                        <th style={{ whiteSpace: "nowrap", width: "15%" }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {data?.emailTemplates.length > 0 ? (
                                        data.emailTemplates.map((template) => (
                                            <tr key={template.id}>
                                                <td>{template.id}</td>
                                                <td style={{
                                                    maxWidth: "300px",
                                                    wordBreak: "break-word",
                                                    whiteSpace: "normal",
                                                }}>
                                                    {template.subject}
                                                </td>
                                                {/* <td style={{
                                                    maxWidth: "300px",
                                                    wordBreak: "break-word",
                                                    whiteSpace: "normal",
                                                }}>
                                                    {template.msg}
                                                </td> */}
                                                <td>{template.action_name}</td>
                                                <td>{template.admin || "No"}</td>
                                                <td>{template.client || "No"}</td>
                                                <td>{template.employee || '-'}</td>
                                                <td>
                                                    <span className={`badge ${template.status === "Active" ? 'bg-success' : 'bg-danger'}`}>
                                                        {template.status}
                                                    </span>
                                                </td>

                                                {/* ✅ Actions */}
                                                <td style={{ whiteSpace: "nowrap" }}>
                                                    <Button
                                                        variant="primary"
                                                        size="sm"
                                                        className="me-2"
                                                        onClick={() => handleShowEditModal(template)} // ✅ Open Edit Modal
                                                    >
                                                        <Icon icon="mdi:pen" width={18} height={18} /> Edit
                                                    </Button>
                                                    <Button
                                                        variant={template.status === "Active" ? "danger" : "info"} // 🔥 Change color based on status
                                                        size="sm"
                                                        className="me-2"
                                                        onClick={() => handleSetInactive(template)} // ✅ Pass the entire template object
                                                    >
                                                        <Icon icon="mdi:close-circle" width={18} height={18} className="me-1" />
                                                        {template.status === "Active" ? "Inactive" : "Active"} {/* 🔥 Change text based on status */}
                                                    </Button>


                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr><td colSpan="9" className="text-center">No Email Templates found</td></tr>
                                    )}
                                </tbody>
                            </Table>

                        </>
                    )}

                    {/* Pagination */}
                    <div className="d-flex justify-content-end">
                        <Pagination>
                            <Pagination.Prev disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)} />
                            {[...Array(totalPages)].map((_, index) => (
                                <Pagination.Item key={index + 1} active={index + 1 === currentPage} onClick={() => setCurrentPage(index + 1)}>
                                    {index + 1}
                                </Pagination.Item>
                            ))}
                            <Pagination.Next disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage + 1)} />
                        </Pagination>
                    </div>
                </Card.Body>
            </Card>

            {/* ✅ Edit Modal (Opens when Edit Button is Clicked) */}
            <Edittemplate
                show={showEditModal}
                onClose={handleCloseEditModal}
                selectedTemplate={selectedTemplate}
            />
        </>
    );
};

export default SMSTemplate;
