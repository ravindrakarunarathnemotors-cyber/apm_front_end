

"use client";

import {
    Modal,
    Button,
    Col,
    FormLabel,
    FormControl,
    Row,
    Form,
    Card
} from "react-bootstrap";
import { Icon } from "@iconify/react";
import React, { useState, useEffect, useRef } from "react";
import Swal from "sweetalert2";
import {
    useGetSMSActionsQuery,
    useUpdateEmailTemplateMutation,
    useGetEmailTemplatebyidMutation,
} from "@/store/features/new_update";
import { FaInfoCircle } from "react-icons/fa";

import "react-quill/dist/quill.snow.css";
import dynamic from "next/dynamic";
const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

/* ====================================================== */

const Edittemplate = ({ show, onClose, selectedTemplate }) => {

    /* ================= API ================= */
    const { data: smsActions, isLoading: isLoadingActions } =
        useGetSMSActionsQuery();

    const [getEmailTemplateById] = useGetEmailTemplatebyidMutation();
    const [updateEmailTemplate, { isLoading }] =
        useUpdateEmailTemplateMutation();

    /* ================= STATE ================= */
    const [loadingTemplate, setLoadingTemplate] = useState(false);
    const [selectedActionName, setSelectedActionName] = useState("");

    const EMS_ACTIONS = [
        "Leave Approve",
        "Leave Reject",
        "Shift Roster",
        "Paysheet",
        "Employee Onboarding"
    ];

    const isEMSAction = EMS_ACTIONS.includes(selectedActionName);


    const quillRef = useRef(null);

    const [formData, setFormData] = useState({
        sms: "",
        subject: "",
        action: "",
        admin: false,
        client: false,
        Employee:false,
        status: "",
    });

    /* ================= LOAD TEMPLATE ================= */
    useEffect(() => {
        if (!selectedTemplate?.id || !smsActions?.length) return;

        const fetchTemplate = async () => {
            setLoadingTemplate(true);
            try {
                const res = await getEmailTemplateById({
                    id: selectedTemplate.id,
                }).unwrap();

                const selectedAction = smsActions.find(
                    (a) => a.name === res.action_name
                );

                setFormData({
                    sms: res.msg || "",
                    subject: res.subject || "",
                    action: selectedAction ? String(selectedAction.id) : "",
                    admin: res.admin === "Yes",
                    client: res.client === "Yes",
                    employee: res.employee === "Yes",
                    status: res.status || "Active",
                });

                // ✅ KEY LINE — shows variables on open
                setSelectedActionName(selectedAction?.name || "");
            } catch (err) {
                console.error(err);
            } finally {
                setLoadingTemplate(false);
            }
        };

        fetchTemplate();
    }, [selectedTemplate?.id, smsActions]);

    /* ================= HANDLERS ================= */
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;

        if (name === "action") {
            const selected = smsActions?.find((a) => a.id === parseInt(value));
            const actionName = selected?.name || "";
            setSelectedActionName(actionName);

            const isEMS = EMS_ACTIONS.includes(actionName);

            setFormData((prev) => ({
                ...prev,
                [name]: value,
                employee: isEMS ? prev.employee : false,
                client: isEMS ? false : prev.client,
            }));
            return;
        }

        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    /* ================= INSERT VARIABLE ================= */
    const insertVariable = (variable) => {
        const quill = quillRef.current?.getEditor?.();
        if (!quill) return;

        const range = quill.getSelection(true);
        const index = range ? range.index : quill.getLength();

        quill.insertText(index, ` ${variable} `);
        quill.setSelection(index + variable.length + 2);
    };

    /* ================= SAVE ================= */
    const handleSubmit = async () => {
        if (!formData.sms || !formData.action || !formData.status) {
            Swal.fire("Missing Data", "Please fill all required fields!", "warning");
            return;
        }

        try {
            await updateEmailTemplate({
                id: selectedTemplate.id,
                sms: formData.sms,
                subject: formData.subject,
                action: formData.action,
                admin: formData.admin ? "Yes" : "No",
                client: isEMSAction ? "No" : (formData.client ? "Yes" : "No"),   
                employee: isEMSAction ? "Yes" : "",   
                status: formData.status,
            }).unwrap();

            Swal.fire({
                icon: "success",
                title: "Updated!",
                text: "Email Template updated successfully",
                timer: 2000,
                showConfirmButton: false,
            });

            onClose();
        } catch (err) {
            Swal.fire("Error", "Update failed", "error");
        }
    };

    /* ================= EMPTY STATE ================= */
    const NoActionSelected = () => (
        <div className="text-center text-muted p-4">
            <FaInfoCircle size={40} className="mb-2" />
            <div>Select an action to view dynamic variables.</div>
        </div>
    );

    /* ================= VARIABLES (SAME AS CREATE) ================= */
    const Var = ({ v }) => (
        <p
            className="text-muted small lh-1 mb-1"
            style={{ cursor: "pointer" }}
            onClick={() => insertVariable(v)}
        >
            {v}
        </p>
    );

    const renderVariableBlock = () => {
        switch (selectedActionName) {
            case "New Order Placed":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[invoice_link]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_fee]</p>


                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Confirmed & Assigned":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_fee]</p>
                            <p className="text-muted small lh-1 mb-1">[tracking_id]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Dispatched":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Completed":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Cancelled":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Address Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[reason]</p>
                        </Col>
                        {/* <Col md={6}> */}

                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}
                    </Row>
                );

            case "Order Returned":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Address Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[reason]</p>
                        </Col>
                        {/* <Col md={6}> */}

                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}
                    </Row>
                );

            case "Order Link":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[invoice_link]</p>
                        </Col>


                    </Row>
                );
            case "Order Paid":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Loyalty points</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[all_points]</p>
                            <p className="text-muted small lh-1 mb-1">[spending_points]</p>
                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>


                    </Row>
                );
            case "User Registration":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>


                    </Row>
                );
            case "Guest Registration":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary ">User Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Username]</p>
                            <p className="text-muted small lh-1 mb-1">[Password]</p>
                        </Col>


                    </Row>
                );

                   case "Leave Approve":
                    case "Leave Reject":
                        return (
                            <Row>
                                <Col md={6}>
                                    <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                                    <p className="text-muted small lh-1 mb-1">[first_name]</p>
                                    <p className="text-muted small lh-1 mb-1">[name]</p>
                                    <p className="text-muted small lh-1 mb-1">[phone]</p>
                                    <p className="text-muted small lh-1 mb-1">[email]</p>

                                    <FormLabel className="fw-bold text-primary mt-3">Leave Information</FormLabel>
                                    <p className="text-muted small lh-1 mb-1">[leave_type]</p>
                                    <p className="text-muted small lh-1 mb-1">[from_date]</p>
                                    <p className="text-muted small lh-1 mb-1">[to_date]</p>
                                </Col>
                                <Col md={6}>
                                    <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                                    <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                                    <p className="text-muted small lh-1 mb-1">[Webname]</p>
                                    <p className="text-muted small lh-1 mb-1">[company_email]</p>
                                </Col>
                            </Row>
                        );
                    case "Shift Roster":
                    return (
                        <Row>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[first_name]</p>
                                <p className="text-muted small lh-1 mb-1">[name]</p>
                                <p className="text-muted small lh-1 mb-1">[phone]</p>

                                <FormLabel className="fw-bold text-primary mt-3">Shift Information</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[shift_name]</p>
                                <p className="text-muted small lh-1 mb-1">[shift_date]</p>
                                <p className="text-muted small lh-1 mb-1">[shift_start]</p>
                                <p className="text-muted small lh-1 mb-1">[shift_end]</p>
                            </Col>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                                <p className="text-muted small lh-1 mb-1">[Webname]</p>
                                <p className="text-muted small lh-1 mb-1">[company_email]</p>
                            </Col>
                        </Row>
                    );

                   case "Paysheet":
                    return (
                        <Row>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[first_name]</p>
                                <p className="text-muted small lh-1 mb-1">[name]</p>
                                <p className="text-muted small lh-1 mb-1">[phone]</p>
                                <p className="text-muted small lh-1 mb-1">[email]</p>

                                <FormLabel className="fw-bold text-primary mt-3">Paysheet Information</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[net_salary]</p>
                                <p className="text-muted small lh-1 mb-1">[salary_start]</p>
                                <p className="text-muted small lh-1 mb-1">[salary_end]</p>
                                <p className="text-muted small lh-1 mb-1">[Paysheet_Link]</p>
                            </Col>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                                <p className="text-muted small lh-1 mb-1">[Webname]</p>
                                <p className="text-muted small lh-1 mb-1">[company_email]</p>
                            </Col>
                        </Row>
                    );
                    case "Employee Onboarding":
                    return (
                        <Row>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[first_name]</p>
                                <p className="text-muted small lh-1 mb-1">[name]</p>
                                <p className="text-muted small lh-1 mb-1">[phone]</p>
                                <p className="text-muted small lh-1 mb-1">[email]</p>

                                <FormLabel className="fw-bold text-primary mt-3">Onboarding Information</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[join_date]</p>
                            </Col>
                            <Col md={6}>
                                <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                                <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                                <p className="text-muted small lh-1 mb-1">[Webname]</p>
                                <p className="text-muted small lh-1 mb-1">[company_email]</p>
                                {/* email template only */}
                                <p className="text-muted small lh-1 mb-1">[website]</p>
                            </Col>
                        </Row>
                    );
            default:
                return (
                    <NoActionSelected />

                );
        }
    };

    /* ================= UI ================= */
    return (
        <Modal show={show} onHide={onClose} centered size="lg">
            <Modal.Header closeButton>
                <Modal.Title>Edit Email Template</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                {loadingTemplate ? (
                    <div className="text-center my-5">
                        <div className="spinner-border text-primary" />
                    </div>
                ) : (
                    <Row>
                        {/* LEFT */}
                        <Col md={8}>
                            <Form>
                                <FormLabel>Subject</FormLabel>
                                <FormControl
                                    name="subject"
                                    value={formData.subject}
                                    onChange={handleChange}
                                />

                                <FormLabel className="mt-3">Email Body</FormLabel>
                                <ReactQuill
                                    ref={quillRef}
                                    value={formData.sms}
                                    onChange={(v) =>
                                        handleChange({
                                            target: { name: "sms", value: v },
                                        })
                                    }
                                />

                                <Row className="mt-3">
                                    <Col md={6}>
                                        <FormLabel>Action</FormLabel>
                                        <Form.Select
                                            name="action"
                                            value={formData.action}
                                            onChange={handleChange}
                                        >
                                            <option value="">Select</option>
                                            {smsActions?.map((a) => (
                                                <option key={a.id} value={a.id}>
                                                    {a.name}
                                                </option>
                                            ))}
                                        </Form.Select>
                                    </Col>

                                    <Col md={6}>
                                        <FormLabel>Status</FormLabel>
                                        <Form.Select
                                            name="status"
                                            value={formData.status}
                                            onChange={handleChange}
                                        >
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </Form.Select>
                                    </Col>
                                </Row>

                                <Row className="mt-3">
                                    <Col md={4}>
                                        <Form.Check
                                            label="Admin"
                                            name="admin"
                                            checked={formData.admin}
                                            onChange={handleChange}
                                        />
                                    </Col>
                                    <Col md={4}>
                                        <Form.Check
                                            label="Client"
                                            name="client"
                                            checked={formData.client}
                                            onChange={handleChange}
                                            disabled={isEMSAction}
                                        />
                                    </Col>
                                        <Col md={4}>
                                            <Form.Check
                                                label="Employee"
                                                name="employee"
                                                checked={formData.employee}
                                                onChange={handleChange}
                                                disabled={!isEMSAction}      
                                            />
                                        </Col>

                                </Row>

                                <div className="text-end mt-4">
                                    <Button onClick={handleSubmit} disabled={isLoading}>
                                        <Icon icon="mdi:content-save" className="me-1" />
                                        Update
                                    </Button>
                                </div>
                            </Form>
                        </Col>

                        {/* RIGHT */}
                        <Col md={4}>
                            <Card className="p-3 h-100">
                                {renderVariableBlock()}
                            </Card>
                        </Col>
                    </Row>
                )}
            </Modal.Body>
        </Modal>
    );
};

export default Edittemplate;

