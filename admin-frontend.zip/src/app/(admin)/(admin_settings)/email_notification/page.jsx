"use client";

import ComponentContainerCard from '@/components/ComponentContainerCard';
import { Button, Col, FormLabel, FormControl, Row, Form, Card } from 'react-bootstrap';
import React, { useState, useEffect, useRef } from "react";
import { Icon } from "@iconify/react";
import {
    useGetSMSActionsQuery,
    useAddEmailTemplateMutation
} from '@/store/features/new_update';
import Swal from 'sweetalert2';
import SMSTemplates from './sms-template/page';
import { FaInfoCircle } from 'react-icons/fa';
// import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import dynamic from 'next/dynamic';

const ReactQuill = dynamic(() => import('react-quill'), { ssr: false });

const SMSTemplate = () => {
   
    const [selectedActionName, setSelectedActionName] = useState('');
    const EMS_ACTIONS = [
        "Leave Approve",
        "Leave Reject",
        "Shift Roster",
        "Paysheet",
        "Employee Onboarding"
    ];
    const isEMSAction = EMS_ACTIONS.includes(selectedActionName);

    // Fetch SMS actions for dropdown
    const { data: smsActions, isLoading: isLoadingActions, refetch, error } = useGetSMSActionsQuery();

    // Mutation for adding SMS Template
    const [addSMSTemplate, { isLoading }] = useAddEmailTemplateMutation();
    
    const quillRef = useRef(null);

    useEffect(() => {
        const quill = quillRef.current?.getEditor?.();
        if (!quill) return;

        const editorRoot = quill.root;                     // .ql-editor
        const container = editorRoot?.parentElement;       // .ql-container
        const toolbar = container?.previousElementSibling; // .ql-toolbar
        const outer = toolbar?.parentElement;              // ReactQuill outer div

        // Outer: flex column so toolbar + container stack correctly
        if (outer) {
            Object.assign(outer.style, {
                display: "flex",
                flexDirection: "column",
                height: "100%",
                boxSizing: "border-box",
            });
        }

        // Toolbar: keep normal border, no overflow
        if (toolbar) {
            Object.assign(toolbar.style, {
                flex: "0 0 auto",
                overflow: "hidden",
                border: "1px solid #ced4da",
                borderBottom: "0", // so the container’s top meets it cleanly
                boxSizing: "border-box",
            });
        }

        // Container: fill remaining height and SHOW its border (incl. bottom)
        if (container) {
            Object.assign(container.style, {
                flex: "1 1 auto",
                height: "auto",
                minHeight: "0",
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
                border: "1px solid #ced4da", // <-- brings back the side + bottom border
                borderTop: "0",              // match Quill default
                boxSizing: "border-box",
                background: "#fff",
            });
        }

        // Editor: scroll inside
        if (editorRoot) {
            Object.assign(editorRoot.style, {
                flex: "1 1 auto",
                height: "100%",
                overflowY: "auto",
                overflowX: "hidden",
                wordBreak: "break-word",
                whiteSpace: "pre-wrap",
                fontSize: "14px",
                padding: "4px 8px",
                boxSizing: "border-box",
            });
        }
    }, []);




    // Form state
    const [formData, setFormData] = useState({
        subject: '',
        sms: '',
        action: '',
        Admin: false,
        Client: false,
        Employee: false,
        status: ''
    });

    // Handle input changes
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;

        if (name === "action") {
            const selected = smsActions?.find((a) => a.id === parseInt(value));
            const actionName = selected?.name || '';
            setSelectedActionName(actionName);

            const isEMS = EMS_ACTIONS.includes(actionName);

            setFormData((prev) => ({
                ...prev,
                [name]: value,
                Employee: isEMS ? prev.Employee : false,
                Client: isEMS ? false : prev.Client,
            }));
            return;
        }

        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value
        });
    };

    // Submit form
    const handleSubmit = async () => {
      
        if (!formData.subject || !formData.sms || !formData.action || !formData.status) {
            Swal.fire({ icon: "warning", title: "Missing Data", text: "Please fill all required fields!" });
            return;
        }

        try {
            await addSMSTemplate({
                sms: formData.sms,
                subject: formData.subject,
                action: parseInt(formData.action, 10), // ✅ Ensure action is an integer
                Admin: formData.Admin ? "Yes" : "",
                Client: isEMSAction ? "No" : (formData.Client ? "Yes" : ""),
                Employee: isEMSAction ? "Yes" : "",
                status: formData.status
            }).unwrap();

            Swal.fire({ icon: "success", title: "Added!", text: "Email Template added successfully", timer: 2000, showConfirmButton: false });

            // Reset form
            setFormData({ subject: '', sms: '', action: '', Admin: false, Client: false, Employee: false, status: '' });
            setSelectedActionName('');

        } catch (err) {
            console.error("Error submitting form:", err);
            Swal.fire({
                icon: "error",
                title: "Submission Failed",
                text: err?.data?.message || "Something went wrong. Please try again!",
            });
        }
    };


    const NoActionSelected = () => (
        <div style={{
            textAlign: 'center',
            color: '#bebebeff',
            fontSize: '0.9rem',
            padding: '30px 10px'
        }}>
            <FaInfoCircle size={40} style={{ marginBottom: 10, color: '#c2c2c2ff' }} />
            <div>Select an action to view dynamic variables.</div>
        </div>
    );



    const renderVariableBlock = () => {
        switch (selectedActionName) {
            case "New Order Placed":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[invoice_link]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_fee]</p>


                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Confirmed & Assigned":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_fee]</p>
                            <p className="text-muted small lh-1 mb-1">[tracking_id]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Dispatched":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Completed":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        {/* <Col md={6}> */}
                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}

                    </Row>
                );

            case "Order Cancelled":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Address Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[reason]</p>
                        </Col>
                        {/* <Col md={6}> */}

                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}
                    </Row>
                );

            case "Order Returned":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Address Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[reason]</p>
                        </Col>
                        {/* <Col md={6}> */}

                        <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                        <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                        <p className="text-muted small lh-1 mb-1">[Webname]</p>
                        <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        {/* </Col> */}
                    </Row>
                );

            case "Order Link":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[invoice_link]</p>
                        </Col>


                    </Row>
                );
            case "Order Paid":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Order Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[order_id]</p>
                            <p className="text-muted small lh-1 mb-1">[delivery_type]</p>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shipping Address</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[address]</p>
                            <p className="text-muted small lh-1 mb-1">[city]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Loyalty points</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[all_points]</p>
                            <p className="text-muted small lh-1 mb-1">[spending_points]</p>
                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>


                    </Row>
                );
            case "User Registration":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>


                    </Row>
                );
            case "Guest Registration":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary ">User Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Username]</p>
                            <p className="text-muted small lh-1 mb-1">[Password]</p>
                        </Col>


                    </Row>
                );

            case "Send Invoice":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Invoice Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Inv_Link]</p>
                            <p className="text-muted small lh-1 mb-1">[Inv_Button]</p>

                        </Col>


                    </Row>
                );



            case "Send Quotation":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Quotation Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Quo_Link]</p>
                            <p className="text-muted small lh-1 mb-1">[Quo_Button]</p>

                        </Col>


                    </Row>
                );

            case "Leave Approve":
            case "Leave Reject":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[first_name]</p>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Leave Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[leave_type]</p>
                            <p className="text-muted small lh-1 mb-1">[from_date]</p>
                            <p className="text-muted small lh-1 mb-1">[to_date]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>
                    </Row>
                );

            case "Shift Roster":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[first_name]</p>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Shift Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[shift_name]</p>
                            <p className="text-muted small lh-1 mb-1">[shift_date]</p>
                            <p className="text-muted small lh-1 mb-1">[shift_start]</p>
                            <p className="text-muted small lh-1 mb-1">[shift_end]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>
                    </Row>
                );
            case "Paysheet":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[first_name]</p>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Paysheet Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[net_salary]</p>
                            <p className="text-muted small lh-1 mb-1">[salary_start]</p>
                            <p className="text-muted small lh-1 mb-1">[salary_end]</p>
                            <p className="text-muted small lh-1 mb-1">[Paysheet_Link]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                        </Col>
                    </Row>
                );

            case "Employee Onboarding":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Employee Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[first_name]</p>
                            <p className="text-muted small lh-1 mb-1">[name]</p>
                            <p className="text-muted small lh-1 mb-1">[phone]</p>
                            <p className="text-muted small lh-1 mb-1">[email]</p>

                            <FormLabel className="fw-bold text-primary mt-3">Onboarding Information</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[join_date]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Branding Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[Hotline]</p>
                            <p className="text-muted small lh-1 mb-1">[Webname]</p>
                            <p className="text-muted small lh-1 mb-1">[company_email]</p>
                            <p className="text-muted small lh-1 mb-1">[website]</p>
                        </Col>
                    </Row>
                );


            case "Invoice Link":
                return (
                    <Row>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mb-1">Invoice Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[amount]</p>
                            <p className="text-muted small lh-1 mb-1">[date]</p>
                            <p className="text-muted small lh-1 mb-1">[inv_link]</p>
                        </Col>
                        <Col md={6}>
                            <FormLabel className="fw-bold text-primary mt-0">Customer Details</FormLabel>
                            <p className="text-muted small lh-1 mb-1">[loyalty_points]</p>
                            <p className="text-muted small lh-1 mb-1">[customer_name]</p>
                        </Col>
                    </Row>
                );

            default:
                return (
                    <NoActionSelected />

                );
        }
    };




    return (
        <>
            <Row>
                {/* Left Side - SMS Form */}
                <Col md={8}>
                    <Card className="p-3 h-100">
                        <Form>
                            <div className="d-flex justify-content-between align-items-center mb-3">
                                <h5 className="mb-0">Create Email Template</h5>
                                <div className="d-flex align-items-center" style={{ gap: "8px" }}></div>
                            </div>

                            <Row className="mb-3">
                                <Col md={6}>
                                    <FormLabel>Action</FormLabel>
                                    <Form.Select name="action" value={formData.action} onChange={handleChange}>
                                        <option value="" disabled hidden>Select</option>
                                        {isLoadingActions ? <option>Loading...</option> :
                                            smsActions?.map((action) => (
                                                <option key={action.id} value={action.id}>{action.name}</option>
                                            ))
                                        }
                                    </Form.Select>
                                </Col>
                                <Col md={6}>
                                    <FormLabel>Status</FormLabel>
                                    <Form.Select name="status" value={formData.status} onChange={handleChange}>
                                        <option value="" disabled hidden>Select</option>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </Form.Select>
                                </Col>
                            </Row>

                            <Row className="mb-3">
                                <Col md={12}>
                                    <FormLabel htmlFor="subject">Email Subject</FormLabel>
                                    <FormControl
                                        as="textarea"
                                        rows={1}
                                        id="subject"
                                        name="subject"
                                        value={formData.subject}
                                        onChange={handleChange}
                                        placeholder="Enter Email Subject"
                                    />

                                    <small className="text-muted d-block mt-1">
                                        {`Sample: "Order Completed"`}
                                    </small>


                                </Col>
                            </Row>
                            <Row className="mb-3">
                                <Col md={12}>
                                    <FormLabel htmlFor="sms">Email</FormLabel>
                                    <div
                                        style={{
                                            height: "300px",
                                            display: "flex",
                                            flexDirection: "column",
                                            overflow: "hidden",
                                            boxSizing: "border-box",
                                        }}
                                    >
                                        <ReactQuill
                                            ref={quillRef}
                                            id="sms"
                                            name="sms"
                                            value={formData.sms}
                                            onChange={(value) => handleChange({ target: { name: "sms", value } })}
                                            placeholder="Enter Email Template"
                                            modules={{
                                                toolbar: [
                                                    [{ header: [1, 2, false] }],
                                                    ["bold", "italic", "underline"],
                                                    [{ list: "ordered" }, { list: "bullet" }],
                                                    ["link"],
                                                    [{ align: [] }],
                                                    ["clean"],
                                                ],
                                            }}
                                            style={{
                                                flex: "1 1 auto",
                                                display: "flex",
                                                flexDirection: "column",
                                                minHeight: 0,
                                            }}
                                        />
                                        <div style={{ height: 1, background: "#ced4da", width: "100%" }} />

                                    </div>

                                    <div>
                                        <small
                                            className="text-muted d-block"
                                            style={{ marginTop: '1%' }} // or '2px', '0px', etc.
                                        >
                                            {`Sample: "Hello [FName], your parcel [WaybillID] is out for delivery. Contact: [RiderMobile]."`}
                                        </small>
                                    </div>

                                </Col>
                            </Row>

                            <Row >
                                <Col md={4}>
                                    <Form.Check type="checkbox" label="Admin" name="Admin" checked={formData.Admin} onChange={handleChange} />
                                </Col>
                                <Col md={4}>
                                    <Form.Check type="checkbox" label="Client" name="Client" checked={formData.Client} onChange={handleChange} disabled={isEMSAction} />
                                </Col>

                                <Col md={4}>
                                    <Form.Check type="checkbox" label="Employee" name="Employee" checked={formData.Client} onChange={handleChange} disabled={!isEMSAction} />
                                </Col>

                            </Row>

                            <Row >
                                <Col sm={12} className="text-end">
                                    <Button variant="primary" onClick={handleSubmit} disabled={isLoading}>
                                        <Icon icon="mdi:content-save" width={20} height={20} className="me-1" />
                                        {isLoading ? "Saving..." : "Add"}
                                    </Button>
                                </Col>
                            </Row>
                        </Form>
                    </Card>
                </Col>


                {/* Right Side - Dynamic SMS Variables */}
                <Col md={4}>
                    <Card className="p-3 border-0 shadow-sm h-100">
                        <Card.Body className="p-2">
                            {renderVariableBlock()}
                        </Card.Body>
                    </Card>
                </Col>



            </Row>


            <SMSTemplates />
        </>
    );


};

export default SMSTemplate;
