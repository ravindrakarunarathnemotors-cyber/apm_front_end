'use client'

import React from 'react'
import { Button, Col, FormControl, FormLabel, Row, Form } from 'react-bootstrap'

const SystemColorsTab = ({ register, handleSubmit, errors, onSubmit }) => {
  const colors = [
    'primary_color',
    'secondary_color',
    'background_color',
    'title_color',
    'subtitle_color',
    'text_color',
    'button_primary_color',
    'button_secondary_color',
    'button_success_color',
    'button_warning_color',
    'button_danger_color',
    'hover_color',
    'border_radius',
    'box_shadow',
  ]

  //color pickers
  const colorFields = [
    'primary_color',
    'secondary_color',
    'background_color',
    'title_color',
    'subtitle_color',
    'text_color',
    'button_primary_color',
    'button_secondary_color',
    'button_success_color',
    'button_warning_color',
    'button_danger_color',
    'hover_color',
  ]

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3">
        {colors.map((field) => {
          const isColorField = colorFields.includes(field)
          return (
            <Col md={4} key={field}>
              <FormLabel>{field.replaceAll('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}</FormLabel>
              <FormControl
                {...register(field, {
                  ...(field === 'box_shadow' || field === 'border_radius'
                    ? {
                        valueAsNumber: true,
                        validate: (value) =>
                          value === undefined || value === '' || Number.isInteger(value) || `${field.replaceAll('_', ' ')} must be an integer`,
                      }
                    : {}),
                })}
                type={isColorField ? 'color' : field === 'box_shadow' || field === 'border_radius' ? 'number' : 'text'}
                step={field === 'box_shadow' || field === 'border_radius' ? '1' : undefined}
                isInvalid={!!errors[field]}
                defaultValue=""
              />
            </Col>
          )
        })}
      </Row>
      <div className="text-end mt-3">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save Colors</Button>
      </div>
    </Form>
  )
}

export default SystemColorsTab
