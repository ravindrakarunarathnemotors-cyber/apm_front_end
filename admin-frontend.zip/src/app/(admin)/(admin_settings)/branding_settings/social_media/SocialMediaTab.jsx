'use client'

import React from 'react'
import { Button, Col, FormControl, FormLabel, Row, Form } from 'react-bootstrap'

const SocialMediaTab = ({ register, handleSubmit, errors, onSubmit }) => {
  const platforms = ['facebook_url', 'twitter_url', 'instagram_url', 'linkedin_url', 'youtube_url', 'tiktok_url']

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3">
        {platforms.map((platform) => (
          <Col md={6} key={platform}>
            <FormLabel>{platform.replaceAll('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}</FormLabel>
            <FormControl {...register(platform)} isInvalid={!!errors[platform]} />
          </Col>
        ))}
      </Row>
      <div className="text-end mt-3">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save Social Links</Button>
      </div>
    </Form>
  )
}

export default SocialMediaTab
