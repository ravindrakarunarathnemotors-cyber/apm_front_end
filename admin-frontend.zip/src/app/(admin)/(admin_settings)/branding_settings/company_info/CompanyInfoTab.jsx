'use client'

import React from 'react'
import { Button, Col, FormControl, FormLabel, Row, Form } from 'react-bootstrap'

const CompanyInfoTab = ({ register, handleSubmit, errors, onSubmit }) => {
  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3">
        <Col md={6}>
          <FormLabel>Company Name</FormLabel>
          <FormControl {...register('company_name')} isInvalid={!!errors.company_name} />
        </Col>
        <Col md={6}>
          <FormLabel>Slogan</FormLabel>
          <FormControl {...register('slogan')} isInvalid={!!errors.slogan} />
        </Col>
        <Col md={6}>
          <FormLabel>Address Line 1</FormLabel>
          <FormControl {...register('address_1')} isInvalid={!!errors.address_1} />
        </Col>
        <Col md={6}>
          <FormLabel>Address Line 2</FormLabel>
          <FormControl {...register('address_2')} isInvalid={!!errors.address_2} />
        </Col>
        <Col md={6}>
          <FormLabel>Hotline</FormLabel>
          <FormControl {...register('hotline')} isInvalid={!!errors.hotline} />
        </Col>
        <Col md={6}>
          <FormLabel>General Phone Number</FormLabel>
          <FormControl {...register('customer_support_phone')} isInvalid={!!errors.customer_support_phone} />
        </Col>
        <Col md={6}>
          <FormLabel>Support Email</FormLabel>
          <FormControl {...register('support_email')} isInvalid={!!errors.support_email} />
        </Col>
        <Col md={6}>
          <FormLabel>Info Email</FormLabel>
          <FormControl {...register('info_email')} isInvalid={!!errors.info_email} />
        </Col>
        <Col md={6}>
          <FormLabel>Billing Email</FormLabel>
          <FormControl {...register('billing_email')} isInvalid={!!errors.billing_email} />
        </Col>
        <Col md={6}>
          <FormLabel>Website URL</FormLabel>
          <FormControl {...register('website_url')} isInvalid={!!errors.website_url} />
        </Col>
        {/* <Col md={6}>
          <FormLabel>Client Portal URL</FormLabel>
          <FormControl isInvalid={!!errors.client_portal_url} />
        </Col> */}
        {/* <Col md={6}>
          <FormLabel>Admin Portal URL</FormLabel>
          <FormControl {...register('admin_portal_url')} isInvalid={!!errors.admin_portal_url} />
        </Col> */}
        {/* <Col md={6}>
          <FormLabel>API URL</FormLabel>
          <FormControl isInvalid={!!errors.api_url} />
        </Col> */}
      </Row>
      <div className="text-end mt-3">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save Company Info</Button>
      </div>
    </Form>
  )
}

export default CompanyInfoTab
