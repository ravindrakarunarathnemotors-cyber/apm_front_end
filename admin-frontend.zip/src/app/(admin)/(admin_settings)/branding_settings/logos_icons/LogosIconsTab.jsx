'use client'

import React, { useState, useEffect, useRef } from 'react'
import { Button, Col, FormLabel, Row, Spinner, Card } from 'react-bootstrap'
import axios from 'axios'
import Swal from 'sweetalert2'
// import Image from 'next/image'

import { useUpdateBrandingSettingsMutation, useGetBrandingSettingsQuery } from '@/store/features/apiSlice'

const LogosIconsTab = () => {
  // Mapping for custom labels
  const fieldLabels = {
    logo_url: 'Sidebar Image (Collapsed)',
    logo_url_white: 'Main Logo (Coloured)',
    logo_name_dark: 'Logo (White Text)',
    welcome_image: 'Welcome Image',
    // logo_name_white: 'White Text Logo',
    favicon_url: 'Favicon',
    // app_icon_android: 'Android App Icon',
    // app_icon_ios: 'iOS App Icon',
  }

  const fields = Object.keys(fieldLabels)

  const { data: settingsData, isLoading } = useGetBrandingSettingsQuery()
  const [updateBrandingSettings] = useUpdateBrandingSettingsMutation()
  const [uploadingField, setUploadingField] = useState(null)
  const [imageUrls, setImageUrls] = useState({})
  const fileInputRefs = useRef({})

  useEffect(() => {
    if (settingsData?.data) {
      setImageUrls(settingsData.data)
    }
  }, [settingsData])

  const handleFileChange = async (e, field) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadingField(field)

    try {
      const date = new Date()
        .toISOString()
        .replace(/[-:.T]/g, '')
        .slice(0, 14)
      const ext = file.name.split('.').pop()
      const newFileName = `${date}-${field}.${ext}`

      const formData = new FormData()
      formData.append('file', file, newFileName)

      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/branding/upload`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const fileUrl = response.data.url || response.data.fileUrl
      const finalUrl = fileUrl?.replace('https://i4i4.fra.idrivee2-52.com', 'https://d8y1.c2.e2-9.dev')

      setImageUrls((prev) => ({ ...prev, [field]: finalUrl }))
    } catch (err) {
      console.error(`Error uploading ${field}:`, err?.response?.data || err.message)
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: `Failed to upload ${field}. Please try again.`,
      })
    } finally {
      setUploadingField(null)
      if (fileInputRefs.current[field]) {
        fileInputRefs.current[field].value = ''
      }
    }
  }

  const triggerFileInput = (field) => {
    if (fileInputRefs.current[field]) {
      fileInputRefs.current[field].click()
    }
  }

  const handleLogosSubmit = async () => {
    try {
      await updateBrandingSettings(imageUrls).unwrap()
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Logos updated successfully!',
        confirmButtonText: 'OK',
      })
    } catch (err) {
      console.error('Error updating branding settings:', err)
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: 'Failed to update logos. Please try again.',
        confirmButtonText: 'OK',
      })
    }
  }

  if (isLoading) {
    return <div>Loading branding settings...</div>
  }

  return (
    <>
      <Row xs={1} md={3} className="g-3">
        {fields.map((field) => (
          <Col key={field}>
            <Card className="h-100 text-center p-2">
              <FormLabel className="mb-2" style={{ fontSize: '0.9rem' }}>
                {fieldLabels[field] || field}
              </FormLabel>
              {imageUrls[field] ? (
                <div
                  style={{
                    backgroundColor: field === 'logo_name_dark' ? '#000' : 'transparent',
                    padding: '8px',
                    borderRadius: '6px',
                    marginBottom: '0.75rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100px',
                  }}>
                  <img
                    src={imageUrls[field]}
                    alt={`${field} preview`}
                    style={{
                      maxWidth: '100%',
                      maxHeight: '100%',
                      objectFit: 'contain',
                    }}
                    loading="lazy"
                  />
                </div>
              ) : (
                <div
                  style={{
                    height: '100px',
                    border: '1px dashed #ccc',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: '0.75rem',
                    color: '#999',
                    fontSize: '0.85rem',
                  }}>
                  No image
                </div>
              )}

              <input
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                ref={(el) => (fileInputRefs.current[field] = el)}
                onChange={(e) => handleFileChange(e, field)}
                disabled={uploadingField !== null}
              />

              <Button
                variant="outline-primary"
                size="sm"
                style={{ minWidth: '110px' }}
                onClick={() => triggerFileInput(field)}
                disabled={uploadingField !== null}>
                {uploadingField === field ? (
                  <>
                    <Spinner animation="border" size="sm" /> Uploading...
                  </>
                ) : imageUrls[field] ? (
                  'Replace Image'
                ) : (
                  'Upload Image'
                )}
              </Button>
            </Card>
          </Col>
        ))}
      </Row>

      <div className="text-end mt-3">
        <Button
          className="btn bg-primary border border-primary px-3"
          type="button"
          onClick={handleLogosSubmit}
          disabled={uploadingField !== null}
          size="md">
          Save Logos
        </Button>
      </div>
    </>
  )
}

export default LogosIconsTab
