'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Tab, Tabs } from 'react-bootstrap'
import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import {
  useUpdateBrandingSettingsMutation,
  useGetBrandingSettingsQuery,
  // Removed: useUploadFileMutation,
} from '../../../../../src/store/features/apiSlice'

import CompanyInfoTab from './company_info/CompanyInfoTab'
import LogosIconsTab from './logos_icons/LogosIconsTab'
import SystemColorsTab from './system_colors/SystemColorsTab'
// import TypographyTab from './typography/TypographyTab'
import SocialMediaTab from './social_media/SocialMediaTab'
import LegalSeoTab from './legal_seo/LegalSeoTab'

// Helper validation function (unchanged)
function validateFileOrUrl(value) {
  if (!value) return true
  if (typeof value === 'string') return /^https?:\/\//.test(value)
  if (value instanceof FileList) return value.length > 0
  return false
}

const schema = yup.object().shape({
  company_name: yup.string().required('Company Name is required'),
  slogan: yup.string(),
  logo_url: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  logo_url_white: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  logo_name_dark: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  logo_name_white: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  favicon_url: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  app_icon_android: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  app_icon_ios: yup.mixed().test('fileOrUrl', 'Invalid file or URL', validateFileOrUrl).nullable(),
  primary_color: yup.string().required(),
  secondary_color: yup.string().required(),
  background_color: yup.string().required(),
  title_color: yup.string(),
  subtitle_color: yup.string(),
  text_color: yup.string(),
  button_primary_color: yup.string(),
  button_secondary_color: yup.string(),
  button_success_color: yup.string(),
  button_warning_color: yup.string(),
  button_danger_color: yup.string(),
  border_radius: yup.string(),
  box_shadow: yup.string(),
  font_family: yup.string(),
  font_size: yup.string(),
  hotline: yup.string(),
  customer_support_phone: yup.string(),
  address_1: yup.string(),
  address_2: yup.string(),
  support_email: yup.string().email(),
  info_email: yup.string().email(),
  billing_email: yup.string().email(),
  website_url: yup.string().url(),
  client_portal_url: yup.string().url().nullable(),
  admin_portal_url: yup.string().url().nullable(),
  api_url: yup.string().url().nullable(),
  facebook_url: yup.string().url().nullable(),
  twitter_url: yup.string().url().nullable(),
  instagram_url: yup.string().url().nullable(),
  linkedin_url: yup.string().url().nullable(),
  youtube_url: yup.string().url().nullable(),
  tiktok_url: yup.string().url().nullable(),
  terms_url: yup.string().url().nullable(),
  privacy_url: yup.string().url().nullable(),
  copyright_text: yup.string(),
  seo_meta_title: yup.string(),
  seo_meta_description: yup.string(),
  seo_meta_keywords: yup.string(),
  footer_text: yup.string(),
})

const BrandingSettingsFormTabs = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue, // ✅ ADD
    watch,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
  })

  const [activeTab, setActiveTab] = useState('company')
  const [updateBrandingSettings] = useUpdateBrandingSettingsMutation()
  const { data, isLoading, error } = useGetBrandingSettingsQuery()
  // Removed: const [uploadFile] = useUploadFileMutation()

  useEffect(() => {
    if (data?.data) {
      reset(data.data)
    }
  }, [data, reset])

  const onSubmit = async (formData) => {
    try {
      // Now no file uploads here —
      // LogosIconsTab handles upload & updates independently

      await updateBrandingSettings(formData).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Branding settings updated successfully!',
        confirmButtonText: 'OK',
      })
    } catch (err) {
      console.error('Error updating branding settings:', err)
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: 'Something went wrong while updating branding settings.',
        confirmButtonText: 'Try Again',
      })
    }
  }

  if (isLoading) return <div>Loading branding settings...</div>
  if (error) return <div>Error loading branding settings.</div>

  return (
    <ComponentContainerCard title="Branding Settings">
      <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k || 'company')} className="my-3">
        <Tab eventKey="company" title="Company Info">
          <CompanyInfoTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={handleSubmit(onSubmit)} />
        </Tab>
        <Tab eventKey="logos" title="Graphics">
          <LogosIconsTab
            register={register}
            handleSubmit={handleSubmit}
            errors={errors}
            onSubmit={handleSubmit(onSubmit)}
            // Note: handleFileChange & upload now handled inside LogosIconsTab
          />
        </Tab>
        <Tab eventKey="colors" title="System Colors">
          <SystemColorsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={handleSubmit(onSubmit)} />
        </Tab>
        {/* <Tab eventKey="typography" title="Typography">
          <TypographyTab
            register={register}
            handleSubmit={handleSubmit}
            errors={errors}
            onSubmit={handleSubmit(onSubmit)}
          />
        </Tab> */}
        <Tab eventKey="social" title="Social Media">
          <SocialMediaTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={handleSubmit(onSubmit)} />
        </Tab>
        <Tab eventKey="legal" title="Legal & SEO">
          <LegalSeoTab
            register={register}
            handleSubmit={handleSubmit}
            errors={errors}
            onSubmit={handleSubmit(onSubmit)}
            setValue={setValue} // ✅ REQUIRED
            watch={watch} // ✅ REQUIRED
          />
        </Tab>
      </Tabs>
    </ComponentContainerCard>
  )
}

export default BrandingSettingsFormTabs
