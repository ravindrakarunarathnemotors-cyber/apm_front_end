'use client'

import React from 'react'
import { Button, Col, FormControl, FormLabel, Row, Form } from 'react-bootstrap'

const TypographyTab = ({ register, handleSubmit, errors, onSubmit }) => {
  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row>
        <Col md={6}>
          <FormLabel>Font Family</FormLabel>
          <FormControl {...register('font_family')} isInvalid={!!errors.font_family} />
        </Col>
        <Col md={6}>
          <FormLabel>Font Size</FormLabel>
          <FormControl {...register('font_size')} isInvalid={!!errors.font_size} />
        </Col>
      </Row>
      <div className="text-end mt-3">
        <Button type="submit">Save Typography</Button>
      </div>
    </Form>
  )
}

export default TypographyTab
