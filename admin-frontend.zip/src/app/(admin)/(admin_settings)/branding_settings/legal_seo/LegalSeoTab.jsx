'use client'

import React, { useState, useRef } from 'react'
import axios from 'axios'
import Swal from 'sweetalert2'
import { Button, Col, FormControl, FormLabel, Row, Form, Card, Spinner } from 'react-bootstrap'

const LegalSeoTab = ({
  register,
  handleSubmit,
  errors,
  onSubmit,
  setValue, // ✅ ADD
  watch, // ✅ ADD
}) => {
  // Use useState to track the character count for the footer_text field
  const [footerTextCount, setFooterTextCount] = useState(0)
  const fileRef = useRef(null)
  const [uploading, setUploading] = useState(false)

  const fields = ['terms_url', 'privacy_url', 'copyright_text', 'seo_meta_title', 'seo_meta_description', 'seo_meta_keywords', 'footer_text']

  // Event handler to update the character count
  const handleFooterTextChange = (e) => {
    const text = e.target.value
    setFooterTextCount(text.length)
  }

  const handleSeoImageUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploading(true)

    try {
      const date = new Date()
        .toISOString()
        .replace(/[-:.T]/g, '')
        .slice(0, 14)
      const ext = file.name.split('.').pop()
      const newFileName = `${date}-seo-image.${ext}`

      const formData = new FormData()
      formData.append('file', file, newFileName)

      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/branding/upload`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      const rawUrl = res.data.url || res.data.fileUrl
      const finalUrl = rawUrl?.replace('https://i4i4.fra.idrivee2-52.com', 'https://d8y1.c2.e2-9.dev')

      // ✅ store URL in react-hook-form
      setValue('seo_image', finalUrl, {
        shouldDirty: true,
        shouldTouch: true,
        shouldValidate: true,
      })
    } catch (err) {
      Swal.fire('Error', 'SEO image upload failed', 'error')
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const handleClearSeoImage = () => {
    setValue('seo_image', '', {
      shouldDirty: true,
      shouldTouch: true,
      shouldValidate: true,
    })

    if (fileRef.current) {
      fileRef.current.value = ''
    }
  }

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row>
        {fields.map((field) => (
          <Col md={6} key={field} className="mb-3">
            <FormLabel>{field.replaceAll('_', ' ').replace(/\b\w/g, (l) => l.toUpperCase())}</FormLabel>
            <FormControl
              {...register(field)}
              isInvalid={!!errors[field]}
              // Add onChange and maxLength attributes for the footer_text field
              {...(field === 'footer_text' && {
                as: 'textarea', // Use a textarea for multi-line input
                rows: 3,
                onChange: handleFooterTextChange,
                maxLength: 500,
              })}
            />
            {/* Conditional rendering for the character counter and muted text */}
            {field === 'footer_text' && (
              <Form.Text className="text-muted d-flex justify-content-between">
                <div>500 characters max.</div>
                <div>{footerTextCount} / 500</div>
              </Form.Text>
            )}
          </Col>
        ))}
        {/* 🖼️ SEO Image */}
        <Col md={6} className="mb-3">
          <FormLabel>SEO Image</FormLabel>
          <input type="hidden" {...register('seo_image')} />

          <Card className="p-2 position-relative text-center">
            {watch('seo_image') && (
              <button
                type="button"
                onClick={handleClearSeoImage}
                title="Remove image"
                style={{
                  position: 'absolute',
                  top: '6px',
                  right: '6px',
                  width: '22px',
                  height: '22px',
                  borderRadius: '50%',
                  border: 'none',
                  background: 'rgba(0,0,0,0.6)',
                  color: '#fff',
                  fontSize: '14px',
                  lineHeight: '22px',
                  cursor: 'pointer',
                  zIndex: 2,
                  transition: 'all 0.2s ease',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.8)')}
                onMouseLeave={(e) => (e.currentTarget.style.background = 'rgba(0,0,0,0.6)')}>
                ×
              </button>
            )}

            {watch('seo_image') ? (
              <img
                src={watch('seo_image')}
                alt="SEO Image Preview"
                style={{
                  maxWidth: '100%',
                  maxHeight: '120px',
                  objectFit: 'contain',
                  marginBottom: '0.75rem',
                }}
              />
            ) : (
              <div
                style={{
                  height: '120px',
                  border: '1px dashed #ccc',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#999',
                  marginBottom: '0.75rem',
                }}>
                No SEO image
              </div>
            )}

            <input type="file" accept="image/*" hidden ref={fileRef} onChange={handleSeoImageUpload} />

            <Button size="sm" variant="outline-primary" onClick={() => fileRef.current?.click()} disabled={uploading}>
              {uploading ? 'Uploading...' : watch('seo_image') ? 'Replace Image' : 'Upload Image'}
            </Button>
          </Card>
        </Col>
      </Row>
      <div className="text-end mt-3">
        <Button className="btn bg-primary border border-primary px-3" type="submit">Save Legal & SEO</Button>
      </div>
    </Form>
  )
}

export default LegalSeoTab
