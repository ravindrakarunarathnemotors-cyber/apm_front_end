import dynamic from 'next/dynamic';
import Footer from '@/components/layout/Footer';
import FallbackLoading from '@/components/FallbackLoading';
import { Suspense } from 'react';
import AuthProtectionWrapper from '@/components/wrappers/AuthProtectionWrapper';
const TopNavigationBar = dynamic(() => import('@/components/layout/TopNavigationBar'));
const VerticalNavigationBar = dynamic(() => import('@/components/layout/VerticalNavigationBar'));

import InvoiceReminderBanner from "@/components/InvoiceReminderBanner";

const AdminLayout = ({
  children
}) => {
  return <AuthProtectionWrapper>


    <Suspense>
      <TopNavigationBar />
    </Suspense>


    <Suspense fallback={<FallbackLoading />}>
      <VerticalNavigationBar />
    </Suspense>

    <InvoiceReminderBanner />


    <div className="page-wrapper">
      <div className="page-content">
        <div className="container-xxl">
          <Suspense>{children}</Suspense>
        </div>
        <Footer />
      </div>
    </div>


  </AuthProtectionWrapper>;
};
export default AdminLayout;