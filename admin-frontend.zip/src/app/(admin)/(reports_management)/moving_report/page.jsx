'use client'

import React, { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Table, Button, Form, Row, Col, Pagination, Spinner } from 'react-bootstrap'
import Select from 'react-select'
import { useGetMovingReportMutation, useGetReportProductSearchQuery, useGetSystemGlobalSettingsQuery } from '@/store/features/apiSlice'

const INITIAL_FILTERS = {
  date_from: '',
  date_to: '',
}

const filterHeight = 36

const selectStyles = {
  control: (base) => ({ ...base, minHeight: filterHeight, height: filterHeight, fontSize: 12.5 }),
  valueContainer: (base) => ({ ...base, padding: '0 6px' }),
  indicatorsContainer: (base) => ({ ...base, height: filterHeight }),
  menu: (base) => ({ ...base, fontSize: 12.5 }),
}

const SORT_OPTIONS = [
  { value: 'fast_moving', label: 'Fast Moving' },
  { value: 'slow_moving', label: 'Slow Moving' },
  { value: 'amount_high', label: 'Amount (High → Low)' },
  { value: 'amount_low', label: 'Amount (Low → High)' },
]

//  Variant inline formatter
function formatVariantInline(item) {
  if (!item.variant_id) return ''

  const typeIsDefault = !item.variant_type || item.variant_type.toLowerCase() === 'default'

  if (typeIsDefault) return `(ID: ${item.variant_id})`

  return `(ID: ${item.variant_id} — ${item.variant_value || ''})`
}

// Qty formatter
const SHOW_MEASUREMENT = false

function formatQty(item) {
  const qty = Number(item.total_sold_qty ?? 0).toLocaleString()

  if (!SHOW_MEASUREMENT) return qty

  const meas = (item.measurement_value || '').trim()
  if (!meas || meas.toLowerCase() === 'pcs') return qty

  return `${qty} ${meas}`
}

function MovingReportPage() {
  const [filters, setFilters] = useState({ ...INITIAL_FILTERS })
  const [rows, setRows] = useState([])
  const [summary, setSummary] = useState({})
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [hasSearched, setHasSearched] = useState(false)
  const [totalItems, setTotalItems] = useState(0)

  const [productSearch, setProductSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [selectedSort, setSelectedSort] = useState(SORT_OPTIONS[0])
  const [dateFromType, setDateFromType] = useState('text')
  const [dateToType, setDateToType] = useState('text')

  const [getMovingReport, { isLoading }] = useGetMovingReportMutation()

  const { data: systemSettings } = useGetSystemGlobalSettingsQuery()
  const currency = systemSettings?.system_settings?.currency || 'LKR'

  const { data: productResults = [], isFetching: productSearching } = useGetReportProductSearchQuery(productSearch, {
    skip: !productSearch || productSearch.length < 2,
  })

  const getFilterSummary = () => {
    const parts = []

    if (filters?.date_from) {
      parts.push(`From: ${new Date(filters.date_from).toLocaleDateString()}`)
    }

    if (filters?.date_to) {
      parts.push(`To: ${new Date(filters.date_to).toLocaleDateString()}`)
    }

    if (selectedProduct?.label) {
      parts.push(`Product: ${selectedProduct.label}`)
    }

    if (selectedSort?.label) {
      parts.push(`Sort: ${selectedSort.label}`)
    } else {
      parts.push(`Sort: Fast Moving`)
    }

    return parts.join('  |  ')
  }

  const productOptions = useMemo(() => {
    const list = productResults?.products || productResults?.data?.products || productResults || []

    if (!Array.isArray(list)) return []

    const uniqueMap = new Map()

    list.forEach((p) => {
      if (!p?.product_id) return
      if (!uniqueMap.has(p.product_id)) {
        uniqueMap.set(p.product_id, {
          value: p.product_id,
          label: `${p.title} (ID: ${p.product_id})`,
        })
      }
    })

    return Array.from(uniqueMap.values())
  }, [productResults])

  const handleChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }))
    setHasSearched(false)
  }

  const handleReset = () => {
    setFilters({ ...INITIAL_FILTERS })
    setDateFromType('text')
    setDateToType('text')
    setProductSearch('')
    setSelectedProduct(null)
    setSelectedSort(SORT_OPTIONS[0])
    setHasSearched(false)
  }

  const hasFilters = filters.date_from || filters.date_to || selectedProduct || selectedSort

  const fetchData = async (page = 1) => {
    try {
      const res = await getMovingReport({
        date_from: filters.date_from || null,
        date_to: filters.date_to || null,
        product_id: selectedProduct?.value ?? null,
        sort_by: selectedSort?.value ?? 'fast_moving',
        page,
        limit: 25,
      }).unwrap()

      setRows(res.data || [])
      setSummary(res.summary || {})
      setTotalPages(res.summary?.total_pages || 1)
      setCurrentPage(page)
      setTotalItems(res.summary?.total_items || 0)
      setHasSearched(true)
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    const loadInitial = async () => {
      try {
        const res = await getMovingReport({
          sort_by: 'fast_moving',
          page: 1,
          limit: 25,
        }).unwrap()

        setRows(res.data || [])
        setSummary(res.summary || {})
        setTotalPages(res.summary?.total_pages || 1)
        setCurrentPage(1)
        setTotalItems(res.summary?.total_items || 0)
      } catch (err) {
        console.error(err)
      }
    }

    loadInitial()
  }, [])

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchData(page)
  }

  const getPaginationRange = () => {
    const maxVisible = 5
    let start = Math.max(currentPage - 2, 1)
    let end = Math.min(start + maxVisible - 1, totalPages)

    if (end - start < maxVisible - 1) start = Math.max(end - maxVisible + 1, 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handlePrint = () => {
    const content = document.getElementById('print-area')?.innerHTML
    const title = document.querySelector('.card-title')?.innerText || 'Report'

    const printContents = `
  <div style="text-align:center; margin-bottom:10px;">
    <h2>${title}</h2>
  </div>
  ${content}
`
    const win = window.open('', '', 'height=900,width=1200')

    win.document.write(`
    <html>
      <head>
        <title>Moving Report</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 10px 20px;
            color: #222;
          }

          .screen-only {
            display: none;
          }

          h2 {
            margin-bottom: 4px;
            font-size: 16px;
          }

          .filters {
            margin-bottom: 8px;
            font-size: 11px;
            color: #444;
          }

          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 6px;
          }

          th, td {
            border: 1px solid #ddd;
            padding: 5px 6px;
            font-size: 11px;
            line-height: 1.25;
          }

          th {
            background: #f4f4f4;
            text-align: left;
          }

          .text-end {
            text-align: right;
          }

          .text-success {
            color: #000;
            font-weight: bold;
          }

          .page-inline {
            width: 100%;
            text-align: right;
            margin-top: 4px;
            font-size: 11px;
            font-weight: 500;
          }

          .footer {
            position: fixed;
            bottom: 10px;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 11px;
            color: #777;
          }

          @media print {
            @page {
              margin: 12mm;
            }

            .screen-only {
              display: none !important;
            }

            .no-print {
              display: none !important;
            }

            body {
              counter-reset: page;
            }

            table {
              margin-bottom: 70px;
            }

            tbody tr {
              page-break-inside: avoid;
            }

            .footer .generated {
              display: none;
            }

            body:last-child .footer .generated {
              display: block;
            }
          }
        </style>
      </head>
      <body>
        ${printContents}
      </body>
    </html>
  `)

    win.document.close()
    win.print()
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light d-flex justify-content-between align-items-center">
            <CardTitle as="h4" className="mb-0">
              Moving Report
            </CardTitle>

            <Button
              variant="purple"
              size="md"
              onClick={handlePrint}
              style={{ backgroundColor: '#7c3aed', borderColor: '#7c3aed', color: '#fff', padding: '6px 18px', fontSize: 14 }}>
              🖨 Print
            </Button>
          </CardHeader>

          <CardBody>
            {/* FILTERS */}
            <Form autoComplete="off">
              <Row className="g-2 align-items-end mb-3">
                <Col md={4}>
                  <Form.Label className="fw-semibold" style={{ fontSize: 14 }}>
                    Product
                  </Form.Label>
                  <Select
                    styles={selectStyles}
                    value={selectedProduct}
                    onInputChange={setProductSearch}
                    onChange={(val) => {
                      setSelectedProduct(val)
                      setHasSearched(false)
                    }}
                    options={productOptions}
                    isLoading={productSearching}
                    placeholder="Search product…"
                    isClearable
                    filterOption={null}
                  />
                </Col>

                <Col md={2}>
                  <Form.Label style={{ fontSize: 14 }}>From</Form.Label>
                  <Form.Control
                    type={dateFromType}
                    placeholder="dd/mm/yy"
                    value={filters.date_from}
                    onFocus={() => setDateFromType('date')}
                    onChange={(e) => handleChange('date_from', e.target.value)}
                    style={{ height: filterHeight }}
                  />
                </Col>

                <Col md={2}>
                  <Form.Label style={{ fontSize: 14 }}>To</Form.Label>
                  <Form.Control
                    type={dateToType}
                    placeholder="dd/mm/yy"
                    value={filters.date_to}
                    onFocus={() => setDateToType('date')}
                    onChange={(e) => handleChange('date_to', e.target.value)}
                    style={{ height: filterHeight }}
                  />
                </Col>

                <Col md={2}>
                  <Form.Label style={{ fontSize: 14 }}>Sort By</Form.Label>
                  <Select
                    styles={selectStyles}
                    value={selectedSort}
                    onChange={(val) => {
                      setSelectedSort(val)
                      setHasSearched(false)
                    }}
                    options={SORT_OPTIONS}
                    isSearchable={false}
                    placeholder="Select Sort..."
                  />
                </Col>

                <Col md={2}>
                  <Button
                    className="w-100"
                    style={{ height: filterHeight }}
                    variant={hasSearched ? 'outline-secondary' : 'primary'}
                    disabled={!hasSearched && (!hasFilters || isLoading)}
                    onClick={() => {
                      if (hasSearched) {
                        handleReset()
                      } else {
                        fetchData(1)
                      }
                    }}>
                    {hasSearched ? 'Reset' : 'Search'}
                  </Button>
                </Col>
              </Row>
            </Form>

            {isLoading && (
              <div className="text-center py-4">
                <Spinner size="sm" /> Loading…
              </div>
            )}

            {!isLoading && (
              <div id="print-area">
                {/* filter summary — print only */}
                <div style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 12, color: '#555' }} className="screen-only">
                    {getFilterSummary()}
                  </div>
                  {totalItems > 0 && (
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#444' }}>
                      {totalItems.toLocaleString()} item{totalItems !== 1 ? 's' : ''}
                    </div>
                  )}
                </div>

                <Table striped bordered hover>
                  <thead className="table-light">
                    <tr>
                      <th>#</th>
                      <th>Product</th>
                      <th>Qty</th>
                      <th className="text-end">Amount ({currency})</th>
                    </tr>
                  </thead>

                  <tbody>
                    {rows.map((item, idx) => (
                      <tr key={idx}>
                        <td>{(currentPage - 1) * 25 + idx + 1}</td>

                        <td>
                          <div className="fw-semibold">
                            #{item.product_id} — {item.title} <span className="text-muted small">{formatVariantInline(item)}</span>
                          </div>
                        </td>

                        <td>{formatQty(item)}</td>

                        <td className="text-end text-success fw-semibold">
                          {Number(item.total_sales_amount ?? 0).toLocaleString(undefined, {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>

                {/*  footer + page — rendered into print window HTML, hidden on screen via print window CSS */}
                <div className="footer d-none">
                  <div className="generated">Generated on: {new Date().toLocaleString()}</div>
                </div>

                <div className="page-inline d-none">
                  Page {summary?.current_page || currentPage} of {summary?.total_pages || totalPages}
                </div>
                <div className="no-print">
                  {/* ================= PAGINATION ================= */}
                  {totalPages > 1 && (
                    <div className="d-flex justify-content-end mt-3">
                      <Pagination>
                        <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                          First
                        </Pagination.Item>
                        <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)}>
                          {'<'}
                        </Pagination.Item>
                        {getPaginationRange().map((p) => (
                          <Pagination.Item key={p} active={p === currentPage} onClick={() => handlePageChange(p)}>
                            {p}
                          </Pagination.Item>
                        ))}
                        <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)}>
                          {'>'}
                        </Pagination.Item>
                        <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                          Last
                        </Pagination.Item>
                      </Pagination>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default MovingReportPage
