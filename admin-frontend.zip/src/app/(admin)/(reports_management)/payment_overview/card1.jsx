'use client'
import { useEffect, useMemo, useState } from 'react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useSalesSummaryCard1Mutation } from '@/store/features/apiSlice'

export default function Card1({ filters, onValuesChange }) {
  const [fetchCard, { data, isLoading }] = useSalesSummaryCard1Mutation()
  const [values, setValues] = useState([])

  const body = useMemo(
    () => ({
      ...(filters.fromDate ? { date_from: filters.fromDate } : {}),
      ...(filters.toDate ? { date_to: filters.toDate } : {}),
    }),
    [filters],
  )

  useEffect(() => {
    fetchCard(body)
  }, [fetchCard, body])

  const nf = (n) => {
    const num = Number(n ?? 0)
    try {
      return new Intl.NumberFormat('en-LK', { maximumFractionDigits: 2 }).format(num)
    } catch {
      return String(num)
    }
  }

  useEffect(() => {
    // Support both shapes: {currency, data:{...}} or already flattened
    const payload = data?.data ?? data
    const c = data?.currency || 'LKR'

    const v = [
      `Total Orders (Qty): ${Number(payload?.total_orders_qty ?? 0)}`,
      `Total Order Value: ${c} ${nf(payload?.total_order_value)}`,
      `Paid Orders (Qty): ${Number(payload?.paid_orders_qty ?? 0)}`,
      `Paid Order Value: ${c} ${nf(payload?.paid_order_value)}`,
      `Unpaid Orders (Qty): ${Number(payload?.unpaid_orders_qty ?? 0)}`,
      `Unpaid Order Value: ${c} ${nf(payload?.unpaid_order_value)}`,
    ]

    setValues(v)
    onValuesChange?.(v)
  }, [data, onValuesChange])

  const skeleton = [
    'Total Orders (Qty): …',
    'Total Order Value: …',
    'Paid Orders (Qty): …',
    'Paid Order Value: …',
    'Unpaid Orders (Qty): …',
    'Unpaid Order Value: …',
  ]

  // Show skeleton while loading OR before first values are ready
  const isPending = isLoading || values.length === 0
  const rows = isPending ? skeleton : values

  return (
    <div className="mini-stat">
      <div className="mini-stat-inner">
        <div className="d-flex justify-content-between align-items-center mb-1">
          <span className="mini-title">Orders Overview</span>
          <span className="mini-icon-wrap">
            <IconifyIcon icon="mdi:cart-outline" className="mini-icon" />
          </span>
        </div>
        <div className="mini-sub">Overview of all payment methods and order statuses</div>
        <hr className="mini-divider" />
        <ul className="kv-list">
          {rows.map((rowText, i) => {
            const [label, ...rest] = String(rowText).split(':')
            const value = rest.join(':').trim()
            return (
              <li key={i} className="kv-row">
                <span className="kv-label">{label}</span>
                <span className="kv-value">{value}</span>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  )
}
