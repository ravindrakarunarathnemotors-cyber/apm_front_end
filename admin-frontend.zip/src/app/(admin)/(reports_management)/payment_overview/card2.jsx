'use client'
import { useEffect, useMemo, useState } from 'react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useSalesSummaryCard2Mutation } from '@/store/features/apiSlice'

export default function Card2({ filters, onValuesChange }) {
  const [fetchCard, { data, isLoading }] = useSalesSummaryCard2Mutation()
  const [values, setValues] = useState([])

  const body = useMemo(() => ({
    ...(filters.fromDate ? { date_from: filters.fromDate } : {}),
    ...(filters.toDate ? { date_to: filters.toDate } : {}),
  }), [filters])

  useEffect(() => {
    fetchCard(body)
  }, [fetchCard, body])

  const nf = (n) => {
    const num = Number(n ?? 0)
    try { return new Intl.NumberFormat('en-LK', { maximumFractionDigits: 2 }).format(num) } catch { return String(num) }
  }

  useEffect(() => {
    // API shape: { currency, data: { ...metrics } }
    const payload = data?.data ?? data
    const c = data?.currency || 'LKR'
    const v = [
      `Total COD Orders (Qty): ${Number(payload?.total_orders_qty ?? 0)}`,
      `Total COD Order Value: ${c} ${nf(payload?.total_order_value)}`,
      `Paid COD Orders (Qty): ${Number(payload?.paid_orders_qty ?? 0)}`,
      `Paid COD Order Value: ${c} ${nf(payload?.paid_order_value)}`,
      `Unpaid COD Orders (Qty): ${Number(payload?.unpaid_orders_qty ?? 0)}`,
      `Unpaid COD Order Value: ${c} ${nf(payload?.unpaid_order_value)}`,
    ]
    setValues(v)
    onValuesChange?.(v)
  }, [data, onValuesChange])

  const skeleton = [
    'Total COD Orders (Qty): …',
    'Total COD Order Value: …',
    'Paid COD Orders (Qty): …',
    'Paid COD Order Value: …',
    'Unpaid COD Orders (Qty): …',
    'Unpaid COD Order Value: …',
  ]

  const rows = (isLoading || values.length === 0) ? skeleton : values

  return (
    <div className="mini-stat">
      <div className="mini-stat-inner">
        <div className="d-flex justify-content-between align-items-center mb-1">
          <span className="mini-title">COD (Cash on Delivery) Overview</span>
          <span className="mini-icon-wrap">
            <IconifyIcon icon="mdi:cash-multiple" className="mini-icon" />
          </span>
        </div>
        <div className="mini-sub">Cash on Delivery performance</div>
        <hr className="mini-divider" />
        <ul className="kv-list">
          {rows.map((rowText, i) => {
            const [label, ...rest] = String(rowText).split(':')
            const value = rest.join(':').trim()
            return (
              <li key={i} className="kv-row">
                <span className="kv-label">{label}</span>
                <span className="kv-value">{value}</span>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  )
}
