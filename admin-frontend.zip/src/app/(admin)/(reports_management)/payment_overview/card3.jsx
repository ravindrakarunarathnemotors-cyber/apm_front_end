'use client'
import { useEffect, useMemo, useState } from 'react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useSalesSummaryCard3Mutation } from '@/store/features/apiSlice'

export default function Card3({ filters, onValuesChange }) {
  const [fetchCard, { data, isLoading }] = useSalesSummaryCard3Mutation()
  const [values, setValues] = useState([])

  const body = useMemo(() => ({
    ...(filters.fromDate ? { date_from: filters.fromDate } : {}),
    ...(filters.toDate ? { date_to: filters.toDate } : {}),
  }), [filters])

  useEffect(() => {
    fetchCard(body)
  }, [fetchCard, body])

  const nf = (n) => {
    const num = Number(n ?? 0)
    try { return new Intl.NumberFormat('en-LK', { maximumFractionDigits: 2 }).format(num) } catch { return String(num) }
  }

  useEffect(() => {
    // API shape: { currency, data: { ...metrics } }
    const payload = data?.data ?? data
    const c = data?.currency || 'LKR'

    const v = [
      `Total Store Pickup Orders (Qty): ${Number(payload?.total_orders_qty ?? 0)}`,
      `Total Store Pickup Order Value: ${c} ${nf(payload?.total_order_value)}`,
      `Paid Store Pickup Orders (Qty): ${Number(payload?.paid_orders_qty ?? 0)}`,
      `Paid Store Pickup Order Value: ${c} ${nf(payload?.paid_order_value)}`,
      `Unpaid Store Pickup Orders (Qty): ${Number(payload?.unpaid_orders_qty ?? 0)}`,
      `Unpaid Store Pickup Order Value: ${c} ${nf(payload?.unpaid_order_value)}`,
    ]

    setValues(v)
    onValuesChange?.(v)
  }, [data, onValuesChange])

  const skeleton = [
    'Total Store Pickup Orders (Qty): …',
    'Total Store Pickup Order Value: …',
    'Paid Store Pickup Orders (Qty): …',
    'Paid Store Pickup Order Value: …',
    'Unpaid Store Pickup Orders (Qty): …',
    'Unpaid Store Pickup Order Value: …',
  ]

  const rows = (isLoading || values.length === 0) ? skeleton : values

  return (
    <div className="mini-stat">
      <div className="mini-stat-inner">
        <div className="d-flex justify-content-between align-items-center mb-1">
          <span className="mini-title">Store Pickup Overview</span>
          <span className="mini-icon-wrap"><IconifyIcon icon="mdi:store-outline" className="mini-icon" /></span>
        </div>
        <div className="mini-sub">Orders picked up at store</div>
        <hr className="mini-divider" />
        <ul className="kv-list">
          {rows.map((rowText, i) => {
            const [label, ...rest] = String(rowText).split(':')
            const value = rest.join(':').trim()
            return (
              <li key={i} className="kv-row">
                <span className="kv-label">{label}</span>
                <span className="kv-value">{value}</span>
              </li>
            )
          })}
        </ul>
      </div>
    </div>
  )
}
