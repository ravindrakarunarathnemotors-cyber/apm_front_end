'use client'

import React, { useEffect, useState, useRef } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Button, Form } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'

import Card1 from './card1'
import Card2 from './card2'
import Card3 from './card3'
import Card4 from './card4'
import Card5 from './card5'
import Card6 from './card6'

export default function SalesSummaryReport() {
  const [filters, setFilters] = useState({ fromDate: '', toDate: '' })
  const handleFilterChange = (e) => setFilters({ ...filters, [e.target.name]: e.target.value })

  const [appliedFilters, setAppliedFilters] = useState({ fromDate: '', toDate: '' })
  const [isSearching, setIsSearching] = useState(false)

  const [card1Values, setCard1Values] = useState([])
  const [card2Values, setCard2Values] = useState([])
  const [card3Values, setCard3Values] = useState([])
  const [card4Values, setCard4Values] = useState([])
  const [card5Values, setCard5Values] = useState([])
  const [card6Values, setCard6Values] = useState([])

  const onSearch = () => {
    setIsSearching(true)
    setAppliedFilters({ fromDate: filters.fromDate || '', toDate: filters.toDate || '' })
    setTimeout(() => setIsSearching(false), 600)
  }

  const styleInjected = useRef(false)
  useEffect(() => {
    if (styleInjected.current) return
    const style = document.createElement('style')
    style.innerHTML = `
      .mini-grid { display: flex; flex-wrap: wrap; gap: 16px; }
      .mini-stat { flex: 0 0 calc(50% - 16px); max-width: calc(50% - 16px); display: flex; }
      .mini-stat-inner {
        border: 1px solid var(--bs-border-color, #dee2e6);
        background: #fff; border-radius: 12px; padding: 14px 16px;
        display: flex; flex-direction: column; flex: 1;
        transition: box-shadow 0.2s ease, transform 0.2s ease;
      }
      .mini-stat-inner:hover { box-shadow: 0 4px 14px rgba(0,0,0,.08); transform: translateY(-2px); }
      .mini-title { font-weight: 600; font-size: 1rem; margin: 0; }
      .mini-sub { font-size: 0.8rem; color: #6c757d; margin: 2px 0 6px; }
      .mini-divider { border: none; border-top: 1px solid rgba(0,0,0,0.12); margin: 6px 0 10px; }
      .kv-row { display: flex; justify-content: space-between; padding: 6px 8px; font-size: 0.85rem; border-bottom: 1px solid rgba(0,0,0,0.06); border-radius: 8px; transition: background 0.15s ease; }
      .kv-row:last-child { border-bottom: none; }
      .kv-row:hover { background: rgba(124, 58, 237, 0.06); }

      @media print {
        @page { margin: 7mm; size: A4 portrait; }
        html, body { height: auto !important; overflow: visible !important; }
        body { margin: 0 !important; font-size: 12px; background: #fff !important; -webkit-print-color-adjust: exact; }
        .btn, form, .card-header, .mini-grid, h5 { display: none !important; }
        .card, .card-body { border: none !important; padding: 0 !important; box-shadow: none !important; }
        .print-report {
          display: flex !important;
          flex-direction: column;
          height: 100%;
          justify-content: space-between;
          padding: 0;
        }
        .print-main-title { text-align: center; font-size: 13px; font-weight: bold; margin: 0 0 6px; padding-bottom: 2px; border-bottom: 1px solid #000; }
        .print-dates { text-align: center; margin: 0 0 6px; font-size: 11px; font-style: italic; }
        .print-content { flex: 1; overflow: hidden; }
        .print-section { margin: 10px 0; page-break-inside: avoid; break-inside: avoid; }
        .print-section h3 { position: relative; font-size: 12px; margin: 0 0 4px; font-weight: 700; padding-left: 12px; }
        .print-section h3::before { content: "•"; position: absolute; left: 0; top: 0; line-height: 1; }
        .print-section ul { list-style: none; padding-left: 14px; margin: 0; }
        .print-section li { display: flex; justify-content: space-between; border-bottom: 1px dotted #ccc; padding: 2px 0; font-size: 11px; }
        .print-section li span:first-child { font-weight: 600; }
        .print-issued { text-align: right; font-size: 10px; font-style: italic; margin-top: 24px; }
      }
    `
    document.head.appendChild(style)
    styleInjected.current = true
  }, [])

  const splitRow = (text) => {
    const [label, ...rest] = String(text).split(':')
    return { label: label?.trim() ?? '', value: rest.join(':').trim() }
  }

  const currentDate = new Date().toLocaleDateString()

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          {/* <CardHeader className="py-2 d-flex justify-content-between align-items-center" style={{ background: '#e5e8ed' }}>
            <CardTitle as="h4" className="mb-0">
              Sales Summary Report
            </CardTitle>
          </CardHeader> */}
          <CardHeader className="py-2" style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
            <div className="d-flex justify-content-between align-items-center">
              <CardTitle as="h4" className="mb-0">
                Sales Summary Report
              </CardTitle>
            </div>
          </CardHeader>

          <CardBody>
            {/* Filters */}
            <Form className="mb-3">
              <Row className="g-3 align-items-end">
                <Col md={3}>
                  <Form.Group controlId="fromDate">
                    <Form.Label>From Date</Form.Label>
                    <Form.Control type="date" name="fromDate" value={filters.fromDate} onChange={handleFilterChange} />
                  </Form.Group>
                </Col>
                <Col md={3}>
                  <Form.Group controlId="toDate">
                    <Form.Label>To Date</Form.Label>
                    <Form.Control type="date" name="toDate" value={filters.toDate} onChange={handleFilterChange} />
                  </Form.Group>
                </Col>
                <Col md="auto">
                  <Button
                    type="button"
                    onClick={onSearch}
                    disabled={isSearching}
                    style={{ background: '#16a34a', borderColor: '#16a34a', minWidth: 140 }}
                    className="d-flex align-items-center gap-1">
                    <IconifyIcon icon={isSearching ? 'mdi:magnify-scan' : 'mdi:magnify'} width={18} height={18} />
                    {isSearching ? 'Searching…' : 'Search'}
                  </Button>
                </Col>
              </Row>
            </Form>

            <h5 className="fw-bold mb-3">Sales Overview</h5>

            {/* Cards for screen */}
            <div className="mini-grid">
              <Card1 filters={appliedFilters} onValuesChange={setCard1Values} />
              <Card2 filters={appliedFilters} onValuesChange={setCard2Values} />
              <Card3 filters={appliedFilters} onValuesChange={setCard3Values} />
              <Card4 filters={appliedFilters} onValuesChange={setCard4Values} />
              <Card5 filters={appliedFilters} onValuesChange={setCard5Values} />
              <Card6 filters={appliedFilters} onValuesChange={setCard6Values} />
            </div>

            {/* Print-only */}
            <div className="print-report" style={{ display: 'none' }}>
              <div>
                <div className="print-main-title">Sales Overview</div>
                <div className="print-dates">
                  {appliedFilters?.fromDate || appliedFilters?.toDate ? (
                    <>
                      {appliedFilters?.fromDate && <>From: {appliedFilters.fromDate}&nbsp;&nbsp;</>}
                      {appliedFilters?.toDate && <>To: {appliedFilters.toDate}</>}
                    </>
                  ) : (
                    <>All Data</>
                  )}
                </div>
              </div>

              <div className="print-content">
                {[
                  { title: 'Orders Overview', values: card1Values },
                  { title: 'COD (Cash on Delivery) Overview', values: card2Values },
                  { title: 'Store Pickup Overview', values: card3Values },
                  { title: 'Stripe Payment Overview', values: card4Values },
                  { title: 'PayHere Payment Overview', values: card5Values },
                  { title: 'Bank Transfer Payment Summary', values: card6Values },
                ].map((card, idx) => (
                  <div key={idx} className="print-section">
                    <h3>{card.title}</h3>
                    <ul>
                      {card.values.map((rowText, i) => {
                        const { label, value } = splitRow(rowText)
                        return (
                          <li key={i}>
                            <span>{label}</span>
                            <span>{value}</span>
                          </li>
                        )
                      })}
                    </ul>
                  </div>
                ))}
              </div>

              <div className="print-issued">Issued on: {currentDate}</div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '2rem', marginRight: '1rem' }}>
              <Button onClick={() => window.print()} style={{ background: '#7c3aed', borderColor: '#7c3aed' }}>
                <IconifyIcon icon="mdi:printer" width={18} height={18} /> Print
              </Button>
            </div>
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}
