'use client'

import React, { useEffect, useMemo, useState, useRef, memo } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Table, Form, FormGroup, FormLabel, Button, Collapse } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  useGetCategoriesQuery,
  useGetReportsBrandsQuery,
  useGetReportsCollectionsQuery,
  useGetFilteredSalesReportMutation,
  useGetDiscountCurrencyQuery,
  useGetReportProductSearchQuery,
} from '@/store/features/apiSlice'

function formatCurrencyLKR(n) {
  const num = Number(n ?? 0)
  try {
    const out = new Intl.NumberFormat('en-LK', { style: 'currency', maximumFractionDigits: 2 }).format(num)
    return out.replace(/\s/g, '\u00A0') // keep symbol + value together when printing
  } catch {
    return `\u00A0${num.toFixed(2)}`
  }
}

const indexCategoriesById = (list = []) => {
  const map = new Map()
  list.forEach((c) => map.set(c.category_id, c))
  return map
}

const makeLineageLabel = (cat, idxMap) => {
  const parts = []
  let cur = cat
  while (cur) {
    parts.push(cur.name)
    cur = cur.category_under ? idxMap.get(cur.category_under) : null
  }
  return parts.reverse().join(' > ')
}

/** Single product row (memoized) — local expand state to avoid page-wide re-render */
const ProductRow = memo(function ProductRow({ p, currencyLabel }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      {/* Product row */}
      <tr className="product-row">
        <td>
          {/* product id */}
          {p.id}
        </td>
        <td>
          {p.variants?.length > 0 && (
            <button
              onClick={() => setOpen((v) => !v)}
              className="expander-btn no-print"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 28,
                height: 28,
                borderRadius: 999,
                border: '1px solid #cfcfcf',
                background: '#f7f7f7',
                color: '#222',
                transition: 'transform .12s ease, background .12s ease, box-shadow .12s ease',
                marginRight: 8,
              }}
              title={open ? 'Collapse' : 'Expand'}>
              <IconifyIcon icon={open ? 'mdi:chevron-down' : 'mdi:chevron-right'} width={18} height={18} />
            </button>
          )}
          {/* product bullet (UI & print) */}
          <span className="product-bullet" aria-hidden>
            ▪
          </span>
          {p.name}
        </td>
        <td>{p.ordered_qty}</td>
        <td>{p.sales_qty}</td>
        <td>{p.returned_qty}</td>
        <td className="text-currency">{formatCurrencyLKR(p.sales_amount)}</td>
      </tr>

      {/* Variants (expanded; print forces open via CSS) */}
      {p.variants?.length > 0 && (
        <tr>
          <td colSpan={6} style={{ padding: 0, borderTop: 0 }}>
            <Collapse in={open}>
              <div>
                <Table size="sm" className="mb-2" style={{ margin: 0, width: '100%' }}>
                  <thead>
                    <tr className="table-secondary">
                      {/* blank spacer col to align under Product ID, width matches main table first col */}
                      <th style={{ width: 90 }} className="th-left"></th>
                      {/* Variant column with indent */}
                      <th className="th-left" style={{ paddingLeft: 56 }}>
                        Variant
                      </th>
                      <th className="text-center">Ordered</th>
                      <th className="text-center">Invoice</th>
                      <th className="text-center">Returned</th>
                      <th className="text-end">Invoice Amount {currencyLabel}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {p.variants.map((v) => (
                      <tr key={v.variant_id}>
                        <td className="th-left"></td>
                        <td className="th-left" style={{ paddingLeft: 56 }}>
                          <span className="variant-icon d-inline-flex align-items-center gap-1">
                            <IconifyIcon icon="mdi:package-variant-closed" width={16} height={16} />
                          </span>
                          <span className="variant-bullet" aria-hidden>
                            •
                          </span>
                          <span>
                            {v.variant_id} — {v.variant_label}
                          </span>
                        </td>
                        <td className="text-center">{v.ordered_qty}</td>
                        <td className="text-center">{v.sales_qty}</td>
                        <td className="text-center">{v.returned_qty}</td>
                        <td className="text-end">{formatCurrencyLKR(v.sales_amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
            </Collapse>
          </td>
        </tr>
      )}
    </>
  )
})

export default function SalesReport() {
  // filters
  const [categoryOpt, setCategoryOpt] = useState(null)
  const [brandOpt, setBrandOpt] = useState(null)
  const [collectionOpt, setCollectionOpt] = useState(null)
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  // table / ui state
  const [rows, setRows] = useState([]) // normalized product rows for UI
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [summary, setSummary] = useState({
    total_ordered_qty: 0,
    total_sales_qty: 0,
    total_returned_qty: 0,
    total_sales_amount: 0,
  })

  // Product search filter
  const [productSearch, setProductSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  // options
  const [brandOptions, setBrandOptions] = useState([{ value: 'all', label: 'All Brands' }])
  const [collectionOptions, setCollectionOptions] = useState([{ value: 'all', label: 'All Collections' }])

  const { data: currency = '', isLoading: currencyLoading } = useGetDiscountCurrencyQuery()
  // react-select sizing
  const filterHeight = 36
  const selectStyles = {
    control: (base) => ({ ...base, minHeight: filterHeight, height: filterHeight, fontSize: 12.5 }),
    valueContainer: (base) => ({ ...base, padding: '0 6px' }),
    indicatorsContainer: (base) => ({ ...base, height: filterHeight }),
    menu: (base) => ({ ...base, fontSize: 12.5 }),
    clearIndicator: (base) => ({ ...base, padding: 4, cursor: 'pointer' }),
    dropdownIndicator: (base) => ({ ...base, padding: 4 }),
  }

  // data hooks
  const { data: categoriesData = [], isLoading: catsLoading } = useGetCategoriesQuery()
  const { data: brandsData = [] } = useGetReportsBrandsQuery()
  const { data: collectionsData = [] } = useGetReportsCollectionsQuery()
  const [getFilteredSalesReport] = useGetFilteredSalesReportMutation()
  const { data: productResults = [], isFetching: productSearching } = useGetReportProductSearchQuery(productSearch, {
    skip: !productSearch || productSearch.length < 2,
  })

  const productOptions = useMemo(() => {
    const list = productResults?.products || productResults?.data?.products || productResults || []

    if (!Array.isArray(list)) return []

    const uniqueMap = new Map()

    list.forEach((p) => {
      if (!p?.product_id) return

      if (!uniqueMap.has(p.product_id)) {
        uniqueMap.set(p.product_id, {
          value: p.product_id,
          label: `${p.title} (ID: ${p.product_id})`,
        })
      }
    })

    return Array.from(uniqueMap.values())
  }, [productResults])
  // map selects
  useEffect(() => {
    if (Array.isArray(brandsData) && brandsData.length > 0) {
      const opts = brandsData.map((b) => ({ value: b.brand_id, label: b.name })).sort((a, b) => a.label.localeCompare(b.label))
      setBrandOptions([{ value: 'all', label: 'All Brands' }, ...opts])
    } else {
      setBrandOptions([{ value: 'all', label: 'All Brands' }])
    }
  }, [brandsData])

  useEffect(() => {
    if (Array.isArray(collectionsData) && collectionsData.length > 0) {
      const opts = collectionsData.map((c) => ({ value: c.collection_id, label: c.name })).sort((a, b) => a.label.localeCompare(b.label))
      setCollectionOptions([{ value: 'all', label: 'All Collections' }, ...opts])
    } else {
      setCollectionOptions([{ value: 'all', label: 'All Collections' }])
    }
  }, [collectionsData])

  const categoryOptions = useMemo(() => {
    if (!Array.isArray(categoriesData) || categoriesData.length === 0) return [{ value: 'all', label: 'All Categories' }]
    const idx = indexCategoriesById(categoriesData)
    const opts = categoriesData.map((c) => ({ value: c.category_id, label: makeLineageLabel(c, idx) }))
    opts.sort((a, b) => a.label.localeCompare(b.label))
    return [{ value: 'all', label: 'All Categories' }, ...opts]
  }, [categoriesData])

  // normalize API -> UI rows
  const normalizeProducts = (products = []) =>
    products.map((p) => ({
      id: p.product_id,
      name: p.title,
      ordered_qty: Number(p.product_total_order_quantity ?? 0),
      sales_qty: Number(p.product_total_sales_quantity ?? 0),
      returned_qty: Number(p.product_returned_items_quantity ?? 0),
      returned_order_qty: Number(p.product_returned_orders_count ?? 0),
      sales_amount: Number(p.product_total_sales_amount ?? 0),
      variants: (p.variants || []).map((v) => ({
        variant_id: v.variant_id,
        variant_label: v.variant_value,
        ordered_qty: Number(v.order_quantity ?? 0),
        sales_qty: Number(v.sales_quantity ?? 0),
        returned_qty: Number(v.returned_items_quantity ?? 0),
        returned_order_qty: Number(v.returned_orders_count ?? 0),
        sales_amount: Number(v.total_sales_amount ?? 0),
      })),
    }))

  // fetch
  const fetchReport = async () => {
    setLoading(true)
    setErrorMsg('')
    try {
      const payload = {
        date_from: dateFrom || null,
        date_to: dateTo || null,
        category_ids: categoryOpt?.value && categoryOpt.value !== 'all' ? [categoryOpt.value] : [],
        collection_ids: collectionOpt?.value && collectionOpt.value !== 'all' ? [collectionOpt.value] : [],
        product_id: selectedProduct?.value ?? null,
        page: 1,
        page_size: 25,
      }

      const res = await getFilteredSalesReport(payload).unwrap()
      const body = res?.products ? res : res?.data?.products ? res.data : res

      const products = normalizeProducts(body?.products ?? [])
      setRows(products)

      const rawSummary = body?.sales_report_summary ?? body?.data?.sales_report_summary ?? body?.summary ?? null

      const computeSummaryFromProducts = (list = []) => {
        let total_ordered_qty = 0
        let total_sales_qty = 0
        let total_returned_qty = 0
        let total_sales_amount = 0
        for (const p of list) {
          total_ordered_qty += Number(p?.ordered_qty ?? 0)
          total_sales_qty += Number(p?.sales_qty ?? 0)
          total_returned_qty += Number(p?.returned_qty ?? 0)
          total_sales_amount += Number(p?.sales_amount ?? 0)
        }
        return { total_ordered_qty, total_sales_qty, total_returned_qty, total_sales_amount }
      }

      const s = rawSummary
        ? {
            total_ordered_qty: Number(rawSummary?.total_ordered_qty ?? 0),
            total_sales_qty: Number(rawSummary?.total_sales_qty ?? 0),
            total_returned_qty: Number(rawSummary?.total_returned_qty ?? 0),
            total_sales_amount: Number(rawSummary?.total_sales_amount ?? 0),
          }
        : computeSummaryFromProducts(products)

      setSummary(s)
    } catch (err) {
      console.error('Report fetch error:', err)
      setErrorMsg('Failed to fetch report')
      setRows([])
      setSummary({
        total_ordered_qty: 0,
        total_sales_qty: 0,
        total_returned_qty: 0,
        total_sales_amount: 0,
      })
    } finally {
      setLoading(false)
    }
  }

  // initial load
  useEffect(() => {
    fetchReport()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const handleSearch = () => fetchReport()
  const handlePrint = () => window.print()

  // global styles once
  const spinAdded = useRef(false)
  useEffect(() => {
    if (spinAdded.current) return
    const style = document.createElement('style')
    style.innerHTML = `
      @keyframes spin { to { transform: rotate(360deg); } }

      /* Base table alignment */
      table.report-table tbody td { vertical-align: middle; text-align: center; }
      table.report-table thead th { text-align: center; vertical-align: middle; }
      table.report-table thead th.th-left,
      table.report-table tbody td:nth-child(1),
      table.report-table tbody td:nth-child(2) { text-align: left; }
      .text-currency { text-align: right !important; white-space: nowrap; }
      .expander-btn:hover { transform: translateY(-1px); background: #efefef; box-shadow: 0 2px 8px rgba(0,0,0,.08); }

      /* Bullet styling visible on screen */
      .product-bullet { display: inline-block; margin: 0 6px 0 2px; font-size: 14px; color: #9ca3af; }
      .variant-bullet { display: inline-block; margin: 0 6px; font-size: 12px; color: #c0c4cc; }

      /* Mini stats (web) — keep dark hover on web only */
      .mini-grid { width: 100%; display: flex; gap: 12px; flex-wrap: nowrap; }
      .mini-stat { flex: 0 0 calc((100% - (12px * 3)) / 4); max-width: calc((100% - (12px * 3)) / 4); }
      .mini-stat-inner { border: 1px solid var(--bs-border-color, #dee2e6); background: #fff; border-radius: 10px; padding: 10px 12px; min-height: 110px; display: flex; flex-direction: column; justify-content: space-between; transition: background-color 0.18s ease, transform 0.18s ease, color 0.18s ease, border-color 0.18s ease; }
      .mini-stat-inner:hover { background-color: #343a40; color: #fff; transform: translateY(-1px); border-color: #343a40; }
      .mini-icon-wrap { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #f3f4f6; }
      .mini-icon { font-size: 16px; color: #6c757d; }
      .mini-stat-inner:hover .mini-icon { color: #05a000ff; }
      .mini-title { font-weight: 600; font-size: 0.85rem; margin-bottom: 2px; }
      .mini-value { font-weight: 700; font-size: 1rem; margin: 0 0 2px; color: #28a745; }
      .mini-divider { border: none; border-top: 1px solid rgba(0,0,0,0.1); margin: 2px 0 4px; width: 100%; }
      .mini-sub { font-size: 0.7rem; color: #6c757d; }

      .chip { display: inline-flex; align-items: center; gap: 6px; font-size: .75rem; border: 1px solid var(--bs-border-color, #dee2e6); border-radius: 999px; padding: 2px 8px; background: #f8f9fa; color: #343a40; margin-left: 6px; }

      /* Print-only helpers (hidden for screen by default) */
      .print-only { display: none !important; }

      /* --- PRINT RULES --- */
      @page {
        size: auto;
        margin: 7mm; /* EXACT 7mm margins on EVERY page */
      }

      @media print {
        html, body {
          font-size: 10px;
          line-height: 1.25;
          background: #fff !important;
          color: #111;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }

        body { margin: 0 !important; padding: 0 0 22mm 0 !important; }

        /* Re-enable print-only elements */
        .print-only { display: initial !important; }

        /* Print title (first page) */
        .print-title {
          text-align: center;
          margin: 0;
          font-weight: 800;
          font-size: 14px;
          letter-spacing: .2px;
        }
        .print-title-hr {
          border: 0;
          border-top: 1.5px solid #000;
          margin: 6px 0 8px 0;
        }

        /* Header */
        .report-header { background: #eceff3 !important; padding: 4px 0 !important; border: none !important; box-shadow: none !important; }
        .report-title { text-align: center !important; width: 100%; display: block; margin: 2mm 0 4mm !important; }

        /* Avoid extra pages and keep proper page flow */
        .card, .card-body, .card-header { border: none !important; box-shadow: none !important; margin: 0 !important; }
        .container, .container-fluid, .row, .col, .report-table { break-inside: auto; }
        .report-table { width: 100% !important; border-collapse: collapse !important; }
        .report-table thead { display: table-header-group; }
        .report-table tfoot { display: table-footer-group; }
        .report-table tr { break-inside: avoid; break-after: auto; }

        /* Hide interactive UI in print */
        .no-print, .no-print * { display: none !important; }
        .mini-grid, .chip { display: none !important; }

        /* Print filters block */
        .print-filters { margin: 3mm 0 8px !important; }
        .print-filters ul { margin: 2px 0 0 16px; padding: 0; }
        .print-filters li { margin: 1px 0; }

        /* === MAIN TABLE HEADER STYLE (keep colored like summary head) === */
        table.report-table thead th,
        table.report-table thead tr {
          background: #444 !important;
          color: #fff !important;
        }
        table.report-table thead th {
          font-weight: 700 !important;
          text-transform: uppercase !important;
          letter-spacing: 0.3px !important;
          border-bottom: 1px solid #333 !important;
          font-size: 10.5px !important;
          padding: 6px 7px !important;
        }

        /* Body cells & borders */
        table.report-table tbody td { border-top: 1px solid #e5e7eb !important; font-size: 10px; padding: 5px 7px !important; }
        .text-currency { text-align: right !important; white-space: nowrap !important; }

        /* === Color ONLY the main product rows (those with Product ID) === */
        /* No rounded corners; just a soft fill */
        table.report-table tbody > tr.product-row > td {
          background: #f1f5f9 !important; /* subtle light fill */
        }

        /* Force variant sections open in print */
        .collapse { display: block !important; height: auto !important; visibility: visible !important; }

        /* Hide expand buttons and variant icons on paper (keep bullets) */
        .expander-btn, .variant-icon { display: none !important; }

        /* Show bullets in print too */
        .variant-bullet, .product-bullet { display: inline-block !important; margin-right: 6px; }

        /* Separator before totals */
        .print-hr { border: 0; border-top: 1.5px solid #000; margin: 4px 0; }

        /* Ensure print-only table rows render correctly */
        tr.print-only { display: table-row !important; }

        /* Do NOT color the variant header in print (neutralize Bootstrap .table-secondary) */
        .collapse thead th,
        .collapse thead tr {
          background: transparent !important;
          color: inherit !important;
        }
        .collapse thead th {
          border-bottom: 1px solid #c9ccd1 !important;
        }

        /* === 4 vertical lines for variant table in print === */
        .collapse tbody tr td:nth-child(2),
        .collapse tbody tr td:nth-child(3),
        .collapse tbody tr td:nth-child(4),
        .collapse tbody tr td:nth-child(5),
        .collapse tbody tr td:nth-child(6) {
          border-left: 1.5px solid #e5e7eb !important;
        }
        .collapse tbody tr td:nth-child(1) { border-left: none !important; }

        /* === Add bottom border for last variant row === */
        .collapse tbody tr:last-child td { border-bottom: 1.5px solid #e5e7eb !important; }

        /* ===== Professional Print Summary Card (left half, two columns, middle divider) ===== */
        .print-summary-box {
          width: 50%;
          border: 1.2px solid #444;
          background: #fafafa !important;
          margin-top: 8px;
          font-size: 10px;
          box-shadow: 0 1px 2px rgba(0,0,0,0.1);
          overflow: hidden;
        }
        .print-summary-head {
          font-weight: 700;
          font-size: 10.5px;
          text-transform: uppercase;
          padding: 6px 10px;
          background: #444;
          color: #fff;
          border-bottom: 1px solid #333;
          letter-spacing: 0.3px;
        }
        .ps-row { display: grid; grid-template-columns: 1fr 1fr; }
        .ps-label, .ps-value { padding: 6px 10px; line-height: 1.4; }
        .ps-label {
          font-weight: 600;
          color: #222;
          background: #f0f0f0;
          border-right: 1px solid #ccc; /* vertical middle line */
        }
        .ps-value { text-align: right; font-weight: 700; color: #111; }
        .ps-row + .ps-row .ps-label,
        .ps-row + .ps-row .ps-value { border-top: 1px solid #ddd; /* row separators */ }
      }
    `
    document.head.appendChild(style)
    spinAdded.current = true
  }, [])
  const currencyLabel = currency ? `(${currency})` : ''
  const appliedFilterChips = useMemo(() => {
    const chips = []
    if (dateFrom || dateTo) chips.push(`Date: ${dateFrom || '—'} → ${dateTo || '—'}`)
    if (categoryOpt?.value && categoryOpt.value !== 'all') chips.push(`Category: ${categoryOpt.label}`)
    if (brandOpt?.value && brandOpt.value !== 'all') chips.push(`Brand: ${brandOpt.label}`)
    if (collectionOpt?.value && collectionOpt.value !== 'all') chips.push(`Collection: ${collectionOpt.label}`)
    return chips
  }, [dateFrom, dateTo, categoryOpt, brandOpt, collectionOpt])

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-2" style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
            <div className="d-flex justify-content-between align-items-center">
              {/* LEFT SIDE – TITLE */}
              <CardTitle as="h4" className="mb-0 report-title">
                Product Based Revenue
              </CardTitle>

              {/* RIGHT SIDE – BUTTON */}
              <div className="d-flex gap-2 no-print">
                <Button onClick={() => window.print()} style={{ background: '#7c3aed', borderColor: '#7c3aed' }}>
                  <IconifyIcon icon="mdi:printer" width={18} height={18} /> Print
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardBody className="position-relative">
            {/* PRINT-ONLY title on first page */}
            {/* <h3 className="print-only print-title">Sales Report By Products</h3> */}
            <hr className="print-only print-title-hr" />

            {loading && (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'rgba(255,255,255,.6)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  zIndex: 2,
                }}>
                <div
                  style={{
                    width: 28,
                    height: 28,
                    border: '3px solid #e5e7eb',
                    borderTopColor: '#7c3aed',
                    borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite',
                  }}
                />
              </div>
            )}

            {/* Filters (won't print) */}
            <Form className="d-flex gap-2 mb-2 no-print flex-nowrap align-items-end">
              {/* PRODUCT */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <FormLabel>Product</FormLabel>
                <Select
                  styles={selectStyles}
                  value={selectedProduct}
                  onInputChange={(value) => setProductSearch(value)}
                  onChange={setSelectedProduct}
                  options={productOptions}
                  isLoading={productSearching}
                  placeholder="Search product..."
                  isClearable
                  filterOption={null}
                  noOptionsMessage={() => (productSearch.length < 2 ? 'Type at least 2 characters...' : 'No products found')}
                />
              </div>

              {/* FROM */}
              <div style={{ flex: 1 }}>
                <FormLabel>From</FormLabel>
                <Form.Control type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} style={{ height: filterHeight }} />
              </div>

              {/* TO */}
              <div style={{ flex: 1 }}>
                <FormLabel>To</FormLabel>
                <Form.Control type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} style={{ height: filterHeight }} />
              </div>

              {/* CATEGORY */}
              <div style={{ flex: 1 }}>
                <FormLabel>Category</FormLabel>
                <Select
                  styles={selectStyles}
                  value={categoryOpt}
                  onChange={setCategoryOpt}
                  options={categoryOptions}
                  isLoading={catsLoading}
                  placeholder="Select category..."
                  isClearable
                />
              </div>

              {/* BRAND */}
              <div style={{ flex: 1 }}>
                <FormLabel>Brand</FormLabel>
                <Select styles={selectStyles} value={brandOpt} onChange={setBrandOpt} options={brandOptions} placeholder="Brand" isClearable />
              </div>

              {/* COLLECTION */}
              <div style={{ flex: 1 }}>
                <FormLabel>Collection</FormLabel>
                <Select
                  styles={selectStyles}
                  value={collectionOpt}
                  onChange={setCollectionOpt}
                  options={collectionOptions}
                  placeholder="Collection"
                  isClearable
                />
              </div>

              {/* BUTTON */}
              <div style={{ width: 110 }}>
                <Button className="w-100" variant="primary" onClick={handleSearch} disabled={loading} style={{ height: filterHeight }}>
                  {loading ? 'Searching…' : 'Search'}
                </Button>
              </div>
            </Form>

            {errorMsg && <p className="text-danger">{errorMsg}</p>}

            {/* PRINT-ONLY: Applied Filters */}
            <div className="print-filters print-only">
              <h6>Applied Filters</h6>
              <ul>{appliedFilterChips.length > 0 ? appliedFilterChips.map((c) => <li key={c}>{c}</li>) : <li>None (all data)</li>}</ul>
            </div>

            {/* Insights (hidden in print) */}
            <div className="mb-2 no-print">
              <div className="d-flex align-items-center flex-wrap gap-1 mt-2 mb-1">
                <h5 className="fw-bold mb-0">Insights</h5>
              </div>
              <hr />
              <Row className="px-1">
                <div className="mini-grid">
                  <MiniStat
                    title="Total Ordered Quantity"
                    stat={summary.total_ordered_qty}
                    subTitle="Total no. of products included in all orders from Web, Admin & Invoice transactions"
                    icon="mdi:cart-outline"
                  />

                  <MiniStat
                    title="Total Invoice Quantity"
                    stat={summary.total_sales_qty}
                    subTitle="Total units sold via Web, Admin & POS Transactions"
                    icon="mdi:cash-register"
                  />

                  <MiniStat
                    title="Total Return Quantity"
                    stat={summary.total_returned_qty}
                    subTitle="Total units returned from Web, Admin & Invoice transactions"
                    icon="mdi:alert-octagon-outline"
                  />

                  <MiniStat
                    title={`Total Invoice Amount ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_sales_amount)}
                    subTitle="Total sales revenue from Web, Admin & Invoice transactions"
                    icon="mdi:currency-usd"
                  />
                </div>
              </Row>
            </div>

            {/* Main table */}
            <Table striped className="mb-0 report-table">
              <thead className="table-light">
                <tr>
                  <th className="th-left" style={{ width: 90 }}>
                    Product ID
                  </th>
                  <th className="th-left">Product / Variant</th>
                  <th>Ordered</th>
                  <th>Invoice</th>
                  <th>Returned</th>
                  <th>Invoice Amount {currencyLabel}</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 && !loading && (
                  <tr>
                    <td colSpan={6} className="text-center py-4">
                      No data
                    </td>
                  </tr>
                )}

                {rows.map((p) => (
                  <ProductRow key={p.id} p={p} currencyLabel={currencyLabel} />
                ))}

                {/* PRINT-ONLY: Separator */}
                <tr className="print-only">
                  <td colSpan={6} style={{ padding: 0 }}>
                    <hr className="print-hr" />
                  </td>
                </tr>

                {/* PRINT-ONLY: Summary card (left half, professional look) */}
                <tr className="print-only">
                  <td colSpan={6} style={{ paddingTop: 6 }}>
                    <div className="print-summary-box" aria-label="Report totals summary">
                      <div className="print-summary-head">Summary</div>

                      <div className="ps-row">
                        <div className="ps-label">Ordered</div>
                        <div className="ps-value">{summary.total_ordered_qty}</div>
                      </div>

                      <div className="ps-row">
                        <div className="ps-label">Invoice</div>
                        <div className="ps-value">{summary.total_sales_qty}</div>
                      </div>

                      <div className="ps-row">
                        <div className="ps-label">Returned</div>
                        <div className="ps-value">{summary.total_returned_qty}</div>
                      </div>

                      <div className="ps-row">
                        <div className="ps-label">Invoice Amount {currencyLabel}</div>
                        <div className="ps-value">{formatCurrencyLKR(summary.total_sales_amount)}</div>
                      </div>
                    </div>
                  </td>
                </tr>
              </tbody>
            </Table>

            {/* NOTE: page numbers removed per request */}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

/* MiniStat component kept unchanged from your previous version */
function MiniStat({ icon, title, stat, subTitle }) {
  return (
    <div className="mini-stat">
      <div className="mini-stat-inner">
        <div className="mini-text w-100">
          <div className="d-flex justify-content-between align-items-start">
            <div className="mini-title">{title}</div>
            <div className="mini-icon-wrap ms-2">
              <IconifyIcon icon={icon} className="mini-icon" />
            </div>
          </div>
          <div className="mini-value">{stat}</div>
          <hr className="mini-divider" />
          <div className="mini-sub">{subTitle}</div>
        </div>
      </div>
    </div>
  )
}
