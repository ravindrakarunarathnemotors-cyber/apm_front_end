'use client'

import React, { useEffect, useMemo, useState, useRef, memo } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Table, Form, Button, Collapse, OverlayTrigger, Tooltip } from 'react-bootstrap'
import Select, { components } from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  useGetCategoriesQuery,
  useGetReportsBrandsQuery,
  useGetReportsCollectionsQuery,
  useGetFilteredSalesReportMutation,
  useGetDiscountCurrencyQuery,
  useGetReportProductSearchQuery,
  useGetActiveBranchesQuery,
  useAddPrintSystemLogMutation,
} from '@/store/features/apiSlice'

function formatCurrencyLKR(n) {
  const num = Number(n ?? 0)
  try {
    const out = new Intl.NumberFormat('en-LK', { style: 'currency', maximumFractionDigits: 2 }).format(num)
    return out.replace(/\s/g, '\u00A0') // keep symbol + value together when printing
  } catch {
    return `\u00A0${num.toFixed(2)}`
  }
}

const indexCategoriesById = (list = []) => {
  const map = new Map()
  list.forEach((c) => map.set(c.category_id, c))
  return map
}

const makeLineageLabel = (cat, idxMap) => {
  const parts = []
  let cur = cat
  while (cur) {
    parts.push(cur.name)
    cur = cur.category_under ? idxMap.get(cur.category_under) : null
  }
  return parts.reverse().join(' > ')
}

const SELECT_ALL_OPTION = {
  value: '__select_all__',
  label: 'Select All',
  isSelectAll: true,
}

const getOptionsWithSelectAll = (options = []) => [SELECT_ALL_OPTION, ...options]

const handleMultiSelectChange = ({ selectedOptions, actionMeta, allOptions, currentValues, setValues }) => {
  const values = Array.isArray(selectedOptions) ? selectedOptions : []
  const normalOptions = Array.isArray(allOptions) ? allOptions : []

  const selectAllClicked = actionMeta?.option?.value === SELECT_ALL_OPTION.value

  const allCurrentlySelected = normalOptions.length > 0 && currentValues.length === normalOptions.length

  if (selectAllClicked) {
    setValues(allCurrentlySelected ? [] : normalOptions)
    return
  }

  // Never store the artificial "Select All" option in state.
  setValues(values.filter((option) => option.value !== SELECT_ALL_OPTION.value))
}

const getTodayDateString = () => {
  const d = new Date()
  const yyyy = d.getFullYear()
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${yyyy}-${mm}-${dd}`
}
/* ---------------------------------------------------------------------- */
/* Shared column layout — used by BOTH the product table and the nested   */
/* variant table so the numeric columns always line up pixel-for-pixel,  */
/* on screen, in print, and at every breakpoint.                          */
/* ---------------------------------------------------------------------- */
const REPORT_COLUMNS = [
  { key: 'id', width: 70 },
  { key: 'name' },
  { key: 'ordered', width: 90 },
  { key: 'invoice', width: 90 },
  { key: 'returned', width: 90 },
  { key: 'baseAmount', width: 150 },
  { key: 'amount', width: 150 },
]

const ReportColGroup = () => (
  <colgroup>
    {REPORT_COLUMNS.map((col) => (
      <col key={col.key} style={col.width ? { width: col.width, minWidth: col.width } : { minWidth: 260 }} />
    ))}
  </colgroup>
)

const CheckboxOption = (props) => {
  const selectedValues = Array.isArray(props.selectProps?.value) ? props.selectProps.value : []

  const availableOptions = Array.isArray(props.selectProps?.allRealOptions) ? props.selectProps.allRealOptions : []

  const isSelectAll = props.data?.isSelectAll === true

  const allSelected = availableOptions.length > 0 && selectedValues.length === availableOptions.length

  const isChecked = isSelectAll ? allSelected : props.isSelected

  return (
    <components.Option {...props}>
      <div className="d-flex align-items-center gap-2">
        <Form.Check type="checkbox" checked={isChecked} onChange={() => {}} tabIndex={-1} readOnly style={{ pointerEvents: 'none' }} />

        <span
          style={{
            fontWeight: isSelectAll ? 600 : 400,
          }}>
          {props.label}
        </span>
      </div>
    </components.Option>
  )
}
const MultiValueContainer = (props) => {
  const { children, selectProps, data } = props

  const selectedValues = Array.isArray(selectProps?.value) ? selectProps.value : []

  const selectedCount = selectedValues.length

  const firstSelectedValue = selectedValues[0]

  const isFirstSelectedItem = firstSelectedValue?.value === data?.value

  if (!isFirstSelectedItem) return null

  return <components.MultiValueContainer {...props}>{selectedCount === 1 ? children : `${selectedCount} selected`}</components.MultiValueContainer>
}

const CategoryTreeItem = ({ node, level = 0, selectedValues = [], expandedIds, toggleExpanded, toggleCategory }) => {
  const hasChildren = Array.isArray(node?.children) && node.children.length > 0

  const isExpanded = expandedIds instanceof Set && expandedIds.has(node.value)

  const isSelected = selectedValues.some((option) => Number(option.value) === Number(node.value))

  const handleExpand = (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (hasChildren) {
      toggleExpanded(node.value)
    }
  }

  const handleSelect = (event) => {
    event.preventDefault()
    event.stopPropagation()

    toggleCategory({
      value: node.value,
      label: node.label,
    })
  }

  return (
    <div className="category-tree-node">
      <div
        className={`category-tree-row ${isSelected ? 'category-tree-row-selected' : ''}`}
        style={{
          paddingLeft: `${8 + level * 18}px`,
        }}>
        <button
          type="button"
          className={`category-tree-expand-btn ${isExpanded ? 'is-expanded' : ''}`}
          onMouseDown={handleExpand}
          disabled={!hasChildren}
          aria-label={hasChildren ? (isExpanded ? `Collapse ${node.label}` : `Expand ${node.label}`) : undefined}>
          {hasChildren ? (
            <IconifyIcon icon="mdi:chevron-right" width={18} height={18} className="category-tree-chevron" />
          ) : (
            <span className="category-tree-leaf-space" />
          )}
        </button>

        <button type="button" className="category-tree-content" onMouseDown={handleSelect} title={node.label}>
          <span className="category-tree-checkbox">
            <Form.Check
              type="checkbox"
              checked={isSelected}
              onChange={() => {}}
              tabIndex={-1}
              readOnly
              style={{
                pointerEvents: 'none',
                margin: 0,
              }}
            />
          </span>

          <span className="category-tree-label">{node.label || `Category ${node.value}`}</span>
        </button>
      </div>

      {hasChildren && (
        <div className={`category-tree-children ${isExpanded ? 'is-expanded' : ''}`}>
          <div className="category-tree-children-inner">
            {node.children.map((child) => (
              <CategoryTreeItem
                key={child.value}
                node={child}
                level={level + 1}
                selectedValues={selectedValues}
                expandedIds={expandedIds}
                toggleExpanded={toggleExpanded}
                toggleCategory={toggleCategory}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

const CategoryMenuList = (props) => {
  const { selectProps } = props

  const categoryTree = selectProps.categoryTree || []

  const selectedValues = Array.isArray(selectProps.value) ? selectProps.value : []

  const expandedIds = selectProps.expandedCategoryIds || new Set()

  const toggleExpanded = selectProps.toggleCategoryExpanded

  const toggleCategory = selectProps.toggleCategorySelection

  const allCategoryOptions = selectProps.allRealOptions || []

  const allSelected = allCategoryOptions.length > 0 && selectedValues.length === allCategoryOptions.length

  return (
    <components.MenuList {...props}>
      <div
        className="category-tree-select-all"
        onMouseDown={(event) => {
          event.preventDefault()
          event.stopPropagation()

          selectProps.toggleAllCategories()
        }}>
        <Form.Check
          type="checkbox"
          checked={allSelected}
          onChange={() => {}}
          tabIndex={-1}
          readOnly
          style={{
            pointerEvents: 'none',
            margin: 0,
          }}
        />

        <span>Select All</span>
      </div>

      <div className="category-tree-divider" />

      {categoryTree.length === 0 ? (
        <div className="category-tree-empty">No categories found</div>
      ) : (
        categoryTree.map((node) => (
          <CategoryTreeItem
            key={node.value}
            node={node}
            level={0}
            selectedValues={selectedValues}
            expandedIds={expandedIds}
            toggleExpanded={toggleExpanded}
            toggleCategory={toggleCategory}
          />
        ))
      )}
    </components.MenuList>
  )
}

const buildCategoryTree = (categories = []) => {
  if (!Array.isArray(categories)) return []

  const nodeMap = new Map()

  categories.forEach((category) => {
    const categoryId = Number(category.category_id)

    if (!Number.isFinite(categoryId)) return

    nodeMap.set(categoryId, {
      value: categoryId,
      label: category.name?.trim() || `Category ${categoryId}`,
      category_under: category.category_under === null || category.category_under === undefined ? null : Number(category.category_under),
      children: [],
    })
  })

  const roots = []

  nodeMap.forEach((node) => {
    if (node.category_under !== null && nodeMap.has(node.category_under)) {
      nodeMap.get(node.category_under).children.push(node)
    } else {
      roots.push(node)
    }
  })

  const sortTree = (nodes) => {
    nodes.sort((a, b) => a.label.localeCompare(b.label))

    nodes.forEach((node) => {
      sortTree(node.children)
    })
  }

  sortTree(roots)

  return roots
}

const flattenCategoryTree = (nodes = []) => {
  const result = []

  const walk = (items) => {
    items.forEach((item) => {
      result.push({
        value: item.value,
        label: item.label,
      })

      if (item.children?.length) {
        walk(item.children)
      }
    })
  }

  walk(nodes)

  return result
}

/** Single product row (memoized) — local expand state to avoid page-wide re-render */

const AmountHeader = ({ label, currencyLabel, tooltip }) => (
  <span className="amount-header-wrap">
    <span>
      {label} {currencyLabel}
    </span>

    <OverlayTrigger placement="top" overlay={<Tooltip className="amount-header-tooltip">{tooltip}</Tooltip>}>
      <button type="button" className="amount-info-btn no-print" aria-label={`Explain ${label}`} onClick={(event) => event.preventDefault()}>
        ?
      </button>
    </OverlayTrigger>
  </span>
)
const ProductRow = memo(function ProductRow({ p }) {
  const [open, setOpen] = useState(false)
  const variants = p.variants || []

  const isSingleDefaultVariant = variants.length === 1 && (variants[0].variant_label || '').trim().toLowerCase() === 'default'

  const hasExpandableVariants = variants.length > 0 && !isSingleDefaultVariant

  return (
    <>
      <tr className="product-row">
        <td className="cell-id">{p.id}</td>
        <td className="cell-name">
          <div className="product-name-wrap">
            <span className="product-name-text" title={p.name}>
              {p.name}
            </span>

            {hasExpandableVariants && (
              <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                className={`variant-count-badge variant-count-badge-clickable no-print ${open ? 'is-expanded' : ''}`}
                aria-expanded={open}
                aria-label={open ? `Collapse variants for ${p.name}` : `Show ${variants.length} variants for ${p.name}`}>
                {variants.length} variant{variants.length > 1 ? 's' : ''}
                <IconifyIcon icon="mdi:chevron-right" width={14} height={14} className="variant-count-chevron" />
              </button>
            )}

            {isSingleDefaultVariant && <span className="variant-count-badge no-print">#{variants[0].variant_id}</span>}
          </div>
        </td>
        <td>{p.ordered_qty}</td>
        <td>{p.sales_qty}</td>
        <td>{p.returned_qty}</td>

        <td className="text-currency">{formatCurrencyLKR(p.base_amount)}</td>
        <td className="text-currency">{formatCurrencyLKR(p.sales_amount)}</td>
      </tr>

      {hasExpandableVariants && (
        <tr className="variant-block-row">
          <td colSpan={7} style={{ padding: 0, borderTop: 0 }}>
            <Collapse in={open}>
              <div>
                <Table size="sm" className="mb-0 variant-table">
                  <ReportColGroup />
                  <tbody>
                    {variants.map((v) => (
                      <tr key={v.variant_id}>
                        <td className="cell-id" />
                        <td className="cell-name variant-name-cell">
                          <span className="variant-icon d-inline-flex align-items-center gap-1">
                            <IconifyIcon icon="mdi:package-variant-closed" width={14} height={14} />
                          </span>
                          <span className="variant-label-text">
                            <span className="variant-id-text">#{v.variant_id}</span> {v.variant_label}
                          </span>
                        </td>
                        <td>{v.ordered_qty}</td>
                        <td>{v.sales_qty}</td>
                        <td>{v.returned_qty}</td>

                        <td className="text-currency">{formatCurrencyLKR(v.base_amount)}</td>
                        <td className="text-currency">{formatCurrencyLKR(v.sales_amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </div>
            </Collapse>
          </td>
        </tr>
      )}
    </>
  )
})

export default function SalesReport() {
  // filters
  const [categoryOpts, setCategoryOpts] = useState([])
  const [brandOpts, setBrandOpts] = useState([])
  const [collectionOpts, setCollectionOpts] = useState([])
  const [outletOpts, setOutletOpts] = useState([])
  const [dateFrom, setDateFrom] = useState(() => getTodayDateString())
  const [dateTo, setDateTo] = useState('')
  const [expandedCategoryIds, setExpandedCategoryIds] = useState(() => new Set())

  // responsive filter panel (collapsed by default on small screens via CSS-driven class,
  // but state-controlled so it also works as a manual toggle on any screen size)
  const [filtersOpen, setFiltersOpen] = useState(true)

  // table / ui state
  const [rows, setRows] = useState([]) // normalized product rows for UI
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')

  const [summary, setSummary] = useState({
    total_ordered_qty: 0,
    total_sales_qty: 0,
    total_returned_qty: 0,

    total_order_base_amount: 0,
    total_invoice_base_amount: 0,
    total_base_amount: 0,

    total_sales_amount: 0,

    total_service_charge_amount: 0,
    total_discount_amount: 0,
    total_tax_amount: 0,
    total_additional_amount: 0,
    total_delivery_charge_amount: 0,
  })

  // Product search filter
  const [productSearch, setProductSearch] = useState('')
  const [selectedProducts, setSelectedProducts] = useState([])
  // options
  const [brandOptions, setBrandOptions] = useState([])
  const [collectionOptions, setCollectionOptions] = useState([])

  const { data: currency = '', isLoading: currencyLoading } = useGetDiscountCurrencyQuery()
  // react-select sizing
  const filterHeight = 38
  const selectStyles = {
    control: (base, state) => ({
      ...base,
      minHeight: filterHeight,
      height: filterHeight,
      fontSize: 13,
      borderRadius: 8,
      borderColor: state.isFocused ? '#7c3aed' : '#dee2e6',
      boxShadow: state.isFocused ? '0 0 0 3px rgba(124,58,237,.12)' : 'none',
      background: '#fff',
      transition: 'border-color .15s ease, box-shadow .15s ease',
    }),
    valueContainer: (base) => ({ ...base, padding: '0 10px', flexWrap: 'nowrap', overflow: 'hidden' }),
    indicatorsContainer: (base) => ({ ...base, height: filterHeight }),
    menu: (base) => ({ ...base, zIndex: 9999, fontSize: 12.5 }),
    menuPortal: (base) => ({ ...base, zIndex: 9999 }),
    clearIndicator: (base) => ({ ...base, padding: 4, cursor: 'pointer' }),
    dropdownIndicator: (base) => ({ ...base, padding: 4 }),
    multiValue: (base) => ({ ...base, maxWidth: '100%', margin: 0 }),
    multiValueLabel: (base) => ({ ...base, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }),
  }

  const multiSelectProps = {
    isMulti: true,
    closeMenuOnSelect: false,
    hideSelectedOptions: false,
    components: {
      Option: CheckboxOption,
      MultiValueContainer,
    },
    styles: selectStyles,
    menuPortalTarget: typeof document !== 'undefined' ? document.body : null,
  }

  // data hooks
  const { data: categoriesData = [], isLoading: catsLoading } = useGetCategoriesQuery()
  const { data: brandsData = [] } = useGetReportsBrandsQuery()
  const { data: collectionsData = [] } = useGetReportsCollectionsQuery()
  const { data: branchesData = [], isLoading: outletsLoading } = useGetActiveBranchesQuery()
  const [getFilteredSalesReport] = useGetFilteredSalesReportMutation()
  const [addPrintSystemLog] = useAddPrintSystemLogMutation()
  const { data: productResults = [], isFetching: productSearching } = useGetReportProductSearchQuery(productSearch, {
    skip: !productSearch || productSearch.length < 2,
  })

  const productOptions = useMemo(() => {
    const list = productResults?.products || productResults?.data?.products || productResults || []

    if (!Array.isArray(list)) return []

    const uniqueMap = new Map()

    list.forEach((p) => {
      if (!p?.product_id) return

      if (!uniqueMap.has(p.product_id)) {
        uniqueMap.set(p.product_id, {
          value: p.product_id,
          label: `${p.title} (ID: ${p.product_id})`,
        })
      }
    })

    return Array.from(uniqueMap.values())
  }, [productResults])
  // map selects
  useEffect(() => {
    if (Array.isArray(brandsData) && brandsData.length > 0) {
      const opts = brandsData.map((b) => ({ value: b.brand_id, label: b.name })).sort((a, b) => a.label.localeCompare(b.label))
      setBrandOptions(opts)
    } else {
      setBrandOptions([])
    }
  }, [brandsData])

  useEffect(() => {
    if (Array.isArray(collectionsData) && collectionsData.length > 0) {
      const opts = collectionsData.map((c) => ({ value: c.collection_id, label: c.name })).sort((a, b) => a.label.localeCompare(b.label))
      setCollectionOptions(opts)
    } else {
      setCollectionOptions([])
    }
  }, [collectionsData])

  const categoryTree = useMemo(() => {
    const list = categoriesData?.data || categoriesData?.categories || categoriesData || []

    return buildCategoryTree(list)
  }, [categoriesData])

  const categoryOptions = useMemo(() => {
    return flattenCategoryTree(categoryTree)
  }, [categoryTree])

  const toggleCategoryExpanded = (categoryId) => {
    setExpandedCategoryIds((current) => {
      const next = new Set(current)

      if (next.has(categoryId)) {
        next.delete(categoryId)
      } else {
        next.add(categoryId)
      }

      return next
    })
  }

  const toggleCategorySelection = (category) => {
    setCategoryOpts((current) => {
      const exists = current.some((option) => Number(option.value) === Number(category.value))

      if (exists) {
        return current.filter((option) => Number(option.value) !== Number(category.value))
      }

      return [
        ...current,
        {
          value: category.value,
          label: category.label,
        },
      ]
    })
  }

  const toggleAllCategories = () => {
    setCategoryOpts((current) => {
      const allSelected = categoryOptions.length > 0 && current.length === categoryOptions.length

      return allSelected ? [] : categoryOptions
    })
  }

  const outletOptions = useMemo(() => {
    const list = branchesData?.data || branchesData?.outlets || branchesData || []
    if (!Array.isArray(list)) return []

    return list
      .filter((branch) => branch?.branch_id != null)
      .map((branch) => ({
        value: branch.branch_id,
        label: branch.branch_name?.trim() || `Outlet ${branch.branch_id}`,
      }))
      .sort((a, b) => a.label.localeCompare(b.label))
  }, [branchesData])

  // normalize API -> UI rows
  const normalizeProducts = (products = []) =>
    products.map((p) => ({
      id: p.product_id,
      name: p.title,

      ordered_qty: Number(p.product_total_order_quantity ?? 0),

      // Invoice quantity only
      sales_qty: Number(p.product_invoice_quantity ?? p.product_invoice_sales_quantity ?? 0),

      returned_qty: Number(p.product_returned_items_quantity ?? 0),

      returned_order_qty: Number(p.product_returned_orders_count ?? 0),

      // Order base amount before additional charges.
      order_base_amount: Number(p.product_order_base_amount ?? 0),

      // Invoice base amount before additional charges.
      invoice_base_amount: Number(p.product_invoice_base_amount ?? 0),

      // Combined order + invoice base amount.
      base_amount: Number(p.product_order_base_amount ?? 0) + Number(p.product_invoice_base_amount ?? 0),
      // Total sales amount from orders and invoices
      sales_amount: Number(p.product_total_sales_amount ?? p.product_invoice_sales_amount ?? p.product_order_sales_amount ?? 0),
      variants: (p.variants || []).map((v) => ({
        variant_id: v.variant_id,
        variant_label: v.variant_value,

        ordered_qty: Number(v.order_quantity ?? 0),

        // Variant invoice quantity only
        sales_qty: Number(v.invoice_quantity ?? v.invoice_sales_quantity ?? 0),

        returned_qty: Number(v.returned_items_quantity ?? 0),

        returned_order_qty: Number(v.returned_orders_count ?? 0),

        order_base_amount: Number(v.order_base_amount ?? 0),

        invoice_base_amount: Number(v.invoice_base_amount ?? 0),

        // Combined order + invoice base amount.
        base_amount: Number(v.order_base_amount ?? 0) + Number(v.invoice_base_amount ?? 0),
        // Variant total sales amount from orders and invoices
        sales_amount: Number(v.total_sales_amount ?? v.invoice_sales_amount ?? v.order_sales_amount ?? 0),
      })),
    }))

  // fetch
  const fetchReport = async () => {
    setLoading(true)
    setErrorMsg('')
    try {
      const payload = {
        date_from: dateFrom || null,
        date_to: dateTo || null,
        category_ids: categoryOpts.map((option) => option.value),
        brand_ids: brandOpts.map((option) => option.value),
        collection_ids: collectionOpts.map((option) => option.value),
        outlet_ids: outletOpts.map((option) => option.value),
        product_ids: selectedProducts.map((option) => option.value),
        page: 1,
        page_size: 25,
      }

      const res = await getFilteredSalesReport(payload).unwrap()
      const body = res?.products ? res : res?.data?.products ? res.data : res

      const products = normalizeProducts(body?.products ?? [])
      setRows(products)

      const rawSummary = body?.sales_report_summary ?? body?.data?.sales_report_summary ?? body?.summary ?? null

      const computeSummaryFromProducts = (list = []) => {
        let total_ordered_qty = 0
        let total_invoice_qty = 0
        let total_returned_qty = 0
        let total_order_base_amount = 0
        let total_invoice_base_amount = 0
        let total_base_amount = 0
        let total_invoice_amount = 0
        for (const p of list) {
          total_ordered_qty += Number(p?.ordered_qty ?? 0)

          total_invoice_qty += Number(p?.sales_qty ?? 0)

          total_returned_qty += Number(p?.returned_qty ?? 0)

          total_order_base_amount += Number(p?.order_base_amount ?? 0)

          total_invoice_base_amount += Number(p?.invoice_base_amount ?? 0)

          total_base_amount += Number(p?.base_amount ?? 0)
          total_invoice_amount += Number(p?.sales_amount ?? 0)
        }

        return {
          total_ordered_qty,
          total_sales_qty: total_invoice_qty,
          total_returned_qty,

          total_order_base_amount,
          total_invoice_base_amount,
          total_base_amount,

          total_sales_amount: total_invoice_amount,
          total_service_charge_amount: 0,
          total_discount_amount: 0,
          total_tax_amount: 0,
          total_additional_amount: 0,
          total_delivery_charge_amount: 0,
        }
      }

      const s = rawSummary
        ? {
            total_ordered_qty: Number(rawSummary?.total_ordered_qty ?? 0),

            total_sales_qty: Number(rawSummary?.total_sales_qty ?? 0),

            total_returned_qty: Number(rawSummary?.total_returned_qty ?? 0),

            total_order_base_amount: Number(rawSummary?.total_order_base_amount ?? 0),

            total_invoice_base_amount: Number(rawSummary?.total_invoice_base_amount ?? 0),

            total_base_amount: Number(
              rawSummary?.total_base_amount ?? Number(rawSummary?.total_order_base_amount ?? 0) + Number(rawSummary?.total_invoice_base_amount ?? 0),
            ),

            total_sales_amount: Number(rawSummary?.total_sales_amount ?? 0),

            total_service_charge_amount: Number(rawSummary?.total_service_charge_amount ?? 0),

            total_discount_amount: Number(rawSummary?.total_discount_amount ?? 0),

            total_tax_amount: Number(rawSummary?.total_tax_amount ?? 0),

            total_additional_amount: Number(rawSummary?.total_additional_amount ?? 0),

            total_delivery_charge_amount: Number(rawSummary?.total_delivery_charge_amount ?? 0),
          }
        : computeSummaryFromProducts(products)

      setSummary(s)
    } catch (err) {
      console.error('Report fetch error:', err)
      setErrorMsg('Failed to fetch report. Please check your connection and try again.')
      setRows([])
      setSummary({
        total_ordered_qty: 0,
        total_sales_qty: 0,
        total_returned_qty: 0,
        total_order_base_amount: 0,
        total_invoice_base_amount: 0,
        total_base_amount: 0,
        total_sales_amount: 0,

        total_service_charge_amount: 0,
        total_discount_amount: 0,
        total_tax_amount: 0,
        total_additional_amount: 0,
        total_delivery_charge_amount: 0,
      })
    } finally {
      setLoading(false)
    }
  }

  // initial load
  useEffect(() => {
    fetchReport()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const handleSearch = () => fetchReport()
  const handlePrint = async () => {
    try {
      await addPrintSystemLog({
        module: 'Sales Report',
        log: 'Printed Product Based Revenue report',
      }).unwrap()
    } catch (error) {
      console.error('Failed to insert print system log:', error)
    } finally {
      window.print()
    }
  }
  const clearAllFilters = () => {
    setDateFrom('')
    setDateTo('')
    setCategoryOpts([])
    setBrandOpts([])
    setCollectionOpts([])
    setOutletOpts([])
    setSelectedProducts([])
    setProductSearch('')
  }

  // global styles once
  const spinAdded = useRef(false)
  useEffect(() => {
    if (spinAdded.current) return
    const style = document.createElement('style')
    style.innerHTML = `
      @keyframes spin { to { transform: rotate(360deg); } }
      @keyframes fadeInUp { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }

      /* Base table alignment */
      table.report-table { table-layout: auto; width: 100%; }
      table.variant-table { table-layout: auto; width: 100%; }
      table.report-table tbody td { vertical-align: middle; text-align: center; }
      table.report-table thead th { text-align: center; vertical-align: middle; }
      table.report-table thead th.th-left,
      table.report-table tbody td.cell-id,
      table.report-table tbody td.cell-name { text-align: left; font-size: 12px;  }
      .text-currency { text-align: right !important; white-space: nowrap; font-variant-numeric: tabular-nums; }
      table.report-table tbody td,
      table.variant-table tbody td { font-variant-numeric: tabular-nums; }

      /* Product name cell */
      .product-name-wrap { display: block; line-height: 1.4; }
      .product-name-text {  white-space: normal; text-transform: capitalize; word-break: break-word;}
      .variant-count-badge {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        font-size: 10.5px;
        font-weight: 600;
        color: #7c3aed;
        background: #f3ecfe;
        border-radius: 999px;
        padding: 2px 8px;
        white-space: nowrap;
        margin-left: 6px;
        vertical-align: middle;
      }

      .variant-count-badge-clickable {
        border: none;
        cursor: pointer;
        transition: background-color .15s ease, transform .1s ease;
      }

      .variant-count-badge-clickable:hover {
        background: #e9dbfc;
      }

      .variant-count-badge-clickable:active {
        transform: scale(0.97);
      }

      .variant-count-chevron {
        transition: transform .18s ease;
      }

      .variant-count-badge-clickable.is-expanded .variant-count-chevron {
        transform: rotate(90deg);
      }


      .expander-btn:focus-visible,
      .category-tree-expand-btn:focus-visible,
      .category-tree-content:focus-visible,
      .filters-toggle-btn:focus-visible {
        outline: 2px solid #7c3aed;
        outline-offset: 2px;
      }

      /* Variant rows — clearly read as "children" of the product row */
      .variant-table tbody tr:hover { background: #fafafa; }
      .variant-name-cell { display: block;  padding-left: 46px !important;  position: relative; }
      .variant-name-cell::before {
        content: '';
        position: absolute;
        left: 24px;
        top: 0;
        bottom: 50%;
        width: 1px;
        background: #d8dbe0;
      }
      .variant-name-cell::after {
        content: '';
        position: absolute;
        left: 24px;
        top: 50%;
        width: 10px;
        height: 1px;
        background: #d8dbe0;
      }
      .variant-icon { color: #9aa0a6; flex: 0 0 auto; }
      .variant-label-text { white-space: normal;  text-transform: capitalize;  word-break: break-word; }
      .variant-id-text { color: #696d71; font-weight: 500; }

      /* Mini stats (web) — responsive grid instead of fixed 4-across flex */
      .mini-grid {
        width: 100%;
        display: grid;
      grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 12px;
      }
      .mini-stat-inner {
        height: 100%;
        border: 1px solid var(--bs-border-color, #dee2e6);
        background: #fff;
        border-radius: 10px;
        padding: 12px 14px;
        min-height: 108px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: background-color 0.18s ease, transform 0.18s ease, color 0.18s ease, border-color 0.18s ease, box-shadow .18s ease;
      }
      .mini-stat-inner:hover { background-color: #343a40; color: #fff; transform: translateY(-2px); border-color: #343a40; box-shadow: 0 6px 16px rgba(0,0,0,.12); }
      .mini-icon-wrap { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #f3f4f6; flex: 0 0 auto; }
      .mini-icon { font-size: 16px; color: #6c757d; }
      .mini-stat-inner:hover .mini-icon { color: #05a000ff; }
      .mini-title { font-weight: 600; font-size: 0.85rem; margin-bottom: 2px; }
      .mini-value { font-weight: 700; font-size: 1.15rem; margin: 0 0 2px; color: #28a745; }
      .mini-divider { border: none; border-top: 1px solid rgba(0,0,0,0.1); margin: 2px 0 4px; width: 100%; }
      .mini-sub { font-size: 0.72rem; color: #6c757d; line-height: 1.35; }

      @media (max-width: 991.98px) {
        .mini-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      }
      @media (max-width: 480px) {
        .mini-grid { grid-template-columns: 1fr; }
      }

      /* Filter chips (screen + print) */
      .chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: .75rem;
        border: 1px solid var(--bs-border-color, #dee2e6);
        border-radius: 999px;
        padding: 4px 8px 4px 10px;
        background: #f8f9fa;
        color: #343a40;
        max-width: 100%;
      }
      .chip-text { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .chip-remove {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        border: none;
        background: transparent;
        color: #6c757d;
        flex: 0 0 auto;
        cursor: pointer;
        padding: 0;
      }
      .chip-remove:hover { background: #e9ecef; color: #111827; }
      .filter-chip-row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; animation: fadeInUp .18s ease; }

      /* Filters panel */
      .filters-card {
        border: 1px solid var(--bs-border-color, #dee2e6);
        border-radius: 12px;
        background: #fbfbfd;
        padding: 14px 16px;
      }
      .filters-card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 2px;
      }
      .filters-toggle-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: none;
        background: transparent;
        font-weight: 700;
        font-size: 13.5px;
        color: #212529;
        padding: 4px 2px;
        cursor: pointer;
      }
      .filters-toggle-icon { transition: transform .2s ease; }
      .filters-toggle-btn[aria-expanded="false"] .filters-toggle-icon { transform: rotate(-90deg); }
      .filters-clear-btn {
        border: none;
        background: transparent;
        color: #7c3aed;
        font-size: 12.5px;
        font-weight: 600;
        padding: 4px 6px;
        border-radius: 6px;
      }
      .filters-clear-btn:hover { background: #f3ecfe; }
      .filters-clear-btn:disabled { color: #adb5bd; cursor: not-allowed; }
      .filters-clear-btn:disabled:hover { background: transparent; }

      /* Two-row report filter layout */
      .sales-filter-grid { width: 100%; display: flex; flex-direction: column; gap: 12px; margin-top: 10px; }
      .sales-filter-row { width: 100%; display: grid; gap: 10px; align-items: end; }
      .sales-filter-row-first { grid-template-columns: minmax(0,1.4fr) minmax(0,1fr) minmax(0,1fr); }
      .sales-filter-row-second { grid-template-columns: repeat(4, minmax(0, 1fr)) minmax(110px, .6fr); }
      .sales-filter-field, .sales-filter-search { min-width: 0; }
      .sales-filter-search .btn { height: 38px; border-radius: 8px; font-weight: 600; }
      .po-filter-label { font-size: 12px; font-weight: 600; margin-bottom: 4px; color: #495057; }
      .sales-filter-field .form-control { height: 38px; border-radius: 8px; font-size: 13px; }
      .sales-filter-field .form-control:focus { border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124,58,237,.12); }

      @media (max-width: 991.98px) {
        .sales-filter-row-first { grid-template-columns: 1fr 1fr; }
        .sales-filter-row-first .sales-filter-field:first-child { grid-column: 1 / -1; }
        .sales-filter-row-second { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .sales-filter-search { grid-column: 1 / -1; }
      }

      @media (max-width: 575.98px) {
        .sales-filter-row-first,
        .sales-filter-row-second { grid-template-columns: 1fr; }
        .sales-filter-row-first .sales-filter-field:first-child,
        .sales-filter-search { grid-column: auto; }
        .filters-card { padding: 12px; }
      }

      /* Report header — stack title/actions on narrow screens */
      .report-header .report-header-inner { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; }
      @media (max-width: 420px) {
        .report-header .report-header-inner { flex-direction: column; align-items: stretch; }
        .report-header .report-header-actions { width: 100%; }
        .report-header .report-header-actions .btn { width: 100%; justify-content: center; }
      }

      /* Table scroll container: horizontal scroll on small screens,
         sticky header for long lists on all screens */
      .table-responsive { position: relative; }
      table.report-table thead th {
        position: sticky;
        top: 0;
        z-index: 1;
        background: #f2f2f5;
      }
      @media (max-width: 767.98px) {
        table.report-table { min-width: 720px; }
      }

      /* Empty / error states */
      .report-empty-state { padding: 48px 16px; text-align: center; color: #6c757d; }
      .report-empty-state .report-empty-icon { font-size: 34px; color: #cbd0d6; margin-bottom: 8px; }
      .report-empty-state .report-empty-title { font-weight: 600; color: #495057; margin-bottom: 2px; }
      .report-error-banner {
        display: flex;
        align-items: center;
        gap: 8px;
        background: #fdeceb;
        border: 1px solid #f5c2c0;
        color: #a02622;
        border-radius: 8px;
        padding: 10px 14px;
        font-size: 13.5px;
        margin-bottom: 14px;
      }

      .amount-header-wrap {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        white-space: nowrap;
      }

      .amount-info-btn {
        width: 17px;
        height: 17px;
        padding: 0;
        border: 1px solid #9ca3af;
        border-radius: 50%;
        background: transparent;
        color: #6b7280;
        font-size: 10px;
        font-weight: 800;
        line-height: 15px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: help;
        transition:
          background-color 0.15s ease,
          color 0.15s ease,
          border-color 0.15s ease;
      }

      .amount-info-btn:hover,
      .amount-info-btn:focus-visible {
        background: #7c3aed;
        border-color: #7c3aed;
        color: #fff;
        outline: none;
      }

      .amount-header-tooltip .tooltip-inner {
        max-width: 300px;
        padding: 9px 11px;
        font-size: 11.5px;
        line-height: 1.45;
        text-align: left;
      }

      /* Bullet styling visible on screen */
      .product-bullet { display: inline-block; margin: 0 6px 0 2px; font-size: 14px; color: #9ca3af; }

      /* Print-only helpers (hidden for screen by default) */
      .print-only { display: none !important; }

      /* --- PRINT RULES --- */
      @page {
        size: auto;
        margin: 12mm 10mm; /* clean, consistent margins on every page */
      }


      @media print {
        * {
          box-shadow: none !important;
          text-shadow: none !important;
          filter: none !important;
        }

        .amount-header-wrap {
  display: inline !important;
    }

    .amount-info-btn {
      display: none !important;
    }

        .bg-orbs,
        .layout-decoration,
        .rotating-blob {
          display: none !important;
        }

        html, body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          font-size: 9.5px;
          line-height: 1.35;
          background: #fff !important;
          color: #1a1a1a;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
          height: auto !important;
          max-height: none !important;
          overflow: visible !important; 
          margin: 0 !important; 
          padding: 0 !important;
          background-image: none !important; 
        }

        .report-loading-overlay {   
          display: none !important;
        }

          body, 
          .card, 
          .report-container, /* Update this class to match your actual main wrapper class */
          .page-content {
            background: #fff !important;
            background-color: #fff !important;
          }

          .filters-card, .card, .card-body {
            background: #fff !important;
            background-color: #fff !important;
            border: none !important;
          }

          /* Specifically target the container that holds the "Applied Filters" and the Table */
          /* If your report is inside a card with a light background, remove it here: */
          .card {
            border: none !important;
          }

        /* Re-enable print-only elements */
        .print-only { display: initial !important; }
        tr.print-only { display: table-row !important; }

        /* --- Blunt but effective: this page usually sits inside a
           dashboard shell (layout wrapper / SimpleBar) that has a fixed
           height + overflow:auto so it scrolls on screen. That container
           is what clips print to a single "page with a scroller" — it
           is NOT this component, so we reach out and neutralize it. */
        *, *::before, *::after {
          max-height: none !important;
          overflow: visible !important;
        }

        /* Common Next.js dashboard-shell / layout wrapper patterns */
        #__next,
        #root,
        #layout-wrapper,
        .wrapper,
        .content-page,
        .page-content,
        .main-content,
        main { 
          height: auto !important;
          max-height: none !important;
          overflow: visible !important;
          position: static !important;
          background: #fff !important;
        }

        /* SimpleBar (very common in these admin templates) keeps its own
           internal scroll box regardless of parent overflow rules —
           it needs to be unwound explicitly or print still clips to
           one viewport height. */
        .simplebar-wrapper,
        .simplebar-mask,
        .simplebar-offset,
        .simplebar-content-wrapper,
        .simplebar-content {
          height: auto !important;
          max-height: none !important;
          overflow: visible !important;
          position: static !important;
          transform: none !important;
          background: #fff !important;
        }
        .simplebar-track,
        .simplebar-scrollbar {
          display: none !important;
        }

        /* Kill any scroll containers inside this component too — this is
           what caused the report table itself to print clipped/scrolled
           instead of flowing across pages */
        .table-responsive {
          overflow: visible !important;
          overflow-x: visible !important;
          overflow-y: visible !important;
          height: auto !important;
          max-height: none !important;
          width: 100% !important;
          -webkit-overflow-scrolling: auto !important;
          margin-top: 8mm !important; /* FIX: gap between filters block and table */
        }
        table.report-table,
        table.variant-table { table-layout: fixed !important; width: 100% !important; }
        table.report-table thead th { position: static !important; }

    /* Hide the screen header when printing */
        .report-header {
          display: none !important;
        }

        /* Professional print-only report header */
        .print-report-header {
          display: block !important;
          width: 100%;
          margin: 0 0 5mm !important;
          padding: 0 !important;
          break-inside: avoid !important;
        }

        .print-report-header-top {
          display: flex !important;
          align-items: flex-end !important;
          justify-content: space-between !important;
          gap: 16mm !important;
          padding: 0 0 3mm !important;
        }

        .print-report-label {
          margin-bottom: 1.2mm !important;
          font-size: 7.5px !important;
          line-height: 1 !important;
          font-weight: 800 !important;
          letter-spacing: 1.3px !important;
          text-transform: uppercase !important;
          color: #6b7280 !important;
        }

        .print-report-title {
          margin: 0 !important;
          padding: 0 !important;
          font-size: 20px !important;
          line-height: 1.1 !important;
          font-weight: 800 !important;
          letter-spacing: -0.3px !important;
          color: #111827 !important;
        }

        .print-report-description {
          margin-top: 1.5mm !important;
          font-size: 8.5px !important;
          line-height: 1.35 !important;
          font-weight: 400 !important;
          color: #6b7280 !important;
        }

        .print-report-meta {
          min-width: 42mm !important;
          display: grid !important;
          grid-template-columns: 1fr !important;
          gap: 1.5mm !important;
          padding: 2.5mm 3mm !important;
          border: 1px solid #d1d5db !important;
          border-radius: 2mm !important;
          background: #f8fafc !important;
        }

        .print-meta-item {
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          gap: 8mm !important;
        }

        .print-meta-item + .print-meta-item {
          padding-top: 1.5mm !important;
          border-top: 1px solid #e5e7eb !important;
        }

        .print-meta-label {
          font-size: 7.5px !important;
          font-weight: 700 !important;
          text-transform: uppercase !important;
          letter-spacing: 0.45px !important;
          color: #6b7280 !important;
        }

        .print-meta-value {
          font-size: 8.5px !important;
          font-weight: 700 !important;
          white-space: nowrap !important;
          color: #111827 !important;
        }

        .print-report-accent {
          width: 100% !important;
          height: 2.2mm !important;
          border-radius: 1mm !important;
          background: linear-gradient(
            90deg,
            #111827 0%,
            #111827 72%,
            #7c3aed 72%,
            #7c3aed 100%
          ) !important;
        }

        /* Avoid extra pages and keep proper page flow */
        .card, .card-body, .card-header { border: none !important; box-shadow: none !important; margin: 0 !important; padding: 0 !important; }
        .container, .container-fluid, .row, .col { break-inside: auto; }

        /* === Table structure & repeating header === */
        .report-table { width: 100% !important; border-collapse: collapse !important; margin: 0 !important; }
        .report-table thead { display: table-header-group; }
        .report-table tfoot { display: table-footer-group; }
        .report-table tr { break-inside: avoid; break-after: auto; }
        table, tr, td, th { orphans: 3; widows: 3; }

        /* Neutralize bootstrap zebra striping in print for a cleaner sheet */
        .report-table.table-striped > tbody > tr > * { background-color: transparent !important; }

        /* Hide interactive UI in print */
        .no-print, .no-print * { display: none !important; }
        .mini-grid, .chip, .filters-card { display: none !important; }

        /* Print filters block */
        .print-filters { margin: 0 0 14px !important; font-size: 9.5px; } /* FIX: was 8px, more breathing room before table */
        .print-filters h6 { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; margin-bottom: 3px; color: #333; }
        .print-filters ul { margin: 2px 0 0 16px; padding: 0; }
        .print-filters li { margin: 1px 0; color: #333; }

        /* === MAIN TABLE HEADER STYLE === */
        table.report-table thead th,
        table.report-table thead tr {
          background: #2b2b2b !important;
          color: #fff !important;
        }
        table.report-table thead th {
          font-weight: 700 !important;
          text-transform: uppercase !important;
          letter-spacing: 0.3px !important;
          border-bottom: 1px solid #000 !important;
          font-size: 9.5px !important;
          padding: 6px 7px !important;
        }

        /* Body cells & borders */
        table.report-table tbody td { border-top: 1px solid #e5e7eb !important; font-size: 9.5px; padding: 5px 7px !important; }
        .text-currency { text-align: right !important; white-space: nowrap !important; }

        /* === Color ONLY the main product rows (those with Product ID) === */
        table.report-table tbody > tr.product-row > td {
          border-top: 1px solid #dfe3e8 !important;
        }

        /* Keep a product row and the start of its variant block together where possible */
        tr.product-row { break-after: avoid; }

        /* Force variant sections open in print */
        .collapse { display: block !important; height: auto !important; visibility: visible !important; }

        /* Hide expand buttons and variant icons on paper (keep bullets) */
        .expander-btn, .expander-spacer, .variant-icon, .variant-count-badge { display: none !important; }
        .variant-name-cell { padding-left: 30px !important; }

        /* FIX: connector tree-lines were overlapping the #variantId text once
           padding shrank to 30px in print — hide them, cleaner on paper anyway */
        .variant-name-cell::before,
        .variant-name-cell::after {
          display: none !important;
        }

        /* Separator before totals */
        .print-hr { border: 0; border-top: 1.4px solid #1a1a1a; margin: 5px 0; }

        /* Do NOT color the variant header in print (neutralize Bootstrap .table-secondary) */
        .variant-table thead th,
        .variant-table thead tr {
          background: #fff !important;
          color: #444 !important;
        }
        .variant-table thead th {
          border-bottom: 1px solid #c9ccd1 !important;
          border-top: none !important;
          font-weight: 700 !important;
          font-size: 8.8px !important;
          text-transform: uppercase;
          letter-spacing: .2px;
          padding: 4px 10px !important;
        }
        .variant-table tbody td {
          font-size: 9px !important;
          padding: 4px 10px !important;
          color: #333;
        }

        /* Each variant row must never split across a page break */ 
        .variant-table tbody tr { break-inside: avoid !important; break-after: auto; }
        .variant-block-row { break-inside: avoid; }

        /* === thin vertical rules for variant table in print === */
        .variant-table tbody tr td:nth-child(2),
        .variant-table tbody tr td:nth-child(3),
        .variant-table tbody tr td:nth-child(4),
        .variant-table tbody tr td:nth-child(5),
        .variant-table tbody tr td:nth-child(6) {
          border: none !important; 
        }
        .variant-table tbody tr td:nth-child(1) { border: none !important; }

        /* === bottom border for last variant row === */
        .variant-table tbody tr:last-child td { border:none !important; }

        /* ===== Professional Print Summary Card ===== */
      .print-summary-box {
        width: 55%;
        margin-top: 6px;
        margin-left: auto !important;
        margin-right: 0 !important;
        border: 1px solid #2b2b2b;
        background: #fff !important;
        font-size: 9.5px;
        break-inside: avoid;
        overflow: hidden;
      }
        .print-summary-head {
          font-weight: 700;
          font-size: 9.5px;
          text-transform: uppercase;
          padding: 5px 10px;
          background: #2b2b2b;
          color: #fff;
          letter-spacing: 0.4px;
        }
        .ps-row { display: grid; grid-template-columns: 1fr 1fr; }
        .ps-row + .ps-row { border-top: 1px solid #e5e7eb; }
        .ps-label, .ps-value { padding: 5px 10px; line-height: 1.4; }
        .ps-label {
          font-weight: 600;
          color: #333;
          background: #f7f8f9;
          border-right: 1px solid #e5e7eb;
        }
        .ps-value { text-align: right; font-weight: 700; color: #111; }
      }

      .category-tree-select-all {
        min-height: 40px;
        display: flex;
        align-items: center;
        gap: 9px;
        padding: 9px 12px;
        cursor: pointer;
        font-weight: 600;
        background: #f8f9fa;
        color: #212529;
        transition: background-color 0.18s ease;
      }

      .category-tree-select-all:hover {
        background: #eef1f4; 
      }

      .category-tree-divider {
        height: 1px;
        background: #e5e7eb;
        margin-bottom: 3px;
      }

      .category-tree-node {
        width: 100%;
      }

      .category-tree-row {
        width: 100%;
        min-height: 38px;
        display: flex;
        align-items: center;
        padding-top: 2px;
        padding-right: 8px;
        padding-bottom: 2px;
        box-sizing: border-box;
        transition:
          background-color 0.16s ease,
          color 0.16s ease;
      }

      .category-tree-row:hover {
        background: #f5f7fa;
      }

      .category-tree-row-selected {
        background: #eef5ff;
      }

      .category-tree-row-selected:hover {
        background: #e6f0ff;
      }

      .category-tree-expand-btn {
        width: 28px;
        height: 32px;
        flex: 0 0 28px;
        padding: 0;
        border: none;
        border-radius: 6px;
        background: transparent;
        color: #5f6368;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition:
          background-color 0.18s ease,
          color 0.18s ease;
      }

      .category-tree-expand-btn:hover:not(:disabled) {
        color: #111827;
        background: #e9ecef;
      }

      .category-tree-expand-btn:disabled {
        cursor: default;
        opacity: 1;
      }

      .category-tree-chevron {
        display: block;
        transition: transform 0.22s ease;
      }

      .category-tree-expand-btn.is-expanded
        .category-tree-chevron {
        transform: rotate(90deg);
      }

      .category-tree-leaf-space {
        display: block;
        width: 18px;
        height: 18px;
      }

      .category-tree-content {
        min-width: 0;
        flex: 1;
        height: 34px;
        padding: 0 6px;
        border: none;
        border-radius: 6px;
        background: transparent;
        color: #212529;
        display: flex;
        align-items: center;
        gap: 9px;
        text-align: left;
        cursor: pointer;
      }

      .category-tree-content:hover {
        color: #111827;
      }

      .category-tree-checkbox {
        flex: 0 0 auto;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .category-tree-label {
        min-width: 0;
        flex: 1;
        display: block;
        color: #212529;
        font-size: 12.5px;
        font-weight: 500;
        line-height: 1.3;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .category-tree-children {
        display: grid;
        grid-template-rows: 0fr;
        opacity: 0;
        transition:
          grid-template-rows 0.24s ease,
          opacity 0.2s ease;
      }

      .category-tree-children.is-expanded {
        grid-template-rows: 1fr;
        opacity: 1;
      }

      .category-tree-children-inner {
        min-height: 0;
        overflow: hidden;
      }

      .category-tree-empty {
        padding: 12px;
        color: #6c757d;
        text-align: center;
      }

    `
    document.head.appendChild(style)
    spinAdded.current = true
  }, [])
  const currencyLabel = currency ? `(${currency})` : ''

  // Structured filter chips — each knows how to clear itself, so users can
  // remove a single filter without reopening the panel. Reused for both the
  // on-screen chip row and the print-only applied-filters list.
  const structuredFilterChips = useMemo(() => {
    const chips = []
    if (dateFrom || dateTo) {
      chips.push({
        id: 'date',
        label: `Date: ${dateFrom || '—'} → ${dateTo || '—'}`,
        onRemove: () => {
          setDateFrom('')
          setDateTo('')
        },
      })
    }
    if (categoryOpts.length) {
      chips.push({
        id: 'categories',
        label: `Categories: ${categoryOpts.map((o) => o.label).join(', ')}`,
        onRemove: () => setCategoryOpts([]),
      })
    }
    if (brandOpts.length) {
      chips.push({
        id: 'brands',
        label: `Brands: ${brandOpts.map((o) => o.label).join(', ')}`,
        onRemove: () => setBrandOpts([]),
      })
    }
    if (collectionOpts.length) {
      chips.push({
        id: 'collections',
        label: `Collections: ${collectionOpts.map((o) => o.label).join(', ')}`,
        onRemove: () => setCollectionOpts([]),
      })
    }
    if (outletOpts.length) {
      chips.push({
        id: 'outlets',
        label: `Warehouses: ${outletOpts.map((o) => o.label).join(', ')}`,
        onRemove: () => setOutletOpts([]),
      })
    }
    if (selectedProducts.length) {
      chips.push({
        id: 'products',
        label: `Products: ${selectedProducts.map((o) => o.label).join(', ')}`,
        onRemove: () => setSelectedProducts([]),
      })
    }
    return chips
  }, [dateFrom, dateTo, categoryOpts, brandOpts, collectionOpts, outletOpts, selectedProducts])

  const hasActiveFilters = structuredFilterChips.length > 0

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-2 report-header" style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
            <div className="report-header-inner">
              {/* LEFT SIDE – TITLE */}
              <CardTitle as="h4" className="mb-0 report-title">
                Product Based Revenue
              </CardTitle>

              {/* RIGHT SIDE – BUTTON */}
              <div className="d-flex gap-2 no-print report-header-actions">
                <Button onClick={handlePrint} disabled={rows.length === 0 || loading} style={{ background: '#7c3aed', borderColor: '#7c3aed' }}>
                  <IconifyIcon icon="mdi:printer" width={18} height={18} /> Print
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardBody className="position-relative">
            {/* PRINT-ONLY title on first page */}
            {/* PRINT-ONLY professional report header */}
            <div className="print-only print-report-header">
              <div className="print-report-header-top">
                <div>
                  <div className="print-report-label">Sales Report</div>
                  <h1 className="print-report-title">Product Based Revenue</h1>
                  <div className="print-report-description">Product sales, invoice quantities, returns and revenue summary</div>
                </div>

                <div className="print-report-meta">
                  <div className="print-meta-item">
                    <span className="print-meta-label">Generated</span>
                    <span className="print-meta-value">
                      {new Date().toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </div>

                  <div className="print-meta-item">
                    <span className="print-meta-label">Products</span>
                    <span className="print-meta-value">{rows.length}</span>
                  </div>
                </div>
              </div>

              <div className="print-report-accent" />
            </div>
            {loading && (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'rgba(255,255,255,.7)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 10,
                  zIndex: 2,
                }}>
                <div
                  style={{
                    width: 28,
                    height: 28,
                    border: '3px solid #e5e7eb',
                    borderTopColor: '#7c3aed',
                    borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite',
                  }}
                />
                <span style={{ fontSize: 12.5, color: '#6c757d', fontWeight: 500 }}>Loading report…</span>
              </div>
            )}

            {/* Filters (won't print) */}
            <div className="mb-3 no-print">
              <div className="filters-card">
                <div className="filters-card-head">
                  <button type="button" className="filters-toggle-btn" aria-expanded={filtersOpen} onClick={() => setFiltersOpen((v) => !v)}>
                    <IconifyIcon icon="mdi:chevron-down" width={18} height={18} className="filters-toggle-icon" />
                    Filters
                    {hasActiveFilters && <span className="variant-count-badge">{structuredFilterChips.length} active</span>}
                  </button>

                  <button type="button" className="filters-clear-btn" onClick={clearAllFilters} disabled={!hasActiveFilters}>
                    Clear all
                  </button>
                </div>

                <Collapse in={filtersOpen}>
                  <div>
                    <div className="sales-filter-grid">
                      {/* FIRST ROW: Product / From / To */}
                      <div className="sales-filter-row sales-filter-row-first">
                        <div className="sales-filter-field">
                          <div className="po-filter-label">Product</div>
                          <Select
                            aria-label="Search products"
                            isMulti
                            closeMenuOnSelect={false}
                            hideSelectedOptions={false}
                            components={{
                              Option: CheckboxOption,
                              MultiValueContainer,
                            }}
                            styles={selectStyles}
                            menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                            value={selectedProducts}
                            onInputChange={(value, actionMeta) => {
                              if (actionMeta.action === 'input-change') {
                                setProductSearch(value)
                              }
                            }}
                            onChange={(options) => {
                              setSelectedProducts(options || [])
                            }}
                            options={productOptions}
                            allRealOptions={productOptions}
                            isLoading={productSearching}
                            placeholder="Search products..."
                            isClearable
                            filterOption={null}
                            noOptionsMessage={() => (productSearch.length < 2 ? 'Type at least 2 characters...' : 'No products found')}
                          />
                        </div>

                        <div className="sales-filter-field">
                          <div className="po-filter-label">From</div>
                          <Form.Control
                            type="date"
                            value={dateFrom}
                            max={dateTo || undefined}
                            onChange={(e) => setDateFrom(e.target.value)}
                            className="form-control form-control-sm"
                          />
                        </div>

                        <div className="sales-filter-field">
                          <div className="po-filter-label">To</div>
                          <Form.Control
                            type="date"
                            value={dateTo}
                            min={dateFrom || undefined}
                            onChange={(e) => setDateTo(e.target.value)}
                            className="form-control form-control-sm"
                          />
                        </div>
                      </div>

                      {/* SECOND ROW: Category / Brand / Collection / Warehouse / Search */}
                      <div className="sales-filter-row sales-filter-row-second">
                        <div className="sales-filter-field">
                          <div className="po-filter-label">Category</div>
                          <Select
                            aria-label="Select categories"
                            isMulti
                            closeMenuOnSelect={false}
                            hideSelectedOptions={false}
                            value={categoryOpts}
                            options={categoryOptions}
                            allRealOptions={categoryOptions}
                            categoryTree={categoryTree}
                            expandedCategoryIds={expandedCategoryIds}
                            toggleCategoryExpanded={toggleCategoryExpanded}
                            toggleCategorySelection={toggleCategorySelection}
                            toggleAllCategories={toggleAllCategories}
                            onChange={(options) => {
                              setCategoryOpts(Array.isArray(options) ? options : [])
                            }}
                            components={{
                              MenuList: CategoryMenuList,
                              MultiValueContainer,
                              Option: () => null,
                            }}
                            styles={selectStyles}
                            menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                            isLoading={catsLoading}
                            placeholder="Select categories..."
                            isClearable
                            isSearchable={false}
                          />
                        </div>
                        <div className="sales-filter-field">
                          <div className="po-filter-label">Brand</div>

                          <Select
                            aria-label="Select brands"
                            {...multiSelectProps}
                            value={brandOpts}
                            options={getOptionsWithSelectAll(brandOptions)}
                            allRealOptions={brandOptions}
                            onChange={(options, actionMeta) =>
                              handleMultiSelectChange({
                                selectedOptions: options,
                                actionMeta,
                                allOptions: brandOptions,
                                currentValues: brandOpts,
                                setValues: setBrandOpts,
                              })
                            }
                            placeholder="Select brands..."
                            isClearable
                          />
                        </div>

                        <div className="sales-filter-field">
                          <div className="po-filter-label">Collection</div>
                          <Select
                            aria-label="Select collections"
                            {...multiSelectProps}
                            value={collectionOpts}
                            options={getOptionsWithSelectAll(collectionOptions)}
                            allRealOptions={collectionOptions}
                            onChange={(options, actionMeta) =>
                              handleMultiSelectChange({
                                selectedOptions: options,
                                actionMeta,
                                allOptions: collectionOptions,
                                currentValues: collectionOpts,
                                setValues: setCollectionOpts,
                              })
                            }
                            placeholder="Select collections..."
                            isClearable
                          />
                        </div>

                        <div className="sales-filter-field">
                          <div className="po-filter-label">Warehouse (Outlet)</div>
                          <Select
                            aria-label="Select warehouses"
                            {...multiSelectProps}
                            value={outletOpts}
                            options={getOptionsWithSelectAll(outletOptions)}
                            allRealOptions={outletOptions}
                            onChange={(options, actionMeta) =>
                              handleMultiSelectChange({
                                selectedOptions: options,
                                actionMeta,
                                allOptions: outletOptions,
                                currentValues: outletOpts,
                                setValues: setOutletOpts,
                              })
                            }
                            isLoading={outletsLoading}
                            placeholder="Select warehouses..."
                            isClearable
                          />
                        </div>

                        <div className="sales-filter-search">
                          <Button
                            className="btn btn-dark btn-sm w-100 d-flex align-items-center justify-content-center gap-2"
                            onClick={handleSearch}
                            disabled={loading}>
                            {loading ? (
                              <>
                                <span
                                  style={{
                                    width: 14,
                                    height: 14,
                                    border: '2px solid rgba(255,255,255,.35)',
                                    borderTopColor: '#fff',
                                    borderRadius: '50%',
                                    display: 'inline-block',
                                    animation: 'spin 0.7s linear infinite',
                                  }}
                                />
                                Searching…
                              </>
                            ) : (
                              <>
                                <IconifyIcon icon="mdi:magnify" width={16} height={16} />
                                Search
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Active filter chips (screen only — print gets its own list below) */}
                    {hasActiveFilters && (
                      <div className="filter-chip-row mt-3">
                        {structuredFilterChips.map((chip) => (
                          <span className="chip" key={chip.id}>
                            <span className="chip-text">{chip.label}</span>
                            <button type="button" className="chip-remove" onClick={chip.onRemove} aria-label={`Remove filter: ${chip.label}`}>
                              <IconifyIcon icon="mdi:close" width={12} height={12} />
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </Collapse>
              </div>
            </div>

            {errorMsg && (
              <div className="report-error-banner" role="alert">
                <IconifyIcon icon="mdi:alert-circle-outline" width={18} height={18} />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* PRINT-ONLY: Applied Filters */}
            <div className="print-filters print-only">
              <h6>Applied Filters</h6>
              <ul>{structuredFilterChips.length > 0 ? structuredFilterChips.map((c) => <li key={c.id}>{c.label}</li>) : <li>None (all data)</li>}</ul>
            </div>

            {/* Insights (hidden in print) */}
            <div className="mb-2 no-print">
              <div className="d-flex align-items-center flex-wrap gap-1 mt-2 mb-1">
                <h5 className="fw-bold mb-0">Insights</h5>
              </div>
              <hr style={{ margin: '0.5rem 0.1rem 1rem 0.1rem' }} />
              <Row>
                <div className="mini-grid">
                  <MiniStat
                    title="Total Ordered Quantity"
                    stat={summary.total_ordered_qty}
                    subTitle="Total no. of products included in all orders from Web, Admin transactions"
                    icon="mdi:cart-outline"
                  />

                  <MiniStat
                    title="Total Invoice Quantity"
                    stat={summary.total_sales_qty}
                    subTitle="Total units sold via Web, Admin & POS Transactions (Orders+Invoices)"
                    icon="mdi:cash-register"
                  />

                  <MiniStat
                    title="Total Return Quantity"
                    stat={summary.total_returned_qty}
                    subTitle="Total units returned from Web, Admin & Invoice transactions"
                    icon="mdi:alert-octagon-outline"
                  />

                  <MiniStat
                    title={`Total Invoice Amount ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_sales_amount)}
                    subTitle="Total sales revenue from Web, Admin & Invoice transactions (Orders+Invoices)"
                    icon="mdi:currency-usd"
                  />
                  <MiniStat
                    title={`Total Base Amount ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_base_amount)}
                    subTitle="Combined order and invoice base amount before discounts, taxes, service charges and other additions"
                    icon="mdi:tag-outline"
                  />

                  <MiniStat
                    title={`Total Service Charge ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_service_charge_amount)}
                    subTitle="Total service charges allocated to the Invoices matching the selected filters"
                    icon="mdi:room-service-outline"
                  />

                  <MiniStat
                    title={`Total Discounts ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_discount_amount)}
                    subTitle="Total Order-level and Invoice-level discounts for the selected filters"
                    icon="mdi:ticket-percent-outline"
                  />

                  <MiniStat
                    title={`Total Tax ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_tax_amount)}
                    subTitle="Total tax amount allocated to the Invoices+Orders matching the selected filters"
                    icon="mdi:receipt-text-outline"
                  />

                  <MiniStat
                    title={`Total Delivery Charge ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_delivery_charge_amount)}
                    subTitle="Total delivery charges allocated to the products matching the selected filters"
                    icon="mdi:truck-delivery-outline"
                  />

                  <MiniStat
                    title={`Total Additional Amount ${currencyLabel}`}
                    stat={formatCurrencyLKR(summary.total_additional_amount)}
                    subTitle="Combined service charge, delivery charge and tax for the selected filters"
                    icon="mdi:cash-plus"
                  />
                </div>
              </Row>
            </div>

            {/* Main table */}
            <div className="table-responsive">
              <Table striped className="table report-table mb-0">
                <ReportColGroup />
                <thead className="table-light">
                  <tr>
                    <th className="th-left">ID</th>
                    <th className="th-left">Product / Variant</th>
                    <th>Ordered</th>
                    <th>Invoice</th>
                    <th>Returned</th>
                    <th>
                      <AmountHeader
                        label="Base Amount"
                        currencyLabel={currencyLabel}
                        tooltip="Quantity × unit price before item discounts, invoice discounts, taxes, service charges and other additions."
                      />
                    </th>

                    <th>
                      <AmountHeader
                        label="Invoice Amount"
                        currencyLabel={currencyLabel}
                        tooltip="Final product revenue calculated from the invoice amount. It may include allocated discounts, taxes, service charges or other invoice-level adjustments, and returns are deducted."
                      />
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.length === 0 && !loading && (
                    <tr>
                      <td colSpan={7} style={{ padding: 0 }}>
                        <div className="report-empty-state">
                          <IconifyIcon icon="mdi:file-search-outline" className="report-empty-icon" />
                          <div className="report-empty-title">No results found</div>
                          <div>Try adjusting or clearing your filters and search again.</div>
                        </div>
                      </td>
                    </tr>
                  )}

                  {rows.map((p) => (
                    <ProductRow key={p.id} p={p} />
                  ))}

                  {/* PRINT-ONLY: Separator */}
                  {rows.length > 0 && (
                    <tr className="print-only">
                      <td colSpan={7} style={{ padding: 0 }}>
                        <hr className="print-hr" />
                      </td>
                    </tr>
                  )}

                  {/* PRINT-ONLY: Summary card (left half, professional look) */}
                  {rows.length > 0 && (
                    <tr className="print-only">
                      <td colSpan={7} style={{ paddingTop: 6 }}>
                        <div className="print-summary-box" aria-label="Report totals summary">
                          <div className="print-summary-head">Summary</div>

                          <div className="ps-row">
                            <div className="ps-label">Ordered</div>
                            <div className="ps-value">{summary.total_ordered_qty}</div>
                          </div>

                          <div className="ps-row">
                            <div className="ps-label">Invoice</div>
                            <div className="ps-value">{summary.total_sales_qty}</div>
                          </div>

                          <div className="ps-row">
                            <div className="ps-label">Returned</div>
                            <div className="ps-value">{summary.total_returned_qty}</div>
                          </div>

                          <div className="ps-row">
                            <div className="ps-label">Base Amount {currencyLabel}</div>

                            <div className="ps-value">{formatCurrencyLKR(summary.total_base_amount)}</div>
                          </div>

                          <div className="ps-row">
                            <div className="ps-label">Invoice Amount {currencyLabel}</div>

                            <div className="ps-value">{formatCurrencyLKR(summary.total_sales_amount)}</div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>

            {/* NOTE: page numbers removed per request */}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

/* MiniStat component kept unchanged from your previous version */
function MiniStat({ icon, title, stat, subTitle }) {
  return (
    <div className="mini-stat">
      <div className="mini-stat-inner">
        <div className="mini-text w-100">
          <div className="d-flex justify-content-between align-items-start">
            <div className="mini-title">{title}</div>
            <div className="mini-icon-wrap ms-2">
              <IconifyIcon icon={icon} className="mini-icon" />
            </div>
          </div>
          <div className="mini-value">{stat}</div>
          <hr className="mini-divider" />
          <div className="mini-sub">{subTitle}</div>
        </div>
      </div>
    </div>
  )
}
