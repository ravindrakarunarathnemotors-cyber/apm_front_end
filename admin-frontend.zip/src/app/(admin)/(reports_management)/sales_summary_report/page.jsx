import React from 'react'
import TotalSalesSummary from '@/components/pos/Report/TotalSalesSummary'

const Summarypage = () => {
  return (
    <div>
        <TotalSalesSummary />
    </div>
  )
}

export default Summarypage