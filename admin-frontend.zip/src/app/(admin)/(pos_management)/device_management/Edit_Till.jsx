'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Form, Button, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useUpdatePosDeviceManagementMutation, useGetActivePosDevicesByTypeQuery } from '@/store/features/apiSlice'

export default function EditTill({ device, onBack }) {
  const [createType, setCreateType] = useState('')
  const [formData, setFormData] = useState({
    till_name: '',
    display_id: '',
    device_model: '',
    enable_customer_input: false,
  })
  const [originalData, setOriginalData] = useState(null)

  /* ================= API ================= */
  const [updateDevice, { isLoading }] = useUpdatePosDeviceManagementMutation()

  const { data: activeDevices, isLoading: isLoadingDevices } = useGetActivePosDevicesByTypeQuery()

  /* ================= PREFILL ================= */
  useEffect(() => {
    if (!device) return

    const detectedType = device.__deviceType || device.type

    const snapshot = {
      till_name: device.till_name || '',
      display_id: Array.isArray(device.display_id) ? device.display_id[0] || '' : '',
      device_model: device.device_model || '',
      enable_customer_input: !!device.enable_customer_input,
    }

    setCreateType(detectedType)
    setFormData(snapshot)
    setOriginalData(snapshot)
  }, [device])

  /* ================= CHANGE ================= */
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleToggleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      enable_customer_input: e.target.checked,
    }))
  }

  /* ================= DIFF CHECK (UI ONLY) ================= */
  const hasChanges = useMemo(() => {
    if (!originalData) return false
    return Object.keys(originalData).some((k) => originalData[k] !== formData[k])
  }, [formData, originalData])

  /* ================= SUBMIT ================= */
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!hasChanges) return

    const changesHtml = Object.keys(formData)
      .filter((k) => formData[k] !== originalData[k])
      .map((k) => `<b>${k.replaceAll('_', ' ')}</b>: ${originalData[k] ?? '-'} → ${formData[k]}`)
      .join('<br/>')

    const confirm = await Swal.fire({
      title: 'Confirm Update',
      html: changesHtml,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Update',
    })

    if (!confirm.isConfirmed) return

    /* ===== BUILD FULL PAYLOAD (NO DIFF) ===== */
    const payload = {
      till_name: formData.till_name,
      device_model: formData.device_model,
      display_id: formData.display_id ? [formData.display_id] : [],
      enable_customer_input: createType === 'display' ? formData.enable_customer_input : null,
    }

    try {
      await updateDevice({
        device_id: device.device_id,
        payload,
      }).unwrap()

      await Swal.fire('Updated!', 'Device updated successfully.', 'success')

      onBack()
    } catch (error) {
      console.error('Update failed:', error)
      Swal.fire('Error', 'Failed to update device.', 'error')
    }
  }

  if (!device) return null

  /* ================= OPTIONS ================= */
  const relatedOptions = createType === 'display' ? activeDevices?.data?.till || [] : activeDevices?.data?.display || []

  /* ================= RENDER ================= */
  return (
    <Card>
      <CardHeader className="bg-light">
        <Row className="align-items-center">
          <Col>
            <CardTitle as="h4" className="mb-0">
              {createType === 'display' ? 'Edit Display' : 'Edit Till'}
            </CardTitle>
            <small className="text-muted">Device & POS Configuration</small>
          </Col>
          <Col xs="auto">
            <Button variant="outline-secondary" onClick={onBack} disabled={isLoading}>
              ← Back
            </Button>
          </Col>
        </Row>
      </CardHeader>

      <CardBody>
        <Form onSubmit={handleSubmit}>
          {/* TYPE + RELATED */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Type</Form.Label>
              <Form.Select value={createType} disabled>
                <option value="display">Display</option>
                <option value="till">Till</option>
              </Form.Select>
            </Col>

            <Col md={6}>
              <Form.Label>{createType === 'display' ? 'Linked Till' : 'Linked Display'}</Form.Label>
              <Form.Select name="display_id" value={formData.display_id} onChange={handleChange} disabled={isLoading || isLoadingDevices}>
                <option value="">Select</option>
                {relatedOptions.map((d) => (
                  <option key={d.device_id} value={d.device_id}>
                    {d.till_name} (ID: {d.device_id})
                  </option>
                ))}
              </Form.Select>
            </Col>
          </Row>

          {/* NAME + MODEL */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>{createType === 'display' ? 'Display Name' : 'Till Name'}</Form.Label>
              <Form.Control name="till_name" value={formData.till_name} onChange={handleChange} required disabled={isLoading} />
            </Col>

            <Col md={6}>
              <Form.Label>Device Model</Form.Label>
              <Form.Control name="device_model" value={formData.device_model} onChange={handleChange} required disabled={isLoading} />
            </Col>
          </Row>

          {/* DISPLAY ONLY : CUSTOMER INPUT */}
          {createType === 'display' && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Customer Input</Form.Label>
                  <div className="d-flex align-items-center gap-3">
                    <Form.Check
                      type="switch"
                      id="enable-customer-input"
                      checked={formData.enable_customer_input}
                      onChange={handleToggleChange}
                      disabled={isLoading}
                    />
                    <small className="text-muted">{formData.enable_customer_input ? 'Enabled' : 'Disabled'}</small>
                  </div>
                </Form.Group>
              </Col>
            </Row>
          )}

          {/* ACTION */}
          <div className="d-flex justify-content-end">
            <Button type="submit" className="bg-primary border-primary" disabled={!hasChanges || isLoading}>
              {isLoading ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  Updating...
                </>
              ) : (
                'Update'
              )}
            </Button>
          </div>
        </Form>
      </CardBody>
    </Card>
  )
}
