'use client'

import { useState } from 'react'
import { Tabs, Tab, Card, CardBody, CardHeader, CardTitle, Col, Row, Button } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import CreateTill from './Create_Till'
import EditTill from './Edit_Till'
import DeviceManagement from './DeviceManagement'
import CardTerminal from './CardTerminal'
import KotDevices from './KotDevices'

export default function DeviceTabs() {
  const [activeTab, setActiveTab] = useState('pos')
  const [showCreateTill, setShowCreateTill] = useState(false)

  return (
    <Card>
      {showCreateTill ? (
        // Render the CreateTill component when the button is clicked
        <CreateTill onBack={() => setShowCreateTill(false)} />
      ) : (
        <>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Device Management
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Button
                  className="bg-primary border-primary"
                  onClick={() => setShowCreateTill(true)}
                >
                  <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                  Create New
                </Button>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Tabs
              activeKey={activeTab}
              onSelect={(k) => setActiveTab(k)}
              className="mb-3"
            >
              <Tab eventKey="pos" title="POS Devices">
                <DeviceManagement />
              </Tab>
              <Tab eventKey="card" title="Card Terminals">
                <CardTerminal />
              </Tab>
               <Tab eventKey="KOT" title="KOT Displays & Printers">
                <KotDevices />
              </Tab>
            </Tabs>
          </CardBody>
        </>
      )}
    </Card>
  )
}