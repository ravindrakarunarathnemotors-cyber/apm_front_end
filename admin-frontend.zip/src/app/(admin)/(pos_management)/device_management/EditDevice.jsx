'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Form, Button, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'
import {
  useUpdatePosDeviceManagementMutation,
  useGetActivePosDevicesByTypeQuery
} from '@/store/features/apiSlice'

export default function EditDevice({ device, onBack }) {
  const [createType, setCreateType] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    related_id: '',
    device_model: '',
    enable_customer_input: false,
  })

  const [originalData, setOriginalData] = useState(null)

  /* ================= API ================= */
  const [updateDevice, { isLoading }] = useUpdatePosDeviceManagementMutation()
  const { data: activeDevices } = useGetActivePosDevicesByTypeQuery()

  const activeTills = activeDevices?.data?.till || []
  const activeDisplays = activeDevices?.data?.display || []
  const activeKotDisplays = activeDevices?.data?.kot_display || []
  const activeKotPrinters = activeDevices?.data?.kot_printer || []

  /* ================= PREFILL ================= */
  useEffect(() => {
    if (!device) return

    const detectedType = device.__deviceType || device.type

    const snapshot = {
      name: device.till_name || '',
      related_id: Array.isArray(device.display_id)
        ? device.display_id[0] || ''
        : '',
      device_model: device.device_model || '',
      enable_customer_input: !!device.enable_customer_input,
    }

    setCreateType(detectedType)
    setFormData(snapshot)
    setOriginalData(snapshot)
  }, [device])

  /* ================= HANDLERS ================= */
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleToggleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      enable_customer_input: e.target.checked,
    }))
  }

  /* ================= CHANGE DETECT ================= */
  const hasChanges = useMemo(() => {
    if (!originalData) return false
    return Object.keys(originalData).some((k) => originalData[k] !== formData[k])
  }, [formData, originalData])

  /* ================= SUBMIT ================= */
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!hasChanges) return

    const payload = {
      till_name: formData.name,
      display_id: formData.related_id
        ? [Number(formData.related_id)]
        : [],
      device_model: formData.device_model,
      enable_customer_input:
        createType === 'display'
          ? formData.enable_customer_input
          : undefined,
    }

    const result = await Swal.fire({
      title: 'Confirm Update',
      html: `
        <div style="text-align:left">
          <strong>Type:</strong> ${createType}<br/>
          <strong>Name:</strong> ${payload.till_name}<br/>
          <strong>Linked Device ID:</strong> ${payload.display_id.join(', ') || '-'}<br/>
          <strong>Device Model:</strong> ${payload.device_model}<br/>
          ${createType === 'display'
            ? `<strong>Customer Input:</strong> ${formData.enable_customer_input ? 'Enabled' : 'Disabled'}`
            : ''
          }
        </div>
      `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Update',
    })

    if (!result.isConfirmed) return

    try {
      await updateDevice({
        device_id: device.device_id,
        payload,
      }).unwrap()

      await Swal.fire('Updated!', 'Device updated successfully.', 'success')
      onBack()
    } catch (error) {
      console.error(error)
      Swal.fire('Error', 'Failed to update device.', 'error')
    }
  }

  if (!device) return null

  /* ================= RELATED OPTIONS ================= */
  const relatedOptions =
    createType === 'display'
      ? activeTills
      : createType === 'till'
        ? activeDisplays
        : createType === 'kot_display'
          ? activeKotPrinters
          : activeKotDisplays

  /* ================= HEADER ================= */
  const headerTitle =
    createType === 'display'
      ? 'Edit Display'
      : createType === 'till'
        ? 'Edit Till'
        : createType === 'kot_display'
          ? 'Edit KOT Display'
          : 'Edit KOT Printer'

  return (
    <Card>
      <CardHeader className="bg-light">
        <Row className="align-items-center">
          <Col>
            <CardTitle as="h4" className="mb-0">{headerTitle}</CardTitle>
            <small className="text-muted">Device & POS Configuration</small>
          </Col>
          <Col xs="auto">
            <Button variant="outline-secondary" onClick={onBack} disabled={isLoading}>
              ← Back
            </Button>
          </Col>
        </Row>
      </CardHeader>

      <CardBody>
        <Form onSubmit={handleSubmit}>
          {/* TYPE + RELATED */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Type</Form.Label>
              <Form.Select value={createType} disabled>
                <option value="display">Display</option>
                <option value="till">Till</option>
                <option value="kot_display">KOT Display</option>
                <option value="kot_printer">KOT Printer</option>
              </Form.Select>
            </Col>

            <Col md={6}>
              <Form.Label>
                {createType === 'display'
                  ? 'Select Till'
                  : createType === 'till'
                    ? 'Select Display'
                    : createType === 'kot_display'
                      ? 'Select KOT Printer'
                      : 'Select KOT Display'}
              </Form.Label>

              <Form.Select
                name="related_id"
                value={formData.related_id}
                onChange={handleChange}
                disabled={isLoading}
              >
                <option value="">Select</option>

                {relatedOptions.map((item) => (
                  <option key={item.device_id} value={item.device_id}>
                    {item.till_name} (ID: {item.device_id})
                  </option>
                ))}
              </Form.Select>
            </Col>
          </Row>

          {/* NAME + MODEL */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>
                {createType === 'display'
                  ? 'Display Name'
                  : createType === 'till'
                    ? 'Till Name'
                    : createType === 'kot_display'
                      ? 'KOT Display Name'
                      : 'KOT Printer Name'}
              </Form.Label>

              <Form.Control
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                disabled={isLoading}
              />
            </Col>

            <Col md={6}>
              <Form.Label>Device Model</Form.Label>
              <Form.Control
                name="device_model"
                value={formData.device_model}
                onChange={handleChange}
                required
                disabled={isLoading}
              />
            </Col>
          </Row>

          {/* DISPLAY ONLY */}
          {createType === 'display' && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Label>Customer Input</Form.Label>
                <div className="d-flex align-items-center gap-3">
                  <Form.Check
                    type="switch"
                    checked={formData.enable_customer_input}
                    onChange={handleToggleChange}
                    disabled={isLoading}
                  />
                  <small>{formData.enable_customer_input ? 'Enabled' : 'Disabled'}</small>
                </div>
              </Col>
            </Row>
          )}

          {/* ACTION */}
          <div className="d-flex justify-content-end">
            <Button type="submit" disabled={!hasChanges || isLoading}>
              {isLoading ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  Updating...
                </>
              ) : (
                'Update'
              )}
            </Button>
          </div>
        </Form>
      </CardBody>
    </Card>
  )
}