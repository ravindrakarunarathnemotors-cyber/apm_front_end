'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Button, Form, Spinner, ProgressBar, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import axios from 'axios'

// RTK hooks
import { useAddBannerFilesMutation, useGetDisplayBannerFilesQuery } from '@/store/features/apiSlice'

const MAX_FILES = 50
const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL

export default function BannerModal({ show, onHide, device }) {
  const [files, setFiles] = useState([])
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)

  const [preparing, setPreparing] = useState(false)
  const [prepareProgress, setPrepareProgress] = useState(0)

  const [dragActive, setDragActive] = useState(false)
  const [removingIndex, setRemovingIndex] = useState(null)

  // RTK
  const [addBannerFiles] = useAddBannerFilesMutation()
  const { data: bannerResponse, isFetching } = useGetDisplayBannerFilesQuery(device?.device_id, {
    skip: !show || !device?.device_id,
  })


  /* ================= PREFILL FROM BACKEND ================= */

  useEffect(() => {
    if (!show || !bannerResponse?.data?.banner_files) {
      setFiles([])
      return
    }

    const existingFiles = bannerResponse.data.banner_files.map((url) => ({
      name: url.split('/').pop(),
      url,
      isExisting: true,
      type: url.endsWith('.mp4') ? 'video/mp4' : 'image/jpeg',
    }))

    setFiles(existingFiles)
  }, [show, bannerResponse])

  if (!device) return null


  /* ================= FILE VALIDATION ================= */

  const allowedMimeTypes = ['image/png', 'image/jpeg', 'video/mp4']
  const allowedExtensions = ['jpg', 'jpeg', 'png', 'mp4']

  const isValidFile = (file) => {
    const ext = file.name.split('.').pop().toLowerCase()
    return allowedMimeTypes.includes(file.type) || allowedExtensions.includes(ext)
  }

  /* ================= FILE PREP ================= */

  const prepareFilesWithProgress = async (newFiles) => {
    setPreparing(true)
    setPrepareProgress(0)

    for (let i = 0; i <= 100; i += 10) {
      await new Promise((r) => setTimeout(r, 60))
      setPrepareProgress(i)
    }

    setFiles((prev) => [...prev, ...newFiles])
    setPreparing(false)
    setPrepareProgress(0)
  }

  const handleFiles = async (selectedFiles) => {
    const incoming = Array.from(selectedFiles)
    const valid = incoming.filter(isValidFile)

    if (!valid.length) {
      Swal.fire('Invalid files', 'Only JPG, JPEG, PNG images and MP4 videos are allowed.', 'warning')
      return
    }

    if (files.length + valid.length > MAX_FILES) {
      Swal.fire('Limit exceeded', `You can upload a maximum of ${MAX_FILES} media files.`, 'warning')
      return
    }

    await prepareFilesWithProgress(valid)
  }

  /* ================= INPUT ================= */

  const handleInputChange = async (e) => {
    if (preparing || uploading) return
    await handleFiles(e.target.files)
  }

  /* ================= DRAG & DROP ================= */

  const handleDragOver = (e) => {
    e.preventDefault()
    setDragActive(true)
  }

  const handleDragLeave = () => setDragActive(false)

  const handleDrop = async (e) => {
    e.preventDefault()
    setDragActive(false)
    if (preparing || uploading) return
    await handleFiles(e.dataTransfer.files)
  }

  /* ================= REMOVE ================= */

  const removeFile = (index) => {
    setRemovingIndex(index)
    setTimeout(() => {
      setFiles((prev) => prev.filter((_, i) => i !== index))
      setRemovingIndex(null)
    }, 200)
  }

  /* ================= REAL UPLOAD ================= */

  const handleUpload = async () => {
    const newFiles = files.filter((f) => !f.isExisting)
    const existingUrls = files.filter((f) => f.isExisting).map((f) => f.url)

    if (!files.length) {
      Swal.fire('No media selected', 'Please add at least one banner media.', 'warning')
      return
    }

    try {
      setUploading(true)
      setProgress(0)

      let uploadedUrls = []

      if (newFiles.length) {
        const formData = new FormData()
        newFiles.forEach((file) => formData.append('files', file))
        formData.append('device_id', device.device_id)

        const res = await axios.post(`${API_BASE_URL}/pos-sub/upload-device-banners`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          onUploadProgress: (e) => {
            const percent = Math.round((e.loaded * 100) / e.total)
            setProgress(percent)
          },
        })

        uploadedUrls = (res.data?.data || []).map((i) => i.url)
      }

      await addBannerFiles({
        device_id: device.device_id,
        files: [...existingUrls, ...uploadedUrls],
      }).unwrap()

      Swal.fire('Saved!', 'Banner files updated successfully.', 'success')
      setFiles([])
      onHide()
    } catch (error) {
      console.error('Upload failed:', error)
      Swal.fire('Upload Failed', error?.response?.data?.message || error?.data?.message || 'Something went wrong while uploading.', 'error')
    } finally {
      setUploading(false)
    }
  }

  /* ================= RENDER ================= */

  return (
    <Modal show={show} onHide={onHide} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          Banner Manager
          <div className="text-muted fs-6 mt-1">
            {device.till_name} • ID: {device.device_id}
          </div>
        </Modal.Title>
      </Modal.Header>

      <Modal.Body style={{ minHeight: 300 }}>
        {/* LOADING EXISTING */}
        {isFetching && (
          <div className="text-center py-4">
            <Spinner animation="border" />
          </div>
        )}

        {/* DROP ZONE */}
        {!isFetching && (
          <div
            className={`d-flex flex-column align-items-center justify-content-center mb-3 ${dragActive ? 'bg-light' : ''}`}
            style={{
              height: 150,
              border: '2px dashed #adb5bd',
              borderRadius: 10,
              cursor: preparing || uploading ? 'not-allowed' : 'pointer',
              opacity: preparing ? 0.6 : 1,
            }}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => !preparing && !uploading && document.getElementById('banner-file-input').click()}>
            <IconifyIcon icon="mdi:cloud-upload-outline" style={{ fontSize: 54 }} className="text-primary mb-2" />
            <div className="fw-semibold">Drag & drop media here</div>
            <small className="text-muted">JPG, JPEG, PNG, MP4 • Max {MAX_FILES} files</small>

            <Form.Control
              id="banner-file-input"
              type="file"
              accept=".jpg,.jpeg,.png,.mp4"
              multiple
              hidden
              disabled={preparing || uploading}
              onChange={handleInputChange}
            />
          </div>
        )}

        {/* GALLERY */}
        {files.length > 0 && (
          <Row className="g-3">
            {files.map((file, index) => (
              <Col key={index} xs={6} md={4} lg={3}>
                <div
                  style={{
                    width: '100%',
                    height: 120,
                    border: '1px solid #dee2e6',
                    borderRadius: 6,
                    overflow: 'hidden',
                    background: '#f8f9fa',
                    position: 'relative',
                  }}>
                  {file.isExisting ? (
                    <img
                      src={file.url}
                      alt=""
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                    />
                  ) : (
                    <img
                      src={URL.createObjectURL(file)}
                      alt={file.name}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                      }}
                    />
                  )}

                  <IconifyIcon
                    icon="mdi:close-circle"
                    className="text-danger position-absolute"
                    style={{
                      top: 6,
                      right: 6,
                      fontSize: 20,
                      cursor: 'pointer',
                    }}
                    onClick={() => removeFile(index)}
                  />
                </div>
              </Col>
            ))}
          </Row>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="outline-secondary" onClick={onHide} disabled={uploading || preparing}>
          Cancel
        </Button>

        <Button variant="primary" onClick={handleUpload} disabled={uploading || preparing}>
          {uploading ? (
            <>
              <Spinner size="sm" className="me-2" />
              Uploading…
            </>
          ) : (
            'Save'
          )}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}
