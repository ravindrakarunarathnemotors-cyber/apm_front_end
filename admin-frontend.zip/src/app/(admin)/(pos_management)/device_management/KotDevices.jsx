'use client'

import React, { useState } from 'react'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Row, Badge, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import { useGetPosDevicesGroupedByTypeQuery, useUpdatePosDeviceStatusMutation } from '@/store/features/apiSlice'
import EditTill from './EditDevice'
export default function KotDeviceManagement() {
  const [hoveredId, setHoveredId] = useState(null)
  const [updatingId, setUpdatingId] = useState(null)

  const { data, isLoading, isError } = useGetPosDevicesGroupedByTypeQuery()
  const [updateDeviceStatus] = useUpdatePosDeviceStatusMutation()

  const kotDisplays = data?.data?.kot_display || []
  const kotPrinters = data?.data?.kot_printer || []
  const [showEditTill, setShowEditTill] = useState(false)
  const [selectedDevice, setSelectedDevice] = useState(null)
  const openEdit = (device, type) => {
  setSelectedDevice({ ...device, __deviceType: type })
  setShowEditTill(true)
}

  const toggleStatus = async (device) => {
    const nextStatus = device.status === 'Active' ? 'Inactive' : 'Active'

    const result = await Swal.fire({
      title: `${nextStatus} Device?`,
      text: `This will set "${device.till_name}" to ${nextStatus}.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${nextStatus}`,
    })

    if (!result.isConfirmed) return

    try {
      setUpdatingId(device.device_id)
      await updateDeviceStatus({
        device_id: device.device_id,
        status: nextStatus,
      }).unwrap()

      Swal.fire('Updated!', `Device is now ${nextStatus}.`, 'success')
    } catch (error) {
      console.error('Status update failed:', error)
      Swal.fire('Error', 'Failed to update device status.', 'error')
    } finally {
      setUpdatingId(null)
    }
  }

  const cardBaseStyle = {
    transition: 'transform 0.15s ease, box-shadow 0.15s ease',
  }

  const cardHoverStyle = {
    transform: 'translateY(-4px)',
    boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
  }

  const renderDeviceCard = (device, isDisplay) => (
    <Col key={device.device_id} xs={12} sm={6} md={4} lg={3}>
      <Card
        className="h-100 position-relative"
        style={{
          ...cardBaseStyle,
          ...(hoveredId === device.device_id ? cardHoverStyle : {}),
        }}
        onMouseEnter={() => setHoveredId(device.device_id)}
        onMouseLeave={() => setHoveredId(null)}
      >
        <CardHeader className="p-2 bg-light">
          <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-1">
            <Badge bg="dark">ID · {device.device_id}</Badge>
            <span className="fw-bold mb-0">{device.till_name}</span>
          </CardTitle>
        </CardHeader>

        <CardBody className="text-start p-2">
          <div className="d-flex gap-2">
            <IconifyIcon
              icon={isDisplay ? 'mdi:monitor' : 'mdi:printer'}
              style={{ fontSize: 50 }}
              className={`mb-2 shadow-sm p-1 ${isDisplay ? 'text-success' : 'text-primary'}`}
            />

            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Model - {device.device_model}</div>

              <div
                role="button"
                onClick={() => toggleStatus(device)}
                className="d-inline-flex align-items-center gap-1 mt-1"
                style={{
                  fontSize: 13,
                  cursor: 'pointer',
                  opacity: updatingId === device.device_id ? 0.6 : 1,
                  pointerEvents: updatingId === device.device_id ? 'none' : 'auto',
                  color: device.status === 'Active' ? 'green' : 'red',
                }}
              >
                <span>Status</span>
                <IconifyIcon
                  icon={device.status === 'Active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                  style={{ fontSize: 26 }}
                />
              </div>


            </div>
          </div>
          <Col xs={isDisplay ? 6 : 12} className="m-0">
            <Button
              size="sm"
              variant="outline-primary"
              className="w-100"
             onClick={() => openEdit(device, isDisplay ? 'kot_display' : 'kot_printer')}
              disabled={updatingId === device.device_id}>
              <IconifyIcon icon="mdi:cog-outline" className="me-1" />
              Config
            </Button>
          </Col>
        </CardBody>
      </Card>
    </Col>
  )

  return (
    <div>
      {showEditTill ? (
        <EditTill
          device={selectedDevice}
          onBack={() => setShowEditTill(false)}
        />
      ) : (
        <>
          <Card className="mb-4">
            <CardHeader className="bg-light">
              <CardTitle as="h4" className="mb-0">KOT Displays</CardTitle>
              <small className="text-muted">Manage all KOT displays</small>
            </CardHeader>
            <CardBody>
              {isLoading ? (
                <div className="text-center py-5"><Spinner /></div>
              ) : kotDisplays.length === 0 ? (
                <div className="text-center text-muted">No KOT displays found.</div>
              ) : (
                <Row className="gy-4">
                  {kotDisplays.map((d) => renderDeviceCard(d, true))}
                </Row>
              )}
            </CardBody>
          </Card>

          <Card>
            <CardHeader className="bg-light">
              <CardTitle as="h4" className="mb-0">KOT Printers</CardTitle>
              <small className="text-muted">Manage all KOT printers</small>
            </CardHeader>
            <CardBody>
              {isLoading ? (
                <div className="text-center py-5"><Spinner /></div>
              ) : kotPrinters.length === 0 ? (
                <div className="text-center text-muted">No KOT printers found.</div>
              ) : (
                <Row className="gy-4">
                  {kotPrinters.map((d) => renderDeviceCard(d, false))}
                </Row>
              )}
            </CardBody>
          </Card>
        </>
      )}
    </div>
  )
}