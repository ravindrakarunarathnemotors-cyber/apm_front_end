import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Device management',
}

const DeviceTabs = dynamic(() => import('./DeviceTabs'), { ssr: false })

export default function DeviceManagementPage() {
  return <DeviceTabs />
}