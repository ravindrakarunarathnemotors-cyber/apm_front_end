'use client'

import React, { useState } from 'react'
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Form, Button, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useCreatePosDeviceManagementMutation, useGetActivePosDevicesByTypeQuery, useCreateCardTerminalMutation, useGetActiveOutletsQuery, useGetActiveBankAccountsQuery } from '@/store/features/apiSlice'

export default function CreateTill({ onBack }) {
  const [createType, setCreateType] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    related_id: '',
    device_model: '',
    enable_customer_input: false, // ✅ NEW

    mac_address: '',
    ip: '',
    account_name: '',
    account_id: '',
    status: '',
    outlet_id: '',
  })

  /* ================= FETCH ACTIVE DEVICES ================= */
  const { data: activeDevices } = useGetActivePosDevicesByTypeQuery()

  const activeTills = activeDevices?.data?.till || []
  const activeDisplays = activeDevices?.data?.display || []
  const activeKotDisplays = activeDevices?.data?.kot_display || []
  const activeKotPrinters = activeDevices?.data?.kot_printer || []

  /* ================= CREATE MUTATION ================= */
  const [createPosDeviceManagement, { isLoading }] = useCreatePosDeviceManagementMutation()
  const [createCardTerminal, { isLoading: isTerminalLoading }] = useCreateCardTerminalMutation()
  const { data: outletData } = useGetActiveOutletsQuery()

  const outlets = outletData?.outlets || []
  const { data, isLoading2, error } = useGetActiveBankAccountsQuery();

  const bankAccounts = data?.data || [];

  /* ================= HANDLERS ================= */

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleToggleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      enable_customer_input: e.target.checked,
    }))
  }

  // const handleSubmit = async (e) => {
  //   e.preventDefault()

  //   /* ===== BUILD PAYLOAD (DB COLUMN NAMES) ===== */
  //   const payload = {
  //     till_name: formData.name,
  //     display_id: formData.related_id ? [Number(formData.related_id)] : [],
  //     device_model: formData.device_model,
  //     type: createType === 'till' ? 'till' : 'display',
  //     enable_customer_input: createType === 'display' ? formData.enable_customer_input : undefined,
  //   }

  //   /* ===== CONFIRMATION ===== */
  //   const result = await Swal.fire({
  //     title: 'Confirm Creation',
  //     html: `
  //       <div style="text-align:left">
  //         <strong>Type:</strong> ${payload.type}<br/>
  //         <strong>Name:</strong> ${payload.till_name}<br/>
  //         <strong>Linked Device ID(s):</strong> ${payload.display_id.join(', ') || '-'}<br/>
  //         <strong>Device Model:</strong> ${payload.device_model}<br/>
  //         ${createType === 'display'
  //         ? `<strong>Customer Input:</strong> ${formData.enable_customer_input ? 'Enabled' : 'Disabled'}`
  //         : ''
  //       }
  //       </div>
  //     `,
  //     icon: 'info',
  //     showCancelButton: true,
  //     confirmButtonText: 'Create',
  //     cancelButtonText: 'Cancel',
  //   })

  //   if (!result.isConfirmed) return

  //   try {
  //     await createPosDeviceManagement(payload).unwrap()
  //     await Swal.fire('Created!', 'Device has been created successfully.', 'success')
  //     onBack()
  //   } catch (error) {
  //     console.error('Create device failed:', error)
  //     Swal.fire('Error', 'Failed to create device. Please try again.', 'error')
  //   }
  // }

  const handleSubmit = async (e) => {
    e.preventDefault();

    /* ================= CARD TERMINAL ================= */
    if (createType === "card_terminal") {
      const result = await Swal.fire({
        title: "Confirm Creation",
        html: `
        <div style="text-align:left">
          <strong>Type:</strong> Card Terminal<br/>
          <strong>Name:</strong> ${formData.name}<br/>
          <strong>MAC:</strong> ${formData.mac_address}<br/>
          <strong>IP:</strong> ${formData.ip}<br/>
          <strong>Status:</strong> ${formData.status}<br/>
        </div>
      `,
        icon: "info",
        showCancelButton: true,
        confirmButtonText: "Create",
        cancelButtonText: "Cancel",
      });

      if (!result.isConfirmed) return;

      try {
        await createCardTerminal({
          name: formData.name,
          mac_address: formData.mac_address,
          ip: formData.ip,
          account_name: formData.account_name,
          account_id: Number(formData.account_id),
          status: formData.status,
          outlet_id: Number(formData.outlet_id),
        }).unwrap();

        await Swal.fire("Created!", "Card Terminal created successfully.", "success");
        onBack();
      } catch (error) {
        console.error("Create terminal failed:", error);
        Swal.fire("Error", "Failed to create card terminal.", "error");
      }

      return; // 🔥 IMPORTANT: stop here
    }

    /* ================= DISPLAY / TILL (YOUR ORIGINAL CODE) ================= */

    const payload = {
      till_name: formData.name,
      display_id: formData.related_id
        ? [Number(formData.related_id)]
        : [],
      device_model: formData.device_model,
      type: createType,
      enable_customer_input:
        createType === "display"
          ? formData.enable_customer_input
          : undefined,
    };

    const result = await Swal.fire({
      title: "Confirm Creation",
      html: `
      <div style="text-align:left">
        <strong>Type:</strong> ${payload.type}<br/>
        <strong>Name:</strong> ${payload.till_name}<br/>
        <strong>Linked Device ID(s):</strong> ${payload.display_id.join(", ") || "-"}<br/>
        <strong>Device Model:</strong> ${payload.device_model}<br/>
        ${createType === "display"
          ? `<strong>Customer Input:</strong> ${formData.enable_customer_input ? "Enabled" : "Disabled"
          }`
          : ""
        }
      </div>
    `,
      icon: "info",
      showCancelButton: true,
      confirmButtonText: "Create",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await createPosDeviceManagement(payload).unwrap();
      await Swal.fire("Created!", "Device has been created successfully.", "success");
      onBack();
    } catch (error) {
      console.error("Create device failed:", error);
       if (error.status === 460) {
        Swal.fire({
          icon: "warning",
          iconColor: "#f59e0b", // Modern amber/warning color
          title: '<span style="font-family: sans-serif; font-weight: 600; color: #1f2937;">Till Limit Reached</span>',
          html: `
                <div style="text-align: center; color: #4b5563; font-family: sans-serif; font-size: 15px; line-height: 1.6; padding: 0 10px;">
                  <p style="margin: 0;">You have reached the maximum number of till devices allowed for your current plan.</p>
                  <p style="margin: 12px 0 0 0; font-weight: 600; color: #111827;">
                    Please contact your administrator to upgrade your subscription.
                  </p>
                </div>
              `,
          confirmButtonText: "Got it",
          confirmButtonColor: "#1f2937", // Pure inline background color
          background: "#ffffff",
          // This inline style rounds the default button beautifully
          didOpen: () => {
            const confirmButton = Swal.getConfirmButton();
            if (confirmButton) {
              confirmButton.style.borderRadius = "8px";
              confirmButton.style.padding = "10px 24px";
              confirmButton.style.fontSize = "14px";
              confirmButton.style.fontFamily = "sans-serif";
            }
          }
        });
        return;
      }
      Swal.fire("Error", "Failed to create device. Please try again.", "error");
    }
  };

  const headerTitle =
    createType === 'display'
      ? 'Create a New Display'
      : createType === 'till'
        ? 'Create a New Till'
        : createType === 'card_terminal'
          ? 'Create a New Card Terminal'
          : createType === 'kot_display'
            ? 'Create a New KOT Display'
            : createType === 'kot_printer'
              ? 'Create a New KOT Printer'
              : 'Create a New Device';


  /* ================= RENDER ================= */

  return (
    <Card>
      <CardHeader className="bg-light">
        <Row className="align-items-center">
          <Col>
            <CardTitle as="h4" className="mb-0">
              {headerTitle}
            </CardTitle>
            <small className="text-muted">Device & POS Configuration</small>
          </Col>
          <Col xs="auto">
            <Button variant="outline-secondary" onClick={onBack} disabled={isLoading}>
              ← Back
            </Button>
          </Col>
        </Row>
      </CardHeader>

      <CardBody>
        <Form onSubmit={handleSubmit}>
          {/* ===== TYPE + RELATED ===== */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Type</Form.Label>
              <Form.Select
                value={createType}
                onChange={(e) => {
                  setCreateType(e.target.value)
                  setFormData((prev) => ({
                    ...prev,
                    related_id: '',
                    enable_customer_input: false, // reset
                  }))
                }}
                required
                disabled={isLoading}>
                <option value="">Select</option>
                <option value="display">Display</option>
                <option value="till">Till</option>
                <option value="card_terminal">Card Terminal</option>
                <option value="kot_display">KOT Display</option>
                <option value="kot_printer">KOT Printer</option>
              </Form.Select>
            </Col>

            {(createType === 'display' || createType === 'till' || createType === 'kot_printer' || createType === 'kot_display') && (
              <Col md={6}>
                {/* <Form.Label>{createType === 'display' ? 'Select Till' : 'Select Display'}</Form.Label> */}
                <Form.Label>
                  {createType === 'display'
                    ? 'Select Till'
                    : createType === 'till'
                      ? 'Select Display'
                      : createType === 'kot_display'
                        ? 'Select KOT Printer'
                        : 'Select KOT Display'}
                </Form.Label>

                <Form.Select
                  name="related_id"
                  value={formData.related_id}
                  onChange={handleChange}
                  required
                  disabled={isLoading}>
                  {/* <option value="">{createType === 'display' ? 'Select Till' : 'Select Display'}</option> */}
                  <option value="">
                    {createType === 'display'
                      ? 'Select Till'
                      : createType === 'till'
                        ? 'Select Display'
                        : createType === 'kot_display'
                          ? 'Select KOT Printer'
                          : 'Select KOT Display'}
                  </option>

                  {(createType === 'display'
                    ? activeTills
                    : createType === 'till'
                      ? activeDisplays
                      : createType === 'kot_display'
                        ? activeKotPrinters
                        : activeKotDisplays
                  ).map((item) => (
                    <option key={item.device_id} value={item.device_id}>
                      {item.till_name} (ID: {item.device_id})
                    </option>
                  ))}

                </Form.Select>

              </Col>
            )}
          </Row>

          {/* ===== NAME + MODEL ===== */}
          {(createType === 'display' || createType === 'till' || createType === 'kot_printer' || createType === 'kot_display') && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>
                    {createType === 'display'
                      ? 'Display Name'
                      : createType === 'till'
                        ? 'Till Name'
                        : createType === 'kot_display'
                          ? 'KOT Display Name'
                          : createType === 'kot_printer'
                            ? 'KOT Printer Name'
                            : 'Device Name'}
                  </Form.Label>
                  <Form.Control
                    name="name"
                    placeholder={
                      createType === 'display'
                        ? 'e.g. Front Counter Display'
                        : createType === 'till'
                          ? 'e.g. Front Counter Till'
                          : createType === 'kot_display'
                            ? 'e.g. Kitchen Display'
                            : createType === 'kot_printer'
                              ? 'e.g. Kitchen Printer'
                              : 'Enter device name'
                    }
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group>
                  <Form.Label>Device Model</Form.Label>
                  <Form.Control
                    name="device_model"
                    placeholder="e.g. HP Engage One / DELL OptiPlex"
                    value={formData.device_model}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Form.Group>
              </Col>
            </Row>
          )}

          {/* ===== DISPLAY ONLY : CUSTOMER INPUT TOGGLE ===== */}
          {createType === 'display' && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Customer Input</Form.Label>

                  <div className="d-flex align-items-center gap-3">
                    <Form.Check
                      type="switch"
                      id="enable-customer-input"
                      checked={formData.enable_customer_input}
                      onChange={handleToggleChange}
                      disabled={isLoading}
                    />

                    <small className="text-muted">
                      {formData.enable_customer_input ? 'Enabled' : 'Disabled'}
                    </small>
                  </div>
                </Form.Group>
              </Col>
            </Row>
          )}

          {createType === 'card_terminal' && (
            <>
              <Row className="mb-3">
                <Col md={6}>
                  <Form.Label>Terminal Name</Form.Label>
                  <Form.Control
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>

                <Col md={6}>
                  <Form.Label>MAC Address</Form.Label>
                  <Form.Control
                    name="mac_address"
                    value={formData.mac_address}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>
              </Row>

              <Row className="mb-3">
                <Col md={6}>
                  <Form.Label>IP Address</Form.Label>
                  <Form.Control
                    name="ip"
                    value={formData.ip}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>

                <Col md={6}>
                  <Form.Label>Account Name</Form.Label>
                  <Form.Control
                    name="account_name"
                    value={formData.account_name}
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                </Col>
              </Row>

              <Row className="mb-3">

                <Col md={4}>
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    disabled={isLoading}
                  >
                    <option value="">Select</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Account ID</Form.Label>
                    <Form.Select
                      name="account_id"
                      value={formData.account_id}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Select Bank Account</option>

                      {bankAccounts.map((account) => (
                        <option key={account.id} value={account.id}>
                          {account.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Outlet</Form.Label>
                    <Form.Select
                      name="outlet_id"
                      value={formData.outlet_id}
                      onChange={handleChange}
                      required
                      disabled={isLoading}
                    >
                      <option value="">Select Outlet</option>

                      {outlets.map((outlet) => (
                        <option
                          key={outlet.outlet_id}
                          value={outlet.outlet_id}
                        >
                          {outlet.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>
            </>
          )}

          {/* ===== ACTION ===== */}
          <div className="d-flex justify-content-end">
            <Button type="submit" className="bg-primary border-primary" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  Creating...
                </>
              ) : (
                'Create'
              )}
            </Button>
          </div>

        </Form>
      </CardBody>
    </Card>
  )
}
