'use client'

import React, { useState } from 'react'
import { Card, CardHeader, CardBody, CardTitle, Row, Col, Form, Button, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import { useCreatePosDeviceManagementMutation, useGetActivePosDevicesByTypeQuery, useCreateCardTerminalMutation, useGetActiveOutletsQuery, useGetActiveBankAccountsQuery } from '@/store/features/apiSlice'

/* ================= RELATED-DEVICE PAIRING RULES =================
   Each creatable type that needs a linked device points at the type
   it pairs with. Keeping this in one place means the "select existing
   vs create new" UI below works the same for every pair. */
const RELATED_TYPE_KEY = {
  display: 'till',
  till: 'display',
  kot_display: 'kot_printer',
  kot_printer: 'kot_display',
}

const RELATED_LABEL = {
  till: 'Till',
  display: 'Display',
  kot_printer: 'KOT Printer',
  kot_display: 'KOT Display',
}

export default function CreateTill({ onBack }) {
  const [createType, setCreateType] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    related_id: '',
    device_model: '',
    enable_customer_input: false, // ✅ NEW

    mac_address: '',
    ip: '',
    account_name: '',
    account_id: '',
    status: '',
    outlet_id: '',
  })

  /* ================= RELATED DEVICE: select existing vs create new ================= */
  const [relatedMode, setRelatedMode] = useState('select') // 'select' | 'create'
  const [newRelated, setNewRelated] = useState({ name: '', device_model: '', enable_customer_input: false })
  const [isCreatingRelated, setIsCreatingRelated] = useState(false)

  /* ================= FETCH ACTIVE DEVICES ================= */
  const { data: activeDevices } = useGetActivePosDevicesByTypeQuery()

  const activeTills = activeDevices?.data?.till || []
  const activeDisplays = activeDevices?.data?.display || []
  const activeKotDisplays = activeDevices?.data?.kot_display || []
  const activeKotPrinters = activeDevices?.data?.kot_printer || []

  const relatedOptionsByType = {
    display: activeTills,
    till: activeDisplays,
    kot_display: activeKotPrinters,
    kot_printer: activeKotDisplays,
  }

  const showRelatedBlock = Boolean(RELATED_TYPE_KEY[createType])
  const relatedTypeKey = RELATED_TYPE_KEY[createType] // e.g. 'display' when createType === 'till'
  const relatedLabel = RELATED_LABEL[relatedTypeKey] || 'Device'
  const relatedOptions = relatedOptionsByType[createType] || []
  const hasRelatedOptions = relatedOptions.length > 0

  /* ================= CREATE MUTATION ================= */
  const [createPosDeviceManagement, { isLoading }] = useCreatePosDeviceManagementMutation()
  const [createCardTerminal, { isLoading: isTerminalLoading }] = useCreateCardTerminalMutation()
  const { data: outletData } = useGetActiveOutletsQuery()

  const outlets = outletData?.outlets || []
  const { data, isLoading2, error } = useGetActiveBankAccountsQuery();

  const bankAccounts = data?.data || [];

  const isBusy = isLoading || isCreatingRelated

  /* ================= HANDLERS ================= */

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleToggleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      enable_customer_input: e.target.checked,
    }))
  }

  const handleTypeChange = (e) => {
    const value = e.target.value
    const options = relatedOptionsByType[value] || []

    setCreateType(value)
    setFormData((prev) => ({
      ...prev,
      related_id: '',
      enable_customer_input: false, // reset
    }))
    // Default to "select existing" only when there's actually something to
    // pick from — e.g. the very first till has no display to select, so
    // there's no point showing an empty dropdown.
    setRelatedMode(options.length > 0 ? 'select' : 'create')
    setNewRelated({ name: '', device_model: '', enable_customer_input: false })
  }

  const handleNewRelatedChange = (e) => {
    const { name, value } = e.target
    setNewRelated((prev) => ({ ...prev, [name]: value }))
  }

  const handleNewRelatedToggle = (e) => {
    setNewRelated((prev) => ({ ...prev, enable_customer_input: e.target.checked }))
  }

  // const handleSubmit = async (e) => {
  //   e.preventDefault()

  //   /* ===== BUILD PAYLOAD (DB COLUMN NAMES) ===== */
  //   const payload = {
  //     till_name: formData.name,
  //     display_id: formData.related_id ? [Number(formData.related_id)] : [],
  //     device_model: formData.device_model,
  //     type: createType === 'till' ? 'till' : 'display',
  //     enable_customer_input: createType === 'display' ? formData.enable_customer_input : undefined,
  //   }

  //   /* ===== CONFIRMATION ===== */
  //   const result = await Swal.fire({
  //     title: 'Confirm Creation',
  //     html: `
  //       <div style="text-align:left">
  //         <strong>Type:</strong> ${payload.type}<br/>
  //         <strong>Name:</strong> ${payload.till_name}<br/>
  //         <strong>Linked Device ID(s):</strong> ${payload.display_id.join(', ') || '-'}<br/>
  //         <strong>Device Model:</strong> ${payload.device_model}<br/>
  //         ${createType === 'display'
  //         ? `<strong>Customer Input:</strong> ${formData.enable_customer_input ? 'Enabled' : 'Disabled'}`
  //         : ''
  //       }
  //       </div>
  //     `,
  //     icon: 'info',
  //     showCancelButton: true,
  //     confirmButtonText: 'Create',
  //     cancelButtonText: 'Cancel',
  //   })

  //   if (!result.isConfirmed) return

  //   try {
  //     await createPosDeviceManagement(payload).unwrap()
  //     await Swal.fire('Created!', 'Device has been created successfully.', 'success')
  //     onBack()
  //   } catch (error) {
  //     console.error('Create device failed:', error)
  //     Swal.fire('Error', 'Failed to create device. Please try again.', 'error')
  //   }
  // }

  const handleSubmit = async (e) => {
    e.preventDefault();

    /* ================= CARD TERMINAL ================= */
    if (createType === "card_terminal") {
      const result = await Swal.fire({
        title: "Confirm Creation",
        html: `
        <div style="text-align:left">
          <strong>Type:</strong> Card Terminal<br/>
          <strong>Name:</strong> ${formData.name}<br/>
          <strong>MAC:</strong> ${formData.mac_address}<br/>
          <strong>IP:</strong> ${formData.ip}<br/>
          <strong>Status:</strong> ${formData.status}<br/>
        </div>
      `,
        icon: "info",
        showCancelButton: true,
        confirmButtonText: "Create",
        cancelButtonText: "Cancel",
      });

      if (!result.isConfirmed) return;

      try {
        await createCardTerminal({
          name: formData.name,
          mac_address: formData.mac_address,
          ip: formData.ip,
          account_name: formData.account_name,
          account_id: Number(formData.account_id),
          status: formData.status,
          outlet_id: Number(formData.outlet_id),
        }).unwrap();

        await Swal.fire("Created!", "Card Terminal created successfully.", "success");
        onBack();
      } catch (error) {
        console.error("Create terminal failed:", error);
        Swal.fire("Error", "Failed to create card terminal.", "error");
      }

      return; // 🔥 IMPORTANT: stop here
    }

    /* ================= DISPLAY / TILL / KOT (YOUR ORIGINAL CODE, extended) ================= */

    const isCreatingNewRelated = showRelatedBlock && relatedMode === 'create'

    // Preview what will be linked so the confirmation dialog is honest about
    // what's about to happen — including the fact that a second device is
    // about to be created.
    const selectedExistingLabel = formData.related_id
      ? relatedOptions.find((item) => String(item.device_id) === String(formData.related_id))?.till_name || `ID ${formData.related_id}`
      : '-'

    const result = await Swal.fire({
      title: "Confirm Creation",
      html: `
      <div style="text-align:left">
        <strong>Type:</strong> ${createType}<br/>
        <strong>Name:</strong> ${formData.name}<br/>
        ${showRelatedBlock
          ? isCreatingNewRelated
            ? `<strong>New ${relatedLabel}:</strong> ${newRelated.name} <span style="color:#2f5fe0">(will be created &amp; linked)</span><br/>`
            : `<strong>Linked ${relatedLabel}:</strong> ${selectedExistingLabel}<br/>`
          : ""
        }
        <strong>Device Model:</strong> ${formData.device_model}<br/>
        ${createType === "display"
          ? `<strong>Customer Input:</strong> ${formData.enable_customer_input ? "Enabled" : "Disabled"}`
          : ""
        }
      </div>
    `,
      icon: "info",
      showCancelButton: true,
      confirmButtonText: "Create",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    let resolvedRelatedId = formData.related_id ? Number(formData.related_id) : null;

    try {
      /* ===== STEP 1 (only if pairing a brand new device): create the related device first ===== */
      if (isCreatingNewRelated) {
        setIsCreatingRelated(true);

        const relatedRes = await createPosDeviceManagement({
          till_name: newRelated.name,
          display_id: [],
          device_model: newRelated.device_model,
          type: relatedTypeKey,
          enable_customer_input: relatedTypeKey === 'display' ? newRelated.enable_customer_input : undefined,
        }).unwrap();

        // NOTE: adjust this extraction if the create endpoint returns the
        // new device's id under a different key.
        resolvedRelatedId =
          relatedRes?.data?.device_id ??
          relatedRes?.device_id ??
          relatedRes?.data?.id ??
          relatedRes?.id ??
          null;

        if (!resolvedRelatedId) {
          throw new Error('MISSING_RELATED_ID');
        }
      }

      /* ===== STEP 2: create the primary device, linked to the related id ===== */
      const payload = {
        till_name: formData.name,
        display_id: resolvedRelatedId ? [resolvedRelatedId] : [],
        device_model: formData.device_model,
        type: createType,
        enable_customer_input: createType === "display" ? formData.enable_customer_input : undefined,
      };

      await createPosDeviceManagement(payload).unwrap();

      await Swal.fire(
        "Created!",
        isCreatingNewRelated
          ? `Both the ${createType} and the new ${relatedLabel} were created and linked.`
          : "Device has been created successfully.",
        "success"
      );
      onBack();
    } catch (error) {
      console.error("Create device failed:", error);

      if (error?.message === 'MISSING_RELATED_ID') {
        Swal.fire(
          'Partially created',
          `The new ${relatedLabel} "${newRelated.name}" was created, but its ID couldn't be read back to link it automatically. Please create "${formData.name}" again and select it from the list.`,
          'warning'
        );
        return;
      }

       if (error.status === 460) {
        Swal.fire({
          icon: "warning",
          iconColor: "#f59e0b", // Modern amber/warning color
          title: '<span style="font-family: sans-serif; font-weight: 600; color: #1f2937;">Till Limit Reached</span>',
          html: `
                <div style="text-align: center; color: #4b5563; font-family: sans-serif; font-size: 15px; line-height: 1.6; padding: 0 10px;">
                  <p style="margin: 0;">You have reached the maximum number of till devices allowed for your current plan.</p>
                  <p style="margin: 12px 0 0 0; font-weight: 600; color: #111827;">
                    Please contact your administrator to upgrade your subscription.
                  </p>
                </div>
              `,
          confirmButtonText: "Got it",
          confirmButtonColor: "#1f2937", // Pure inline background color
          background: "#ffffff",
          // This inline style rounds the default button beautifully
          didOpen: () => {
            const confirmButton = Swal.getConfirmButton();
            if (confirmButton) {
              confirmButton.style.borderRadius = "8px";
              confirmButton.style.padding = "10px 24px";
              confirmButton.style.fontSize = "14px";
              confirmButton.style.fontFamily = "sans-serif";
            }
          }
        });
        return;
      }
      Swal.fire("Error", "Failed to create device. Please try again.", "error");
    } finally {
      setIsCreatingRelated(false);
    }
  };

  const headerTitle =
    createType === 'display'
      ? 'Create a New Display'
      : createType === 'till'
        ? 'Create a New Till'
        : createType === 'card_terminal'
          ? 'Create a New Card Terminal'
          : createType === 'kot_display'
            ? 'Create a New KOT Display'
           : createType === 'kot_printer'
              ? 'Create a New KOT Printer'
              : createType === 'attendance_device'
                ? 'Create a New Attendance Device'
                : 'Create a New Device';


  /* ================= RENDER ================= */

  return (
    <Card>
      <CardHeader className="bg-light">
        <Row className="align-items-center">
          <Col>
            <CardTitle as="h4" className="mb-0">
              {headerTitle}
            </CardTitle>
            <small className="text-muted">Device & POS Configuration</small>
          </Col>
          <Col xs="auto">
            <Button variant="outline-secondary" onClick={onBack} disabled={isBusy}>
              ← Back
            </Button>
          </Col>
        </Row>
      </CardHeader>

      <CardBody>
        <Form onSubmit={handleSubmit}>
          {/* ===== TYPE + RELATED ===== */}
          <Row className="mb-3">
            <Col md={6}>
              <Form.Label>Type</Form.Label>
              <Form.Select value={createType} onChange={handleTypeChange} required disabled={isBusy}>
                <option value="">Select</option>
                <option value="display">Display</option>
                <option value="till">Till</option>
                <option value="card_terminal">Card Terminal</option>
                <option value="kot_display">KOT Display</option>
                <option value="kot_printer">KOT Printer</option>
                <option value="attendance_device">Finger Print Device</option>
              </Form.Select>
            </Col>

            {showRelatedBlock && (
              <Col md={6}>
                <div className="ct-related-label-row">
                  <Form.Label className="mb-0">Select {relatedLabel}</Form.Label>

                  {hasRelatedOptions && (
                    <div className="ct-seg" role="tablist" aria-label={`Choose how to link a ${relatedLabel}`}>
                      <button
                        type="button"
                        role="tab"
                        aria-selected={relatedMode === 'select'}
                        className={`ct-seg-btn ${relatedMode === 'select' ? 'is-active' : ''}`}
                        onClick={() => setRelatedMode('select')}
                        disabled={isBusy}>
                        Select existing
                      </button>
                      <button
                        type="button"
                        role="tab"
                        aria-selected={relatedMode === 'create'}
                        className={`ct-seg-btn ${relatedMode === 'create' ? 'is-active' : ''}`}
                        onClick={() => setRelatedMode('create')}
                        disabled={isBusy}>
                        Create new
                      </button>
                    </div>
                  )}
                </div>

                {relatedMode === 'select' ? (
                  <Form.Select
                    name="related_id"
                    value={formData.related_id}
                    onChange={handleChange}
                    required
                    disabled={isBusy}
                    className="mt-2">
                    <option value="">Select {relatedLabel}</option>
                    {relatedOptions.map((item) => (
                      <option key={item.device_id} value={item.device_id}>
                        {item.till_name} (ID: {item.device_id})
                      </option>
                    ))}
                  </Form.Select>
                ) : (
                  <div className="ct-create-note mt-2">
                    <IconifyIcon icon="mdi:link-plus" />
                    A new {relatedLabel.toLowerCase()} will be created and linked automatically.
                  </div>
                )}

                {!hasRelatedOptions && (
                  <div className="ct-empty-hint">
                    <IconifyIcon icon="mdi:information-outline" />
                    No active {relatedLabel.toLowerCase()}s yet — fill in its details below and it&apos;ll be created together with this {createType}.
                  </div>
                )}
              </Col>
            )}
          </Row>

          {/* ===== INLINE PANEL: new related device details ===== */}
          {showRelatedBlock && relatedMode === 'create' && (
            <div className="ct-panel">
              <div className="ct-panel-title">
                <IconifyIcon icon="mdi:plus-box-outline" className="iconify" />
                New {relatedLabel} details
              </div>

              <Row className="g-3">
                <Col md={6}>
                  <Form.Group>
                    <Form.Label>{relatedLabel} Name</Form.Label>
                    <Form.Control
                      name="name"
                      placeholder={`e.g. ${relatedTypeKey === 'display' ? 'Front Counter Display' : relatedTypeKey === 'till' ? 'Front Counter Till' : relatedTypeKey === 'kot_printer' ? 'Kitchen Printer' : 'Kitchen Display'}`}
                      value={newRelated.name}
                      onChange={handleNewRelatedChange}
                      required
                      disabled={isBusy}
                    />
                  </Form.Group>
                </Col>

                <Col md={6}>
                  <Form.Group>
                    <Form.Label>Device Model</Form.Label>
                    <Form.Control
                      name="device_model"
                      placeholder="e.g. HP Engage One / DELL OptiPlex"
                      value={newRelated.device_model}
                      onChange={handleNewRelatedChange}
                      disabled={isBusy}
                    />
                  </Form.Group>
                </Col>

                {relatedTypeKey === 'display' && (
                  <Col md={6}>
                    <Form.Group>
                      <Form.Label>Customer Input</Form.Label>
                      <div className="d-flex align-items-center gap-3">
                        <Form.Check
                          type="switch"
                          id="new-related-customer-input"
                          checked={newRelated.enable_customer_input}
                          onChange={handleNewRelatedToggle}
                          disabled={isBusy}
                        />
                        <small className="text-muted">{newRelated.enable_customer_input ? 'Enabled' : 'Disabled'}</small>
                      </div>
                    </Form.Group>
                  </Col>
                )}
              </Row>
            </div>
          )}

          {/* ===== NAME + MODEL ===== */}
          {(createType === 'display' || createType === 'till' || createType === 'kot_printer' || createType === 'kot_display' || createType === 'attendance_device') && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>
                    {createType === 'display'
                      ? 'Display Name'
                      : createType === 'till'
                        ? 'Till Name'
                        : createType === 'kot_display'
                          ? 'KOT Display Name'
                          : createType === 'kot_printer'
                            ? 'KOT Printer Name'
                            : createType === 'attendance_device'
                              ? 'Attendance Device Name'
                              : 'Device Name'}
                  </Form.Label>
                  <Form.Control
                    name="name"
                    placeholder={
                      createType === 'display'
                        ? 'e.g. Front Counter Display'
                        : createType === 'till'
                          ? 'e.g. Front Counter Till'
                          : createType === 'kot_display'
                            ? 'e.g. Kitchen Display'
                            : createType === 'kot_printer'
                              ? 'e.g. Kitchen Printer'
                              : createType === 'attendance_device'
                                ? 'e.g. Main Entrance Scanner'
                                : 'Enter device name'
                    }
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={isBusy}
                  />
                </Form.Group>
              </Col>

              <Col md={6}>
                <Form.Group>
                  <Form.Label>Device Model</Form.Label>
                  <Form.Control
                    name="device_model"
                    placeholder="e.g. HP Engage One / DELL OptiPlex"
                    value={formData.device_model}
                    onChange={handleChange}
                    required
                    disabled={isBusy}
                  />
                </Form.Group>
              </Col>
            </Row>
          )}

          {/* ===== DISPLAY ONLY : CUSTOMER INPUT TOGGLE ===== */}
          {createType === 'display' && (
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Customer Input</Form.Label>

                  <div className="d-flex align-items-center gap-3">
                    <Form.Check
                      type="switch"
                      id="enable-customer-input"
                      checked={formData.enable_customer_input}
                      onChange={handleToggleChange}
                      disabled={isBusy}
                    />

                    <small className="text-muted">
                      {formData.enable_customer_input ? 'Enabled' : 'Disabled'}
                    </small>
                  </div>
                </Form.Group>
              </Col>
            </Row>
          )}

          {createType === 'card_terminal' && (
            <>
              <Row className="mb-3">
                <Col md={6}>
                  <Form.Label>Terminal Name</Form.Label>
                  <Form.Control
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>

                <Col md={6}>
                  <Form.Label>MAC Address</Form.Label>
                  <Form.Control
                    name="mac_address"
                    value={formData.mac_address}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>
              </Row>

              <Row className="mb-3">
                <Col md={6}>
                  <Form.Label>IP Address</Form.Label>
                  <Form.Control
                    name="ip"
                    value={formData.ip}
                    onChange={handleChange}
                    required
                    disabled={isLoading}
                  />
                </Col>

                <Col md={6}>
                  <Form.Label>Account Name</Form.Label>
                  <Form.Control
                    name="account_name"
                    value={formData.account_name}
                    onChange={handleChange}
                    disabled={isLoading}
                  />
                </Col>
              </Row>

              <Row className="mb-3">

                <Col md={4}>
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    disabled={isLoading}
                  >
                    <option value="">Select</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Account ID</Form.Label>
                    <Form.Select
                      name="account_id"
                      value={formData.account_id}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Select Bank Account</option>

                      {bankAccounts.map((account) => (
                        <option key={account.id} value={account.id}>
                          {account.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Outlet</Form.Label>
                    <Form.Select
                      name="outlet_id"
                      value={formData.outlet_id}
                      onChange={handleChange}
                      required
                      disabled={isLoading}
                    >
                      <option value="">Select Outlet</option>

                      {outlets.map((outlet) => (
                        <option
                          key={outlet.outlet_id}
                          value={outlet.outlet_id}
                        >
                          {outlet.name}
                        </option>
                      ))}
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>
            </>
          )}

          {/* ===== ACTION ===== */}
          <div className="d-flex justify-content-end">
            <Button type="submit" className="bg-primary border-primary" disabled={isBusy}>
              {isBusy ? (
                <>
                  <Spinner size="sm" className="me-2" />
                  {isCreatingRelated ? `Creating ${relatedLabel}...` : 'Creating...'}
                </>
              ) : (
                'Create'
              )}
            </Button>
          </div>

        </Form>
      </CardBody>
    </Card>
  )
}