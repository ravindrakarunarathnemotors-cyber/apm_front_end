'use client'

import React, { useState } from 'react'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Row, Badge, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import CreateTill from './Create_Till'
import EditTill from './Edit_Till'
import BannerModal from './BannerModal'

import Swal from 'sweetalert2'
import { useGetPosDevicesGroupedByTypeQuery, useUpdatePosDeviceStatusMutation } from '@/store/features/apiSlice'

export default function DeviceManagement() {
  const [showCreateTill, setShowCreateTill] = useState(false)
  const [showEditTill, setShowEditTill] = useState(false)
  const [selectedDevice, setSelectedDevice] = useState(null)
  const [hoveredId, setHoveredId] = useState(null)
  const [hoveredAction, setHoveredAction] = useState(null)
  const [updatingId, setUpdatingId] = useState(null)

  const [showBannerModal, setShowBannerModal] = useState(false)
  const [bannerDevice, setBannerDevice] = useState(null)

  /* ================= FETCH ================= */
  const { data, isLoading, isError } = useGetPosDevicesGroupedByTypeQuery()

  const [updateDeviceStatus] = useUpdatePosDeviceStatusMutation()

  /* ✅ FLATTEN WITH EXPLICIT TYPE */
  const devices = [
    ...(data?.data?.till || []).map((d) => ({
      ...d,
      __deviceType: 'till',
    })),
    ...(data?.data?.display || []).map((d) => ({
      ...d,
      __deviceType: 'display',
    })),
  ]
  const activeDevices = devices.filter((d) => d.status === 'Active')

  const inactiveDevices = devices.filter((d) => d.status === 'Inactive')

  /* ================= ACTIONS ================= */

  const toggleStatus = async (device) => {
    const nextStatus = device.status === 'Active' ? 'Inactive' : 'Active'

    const result = await Swal.fire({
      title: `${nextStatus} Device?`,
      text: `This will set "${device.till_name}" to ${nextStatus}.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${nextStatus}`,
    })

    if (!result.isConfirmed) return

    try {
      setUpdatingId(device.device_id)

      await updateDeviceStatus({
        device_id: device.device_id,
        status: nextStatus,
      }).unwrap()

      Swal.fire('Updated!', `Device is now ${nextStatus}.`, 'success')
    } catch (error) {
      console.error('Status update failed:', error)

      Swal.fire('Error', 'Failed to update device status.', 'error')
    } finally {
      setUpdatingId(null)
    }
  }

  const openEdit = (device) => {
    setSelectedDevice(device)
    setShowEditTill(true)
  }

  const openBanner = (device) => {
    setBannerDevice(device)
    setShowBannerModal(true)
  }

  /* ================= STYLES ================= */

  const cardBaseStyle = {
    transition: 'transform 0.15s ease, box-shadow 0.15s ease',
  }

  const cardHoverStyle = {
    transform: 'translateY(-4px)',
    boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
  }

  const actionHoverStyle = {
    transform: 'scale(1.15)',
    transition: 'transform 0.15s ease',
  }

  /* ================= RENDER ================= */
  return (
    <div>
      {showCreateTill ? (
        <CreateTill onBack={() => setShowCreateTill(false)} />
      ) : showEditTill ? (
        <EditTill device={selectedDevice} onBack={() => setShowEditTill(false)} />
      ) : (
        <Card>
          {/* <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Device Management
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Button className="bg-primary border-primary" onClick={() => setShowCreateTill(true)}>
                  <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                  Create New
                </Button>
              </Col>
            </Row>
          </CardHeader> */}

          <CardBody>
            {isLoading ? (
              <div className="text-center py-5">
                <Spinner />
              </div>
            ) : isError ? (
              <div className="text-center text-danger">Failed to load devices</div>
            ) : (
              <Row className="gy-4">
                {/* ================= ACTIVE DEVICES ================= */}
                {activeDevices.map((device) => {
                  const isDisplay = device.__deviceType === 'display'

                  return (
                    <Col key={device.device_id} xs={12} sm={6} md={4} lg={3}>
                      <Card
                        className="h-100 position-relative"
                        style={{
                          ...cardBaseStyle,
                          ...(hoveredId === device.device_id ? cardHoverStyle : {}),
                        }}
                        onMouseEnter={() => setHoveredId(device.device_id)}
                        onMouseLeave={() => setHoveredId(null)}>
                        <CardHeader className="p-2 bg-light">
                          <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-1">
                            <Badge bg="dark">ID · {device.device_id}</Badge>
                            <h5 className="fw-bold mb-0 capitalize" style={{ textTransform: 'capitalize' }}>
                              {device.till_name}
                            </h5>
                          </CardTitle>
                        </CardHeader>
                        <Card.Body className="text-start p-2">
                          <div className="d-flex gap-2">
                            <div>
                              <IconifyIcon
                                icon={isDisplay ? 'mdi:monitor' : 'mdi:cash-register'}
                                style={{ fontSize: 50, borderRadius: '10px' }}
                                className={`mb-2 shadow-sm p-1 ${isDisplay ? 'text-success' : 'text-dark'}`}
                              />
                            </div>
                            <div>
                              <div
                                style={{
                                  fontSize: 13,
                                  fontWeight: 500,
                                }}>
                                Model - {device.device_model}
                              </div>

                              {/* STATUS TOGGLE BELOW MODEL */}
                              <div
                                role="button"
                                onClick={() => toggleStatus(device)}
                                className="d-inline-flex align-items-center gap-1 mt-1 text-success"
                                style={{
                                  fontSize: 13,
                                  cursor: 'pointer',
                                  opacity: updatingId === device.device_id ? 0.6 : 1,
                                  pointerEvents: updatingId === device.device_id ? 'none' : 'auto',
                                }}>
                                <span>Status</span>
                                <IconifyIcon icon="mdi:toggle-switch" style={{ fontSize: 26 }} />
                              </div>
                            </div>
                          </div>

                          {/* <h5 className="fw-bold">{device.till_name}</h5> */}

                          {/* <Badge bg="success" className="my-2">
                            Active
                          </Badge> */}

                          <Row className="mt-1 g-2">
                            {/* CONFIG BUTTON */}
                            <Col xs={isDisplay ? 6 : 12} className="m-0">
                              <Button
                                size="sm"
                                variant="outline-primary"
                                className="w-100"
                                onClick={() => openEdit(device)}
                                disabled={updatingId === device.device_id}>
                                <IconifyIcon icon="mdi:cog-outline" className="me-1" />
                                Config
                              </Button>
                            </Col>

                            {/* BANNER BUTTON (ONLY IF DISPLAY) */}
                            {isDisplay && (
                              <Col xs={6} className="m-0">
                                <Button
                                  size="sm"
                                  variant="outline-secondary"
                                  className="w-100"
                                  onClick={() => openBanner(device)}
                                  disabled={updatingId === device.device_id}>
                                  <IconifyIcon icon="mdi:view-dashboard-outline" className="me-1" />
                                  Banner
                                </Button>
                              </Col>
                            )}
                          </Row>
                        </Card.Body>
                      </Card>
                    </Col>
                  )
                })}

                {/* ================= INACTIVE TITLE + DIVIDER ================= */}
                {inactiveDevices.length > 0 && (
                  <Col xs={12} className="mt-4 mb-2">
                    <div className="d-flex align-items-center gap-3">
                      <span className="text-muted fw-semibold text-uppercase small">Inactive Devices</span>
                      <hr className="flex-grow-1 opacity-25 m-0" />
                    </div>
                  </Col>
                )}

                {/* ================= INACTIVE DEVICES ================= */}
                {inactiveDevices.map((device) => {
                  const isDisplay = device.__deviceType === 'display'

                  return (
                    <Col key={device.device_id} xs={12} sm={6} md={4} lg={3}>
                      <Card className="h-100 position-relative" style={cardBaseStyle}>
                        <CardHeader className="p-2 bg-light">
                          <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-1">
                            <Badge bg="secondary">ID · {device.device_id}</Badge>
                            <h5 className="fw-bold mb-0 capitalize" style={{ textTransform: 'capitalize' }}>
                              {device.till_name}
                            </h5>
                          </CardTitle>
                        </CardHeader>

                        <Card.Body className="text-start p-2">
                          <div className="d-flex gap-2">
                            <div>
                              <IconifyIcon
                                icon={isDisplay ? 'mdi:monitor' : 'mdi:cash-register'}
                                style={{ fontSize: 50, borderRadius: '10px' }}
                                className="mb-2 shadow-sm p-1 text-secondary"
                              />
                            </div>

                            <div>
                              <div style={{ fontSize: 13, fontWeight: 500 }}>Model - {device.device_model}</div>

                              <div
                                role="button"
                                onClick={() => toggleStatus(device)}
                                className="d-inline-flex align-items-center gap-1 mt-1 text-danger"
                                style={{
                                  fontSize: 13,
                                  cursor: 'pointer',
                                }}>
                                <span>Status</span>
                                <IconifyIcon icon="mdi:toggle-switch-off" style={{ fontSize: 26 }} />
                              </div>
                            </div>
                          </div>

                          {/* ACTION BUTTONS (SAME AS ACTIVE, DISABLED) */}
                          <Row className="mt-1 g-2">
                            <Col xs={isDisplay ? 6 : 12} className="m-0">
                              <Button size="sm" variant="outline-secondary" className="w-100" disabled>
                                <IconifyIcon icon="mdi:cog-outline" className="me-1" />
                                Config
                              </Button>
                            </Col>

                            {isDisplay && (
                              <Col xs={6} className="m-0">
                                <Button size="sm" variant="outline-secondary" className="w-100" disabled>
                                  <IconifyIcon icon="mdi:view-dashboard-outline" className="me-1" />
                                  Banner
                                </Button>
                              </Col>
                            )}
                          </Row>

                          {/* INACTIVE BADGE */}
                          <div className="text-center mt-2">
                            <Badge bg="secondary">Inactive</Badge>
                          </div>
                        </Card.Body>
                      </Card>
                    </Col>
                  )
                })}

                {devices.length === 0 && <Col className="text-center text-muted">No devices created yet.</Col>}
              </Row>
            )}
          </CardBody>
        </Card>
      )}

      {showBannerModal && (
        <BannerModal
          show={showBannerModal}
          device={bannerDevice}
          onHide={() => {
            setShowBannerModal(false)
            setBannerDevice(null)
          }}
        />
      )}
    </div>
  )
}
