'use client'

import React, { useState } from 'react'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Row, Badge, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import CreateTill from './Create_Till'
import EditTill from './Edit_Till'
import BannerModal from './BannerModal'
import Swal from 'sweetalert2'
import axiosInstance from '@/lib/axiosInstance';
import { useGetPosDevicesGroupedByTypeQuery, useUpdatePosDeviceStatusMutation } from '@/store/features/apiSlice'

export default function DeviceManagement() {
  const [showCreateTill, setShowCreateTill] = useState(false)
  const [showEditTill, setShowEditTill] = useState(false)
  const [selectedDevice, setSelectedDevice] = useState(null)
  const [hoveredId, setHoveredId] = useState(null)
  const [hoveredAction, setHoveredAction] = useState(null)
  const [updatingId, setUpdatingId] = useState(null)

  const [showBannerModal, setShowBannerModal] = useState(false)
  const [bannerDevice, setBannerDevice] = useState(null)

  /* ================= FETCH ================= */
  const { data, isLoading, isError, refetch } = useGetPosDevicesGroupedByTypeQuery()

  const [updateDeviceStatus] = useUpdatePosDeviceStatusMutation()

  /* ✅ FLATTEN WITH EXPLICIT TYPE */
  const devices = [
    ...(data?.data?.till || []).map((d) => ({
      ...d,
      __deviceType: 'till',
    })),
    ...(data?.data?.display || []).map((d) => ({
      ...d,
      __deviceType: 'display',
    })),
  ]
  const activeDevices = devices.filter((d) => d.status === 'Active')

  const inactiveDevices = devices.filter((d) => d.status === 'Inactive')

  /* ================= ACTIONS ================= */

  const toggleStatus = async (device) => {
    const nextStatus = device.status === 'Active' ? 'Inactive' : 'Active'

    const result = await Swal.fire({
      title: `${nextStatus} Device?`,
      text: `This will set "${device.till_name}" to ${nextStatus}.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${nextStatus}`,
    })

    if (!result.isConfirmed) return

    try {
      setUpdatingId(device.device_id)

      await updateDeviceStatus({
        device_id: device.device_id,
        status: nextStatus,
      }).unwrap()

      Swal.fire('Updated!', `Device is now ${nextStatus}.`, 'success')
    } catch (error) {
      console.error('Status update failed:', error)

      Swal.fire('Error', 'Failed to update device status.', 'error')
    } finally {
      setUpdatingId(null)
    }
  }

  const openEdit = (device) => {
    setSelectedDevice(device)
    setShowEditTill(true)
  }

  const openBanner = (device) => {
    setBannerDevice(device)
    setShowBannerModal(true)
  }

  /* ================= STYLES ================= */

  const cardBaseStyle = {
    transition: 'transform 0.15s ease, box-shadow 0.15s ease',
  }

  const cardHoverStyle = {
    transform: 'translateY(-4px)',
    boxShadow: '0 6px 18px rgba(0,0,0,0.08)',
  }

  const actionHoverStyle = {
    transform: 'scale(1.15)',
    transition: 'transform 0.15s ease',
  }

  const resetDevice = async (device) => {
    const result = await Swal.fire({
      title: 'Remove device usage?',
      text: `${device.till_name} will become available again.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, Reset',
    })

    if (!result.isConfirmed) return

    try {
      await axiosInstance.post(
        `/pos/resetDeviceInfo`,
        { device_id: device.device_id }
      )

      Swal.fire({
        icon: 'success',
        title: 'Device Reset',
        text: 'Device is now available.',
        timer: 1800,
        showConfirmButton: false,
      })

      refetch()
    } catch (error) {
      console.error(error)

      Swal.fire({
        icon: 'error',
        title: 'Reset Failed',
        text: 'Something went wrong.',
      })
    }
  }

  /* ================= RENDER ================= */
  return (
    <div>
      {showCreateTill ? (
        <CreateTill onBack={() => setShowCreateTill(false)} />
      ) : showEditTill ? (
        <EditTill device={selectedDevice} onBack={() => setShowEditTill(false)} />
      ) : (
        <Card>
          {/* <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Device Management
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Button className="bg-primary border-primary" onClick={() => setShowCreateTill(true)}>
                  <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                  Create New
                </Button>
              </Col>
            </Row>
          </CardHeader> */}

          <CardBody>
            {isLoading ? (
              <div className="text-center py-5">
                <Spinner />
              </div>
            ) : isError ? (
              <div className="text-center text-danger">Failed to load devices</div>
            ) : (
              <Row className="gy-4">
                {/* ================= ACTIVE DEVICES ================= */}
                {activeDevices.map((device) => {
                  const isDisplay = device.__deviceType === 'display'

                  return (
                    <Col key={device.device_id} xs={12} sm={6} md={4} lg={3}>
                      <Card
                        className="border-0 shadow-sm h-100 rounded-4 overflow-hidden"
                        style={{
                          transition: '0.2s ease',
                          transform:
                            hoveredId === device.device_id
                              ? 'translateY(-4px)'
                              : 'translateY(0)',
                        }}
                        onMouseEnter={() => setHoveredId(device.device_id)}
                        onMouseLeave={() => setHoveredId(null)}
                      >
                        {/* HEADER */}
                        <div className="p-3 border-bottom bg-light-subtle">
                          <div className="d-flex justify-content-between align-items-start gap-1">
                            <div>
                              <h5
                                className="mb-1 fw-bold"
                                style={{ textTransform: 'capitalize' }}
                              >
                                {device.till_name}
                              </h5>

                              <div className="text-muted small">
                                Device ID: {device.device_id}
                              </div>
                            </div>

                            <IconifyIcon
                              icon={isDisplay ? 'mdi:monitor-dashboard' : 'mdi:cash-register'}
                              style={{
                                fontSize: 38,
                              }}
                              className={isDisplay ? 'text-success' : 'text-primary'}
                            />
                          </div>
                        </div>

                        {/* BODY */}
                        <Card.Body className="d-flex flex-column gap-3">
                          {/* MODEL */}
                          <div>
                            <div className="text-muted small mb-1">Model</div>

                            <div className="fw-semibold">
                              {device.device_model || 'N/A'}
                            </div>
                          </div>

                          {/* STATUS */}
                          <div className="d-flex flex-wrap gap-2">
                            <Badge bg="success-subtle" text="success" className="px-3 py-2">
                              {device.status}
                            </Badge>

                            <Badge
                              bg={device.has_device_info ? 'danger' : 'secondary'}
                              className="px-3 py-2"
                            >
                              {device.has_device_info ? 'In Use' : 'Available'}
                            </Badge>
                          </div>

                          {/* TOGGLE */}
                          <div
                            role="button"
                            onClick={() => toggleStatus(device)}
                            className="d-flex align-items-center gap-2 small text-muted"
                            style={{
                              cursor: 'pointer',
                              width: 'fit-content',
                              opacity: updatingId === device.device_id ? 0.6 : 1,
                            }}
                          >
                            <IconifyIcon
                              icon="mdi:toggle-switch-outline"
                              style={{ fontSize: 28 }}
                            />

                            Change Status
                          </div>

                          <div
                            className="mt-1 small text-muted"
                            style={{
                              background: device.has_device_info ? 'rgba(255,255,255,0.6)' : 'transparent',
                              borderRadius: '12px',
                              padding: device.has_device_info ? '4px 8px' : '0',
                            }}
                          >
                            {device.has_device_info && (
                              <>
                                <div className="d-flex justify-content-center gap-2 flex-wrap">
                                  <span>{device.device_info?.user_id ? `${device.device_info?.username} (${device.device_info?.user_id})` : ''}</span>
                                </div>

                                <div className="d-flex justify-content-center gap-2 flex-wrap">
                                  <span>{device.device_info?.os}</span>
                                  <span>{device.device_info?.browser}</span>
                                  <span>{device.device_info?.device_type}</span>
                                </div>
                              </>
                            )}
                          </div>

                          {/* ACTIONS */}
                          <div className="mt-auto">
                            <Row className="g-2">
                              <Col xs={device.has_device_info ? 6 : 12}>
                                <Button
                                  size="sm"
                                  variant="dark"
                                  className="w-100 rounded-3"
                                  onClick={() => openEdit(device)}
                                >
                                  <IconifyIcon icon="mdi:cog-outline" className="me-1" />
                                  Config
                                </Button>
                              </Col>

                              {/* RESET BUTTON */}
                              {device.has_device_info && (
                                <Col xs={6}>
                                  <Button
                                    size="sm"
                                    variant="outline-danger"
                                    className="w-100 rounded-3"
                                    onClick={() => resetDevice(device)}
                                  >
                                    <IconifyIcon
                                      icon="mdi:restart-alert"
                                      className="me-1"
                                    />
                                    Reset
                                  </Button>
                                </Col>
                              )}

                              {/* DISPLAY BUTTON */}
                              {isDisplay && (
                                <Col xs={12}>
                                  <Button
                                    size="sm"
                                    variant="outline-secondary"
                                    className="w-100 rounded-3"
                                    onClick={() => openBanner(device)}
                                  >
                                    <IconifyIcon
                                      icon="mdi:view-dashboard-outline"
                                      className="me-1"
                                    />
                                    Manage Banner
                                  </Button>
                                </Col>
                              )}
                            </Row>
                          </div>
                        </Card.Body>
                      </Card>
                    </Col>
                  )
                })}

                {/* ================= INACTIVE TITLE + DIVIDER ================= */}
                {inactiveDevices.length > 0 && (
                  <Col xs={12} className="mt-4 mb-2">
                    <div className="d-flex align-items-center gap-3">
                      <span className="text-muted fw-semibold text-uppercase small">Inactive Devices</span>
                      <hr className="flex-grow-1 opacity-25 m-0" />
                    </div>
                  </Col>
                )}

                {/* ================= INACTIVE DEVICES ================= */}
                {inactiveDevices.map((device) => {
                  const isDisplay = device.__deviceType === 'display'

                  return (
                    <Col key={device.device_id} xs={12} sm={6} md={4} lg={3}>
                      <Card className="h-100 position-relative" style={cardBaseStyle}>
                        <CardHeader className="p-2 bg-light">
                          <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-1">
                            <Badge bg="secondary">ID · {device.device_id}</Badge>
                            <h5 className="fw-bold mb-0 capitalize" style={{ textTransform: 'capitalize' }}>
                              {device.till_name}
                            </h5>
                          </CardTitle>
                        </CardHeader>

                        <Card.Body className="text-start p-2">
                          <div className="d-flex gap-2">
                            <div>
                              <IconifyIcon
                                icon={isDisplay ? 'mdi:monitor' : 'mdi:cash-register'}
                                style={{ fontSize: 50, borderRadius: '10px' }}
                                className="mb-2 shadow-sm p-1 text-secondary"
                              />
                            </div>

                            <div>
                              <div style={{ fontSize: 13, fontWeight: 500 }}>Model - {device.device_model}</div>

                              <div
                                role="button"
                                onClick={() => toggleStatus(device)}
                                className="d-inline-flex align-items-center gap-1 mt-1 text-danger"
                                style={{
                                  fontSize: 13,
                                  cursor: 'pointer',
                                }}>
                                <span>Status</span>
                                <IconifyIcon icon="mdi:toggle-switch-off" style={{ fontSize: 26 }} />
                              </div>
                            </div>
                          </div>

                          {/* ACTION BUTTONS (SAME AS ACTIVE, DISABLED) */}
                          <Row className="mt-1 g-2">
                            <Col xs={isDisplay ? 6 : 12} className="m-0">
                              <Button size="sm" variant="outline-secondary" className="w-100" disabled>
                                <IconifyIcon icon="mdi:cog-outline" className="me-1" />
                                Config
                              </Button>
                            </Col>

                            {isDisplay && (
                              <Col xs={6} className="m-0">
                                <Button size="sm" variant="outline-secondary" className="w-100" disabled>
                                  <IconifyIcon icon="mdi:view-dashboard-outline" className="me-1" />
                                  Banner
                                </Button>
                              </Col>
                            )}
                          </Row>

                          {/* INACTIVE BADGE */}
                          <div className="text-center mt-2">
                            <Badge bg="secondary">Inactive</Badge>
                          </div>
                        </Card.Body>
                      </Card>
                    </Col>
                  )
                })}

                {devices.length === 0 && <Col className="text-center text-muted">No devices created yet.</Col>}
              </Row>
            )}
          </CardBody>
        </Card>
      )}

      {showBannerModal && (
        <BannerModal
          show={showBannerModal}
          device={bannerDevice}
          onHide={() => {
            setShowBannerModal(false)
            setBannerDevice(null)
          }}
        />
      )}
    </div>
  )
}
