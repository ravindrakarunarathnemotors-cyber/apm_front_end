'use client'

import React, { useState, useEffect } from 'react'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardBody, Col, Form, FormGroup, FormLabel, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
    useGetCardTerminalMutation,
    useToggleCardterminalStatusMutation,
    useGetCardterminalNamesQuery,
} from '@/store/features/apiSlice'

function CardTerminal() {
    const [filters, setFilters] = useState({ keyword: '' })
    const [paymentStatus, setPaymentStatus] = useState('active')
    const [logs, setLogs] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)
    const [searchRecipient, setSearchRecipient] = useState('')
    const [recipientName, setRecipientName] = useState('')


    const logsPerPage = 10
    const [fetchFilteredProducts, { isLoading }] = useGetCardTerminalMutation()
    const [toggleCardterminalStatus] = useToggleCardterminalStatusMutation()

    const { data: RecipientResults } = useGetCardterminalNamesQuery(searchRecipient, {
        skip: searchRecipient.length < 2,
    })
    const orderOptions =
        RecipientResults?.map((order) => ({
            label: `${order.name}`,
        })) || []

    function getPageWindow(current, total, width = 5) {
        const w = Math.max(1, width)
        const half = Math.floor(w / 2)

        let start = Math.max(1, current - half)
        let end = Math.min(total, start + w - 1)
        start = Math.max(1, end - w + 1)

        return Array.from({ length: end - start + 1 }, (_, i) => start + i)
    }

    const debouncedSearchRecipient = debounce((value) => {
        setSearchRecipient(value)
    }, 300)

    const fetchLogs = async (page) => {
        setLoading(true)
        try {
            const res = await fetchFilteredProducts({
                page,
                limit: logsPerPage,
                keyword: filters.keyword,
                status: paymentStatus,



            }).unwrap()

            setLogs(res.restaurant_tables || [])
            setTotalPages(res.totalPages || 1)
            setCurrentPage(page)

        } catch (err) {
            console.error('Failed to fetch products:', err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchLogs(1)
    }, [])

    const handlePageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalPages) return
        setCurrentPage(pageNumber)
        fetchLogs(pageNumber)
    }

    const handleToggleStatus = async (id) => {
        const material = logs.find((m) => m.id === id)
        if (!material) return

        const newStatus =
            material.status === 'active' ? 'inactive' : 'active'

        const result = await Swal.fire({
            title: `Confirm Status Change`,
            html: `
      Are you sure you want to 
      <strong>${newStatus}</strong> 
      the restaurant name <strong>${material.name}</strong>?
      <br/><br/>
    `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: `Yes, ${newStatus}`,
            cancelButtonText: 'Cancel',
            reverseButtons: true,
        })

        if (!result.isConfirmed) return

        try {
            await toggleCardterminalStatus({
                id,
                status: newStatus,
            }).unwrap()

            Swal.fire('Success', 'Status updated successfully!', 'success')

            // Update UI instantly
            setLogs((prevLogs) =>
                prevLogs.map((m) =>
                    m.id === id
                        ? { ...m, status: newStatus }
                        : m
                )
            )
        } catch (error) {
            console.error('Failed to update status:', error)
            Swal.fire('Error', 'Failed to update status.', 'error')
        }
    }

    const getPaginationRange = () => {
        const maxVisiblePages = 7
        let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
        let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(endPage - maxVisiblePages + 1, 1)
        }
        return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
    }


    return (
        <Row className="justify-content-center">
            <Col>
                <Card>
                    <CardBody>
                        <Form className="row g-3 mb-3">
                            <FormGroup className="col-md-4">
                                <FormLabel>Keyword</FormLabel>
                                <Select
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderRadius: '999px',
                                            borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                                            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                                        }),
                                    }}
                                    options={orderOptions}
                                    onInputChange={(value, { action }) => {
                                        if (action === 'input-change') {
                                            // Typing
                                            debouncedSearchRecipient(value)
                                            setSearchRecipient(value)
                                            setRecipientName(value)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: value,
                                            }))
                                        }
                                    }}
                                    onChange={(option) => {
                                        if (option) {
                                            const name = option.label?.split('(')[0].trim()
                                            setRecipientName(name)
                                            setSearchRecipient(name)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: name,
                                            }))
                                        } else {
                                            setRecipientName('')
                                            setSearchRecipient('')
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: '',
                                            }))
                                        }
                                    }}
                                    placeholder="ID, Name"
                                    isClearable
                                    isSearchable
                                    value={recipientName ? { label: recipientName, value: recipientName } : null}
                                    components={{
                                        DropdownIndicator: null,
                                    }}
                                />
                            </FormGroup>
                            <FormGroup className="col-md-3">
                                <FormLabel>Status</FormLabel>
                                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                                    <option value="">All</option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>

                                </Form.Select>
                            </FormGroup>
                            <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                                    Search
                                </Button>
                            </FormGroup>
                        </Form>

                        {isLoading || loading ? (
                            <p>Loading raw materials...</p>
                        ) : (
                            <>
                                <Table striped className="table mb-0">
                                    <thead className="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Account Name</th>
                                            <th>Mac Address</th>
                                            <th>Outlet</th>
                                            <th>Status</th>
                                            <th className="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {logs.length === 0 ? (
                                            <tr>
                                                <td colSpan="6" className="text-center">
                                                    No raw materials found.
                                                </td>
                                            </tr>
                                        ) : (
                                            logs.map((item) => (
                                                <tr key={item.id}>
                                                    <td>{item.id}</td>
                                                    <td>{item.name || '-'}</td>
                                                    <td>{item.account_name || '-'}</td>
                                                    <td>{item.mac_address || '-'}</td>
                                                    <td>{item.outlet_name || '-'}</td>
                                                    <td>
                                                        <span
                                                            className={`badge ${item.status === 'active' ? 'bg-success' : 'bg-danger'
                                                                }`}
                                                        >
                                                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                                                        </span>
                                                    </td>
                                                    <td className="text-end">
                                                        <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                                                            <Button
                                                                className="d-flex align-items-center justify-content-center"
                                                                style={{
                                                                    minWidth: 'auto',
                                                                    padding: '0.3rem 0.6rem',
                                                                    fontSize: '0.65rem',
                                                                    height: '30px',
                                                                    borderRadius: '15px',
                                                                    color: '#fff',
                                                                    backgroundColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                                                    borderColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                                                    flex: 1,
                                                                }}
                                                                onClick={() => handleToggleStatus(item.id)}
                                                                title={item.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                                                                <IconifyIcon
                                                                    icon={item.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                                                    style={{ fontSize: '20px', marginRight: '4px' }}
                                                                />
                                                                <span>{item.status === 'active' ? 'Active' : 'Inactive'}</span>
                                                            </Button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </Table>
                                {totalPages > 1 && (
                                    <nav aria-label="Page navigation" className="mt-3 w-100">
                                        <ul className="pagination justify-content-end mb-0">
                                            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                                                <button className="page-link" onClick={() => handlePageChange(Math.max(1, currentPage - 1))} disabled={currentPage === 1}>
                                                    Previous
                                                </button>
                                            </li>

                                            {getPageWindow(currentPage, totalPages, 5).map((page) => (
                                                <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                                                    <button className="page-link" onClick={() => handlePageChange(page)}>
                                                        {page}
                                                    </button>
                                                </li>
                                            ))}

                                            <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                                                <button
                                                    className="page-link"
                                                    onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                                                    disabled={currentPage === totalPages}>
                                                    Next
                                                </button>
                                            </li>
                                        </ul>
                                    </nav>
                                )}
                            </>
                        )}
                    </CardBody>
                </Card>
            </Col>
        </Row>
    )
}

export default CardTerminal
