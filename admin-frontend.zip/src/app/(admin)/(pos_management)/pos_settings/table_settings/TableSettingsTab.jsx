'use client'

import { useState } from 'react'
import { Row, Col, Form, Button, Card, Modal } from 'react-bootstrap'
import { useFieldArray } from 'react-hook-form'

const TableSettingsTab = ({ register, control, handleSubmit, onSubmit }) => {
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'tables',
  })

  const [showModal, setShowModal] = useState(false)
  const [tempTable, setTempTable] = useState({
    name: '',
    chairs: 4,
  })

  const handleAddTable = () => {
    if (!tempTable.name) return

    append(tempTable)
    setTempTable({ name: '', chairs: 4 })
    setShowModal(false)
  }

  return (
    <>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row className="gy-3 p-2">

          {/* Add Table Button */}
          <Col xs={12} className="text-end">
            <Button
              variant="outline-success"
              onClick={() => setShowModal(true)}
            >
              + Add Table
            </Button>
          </Col>

          {/* Table Cards */}
          {fields.length === 0 && (
            <Col xs={12} className="text-muted text-center">
              No tables added yet
            </Col>
          )}

          {fields.map((field, index) => (
            <Col md={4} key={field.id}>
              <Card className="shadow-sm border-0">
                <Card.Body>
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <strong>{field.name || `Table ${index + 1}`}</strong>
                    <Button
                      size="sm"
                      variant="outline-danger"
                      onClick={() => remove(index)}
                    >
                      ✕
                    </Button>
                  </div>

                  <div className="text-muted small">
                    Chairs: {field.chairs}
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}

          {/* Save */}
          <Col xs={12} className="text-end mt-4">
            <Button className="btn bg-primary px-3" type="submit">
              Save Table Settings
            </Button>
          </Col>
        </Row>
      </Form>

      {/* ADD TABLE MODAL */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add Table</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Table Name</Form.Label>
            <Form.Control
              placeholder="Ex: Table 1, VIP"
              value={tempTable.name}
              onChange={(e) =>
                setTempTable({ ...tempTable, name: e.target.value })
              }
            />
          </Form.Group>

          <Form.Group>
            <Form.Label>Number of Chairs</Form.Label>
            <Form.Control
              type="number"
              min={1}
              value={tempTable.chairs}
              onChange={(e) =>
                setTempTable({ ...tempTable, chairs: Number(e.target.value) })
              }
            />
          </Form.Group>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button variant="success" onClick={handleAddTable}>
            Add Table
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default TableSettingsTab
