import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Pos Settings',
}

const PosSettings = dynamic(() => import('./PosSettings'), { ssr: false })

export default function PosSettingsPage() {
  return <PosSettings />
}