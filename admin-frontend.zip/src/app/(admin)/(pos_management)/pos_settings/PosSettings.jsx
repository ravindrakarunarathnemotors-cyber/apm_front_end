'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Tabs, Tab } from 'react-bootstrap'
import { useEffect, useState } from 'react'
import Swal from 'sweetalert2'
import ComponentContainerCard from '@/components/ComponentContainerCard'

import { useGetPosSettingsQuery, useUpdatePosSettingsMutation } from '../../../../../src/store/features/apiSlice'

// Tab components
import GeneralSettingsTab from './general_settings/GeneralSettingsTab'
import TableSettingsTab from './table_settings/TableSettingsTab'

// Yup validation schema (minimal)
const schema = yup.object().shape({
  default_timezone: yup.string().required(),
  date_format: yup.string().required(),
  currency: yup.string().required(),
  default_country: yup.string().required(),
})

const PosSettings = () => {
  const [activeTab, setActiveTab] = useState('general')
  const [updatePosSettings] = useUpdatePosSettingsMutation()

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    control,
    watch,
    setValue,
  } = useForm({
    defaultValues: {
      sound_enabled: false,
      restaurant_mode: false,
    },
  })

  const isRestaurantMode = watch('restaurant_mode')

  const { data: posData, isLoading } = useGetPosSettingsQuery()
  console.log('first', posData)

  useEffect(() => {
    if (!posData?.data) return

    setValue('restaurant_mode', posData.data.restaurant_mode)
    setValue('sound_enabled', posData.data.sound)
    setValue('quantity_dialog', posData.data.quantity_dialog)
    setValue('scan_code', posData.data.scan_code)
    setValue('web_url', posData.data.web_url || '')
    setValue('printing_mode', posData.data.printing_mode)
    if (posData.data?.return_policy) {
      const returnPolicyArray = posData.data.return_policy

      const returnPolicyText = Array.isArray(returnPolicyArray)
        ? returnPolicyArray.join('\n')
        : ''

      setValue('return_policy', returnPolicyText)
    }
  }, [posData, setValue])

  const termsText = watch('terms_conditions_quotations') || ''

  const onSubmit = async (formData) => {
    try {
      const payload = {
        sound: formData.sound_enabled,
        restaurant_mode: formData.restaurant_mode,
        quantity_dialog: formData.quantity_dialog,
        scan_code: formData.scan_code,
        printing_mode: formData.printing_mode,
        logo_url: formData.logo_url || null,
        web_url: formData.web_url || null,
        return_policy: formData.return_policy
          ? formData.return_policy
            .split('\n')
            .map((l) => l.trim())
            .filter(Boolean)
          : null,
      }

      await updatePosSettings(payload).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: 'POS settings updated successfully!',
      })
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Update failed',
      })
    }
  }

  if (isLoading) return <div>Loading POS settings...</div>

  return (
    <ComponentContainerCard title="POS Settings">
      <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k || 'general')} className="my-2">
        <Tab eventKey="general" title="General">
          <GeneralSettingsTab register={register} handleSubmit={handleSubmit} errors={errors} onSubmit={onSubmit} watch={watch} setValue={setValue} posData={posData}/>
        </Tab>

        {/* {isRestaurantMode && (
          <Tab eventKey="tables" title="Tables">
            <TableSettingsTab register={register} control={control} handleSubmit={handleSubmit} onSubmit={onSubmit} />
          </Tab>
        )} */}
      </Tabs>
    </ComponentContainerCard>
  )
}

export default PosSettings
