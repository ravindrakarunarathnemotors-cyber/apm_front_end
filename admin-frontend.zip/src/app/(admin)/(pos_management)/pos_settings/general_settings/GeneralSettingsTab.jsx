'use client'

import { Form, Row, Col, Button, FormLabel, FormCheck, FormControl, ListGroup, Spinner } from 'react-bootstrap'
import { useRef, useState, useEffect } from 'react'

const GeneralSettingsTab = ({ register, handleSubmit, errors, onSubmit, watch, setValue, posData }) => {
  const returnPolicyText = watch('return_policy') || ''
  console.log(returnPolicyText)
  const logoInputRef = useRef(null)
  const [logoPreview, setLogoPreview] = useState(null)
  const [uploadingLogo, setUploadingLogo] = useState(false)

  useEffect(() => {
    if (!posData || !posData.data || !posData.data.logo_url) return
    setLogoPreview(posData.data.logo_url)
  }, [posData])


  /* ---------------- helpers ---------------- */

  const toBullets = (text) =>
    String(text ?? '')
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean)

  const returnPoints = toBullets(returnPolicyText)

  const triggerLogoSelect = () => {
    if (!uploadingLogo) logoInputRef.current?.click()
  }

  /* ---------------- LOGO UPLOAD ---------------- */

  const handleLogoChange = async (e) => {
    const file = e.target.files?.[0]
    if (!file || uploadingLogo) return

    setUploadingLogo(true)

    // local preview immediately
    setLogoPreview(URL.createObjectURL(file))

    const formData = new FormData()
    formData.append('files', file)

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/pos-sub/upload-media`, {
        method: 'POST',
        body: formData,
      })

      const data = await res.json()

      // ONLY rule: success === true
      if (data?.success === true && data?.data?.[0]?.url) {
        const uploadedUrl = data.data[0].url

        // replace preview with CDN URL
        setLogoPreview(uploadedUrl)

        // IMPORTANT: must be registered to be submitted
        setValue('logo_url', uploadedUrl, { shouldDirty: true })
      }
    } catch (e) {
      // do NOT lie to user — upload already succeeded server-side
      console.error('Upload request error:', e)
    } finally {
      setUploadingLogo(false)
      if (logoInputRef.current) logoInputRef.current.value = ''
    }
  }

  /* ---------------- render ---------------- */

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <Row className="gy-3 p-2">
        {/* REQUIRED hidden registered field */}
        <input type="hidden" {...register('logo_url')} />

        {/* Sound Toggle */}
        <Col md={6}>
          <FormLabel>Sound</FormLabel>
          <FormCheck type="switch" id="sound-enabled" label="Enable sound notifications" {...register('sound_enabled')} />
        </Col>

        {/* Restaurant Mode Toggle */}
        <Col md={6}>
          <FormLabel>Restaurant Mode</FormLabel>
          <FormCheck type="switch" id="restaurant-mode" label="Enable restaurant mode (Tables, dine-in)" {...register('restaurant_mode')} />
        </Col>

        <Col md={6}>
          <FormLabel>Quantity Dialog</FormLabel>
          <FormCheck type="switch" id="quantity-dialog" label="Enable quantity dialog" {...register('quantity_dialog')} />
        </Col>

        <Col md={6}>
          <FormLabel>Scan Code</FormLabel>
          <Form.Select {...register('scan_code')} style={{ width: '150px' }}>
            <option value="variant">Variant</option>
            <option value="product">Product</option>
            <option value="barcode">Barcode</option>
            <option value="all">All</option>
          </Form.Select>
        </Col>
        {/* WEB URL */}
        <Col md={6}>
          <FormLabel className="fw-semibold">Web URL</FormLabel>
          <FormControl
            type="text"
            placeholder="https://yourwebsite.com"
            {...register('web_url')}
            onChange={(e) => {
              let value = e.target.value

              // If user starts typing and no protocol → add https://
              if (value && !value.startsWith('http://') && !value.startsWith('https://')) {
                value = 'https://' + value
              }

              setValue('web_url', value, { shouldDirty: true })
            }}
          />
        </Col>
        <Col md={6}>
          <FormLabel>Printing Mode</FormLabel>
          <Form.Select {...register('printing_mode')} style={{ width: '150px' }}>
            <option value="basic">Basic</option>
            <option value="advanced">Advanced</option>
          </Form.Select>
        </Col>

        {/* RETURN POLICY */}
        <Col md={6} className="mt-3">
          <FormLabel className="fw-semibold">Return Policy</FormLabel>
          <FormControl as="textarea" rows={6} placeholder="Each new line becomes a bullet point" {...register('return_policy')} />

          <div className="mt-2">
            <strong>Preview:</strong>
            <ListGroup className="mt-1">
              {returnPoints.length ? (
                returnPoints.map((t, i) => <ListGroup.Item key={i}>• {t}</ListGroup.Item>)
              ) : (
                <div className="text-muted small">No return policy added.</div>
              )}
            </ListGroup>
          </div>
        </Col>

        {/* LOGO */}
        <Col md={6} className="mt-3">
          <FormLabel className="fw-semibold">Invoice Logo</FormLabel>

          {logoPreview ? (
            <img
              src={logoPreview}
              alt="Logo preview"
              style={{
                maxWidth: '100%',
                maxHeight: '120px',
                objectFit: 'contain',
                marginBottom: '0.75rem',
              }}
            />
          ) : (
            <div
              style={{
                height: '120px',
                border: '1px dashed #ccc',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '0.75rem',
                color: '#999',
                fontSize: '0.85rem',
              }}>
              No image
            </div>
          )}

          <input type="file" accept="image/*" ref={logoInputRef} style={{ display: 'none' }} onChange={handleLogoChange} />

          <Button variant="outline-primary" size="sm" onClick={triggerLogoSelect} disabled={uploadingLogo}>
            {uploadingLogo ? (
              <>
                <Spinner animation="border" size="sm" /> Uploading…
              </>
            ) : logoPreview ? (
              'Replace Image'
            ) : (
              'Upload Image'
            )}
          </Button>
        </Col>

        {/* SAVE */}
        <Col md={12} className="text-end mt-4">
          <Button type="submit" className="btn bg-primary px-3" disabled={uploadingLogo}>
            {uploadingLogo ? 'Uploading…' : 'Save General Settings'}
          </Button>
        </Col>
      </Row>
    </Form>
  )
}

export default GeneralSettingsTab
