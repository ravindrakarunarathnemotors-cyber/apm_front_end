'use client';
import { useState } from "react";
import { Modal, Button, Form, Card, Row, Col } from "react-bootstrap";
import { useRouter } from 'next/navigation'
import Swal from "sweetalert2";

export default function PermissionManager() {
    const router = useRouter();

    const [password, setPassword] = useState("");
    const [isAuthorized, setIsAuthorized] = useState(false);
    const [loading, setLoading] = useState(false);

    // 🔐 Hardcoded password
    const CORRECT_PASSWORD = "kalana@123";

    // 📋 Menu Array
    const menuItems = [
        { id: 1, name: "Navigation Order", route: "/menu_items" },
        { id: 2, name: "Same Page", route: "#" },
    ];

    // 🔹 Password check
    const handleVerifyPassword = async () => {
        if (!password) {
            Swal.fire({
                icon: "error",
                title: "Access Denied",
                text: "Password is required.",
                confirmButtonColor: "#d33",
            })
            return;
        }

        setLoading(true);
        // try {
        //     const res = await axios.post("http://localhost:5000/login", {
        //         password: password
        //     });

        //     if (res.status === 200) {
        //         setIsAuthorized(true);
        //     } else {
        //         Swal.fire({
        //             icon: "error",
        //             title: "Access Denied",
        //             text: "Incorrect password. Try again.",
        //             confirmButtonColor: "#d33",
        //         });
        //     }
        // } catch (err) {
        //     console.error(err);
        // } finally {
        //     setLoading(false);
        // }

        setTimeout(async () => {
            if (password === CORRECT_PASSWORD) {
                setIsAuthorized(true);

                await Swal.fire({
                    icon: "success",
                    title: "Access Granted",
                    text: "Welcome!",
                    timer: 1500,
                    showConfirmButton: false,
                });

            } else {
                await Swal.fire({
                    icon: "error",
                    title: "Access Denied",
                    text: "Incorrect password. Try again.",
                    confirmButtonColor: "#d33",
                });
            }

            setLoading(false);
            setPassword("");
        }, 500);
    };

    return (
        <>
            {/* 🔐 PASSWORD MODAL */}
            <Modal show={!isAuthorized} centered backdrop="static">
                <Modal.Body className="text-center p-4">
                    <h5 className="fw-bold mb-3">🔐 Secure Access</h5>

                    <p className="text-muted small mb-3">
                        Enter password to continue
                    </p>

                    <Form.Control
                        type="password"
                        placeholder="Enter password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="mb-3"
                        onKeyDown={(e) => e.key === "Enter" && handleVerifyPassword()}
                    />

                    <Button
                        className="w-100"
                        onClick={handleVerifyPassword}
                        disabled={loading}
                    >
                        {loading ? "Checking..." : "Unlock"}
                    </Button>
                </Modal.Body>
            </Modal>

            {/* ================= MAIN UI ================= */}
            {isAuthorized && (
                <div className="p-3">

                    <Card className="shadow-sm">
                        <Card.Header className="fw-bold">
                            Menu
                        </Card.Header>

                        <Card.Body>
                            <Row>
                                {menuItems.map((item) => (
                                    <Col md={6} key={item.id} className="mb-3">
                                        <div className="border rounded-3 p-3 d-flex justify-content-between align-items-center">

                                            <strong>{item.name}</strong>

                                            <Button
                                                size="sm"
                                                variant="primary"
                                                onClick={() => router.push(item.route)}
                                            >
                                                Open →
                                            </Button>

                                        </div>
                                    </Col>
                                ))}
                            </Row>
                        </Card.Body>
                    </Card>

                </div>
            )}
        </>
    );
}