'use client'

import React from 'react'
import { Col, Row } from 'react-bootstrap'
import Stats from './components/Stats'
import ProductTrendsChart from './components/ProductTrendsChart'
import DeliveryInsights from './components/DeliveryInsights'
import RecentOrders from './components/RecentOrders'
import StockTable from './components/StockTable'
import CustomerSection from './components/CustomerSection'
import ReviewSection from './components/ReviewSection'
import MovingReport from './components/MovingReport'
import RecentInvoices from './components/RecentInvoices'
import UpcomingLeaves from './components/UpcomingLeaves'

import { useGetDashboardWidgetsQuery } from '@/store/features/apiSlice'

const CARD_HEIGHT = 360

const AnalyticDashboardClient = () => {
  const { data, isLoading } = useGetDashboardWidgetsQuery()

  // 🔹 Convert API → map (package + enabled)
  const widgetMap = {}
  if (data?.widgets) {
    data.widgets.forEach((w) => {
      const key = w.name.toLowerCase().replace(/\s+/g, '_')

      widgetMap[key] = {
        enabled: w.is_enabled === true,
        package: w.package === true,
      }
    })
  }

  if (isLoading) return null

  // 🔥 Helper: final visibility rule
  const canShow = (key) => {
    const w = widgetMap[key]
    return w && w.package && w.enabled
  }

  // 🔥 Build widget list
  const widgets = []

  if (canShow('operation_overview')) {
    widgets.push({
      key: 'operation_overview',
      component: <Stats />,
      full: true,
    })
  }

  if (canShow('orders_trend')) {
    widgets.push({ key: 'orders_trend', component: <ProductTrendsChart /> })
  }

  if (canShow('delivery_insights')) {
    widgets.push({
      key: 'delivery_insights',
      component: <DeliveryInsights compact />,
    })
  }

  if (canShow('recent_orders')) {
    widgets.push({ key: 'recent_orders', component: <RecentOrders /> })
  }

  if (canShow('stock_status')) {
    widgets.push({
      key: 'stock_status',
      component: <StockTable minHeight={CARD_HEIGHT} />,
    })
  }

  if (canShow('top_customers')) {
    widgets.push({ key: 'top_customers', component: <CustomerSection /> })
  }

  if (canShow('recent_reviews')) {
    widgets.push({ key: 'recent_reviews', component: <ReviewSection /> })
  }

  if (canShow('recent_invoices')) {
    widgets.push({
      key: 'recent_invoices',
      component: <RecentInvoices />,
    })
  }

  if (canShow('moving_report')) {
    widgets.push({
      key: 'moving_report',
      component: <MovingReport />,
    })
  }

  if (canShow('upcoming_leaves')) {
    widgets.push({
      key: 'upcoming_leaves',
      component: <UpcomingLeaves />,
    })
  }

  return (
    <>
      {/* FULL WIDTH */}
      {widgets
        .filter((w) => w.full)
        .map((w) => (
          <div key={w.key}>{w.component}</div>
        ))}

      {/* GRID */}
      <Row className="g-3 mb-4">
        {widgets
          .filter((w) => !w.full)
          .map((w) => (
            <Col key={w.key} xs={12} md={6} className="d-flex align-items-stretch">
              <div
                className="w-100 d-flex flex-column h-100"
                style={{
                  minHeight: CARD_HEIGHT,
                  height: '100%',
                }}>
                <div className="flex-grow-1">{w.component}</div>
              </div>
            </Col>
          ))}
      </Row>
    </>
  )
}

export default function Page() {
  return <AnalyticDashboardClient />
}
