import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Dashboard',
}


const AnalyticDashboardClient = dynamic(() => import('./AnalyticDashboardClient'), { ssr: false })

export default function AnalyticDashboardClientPage() {
  return <AnalyticDashboardClient />
}