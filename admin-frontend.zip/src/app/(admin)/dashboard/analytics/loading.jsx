'use client';

import React from 'react';
import { Row, Col, Card, CardBody } from 'react-bootstrap';

const SkeletonLine = ({ w = '100%', h = 12, className = '' }) => (
  <div className={`sk-line ${className}`} style={{ width: w, height: h }} />
);

const Box = ({ height = 120, className = '' }) => (
  <Card className={`shadow-sm border-0 ${className}`} style={{ minHeight: height }}>
    <CardBody>
      <SkeletonLine w="60%" h={12} />
      <SkeletonLine w="40%" h={10} className="mt-2" />
      <SkeletonLine w="90%" h={10} className="mt-3" />
      <SkeletonLine w="70%" h={10} className="mt-2" />
    </CardBody>
  </Card>
);

export default function Loading() {
  return (
    <>
      {/* Stats skeleton row (5 compact cards) */}
      <Row className="g-3 mt-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <Col key={i} xs={12} sm={6} md={6} lg={2} className="d-flex w-100">
            <Card className="shadow-sm border-0 w-100" style={{ minHeight: 90 }}>
              <CardBody className="py-3">
                <SkeletonLine w="55%" h={10} />
                <SkeletonLine w="30%" h={10} className="mt-2" />
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>

      {/* Row 1: Sales Trend + Customer Insights */}
      <Row className="g-3 align-items-stretch mt-3">
        <Col md={6} lg={8} className="d-flex">
          <Box height={340} className="w-100" />
        </Col>
        <Col md={6} lg={4} className="d-flex">
          <Box height={290} className="w-100" />
        </Col>
      </Row>

      {/* Row 2: Recent Orders + Stock Status (same height) */}
      <Row className="g-3 align-items-stretch mt-3">
        <Col xs={12} md={6} className="d-flex">
          <Box height={360} className="w-100" />
        </Col>
        <Col xs={12} md={6} className="d-flex">
          <Box height={360} className="w-100" />
        </Col>
      </Row>

      {/* Row 3: Top Customers + Recent Reviews (same height) */}
      <Row className="g-3 align-items-stretch mt-3">
        <Col xs={12} md={6} className="d-flex">
          <Box height={320} className="w-100" />
        </Col>
        <Col xs={12} md={6} className="d-flex">
          <Box height={320} className="w-100" />
        </Col>
      </Row>

      {/* Shimmer CSS */}
      <style jsx global>{`
        .sk-line {
          display: block;
          border-radius: 6px;
          background: linear-gradient(
            90deg,
            rgba(0,0,0,0.06) 25%,
            rgba(0,0,0,0.12) 37%,
            rgba(0,0,0,0.06) 63%
          );
          background-size: 400% 100%;
          animation: sk-wave 1.2s ease-in-out infinite;
        }
        @keyframes sk-wave {
          0% { background-position: 100% 0; }
          100% { background-position: 0 0; }
        }
      `}</style>
    </>
  );
}
