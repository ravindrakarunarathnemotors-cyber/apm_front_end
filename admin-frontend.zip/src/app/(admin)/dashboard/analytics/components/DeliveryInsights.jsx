'use client'

import { useEffect, useRef, useState, useMemo } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Row, Col, Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Badge } from 'react-bootstrap'
import Chart from 'chart.js/auto'
import { useGetDeliveryInsightsMutation } from '@/store/features/apiSlice'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import HelpModal from './HelpModal'
const WEEK_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const MONTH_LABELS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

// Be tolerant of different partner field names
const getPartnerId = (p) => p?.id ?? p?.d_partner_id ?? p?.partner_id ?? p?.delivery_partner_id ?? null

const getPartnerName = (p) => p?.name ?? p?.partner_name ?? p?.company_name ?? p?.outlet_name ?? `Partner ${getPartnerId(p) ?? ''}`

export default function DeliveryInsightsChart({ height = 300 }) {
  const canvasRef = useRef(null)
  const chartRef = useRef(null)

  // Default exactly what you want to send first time:
  // { delivery_partner_id: 2, range: 'month' }
  //const [partnerId, setPartnerId] = useState(2)
  const [partnerId, setPartnerId] = useState(null)
  const [range, setRange] = useState('month')
  const [showHelp, setShowHelp] = useState(false)
  const [helpContext, setHelpContext] = useState(null)
  const [helpHover, setHelpHover] = useState(false)
  const [partners, setPartners] = useState([])

  const [getDeliveryInsights, { data, isLoading, isError }] = useGetDeliveryInsightsMutation()

  // Fetch partners on mount
  useEffect(() => {
    const fetchPartners = async () => {
      try {
        const token = sessionStorage.getItem('access_token')
        const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/delivery-management-sub/active-delivery-partners`, {
          headers: { Authorization: `Bearer ${token}` },
        })
        const json = await res.json()
        const list = Array.isArray(json) ? json : []
        setPartners(list)
        console.log('partner list:', list)
      } catch (err) {
        console.error('Failed to fetch partners', err)
        setPartners([])
      }
    }
    fetchPartners()
  }, [])
  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }
  // useEffect(() => {
  //   const fetchPartners = async () => {
  //     try {
  //       const token = sessionStorage.getItem('access_token')
  //       const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/delivery-management-sub/active-delivery-partners`, {
  //         headers: { Authorization: `Bearer ${token}` },
  //       })
  //       const json = await res.json()
  //       const list = Array.isArray(json) ? json : []
  //       setPartners(list)
  //       console.log('partner list:', list)

  //       // If your default partner (2) doesn't exist, fall back to first partner
  //       if (list.length > 0) {
  //         const ids = list.map(getPartnerId).filter((x) => x != null)
  //         if (!ids.includes(partnerId)) {
  //           setPartnerId(Number(ids[0])) // ensure numeric
  //         }
  //       }
  //     } catch (err) {
  //       console.error('Failed to fetch partners', err)
  //       setPartners([])
  //     }
  //   }
  //   fetchPartners()
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [])

  // Fetch insights whenever filters change — ALWAYS send both keys
  useEffect(() => {
    // ensure numeric or null (never undefined)
    const deliveryPartnerId = partnerId === null || partnerId === undefined || Number.isNaN(Number(partnerId)) ? null : Number(partnerId)

    const payload = {
      delivery_partner_id: deliveryPartnerId,
      range, // 'week' | 'month'
    }

    getDeliveryInsights(payload)
    // console.log('payload ->', payload);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [partnerId, range])

  // Transform API payload -> labels + arrays
  const { labels, completed, returned, appliedRange } = useMemo(() => {
    const result = {
      labels: range === 'week' ? WEEK_LABELS : MONTH_LABELS,
      completed: [],
      returned: [],
      appliedRange: data?.appliedFilters ? `${data.appliedFilters.start_date} → ${data.appliedFilters.end_date}` : null,
    }

    const bucket = range === 'week' ? data?.day_wise_counts : data?.month_wise_counts

    result.labels.forEach((lbl) => {
      const row = bucket?.[lbl] || {}
      const c = Number(row.completed || 0)
      const r = Number(row.returned || 0)
      result.completed.push(Number.isFinite(c) ? c : 0)
      result.returned.push(Number.isFinite(r) ? r : 0)
    })

    return result
  }, [data, range])

  // Build / update chart
  useEffect(() => {
    if (!canvasRef.current || !labels) return

    if (chartRef.current) {
      chartRef.current.destroy()
      chartRef.current = null
    }

    const maxVal = Math.max(...(completed?.length ? completed : [0]), ...(returned?.length ? returned : [0]))
    const yMax = Math.max(10, Math.ceil(maxVal / 2) * 2)
    const stepSize = yMax > 10 ? Math.ceil(yMax / 5) : 2

    const cfg = {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Completed',
            data: completed,
            backgroundColor: '#31B757', // green
            borderColor: '#31B757',
            borderWidth: 1,
            borderRadius: 6,
            maxBarThickness: 25,
          },
          {
            label: 'Returned',
            data: returned,
            backgroundColor: '#E53935', // red
            borderColor: '#E53935',
            borderWidth: 1,
            borderRadius: 6,
            maxBarThickness: 25,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { color: '#333', font: { size: 12 } } },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y}`,
            },
          },
        },
        scales: {
          x: { grid: { display: false } },
          y: {
            beginAtZero: true,
            max: yMax,
            ticks: { stepSize, precision: 0 },
            grid: { color: 'rgba(0,0,0,0.05)' },
            title: { display: true, text: 'Order Count' },
          },
        },
        barPercentage: 0.5,
        categoryPercentage: 0.6,
      },
    }

    chartRef.current = new Chart(canvasRef.current, cfg)

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy()
        chartRef.current = null
      }
    }
  }, [labels, completed, returned])

  // Current partner name display
  const currentPartnerName =
    partnerId == null ? 'All Partners' : getPartnerName(partners.find((p) => Number(getPartnerId(p)) === Number(partnerId))) || `Partner ${partnerId}`

  return (
    <Card className="w-100 h-100 d-flex flex-column">
      <CardHeader className="py-3">
        <Row className="align-items-center g-2">
          <Col>
            <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-2">
              <span className="d-flex align-items-center">Delivery Insights</span>

              <IconifyIcon
                icon="mdi:help-circle-outline"
                style={{
                  fontSize: helpHover ? '20px' : '18px',
                  cursor: 'pointer',
                  color: helpHover ? '#0d6efd' : '#6c757d',
                  transition: 'all 0.18s ease',
                  display: 'flex',
                  alignItems: 'center',
                }}
                onMouseEnter={() => setHelpHover(true)}
                onMouseLeave={() => setHelpHover(false)}
                onClick={() => openHelp('delivery_insights_chart')}
              />
            </CardTitle>
            {appliedRange && (
              <div className="mt-1">
                <Badge bg="light" text="dark">
                  {appliedRange}
                </Badge>
              </div>
            )}
          </Col>
          <Col xs="auto" className="d-flex gap-2">
            {/* Partner filter (from API) */}
            <Dropdown>
              <DropdownToggle className="btn btn-light btn-sm">{currentPartnerName}</DropdownToggle>
              <DropdownMenu align="end" style={{ maxHeight: 320, overflowY: 'auto' }}>
                <DropdownItem active={partnerId == null} onClick={() => setPartnerId(null)}>
                  All Partners
                </DropdownItem>
                {partners.map((p) => {
                  const id = Number(getPartnerId(p))
                  const name = getPartnerName(p)
                  return (
                    <DropdownItem
                      key={`${id}-${name}`}
                      active={Number(partnerId) === id}
                      onClick={() => setPartnerId(id)} // ensure numeric
                    >
                      {name}
                    </DropdownItem>
                  )
                })}
              </DropdownMenu>
            </Dropdown>

            {/* Range filter */}
            <Dropdown>
              <DropdownToggle className="btn btn-light btn-sm">{range === 'week' ? 'Week' : 'Month'}</DropdownToggle>
              <DropdownMenu align="end">
                <DropdownItem active={range === 'week'} onClick={() => setRange('week')}>
                  Week
                </DropdownItem>
                <DropdownItem active={range === 'month'} onClick={() => setRange('month')}>
                  Month
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </Col>
        </Row>
      </CardHeader>

      <CardBody className="d-flex flex-column p-3">
        <div className="position-relative mt-3" style={{ height }}>
          <canvas ref={canvasRef} />
        </div>

        {isLoading && <div className="position-absolute top-50 start-50 translate-middle text-muted">Loading…</div>}

        {isError && <div className="position-absolute top-50 start-50 translate-middle text-danger">Failed to load</div>}

        {/* -----------------------------
     HELP NOTICE (COMPACT)
  ------------------------------*/}
        {/* {showHelp && (
  <div
    className="px-3 py-2 mt-2"
    style={{
      border: '1px solid #dee2e6',
      borderRadius: '6px',
      background: '#f8f9fa',
      fontSize: '0.75rem',
      lineHeight: '1.3',
    }}
  >
    <div className="text-muted">
      <strong className="text-dark">Chart Guide:</strong> This chart displays delivery performance for the selected
      partner and time range. Green bars represent completed deliveries while red bars indicate returned deliveries.
      You can filter the data by delivery partner and view trends either weekly or monthly.
    </div>
  </div>
)} */}

        <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
      </CardBody>
    </Card>
  )
}
