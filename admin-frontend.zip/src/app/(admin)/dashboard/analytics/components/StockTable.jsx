'use client'

import { useRouter } from 'next/navigation'
import { Card, CardHeader, CardTitle, CardBody, Table, Placeholder, Badge, Button } from 'react-bootstrap'
import { useGetRecentStocksQuery } from '@/store/features/apiSlice' // keep existing hook
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useState } from 'react'
import HelpModal from './HelpModal'
// Map quantities to a reorder-status badge
const getReorderBadge = (qty, reorder) => {
  const r = reorder ?? 0 // default null to 0
  if (qty <= 0) return { text: 'Out of Stock', variant: 'danger' }
  if (qty <= r) return { text: 'Reached', variant: 'warning' }
  if (qty <= Math.ceil(r * 1.2)) return { text: 'Near to Reach', variant: 'info' }
  return { text: 'In Stock', variant: 'success' }
}

// Skeleton loader
const RowSkeleton = ({ count = 5 }) => (
  <tbody>
    {Array.from({ length: count }).map((_, i) => (
      <tr key={`sk-${i}`}>
        {[260, 140, 180].map((w, j) => (
          <td key={j}>
            <Placeholder as="div" animation="wave" className="mb-0">
              <Placeholder xs={Math.max(4, Math.min(12, Math.floor(w / 20)))} />
            </Placeholder>
          </td>
        ))}
      </tr>
    ))}
  </tbody>
)

const StockTable = () => {
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  const router = useRouter()
  const { data, isLoading } = useGetRecentStocksQuery()

  const rows = data?.results?.length ? data.results : []
  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  console.log('Received rows:', rows)

  return (
    <Card className="h-100 d-flex flex-column">
      <CardHeader className="py-2 px-3">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">Stock Status</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('stock_status_widget')}
          />
        </CardTitle>
      </CardHeader>

      <CardBody className="pt-2 pb-2 px-3 d-flex flex-column">
        <Table bordered hover responsive size="sm" className="stock-like-recent mb-2 text-center">
          <thead>
            <tr>
              <th className="text-start">Product / Variant</th>
              <th style={{ width: 100 }}>Current Qty</th>
              <th style={{ width: 120 }}>Re-Order Level</th>
            </tr>
          </thead>

          {isLoading ? (
            <RowSkeleton count={5} />
          ) : rows.length > 0 ? (
            <tbody>
              {rows.map((row, idx) => {
                const productTitle = row.product_title
                const variantValue = row.variant_value
                const currentQty = row.current_stock
                const reorderLevel = row.reorder_level ?? 0

                const badge = getReorderBadge(currentQty, reorderLevel)

                return (
                  <tr key={idx}>
                    <td className="text-start text-truncate" style={{ maxWidth: '220px' }}>
                      {productTitle} / {variantValue}
                    </td>
                    <td className="fw-semibold text-end me-1">{currentQty}</td>
                    <td>
                      <Badge bg={badge.variant} className="text-uppercase badge-compact">
                        {badge.text}
                      </Badge>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          ) : (
            <tbody>
              <tr>
                <td colSpan={3} className="text-center text-muted py-4">
                  No low-stock variants
                </td>
              </tr>
            </tbody>
          )}
        </Table>

        {/* -----------------------------
   HELP NOTICE (COMPACT)
------------------------------*/}

        {rows.length > 0 && (
          <div className="d-flex justify-content-end mt-0">
            <Button
              variant="link"
              size="sm"
              className="text-success text-decoration-none p-0 fw-normal"
              onClick={() => router.push('/inventory_status')}>
              Show All
            </Button>
          </div>
        )}
      </CardBody>

      <style jsx global>{`
        .stock-like-recent {
          font-size: 0.8rem;
        }
        .stock-like-recent thead th {
          font-size: 0.82rem;
          background: var(--bs-light);
          font-weight: 600;
          white-space: nowrap; /* Prevent header line breaks */
        }
        .stock-like-recent > :not(caption) > * > * {
          padding: 0.3rem 0.45rem;
          vertical-align: middle;
        }
        .stock-like-recent tbody tr:hover {
          background: rgba(0, 0, 0, 0.02);
        }
        .stock-like-recent tbody td.text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap; /* Keep content on one line */
        }
        .badge-compact {
          font-size: 0.65rem;
          padding: 0.18rem 0.4rem;
          letter-spacing: 0.02em;
        }
      `}</style>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}

export default StockTable
