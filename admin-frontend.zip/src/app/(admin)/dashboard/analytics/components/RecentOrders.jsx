'use client'

import Link from 'next/link'
import { Card, CardHeader, CardTitle, CardBody, Table, Badge, Button } from 'react-bootstrap'
import { useGetRecentOrdersListQuery } from '@/store/features/apiSlice' // RTK hook
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useMemo, useState, useEffect } from 'react'
import HelpModal from './HelpModal'
const STATUS_VARIANTS = {
  Pending: 'warning',
  Confirmed: 'primary',
  Processing: 'primary',
  Completed: 'success',
  Returned: 'danger',
  Cancelled: 'secondary', // or 'danger' if you prefer red
}
// Normalize server status -> UI label
const normalizeStatus = (s) => {
  const v = String(s || '')
    .toLowerCase()
    .trim()

  if (v === 'pending') return 'Pending'
  if (v === 'confirmed') return 'Confirmed'
  if (v === 'processing') return 'Processing'
  if (v === 'completed') return 'Completed'
  if (v === 'returned') return 'Returned'

  // handle cancelled variations
  if (v === 'cancelled' || v === 'canceled') return 'Cancelled'

  return 'Pending'
}
const RecentOrders = () => {
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  // Fetch the latest 10 orders
  const {
    data: apiRows,
    isLoading,
    isError,
  } = useGetRecentOrdersListQuery(15, {
    refetchOnMountOrArgChange: true,
  })
  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }
  return (
    <Card className="recent-orders h-100 d-flex flex-column">
      <CardHeader className="recent-orders__header py-2 px-3">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">Recent Orders</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('recent_orders_table')}
          />
        </CardTitle>
      </CardHeader>

      <CardBody className="recent-orders__body pt-2 pb-2 px-3 d-flex flex-column">
        <div className="recent-orders__table-wrapper">
          <Table bordered hover responsive size="sm" className="recent-orders__table text-center mb-1">
            <thead>
              <tr>
                <th className="recent-orders__col recent-orders__col--id text-start">Order ID</th>
                <th className="recent-orders__col text-start">Customer</th>
                <th className="recent-orders__col recent-orders__col--status">Status</th>
                <th className="recent-orders__col recent-orders__col--price text-end">Price ({apiRows && apiRows[0] && apiRows[0].currency})</th>
              </tr>
            </thead>

            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={4} className="py-4 text-muted">
                    Loading recent orders...
                  </td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan={4} className="py-4 text-muted">
                    Failed to load recent orders
                  </td>
                </tr>
              ) : Array.isArray(apiRows) && apiRows.length > 0 ? (
                apiRows
                  .filter((r) => {
                    const v = String(r.order_status || '')
                      .toLowerCase()
                      .trim()
                    return v !== 'cancelled' && v !== 'canceled'
                  })
                  .map((r) => {
                    const statusLabel = normalizeStatus(r.order_status)
                    const fullName = [r.first_name, r.last_name].filter(Boolean).join(' ') || '—'
                    return (
                      <tr key={r.order_id}>
                        <td className="recent-orders__cell recent-orders__cell--id text-start text-nowrap">#{r.order_id}</td>
                        <td className="recent-orders__cell recent-orders__cell--customer text-truncate text-start">{fullName}</td>
                        <td className="recent-orders__cell recent-orders__cell--status">
                          <Badge bg={STATUS_VARIANTS[statusLabel]} className="recent-orders__badge text-uppercase">
                            {statusLabel}
                          </Badge>
                        </td>
                        <td className="recent-orders__cell recent-orders__cell--price text-end">{parseFloat(r.total_value).toFixed(2)}</td>
                      </tr>
                    )
                  })
              ) : (
                <tr>
                  <td colSpan={4} className="py-4 text-muted">
                    No recent orders
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
        </div>
        {/* -----------------------------
   HELP NOTICE (COMPACT)
------------------------------*/}

        {/* Bottom-right CTA */}
        <div className="d-flex justify-content-end">
          <Button
            as={Link}
            href="/all_orders"
            size="sm"
            variant="link"
            className="recent-orders__cta text-success text-decoration-none p-0 fw-normal">
            Show All
          </Button>
        </div>

        {/* Scoped styles for RecentOrders */}
        <style jsx global>{`
          .recent-orders__table {
            font-size: 0.8rem;
          }

          .recent-orders__table thead th {
            font-size: 0.82rem;
            background: var(--bs-light);
            font-weight: 600;
          }

          .recent-orders__table > :not(caption) > * > * {
            padding: 0.3rem 0.45rem;
            vertical-align: middle;
          }

          .recent-orders__table tbody tr:hover {
            background: rgba(0, 0, 0, 0.02);
          }

          .recent-orders__col--id {
            width: 120px;
          }
          .recent-orders__col--status {
            width: 130px;
          }
          .recent-orders__col--price {
            width: 140px;
          }

          .recent-orders__cell {
            font-size: 0.8rem;
          }

          .recent-orders__badge {
            font-size: 0.65rem;
            padding: 0.18rem 0.4rem;
            letter-spacing: 0.02em;
          }

          .recent-orders__cta {
            font-size: 0.78rem;
            padding: 0.3rem 0.6rem;
            border-radius: 999px;
          }
        `}</style>
      </CardBody>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}

export default RecentOrders
