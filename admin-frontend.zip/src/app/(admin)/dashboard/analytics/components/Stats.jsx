'use client'

import { useState } from 'react'
import {
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Row,
  Col,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Modal,
  Button,
  Form,
} from 'react-bootstrap'

import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import { useGetOrderSummaryQuery, useGetDashboardCardsRangeQuery, useGetSystemGlobalSettingsQuery } from '@/store/features/apiSlice'
import HelpModal from './HelpModal'

const RANGE_LABELS = {
  today: 'Today',
  weekly: 'Week',
  monthly: 'Month',
  '3months': '3 Months',
  '6months': '6 Months',
  annual: 'Annual',
  custom: 'Custom',
}

const formatDate = (date) => {
  const d = new Date(date)

  const day = String(d.getDate()).padStart(2, '0')

  const month = d.toLocaleString('en-GB', {
    month: 'short', //  "Mar" (use 'long' for "March")
  })

  const year = String(d.getFullYear()).slice(-2)

  return `${day} ${month} ${year}`
}

const getDateRangeLabel = (range, customRange) => {
  if (range === 'custom' && customRange.start && customRange.end) {
    return `${formatDate(new Date(customRange.start))} – ${formatDate(new Date(customRange.end))}`
  }

  const end = new Date()
  const start = new Date()

  if (range === 'today') return formatDate(end)

  if (range === 'weekly') start.setDate(end.getDate() - 6)
  else if (range === 'monthly') start.setDate(end.getDate() - 29)
  else if (range === '3months') start.setMonth(end.getMonth() - 3)
  else if (range === '6months') start.setMonth(end.getMonth() - 6)
  else if (range === 'annual') start.setFullYear(end.getFullYear() - 1)

  return `${formatDate(start)} – ${formatDate(end)}`
}

const CustomDateModal = ({ show, onHide, customRange, setCustomRange, onApply }) => {
  return (
    <Modal
      show={show}
      onHide={onHide}
      centered
      backdrop="static"
      keyboard={false}
      animation={false} // 🔥 prevents flicker
    >
      <Modal.Header closeButton>
        <Modal.Title>Select Date Range</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form.Group className="mb-3">
          <Form.Control
            type="date"
            max={new Date().toISOString().split('T')[0]}
            value={customRange.start}
            onChange={(e) =>
              setCustomRange((prev) => ({
                ...prev,
                start: e.target.value,
              }))
            }
          />

          {customRange.start && (
            <div className="text-muted mt-1" style={{ fontSize: '0.8rem' }}>
              Selected: {formatDate(customRange.start)}
            </div>
          )}
        </Form.Group>

        <Form.Group>
          <Form.Control
            type="date"
            max={new Date().toISOString().split('T')[0]}
            min={customRange.start || undefined}
            value={customRange.end}
            onChange={(e) =>
              setCustomRange((prev) => ({
                ...prev,
                end: e.target.value,
              }))
            }
          />

          {customRange.end && (
            <div className="text-muted mt-1" style={{ fontSize: '0.8rem' }}>
              Selected: {formatDate(customRange.end)}
            </div>
          )}
        </Form.Group>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="light" onClick={onHide}>
          Cancel
        </Button>

        <Button variant="primary" onClick={onApply}>
          Apply
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

const MiniStat = ({ icon, title, stat, subTitle, route }) => {
  const router = useRouter()
  return (
    <div className="mini-stat clickable" onClick={() => route && router.push(route)}>
      <div className="mini-stat-inner">
        <div className="mini-text">
          <div className="d-flex justify-content-between align-items-center">
            <div className="mini-title">{title}</div>
            <div className="mini-icon-wrap">
              <IconifyIcon icon={icon} className="mini-icon" />
            </div>
          </div>
          <div className="mini-value">{stat}</div>
          <hr className="mini-divider" />
          <div className="mini-sub">{subTitle}</div>
        </div>
      </div>
    </div>
  )
}

const MiniStatSkeleton = () => (
  <div className="mini-stat">
    <div className="mini-stat-inner">
      <div className="mini-text">
        <div className="d-flex justify-content-between align-items-center">
          <div className="sk-line sk-w-40" />
          <div className="mini-icon-wrap">
            <div className="sk-circle" />
          </div>
        </div>
        <div className="sk-line sk-w-25 sk-h-18 mt-2" />
        <div className="mini-divider my-1" />
        <div className="sk-line sk-w-50 mt-1" />
      </div>
    </div>
  </div>
)

const Stats = () => {
  const [showCustomModal, setShowCustomModal] = useState(false)
  const [showDropdown, setShowDropdown] = useState(false)
  const [customRange, setCustomRange] = useState({
    start: '',
    end: '',
  })
  const [range, setRange] = useState('weekly')
  const [modalKey] = useState(() => Date.now())
  const [showHelp, setShowHelp] = useState(false)
  const [helpContext, setHelpContext] = useState(null)
  const [helpHover, setHelpHover] = useState(false)
  const queryParams =
    range === 'custom' && customRange.start && customRange.end
      ? {
          range: 'custom',
          start_date: customRange.start,
          end_date: customRange.end,
        }
      : { range }

  const { data, isLoading, isError } = useGetOrderSummaryQuery(queryParams)

  const { data: dashboardCards, isLoading: cardsLoading } = useGetDashboardCardsRangeQuery(queryParams)

  const { data: systemSettings } = useGetSystemGlobalSettingsQuery()
  const pending = data?.orders?.pending ?? 0
  const confirmed = data?.orders?.confirmed ?? 0
  const completed = data?.orders?.completed ?? 0
  const returned = data?.orders?.returned ?? 0
  const lowStock = data?.inventory?.low_stock_total ?? data?.inventory?.strictly_below ?? 0

  /* -----------------------------
     NEW: TODAY STAT DATA
  ------------------------------*/
  const todaySales = dashboardCards?.totalSalesAmount ?? 0
  const todayInvoiceCount = dashboardCards?.invoiceCount ?? 0
  const clientCount = dashboardCards?.clientCount ?? 0
  const totalInvoiceValue = dashboardCards?.totalInvoiceValue ?? 0
  const todayReturns = dashboardCards?.invoiceReturns ?? 0
  const currency = systemSettings?.system_settings?.currency ?? ''
  const todayStatData = [
    {
      title: 'Total Sales',
      stat: `${currency} ${todaySales}`,
      subTitle: 'Total sales for selected period',
      icon: 'mdi:cash-register',
      route: '/sales_report',
    },
    {
      title: 'Invoice Count',
      stat: todayInvoiceCount,
      subTitle: 'Total invoices for selected period',
      icon: 'mdi:file-document-outline',
      route: '/invoices',
    },
    {
      title: 'Clients',
      stat: clientCount,
      subTitle: 'Total active clients',
      icon: 'mdi:account-group-outline',
      route: '/clients',
    },
    {
      title: 'Total Invoice Value',
      stat: `${currency} ${totalInvoiceValue}`,
      subTitle: 'Invoice value for selected period',
      icon: 'mdi:receipt-text-outline',
      route: '/invoices',
    },
    {
      title: 'Invoice Returns',
      stat: todayReturns,
      subTitle: 'Returned total items from invoices',
      icon: 'mdi:backup-restore',
      route: '/returned_orders',
    },
  ]
  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }
  /* -----------------------------
     EXISTING OPERATION STATS
  ------------------------------*/

  const statData = [
    { title: 'Pending Orders', stat: pending, subTitle: 'Orders awaiting confirmation', icon: 'mdi:clock-outline', route: '/pending_orders' },
    {
      title: 'Confirmed Orders',
      stat: confirmed,
      subTitle: 'Orders confirmed & processing',
      icon: 'mdi:check-circle-outline',
      route: '/confirmed_orders',
    },
    {
      title: 'Completed Orders',
      stat: completed,
      subTitle: 'Orders successfully delivered',
      icon: 'mdi:package-variant-closed',
      route: '/complete_orders',
    },
    { title: 'Returned Orders', stat: returned, subTitle: 'Orders returned by customers', icon: 'mdi:backup-restore', route: '/returned_orders' },
    {
      title: 'Low Stock',
      stat: lowStock,
      subTitle: 'Variants at/near reorder level',
      icon: 'mdi:alert-circle-outline',
      route: '/reOrder',
    },
  ]

  return (
    <Card>
      <CardHeader className="py-2">
        <Row className="align-items-center g-2">
          <Col>
            <CardTitle as="h5" className="mb-0 d-flex align-items-center gap-2">
              Operation Overview
              {/* Help icon */}
              <IconifyIcon
                icon="mdi:help-circle-outline"
                style={{
                  fontSize: helpHover ? '20px' : '18px',
                  cursor: 'pointer',
                  color: helpHover ? '#0d6efd' : '#6c757d',
                  transition: 'all 0.18s ease',
                }}
                onMouseEnter={() => setHelpHover(true)}
                onMouseLeave={() => setHelpHover(false)}
                onClick={() => openHelp('dashboard_overview')}
              />
              <span className="badge bg-light text-dark">{getDateRangeLabel(range, customRange)}</span>
            </CardTitle>
          </Col>

          <Col xs="auto">
            <div className="position-relative">
              <button className="btn btn-light d-flex align-items-center" onClick={() => setShowDropdown((prev) => !prev)}>
                <IconifyIcon icon="mdi:calendar-month-outline" className="me-2 fs-5" />
                {RANGE_LABELS[range]}
                <IconifyIcon icon="la:angle-down" className="ms-2" />
              </button>

              {showDropdown && (
                <div className="dropdown-menu show" style={{ right: 0, left: 'auto', position: 'absolute' }}>
                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('today')
                      setShowDropdown(false)
                    }}>
                    Today
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('weekly')
                      setShowDropdown(false)
                    }}>
                    Week
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('monthly')
                      setShowDropdown(false)
                    }}>
                    Month
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('3months')
                      setShowDropdown(false)
                    }}>
                    3 Months
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('6months')
                      setShowDropdown(false)
                    }}>
                    6 Months
                  </button>

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setRange('annual')
                      setShowDropdown(false)
                    }}>
                    Annual
                  </button>

                  <div className="dropdown-divider" />

                  <button
                    className="dropdown-item"
                    onClick={() => {
                      setShowDropdown(false)
                      setShowCustomModal(true)
                    }}>
                    Custom
                  </button>
                </div>
              )}
            </div>
          </Col>
        </Row>
      </CardHeader>

      <CardBody className="pt-0">
        {/* -----------------------------
           NEW: TODAY PERFORMANCE ROW
        ------------------------------*/}
        <Row className="px-1 mb-3">
          <div className="mini-grid">
            {isLoading
              ? Array.from({ length: 5 }).map((_, i) => <MiniStatSkeleton key={`today-sk-${i}`} />)
              : todayStatData.map((s, i) => <MiniStat key={`today-${i}`} {...s} />)}
          </div>
        </Row>

        {/* -----------------------------
           ORIGINAL EXISTING STATS
        ------------------------------*/}
        <Row className="px-1">
          <div className="mini-grid">
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => <MiniStatSkeleton key={`sk-${i}`} />)
            ) : isError ? (
              <div className="text-muted py-3 px-2">Couldn&apos;t load stats.</div>
            ) : (
              statData.map((s, i) => <MiniStat key={i} {...s} />)
            )}
          </div>
        </Row>

      </CardBody>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
      <style jsx global>{`
        .mini-grid {
          width: 100%;
          display: flex;
          gap: 12px;
          flex-wrap: nowrap;
        }
        .mini-stat {
          flex: 0 0 calc((100% - (12px * 4)) / 5);
          max-width: calc((100% - (12px * 4)) / 5);
        }
        .mini-stat-inner {
          border: 1px solid var(--bs-border-color, #dee2e6);
          background: #fff;
          border-radius: 10px;
          padding: 12px;
          min-height: 120px;
          height: 100%;
          display: flex;
          align-items: flex-start;
          transition:
            background-color 0.18s ease,
            transform 0.18s ease,
            color 0.18s ease,
            border-color 0.18s ease;
        }
        .mini-stat-inner:hover {
          background-color: #343a40;
          color: #fff;
          transform: translateY(-1px);
          border-color: #343a40;
        }
        .mini-icon-wrap {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #f3f4f6;
        }
        .mini-icon {
          font-size: 18px;
          color: #6c757d;
        }
        .mini-stat-inner:hover .mini-icon {
          color: #05a000ff;
          filter: drop-shadow(0 0 2px rgba(0, 0, 0, 0.3));
        }
        .mini-text {
          flex: 1;
          min-width: 0;
        }
        .mini-title {
          font-weight: 600;
          font-size: 0.95rem;
          line-height: 1.1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .mini-value {
          font-weight: 700;
          font-size: 1.15rem;
          margin-top: 6px;
          margin-bottom: 4px;
          color: #28a745;
        }
        .mini-stat.clickable {
          cursor: pointer;
        }
        .mini-divider {
          border: none;
          border-top: 1px solid rgba(12, 12, 12, 0.8);
          margin: 4px 0;
          transition: border-color 0.18s ease;
        }
        .mini-sub {
          font-size: 0.78rem;
          color: #6c757d;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .mini-stat-inner:hover .mini-sub {
          color: #e9ecef;
        }
        .mini-stat-inner:hover .mini-divider {
          border-color: rgba(255, 255, 255, 0.2);
        }

        .sk-line {
          height: 12px;
          border-radius: 6px;
          background: linear-gradient(90deg, rgba(0, 0, 0, 0.06) 25%, rgba(0, 0, 0, 0.12) 37%, rgba(0, 0, 0, 0.06) 63%);
          background-size: 400% 100%;
          animation: sk-wave 1.2s ease-in-out infinite;
        }
        .sk-w-40 {
          width: 40%;
        }
        .sk-w-50 {
          width: 50%;
        }
        .sk-w-25 {
          width: 25%;
        }
        .sk-h-18 {
          height: 18px;
        }
        .sk-circle {
          width: 18px;
          height: 18px;
          border-radius: 50%;
          background: linear-gradient(90deg, rgba(0, 0, 0, 0.06) 25%, rgba(0, 0, 0, 0.12) 37%, rgba(0, 0, 0, 0.06) 63%);
          background-size: 400% 100%;
          animation: sk-wave 1.2s ease-in-out infinite;
        }
        @keyframes sk-wave {
          0% {
            background-position: 100% 0;
          }
          100% {
            background-position: 0 0;
          }
        }

        @media (max-width: 991.98px) {
          .mini-grid {
            flex-wrap: wrap;
          }
          .mini-stat {
            flex: 0 0 calc((100% - 12px) / 2);
            max-width: calc((100% - 12px) / 2);
          }
        }

        @media (max-width: 575.98px) {
          .mini-stat {
            flex: 0 0 100%;
            max-width: 100%;
          }
        }
      `}</style>
      <CustomDateModal
        key={modalKey} // 🔥 prevents remount chaos
        show={showCustomModal}
        onHide={() => setShowCustomModal(false)}
        customRange={customRange}
        setCustomRange={setCustomRange}
        onApply={() => {
          if (!customRange.start || !customRange.end) return
          setRange('custom')
          setShowCustomModal(false)
        }}
      />
    </Card>
  )
}

export default Stats
