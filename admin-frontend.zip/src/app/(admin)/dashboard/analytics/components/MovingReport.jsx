'use client'

import { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardBody, Table, Button, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import { useGetTopSellingProductsMutation, useGetSystemGlobalSettingsQuery } from '@/store/features/apiSlice'
import HelpModal from './HelpModal'

const RANGE_LABELS = {
  today: 'Today',
  weekly: 'Week',
  monthly: 'Month',
  '3month': '3 Months',
  '6month': '6 Months',
  annual: 'Annual',
}

// ✅ Qty formatter with measurement
function formatQty(item) {
  const qty = Number(item.total_sold_qty ?? 0).toLocaleString()
  const meas = (item.measurement_value || '').trim()

  if (!meas || meas.toLowerCase() === 'pcs') return qty
  return `${qty} ${meas}`
}

const MovingReport = () => {
  const router = useRouter()

  const [range, setRange] = useState('monthly')
  const [showDropdown, setShowDropdown] = useState(false)
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  const [getTopSellingProducts, { data, isLoading, isError }] = useGetTopSellingProductsMutation()
  const { data: settingsData } = useGetSystemGlobalSettingsQuery()

  const products = (data?.products || []).slice(0, 12)
  const currency = settingsData?.system_settings?.currency || ''

  useEffect(() => {
    getTopSellingProducts(range)
  }, [range])

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  return (
    <Card className="h-100 d-flex flex-column">
      {/* HEADER */}
      <CardHeader className="py-2 px-3 d-flex justify-content-between align-items-center">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">Product Performance</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('moving_report_widget')}
          />
        </CardTitle>

        {/* FILTER BUTTON */}
        <div className="position-relative">
          <button className="btn btn-light btn-sm d-flex align-items-center" onClick={() => setShowDropdown((prev) => !prev)}>
            <IconifyIcon icon="mdi:calendar-month-outline" className="me-1" />
            {RANGE_LABELS[range]}
            <IconifyIcon icon="la:angle-down" className="ms-1" />
          </button>

          {showDropdown && (
            <div className="dropdown-menu show" style={{ right: 0, left: 'auto', position: 'absolute' }}>
              {Object.entries(RANGE_LABELS).map(([key, label]) => (
                <button
                  key={key}
                  className="dropdown-item"
                  onClick={() => {
                    setRange(key)
                    setShowDropdown(false)
                  }}>
                  {label}
                </button>
              ))}
            </div>
          )}
        </div>
      </CardHeader>

      {/* BODY */}
      <CardBody className="pt-2 pb-2 px-3 d-flex flex-column">
        {/* Loading */}
        {isLoading && (
          <div className="d-flex justify-content-center align-items-center py-4">
            <Spinner animation="border" size="sm" variant="primary" />
          </div>
        )}

        {/* Error */}
        {isError && (
          <div className="text-center text-danger py-4" style={{ fontSize: '0.82rem' }}>
            Failed to load report.
          </div>
        )}

        {/* Empty */}
        {!isLoading && !isError && products.length === 0 && (
          <div className="text-center text-muted py-4" style={{ fontSize: '0.82rem' }}>
            No data found for this period.
          </div>
        )}

        {/* Table */}
        {!isLoading && !isError && products.length > 0 && (
          <div className="moving-table-wrapper">
            <Table bordered hover responsive size="sm" className="mb-1 text-center">
              <thead>
                <tr>
                  <th className="text-start">Item</th>
                  <th style={{ width: 90 }}>Sold Qty</th>
                  <th className="text-end" style={{ width: 140 }}>
                    Amount {currency ? `(${currency})` : ''}
                  </th>
                </tr>
              </thead>

              <tbody>
                {products.map((item, idx) => (
                  <tr key={idx}>
                    <td className="text-start">{item.title ?? 'N/A'}</td>

                    {/* ✅ UPDATED QTY COLUMN */}
                    <td>{formatQty(item)}</td>

                    <td className="fw-semibold text-success text-end">
                      {Number(item.total_sales_amount).toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        )}

        {/* FOOTER BUTTON */}
        <div className="d-flex justify-content-end mt-auto">
          <Button variant="link" size="sm" className="text-primary text-decoration-none p-0" onClick={() => router.push('/moving_report')}>
            View Report
          </Button>
        </div>
      </CardBody>

      {/* STYLE */}
      <style jsx global>{`
        .moving-table-wrapper {
          flex: 1;
          overflow-y: auto;
          max-height: 100%;
        }

        table thead th {
          font-size: 0.8rem;
          background: var(--bs-light);
          font-weight: 600;
        }

        table td {
          font-size: 0.8rem;
        }
      `}</style>

      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}

export default MovingReport
