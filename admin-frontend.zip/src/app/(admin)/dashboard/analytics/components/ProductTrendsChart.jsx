'use client'

import { useMemo, useState, useEffect } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Dropdown, DropdownItem, DropdownMenu, DropdownToggle, Row } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import dynamic from 'next/dynamic'
const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })
import { useGetOrderStatsMutation } from '@/store/features/apiSlice'
import HelpModal from './HelpModal'
const RANGE_LABELS = { weekly: 'Week', monthly: 'Month' }

// Order statuses to plot
const ORDER_STATUSES = ['Pending', 'Confirmed', 'Completed', 'Cancelled']
const baseOptions = {
  chart: {
    height: 380,
    type: 'line',
    stacked: false,
    toolbar: { show: false },
  },
  dataLabels: { enabled: false },
  stroke: { curve: 'smooth', width: 2 },
  grid: { borderColor: '#45404a2e', strokeDashArray: 4 },
  markers: { size: 4 },
  tooltip: { shared: true, intersect: false },
  legend: { position: 'top', horizontalAlign: 'right' },
  xaxis: { categories: [] },
  yaxis: {
    title: { text: 'Orders' },
    min: 0,
    forceNiceScale: true,
    tickAmount: 4, // ensures even spacing (like 0, 5, 10, 15)
  },
  colors: ['#f59e0b', '#3b82f6', '#10b981', '#ef4444'], // pending, confirmed, completed, cancelled
}

const OrderStatsChart = () => {
  const [range, setRange] = useState('weekly')
  const [showHelp, setShowHelp] = useState(false)
  const [helpContext, setHelpContext] = useState(null)
  const [helpHover, setHelpHover] = useState(false)
  const [getOrderStats, { data: apiData }] = useGetOrderStatsMutation()
  const [chartSeries, setChartSeries] = useState([])
  const [categories, setCategories] = useState([])

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  useEffect(() => {
    const fetchStats = async () => {
      try {
        // ✅ Include both merchant_id and range in payload
        const result = await getOrderStats({ merchant_id: 1, range }).unwrap()
        if (!result) return

        if (range === 'weekly') {
          const weekDays = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']
          setCategories(weekDays)

          const series = ORDER_STATUSES.map((status) => ({
            name: status,
            data: weekDays.map((day) => result.week?.[day]?.[status.toLowerCase()] ?? 0),
          }))
          setChartSeries(series)
        } else if (range === 'monthly') {
          const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
          setCategories(months)

          const series = ORDER_STATUSES.map((status) => ({
            name: status,
            data: months.map((m) => result.month?.[m]?.[status.toLowerCase()] ?? 0),
          }))
          setChartSeries(series)
        }
      } catch (err) {
        console.error('Error fetching order stats', err)
      }
    }

    fetchStats()
  }, [range, getOrderStats])

  const options = useMemo(
    () => ({
      ...baseOptions,
      xaxis: { ...baseOptions.xaxis, categories },
    }),
    [categories],
  )

  return (
    <Card className="h-100 d-flex flex-column">
      <CardHeader>
        <Row className="align-items-center g-2">
          <Col>
            <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
              <span className="d-flex align-items-center">Orders Trend</span>

              <IconifyIcon
                icon="mdi:help-circle-outline"
                style={{
                  fontSize: helpHover ? '20px' : '18px',
                  cursor: 'pointer',
                  color: helpHover ? '#0d6efd' : '#6c757d',
                  transition: 'all 0.18s ease',
                  display: 'flex',
                  alignItems: 'center',
                }}
                onMouseEnter={() => setHelpHover(true)}
                onMouseLeave={() => setHelpHover(false)}
                onClick={() => openHelp('orders_trend_chart')}
              />
            </CardTitle>
          </Col>
          <Col xs="auto">
            <Dropdown>
              <DropdownToggle className="btn btn-light d-flex align-items-center">
                <IconifyIcon icon="mdi:calendar-month-outline" className="me-2 fs-5" />
                {RANGE_LABELS[range]}
                <IconifyIcon icon="la:angle-down" className="ms-2" />
              </DropdownToggle>
              <DropdownMenu align="end">
                <DropdownItem active={range === 'weekly'} onClick={() => setRange('weekly')}>
                  Week
                </DropdownItem>
                <DropdownItem active={range === 'monthly'} onClick={() => setRange('monthly')}>
                  Month
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </Col>
        </Row>
      </CardHeader>

      <CardBody className="d-flex flex-column p-3">
        <ReactApexChart height={320} type="line" options={options} series={chartSeries} />

        {/* -----------------------------
     HELP NOTICE (COMPACT)
  ------------------------------*/}
        {/* {showHelp && (
          <div
            className="px-3 py-2 mt-2"
            style={{
              border: '1px solid #dee2e6',
              borderRadius: '6px',
              background: '#f8f9fa',
              fontSize: '0.75rem',
              lineHeight: '1.3',
            }}>
            <div className="text-muted">
              <strong className="text-dark">Chart Guide:</strong> This chart shows the number of orders by status over the selected period.
              <b> Weekly</b> view displays order counts per weekday, while <b>Monthly</b> view shows totals per month. Each colored line represents a
              different order status (Pending, Confirmed, Completed, Cancelled).
            </div>
          </div>
        )} */}

        <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
      </CardBody>
    </Card>
  )
}

export default OrderStatsChart
