'use client'

import { Card, CardHeader, CardTitle, CardBody, Table, Placeholder, Button } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { useGetRecentReviewsQuery } from '@/store/features/apiSlice'
import HelpModal from './HelpModal'
const clampToHalf = (n) => Math.max(0, Math.min(5, Math.round(n * 2) / 2))
const truncate = (s, len = 80) => (s?.length > len ? s.slice(0, len) + '...' : s || '')
// Avatar initials helper
const avatarHue = (str) => {
  let h = 0
  for (let i = 0; i < (str || '').length; i++) h = (h * 31 + str.charCodeAt(i)) & 0xffff
  return h % 360
}
const getInitials = (name) => {
  if (!name) return '?'
  const p = name.trim().split(/\s+/)
  return p.length >= 2 ? (p[0][0] + p[p.length - 1][0]).toUpperCase() : name.slice(0, 2).toUpperCase()
}

// Client cell with avatar
const ClientCell = ({ name }) => {
  const hue = avatarHue(name)
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
      <div style={{
        width: 24, height: 24, borderRadius: '50%',
        background: `hsl(${hue},50%,92%)`,
        color: `hsl(${hue},38%,28%)`,
        border: `1.5px solid hsl(${hue},35%,82%)`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 9, fontWeight: 700, flexShrink: 0,
      }}>
        {getInitials(name)}
      </div>
      <span style={{ fontWeight: 500, fontSize: '0.8rem' }}>{name}</span>
    </div>
  )
}
const Stars = ({ rating }) => {
  const r = clampToHalf(rating)
  const full = Math.floor(r)
  const half = r - full >= 0.5 ? 1 : 0
  const empty = 5 - full - half
  const AMBER = '#f59e0b', EMPTY = '#d1d5db'
  const pts = (cx, cy) =>
    `${cx},${cy-4.5} ${cx+1.35},${cy-1.6} ${cx+4.5},${cy-1.45} ${cx+2.15},${cy+1.35} ${cx+2.7},${cy+4.5} ${cx},${cy+2.7} ${cx-2.7},${cy+4.5} ${cx-2.15},${cy+1.35} ${cx-4.5},${cy-1.45} ${cx-1.35},${cy-1.6}`
  const total = full + half + empty
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 1 }} aria-label={`${r} out of 5`}>
      <svg width={total * 12} height={11} viewBox={`0 0 ${total * 12} 11`} fill="none">
        {Array.from({ length: full }).map((_, i) => (
          <polygon key={`f${i}`} points={pts(i * 12 + 6, 5.5)} fill={AMBER} />
        ))}
        {half === 1 && (() => {
          const x = full * 12
          return <>
            <defs><clipPath id="hc"><rect x={x} y={0} width={6} height={11} /></clipPath></defs>
            <polygon points={pts(x + 6, 5.5)} fill={EMPTY} />
            <polygon points={pts(x + 6, 5.5)} fill={AMBER} clipPath="url(#hc)" />
          </>
        })()}
        {Array.from({ length: empty }).map((_, i) => (
          <polygon key={`e${i}`} points={pts((full + half + i) * 12 + 6, 5.5)} fill={EMPTY} />
        ))}
      </svg>
      <small className="ms-1 text-muted">{r.toFixed(1)}</small>
    </div>
  )
}

const RowSkeleton = ({ rows = 5 }) => (
  <tbody>
    {Array.from({ length: rows }).map((_, i) => (
      <tr key={`sk-${i}`}>
        {[220, 420, 160].map((w, j) => (
          <td key={j} className="text-center">
            <Placeholder as="div" animation="wave" className="mb-0">
              <Placeholder xs={Math.max(4, Math.min(12, Math.floor(w / 40)))} />
            </Placeholder>
          </td>
        ))}
      </tr>
    ))}
  </tbody>
)

export default function ReviewsSection({ title = 'Recent Reviews' }) {
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  const router = useRouter()
  const { data, isLoading } = useGetRecentReviewsQuery()

  const reviews = data?.length ? data : []

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  return (
    <Card className="h-100 d-flex flex-column">
      <CardHeader className="py-2 px-3 d-flex justify-content-between align-items-center">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">{title}</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('recent_reviews_widget')}
          />
        </CardTitle>

      </CardHeader>

    <CardBody className="pt-2 pb-2 px-3 d-flex flex-column">
  <Table bordered hover responsive size="sm" className="recent-orders-table reviews-table mb-2 text-center">
    <thead>
      <tr>
        <th style={{ width: 220 }}>Client</th>
        <th>Comment</th>
        <th style={{ width: 160 }}>Review</th>
      </tr>
    </thead>

    {isLoading ? (
      <RowSkeleton rows={5} />
    ) : reviews.length > 0 ? (
      <tbody>
        {reviews.map((r) => (
          <tr key={r.id}>
            <td className="text-start">
              <ClientCell name={r.client} />
            </td>
            <td className="text-truncate text-start" title={r.comment}>
              {truncate(r.comment, 80)}
            </td>
            <td>
              <Stars rating={r.rating} />
            </td>
          </tr>
        ))}
      </tbody>
    ) : (
      <tbody>
        <tr>
          <td colSpan="3" className="text-center text-muted py-3">
            No Reviews Found
          </td>
        </tr>
      </tbody>
    )}
  </Table>

  {reviews.length > 0 && (
    <div className="d-flex justify-content-end mt-0">
      <Button
        variant="link"
        size="sm"
        className="text-primary text-decoration-none p-0 fw-normal d-flex align-items-center gap-1"
        onClick={() => router.push('../approve_reviews')}
      >
        Review List
      </Button>
    </div>
  )}
</CardBody>

      <style jsx global>{`
        .recent-orders-table {
          font-size: 0.925rem;
        }
        .recent-orders-table > :not(caption) > * > * {
          padding: 0.35rem 0.5rem;
          vertical-align: middle;
          font-size: 0.8rem;
        }
        .recent-orders-table thead th {
          background: var(--bs-light);
          font-weight: 600;
          font-size: 0.82rem;
          text-align: center;
        }
        .recent-orders-table tbody td {
          text-align: center;
          font-size: 0.815rem;
        }

        .recent-orders-table tbody tr:hover {
          background: rgba(0, 0, 0, 0.02);
        }
        .review-star {
          font-size: 13px;
          line-height: 1;
          color: #f59e0b;
          margin-right: 2px;
        }
      `}</style>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}
