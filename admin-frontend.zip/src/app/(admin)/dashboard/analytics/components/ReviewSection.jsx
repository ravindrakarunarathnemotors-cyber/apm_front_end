'use client'

import { Card, CardHeader, CardTitle, CardBody, Table, Placeholder, Button } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { useGetRecentReviewsQuery } from '@/store/features/apiSlice'
import HelpModal from './HelpModal'
const clampToHalf = (n) => Math.max(0, Math.min(5, Math.round(n * 2) / 2))
const truncate = (s, len = 80) => (s?.length > len ? s.slice(0, len) + '...' : s || '')

const Stars = ({ rating }) => {
  const r = clampToHalf(Number(rating) || 0)
  const full = Math.floor(r)
  const half = r - full >= 0.5 ? 1 : 0
  const empty = 5 - full - half

  return (
    <div className="d-inline-flex align-items-center justify-content-center" aria-label={`Rating ${r} out of 5`}>
      {Array.from({ length: full }).map((_, i) => (
        <IconifyIcon key={`f${i}`} icon="mdi:star" className="review-star" />
      ))}
      {half === 1 && <IconifyIcon icon="mdi:star-half-full" className="review-star" />}
      {Array.from({ length: empty }).map((_, i) => (
        <IconifyIcon key={`e${i}`} icon="mdi:star-outline" className="review-star" />
      ))}
      <small className="ms-2 text-muted">{r.toFixed(1)}</small>
    </div>
  )
}

const RowSkeleton = ({ rows = 5 }) => (
  <tbody>
    {Array.from({ length: rows }).map((_, i) => (
      <tr key={`sk-${i}`}>
        {[220, 420, 160].map((w, j) => (
          <td key={j} className="text-center">
            <Placeholder as="div" animation="wave" className="mb-0">
              <Placeholder xs={Math.max(4, Math.min(12, Math.floor(w / 40)))} />
            </Placeholder>
          </td>
        ))}
      </tr>
    ))}
  </tbody>
)

export default function ReviewsSection({ title = 'Recent Reviews' }) {
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  const router = useRouter()
  const { data, isLoading } = useGetRecentReviewsQuery()

  const reviews = data?.length ? data : []

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  return (
    <Card className="h-100 d-flex flex-column">
      <CardHeader className="py-2 px-3 d-flex justify-content-between align-items-center">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">{title}</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('recent_reviews_widget')}
          />
        </CardTitle>

      </CardHeader>

      <CardBody className="pt-2 pb-2 px-3 d-flex flex-column">
        <Table bordered hover responsive size="sm" className="recent-orders-table reviews-table mb-2 text-center">
          <thead>
            <tr>
              <th style={{ width: 220 }}>Client</th>
              <th>Comment</th>
              <th style={{ width: 160 }}>Review</th>
            </tr>
          </thead>

          {isLoading ? (
            <RowSkeleton rows={5} />
          ) : reviews.length > 0 ? (
            <tbody>
              {reviews.map((r) => (
                <tr key={r.id}>
                  <td className="text-truncate text-start tex-capitalize">{r.client}</td>
                  <td className="text-truncate text-start tex-capitalize" title={r.comment}>
                    {truncate(r.comment, 80)}
                  </td>
                  <td>
                    <Stars rating={r.rating} />
                  </td>
                </tr>
              ))}
            </tbody>
          ) : (
            <tbody>
              <tr>
                <td colSpan="3" className="text-center text-muted py-3">
                  No Reviews Found
                </td>
              </tr>
            </tbody>
          )}
        </Table>

        {/* -----------------------------
   HELP NOTICE (COMPACT)
------------------------------*/}
{reviews.length > 0 && (
  <div className="d-flex justify-content-end mt-0">
    <Button
      variant="link"
      size="sm"
      className="text-primary text-decoration-none p-0 fw-normal d-flex align-items-center gap-1"
      onClick={() => router.push('../approve_reviews')}
    >
      
      Review List
    </Button>
  </div>
)}
      </CardBody>

      <style jsx global>{`
        .recent-orders-table {
          font-size: 0.925rem;
        }
        .recent-orders-table > :not(caption) > * > * {
          padding: 0.35rem 0.5rem;
          vertical-align: middle;
          font-size: 0.8rem;
        }
        .recent-orders-table thead th {
          background: var(--bs-light);
          font-weight: 600;
          font-size: 0.82rem;
          text-align: center;
        }
        .recent-orders-table tbody td {
          text-align: center;
          font-size: 0.815rem;
        }

        .recent-orders-table tbody tr:hover {
          background: rgba(0, 0, 0, 0.02);
        }
        .review-star {
          font-size: 13px;
          line-height: 1;
          color: #f59e0b;
          margin-right: 2px;
        }
      `}</style>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}
