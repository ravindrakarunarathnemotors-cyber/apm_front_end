'use client'

import { Modal, Button } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'

const HelpModal = ({ show, onHide, context }) => {
  const helpContent = {
    dashboard_overview: {
      title: 'Dashboard Overview',
      content: (
        <>
          <p className="help-desc">
            The dashboard shows live operational metrics calculated from orders, invoices and customer records for the selected date range.
          </p>

          <ul className="help-list">
            <li>
              <span className="help-key">Total Sales</span> — calculated from two sources:
              <ul>
                <li>
                  Order item totals from orders in the states:
                  <strong> confirmed, processing, dispatched, completed</strong>
                </li>
                <li>
                  Invoice line totals
                  <strong> (quantity × unit price − discounts)</strong>
                </li>
              </ul>
              These two values are combined to produce the total sales amount.
            </li>

            <li>
              <span className="help-key">Invoice Count</span> — total number of invoices created in the selected period (from the invoice header
              records).
            </li>

            <li>
              <span className="help-key">Clients</span> — number of
              <strong> active customers</strong> created during the selected period.
            </li>

            <li>
              <span className="help-key">Total Invoice Value</span> — the
              <strong> summed invoice totals</strong> from the invoice header table for the selected date range.
            </li>

            <li>
              <span className="help-key">Invoice Returns</span> — number of invoice records included in reporting (excluding invoices with status
              <strong> cancelled, draft, or hold</strong>).
            </li>
          </ul>

          <div className="help-section">
            Operational statistics below the performance cards summarize order processing stages (pending, confirmed, processing, dispatched,
            completed, cancelled, returned) and inventory alerts such as low stock. These values are grouped by the selected date range (today, week,
            month, etc.).
          </div>
        </>
      ),
    },
    delivery_insights_chart: {
      title: 'Delivery Insights',
      content: (
        <>
          <p className="help-desc">This chart shows delivery performance for the selected delivery partner and time range.</p>

          <div className="help-subtitle">Delivery Status</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Completed</span> — successfully delivered orders
            </li>
            <li>
              <span className="help-key">Returned</span> — deliveries returned or failed
            </li>
          </ul>

          <div className="help-subtitle">Filters</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Delivery Partner</span> — view performance for a specific partner
            </li>
            <li>
              <span className="help-key">Range</span> — analyze results weekly or monthly
            </li>
          </ul>
        </>
      ),
    },

    orders_trend_chart: {
      title: 'Orders Trend Chart',
      content: (
        <>
          <p className="help-desc">This chart displays the number of orders by status over the selected time period.</p>

          <div className="help-subtitle">Time Range</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Weekly</span> — shows order counts per weekday
            </li>
            <li>
              <span className="help-key">Monthly</span> — shows order totals per month
            </li>
          </ul>

          <div className="help-subtitle">Order Status Lines</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Pending</span> — orders waiting confirmation
            </li>
            <li>
              <span className="help-key">Confirmed</span> — processing orders
            </li>
            <li>
              <span className="help-key">Completed</span> — delivered orders
            </li>
            <li>
              <span className="help-key">Cancelled</span> — cancelled orders
            </li>
          </ul>
        </>
      ),
    },
    recent_orders_table: {
      title: 'Recent Orders',
      content: (
        <>
          <p className="help-desc">This table displays the latest orders created in the system.</p>

          <div className="help-subtitle">Displayed Information</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Order ID</span> — unique identifier for each order
            </li>
            <li>
              <span className="help-key">Customer</span> — customer who placed the order
            </li>
            <li>
              <span className="help-key">Status</span> — current order processing stage
            </li>
            <li>
              <span className="help-key">Price</span> — total order value
            </li>
          </ul>

          <div className="help-subtitle">Quick Access</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Show All</span> — view the complete orders list
            </li>
          </ul>
        </>
      ),
    },
    stock_status_widget: {
      title: 'Stock Status',
      content: (
        <>
          <p className="help-desc">This table highlights product variants that are approaching or below their reorder level.</p>

          <div className="help-subtitle">Displayed Information</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Product / Variant</span> — product and variant combination
            </li>
            <li>
              <span className="help-key">Current Qty</span> — current inventory level
            </li>
            <li>
              <span className="help-key">Re-Order Level</span> — stock threshold indicator
            </li>
          </ul>

          <div className="help-subtitle">Stock Indicators</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Out of Stock</span> — no inventory remaining
            </li>
            <li>
              <span className="help-key">Reached</span> — stock has reached reorder level
            </li>
            <li>
              <span className="help-key">Near to Reach</span> — approaching reorder threshold
            </li>
            <li>
              <span className="help-key">In Stock</span> — healthy inventory levels
            </li>
          </ul>
        </>
      ),
    },

    top_customers_widget: {
      title: 'Top Customers',
      content: (
        <>
          <p className="help-desc">This section highlights customers with the highest order activity.</p>

          <div className="help-subtitle">Customer Cards</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Orders</span> — total number of orders placed by the customer
            </li>
            <li>
              <span className="help-key">Customer Name</span> — full name of the customer
            </li>
            <li>
              <span className="help-key">Customer ID</span> — unique identifier of the customer account
            </li>
            <li>
              <span className="help-key">Phone</span> — contact number for the customer
            </li>
          </ul>

          <div className="help-subtitle">Status Indicator</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Active</span> — customer account is active
            </li>
            <li>
              <span className="help-key">Inactive</span> — customer account is currently disabled
            </li>
          </ul>
        </>
      ),
    },
    recent_reviews_widget: {
      title: 'Recent Reviews',
      content: (
        <>
          <p className="help-desc">This section displays the most recent customer reviews submitted for your products or services.</p>

          <div className="help-subtitle">Displayed Information</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Client</span> — the customer who submitted the review
            </li>
            <li>
              <span className="help-key">Comment</span> — feedback or review message from the customer
            </li>
            <li>
              <span className="help-key">Review</span> — star rating from 1 to 5
            </li>
          </ul>

          <div className="help-subtitle">Star Ratings</div>

          <ul className="help-list">
            <li>
              <span className="help-key">5 Stars</span> — excellent customer satisfaction
            </li>
            <li>
              <span className="help-key">3–4 Stars</span> — positive feedback
            </li>
            <li>
              <span className="help-key">1–2 Stars</span> — customer issues or dissatisfaction
            </li>
          </ul>
        </>
      ),
    },

    moving_report_widget: {
      title: 'Product Performance',
      content: (
        <>
          <p className="help-desc">This table displays the top 10 best-selling products ranked by units sold for the selected time period.</p>

          <div className="help-subtitle">Displayed Information</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Item</span> — product name
            </li>
            <li>
              <span className="help-key">Sold</span> — total units sold within the selected period
            </li>
            <li>
              <span className="help-key">Amount</span> — total sales value generated by the product
            </li>
          </ul>

          <div className="help-subtitle">Time Filters</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Today</span> — sales from today only
            </li>
            <li>
              <span className="help-key">Week</span> — last 7 days
            </li>
            <li>
              <span className="help-key">Month</span> — last 30 days
            </li>
            <li>
              <span className="help-key">3 Months</span> — last 3 months
            </li>
            <li>
              <span className="help-key">6 Months</span> — last 6 months
            </li>
            <li>
              <span className="help-key">Annual</span> — last 12 months
            </li>
          </ul>

          <div className="help-section">
            Sales data is combined from both orders and invoices. Only confirmed, processing, dispatched and completed orders are included.
          </div>
        </>
      ),
    },

    recent_invoices_widget: {
      title: 'Recent Invoices',
      content: (
        <>
          <p className="help-desc">This table displays the most recent invoices created in the system, showing up to 15 records.</p>

          <div className="help-subtitle">Displayed Information</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Invoice ID</span> — unique identifier for each invoice
            </li>
            <li>
              <span className="help-key">Client</span> — customer linked to the invoice
            </li>
            <li>
              <span className="help-key">Status</span> — current payment status of the invoice
            </li>
            <li>
              <span className="help-key">Amount</span> — total invoice value in the system currency
            </li>
          </ul>

          <div className="help-subtitle">Payment Status</div>

          <ul className="help-list">
            <li>
              <span className="help-key">Paid</span> — invoice has been fully settled
            </li>
            <li>
              <span className="help-key">Pending</span> — awaiting payment
            </li>
            <li>
              <span className="help-key">Overdue</span> — payment deadline has passed
            </li>
          </ul>

          <div className="help-subtitle">Quick Access</div>

          <ul className="help-list">
            <li>
              <span className="help-key">View All</span> — navigates to the full invoices list
            </li>
          </ul>
        </>
      ),
    },

    upcoming_leaves_widget: {
  title: 'Upcoming Leaves',
  content: (
    <>
      <p className="help-desc">
        This section displays employees who have approved upcoming leave requests.
      </p>

      <div className="help-subtitle">Displayed Information</div>

      <ul className="help-list">
        <li>
          <span className="help-key">Employee</span> — name of the employee who requested leave
        </li>
        <li>
          <span className="help-key">Date</span> — leave start and end dates
        </li>
        <li>
          <span className="help-key">Days Left</span> — number of days remaining until the leave starts
        </li>
        <li>
          <span className="help-key">Type</span> — duration type such as full day or half day
        </li>
      </ul>

      <div className="help-subtitle">Highlights</div>

      <ul className="help-list">
        <li>
          <span className="help-key">Red Badge</span> — leave starting soon (0–2 days)
        </li>
        <li>
          <span className="help-key">Yellow Badge</span> — medium upcoming (3–5 days)
        </li>
        <li>
          <span className="help-key">Green Badge</span> — future leaves (6+ days)
        </li>
      </ul>

      <div className="help-section">
        Only approved future leaves are shown here. Use &ldquo;Show All Leaves&ldquo; to view the complete leave management page.
      </div>
    </>
  ),
},
  }

  const data = helpContent[context] || {
    title: 'Help',
    content: <p className="text-muted">Help content not available.</p>,
  }

  return (
    <>
      <Modal show={show} onHide={onHide} centered size="lg">
        <Modal.Header closeButton className="help-header">
          <Modal.Title className="d-flex align-items-center gap-2">
            <IconifyIcon icon="mdi:help-circle-outline" className="help-icon" />
            {data.title}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body className="help-body">{data.content}</Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={onHide}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <style jsx global>{`
        .help-header {
          border-bottom: 1px solid #e9ecef;
        }

        .help-icon {
          font-size: 22px;
          color: #0d6efd;
        }

        .help-body {
          font-size: 0.9rem;
          line-height: 1.6;
          color: #495057;
        }

        .help-desc {
          margin-bottom: 12px;
        }

        .help-section {
          margin-top: 12px;
          padding: 10px 12px;
          background: #f8f9fa;
          border-radius: 6px;
          font-size: 0.85rem;
        }

        .help-subtitle {
          margin-top: 14px;
          margin-bottom: 6px;
          font-weight: 600;
          font-size: 0.85rem;
          color: #0d6efd;
        }

        .help-list {
          padding-left: 18px;
          margin-bottom: 8px;
        }

        .help-list li {
          margin-bottom: 4px;
        }

        .help-key {
          font-weight: 600;
          color: #212529;
        }
      `}</style>
    </>
  )
}

export default HelpModal
