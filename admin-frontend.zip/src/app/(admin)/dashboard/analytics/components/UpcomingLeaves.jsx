'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useGetUpcomingLeavesQuery } from '@/store/features/apiSlice'
import { Badge, Table, Spinner, Button } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import HelpModal from './HelpModal'
function UpcomingLeaves() {
  const router = useRouter()
  const { data, isLoading, error } = useGetUpcomingLeavesQuery()

  const [showHelp, setShowHelp] = useState(false)

  const allLeaves = data?.data || []
  const leaves = allLeaves.slice(0, 10)
  const hasMore = allLeaves.length > 10

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
    })
  }

  const getDaysLeft = (date) => {
    const today = new Date()
    const leaveDate = new Date(date)
    const diff = Math.ceil((leaveDate - today) / (1000 * 60 * 60 * 24))
    return diff
  }

  return (
    <>
      <div className="card shadow-sm border-0 h-100">
        <div className="card-body d-flex flex-column">
          {/* Header */}
          <div className="d-flex justify-content-between align-items-center mb-3">
            <div className="d-flex align-items-center gap-2">
              <h5 className="mb-0">Upcoming Leaves</h5>

              {/* Help Icon */}
              <span style={{ cursor: 'pointer' }} onClick={() => setShowHelp(true)}>
                <IconifyIcon icon="mdi:help-circle-outline" style={{ fontSize: 18, color: '#6c757d' }} />
              </span>
            </div>

            <Badge bg="light" text="dark">
              {allLeaves.length}
            </Badge>
          </div>

          {/* Content */}
          {isLoading ? (
            <div className="text-center py-4">
              <Spinner animation="border" size="sm" />
            </div>
          ) : error ? (
            <div className="text-danger text-center py-3">Failed to load</div>
          ) : leaves.length === 0 ? (
            <div className="text-muted text-center py-3">No upcoming leaves</div>
          ) : (
            <>
              <Table hover responsive className="align-middle mb-2">
                <thead className="table-light">
                  <tr style={{ fontSize: '0.8rem' }}>
                    <th>Employee</th>
                    <th>Date</th>
                    <th>Days Left</th>
                    <th>Type</th>
                  </tr>
                </thead>

                <tbody>
                  {leaves.map((leave) => {
                    const daysLeft = getDaysLeft(leave.from_date)

                    return (
                      <tr key={leave.leave_id}>
                        <td>
                          <div style={{ fontWeight: 500 }}>
                            {leave.first_name} {leave.last_name}
                          </div>
                          <div className="text-muted" style={{ fontSize: '0.75rem' }}>
                            {leave.reason}
                          </div>
                        </td>

                        <td style={{ fontSize: '0.85rem' }}>
                          {formatDate(leave.from_date)} → {formatDate(leave.to_date)}
                        </td>

                        <td>
                          <Badge bg={daysLeft <= 2 ? 'danger' : daysLeft <= 5 ? 'warning' : 'success'}>{daysLeft}d</Badge>
                        </td>

                        <td>
                          <Badge bg="info" className="text-capitalize">
                            {leave.duration_type.replace('_', ' ')}
                          </Badge>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>

              {/* Show All Button */}
              {hasMore && (
                <div className="text-end mt-2">
                  <Button variant="outline-primary" size="sm" onClick={() => router.push('/leave')}>
                    Show All Leaves →
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Help Modal */}
      <HelpModal show={showHelp} onHide={() => setShowHelp(false)} context="upcoming_leaves_widget" />
    </>
  )
}

export default UpcomingLeaves
