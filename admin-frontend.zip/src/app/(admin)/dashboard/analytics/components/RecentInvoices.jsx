'use client'

import { Card, CardHeader, CardTitle, CardBody, Table, Badge, Button, Spinner } from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetRecentOrdersQuery, useGetSystemGlobalSettingsQuery } from '@/store/features/apiSlice'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import HelpModal from './HelpModal'

// Status styling
const getStatusVariant = (status) => {
  switch (status?.toLowerCase()) {
    case 'paid':
      return 'success'
    case 'pending':
      return 'warning'
    case 'overdue':
      return 'danger'
    default:
      return 'secondary'
  }
}

const formatStatus = (status) => {
  if (!status) return 'N/A'
  return status.charAt(0).toUpperCase() + status.slice(1)
}

const RecentInvoices = () => {
  const { data, isLoading, isError } = useGetRecentOrdersQuery()
  const { data: settingsData } = useGetSystemGlobalSettingsQuery()
  const router = useRouter()

  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  const orders = (data?.orders || []).slice(0, 15)
  const currency = settingsData?.system_settings?.currency || ''

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  return (
    <Card className="h-100 d-flex flex-column">
      {/* HEADER */}
      <CardHeader className="py-2 px-3 d-flex justify-content-between align-items-center">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">Recent Invoices</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('recent_invoices_widget')}
          />
        </CardTitle>

        <IconifyIcon icon="mdi:receipt-text-outline" className="text-muted" />
      </CardHeader>

      {/* BODY */}
      <CardBody className="pt-2 pb-2 px-3 d-flex flex-column">
        {/* Loading */}
        {isLoading && (
          <div className="d-flex justify-content-center align-items-center py-4">
            <Spinner animation="border" size="sm" variant="primary" />
          </div>
        )}

        {/* Error */}
        {isError && (
          <div className="text-center text-danger py-4" style={{ fontSize: '0.82rem' }}>
            Failed to load invoices.
          </div>
        )}

        {/* Empty */}
        {!isLoading && !isError && orders.length === 0 && (
          <div className="text-center text-muted py-4" style={{ fontSize: '0.82rem' }}>
            No recent invoices found.
          </div>
        )}

        {/* Table */}
        {!isLoading && !isError && orders.length > 0 && (
          <div className="invoice-table-wrapper">
            <Table bordered hover responsive size="sm" className="mb-1">
              <thead>
                <tr>
                  <th className="text-center" style={{ width: 100 }}>
                    Invoice ID
                  </th>
                  <th className="text-start">Client</th>
                  <th className="text-center" style={{ width: 110 }}>
                    Status
                  </th>
                  <th className="text-end" style={{ width: 130 }}>
                    Amount {currency ? `(${currency})` : ''}
                  </th>
                </tr>
              </thead>

              <tbody>
                {orders.map((inv, idx) => (
                  <tr key={idx}>
                    <td className="text-center fw-semibold">#{inv.invoice ?? 'N/A'}</td>
                    <td className="text-start text-truncate" style={{ maxWidth: 140 }}>
                      {inv.client ?? 'N/A'}
                    </td>
                    <td className="text-center">
                      <Badge bg={getStatusVariant(inv.payment_status)} className="text-uppercase badge-compact">
                        {formatStatus(inv.payment_status)}
                      </Badge>
                    </td>
                    <td className="fw-semibold text-success text-end">
                      {Number(inv.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        )}

        {/* FOOTER */}
        <div className="d-flex justify-content-end mt-auto">
          <Button variant="link" size="sm" className="text-primary text-decoration-none p-0" onClick={() => router.push('/invoices')}>
            View All
          </Button>
        </div>
      </CardBody>

      {/* STYLE */}
      <style jsx global>{`
        .invoice-table-wrapper {
          flex: 1;
          overflow-y: auto;
          max-height: 100%;
        }

        table thead th {
          font-size: 0.8rem;
          background: var(--bs-light);
          font-weight: 600;
        }

        table td {
          font-size: 0.8rem;
        }

        .badge-compact {
          font-size: 0.65rem;
          padding: 0.18rem 0.4rem;
          letter-spacing: 0.02em;
        }
      `}</style>

      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}

export default RecentInvoices
