'use client'

import { useMemo, useState } from 'react'
import { Card, CardHeader, CardTitle, CardBody, Badge, Placeholder } from 'react-bootstrap'
import { useGetTopCustomersQuery } from '@/store/features/apiSlice' //  RTK hook
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import HelpModal from './HelpModal'
const normalizeStatus = (status) => (String(status).toLowerCase() === 'inactive' ? 'inactive' : 'active')
const statusVariant = (status) => (status === 'inactive' ? 'secondary' : 'success')
const truncate = (str, len = 15) => (str?.length > len ? `${str.slice(0, len)}...` : str || 'No name available')

const CustomerCardSkeleton = () => (
  <Card className="mini-cust h-100 shadow-sm border-0">
    <CardBody className="mini-body d-flex flex-column align-items-center justify-content-between">
      <Placeholder animation="wave" className="orders-pill w-75 mb-1">
        <Placeholder xs={5} />
      </Placeholder>
      <div className="avatar-skel rounded-circle mb-1">
        <Placeholder animation="wave" className="w-100 h-100 rounded-circle" />
      </div>
      <div className="text-center w-100">
        <Placeholder animation="wave">
          <Placeholder xs={8} />
        </Placeholder>
        <Placeholder animation="wave" className="mt-1">
          <Placeholder xs={6} />
        </Placeholder>
        <Placeholder animation="wave" className="mt-2">
          <Placeholder xs={4} />
        </Placeholder>
      </div>
    </CardBody>
  </Card>
)

const CustomerCard = ({ customer }) => {
  const status = normalizeStatus(customer.status)
  const name = truncate(customer.name)

  return (
    <Card className="h-100 d-flex flex-column">
      <CardBody className="mini-body d-flex flex-column align-items-center justify-content-between">
        {/* Top: orders */}
        <div className="orders-pill text-center">
          {customer.orders || 0} <span className="text-muted">orders</span>
        </div>

        {/* Middle: avatar */}
        <img
          src={customer.imageUrl || '/defavatar.jpg'}
          alt={`${customer.name || 'No name available'} avatar`}
          className="avatar-img mb-1"
          width={44}
          height={44}
        />

        {/* Bottom: ID / name / phone / status */}
        <div className="text-center">
          <div className="cust-name text-truncate" title={customer.name || 'No name available'}>
            {name}
          </div>
          <div className="cust-id text-muted mt-1 mb-1">Customer ID: {customer.id ?? 'No ID available'}</div>
          <div className="cust-phone text-muted text-truncate">{customer.phone || '-'}</div>
          <Badge bg={statusVariant(status)} className="mt-1 text-uppercase badge-compact">
            {status}
          </Badge>
        </div>
      </CardBody>
    </Card>
  )
}

export default function CustomerSection({ customers, isLoading = false, title = 'Top Customers' }) {
  const [showHelp, setShowHelp] = useState(false)
  const [helpHover, setHelpHover] = useState(false)
  const [helpContext, setHelpContext] = useState(null)

  //  Fetch real data (top 15) from backend
  const { data: apiData, isLoading: isLoadingApi, isFetching: isFetchingApi } = useGetTopCustomersQuery()

  //  Map API -> UI model
  const mappedFromApi = useMemo(() => {
    const rows = apiData?.data ?? []
    return rows.map((r) => ({
      id: r.customer_id ?? 'No ID available',
      name: [r.first_name, r.last_name].filter(Boolean).join(' ') || 'No name available',
      phone: r.contact_number_1 || '-',
      status: r.status ?? 'active',
      orders: Number(r.order_count) || 0,
      imageUrl: r.picture || '', // fallback handled in <img />
    }))
  }, [apiData])

  const openHelp = (context) => {
    setHelpContext(context)
    setShowHelp(true)
  }

  //  Choose source: explicit prop > API > empty
  const source = useMemo(() => {
    if (customers && customers.length) return customers
    if (mappedFromApi && mappedFromApi.length) return mappedFromApi
    return []
  }, [customers, mappedFromApi])

  // Keep your sort, but show 15 items
  const topFifteen = useMemo(() => {
    const src = source.slice()
    src.sort((a, b) => (b.orders || 0) - (a.orders || 0))
    return src.slice(0, 15)
  }, [source])

  const loading = isLoading || isLoadingApi || isFetchingApi

  return (
    <Card className="h-100 d-flex flex-column">
      <CardHeader className="py-2 px-3">
        <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
          <span className="d-flex align-items-center">{title}</span>

          <IconifyIcon
            icon="mdi:help-circle-outline"
            style={{
              fontSize: helpHover ? '20px' : '18px',
              cursor: 'pointer',
              color: helpHover ? '#0d6efd' : '#6c757d',
              transition: 'all 0.18s ease',
              display: 'flex',
              alignItems: 'center',
            }}
            onMouseEnter={() => setHelpHover(true)}
            onMouseLeave={() => setHelpHover(false)}
            onClick={() => openHelp('top_customers_widget')}
          />
        </CardTitle>
      </CardHeader>

      <CardBody className="pt-2 pb-2 d-flex flex-column">
        <div className="cust-grid-wrapper">
          <div className="cust-grid compact">
            {loading ? (
              Array.from({ length: 15 }).map((_, i) => (
                <div className="cust-item" key={`sk-${i}`}>
                  <CustomerCardSkeleton />
                </div>
              ))
            ) : topFifteen.length === 0 ? (
              <div className="text-center text-muted py-4 w-100" style={{ fontSize: '0.82rem' }}>
                No customers found.
              </div>
            ) : (
              topFifteen.map((c) => (
                <div className="cust-item" key={c?.id}>
                  <CustomerCard customer={c} />
                </div>
              ))
            )}
          </div>
        </div>

        {/* -----------------------------
     HELP NOTICE (COMPACT)
  ------------------------------*/}
      </CardBody>

      <style jsx global>{`
        .cust-grid {
          --gap: 8px;
          display: flex;
          flex-wrap: wrap;
          gap: var(--gap);
        }
        .cust-item {
          flex: 0 0 calc((100% - (var(--gap) * 4)) / 5);
          max-width: calc((100% - (var(--gap) * 4)) / 5);
        }
        @media (max-width: 991.98px) {
          .cust-item {
            flex: 0 0 calc((100% - (var(--gap) * 2)) / 3);
            max-width: calc((100% - (var(--gap) * 2)) / 3);
          }
        }
        @media (max-width: 575.98px) {
          .cust-item {
            flex: 0 0 calc((100% - var(--gap)) / 2);
            max-width: calc((100% - var(--gap)) / 2);
          }
        }

        .mini-cust {
          border-radius: 10px;
          transition:
            transform 0.18s ease,
            box-shadow 0.18s ease,
            background-color 0.18s ease;
        }
        .mini-cust:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
          background-color: #f9fafb;
        }
        .mini-body {
          padding: 6px 8px;
          min-height: 125px;
        }
        .orders-pill {
          font-weight: 600;
          font-size: 0.72rem;
          background: #f3f4f6;
          border-radius: 999px;
          padding: 2px 8px;
          min-width: 78px;
          line-height: 1.05;
        }
        .avatar-img {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          object-fit: cover;
          border: 2px solid #ffffff;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
          background: #e5e7eb;
          display: block;
        }
        .cust-id {
          font-size: 0.67rem;
          line-height: 1.05;
        }
        .cust-name {
          font-weight: 600;
          font-size: 0.78rem;
          line-height: 1.1;
          max-width: 100%;
        }
        .cust-phone {
          font-size: 0.67rem;
          line-height: 1.05;
        }
        .badge-compact {
          font-size: 0.52rem;
          padding: 0.12rem 0.3rem;
          line-height: 1;
          letter-spacing: 0.03em;
          border-radius: 6px;
        }
        .avatar-skel {
          width: 44px;
          height: 44px;
          overflow: hidden;
        }
      `}</style>
      <HelpModal show={showHelp} context={helpContext} onHide={() => setShowHelp(false)} />
    </Card>
  )
}
