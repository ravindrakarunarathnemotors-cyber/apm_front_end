'use client';

import React, { useState, useRef } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';

const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;

export default function WebMediaUploader({
  name = 'media_url',
  fieldDef = { label: 'Upload File' },
  register = () => ({}),
  err = null,
}) {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [previewUrl, setPreviewUrl] = useState(null);
  const fileInputRef = useRef();

  const handleUpload = async (event) => {
    const files = event.target.files;
    if (!files?.length) return;

    const formData = new FormData();
    Array.from(files).forEach((file) => formData.append('files', file));

    try {
      setUploading(true);
      setUploadProgress(0);

      const res = await axios.post(`${API_BASE_URL}/web-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percent);
        },
      });

      setUploading(false);
      setUploadProgress(0);

      const uploadedMedia = res.data?.media?.[0];
      if (uploadedMedia?.media_url) {
        setPreviewUrl(uploadedMedia.media_url);
        const input = document.querySelector(`input[name="${name}"]`);
        if (input) input.value = uploadedMedia.media_url;
      }
    } catch (error) {
      setUploading(false);
      setUploadProgress(0);
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: error?.response?.data?.error || 'Something went wrong while uploading.',
      });
    }
  };

  return (
    <div className="card mb-3" style={{ maxWidth: 450 }}>
      <div className="card-body p-3">
        <label className="form-label mb-2">{fieldDef?.label || 'Upload File'}</label>
        <div className="input-group input-group-sm">
          <input
            type="text"
            name={name}
            className="form-control"
            placeholder="https://..."
            {...register(name)}
            readOnly
            style={{ height: '34px' }}
          />
          <button
            type="button"
            className="btn btn-outline-secondary"
            onClick={() => fileInputRef.current.click()}
            style={{ height: '34px' }}
          >
            Browse…
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleUpload}
            accept="image/*,video/*,.glb"
            style={{ display: 'none' }}
          />
        </div>

        {err && <div className="text-danger small mt-1">{err.message}</div>}

        {uploading && (
          <div className="mt-2">
            <progress value={uploadProgress} max="100" style={{ width: '100%' }} />
            <div className="small text-muted">{uploadProgress}%</div>
          </div>
        )}
      </div>
    </div>
  );
}
