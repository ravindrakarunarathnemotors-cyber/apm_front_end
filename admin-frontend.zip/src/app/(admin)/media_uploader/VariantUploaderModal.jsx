'use client'

import { useState, useRef, useEffect, useMemo } from 'react'
import { Button, Modal, Image, Spinner, ProgressBar } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import axios from 'axios'
import Swal from 'sweetalert2'

/* ====== storage helpers (variant_media store) ====== */
const VM_KEY = 'variant_media'
const PID_STAGING = '__staging__'

const safeParseObject = (v) => {
  try {
    const p = JSON.parse(v)
    return p && typeof p === 'object' && !Array.isArray(p) ? p : {}
  } catch {
    return {}
  }
}
const readVM = () => {
  if (typeof window === 'undefined') return {}
  const raw = sessionStorage.getItem(VM_KEY) ?? localStorage.getItem(VM_KEY)
  return safeParseObject(raw)
}
const writeVM = (vm) => {
  if (typeof window === 'undefined') return
  const json = JSON.stringify(vm || {})
  sessionStorage.setItem(VM_KEY, json)
  localStorage.setItem(VM_KEY, json)
}
const getPidKey = (productId) => (productId ? String(productId) : PID_STAGING)

const ensureBucket = (vm, pidKey) => {
  if (!vm[pidKey]) vm[pidKey] = { product: [], variants: {} }
  if (!Array.isArray(vm[pidKey].product)) vm[pidKey].product = []
  if (!vm[pidKey].variants || typeof vm[pidKey].variants !== 'object') vm[pidKey].variants = {}
  return vm[pidKey]
}

const mergeUniqueByUrl = (base = [], incoming = []) => {
  const map = new Map()

  ;[...base, ...incoming].forEach((m) => {
    if (!m?.media_url) return

    const key = String(m.media_url).trim()

    map.set(key, {
      ...(map.get(key) || {}),
      ...m,
      media_url: key,
    })
  })

  return [...map.values()]
}
/** Append items into variant_media store */
const pushToScopeStore = ({ productId, variantKey, items }) => {
  if (!items?.length) return
  const pidKey = getPidKey(productId)
  const vm = readVM()
  const bucket = ensureBucket(vm, pidKey)

  if (variantKey != null) {
    const vk = String(variantKey)
    bucket.variants[vk] = mergeUniqueByUrl(
      bucket.variants[vk] || [],
      items.map((it) => ({ ...it, variant_id: variantKey })),
    )
  } else {
    // product scope
    bucket.product = mergeUniqueByUrl(
      bucket.product,
      items.filter((m) => m?.variant_id == null),
    )
  }

  writeVM(vm)
}

/** Remove a single media from the right place inside variant_media store */
const removeFromScopeStore = ({ productId, media }) => {
  const pidKey = getPidKey(productId)
  const vm = readVM()
  const bucket = ensureBucket(vm, pidKey)

  const mediaId = media?.media_id || media?.id || media?.media_url
  const filterFn = (m) => (m.media_id || m.id || m.media_url) !== mediaId

  if (media?.variant_id != null) {
    const vk = String(media.variant_id)
    const current = bucket.variants[vk] || []
    bucket.variants[vk] = current.filter(filterFn)
  } else {
    bucket.product = (bucket.product || []).filter(filterFn)
  }

  writeVM(vm)
}
/* ====== end storage helpers ====== */

/* tiny helper to normalize variant_id to null when missing */
const normalizeVariantId = (m) => ({
  ...m,
  variant_id: m?.variant_id === '' || m?.variant_id === 'null' || typeof m?.variant_id === 'undefined' ? null : m.variant_id,
})

/* Turns a variant key like "Red_Large" or "Red_default" into "Red / Large" for display */
const formatVariantLabel = (key) => {
  if (!key) return ''
  return String(key)
    .replace(/_default$/, '')
    .split('_')
    .filter(Boolean)
    .join(' / ')
}

const VariantUploaderModal = ({ productId, onMediaChange, showModal, setShowModal, activeVariantKey = null }) => {
  const [previewImage, setPreviewImage] = useState(null)

  // 🔵 Variant media still uses this list (UNCHANGED)
  const [masterMediaList, setMasterMediaList] = useState([])

  // 🟢 NEW: product-only state that feeds the Product Media section
  const [productMedia, setProductMedia] = useState([])

  const [imageLoading, setImageLoading] = useState({})
  const [uploadProgress, setUploadProgress] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [mediaFetching, setMediaFetching] = useState(false)
  const [selectedVariantKey, setSelectedVariantKey] = useState(null)
  const [selectedMainImage, setSelectedMainImage] = useState(null)
  const [hoveredClose, setHoveredClose] = useState({})
  const [hoveredId, setHoveredId] = useState(null)
  const [dragActive, setDragActive] = useState(false)
  const [structuredMedia, setStructuredMedia] = useState(null)

  const fileInputRef = useRef()

  const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL
  const isUpdatePage = typeof window !== 'undefined' && window.location.pathname.includes('/update_product')

  // 🔵 Variant gallery derived from masterMediaList (UNCHANGED)
  const activeFlat = useMemo(() => masterMediaList.filter((m) => m?.status !== 'inactive'), [masterMediaList])

  const productGallery = useMemo(() => (productMedia || []).filter((m) => m?.variant_id == null), [productMedia])
  // 🔵 Variant Media unchanged
  const variantGallery = useMemo(() => activeFlat.filter((m) => m?.variant_id != null), [activeFlat])

  // Set selected variant on modal open (UNCHANGED)
  useEffect(() => {
    if (!showModal) return

    // important: clear old variant when opened from product media button
    setSelectedVariantKey(activeVariantKey ?? null)
  }, [showModal, activeVariantKey])
  // Selected main image for active variant.
  //  Now also falls back to the PARENT option's applied image (e.g. "Red_Large"
  // falls back to "Red_default") so re-opening the modal for a child variant that
  // is simply inheriting its parent's image still shows that image as selected.
  useEffect(() => {
    if (!showModal || !selectedVariantKey) return

    const vKey = String(selectedVariantKey)
    const parentKey = vKey.includes('_') && !vKey.endsWith('_default') ? `${vKey.split('_')[0]}_default` : null

    const ownStored = sessionStorage.getItem(`variant_image_${vKey}`)
    const parentStored = parentKey ? sessionStorage.getItem(`variant_image_${parentKey}`) : null

    if (ownStored) {
      setSelectedMainImage(ownStored)
      return
    }
    if (parentStored) {
      setSelectedMainImage(parentStored)
      return
    }

    const fallbackMain =
      masterMediaList.find((m) => m.variant_id === vKey && m.main) ||
      (parentKey ? masterMediaList.find((m) => m.variant_id === parentKey && m.main) : null)
    setSelectedMainImage(fallbackMain?.media_url || null)
  }, [showModal, selectedVariantKey, masterMediaList])

  /* ===========================================================
   * Load backend product_main + product_sub into Product Media,
   * AND put backend variant_media into master list (variant section).
   * Variant logic otherwise remains the same.
   * =========================================================== */
  useEffect(() => {
    if (!showModal || !isUpdatePage || !productId) return

    const key = `product_media_${productId}`
    const url = `${API_BASE_URL}/product-media/${productId}`

    const flatten = (payload) => {
      const src = payload?.media && typeof payload.media === 'object' ? payload.media : payload

      const pm = src?.product_main
      const ps = Array.isArray(src?.product_sub) ? src.product_sub : []
      const vm = src?.variant_media && typeof src.variant_media === 'object' ? src.variant_media : {}

      const productMain = pm ? [pm] : []
      const productFlat = [...productMain, ...ps].map(normalizeVariantId)

      const variantFlat = Object.values(vm)
        .flatMap((set) => {
          const main = set?.main ? [set.main] : []
          const sub = Array.isArray(set?.sub) ? set.sub : []
          return [...main, ...sub]
        })
        .map(normalizeVariantId)

      return { productFlat, variantFlat }
    }

    ;(async () => {
      setMediaFetching(true)

      try {
        const res = await axios.get(url)
        const payload = res.data?.media ?? res.data
        setStructuredMedia(payload)

        const { productFlat, variantFlat } = flatten(payload)

        setProductMedia(productFlat.filter((m) => m?.variant_id == null))

        const vm = readVM()
        const bucket = ensureBucket(vm, getPidKey(productId))
        const localVariantAll = Object.values(bucket.variants || {}).flat() || []
        const mergedVariants = mergeUniqueByUrl(variantFlat, localVariantAll.map(normalizeVariantId))

        setMasterMediaList((prev) => mergeUniqueByUrl(prev, mergedVariants))

        sessionStorage.setItem(key, JSON.stringify(payload))
        onMediaChange?.(mergeUniqueByUrl(productFlat, mergedVariants))
      } catch (err) {
        const fallback = sessionStorage.getItem(key)

        if (fallback) {
          try {
            const parsed = JSON.parse(fallback)
            const { productFlat, variantFlat } = flatten(parsed)

            setProductMedia(productFlat)

            const vm = readVM()
            const bucket = ensureBucket(vm, getPidKey(productId))
            const localVariantAll = Object.values(bucket.variants || {}).flat() || []
            const mergedVariants = mergeUniqueByUrl(variantFlat, localVariantAll.map(normalizeVariantId))

            setMasterMediaList((prev) => mergeUniqueByUrl(prev, mergedVariants))
            onMediaChange?.(mergeUniqueByUrl(productFlat, mergedVariants))
          } catch {
            sessionStorage.removeItem(key)
          }
        }
      } finally {
        setMediaFetching(false)
      }
    })()
  }, [showModal, isUpdatePage, productId, API_BASE_URL, onMediaChange])
  // Rehydrate from local variant_media when modal opens (UNCHANGED)
  useEffect(() => {
    if (!showModal) return
    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const storedProduct = bucket.product || [] // harmless; product section uses productMedia state now
    const storedVariant = selectedVariantKey != null ? bucket.variants?.[String(selectedVariantKey)] || [] : []

    const toMerge = [...storedProduct, ...storedVariant]
    if (!toMerge.length) return

    setMasterMediaList((prev) => {
      const merged = mergeUniqueByUrl(prev, toMerge.map(normalizeVariantId))
      if (merged.length !== prev.length) onMediaChange?.(merged)
      return merged
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal, selectedVariantKey, productId])

  // Rehydrate product-level media when modal opens
  // Always show latest product-level media when modal opens,
  // even when opened from variant media button
  useEffect(() => {
    if (!showModal) return

    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const storedProduct = (bucket.product || []).map(normalizeVariantId).filter((m) => m?.variant_id == null)

    if (storedProduct.length > 0) {
      setProductMedia((prev) => mergeUniqueByUrl(prev, storedProduct))
    }

    if (isUpdatePage && productId) {
      refetchProductMedia()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal, productId])

  // Fallback for Add Product: read from 'media_staging' (array) if VM bucket is empty
  useEffect(() => {
    if (!showModal) return
    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const hasBucketProduct = (bucket.product || []).length > 0

    if (!hasBucketProduct) {
      const raw = sessionStorage.getItem('media_staging')
      if (raw) {
        try {
          const arr = JSON.parse(raw)
          if (Array.isArray(arr) && arr.length) {
            const productOnly = arr.map(normalizeVariantId).filter((m) => m?.variant_id == null)
            if (productOnly.length) {
              setProductMedia((prev) => mergeUniqueByUrl(prev, productOnly))
            }
          }
        } catch {
          // ignore malformed staging
        }
      }
    }
  }, [showModal, productId])

  // Persist a flat snapshot of what you're showing (UNCHANGED)
  useEffect(() => {
    if (!showModal) return

    const key = isUpdatePage && productId ? `product_media_${productId}_flat_mixed` : 'media_staging'

    //  For Add Product: only persist product-level images to media_staging
    const productOnly = (productMedia || []).filter((m) => m?.variant_id == null)

    if (key === 'media_staging') {
      sessionStorage.setItem(key, JSON.stringify(productOnly))
      onMediaChange?.(productOnly)
    } else {
      //  For Update Product: keep current behavior (product + variant snapshot)
      const flatMixed = [...(productMedia || []), ...(masterMediaList || [])]
      sessionStorage.setItem(key, JSON.stringify(flatMixed))
      onMediaChange?.(flatMixed)
    }
  }, [masterMediaList, productMedia, showModal, isUpdatePage, productId, onMediaChange])

  const MAX_MODAL_MEDIA = 90

  const refetchProductMedia = async () => {
    if (!isUpdatePage || !productId) return

    const url = `${API_BASE_URL}/product-media/${productId}`
    const key = `product_media_${productId}`

    try {
      setMediaFetching(true)

      const res = await axios.get(url)
      const payload = res.data?.media ?? res.data
      setStructuredMedia(payload)

      const src = payload?.media && typeof payload.media === 'object' ? payload.media : payload

      const productMain = src?.product_main ? [src.product_main] : []
      const productSub = Array.isArray(src?.product_sub) ? src.product_sub : []

      const productFlat = [...productMain, ...productSub].map(normalizeVariantId).filter((m) => m?.variant_id == null)

      setProductMedia((prev) => mergeUniqueByUrl(prev, productFlat))

      sessionStorage.setItem(key, JSON.stringify(payload))
    } catch (err) {
      console.error('Product media refetch failed:', err)
    } finally {
      setMediaFetching(false)
    }
  }

  /** Core upload logic — now takes a plain array of File objects so both the
   * <input type="file"> change handler and drag & drop can share it. */
  const processFiles = async (incomingFiles) => {
    if (!incomingFiles?.length) return

    const currentTotal = masterMediaList.filter((m) => m.status !== 'inactive').length
    const totalAfterUpload = currentTotal + incomingFiles.length
    if (totalAfterUpload > MAX_MODAL_MEDIA) {
      Swal.fire({
        icon: 'warning',
        title: 'Upload Limit Reached',
        text: `You can only upload up to ${MAX_MODAL_MEDIA} files in total for this product.`,
        confirmButtonColor: '#3085d6',
      })
      if (fileInputRef.current) fileInputRef.current.value = ''
      return
    }

    const formData = new FormData()
    for (let file of incomingFiles) formData.append('files', file)
    if (isUpdatePage && productId) formData.append('product_id', productId)

    try {
      const endpoint = isUpdatePage && productId ? `${API_BASE_URL}/product-media/upload` : `${API_BASE_URL}/product-media/upload-staging`

      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(endpoint, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => {
          const percent = Math.round((e.loaded * 100) / e.total)
          setUploadProgress(percent)
        },
      })

      setUploadProgress(null)
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''

      const newMedia = res.data.media || []
      const isVariantUpload = selectedVariantKey != null

      const updatedNew = newMedia.map((m, i) => ({
        ...m,
        variant_id: isVariantUpload ? selectedVariantKey : null,
        main: isVariantUpload
          ? activeFlat.filter((x) => x.variant_id === selectedVariantKey).length === 0 && i === 0
          : productMedia.filter((x) => x?.variant_id == null).length === 0 && i === 0,
        temp: true,
        status: m.status || 'active',
      }))

      // keep original behavior: push into master list (affects Variant section if a variant is selected)
      if (isVariantUpload) {
        setMasterMediaList((prev) => mergeUniqueByUrl(prev, updatedNew))
      } else {
        setProductMedia((prev) => mergeUniqueByUrl(prev, updatedNew))
      }

      // persist local
      pushToScopeStore({
        productId,
        variantKey: selectedVariantKey ?? null,
        items: updatedNew,
      })

      // immediately refresh product media after product-level upload
    } catch (err) {
      setUploading(false)
      setUploadProgress(null)
      console.error('Upload failed:', err)
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: 'Something went wrong while uploading the files.',
      })
    }
  }

  const handleFiles = (event) => {
    const files = event.target.files
    if (!files?.length) return
    processFiles(Array.from(files))
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    const files = e.dataTransfer?.files
    if (files?.length) processFiles(Array.from(files))
  }

  // Delete (UNCHANGED)
  const handleDelete = async (media) => {
    const mediaId = media?.media_id || media?.id || media?.media_url
    if (!mediaId) return

    if (isUpdatePage && productId && media?.media_id && !media?.temp) {
      try {
        await axios.patch(`${API_BASE_URL}/product-media/${productId}/${media.media_id}`, { status: 'inactive' })
      } catch {
        alert('Soft delete failed')
        return
      }
    }
    setMasterMediaList((prev) =>
      prev.filter((item) => {
        const id = item.media_id || item.id || item.media_url
        return id !== mediaId
      }),
    )
    removeFromScopeStore({ productId, media })
  }

  const handleImageLoad = (id) => setImageLoading((prev) => ({ ...prev, [id]: false }))
  const handleImageStartLoading = (id) => setImageLoading((prev) => ({ ...prev, [id]: true }))

  const renderMediaItem = (media, key, { isVariant } = { isVariant: false }) => {
    const mediaId = media.media_id || media.id || media.media_url || key
    const showClose = !!isVariant // only for variant images
    const isSelected = !!selectedMainImage && selectedMainImage === media.media_url
    const isHovered = hoveredId === mediaId

    return (
      <div key={mediaId} className="col-6 col-md-4 col-lg-3 mb-3">
        <div
          onMouseEnter={() => setHoveredId(mediaId)}
          onMouseLeave={() => setHoveredId((prev) => (prev === mediaId ? null : prev))}
          className="position-relative rounded overflow-hidden"
          style={{
            height: 140,
            background: '#f8f9fa',
            border: isSelected ? '2.5px solid #198754' : '1.5px solid #e9ecef',
            boxShadow: isSelected ? '0 0 0 3px rgba(25,135,84,0.15)' : isHovered ? '0 6px 16px rgba(0,0,0,0.12)' : '0 1px 3px rgba(0,0,0,0.05)',
            transition: 'box-shadow .15s ease, border-color .15s ease',
          }}>
          {media.media_type === 'image' && (
            <>
              {imageLoading[mediaId] && (
                <div
                  className="position-absolute w-100 h-100 bg-white bg-opacity-75 d-flex justify-content-center align-items-center"
                  style={{ zIndex: 1 }}>
                  <Spinner animation="border" size="sm" variant="success" />
                </div>
              )}
              <Image
                src={media.media_url}
                className="w-100 h-100 object-fit-cover"
                onClick={() => setSelectedMainImage(media.media_url)}
                onLoadStart={() => handleImageStartLoading(mediaId)}
                onLoad={() => handleImageLoad(mediaId)}
                onError={() => handleImageLoad(mediaId)}
                style={{ cursor: 'pointer' }}
                alt="Media"
              />
            </>
          )}

          {media.media_type === 'video' && (
            <>
              {imageLoading[mediaId] && (
                <div
                  className="position-absolute w-100 h-100 bg-white bg-opacity-75 d-flex justify-content-center align-items-center"
                  style={{ zIndex: 1 }}>
                  <Spinner animation="border" size="sm" variant="success" />
                </div>
              )}

              <video
                src={media.media_url}
                className="w-100 h-100"
                controls
                muted
                preload="metadata"
                onLoadedData={() => handleImageLoad(mediaId)}
                onLoadStart={() => handleImageStartLoading(mediaId)}
                style={{ objectFit: 'cover' }}
              />
            </>
          )}

          {media.media_type === '3d' && (
            <div className="bg-light d-flex flex-column align-items-center justify-content-center w-100 h-100 text-muted">
              <Icon icon="mdi:cube-outline" width={26} height={26} />
              <span style={{ fontSize: 11, marginTop: 4 }}>3D File</span>
            </div>
          )}

          {/* Hover scrim */}
          <div
            className="position-absolute top-0 start-0 w-100 h-100"
            style={{
              background: isHovered ? 'rgba(0,0,0,0.25)' : 'transparent',
              transition: 'background .15s ease',
              pointerEvents: 'none',
            }}
          />

          {/* Preview (eye) button on hover */}
          {isHovered && media.media_type === 'image' && (
            <button
              type="button"
              className="position-absolute border-0 rounded-circle d-flex align-items-center justify-content-center"
              onClick={(e) => {
                e.stopPropagation()
                setPreviewImage(media.media_url)
              }}
              style={{
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: 34,
                height: 34,
                background: 'rgba(255,255,255,0.92)',
                zIndex: 2,
                cursor: 'pointer',
              }}
              title="Preview">
              <Icon icon="mdi:eye-outline" width={18} height={18} style={{ color: '#212529' }} />
            </button>
          )}

          {/* Selected checkmark badge */}
          {isSelected && (
            <div
              className="position-absolute d-flex align-items-center justify-content-center rounded-circle"
              style={{
                top: 6,
                left: 6,
                width: 22,
                height: 22,
                background: '#198754',
                zIndex: 3,
                boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
              }}>
              <Icon icon="mdi:check" width={14} height={14} style={{ color: '#fff' }} />
            </div>
          )}

          {showClose && (
            <button
              type="button"
              className="position-absolute top-0 end-0 m-1 p-1 rounded-circle border-0"
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(media)
              }}
              onMouseEnter={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: true }))}
              onMouseLeave={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: false }))}
              style={{
                zIndex: 5,
                cursor: 'pointer',
                opacity: isHovered ? 1 : 0,
                transition: 'transform 120ms ease, background-color 120ms ease, box-shadow 120ms ease, opacity 120ms ease',
                transform: hoveredClose[mediaId] ? 'scale(1.08)' : 'scale(1)',
                backgroundColor: hoveredClose[mediaId] ? '#ffffff' : 'rgba(0,0,0,0.55)',
                boxShadow: hoveredClose[mediaId] ? '0 4px 12px rgba(0,0,0,0.25)' : '0 2px 8px rgba(0,0,0,0.2)',
              }}
              aria-label="Remove"
              title="Remove">
              <Icon icon="mdi:close" width={20} height={20} style={{ color: hoveredClose[mediaId] ? '#dc3545' : '#ffffffe8' }} />
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <>
      <Modal
        show={showModal}
        onHide={() => setShowModal(false)}
        centered
        size="lg"
        contentClassName="border-0"
        style={{ '--bs-modal-border-radius': '14px' }}>
        <Modal.Header closeButton style={{ borderBottom: '1px solid #eef0f2', padding: '18px 24px' }}>
          <div>
            <Modal.Title style={{ fontSize: 18, fontWeight: 700, color: '#212529' }}>Manage Media</Modal.Title>
            <div style={{ fontSize: 13, color: '#6c757d', marginTop: 2 }}>
              Upload images or videos for this product, or assign a specific image to a variant.
            </div>
          </div>
        </Modal.Header>

        <Modal.Body style={{ padding: '22px 24px' }}>
          {selectedVariantKey && (
            <div className="d-flex align-items-center gap-2 mb-3 px-3 py-2 rounded" style={{ background: '#eef6ff', border: '1px solid #d3e6ff' }}>
              <Icon icon="mdi:tag-outline" width={16} height={16} style={{ color: '#0d6efd', flexShrink: 0 }} />
              <span style={{ fontSize: 13, color: '#0d6efd', fontWeight: 600 }}>Selecting image for: {formatVariantLabel(selectedVariantKey)}</span>
            </div>
          )}

          {/* Dropzone */}
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault()
              setDragActive(true)
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className="d-flex flex-column align-items-center justify-content-center text-center mb-3"
            style={{
              border: `2px dashed ${dragActive ? '#198754' : '#dee2e6'}`,
              borderRadius: 12,
              padding: '26px 16px',
              cursor: 'pointer',
              background: dragActive ? '#f0faf5' : '#fafbfc',
              transition: 'border-color .15s ease, background .15s ease',
            }}>
            <Icon icon="mdi:cloud-upload-outline" width={32} height={32} style={{ color: dragActive ? '#198754' : '#adb5bd', marginBottom: 6 }} />
            <div style={{ fontSize: 14, fontWeight: 600, color: '#212529' }}>Drag & drop images or videos here</div>
            <div style={{ fontSize: 12, color: '#6c757d', marginTop: 2 }}>
              or click to browse · PNG, JPG, MP4, GLB · up to {MAX_MODAL_MEDIA} files total
            </div>
            <input type="file" ref={fileInputRef} onChange={handleFiles} multiple accept="image/*,video/*,.glb" style={{ display: 'none' }} />
          </div>

          {uploading && (
            <div className="mb-3">
              <ProgressBar
                now={uploadProgress}
                label={`${uploadProgress}%`}
                animated
                striped
                variant="success"
                style={{ height: 8, borderRadius: 6 }}
              />
            </div>
          )}

          {/* PRODUCT GALLERY — backend product_main + product_sub ONLY */}
          <div className="d-flex align-items-center justify-content-between mb-2">
            <h6 className="text-uppercase mb-0" style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.6px', color: '#6c757d' }}>
              Product Media
            </h6>
            <span style={{ fontSize: 12, color: '#adb5bd' }}>
              {productGallery.length} item{productGallery.length !== 1 ? 's' : ''}
            </span>
          </div>
          {mediaFetching ? (
            <div className="text-center py-4 mb-2" style={{ border: '1px dashed #eee', borderRadius: 8 }}>
              <Spinner animation="border" size="sm" variant="success" />
              <div style={{ fontSize: 13, color: '#6c757d', marginTop: 8 }}>Loading product media...</div>
            </div>
          ) : productGallery.length === 0 ? (
            <div className="text-center py-3 mb-2" style={{ fontSize: 13, color: '#adb5bd', border: '1px dashed #eee', borderRadius: 8 }}>
              No product images yet.
            </div>
          ) : (
            <div className="row g-2 mb-1">{productGallery.map((m, i) => renderMediaItem(m, `p-${m.media_id ?? i}`, { isVariant: false }))}</div>
          )}

          <hr className="my-3" style={{ borderColor: '#eef0f2' }} />

          {/* VARIANT GALLERY — UNCHANGED (driven by masterMediaList) */}
          <div className="d-flex align-items-center justify-content-between mb-2">
            <h6 className="text-uppercase mb-0" style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.6px', color: '#6c757d' }}>
              Variant Media
            </h6>
            <span style={{ fontSize: 12, color: '#adb5bd' }}>
              {variantGallery.length} item{variantGallery.length !== 1 ? 's' : ''}
            </span>
          </div>
          {mediaFetching ? (
            <div className="text-center py-4" style={{ border: '1px dashed #eee', borderRadius: 8 }}>
              <Spinner animation="border" size="sm" variant="success" />
              <div style={{ fontSize: 13, color: '#6c757d', marginTop: 8 }}>Loading variant media...</div>
            </div>
          ) : variantGallery.length === 0 ? (
            <div className="text-center py-3" style={{ fontSize: 13, color: '#adb5bd', border: '1px dashed #eee', borderRadius: 8 }}>
              No variant images yet — upload above to assign one.
            </div>
          ) : (
            <div className="row g-2">{variantGallery.map((m, i) => renderMediaItem(m, `v-${m.media_id ?? i}`, { isVariant: true }))}</div>
          )}
        </Modal.Body>

        <Modal.Footer
          style={{
            borderTop: '1px solid #eef0f2',
            padding: '14px 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
          <div className="d-flex align-items-center gap-2">
            {selectedMainImage ? (
              <>
                <div style={{ width: 32, height: 32, borderRadius: 6, overflow: 'hidden', border: '1px solid #dee2e6', flexShrink: 0 }}>
                  <Image src={selectedMainImage} alt="Selected" className="w-100 h-100 object-fit-cover" />
                </div>
                <span style={{ fontSize: 12, color: '#6c757d' }}>Image selected</span>
              </>
            ) : (
              <span style={{ fontSize: 12, color: '#adb5bd' }}>No image selected yet</span>
            )}
          </div>
          <div className="d-flex gap-2">
            <Button variant="light" onClick={() => setShowModal(false)}>
              Close
            </Button>
            <Button
              variant="success"
              disabled={!selectedMainImage}
              onClick={() => {
                const updated = masterMediaList.map((img) => ({
                  ...img,
                  main: img.media_url === selectedMainImage && img.variant_id === selectedVariantKey,
                }))
                setMasterMediaList(updated)
                onMediaChange?.(updated)
                if (selectedVariantKey) {
                  sessionStorage.setItem(`variant_image_${selectedVariantKey}`, selectedMainImage)
                }
                setShowModal(false)
              }}>
              Apply
            </Button>
          </div>
        </Modal.Footer>
      </Modal>

      {/* Full-screen preview */}
      <Modal show={!!previewImage} onHide={() => setPreviewImage(null)} centered size="xl" backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>Image Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
          <div style={{ maxWidth: '600px', aspectRatio: '1 / 1', backgroundColor: '#f9f9f9' }}>
            <Image src={previewImage || ''} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} fluid />
          </div>
        </Modal.Body>
      </Modal>
    </>
  )
}

export default VariantUploaderModal
