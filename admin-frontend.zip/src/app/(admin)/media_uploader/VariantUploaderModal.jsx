'use client'

import { useState, useRef, useEffect, useMemo } from 'react'
import { Button, Modal, Image, Spinner, ProgressBar } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import axios from 'axios'
import Swal from 'sweetalert2'

/* ====== storage helpers (variant_media store) ====== */
const VM_KEY = 'variant_media'
const PID_STAGING = '__staging__'

const safeParseObject = (v) => {
  try {
    const p = JSON.parse(v)
    return p && typeof p === 'object' && !Array.isArray(p) ? p : {}
  } catch {
    return {}
  }
}
const readVM = () => {
  if (typeof window === 'undefined') return {}
  const raw = sessionStorage.getItem(VM_KEY) ?? localStorage.getItem(VM_KEY)
  return safeParseObject(raw)
}
const writeVM = (vm) => {
  if (typeof window === 'undefined') return
  const json = JSON.stringify(vm || {})
  sessionStorage.setItem(VM_KEY, json)
  localStorage.setItem(VM_KEY, json)
}
const getPidKey = (productId) => (productId ? String(productId) : PID_STAGING)

const ensureBucket = (vm, pidKey) => {
  if (!vm[pidKey]) vm[pidKey] = { product: [], variants: {} }
  if (!Array.isArray(vm[pidKey].product)) vm[pidKey].product = []
  if (!vm[pidKey].variants || typeof vm[pidKey].variants !== 'object') vm[pidKey].variants = {}
  return vm[pidKey]
}

const mergeUniqueByUrl = (base = [], incoming = []) => {
  const map = new Map()
  ;[...base, ...incoming].forEach((m) => {
    if (m?.media_url) map.set(m.media_url, m)
  })
  return [...map.values()]
}

/** Append items into variant_media store */
const pushToScopeStore = ({ productId, variantKey, items }) => {
  if (!items?.length) return
  const pidKey = getPidKey(productId)
  const vm = readVM()
  const bucket = ensureBucket(vm, pidKey)

  if (variantKey != null) {
    const vk = String(variantKey)
    bucket.variants[vk] = mergeUniqueByUrl(
      bucket.variants[vk] || [],
      items.map((it) => ({ ...it, variant_id: variantKey })),
    )
  } else {
    // product scope
    bucket.product = mergeUniqueByUrl(
      bucket.product,
      items.filter((m) => m?.variant_id == null),
    )
  }

  writeVM(vm)
}

/** Remove a single media from the right place inside variant_media store */
const removeFromScopeStore = ({ productId, media }) => {
  const pidKey = getPidKey(productId)
  const vm = readVM()
  const bucket = ensureBucket(vm, pidKey)

  const mediaId = media?.media_id || media?.id || media?.media_url
  const filterFn = (m) => (m.media_id || m.id || m.media_url) !== mediaId

  if (media?.variant_id != null) {
    const vk = String(media.variant_id)
    const current = bucket.variants[vk] || []
    bucket.variants[vk] = current.filter(filterFn)
  } else {
    bucket.product = (bucket.product || []).filter(filterFn)
  }

  writeVM(vm)
}
/* ====== end storage helpers ====== */

/* tiny helper to normalize variant_id to null when missing */
const normalizeVariantId = (m) => ({
  ...m,
  variant_id: m?.variant_id === '' || m?.variant_id === 'null' || typeof m?.variant_id === 'undefined' ? null : m.variant_id,
})

const VariantUploaderModal = ({ productId, onMediaChange, showModal, setShowModal, activeVariantKey = null }) => {
  const [previewImage, setPreviewImage] = useState(null)

  // 🔵 Variant media still uses this list (UNCHANGED)
  const [masterMediaList, setMasterMediaList] = useState([])

  // 🟢 NEW: product-only state that feeds the Product Media section
  const [productMedia, setProductMedia] = useState([])

  const [imageLoading, setImageLoading] = useState({})
  const [uploadProgress, setUploadProgress] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [selectedVariantKey, setSelectedVariantKey] = useState(null)
  const [selectedMainImage, setSelectedMainImage] = useState(null)
  const [hoveredClose, setHoveredClose] = useState({})
  const [structuredMedia, setStructuredMedia] = useState(null)

  const fileInputRef = useRef()

  const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL
  const isUpdatePage = typeof window !== 'undefined' && window.location.pathname.includes('/update_product')

  // 🔵 Variant gallery derived from masterMediaList (UNCHANGED)
  const activeFlat = useMemo(() => masterMediaList.filter((m) => m?.status !== 'inactive'), [masterMediaList])

  const productGallery = useMemo(() => (productMedia || []).filter((m) => m?.variant_id == null), [productMedia])
  // 🔵 Variant Media unchanged
  const variantGallery = useMemo(() => activeFlat.filter((m) => m?.variant_id != null), [activeFlat])

  // Set selected variant on modal open (UNCHANGED)
  useEffect(() => {
    if (showModal && activeVariantKey) setSelectedVariantKey(activeVariantKey)
  }, [showModal, activeVariantKey])

  // Selected main image for active variant (UNCHANGED)
  useEffect(() => {
    if (!showModal || !selectedVariantKey) return
    const stored = sessionStorage.getItem(`variant_image_${selectedVariantKey}`)
    if (stored) {
      setSelectedMainImage(stored)
    } else {
      const fallbackMain = masterMediaList.find((m) => m.variant_id === selectedVariantKey && m.main)
      setSelectedMainImage(fallbackMain?.media_url || null)
    }
  }, [showModal, selectedVariantKey, masterMediaList])

  /* ===========================================================
   * Load backend product_main + product_sub into Product Media,
   * AND put backend variant_media into master list (variant section).
   * Variant logic otherwise remains the same.
   * =========================================================== */
  useEffect(() => {
    if (!showModal || !isUpdatePage || !productId) return
    const key = `product_media_${productId}`
    const url = `${API_BASE_URL}/product-media/${productId}`

    const flatten = (payload) => {
      // tolerate either top-level or .media wrapper
      const src = payload?.media && typeof payload.media === 'object' ? payload.media : payload

      const pm = src?.product_main
      const ps = Array.isArray(src?.product_sub) ? src.product_sub : []
      const vm = src?.variant_media && typeof src.variant_media === 'object' ? src.variant_media : {}

      const productMain = pm ? [pm] : []
      const productFlat = [...productMain, ...ps].map(normalizeVariantId)

      const variantFlat = Object.values(vm)
        .flatMap((set) => {
          const main = set?.main ? [set.main] : []
          const sub = Array.isArray(set?.sub) ? set.sub : []
          return [...main, ...sub]
        })
        .map(normalizeVariantId)

      return { productFlat, variantFlat }
    }

    ;(async () => {
      try {
        const res = await axios.get(url)
        const payload = res.data?.media ?? res.data
        setStructuredMedia(payload)

        const { productFlat, variantFlat } = flatten(payload)

        // 🟢 Show product_main + product_sub in Product Media section
        setProductMedia(productFlat.filter((m) => m?.variant_id == null))
        // 🔵 Keep variant section logic unchanged: merge backend variant + local variant uploads
        const vm = readVM()
        const bucket = ensureBucket(vm, getPidKey(productId))
        const localVariantAll = Object.values(bucket.variants || {}).flat() || []
        const mergedVariants = mergeUniqueByUrl(variantFlat, localVariantAll.map(normalizeVariantId))

        setMasterMediaList((prev) => mergeUniqueByUrl(prev, mergedVariants))

        // keep your snapshot
        sessionStorage.setItem(key, JSON.stringify(payload))
        onMediaChange?.(mergeUniqueByUrl(productFlat, mergedVariants)) // optional bubble-up
      } catch (err) {
        // Fallback to snapshot
        const fallback = sessionStorage.getItem(key)
        if (fallback) {
          try {
            const parsed = JSON.parse(fallback)
            const { productFlat, variantFlat } = flatten(parsed)

            setProductMedia(productFlat)

            const vm = readVM()
            const bucket = ensureBucket(vm, getPidKey(productId))
            const localVariantAll = Object.values(bucket.variants || {}).flat() || []
            const mergedVariants = mergeUniqueByUrl(variantFlat, localVariantAll.map(normalizeVariantId))

            setMasterMediaList((prev) => mergeUniqueByUrl(prev, mergedVariants))
            onMediaChange?.(mergeUniqueByUrl(productFlat, mergedVariants))
          } catch {
            sessionStorage.removeItem(key)
          }
        }
      }
    })()
  }, [showModal, isUpdatePage, productId, API_BASE_URL, onMediaChange])

  // Rehydrate from local variant_media when modal opens (UNCHANGED)
  useEffect(() => {
    if (!showModal) return
    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const storedProduct = bucket.product || [] // harmless; product section uses productMedia state now
    const storedVariant = selectedVariantKey != null ? bucket.variants?.[String(selectedVariantKey)] || [] : []

    const toMerge = [...storedProduct, ...storedVariant]
    if (!toMerge.length) return

    setMasterMediaList((prev) => {
      const merged = mergeUniqueByUrl(prev, toMerge.map(normalizeVariantId))
      if (merged.length !== prev.length) onMediaChange?.(merged)
      return merged
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showModal, selectedVariantKey, productId])

  // Rehydrate product-level media when modal opens
  useEffect(() => {
    if (!showModal) return
    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const storedProduct = bucket.product || []
    if (storedProduct.length > 0) {
      setProductMedia((prev) => mergeUniqueByUrl(prev, storedProduct.map(normalizeVariantId)))
    }
  }, [showModal, productId])

  // Fallback for Add Product: read from 'media_staging' (array) if VM bucket is empty
  useEffect(() => {
    if (!showModal) return
    const vm = readVM()
    const bucket = ensureBucket(vm, getPidKey(productId))
    const hasBucketProduct = (bucket.product || []).length > 0

    if (!hasBucketProduct) {
      const raw = sessionStorage.getItem('media_staging')
      if (raw) {
        try {
          const arr = JSON.parse(raw)
          if (Array.isArray(arr) && arr.length) {
            const productOnly = arr.map(normalizeVariantId).filter((m) => m?.variant_id == null)
            if (productOnly.length) {
              setProductMedia((prev) => mergeUniqueByUrl(prev, productOnly))
            }
          }
        } catch {
          // ignore malformed staging
        }
      }
    }
  }, [showModal, productId])

  // Persist a flat snapshot of what you're showing (UNCHANGED)
  useEffect(() => {
    if (!showModal) return

    const key = isUpdatePage && productId ? `product_media_${productId}_flat_mixed` : 'media_staging'

    // ✅ For Add Product: only persist product-level images to media_staging
    const productOnly = (productMedia || []).filter((m) => m?.variant_id == null)

    if (key === 'media_staging') {
      sessionStorage.setItem(key, JSON.stringify(productOnly))
      onMediaChange?.(productOnly)
    } else {
      // ✅ For Update Product: keep current behavior (product + variant snapshot)
      const flatMixed = [...(productMedia || []), ...(masterMediaList || [])]
      sessionStorage.setItem(key, JSON.stringify(flatMixed))
      onMediaChange?.(flatMixed)
    }
  }, [masterMediaList, productMedia, showModal, isUpdatePage, productId, onMediaChange])

  const MAX_MODAL_MEDIA = 90

  const handleFiles = async (event) => {
    const files = event.target.files
    if (!files?.length) return

    const currentTotal = masterMediaList.filter((m) => m.status !== 'inactive').length
    const incomingFiles = Array.from(files)
    const totalAfterUpload = currentTotal + incomingFiles.length
    if (totalAfterUpload > MAX_MODAL_MEDIA) {
      Swal.fire({
        icon: 'warning',
        title: 'Upload Limit Reached',
        text: `You can only upload up to ${MAX_MODAL_MEDIA} files in total for this product.`,
        confirmButtonColor: '#3085d6',
      })
      fileInputRef.current.value = ''
      return
    }

    const formData = new FormData()
    for (let file of incomingFiles) formData.append('files', file)
    if (isUpdatePage && productId) formData.append('product_id', productId)

    try {
      const endpoint = isUpdatePage && productId ? `${API_BASE_URL}/product-media/upload` : `${API_BASE_URL}/product-media/upload-staging`

      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(endpoint, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => {
          const percent = Math.round((e.loaded * 100) / e.total)
          setUploadProgress(percent)
        },
      })

      setUploadProgress(null)
      setUploading(false)
      fileInputRef.current.value = ''

      const newMedia = res.data.media || []
      const updatedNew = newMedia.map((m, i) => ({
        ...m,
        variant_id: selectedVariantKey || null,
        main: activeFlat.filter((x) => (selectedVariantKey ? x.variant_id === selectedVariantKey : x.variant_id == null)).length === 0 && i === 0,
        temp: true,
        status: m.status || 'active',
      }))

      // keep original behavior: push into master list (affects Variant section if a variant is selected)
      const updated = [...masterMediaList, ...updatedNew]
      setMasterMediaList(updated)

      // persist local
      pushToScopeStore({
        productId,
        variantKey: selectedVariantKey ?? null,
        items: updatedNew,
      })

      // note: Product Media section is backend-driven; product uploads will appear after backend save/fetch
    } catch (err) {
      setUploading(false)
      setUploadProgress(null)
      console.error('Upload failed:', err)
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: 'Something went wrong while uploading the files.',
      })
    }
  }

  // Delete (UNCHANGED)
  const handleDelete = async (media) => {
    const mediaId = media?.media_id || media?.id || media?.media_url
    if (!mediaId) return

    if (isUpdatePage && productId && media?.media_id && !media?.temp) {
      try {
        await axios.patch(`${API_BASE_URL}/product-media/${productId}/${media.media_id}`, { status: 'inactive' })
      } catch {
        alert('Soft delete failed')
        return
      }
    }
    setMasterMediaList((prev) =>
      prev.filter((item) => {
        const id = item.media_id || item.id || item.media_url
        return id !== mediaId
      }),
    )
    removeFromScopeStore({ productId, media })
  }

  const handleImageLoad = (id) => setImageLoading((prev) => ({ ...prev, [id]: false }))
  const handleImageStartLoading = (id) => setImageLoading((prev) => ({ ...prev, [id]: true }))

  const renderMediaItem = (media, key, { isVariant } = { isVariant: false }) => {
    const mediaId = media.media_id || media.id || media.media_url || key
    const showClose = !!isVariant // only for variant images

    return (
      <div key={mediaId} className="col-6 col-md-4 col-lg-3 mb-2">
        <div
          className={`position-relative border rounded overflow-hidden ${selectedMainImage === media.media_url ? 'border-3 border-success' : ''}`}
          style={{ height: 140 }}>
          {media.media_type === 'image' && (
            <>
              {imageLoading[mediaId] && (
                <div className="position-absolute w-100 h-100 bg-white bg-opacity-75 d-flex justify-content-center align-items-center">
                  <Spinner animation="border" size="sm" />
                </div>
              )}
              <Image
                src={media.media_url}
                className="w-100 h-100 object-fit-cover"
                onClick={() => setSelectedMainImage(media.media_url)}
                onLoad={() => handleImageLoad(mediaId)}
                onLoadStart={() => handleImageStartLoading(mediaId)}
                style={{ cursor: 'pointer' }}
                alt="Media"
              />
            </>
          )}

          {media.media_type === 'video' && <video src={media.media_url} className="w-100 h-100" controls muted />}

          {media.media_type === '3d' && (
            <div className="bg-light d-flex align-items-center justify-content-center w-100 h-100">
              <span className="text-muted">3D File</span>
            </div>
          )}

          {showClose && (
            <button
              type="button"
              className="position-absolute top-0 end-0 m-1 p-1 rounded-circle border-0"
              onClick={(e) => {
                e.stopPropagation()
                handleDelete(media)
              }}
              onMouseEnter={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: true }))}
              onMouseLeave={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: false }))}
              style={{
                zIndex: 5,
                cursor: 'pointer',
                transition: 'transform 120ms ease, background-color 120ms ease, box-shadow 120ms ease',
                transform: hoveredClose[mediaId] ? 'scale(1.08)' : 'scale(1)',
                backgroundColor: hoveredClose[mediaId] ? '#ffffff' : 'rgba(0,0,0,0.55)',
                boxShadow: hoveredClose[mediaId] ? '0 4px 12px rgba(0,0,0,0.25)' : '0 2px 8px rgba(0,0,0,0.2)',
              }}
              aria-label="Remove"
              title="Remove">
              <Icon icon="mdi:close" width={24} height={24} style={{ color: hoveredClose[mediaId] ? '#dc3545' : '#ffffffe8' }} />
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <>
      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Upload Variant Media</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFiles}
            multiple
            accept="image/*,video/*,.glb"
            className="form-control mb-3"
            autoFocus
          />

          {uploading && (
            <div className="mb-3">
              <ProgressBar now={uploadProgress} label={`${uploadProgress}%`} animated striped variant="info" />
            </div>
          )}

          {/* PRODUCT GALLERY — backend product_main + product_sub ONLY */}
          <h6 className="text-muted mb-2">Product Media</h6>
          <div className="row g-2">{productGallery.map((m, i) => renderMediaItem(m, `p-${m.media_id ?? i}`, { isVariant: false }))}</div>

          <hr className="my-3" />

          {/* VARIANT GALLERY — UNCHANGED (driven by masterMediaList) */}
          <h6 className="text-muted mb-2">Variants Media</h6>
          <div className="row g-2">{variantGallery.map((m, i) => renderMediaItem(m, `v-${m.media_id ?? i}`, { isVariant: true }))}</div>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
          <Button
            variant="primary"
            disabled={!selectedMainImage}
            onClick={() => {
              const updated = masterMediaList.map((img) => ({
                ...img,
                main: img.media_url === selectedMainImage && img.variant_id === selectedVariantKey,
              }))
              setMasterMediaList(updated)
              onMediaChange?.(updated)
              if (selectedVariantKey) {
                sessionStorage.setItem(`variant_image_${selectedVariantKey}`, selectedMainImage)
              }
              setShowModal(false)
            }}>
            Apply
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Full-screen preview */}
      <Modal show={!!previewImage} onHide={() => setPreviewImage(null)} centered size="xl" backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>Image Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
          <div style={{ maxWidth: '600px', aspectRatio: '1 / 1', backgroundColor: '#f9f9f9' }}>
            <Image src={previewImage || ''} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} fluid />
          </div>
        </Modal.Body>
      </Modal>
    </>
  )
}

export default VariantUploaderModal
