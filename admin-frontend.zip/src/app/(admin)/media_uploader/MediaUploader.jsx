'use client'

import { useState, useRef, useEffect } from 'react'
import { Button, Modal, Image, Row, Col, Spinner, ProgressBar } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import axios from 'axios'
import { ReactSortable } from 'react-sortablejs'
import Swal from 'sweetalert2'

const MediaUploaderModal = ({ productId, onMediaChange, showModal, setShowModal, activeVariantKey = null, variants = [] }) => {
  // const MediaUploaderModal = ({ productId, onMediaChange, showModal, setShowModal }) => {

  const [previewImage, setPreviewImage] = useState(null)
  const [mediaList, setMediaList] = useState([])
  // const [showModal, setShowModal] = useState(false)
  const [imageLoading, setImageLoading] = useState({})
  const [uploadProgress, setUploadProgress] = useState(null)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef()
  const [selectedVariantKey, setSelectedVariantKey] = useState(null)
  const [hoveredClose, setHoveredClose] = useState({})

  const isUpdatePage = typeof window !== 'undefined' && window.location.pathname.includes('/update_product')

  const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL

  useEffect(() => {
    return () => {
      if (!isUpdatePage && !productId) {
        sessionStorage.removeItem('media_staging')
      }
    }
  }, [])

  useEffect(() => {
    if (showModal && activeVariantKey) {
      setSelectedVariantKey(activeVariantKey)
    }
  }, [showModal, activeVariantKey])

  useEffect(() => {
    if (!productId || !isUpdatePage) return

    const fetchMedia = async () => {
      try {
        const res = await axios.get(`${API_BASE_URL}/product-media/${productId}`)
        const { product_main, product_sub, variant_media } = res.data

        const structuredPayload = {
          product_main: product_main ? [product_main] : [],
          product_sub: product_sub || [],
          variant_media: variant_media || {},
        }

        const flatMedia = [...structuredPayload.product_main, ...structuredPayload.product_sub]

        setMediaList(flatMedia) // Show only product-level in modal UI
        sessionStorage.setItem(`product_media_${productId}`, JSON.stringify(structuredPayload))
        onMediaChange?.(structuredPayload) // send full object back
      } catch (error) {
        const fallback = sessionStorage.getItem(`product_media_${productId}`)
        if (fallback) {
          try {
            const parsed = JSON.parse(fallback)
            const flatMedia = [...(parsed.product_main || []), ...(parsed.product_sub || [])]
            setMediaList(flatMedia)
            onMediaChange?.(parsed)
          } catch {
            sessionStorage.removeItem(`product_media_${productId}`)
          }
        }
      }
    }

    fetchMedia()
  }, [productId, isUpdatePage])

  useEffect(() => {
    if (!productId && !isUpdatePage) {
      const stored = sessionStorage.getItem('media_staging')
      if (stored) {
        const parsed = JSON.parse(stored)
        setMediaList(parsed)
        onMediaChange?.(parsed)
      }
    }
  }, [productId, isUpdatePage])

  useEffect(() => {
    console.log('📦 Media payload:', mediaList)

    const key = isUpdatePage && productId ? `product_media_${productId}` : 'media_staging'
    sessionStorage.setItem(key, JSON.stringify(mediaList))
    onMediaChange?.(mediaList)
  }, [mediaList])

  const MAX_PRODUCT_MEDIA = 25

  const handleFiles = async (event) => {
    const files = event.target.files
    if (!files?.length) return

    const newFiles = Array.from(files)

    const existingActive = mediaList.filter((m) => m.status !== 'inactive')
    const existingCount = existingActive.length

    const remainingSlots = MAX_PRODUCT_MEDIA - existingCount

    if (remainingSlots <= 0) {
      Swal.fire({
        icon: 'warning',
        title: 'Upload Limit Reached',
        html: `You already uploaded <b>${existingCount}</b> files. Limit is <b>${MAX_PRODUCT_MEDIA}</b>.`,
      })
      fileInputRef.current.value = ''
      return
    }

    // ❗ only take allowed number of files
    const allowedFiles = newFiles.slice(0, remainingSlots)

    if (allowedFiles.length < newFiles.length) {
      Swal.fire({
        icon: 'info',
        title: 'Partial Upload',
        text: `Only ${allowedFiles.length} of ${newFiles.length} selected files were accepted.`,
      })
    }

    const formData = new FormData()
    allowedFiles.forEach((file) => formData.append('files', file))

    if (isUpdatePage && productId) formData.append('product_id', productId)

    try {
      const endpoint = isUpdatePage && productId ? `${API_BASE_URL}/product-media/upload` : `${API_BASE_URL}/product-media/upload-staging`

      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(endpoint, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          setUploadProgress(percent)
        },
      })

      setUploadProgress(null)
      setUploading(false)
      fileInputRef.current.value = ''

      const newMedia = res.data.media || []

      const updated = [...mediaList, ...newMedia].map((m) => ({
        ...m,
        variant_id: selectedVariantKey || null,
        main: false,
      }))

      if (!selectedVariantKey) {
        const firstProductImageIndex = updated.findIndex((m) => m.variant_id == null && m.status !== 'inactive')
        if (firstProductImageIndex !== -1) {
          updated[firstProductImageIndex].main = true
        }
      }

      setMediaList(updated)
    } catch (error) {
      setUploadProgress(null)
      setUploading(false)
      console.error('Upload failed:', error)
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: error?.response?.data?.message || 'Something went wrong during media upload.',
      })
    }
  }

  const handleDelete = (mediaId) => {
    setMediaList((prev) => {
      // remove the item from the UI list only
      const filtered = prev.filter((item) => (item.media_id || item.id || item.media_url) !== mediaId)

      // re-assert "main by order"
      let firstProductIndex = -1
      const firstIndexByVariant = new Map()

      filtered.forEach((m, idx) => {
        if (m.status === 'inactive') return
        if (m.variant_id == null) {
          if (firstProductIndex === -1) firstProductIndex = idx
        } else {
          if (!firstIndexByVariant.has(m.variant_id)) {
            firstIndexByVariant.set(m.variant_id, idx)
          }
        }
      })

      return filtered.map((item, idx) => {
        if (item.variant_id == null) {
          // first product-level image is main
          return { ...item, main: idx === firstProductIndex }
        }
        // first image per variant is main
        const firstOfVar = firstIndexByVariant.get(item.variant_id)
        return { ...item, main: idx === firstOfVar }
      })
    })
  }

  const handleImageLoad = (id) => {
    setImageLoading((prev) => ({ ...prev, [id]: false }))
  }

  const handleImageStartLoading = (id) => {
    setImageLoading((prev) => ({ ...prev, [id]: true }))
  }

  return (
    <div className="mb-3">
      <Button variant="outline-primary" onClick={() => setShowModal(true)}>
        <Icon icon="fa6-solid:upload" className="me-2" /> Upload Media
      </Button>

      <div className="d-flex flex-wrap gap-2 mt-2">
        {mediaList
          .filter((m) => m.status !== 'inactive')
          .map((media, index) => {
            const mediaId = media.media_id || media.id || media.media_url || index
            return (
              <div key={mediaId} className="position-relative border rounded p-1">
                {media.media_type === 'image' && (
                  <div style={{ width: 100, height: 100, position: 'relative', backgroundColor: '#f9f9f9' }}>
                    {imageLoading[mediaId] && (
                      <div className="d-flex justify-content-center align-items-center w-100 h-100 position-absolute top-0 start-0 bg-white bg-opacity-75">
                        <Spinner animation="border" size="sm" />
                      </div>
                    )}
                    <Image
                      src={media.media_url}
                      alt="Media"
                      className="w-100 h-100 object-fit-contain rounded"
                      onClick={() => setPreviewImage(media.media_url)}
                      style={{ cursor: 'zoom-in' }}
                      onLoad={() => handleImageLoad(mediaId)}
                      onLoadStart={() => handleImageStartLoading(mediaId)}
                    />
                  </div>
                )}
                {media.media_type === 'video' && <video src={media.media_url} width={100} height={100} controls muted />}
                {media.media_type === '3d' && (
                  <div className="bg-light d-flex align-items-center justify-content-center" style={{ width: 100, height: 100 }}>
                    <span className="text-muted">3D File</span>
                  </div>
                )}
                <button
                  type="button"
                  className="position-absolute top-0 end-0 m-1 p-1 rounded-circle border-0"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleDelete(mediaId)
                  }}
                  onMouseEnter={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: true }))}
                  onMouseLeave={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: false }))}
                  style={{
                    zIndex: 5,
                    cursor: 'pointer',
                    transition: 'transform 120ms ease, background-color 120ms ease, box-shadow 120ms ease',
                    transform: hoveredClose[mediaId] ? 'scale(1.08)' : 'scale(1)',
                    // default: dark glass + white icon; hover: white bg + red icon
                    backgroundColor: hoveredClose[mediaId] ? '#ffffff' : 'rgba(0,0,0,0.55)',
                    boxShadow: hoveredClose[mediaId] ? '0 4px 12px rgba(0,0,0,0.25)' : '0 2px 8px rgba(0,0,0,0.2)',
                  }}
                  aria-label="Remove"
                  title="Remove">
                  <Icon
                    icon="mdi:close"
                    width={24}
                    height={24}
                    style={{ color: hoveredClose[mediaId] ? '#dc3545' /* red */ : '#ffffffe8' /* white */ }}
                  />
                </button>
              </div>
            )
          })}
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Upload Product Media</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFiles}
            multiple
            accept="image/*,video/*,.glb"
            className="form-control mb-3"
            autoFocus
          />

          {uploading && (
            <div className="mb-3">
              <ProgressBar now={uploadProgress} label={`${uploadProgress}%`} animated striped variant="info" />
            </div>
          )}

          <p className="text-muted">You can select and upload multiple files at once. Upload progress will be shown below.</p>
          <ReactSortable
            list={mediaList}
            setList={(newList) => {
              const productImageIndices = newList.map((m, idx) => (m.variant_id == null ? idx : null)).filter((idx) => idx !== null)

              const firstProductIndex = productImageIndices[0]

              const updatedList = newList.map((item, idx) => {
                if (selectedVariantKey) {
                  const isSameVariant = item.variant_id === selectedVariantKey
                  const firstOfVariant = newList.findIndex((m) => m.variant_id === selectedVariantKey)
                  return {
                    ...item,
                    main: isSameVariant && idx === firstOfVariant,
                  }
                } else {
                  return {
                    ...item,
                    main: item.variant_id == null && idx === firstProductIndex,
                  }
                }
              })

              setMediaList(updatedList)
            }}
            className="row"
            animation={200}>
            {mediaList
              .filter((m) => m.status !== 'inactive')
              .map((media, index) => {
                const mediaId = media.media_id || media.id || media.media_url || index
                const isMain =
                  selectedVariantKey != null ? media.variant_id === selectedVariantKey && media.main : media.variant_id == null && media.main

                return (
                  <div key={mediaId} className="col-xs-6 col-md-4 col-lg-3 mb-3">
                    <div
                      className={`position-relative border rounded overflow-hidden ${isMain ? 'border-3 border-primary' : ''}`}
                      style={{ height: 140, cursor: 'grab' }}>
                      {isMain && (
                        <div
                          className="position-absolute top-0 start-0 w-100 h-100 d-flex justify-content-center align-items-center text-white fw-bold"
                          style={{
                            backgroundColor: 'rgba(0, 0, 0, 0.4)',
                            opacity: 1,
                            zIndex: 1,
                          }}>
                          {selectedVariantKey ? 'Main Variant Image' : 'Main Product Image'}
                        </div>
                      )}

                      {media.media_type === 'image' && (
                        <>
                          {imageLoading[mediaId] && (
                            <div className="d-flex justify-content-center align-items-center w-100 h-100 position-absolute top-0 start-0 bg-white bg-opacity-75 z-2">
                              <Spinner animation="border" size="sm" />
                            </div>
                          )}
                          <Image
                            src={media.media_url}
                            alt="Media"
                            className="w-100 h-100 object-fit-cover"
                            onClick={() => setPreviewImage(media.media_url)}
                            onLoad={() => handleImageLoad(mediaId)}
                            onLoadStart={() => handleImageStartLoading(mediaId)}
                            style={{ cursor: 'zoom-in', zIndex: 0 }}
                          />
                        </>
                      )}

                      {media.media_type === 'video' && <video src={media.media_url} className="w-100 h-100" controls muted />}

                      {media.media_type === '3d' && (
                        <div className="bg-light d-flex align-items-center justify-content-center w-100 h-100">
                          <span className="text-muted">3D File</span>
                        </div>
                      )}

                      <button
                        type="button"
                        className="position-absolute top-0 end-0 m-1 p-1 rounded-circle border-0"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDelete(mediaId)
                        }}
                        onMouseEnter={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: true }))}
                        onMouseLeave={() => setHoveredClose((prev) => ({ ...prev, [mediaId]: false }))}
                        style={{
                          zIndex: 5,
                          cursor: 'pointer',
                          transition: 'transform 120ms ease, background-color 120ms ease, box-shadow 120ms ease',
                          transform: hoveredClose[mediaId] ? 'scale(1.08)' : 'scale(1)',
                          backgroundColor: hoveredClose[mediaId] ? '#ffffff' : 'rgba(0,0,0,0.55)',
                          boxShadow: hoveredClose[mediaId] ? '0 4px 12px rgba(0,0,0,0.25)' : '0 2px 8px rgba(0,0,0,0.2)',
                        }}
                        aria-label="Remove"
                        title="Remove">
                        <Icon icon="mdi:close" width={24} height={24} style={{ color: hoveredClose[mediaId] ? '#dc3545' : '#ffffffe8' }} />
                      </button>

                      {/* ✅ Show Set as Main if a variant is selected */}
                      {selectedVariantKey && (
                        <button
                          className="btn btn-sm btn-outline-primary position-absolute bottom-0 start-0 m-1"
                          onClick={() => {
                            const updated = mediaList.map((img) => ({
                              ...img,
                              variant_id: selectedVariantKey || null, // ✅ ensure variant_id is assigned
                              main: img.media_url === media.media_url && img.variant_id === selectedVariantKey,
                            }))
                            setMediaList(updated)
                          }}
                          style={{ zIndex: 2 }}>
                          Set as Main
                        </button>
                      )}
                    </div>
                  </div>
                )
              })}
          </ReactSortable>

          {/* Hover effect styling */}
          <style jsx>{`
            .position-relative:hover .fw-bold {
              opacity: 1 !important;
            }
          `}</style>
        </Modal.Body>

        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={() => {
              setShowModal(false)
              if (!isUpdatePage && !productId) {
                sessionStorage.removeItem('media_staging')
              }
            }}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Full Image Preview Modal */}
      <Modal show={!!previewImage} onHide={() => setPreviewImage(null)} centered size="xl" backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>Image Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
          <div
            style={{
              width: '100%',
              maxWidth: '600px',
              aspectRatio: '1 / 1',
              backgroundColor: '#f9f9f9',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image src={previewImage} alt="Preview" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} fluid />
          </div>
        </Modal.Body>
      </Modal>

      {/* <style jsx>{`
  .position-relative:hover .fw-bold {
    opacity: 1 !important;
  }
`}</style> */}
    </div>
  )
}

export default MediaUploaderModal
