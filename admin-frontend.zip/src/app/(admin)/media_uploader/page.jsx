import dynamic from 'next/dynamic';

// Correctly use dynamic() to import your component
const VariantUploaderModal = dynamic(() => import('./VariantUploaderModal'), {
  // ssr: false tells Next.js not to render this component on the server.
  // This is useful if the component relies on browser-specific APIs (like window/document).
  // If it can be server-rendered, you can remove this or set ssr: true.
  ssr: false
});

export default function ProductsPage() {
  return <VariantUploaderModal />;
}