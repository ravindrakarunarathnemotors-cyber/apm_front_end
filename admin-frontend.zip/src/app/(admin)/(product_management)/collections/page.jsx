import React from 'react'
import CollectionList from '@/components/ProductManagement/CollectionList'
import AddCollection from '../collections/add_collection'

function page() {
  return (
    <>
      <AddCollection />
      <CollectionList />
    </>
  )
}

export default page
