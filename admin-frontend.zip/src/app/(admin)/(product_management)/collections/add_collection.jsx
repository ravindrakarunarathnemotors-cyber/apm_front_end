'use client'

import React, { useState } from 'react'
import { debounce } from 'lodash'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import Select from 'react-select'
import {
  Form,
  Button,
  Card,
  Row,
  Col,
  Alert,
  CardHeader,
  CardTitle,
  FormGroup,
  FormLabel,
  FormControl,
  Spinner,
  ProgressBar,
  Image,
  Table,
} from 'react-bootstrap'
import { useCreateCollectionMutation, useGetProductseQuery } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import axios from 'axios'

const AddCollection = () => {
  const router = useRouter()
  const [form, setForm] = useState({
    name: '',
    description: '',
    status: 'active',
    mobile_url: '',
    desktop_url: '',
  })
  const [error, setError] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProducts, setSelectedProducts] = useState([])
  const [addCollection, { isLoading }] = useCreateCollectionMutation()
  const [logoPreview, setLogoPreview] = useState(null)
  const [logoTitlePreview, setLogoTitlePreview] = useState(null)
  const [uploadingField, setUploadingField] = useState(null)
  const [uploadProgress, setUploadProgress] = useState(0)

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL

  const handleImageUpload = async (file, fieldName, setPreview) => {
    if (!file) return

    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'temp-brand')

    try {
      setUploadingField(fieldName)
      const res = await axios.post(`${API_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => setUploadProgress(Math.round((e.loaded * 100) / e.total)),
      })

      const uploaded = res.data.media?.[0]
      if (!uploaded) throw new Error('Upload failed or no media returned.')

      setPreview(uploaded.media_url)
      setForm((prev) => ({ ...prev, [fieldName]: uploaded.media_url }))
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: err?.response?.data?.error || err.message || 'Image upload failed',
      })
    } finally {
      setUploadProgress(0)
      setUploadingField(null)
    }
  }

  const {
    register,

    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    mode: 'onChange',
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const user_id = sessionStorage.getItem('user_id')
      const product_ids = selectedProducts.map((p) => p.value)

      if (!logoPreview || !logoTitlePreview) {
        setError('Both mobile and desktop images must be uploaded')
        return
      }

      const payload = {
        ...form,
        user_id,
        product_ids,
      }

      console.log('Submitting payload:', payload)

      await addCollection(payload).unwrap()
      Swal.fire('Success', 'Collection added successfully!', 'success')

      // Reset form
      setForm({
        name: '',
        description: '',
        status: 'active',
        mobile_url: '',
        desktop_url: '',
      })
      setSelectedProducts([])
      setLogoPreview(null)
      setLogoTitlePreview(null)
    } catch (err) {
      console.error(err)
      setError(err?.data?.error || 'Failed to add collection')
    }
  }

  const { data: productResults } = useGetProductseQuery(searchProduct, {
    skip: searchProduct.length < 2,
  })

  const productOptions =
    productResults?.map((product) => ({
      value: product.product_id,
      label: `${product.title} (${product.product_id})`,
    })) || []

  const debouncedSearchProduct = debounce((value) => {
    setSearchProduct(value)
  }, 300)

  // Remove product handler
  const removeProduct = (value) => {
    setSelectedProducts((prev) => prev.filter((p) => p.value !== value))
  }

  // If more than 10 products, enable vertical scrolling for the table body container
  const tableScrollStyle = selectedProducts.length > 10 ? { maxHeight: '320px', overflowY: 'auto' } : {}

  return (
    <Row className="justify-content-center mt-2">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Add Collections
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>
          <Card.Body>
            {error && <Alert variant="danger">{error}</Alert>}

            <Form onSubmit={handleSubmit} className="row g-3">
              <Form.Group className="col-md-6">
                <Form.Label>Collection Name</Form.Label>
                <Form.Control type="text" name="name" placeholder="Enter collection name" value={form.name} onChange={handleChange} required />
              </Form.Group>
              <Col md={3}>
                <FormLabel>Mobile Image</FormLabel>
                <FormControl type="file" accept="image/*" onChange={(e) => handleImageUpload(e.target.files[0], 'mobile_url', setLogoPreview)} />
                {uploadingField === 'mobile_url' && <ProgressBar now={uploadProgress} label={`${uploadProgress}%`} className="mt-2" />}
                {logoPreview && (
                  <div className="mt-2 border rounded p-1" style={{ width: 100, height: 100 }}>
                    <Image src={logoPreview} alt="Mobile" thumbnail style={{ objectFit: 'contain', width: '100%', height: '100%' }} />
                  </div>
                )}
              </Col>

              <Col md={3}>
                <FormLabel>Desktop Image</FormLabel>
                <FormControl
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e.target.files[0], 'desktop_url', setLogoTitlePreview)}
                />
                {uploadingField === 'desktop_url' && <ProgressBar now={uploadProgress} label={`${uploadProgress}%`} className="mt-2" />}
                {logoTitlePreview && (
                  <div className="mt-2 border rounded p-1" style={{ width: 100, height: 100 }}>
                    <Image src={logoTitlePreview} alt="Desktop" thumbnail style={{ objectFit: 'contain', width: '100%', height: '100%' }} />
                  </div>
                )}
              </Col>

              <Form.Group className="col-md-6">
                <div>
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    name="description"
                    placeholder="Enter description"
                    rows={3}
                    value={form.description}
                    onChange={handleChange}
                  />
                </div>
                <div className="mt-3">
                  <FormLabel>Add Product</FormLabel>
                  <Select
                    options={productOptions}
                    onInputChange={debouncedSearchProduct}
                    onChange={(option) => {
                      if (option && !selectedProducts.find((p) => p.value === option.value)) {
                        setSelectedProducts((prev) => [...prev, option])
                      }
                    }}
                    placeholder="Add Product..."
                    isClearable
                    isSearchable
                    value={null}
                    styles={{
                      control: (base, state) => ({
                        ...base,
                        borderRadius: '999px',
                        borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                        boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                      }),
                    }}
                  />
                </div>
              </Form.Group>

              {/* ====== Selected Products Card + Compact Table ====== */}
              <FormGroup className="col-md-6">
                <Card className="mt-2">
                  <Card.Header style={{ backgroundColor: '#f7f8fa', padding: '0.5rem 0.75rem' }}>
                    <div className="d-flex align-items-center justify-content-between">
                      <div style={{ fontSize: '0.9rem', fontWeight: 600 }}>Selected Products</div>
                      <div style={{ fontSize: '0.8rem', color: '#6c757d' }}>{selectedProducts.length} item(s)</div>
                    </div>
                  </Card.Header>
                  <Card.Body style={{ padding: '0.4rem' }}>
                    {selectedProducts.length === 0 ? (
                      <div className="text-muted small px-2 py-2">No products selected yet.</div>
                    ) : (
                      // Outer div handles horizontal overflow; inner div handles vertical scroll when > 10 items
                      <div style={{ overflowX: 'auto' }}>
                        <div style={tableScrollStyle}>
                          <Table hover size="sm" responsive className="mb-0" style={{ fontSize: '0.78rem', marginBottom: 0 }}>
                            <thead>
                              <tr>
                                <th style={{ width: '36px', padding: '6px 8px' }}>#</th>
                                <th style={{ minWidth: '100px', padding: '6px 8px' }}>Product ID</th>
                                <th style={{ padding: '6px 8px' }}>Product Title</th>
                                <th style={{ width: '48px', padding: '6px 8px', textAlign: 'right' }} aria-hidden="true"></th>
                              </tr>
                            </thead>
                            <tbody>
                              {selectedProducts.map((product, index) => (
                                <tr key={product.value} style={{ cursor: 'default' }}>
                                  <td style={{ padding: '6px 8px', verticalAlign: 'middle' }}>{index + 1}</td>
                                  <td style={{ padding: '6px 8px', verticalAlign: 'middle' }}>{product.value}</td>
                                  <td style={{ padding: '6px 8px', verticalAlign: 'middle' }}>
                                    <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '320px' }}>
                                      {product.label.replace(/\s*\(\d+\)$/, '') /* remove trailing (id) in label for title display */}
                                    </div>
                                  </td>
                                  <td style={{ padding: '6px 8px', verticalAlign: 'middle', textAlign: 'right' }}>
                                    <button
                                      type="button"
                                      className="btn btn-sm btn-outline-secondary"
                                      aria-label={`Remove ${product.label}`}
                                      onClick={() => removeProduct(product.value)}
                                      style={{
                                        padding: '3px 6px',
                                        lineHeight: '1',
                                        borderRadius: 6,
                                        fontSize: '0.78rem',
                                      }}>
                                      &times;
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </Table>
                        </div>
                      </div>
                    )}
                  </Card.Body>
                </Card>
              </FormGroup>
              {/* ====== end Selected Products Card ====== */}

              <div className="col-12 d-flex justify-content-end">
                <Button type="submit" className="btn bg-primary border border-primary" disabled={isLoading}>
                  {isLoading ? 'Saving...' : 'Add Collection'}
                </Button>
              </div>
            </Form>
          </Card.Body>
        </Card>
      </Col>

      {/* Inline compact styles to ensure rows are tight and font is small; add nice scrollbar visuals */}
      <style jsx>{`
        /* make table rows denser on small screens too */
        .table > :not(caption) > * > * {
          padding: 0;
        }

        /* scrollbar for the selected products scroll container */
        div[style*='max-height'] {
          scrollbar-width: thin;
          scrollbar-color: rgba(0, 0, 0, 0.2) transparent;
        }
        div[style*='max-height']::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        div[style*='max-height']::-webkit-scrollbar-thumb {
          background: rgba(0, 0, 0, 0.12);
          border-radius: 8px;
        }
        div[style*='max-height']::-webkit-scrollbar-track {
          background: transparent;
        }
      `}</style>
    </Row>
  )
}

export default AddCollection
