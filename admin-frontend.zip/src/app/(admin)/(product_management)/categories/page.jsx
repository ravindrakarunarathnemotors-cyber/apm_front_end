import React from 'react'
import AddCategory from '@/components/ProductManagement/Category/AddCategory'
import CategoryList from '@/components/ProductManagement/Category/CategoryList'

function page() {
  return (
    <>        
        <AddCategory/>
        <CategoryList/>
    </>
  )
}

export default page