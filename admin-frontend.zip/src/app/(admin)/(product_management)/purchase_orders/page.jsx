import React from 'react'

function page() {
  return (
    <div>
      <h1>purchase orders</h1>
    </div>
  )
}

export default page
