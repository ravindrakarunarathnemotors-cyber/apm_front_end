import React from 'react'
import AddBrand from '@/components/ProductManagement/Brand/AddBrand'
import BrandList from '@/components/ProductManagement/Brand/BrandList'

function page() {
  return (
    <>        
        <AddBrand/>
        <BrandList/>
    </>
  )
}

export default page