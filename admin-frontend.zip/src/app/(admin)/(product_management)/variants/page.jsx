import React from 'react'
import AddVariant from '@/components/ProductManagement/Variants/AddVariants'
import VariantList from '@/components/ProductManagement/Variants/VariantList'

function page() {
  return (
    <>
        <AddVariant/>
        <VariantList/>
    </>
  )
}

export default page