import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Variants',
}

const Variants = dynamic(() => import('./Variants'), { ssr: false })

export default function VariantsPage() {
  return <Variants />
}