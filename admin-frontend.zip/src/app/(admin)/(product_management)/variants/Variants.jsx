'use client'

import React, { useState } from 'react'
import AddVariant from '@/components/ProductManagement/Variants/AddVariants'
import VariantList from '@/components/ProductManagement/Variants/VariantList'

function Variants() {
  const [refreshKey, setRefreshKey] = useState(0)

  return (
    <>
      <AddVariant onVariantAdded={() => setRefreshKey((prev) => prev + 1)} />
      <VariantList refreshTrigger={refreshKey} />
    </>
  )
}

export default Variants