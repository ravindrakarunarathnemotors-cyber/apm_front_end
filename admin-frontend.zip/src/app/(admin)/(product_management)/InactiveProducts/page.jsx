'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  useGetFilteredProductListMutation,
  useGetProductseQuery,
  useGetProductceyQuery,
  useToggleProductStatusMutation,
  useGetProductcollQuery,
} from '@/store/features/apiSlice'

function InProductsPage() {
  const [filters, setFilters] = useState({ keyword: '' })
  const [productName, setProductName] = useState('')
  const [productstate, setProductState] = useState('inactive')
  const [productId, setProductId] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [searchCategory, setSearchCategory] = useState('')
  const [searchCollection, setSearchCollection] = useState('')
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [selectedCollection, setSelectedCollection] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [logs, setLogs] = useState([])
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [currency, setCurrency] = useState('');
  const logsPerPage = 10

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredProductListMutation()

  const { data: productResults } = useGetProductseQuery(searchProduct, {
    skip: searchProduct.length < 2,
  })
  const [toggleProductStatus] = useToggleProductStatusMutation()

  const { data: productCategory } = useGetProductceyQuery(searchCategory, {
    skip: searchCategory.length < 2,
  })

  const { data: productColloection } = useGetProductcollQuery(searchCollection, {
    skip: searchCollection.length < 2,
  })

  const keywordOptions = useMemo(
    () =>
      productResults?.map((p) => ({
        value: p.product_id,
        label: `${p.title} (${p.product_id})`,
      })) || [],
    [productResults],
  )

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const debouncedSearchKeyword = useMemo(
    () =>
      debounce((value) => {
        const v = (value || '').trim()
        // send as-is; backend should treat numeric-only as ID, else as name
        setSearchProduct(v)
      }, 300),
    [],
  )

  const productOptions =
    productResults?.map((product) => ({
      value: product.product_id,
      label: `${product.title} (${product.product_id})`,
    })) || []

  const categoryOptions =
    productCategory?.map((cat) => ({
      value: cat.category_id,
      label: `${cat.name} (${cat.category_id})`,
    })) || []

  const debouncedSearchProduct = debounce((value) => {
    setSearchProduct(value)
  }, 300)

  const debouncedSearchCategory = debounce((value) => {
    setSearchCategory(value)
  }, 300)

  const productCollecOptions =
    productColloection?.map((collect) => ({
      value: collect.collection_id,
      label: `${collect.name} (${collect.collection_id})`,
    })) || []

  const debouncedSearchProductcollect = debounce((value) => {
    setSearchCollection(value)
  }, 300)

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredProducts({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        product_state: productstate,
        productId: productId,
        product_name: productName,
        category: selectedCategory?.value || '',
        collection: selectedCollection?.value || '',
        created_at: productDate,
        merchant_id: '20001',
      }).unwrap()

      setLogs(res.products || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
      setCurrentPage(page)
      setCurrency(res.currency || res.products?.[0]?.currency || ''); setCurrency(res.products?.[0]?.currency || '');
    } catch (err) {
      console.error('Failed to fetch products:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const handleToggleStatus = async (product_id) => {
    const product = logs.find((p) => p.product_id === product_id)
    if (!product) return

    const newStatus = product.status === 'active' ? 'inactive' : 'active'


    const result = await Swal.fire({
      title: `Confirm Product ${newStatus === 'active' ? 'Inactive' : 'Active'} Status Change`,
      html: `
      Are you sure you want to <strong>${newStatus === 'active' ? 'Active' : 'Inactive'}</strong> the ${product.product_name}?<br/><br/>


    `,

      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus === 'active' ? 'Active' : 'Inactive'}`,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      await toggleProductStatus({
        product_id,
        status: newStatus,
      }).unwrap()

      Swal.fire('Success', 'Product status updated successfully!', 'success')

      setLogs((prevLogs) => prevLogs.map((p) => (p.product_id === product_id ? { ...p, status: newStatus } : p)))
    } catch (error) {
      console.error('Failed to update product status:', error)
      Swal.fire('Error', 'Failed to update product status.', 'error')
    }
  }

  const normalizedProducts = logs.map((p) => ({
    product_id: p.product_id,
    name: p.product_name || 'No Name',
    category: p.categories || '-',
    collections: p.collections || '-',
    price: parseFloat(p.price),
    status: p.status || 'N/A',
    created_at: p.created_at,
    image_url: p.selected_image || null,
  }))

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader
            className="py-3 bg-light"
          >
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Inactive Products
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Link href="/products/add_products" passHref>
                  <Button type="button" className="btn bg-primary border border-primary">
                    <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Add Product
                  </Button>
                </Link>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-3 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Product Date</FormLabel>
                <Form.Control type="date" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-3">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={keywordOptions}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={filters.keyword ? { label: filters.keyword, value: filters.keyword } : null}
                  components={{ DropdownIndicator: null }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // user typing
                      debouncedSearchKeyword(value)
                      setFilters((prev) => ({ ...prev, keyword: value }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      // pick the "name" part before the (ID)
                      const nameOnly = option.label?.split('(')[0].trim()
                      setSearchProduct(nameOnly)
                      setFilters((prev) => ({ ...prev, keyword: nameOnly }))
                    } else {
                      // cleared
                      setSearchProduct('')
                      setFilters((prev) => ({ ...prev, keyword: '' }))
                    }
                  }}
                />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Product Category</FormLabel>
                <Select
                  options={categoryOptions}
                  onInputChange={debouncedSearchCategory}
                  onChange={(option) => {
                    setSelectedCategory(option)
                  }}
                  placeholder="Category..."
                  isClearable
                  isSearchable
                  value={selectedCategory}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Product Collection</FormLabel>
                <Select
                  options={productCollecOptions}
                  onInputChange={debouncedSearchProductcollect}
                  onChange={(option) => {
                    setSelectedCollection(option)
                  }}
                  placeholder="Collection..."
                  isClearable
                  isSearchable
                  value={selectedCollection}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-12 col-md-2 d-grid d-flex align-items-end">
                <Button
                  type="button"
                  className="btn bg-primary border border-primary w-100 w-md-auto"
                  onClick={() => fetchLogs(1)}
                >
                  Search
                </Button>

              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading products...</p>
            ) : (
              <>
                <div className="table-responsive">
                  <Table striped className="table mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Created At</th>
                        <th>Product Name </th>
                        <th>Collections</th>
                        <th>Category</th>
                        <th>Price({currency})</th>

                        <th className="text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {normalizedProducts.length === 0 ? (
                        <tr>
                          <td colSpan="7" className="text-center">
                            No products found.
                          </td>
                        </tr>
                      ) : (
                        normalizedProducts.map((item) => (
                          <tr key={item.product_id}>
                            <td>{item.product_id}</td>
                            <td>{new Date(item.created_at).toLocaleDateString()}</td>
                            <td>
                              {item.image_url && (
                                <Image src={item.image_url} alt={item.name} className="rounded-circle thumb-md me-1 d-inline" width={30} height={30} />
                              )}
                              {item.name}
                            </td>
                            <td>{item.collections}</td>
                            <td>{item.category}</td>
                            <td className="text-end">{item.price.toFixed(2)}</td>

                            <td className="text-end">
                              <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                                {/* View Button */}
                                <Button
                                  className="d-flex align-items-center justify-content-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#007bff',
                                    borderColor: '#007bff',
                                    color: '#fff',
                                    flex: 1,
                                  }}
                                  onClick={() => (window.location.href = `/products/product_view?product_id=${item.product_id}`)}>
                                  <IconifyIcon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>View</span>
                                </Button>
                                <Button
                                  className="d-flex align-items-center justify-content-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#fd7e14',
                                    borderColor: '#fd7e14',
                                    color: '#fff',
                                    flex: 1,
                                  }}
                                  onClick={() => (window.location.href = `/products/update_product?product_id=${item.product_id}`)}>
                                  <IconifyIcon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>Edit</span>
                                </Button>

                                <Button
                                  className="d-flex align-items-center justify-content-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    color: '#fff',
                                    backgroundColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                    borderColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                    flex: 1,
                                  }}
                                  onClick={() => handleToggleStatus(item.product_id)}
                                  title={item.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                                  <IconifyIcon
                                    icon={item.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                    style={{ fontSize: '20px', marginRight: '4px' }}
                                  />
                                  <span>{item.status === 'active' ? 'Active' : 'Inactive'}</span>
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalEntries={totalEntries}
                  limit={limit}
                  onPageChange={handlePageChange}
                  onLimitChange={(val) => {
                    setLimit(val)
                    setCurrentPage(1)
                    fetchLogs(1, val)
                  }}
                  showingFrom={logs.length === 0 ? 0 : (currentPage - 1) * limit + 1}
                  showingTo={(currentPage - 1) * limit + logs.length}
                />
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default InProductsPage
