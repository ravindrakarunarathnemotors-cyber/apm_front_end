import React from 'react'

function page() {
  return (
    <div>
      <h1>import products page</h1>
    </div>
  )
}

export default page
