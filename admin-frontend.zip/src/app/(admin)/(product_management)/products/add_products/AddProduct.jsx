'use client'

import { useForm, Controller } from 'react-hook-form'
import { useMemo, useCallback, useState, useEffect, useRef } from 'react'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Badge, Button, Col, Form, FormControl, FormLabel, FormCheck, FormSelect, Row, Modal, FormGroup } from 'react-bootstrap'
import { useRouter } from 'next/navigation'
import dynamic from 'next/dynamic'
import Swal from 'sweetalert2'
import { OverlayTrigger, Tooltip } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import AsyncCreatableSelect from 'react-select/async-creatable'
import InsertBarcode from '@/app/(admin)/(product_management)/products/product_barcode/Insert_barcode'
import InsertKeywords from '@/app/(admin)/(product_management)/products/product_keywords/insert_keywords'

const MeasurementSelector = dynamic(() => import('@/app/(admin)/(product_management)/products/measurement_selector/MeasurementSelector'), {
  ssr: false,
  loading: () => <p>Loading Measurement...</p>,
})

const BrandSelector = dynamic(() => import('@/app/(admin)/(product_management)/products/brand_selector/BrandSelector'), {
  ssr: false,
  loading: () => <p>Loading Brands...</p>,
})
import ComponentContainerCard from '@/components/ComponentContainerCard'
import CustomQuill from '@/components/CustomQuill'
import VariantUploaderModal from '@/app/(admin)/media_uploader/VariantUploaderModal'

import {
  useGetCategoriesQuery,
  useGetCollectionsQuery,
  useLazySearchTagsQuery,
  useAddProductMutation,
  useGetDiscountCurrencyQuery,
} from '@/store/features/apiSlice'

const ReactQuill = dynamic(() => import('react-quill'), { ssr: false, loading: () => <p>Loading Editor...</p> })
const VariantSelectorCard = dynamic(() => import('@/components/ProductManagement/Variants/VariantSelectorCard'), { ssr: false })
const MediaUploader = dynamic(() => import('@/app/(admin)/media_uploader/MediaUploader'), { ssr: false })

const schema = yup.object({
  title: yup.string().required(' Title is required').max(100, 'Title cannot exceed 100 characters'),
  search_engine_title: yup.string().max(70, 'Search Engine Title cannot exceed 70 characters'),
  search_engine_desc: yup.string().max(160, 'Search Engine Description cannot exceed 160 characters'),
  category: yup.string().required('Please select a category'),
  cost: yup.number().typeError('Only numbers allowed').required('Cost is required'),
  price: yup.number().typeError('Only numbers allowed').required('Selling Price is required'),
  profit: yup.number().typeError('Only numbers allowed').required('Profit is required'),
  margin: yup.number().typeError('Only numbers allowed').required('Margin is required'),
})

const defaultProductValues = {
  title: '',
  status: 'active',
  category: '',
  search_engine_title: '',
  search_engine_desc: '',
  measurement_id: '', // <- register measurement
  amount_per_unit: '', // <- register amount per unit
}

const handleMediaChange = (mediaList) => {
  setUploadedMediaList(mediaList)
}

const AddProducts = () => {
  const toTitleCase = (str) => str.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase())
  const toSentenceCase = (str) => str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()

  const dropdownRef = useRef(null)
  const [addProduct] = useAddProductMutation()

  const { data: currencyData } = useGetDiscountCurrencyQuery()

  // currencyData is actually "USD"
  const currencySymbol = typeof currencyData === 'string' ? currencyData : currencyData?.currency || ''

  const [description, setDescription] = useState('')
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [pendingSubmitData, setPendingSubmitData] = useState(null)
  const [selectedMain, setSelectedMain] = useState(null)
  const [selectedSub, setSelectedSub] = useState(null)
  const [customVariants, setCustomVariants] = useState([])
  const [selectedCollections, setSelectedCollections] = useState([])
  const [selectedTags, setSelectedTags] = useState([])
  const [searchTags] = useLazySearchTagsQuery()
  const [fetchedTagOptions, setFetchedTagOptions] = useState([])
  // const [createTag] = useCreateTagMutation()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadedMediaList, setUploadedMediaList] = useState([])
  const [seoTitle, setSeoTitle] = useState('')
  const [seoDesc, setSeoDesc] = useState('')
  const [publishToWeb, setPublishToWeb] = useState(false)
  const [seoTitleTouched, setSeoTitleTouched] = useState(false)
  const [seoDescTouched, setSeoDescTouched] = useState(false)
  const [selectedMeasurementId, setSelectedMeasurementId] = useState(null)
  // New: track whether child Amount-per-unit field is visible (expanded)
  const [amountFieldVisible, setAmountFieldVisible] = useState(false)
  const [selectedMeasurementUnit, setSelectedMeasurementUnit] = useState('')
  const [keywords, setKeywords] = useState([])

  // ---------- NEW state to receive data from MeasurementSelector ----------
  // measurementShow: boolean from MeasurementSelector onShowChange(show)
  // when measurementShow === false -> hide VariantSelectorCard
  const [measurementShow, setMeasurementShow] = useState(true) // default true so variants visible until measurement selector says false
  const [amountPerUnit, setAmountPerUnit] = useState('') // value from MeasurementSelector (string)
  // -----------------------------------------------------------------------

  const [showMediaUploader, setShowMediaUploader] = useState(false)
  const [showVariantMediaModal, setShowVariantMediaModal] = useState(false)
  const [activeVariantKey, setActiveVariantKey] = useState(null)
  const [selectedBrandId, setSelectedBrandId] = useState(null)
  const [continueSelling, setContinueSelling] = useState(true)

  useEffect(() => {
    const savedMedia = sessionStorage.getItem('media_staging')
    if (savedMedia) {
      try {
        const parsed = JSON.parse(savedMedia)
        if (Array.isArray(parsed)) {
          setUploadedMediaList(parsed)
        }
      } catch (e) {
        console.error('Failed to parse media_staging from sessionStorage:', e)
      }
    }
  }, [])

  const handleMediaChange = (updatedMediaList) => {
    setUploadedMediaList(updatedMediaList)
  }

  const parseMoney = (value) => {
    if (!value) return 0

    return (
      parseFloat(
        value
          .toString()
          .replace(new RegExp(`\\s*${currencySymbol}$`, 'i'), '') // removes trailing " USD"

          .replace(/,/g, '')
          .trim(),
      ) || 0
    )
  }

  const router = useRouter()

  const stripHtml = (html) => {
    const div = document.createElement('div')
    div.innerHTML = html
    return div.textContent || div.innerText || ''
  }
  const trimForSEO = (text, maxLength = 160) => {
    if (!text) return ''
    const plainText = stripHtml(text) // stripHtml from earlier
    return plainText.length > maxLength ? plainText.substring(0, maxLength).trim() + '...' : plainText
  }

  const { data: categoryData, isLoading: isCategoryLoading } = useGetCategoriesQuery()

  const productId = '101' // For testing; ideally this should be dynamic

  const categories = useMemo(() => {
    if (!Array.isArray(categoryData)) {
      console.log('categoryData is not an array:', categoryData)
      return []
    }
    return categoryData.map((category) => {
      return {
        category_id: category.category_id,
        name: category.name || 'No Name',
        category_under: category.category_under,
      }
    })
  }, [categoryData])

  const {
    data: collectionData = [], // [{ id, name }]
    isLoading: isCollectionLoading,
  } = useGetCollectionsQuery()

  const mainCategories = Array.isArray(categories) ? categories.filter((c) => c.category_under === null) : []

  const getSubCategories = (parentId) => {
    if (!Array.isArray(categories)) return []
    return categories.filter((c) => c.category_under === Number(parentId))
  }

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
    watch,
    setValue, // Add setValue to manually set hub ID
    getValues,
    trigger,
    setError, // <-- add
    clearErrors, // <-- add
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onSubmit',
    defaultValues: defaultProductValues,
  })

  // normalize incoming unit to canonical tokens
  const normalize = (v) => {
    if (!v) return ''
    const s = String(v).trim().toLowerCase()
    if (['kg', 'kgs', 'kilogram', 'kilograms'].includes(s)) return 'kg'
    if (['g', 'gram', 'grams', 'gms'].includes(s)) return 'g'
    if (['l', 'liter', 'litre', 'liters', 'litres', 'ltr'].includes(s)) return 'l'
    if (['ml', 'milliliter', 'millilitre', 'milliliters', 'millilitres'].includes(s)) return 'ml'
    if (['pcs', 'pc', 'piece', 'pieces'].includes(s)) return 'pc'
    // fallback
    return s.endsWith('s') ? s.slice(0, -1) : s
  }

  // whenever parent receives the raw value, store normalized form
  useEffect(() => {
    // wherever you setSelectedMeasurementUnit, you can instead set normalized:
    // setSelectedMeasurementUnit(normalize(rawVal))
    // but if you prefer to keep current handler, you can derive:
    const norm = normalize(selectedMeasurementUnit)
    // hide & clear stored weight if necessary
    if (['g', 'kg'].includes(norm)) {
      setValue('weight_per_item', '')
      clearErrors('weight_per_item')
    }
    // optionally set a normalized state: setNormalizedUnit(norm)
  }, [selectedMeasurementUnit, setValue, clearErrors])

  useEffect(() => {
    const subscription = watch((values, { name }) => {
      if (name === 'title' && !seoTitleTouched) {
        const updated = values.title?.slice(0, 70) || ''
        setSeoTitle(updated)
        setValue('search_engine_title', updated)
      }
    })

    return () => subscription.unsubscribe()
  }, [watch, seoTitleTouched])

  useEffect(() => {
    if (!seoDescTouched && description) {
      const plainText = stripHtml(description)
      const limited = plainText.slice(0, 120)
      setSeoDesc(limited)
      setValue('search_engine_desc', limited)
    }
  }, [description, seoDescTouched])

  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      const firstErrorField = Object.keys(errors)[0]
      const el = document.querySelector(`[name="${firstErrorField}"]`)
      if (el && el.scrollIntoView) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
        el.focus()
      }
    }
  }, [errors])

  // clear default weight when unit is grams or kilograms (so hidden field doesn't keep stale value)
  useEffect(() => {
    const u = String(selectedMeasurementUnit || '')
      .toLowerCase()
      .trim()
    const hideFor = new Set(['g', 'gram', 'grams', 'kg', 'kilogram', 'kilograms', 'kgs'])
    const shouldHide = hideFor.has(u)

    if (shouldHide) {
      // clear the registered form value and any validation error
      setValue('weight_per_item', '')
      clearErrors('weight_per_item')
    }
    // only run when unit changes
  }, [selectedMeasurementUnit, setValue, clearErrors])

  const statusValue = watch('status')
  const defaultWeight = watch('weight_per_item')

  const onlyAllowNumbers = (e) => {
    const char = String.fromCharCode(e.which || e.keyCode)
    if (!/[0-9.]$/.test(char)) {
      e.preventDefault()
    }
  }

  const onSubmit = async (data) => {
    const mediaFiles = JSON.parse(sessionStorage.getItem('media_staging') || '[]')

    const finalPayload = {
      ...data,
      mediaFiles: uploadedMediaList.map((media) => ({
        url: media.media_url,
        type: media.media_type,
        main: media.main ? true : false,
        variant_id: media.variant_id || null,
      })),
    }

    sessionStorage.removeItem('media_staging')

    if (!data.category || !data.title || !data.cost || !data.price) return
    // Store form data and open confirm modal
    setPendingSubmitData(data)
    setShowConfirmModal(true)
  }
  const handleConfirmedSubmit = async () => {
    if (isSubmitting) return // prevent double fire
    setIsSubmitting(true)
    const data = pendingSubmitData

    const defaultWeightNum = Number.parseFloat((data && data.weight_per_item) ?? getValues('weight_per_item')) || 0

    // ---- build normalized variantsPayload depending on measurementShow ----
    const defaultVariant = {
      variant_type: 'Default',
      variant_value: 'Default',
      cost: parseMoney(data.cost),
      price: parseMoney(data.price),
      weight: defaultWeightNum,
      variant_key: 'default',
    }

    // If measurementShow is false -> ALWAYS send a single Default variant
    // If measurementShow is true -> send customVariants if present, otherwise send Default
    let variantsPayload = []

    if (!measurementShow) {
      // measurement disables variants (e.g., pcs/g/kg), but backend still expects a default variant object
      variantsPayload = [defaultVariant]
    } else {
      // measurement allows variants: include user-created variants if any, else default
      variantsPayload =
        customVariants && customVariants.length > 0
          ? customVariants.map((variant) => ({
              ...variant,
              cost: parseFloat(variant.cost),
              price: parseFloat(variant.price),
              weight: variant.weight !== undefined && variant.weight !== '' ? parseFloat(variant.weight) : defaultWeightNum,
              variant_key: variant.variant_key,
            }))
          : [defaultVariant]
    }

    // ---- build product object (always include `variants` key) ----
    const safeSearchEngineTitle = seoTitle?.trim() || data.title
    const safeSearchEngineDesc = seoDesc?.trim() || trimForSEO(description, 160)

    const productObject = {
      title: data.title,
      description,
      status: data.status,
      price: parseMoney(data.price),
      cost_per_item: parseMoney(data.cost),
      profit: parseFloat(data.profit) || 0,
      margin: parseFloat(data.margin) || 0,
      type: data.type,
      category: data.category,
      measurement_id: selectedMeasurementId,
      brand_id: getValues('brand_id') ?? null,
      default_weight: defaultWeightNum,
      default_barcode: data.barcode || null,
      publish_to_web: publishToWeb,
      continue_selling: continueSelling,

      // include amount_per_unit from MeasurementSelector (or null)
      amount_per_unit: amountPerUnit !== '' ? parseFloat(amountPerUnit) : null,

      // ALWAYS include variants array (either default single or custom list)
      variants: variantsPayload,

      search_engine_title: safeSearchEngineTitle,
      search_engine_desc: safeSearchEngineDesc,
      collection: selectedCollections.map((c) => c.value),
      tags: selectedTags.filter((t) => t && typeof t.label === 'string' && t.label.trim() !== '').map((t) => t.label.trim()),

      similar_keywords: keywords.length > 0 ? keywords.map((k) => k.label) : null,

      mediaFiles: (() => {
        const productImages = uploadedMediaList.filter((m) => !m.variant_id)
        const hasMain = productImages.some((m) => m.main === true)
        let fixedProductImages = productImages
        if (!hasMain && productImages.length > 0) {
          fixedProductImages = productImages.map((m, idx) => ({ ...m, main: idx === 0 }))
        }
        // keep variant images only if measurementShow is true (optional — comment out if you want to keep)
        const variantImages = measurementShow ? uploadedMediaList.filter((m) => m.variant_id) : []
        return [...fixedProductImages, ...variantImages].map((media) => ({
          url: media.media_url,
          type: media.media_type,
          main: media.main === true,
          variant_id: measurementShow ? media.variant_id || null : null,
        }))
      })(),
    }

    try {
      const response = await addProduct(productObject).unwrap()
      Swal.fire({
        icon: 'success',
        title: 'Product Added!',
        html: `<p><b>Product ID:</b> ${response.product.product_id}</p>
             <p><b>Title:</b> ${response.product.title}</p>`,
        confirmButtonText: 'Go to Products',
      }).then(() => {
        sessionStorage.removeItem('media_staging')
        Object.keys(sessionStorage).forEach((k) => k.startsWith('variant_image_') && sessionStorage.removeItem(k))
        router.push('/products')
      })
      reset()
      setCustomVariants([])
      setSelectedTags([])
      setSelectedCollections([])
      setShowConfirmModal(false)
    } catch (error) {
      console.error('Add product error:', error)
      Swal.fire({ icon: 'error', title: 'Failed to add product', text: error?.data?.message || 'Something went wrong while saving the product.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  const watchedValues = watch(['cost', 'price', 'profit', 'margin'])

  useEffect(() => {
    const [costRaw, priceRaw, profitRaw, marginRaw] = watchedValues
    const activeField = document.activeElement?.name

    const cost = parseMoney(costRaw)
    const price = parseMoney(priceRaw)
    const profit = parseFloat(profitRaw)
    const margin = parseFloat(marginRaw)

    if (!cost || isNaN(cost)) return

    // CASE 1: user edits Selling Price
    if (activeField === 'price' && price > 0) {
      const newProfit = price - cost
      const newMargin = cost !== 0 ? ((newProfit / cost) * 100).toFixed(2) : '0.00'

      setValue('profit', newProfit.toFixed(2))
      setValue('margin', newMargin)
    }

    // CASE 2: user edits Profit
    else if (activeField === 'profit' && profit >= 0) {
      const newPrice = cost + profit
      const newMargin = cost !== 0 ? ((profit / cost) * 100).toFixed(2) : '0.00'

      setValue('price', newPrice.toFixed(2))
      setValue('margin', newMargin)
    }

    // CASE 3: user edits Margin (MARKUP)
    else if (activeField === 'margin' && margin >= 0) {
      const newProfit = cost * (margin / 100)
      const newPrice = cost + newProfit

      setValue('profit', newProfit.toFixed(2))
      setValue('price', newPrice.toFixed(2))
    }
  }, [watchedValues, setValue])

  useEffect(() => {
    setValue('price', '')
    setValue('profit', '')
    setValue('margin', '')
  }, [watch('cost')])

  const handleFinalVariants = useCallback((variantList) => {
    setCustomVariants(variantList)
  }, [])

  const handleTagSearch = async (inputValue) => {
    if (!inputValue) return

    try {
      const response = await searchTags(inputValue).unwrap()
      console.log(response)
      const newOptions = response.map((tag) => ({
        value: tag.id,
        label: tag.name,
      }))

      // Ensure already selected tags are included
      const merged = [...newOptions, ...selectedTags.filter((tag) => !newOptions.find((opt) => opt.value === tag.value))]

      setFetchedTagOptions(merged)
    } catch (error) {
      console.error('Tag search error:', error)
    }
  }
  const collectionOptions = collectionData.map((type) => ({
    value: type.collection_id,
    label: type.name,
  }))

  return (
    <Row className="justify-content-center">
      <div >
        <Form onSubmit={handleSubmit(onSubmit)}>
          <input type="hidden" {...register('brand_id')} />

          <Row>
            {/*======================================Left Side====================================== */}

            <Col sm={12}>
              <ComponentContainerCard title="Add New Product" sub="Basic details about your product.">
                {/* Title – same font, just bigger */}
                {/* <div
                  style={{
                    fontSize: '18px', // ⬅️ increased
                    fontWeight: 600,
                    color: '#212529',
                    marginBottom: '6px',
                  }}>
                  Add New Product
                </div> */}

                {/* Smooth divider */}
                {/* <hr
                  style={{
                    margin: '6px 0 16px',
                    borderColor: '#e9ecef',
                    opacity: 1,
                  }}
                /> */}

                <Row>
                  <Col md="12">
                    <FormLabel className="col-sm-4 col-form-label text-start">Title</FormLabel>
                    <Col sm="12">
                      <FormControl
                        type="text"
                        {...register('title')}
                        maxLength={100}
                        value={watch('title')}
                        placeholder="Enter Product Name"
                        onChange={(e) => {
                          if (e.target.value.length <= 100) {
                            setValue('title', e.target.value)
                          }
                        }}
                      />
                      <Form.Text className="text-muted">{watch('title')?.length || 0}/100 characters</Form.Text>

                      <p className="text-danger ps-1">{errors.title?.message}</p>
                    </Col>
                  </Col>
                </Row>
                <Row className="mb-1">
                  <Col md="12">
                    <FormLabel className="col-sm-4 col-form-label text-start">Description</FormLabel>
                    <Col>
                      <CustomQuill value={description} setValue={setDescription} />
                    </Col>
                  </Col>
                </Row>

                {/* Media Section */}
                <div style={{ marginTop: '20px' }}>
                  <FormLabel className="col-sm-4 col-form-label text-start">Media</FormLabel>

                  {/* Soft divider */}
                  <hr
                    style={{
                      margin: '6px 0 16px',
                      borderColor: '#e9ecef',
                      opacity: 1,
                    }}
                  />

                  <Row>
                    <MediaUploader
                      className="mt-3"
                      productId={productId}
                      onMediaChange={setUploadedMediaList}
                      showModal={showMediaUploader}
                      setShowModal={setShowMediaUploader}
                    />
                  </Row>
                </div>

                <Row className="mb-0 align-items-start">
                  <Col md="4">
                    <InsertBarcode
                      value={watch('barcode') || ''}
                      error={errors.barcode?.message}
                      onChange={(val) => {
                        setValue('barcode', val)
                        clearErrors('barcode')
                      }}
                    />
                  </Col>

                  <Col md="4">
                    <BrandSelector
                      initialBrandId={null}
                      onSelectBrand={(id) => {
                        setSelectedBrandId(id)
                        setValue('brand_id', id || null)
                      }}
                      errors={errors}
                    />
                  </Col>
                  {/* Keywords */}
                  <Col md="4">
                    <InsertKeywords value={keywords} onChange={setKeywords} />
                  </Col>
                </Row>

                <Row className="mb-3 align-items-start">
                  {/* Measurement Unit */}
                  <Col md="4">
                    <MeasurementSelector
                      onSelectMeasurement={(id) => {
                        setSelectedMeasurementId(id)
                        setValue('measurement_id', id || '')
                      }}
                      onShowChange={(showIsPcs) => {
                        setMeasurementShow(showIsPcs)
                      }}
                      onAmountPerUnitChange={(val) => {
                        setAmountPerUnit(val)
                        setValue('amount_per_unit', val || '')
                        if (val && val !== '') {
                          clearErrors('amount_per_unit')
                        }
                      }}
                      onAmountFieldVisibleChange={(visible) => {
                        setAmountFieldVisible(Boolean(visible))
                        if (!visible) {
                          setValue('amount_per_unit', '')
                          clearErrors('amount_per_unit')
                        }
                      }}
                      onMeasurementValueChange={(val) => {
                        setSelectedMeasurementUnit(String(val || '').toLowerCase())
                      }}
                      errors={errors}
                    />
                  </Col>

                  {/* Default Weight (conditionally shown) */}
                  {(() => {
                    const u = String(selectedMeasurementUnit || '')
                      .toLowerCase()
                      .trim()
                    const hideFor = new Set(['g', 'gram', 'grams', 'kg', 'kilogram', 'kilograms', 'kgs'])
                    const show = !hideFor.has(u)

                    if (!show) {
                      // 🔒 reserve space so layout doesn't jump
                      return <Col md="4" />
                    }

                    return (
                      <Col md="4">
                        <FormLabel className="col-form-label text-start d-flex align-items-center gap-1">
                          Default Weight (KG)
                          <OverlayTrigger
                            placement="right"
                            overlay={<Tooltip id="weight-info-tooltip">Recommended for invoicing and delivery billing accuracy.</Tooltip>}>
                            <span style={{ cursor: 'pointer' }}>
                              <Icon icon="mdi:information" width={16} color="#6c757d" />
                            </span>
                          </OverlayTrigger>
                        </FormLabel>

                        <FormControl
                          name="weight_per_item"
                          type="number"
                          inputMode="decimal"
                          step="0.01"
                          min={0}
                          placeholder="e.g., 1.25"
                          {...register('weight_per_item')}
                        />

                        <div style={{ minHeight: '16px' }}>
                          <Form.Text className="text-danger">{errors.weight_per_item?.message || '\u00A0'}</Form.Text>
                        </div>
                      </Col>
                    )
                  })()}
                </Row>

                {isCategoryLoading ? (
                  <p>Loading categories...</p>
                ) : (
                  <Row>
                    {/* Main Category */}
                    <Col md="4" className="mb-3">
                      <FormLabel className="col-form-label text-start">Main Category *</FormLabel>
                      <FormSelect
                        onChange={(e) => {
                          const selected = Number(e.target.value)
                          setSelectedMain(selected)
                          setSelectedSub(null)
                          setValue('category', selected) // Save main as selected if no sub
                        }}>
                        <option value="">Select Main Category</option>
                        {mainCategories.map((cat) => (
                          <option key={cat.category_id} value={cat.category_id}>
                            {cat.name}
                          </option>
                        ))}
                      </FormSelect>
                      <Form.Text className="text-danger">{errors.category?.message}</Form.Text>
                    </Col>

                    {/* Sub Category */}
                    {selectedMain && getSubCategories(selectedMain).length > 0 && (
                      <Col md="4" className="mb-3">
                        <FormLabel className="col-form-label text-start">Sub Category</FormLabel>
                        <FormSelect
                          onChange={(e) => {
                            const selected = Number(e.target.value)
                            setSelectedSub(selected)
                            setValue('category', selected) // Save sub as selected if no child
                          }}>
                          <option value="">Select Sub Category</option>
                          {getSubCategories(selectedMain).map((cat) => (
                            <option key={cat.category_id} value={cat.category_id}>
                              {cat.name}
                            </option>
                          ))}
                        </FormSelect>
                      </Col>
                    )}

                    {/* Child Category */}
                    {selectedSub && getSubCategories(selectedSub).length > 0 && (
                      <Col md="4" className="mb-3">
                        <FormLabel className="col-form-label text-start">Child Category</FormLabel>
                        <FormSelect
                          onChange={(e) => {
                            const selected = Number(e.target.value)
                            setValue('category', selected) // Save child category as final
                          }}>
                          <option value="">Select Child Category</option>
                          {getSubCategories(selectedSub).map((cat) => (
                            <option key={cat.category_id} value={cat.category_id}>
                              {cat.name}
                            </option>
                          ))}
                        </FormSelect>
                      </Col>
                    )}
                  </Row>
                )}
              </ComponentContainerCard>
              {/* 
              listing settings open */}
              <ComponentContainerCard title="Listing Settings" sub="Visibility, availability and web presence.">
                {/* ───── ALWAYS VISIBLE TOGGLES ───── */}
                <Row className="mt-3">
                  <Col md="4">
                    {/* Status Toggle */}
                    <FormGroup className="mb-2">
                      <FormLabel>Status</FormLabel>
                      <Form.Check
                        type="switch"
                        id="status-toggle"
                        label={statusValue === 'active' ? 'Active' : 'Inactive'}
                        checked={statusValue === 'active'}
                        onChange={(e) => setValue('status', e.target.checked ? 'active' : 'inactive')}
                      />
                    </FormGroup>
                  </Col>

                  <Col md="4">
                    {/* Publish to Web Toggle */}
                    <FormGroup>
                      <FormLabel>Publish to Web</FormLabel>
                      <Form.Check
                        type="switch"
                        id="publish-to-web-toggle"
                        label={publishToWeb ? 'Published' : 'Unpublished'}
                        checked={publishToWeb}
                        onChange={(e) => setPublishToWeb(e.target.checked)}
                      />
                    </FormGroup>
                  </Col>

                  <Col md="4">
                    {/* Continue Selling Toggle */}
                    <FormGroup>
                      <FormLabel>Continue Selling</FormLabel>
                      <Form.Check
                        type="switch"
                        id="continue-selling-toggle"
                        label={continueSelling ? 'Enabled' : 'Disabled'}
                        checked={continueSelling}
                        onChange={(e) => setContinueSelling(e.target.checked)}
                      />
                    </FormGroup>
                  </Col>
                </Row>
                {publishToWeb && <hr />}

                {/* ───── REST OF LISTING SETTINGS (CONDITIONAL) ───── */}
                {publishToWeb && (
                  <Row className="align-items-start">
                    {/* LEFT: LISTING */}
                    <Col md="6">
                      <div
                        style={{
                          fontSize: '12px',
                          fontWeight: 600,
                          color: '#6c757d',
                          letterSpacing: '0.4px',
                          textTransform: 'uppercase',
                          marginBottom: '10px',
                        }}>
                        Listing
                      </div>

                      {/* Collections */}
                      <FormGroup className="mb-3">
                        <FormLabel>Collections</FormLabel>
                        <Select
                          isMulti
                          placeholder="Select collections"
                          value={selectedCollections}
                          onChange={setSelectedCollections}
                          options={collectionOptions}
                        />
                      </FormGroup>
                    </Col>

                    {/* RIGHT: SEARCH ENGINE */}
                    <Col md="6">
                      <div
                        style={{
                          fontSize: '12px',
                          fontWeight: 600,
                          color: '#6c757d',
                          letterSpacing: '0.4px',
                          textTransform: 'uppercase',
                          marginBottom: '10px',
                        }}>
                        Search Engine
                      </div>

                      {/* SEO Title */}
                      <FormGroup className="mb-3">
                        <FormLabel>Search Engine Title</FormLabel>
                        <FormControl
                          maxLength={70}
                          value={seoTitle}
                          onChange={(e) => {
                            setSeoTitleTouched(true)
                            setSeoTitle(e.target.value)
                            setValue('search_engine_title', e.target.value)
                          }}
                        />
                        <Form.Text className="text-muted">{seoTitle.length}/70 characters</Form.Text>
                      </FormGroup>

                      {/* Tags */}
                      <FormGroup className="mb-3">
                        <FormLabel>Tags</FormLabel>
                        <AsyncCreatableSelect
                          isMulti
                          cacheOptions
                          defaultOptions
                          value={selectedTags}
                          onChange={setSelectedTags}
                          loadOptions={async (inputValue) => {
                            try {
                              const result = await searchTags(inputValue).unwrap()
                              return result.map((tag) => ({
                                label: tag.name,
                                value: tag.tag_id,
                              }))
                            } catch {
                              return selectedTags
                            }
                          }}
                        />
                      </FormGroup>

                      {/* SEO Description */}
                      <FormGroup>
                        <FormLabel>Search Engine Description</FormLabel>
                        <FormControl
                          as="textarea"
                          rows={4}
                          maxLength={120}
                          value={seoDesc}
                          onChange={(e) => {
                            setSeoDescTouched(true)
                            setSeoDesc(e.target.value)
                            setValue('search_engine_desc', e.target.value)
                          }}
                        />
                        <Form.Text className="text-muted">{seoDesc.length}/120 characters</Form.Text>
                      </FormGroup>
                    </Col>
                  </Row>
                )}
              </ComponentContainerCard>

              {/* closing */}
              <ComponentContainerCard title={<span>Pricing {currencySymbol ? `(${currencySymbol})` : ''}</span>} sub="Cost, selling price, margin and profit are linked — edit any one.">
                {/* Pricing Fields */}
                <Row className="my-2">
                  {/* Cost */}
                  <Col md="3">
                    <FormLabel className="col-form-label text-start">Cost</FormLabel>
                    <FormControl
                      name="cost"
                      type="text"
                      inputMode="decimal"
                      pattern="^[0-9]*\\.?[0-9]*$"
                      {...register('cost')}
                      onKeyPress={onlyAllowNumbers}
                      placeholder={`0.00 ${currencySymbol}`}
                    />
                    <Form.Text className="text-danger">{errors.cost?.message}</Form.Text>
                  </Col>

                  {/* Margin */}
                  <Col md="3">
                    <FormLabel className="col-form-label text-start">Margin (%)</FormLabel>
                    <FormControl
                      name="margin"
                      type="text"
                      inputMode="decimal"
                      pattern="^[0-9]*\\.?[0-9]*$"
                      {...register('margin')}
                      onKeyPress={onlyAllowNumbers}
                      placeholder="0.00 %"
                    />
                    <Form.Text className="text-danger">{errors.margin?.message}</Form.Text>
                  </Col>

                  {/* Selling Price */}
                  <Col md="3">
                    <FormLabel className="col-form-label text-start">Selling Price</FormLabel>
                    <FormControl
                      name="price"
                      type="text"
                      inputMode="decimal"
                      pattern="^[0-9]*\\.?[0-9]*$"
                      {...register('price')}
                      onKeyPress={onlyAllowNumbers}
                      placeholder={`0.00 ${currencySymbol}`}
                    />
                    <Form.Text className="text-danger">{errors.price?.message}</Form.Text>
                  </Col>

                  {/* Profit */}
                  <Col md="3">
                    <FormLabel className="col-form-label text-start">Profit</FormLabel>
                    <FormControl
                      name="profit"
                      type="text"
                      inputMode="decimal"
                      pattern="^[0-9]*\\.?[0-9]*$"
                      {...register('profit')}
                      onKeyPress={onlyAllowNumbers}
                      placeholder={`0.00 ${currencySymbol}`}
                    />
                    <Form.Text className="text-danger">{errors.profit?.message}</Form.Text>
                  </Col>
                </Row>
              </ComponentContainerCard>

              {measurementShow && (
                <ComponentContainerCard title="Variants" sub="Size, colour, or other option combination.">
                  <br />

                  {/* ---------- RENDER VARIANT SELECTOR CARD ONLY WHEN measurementShow is true ---------- */}
                  <VariantSelectorCard
                    basePrice={{
                      cost: parseMoney(watch('cost')),
                      selling: parseMoney(watch('price')),
                      weight: parseFloat(watch('weight_per_item') || 0),
                    }}
                    onFinalVariants={handleFinalVariants}
                    onMediaUploadClick={(key) => {
                      setActiveVariantKey(key)
                      setShowVariantMediaModal(true)
                    }}
                  />

                  <VariantUploaderModal
                    productId={productId}
                    showModal={showVariantMediaModal}
                    setShowModal={setShowVariantMediaModal}
                    activeVariantKey={activeVariantKey}
                    onMediaChange={handleMediaChange}
                  />

                  {/* FINAL VARIANT OUTPUT */}
                  {customVariants.length > 0 && (
                    <div className="mt-3">
                      <h6 className="fw-bold">Final Variant Output</h6>
                      <Row className="d-flex mx-1 gy-1">
                        {customVariants.map((v, idx) => (
                          <Col md="4" key={idx} className=" d-flex flex-column justify-content-between p-1">
                            <div className="border rounded p-1">
                              <div className="d-flex gap-1 align-items-center py-1">
                                {Array.isArray(v.option_values) &&
                                  v.option_values.map((opt, i) => (
                                    <Badge key={i} bg="light" className="me-1 text-dark">
                                      {opt.value}
                                    </Badge>
                                  ))}
                              </div>
                              <div className="d-flex justify-content-between px-1">
                                <span className="text-muted text-start">
                                  Cost: <br /> Selling:
                                </span>
                                <span className="text-muted text-end">
                                  {v.cost} {currencySymbol} <br />
                                  {v.price} {currencySymbol}
                                </span>
                              </div>
                            </div>
                          </Col>
                        ))}
                      </Row>
                    </div>
                  )}
                </ComponentContainerCard>
              )}
              {/*======================================Right Side====================================== */}

              <Row className="mb-3 d-flex justify-content-end px-2">
                <Button
                  type="button"
                  className="btn bg-primary border-primary px-4 py-2 me-0 w-25"
                  disabled={isSubmitting}
                  onClick={async () => {
                    const isValid = await trigger()
                    // run the normal validations first
                    if (!isValid) return

                    // Additional runtime validation: measurement required
                    const formValues = getValues()
                    const selectedMeasId = selectedMeasurementId ?? formValues.measurement_id
                    if (!selectedMeasId && (!formValues.measurement_id || formValues.measurement_id === '')) {
                      setError('measurement_id', { type: 'required', message: 'Please select a measurement unit' })
                      // scroll to element if you want:
                      const el = document.querySelector('[name="measurement_id"]')
                      if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
                      return
                    }

                    // If amount field is visible (child told us), require amount_per_unit
                    if (amountFieldVisible) {
                      const amt = (formValues.amount_per_unit ?? '').toString().trim()
                      if (amt === '' || amt === null || amt === undefined) {
                        setError('amount_per_unit', { type: 'required', message: 'Amount per unit is required' })
                        const el = document.querySelector('[name="amount_per_unit"]')
                        if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
                        return
                      }
                      // Optionally: validate numeric
                      if (!/^[0-9]*\.?[0-9]+$/.test(amt)) {
                        setError('amount_per_unit', { type: 'pattern', message: 'Amount must be a number' })
                        return
                      }
                    }

                    const formData = getValues()
                    const plainDescription = stripHtml(description)

                    const safeData = {
                      ...formData,
                      title: formData.title.trim().slice(0, 100),
                      search_engine_title: formData.search_engine_title?.trim().slice(0, 70) || formData.title.trim().slice(0, 70),
                      search_engine_desc: formData.search_engine_desc?.trim().slice(0, 120) || plainDescription.slice(0, 120),
                      measurement_id: selectedMeasId ?? null,
                      amount_per_unit: formData.amount_per_unit !== '' ? parseFloat(formData.amount_per_unit) : null,
                    }

                    console.log('SAFE DATA (to confirm):', safeData)

                    setPendingSubmitData(safeData)
                    setShowConfirmModal(true)
                  }}>
                  {isSubmitting ? 'Saving Product…' : 'Save Product'}
                </Button>
                {/* <Col sm="10" className="offset-sm-2 text-end">
              </Col> */}
              </Row>
            </Col>
          </Row>
        </Form>
      </div>
      {showConfirmModal && (
        <Modal show={showConfirmModal} onHide={() => setShowConfirmModal(false)} centered size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Confirm Variants</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {measurementShow ? (
              <>
                <p className="mb-2">These are the variants you’ve added:</p>

                <Row className="d-flex mx-1 gy-1">
                  {customVariants.map((v, idx) => (
                    <Col md="4" key={idx} className="d-flex flex-column justify-content-between p-1">
                      <div className="border rounded p-1">
                        <div className="d-flex gap-1 align-items-center py-1">
                          {v.option_values.map((opt, i) => (
                            <Badge key={i} bg="light" className="me-1 text-dark">
                              {opt.value}
                            </Badge>
                          ))}
                        </div>

                        <div className="d-flex justify-content-between px-1">
                          <span className="text-muted text-start">
                            Cost: <br /> Selling:
                          </span>
                          <span className="text-muted text-end">
                            {v.cost} {currencySymbol} <br />
                            {v.price} {currencySymbol}
                          </span>
                        </div>
                      </div>
                    </Col>
                  ))}
                </Row>
              </>
            ) : (
              <>
                {/* FALLBACK SHOWN WHEN measurementShow = false */}
                <p className="mb-2 text-muted">Variants are disabled for the selected measurement type.</p>
              </>
            )}

            <p className="mt-3">Do you want to confirm and proceed?</p>
          </Modal.Body>

          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>
              No
            </Button>

            <Button variant="primary" onClick={handleConfirmedSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Confirming...' : 'Confirm'}
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </Row>
  )
}

export default AddProducts
