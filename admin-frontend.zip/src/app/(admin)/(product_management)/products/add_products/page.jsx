import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Add Product',
}

const AddProduct = dynamic(() => import('./AddProduct'), { ssr: false })

export default function AddProductPage() {
  return <AddProduct />
}