'use client'

import { useState } from 'react'
import AsyncCreatableSelect from 'react-select/async-creatable'
import { Form } from 'react-bootstrap'

const MAX_KEYWORDS = 20

const InsertKeywords = ({ value = [], onChange, error, placeholder = 'Enter keywords' }) => {
  const [localError, setLocalError] = useState('')

  // normalize + dedupe
  const normalize = (keywords) => {
    const map = new Map()

    ;(keywords || []).forEach((k) => {
      const label = k?.label?.trim()
      if (!label) return

      const key = label.toLowerCase()
      if (!map.has(key)) {
        map.set(key, { label, value: key })
      }
    })

    return Array.from(map.values())
  }

  const handleChange = (newValue, actionMeta) => {
    setLocalError('') // clear error on any valid change

    if (newValue && newValue.length > MAX_KEYWORDS) {
      setLocalError(`Maximum ${MAX_KEYWORDS} keywords allowed`)
      return
    }

    if (actionMeta.action === 'create-option') {
      const label = actionMeta.option.label.trim()
      if (!label) return

      const key = label.toLowerCase()

      // ✅ EXACT duplicate check
      const exists = value.some((k) => k.label.trim().toLowerCase() === key)

      if (exists) {
        setLocalError('This keyword already exists')
        return
      }

      if (value.length >= MAX_KEYWORDS) {
        setLocalError(`Maximum ${MAX_KEYWORDS} keywords allowed`)
        return
      }

      onChange(normalize([...value, { label, value: key }]))
      return
    }

    onChange(normalize(newValue))
  }

  return (
    <Form.Group className="mb-1 w-100">
      <Form.Label className="col-form-label text-start">Keywords</Form.Label>

      <AsyncCreatableSelect
        isMulti
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        loadOptions={async () => []}
        formatCreateLabel={(input) => `Add keyword "${input}"`}
        isDisabled={value.length >= MAX_KEYWORDS}
        className="w-100"
        classNamePrefix="react-select"
        styles={{
          container: (base) => ({
            ...base,
            width: '100%',
          }),
          control: (base, state) => ({
            ...base,
            minHeight: '38px',
            width: '100%',
            borderRadius: '999px',
            borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
          }),
        }}
      />

      <div className="d-flex justify-content-between">
        <Form.Text className="text-danger">{localError || error || '\u00A0'}</Form.Text>

        <Form.Text muted>
          {value.length}/{MAX_KEYWORDS}
        </Form.Text>
      </div>
    </Form.Group>
  )
}

export default InsertKeywords
