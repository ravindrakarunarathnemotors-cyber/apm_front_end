'use client'

import React, { useState, useEffect, useMemo, useRef } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  useGetFilteredProductListMutation,
  useGetProductseQuery,
  useGetProductceyQuery,
  useToggleProductStatusMutation,
  useGetProductcollQuery,
} from '@/store/features/apiSlice'

function ProductsPage() {
  const [filters, setFilters] = useState({ keyword: '' })
  const [productName, setProductName] = useState('')
  const [productstate, setProductState] = useState('active')
  const [productId, setProductId] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [searchCategory, setSearchCategory] = useState('')
  const [searchCollection, setSearchCollection] = useState('')
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [selectedCollection, setSelectedCollection] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [currency, setCurrency] = useState('')
  const logsPerPage = 10
  const [keywordInputValue, setKeywordInputValue] = useState('')
  const [isKeywordMenuOpen, setIsKeywordMenuOpen] = useState(false)
  const isKeywordSelectingRef = useRef(false)

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredProductListMutation()

  const { data: productResults } = useGetProductseQuery(searchProduct, {
    skip: searchProduct.length < 2,
  })
  const [toggleProductStatus] = useToggleProductStatusMutation()

  const { data: productCategory } = useGetProductceyQuery(searchCategory, {
    skip: searchCategory.length < 2,
  })

  const { data: productColloection } = useGetProductcollQuery(searchCollection, {
    skip: searchCollection.length < 2,
  })

  const productStateOptions = [
    { value: '', label: 'All' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
  ]

  // stable debounced setter for keyword search
  // const debouncedSearchKeyword = useMemo(
  //   () => debounce((value) => setSearchProduct(value), 300),
  //   []
  // );

  // cleanup on unmount
  // useEffect(() => {
  //   return () => debouncedSearchKeyword.cancel();
  // }, [debouncedSearchKeyword]);

  // Build options for Keyword select from productResults
  const keywordOptions = useMemo(
    () =>
      productResults?.map((p) => ({
        value: p.product_id,
        label: `${p.title} (${p.product_id})`,
      })) || [],
    [productResults],
  )

  useEffect(() => {
    if (keywordOptions.length > 0) {
      setIsKeywordMenuOpen(true)
    }
  }, [keywordOptions])

  const debouncedSearchKeyword = useMemo(
    () =>
      debounce((value) => {
        const v = (value || '').trim()
        // send as-is; backend should treat numeric-only as ID, else as name
        setSearchProduct(v)
      }, 300),
    [],
  )

  const productOptions =
    productResults?.map((product) => ({
      value: product.product_id,
      label: `${product.title} (${product.product_id})`,
    })) || []

  const categoryOptions =
    productCategory?.map((cat) => ({
      value: cat.category_id,
      label: `${cat.name} (${cat.category_id})`,
    })) || []

  const debouncedSearchProduct = debounce((value) => {
    setSearchProduct(value)
  }, 300)

  const debouncedSearchCategory = debounce((value) => {
    setSearchCategory(value)
  }, 300)

  const productCollecOptions =
    productColloection?.map((collect) => ({
      value: collect.collection_id,
      label: `${collect.name} (${collect.collection_id})`,
    })) || []

  const debouncedSearchProductcollect = debounce((value) => {
    setSearchCollection(value)
  }, 300)

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredProducts({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        product_state: productstate,
        productId: productId,
        product_name: productName,
        category: selectedCategory?.value || '',
        collection: selectedCollection?.value || '',
        created_at: productDate,
        merchant_id: '20001',
      }).unwrap()

      setLogs(res.products || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
      setCurrency(res.currency || res.products?.[0]?.currency || '')
      setCurrency(res.products?.[0]?.currency || '')
    } catch (err) {
      console.error('Failed to fetch products:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const handleToggleStatus = async (product_id) => {
    const product = logs.find((p) => p.product_id === product_id)
    if (!product) return

    const newStatus = product.status === 'active' ? 'inactive' : 'active'
    const user_id = sessionStorage.getItem('user_id')

    const result = await Swal.fire({
      title: `Confirm Product ${newStatus === 'active' ? 'Inactive' : 'Active'} Status Change`,
      html: `
      Are you sure you want to <strong>${newStatus === 'active' ? 'Active' : 'Inactive'}</strong> the ${product.product_name}?<br/><br/>
    
      
    `,

      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus === 'active' ? 'Active' : 'Inactive'}`,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      await toggleProductStatus({
        product_id,
        status: newStatus,
        user_id,
      }).unwrap()

      Swal.fire('Success', 'Product status updated successfully!', 'success')

      setLogs((prevLogs) => prevLogs.map((p) => (p.product_id === product_id ? { ...p, status: newStatus } : p)))
    } catch (error) {
      console.error('Failed to update product status:', error)
      Swal.fire('Error', 'Failed to update product status.', 'error')
    }
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  const normalizedProducts = logs.map((p) => ({
    product_id: p.product_id,
    name: p.product_name || 'No Name',
    category: p.categories || '-',
    collections: p.collections || '-',
    price: parseFloat(p.price),
    status: p.status || 'N/A',
    created_at: p.created_at,
    image_url: p.selected_image || null,
  }))

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Active Products
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Link href="/products/add_products" passHref>
                  <Button type="button" className="btn bg-primary border border-primary">
                    <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Add Product
                  </Button>
                </Link>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-3 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Product Date</FormLabel>
                <Form.Control type="date" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
              </FormGroup>

              {/* <FormGroup className="col-md-2">
                <FormLabel>Product ID</FormLabel>
                <Form.Control type="text" placeholder="Product ID" value={productId} onChange={(e) => setProductId(e.target.value)} />
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Product Name</FormLabel>
                <Select
                  options={productOptions}
                  onInputChange={debouncedSearchProduct}
                  onChange={(option) => {
                    setSelectedProduct(option)
                    setProductName(option?.label?.split('(')[0].trim() || '')
                  }}
                  placeholder="Search Product..."
                  isClearable
                  isSearchable
                  value={selectedProduct}
                />
              </FormGroup> */}
              <FormGroup className="col-md-3">
                <FormLabel>Keyword</FormLabel>

                <Select
                  options={keywordOptions}
                  placeholder="ID, Name, Keyword"
                  isClearable
                  isSearchable
                  value={filters.keyword ? { label: filters.keyword, value: filters.keyword } : null}
                  inputValue={keywordInputValue}
                  menuIsOpen={isKeywordMenuOpen}
                  filterOption={null} // 🔥 disable client-side filtering
                  components={{ DropdownIndicator: null }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  onInputChange={(value, { action }) => {
                    if (isKeywordSelectingRef.current) return
                    if (action !== 'input-change') return

                    setKeywordInputValue(value)
                    setIsKeywordMenuOpen(true)

                    debouncedSearchKeyword(value)
                    setFilters((prev) => ({ ...prev, keyword: value }))
                  }}
                  onChange={(option) => {
                    isKeywordSelectingRef.current = true

                    if (option) {
                      const nameOnly = option.label.split('(')[0].trim()
                      setFilters((prev) => ({ ...prev, keyword: nameOnly }))
                      setSearchProduct(nameOnly)
                    } else {
                      setFilters((prev) => ({ ...prev, keyword: '' }))
                      setSearchProduct('')
                    }

                    setKeywordInputValue('')
                    setIsKeywordMenuOpen(false)

                    setTimeout(() => {
                      isKeywordSelectingRef.current = false
                    }, 0)
                  }}
                  onMenuClose={() => setIsKeywordMenuOpen(false)}
                />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Product Category</FormLabel>
                <Select
                  options={categoryOptions}
                  onInputChange={debouncedSearchCategory}
                  onChange={(option) => {
                    setSelectedCategory(option)
                  }}
                  placeholder="Category..."
                  isClearable
                  isSearchable
                  value={selectedCategory}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Product Collection</FormLabel>
                <Select
                  options={productCollecOptions}
                  onInputChange={debouncedSearchProductcollect}
                  onChange={(option) => {
                    setSelectedCollection(option)
                  }}
                  placeholder="Collection..."
                  isClearable
                  isSearchable
                  value={selectedCollection}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-12 col-md-2 d-flex align-items-end">
                <Button
                  type="button"
                  className="btn bg-primary border border-primary  w-100 w-md-auto d-inline-flex align-items-center justify-content-center"
                  onClick={() => fetchLogs(1)}>
                  <Icon className="me-1" style={{ fontSize: '14px' }} />
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading products...</p>
            ) : (
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Created At</th>
                      <th>Product Name </th>
                      <th>Collections</th>
                      <th>Category</th>
                      <th className="text-end">Price ({currency})</th>

                      <th className="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {normalizedProducts.length === 0 ? (
                      <tr>
                        <td colSpan="7" className="text-center">
                          No products found.
                        </td>
                      </tr>
                    ) : (
                      normalizedProducts.map((item) => (
                        <tr key={item.product_id}>
                          <td>{item.product_id}</td>
                          <td>{new Date(item.created_at).toLocaleDateString()}</td>
                          <td>
                            {item.image_url && (
                              <Image src={item.image_url} alt={item.name} className="rounded-circle thumb-md me-1 d-inline" width={30} height={30} />
                            )}
                            {item.name}
                          </td>
                          <td>{item.collections}</td>
                          <td>{item.category}</td>
                          <td className="text-end">{item.price.toFixed(2)}</td>

                          <td className="text-end">
                            <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                              {/* View Button */}
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#007bff',
                                  borderColor: '#007bff',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => (window.location.href = `/products/product_view?product_id=${item.product_id}`)}>
                                <IconifyIcon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>View</span>
                              </Button>
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#fd7e14',
                                  borderColor: '#fd7e14',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => (window.location.href = `/products/update_product?product_id=${item.product_id}`)}>
                                <IconifyIcon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Edit</span>
                              </Button>

                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  color: '#fff',
                                  backgroundColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                  borderColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                  flex: 1,
                                }}
                                onClick={() => handleToggleStatus(item.product_id)}
                                title={item.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                                <IconifyIcon
                                  icon={item.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                  style={{ fontSize: '20px', marginRight: '4px' }}
                                />
                                <span>{item.status === 'active' ? 'Active' : 'Inactive'}</span>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {/* FIRST */}
                      <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                        First
                      </Pagination.Item>

                      {/* PREVIOUS */}
                      <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                      {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                      {(() => {
                        let pages = []

                        if (totalPages <= 5) {
                          // SHOW ALL PAGES (1 → totalPages)
                          for (let i = 1; i <= totalPages; i++) {
                            pages.push(
                              <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                                {i}
                              </Pagination.Item>,
                            )
                          }
                        } else {
                          // CENTER CURRENT PAGE (MAX 5)
                          let start = currentPage - 2
                          let end = currentPage + 2

                          if (start < 1) {
                            start = 1
                            end = 5
                          }

                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }

                          for (let i = start; i <= end; i++) {
                            pages.push(
                              <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                                {i}
                              </Pagination.Item>,
                            )
                          }
                        }

                        return pages
                      })()}

                      {/* NEXT */}
                      <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                      {/* LAST */}
                      <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                        Last
                      </Pagination.Item>
                    </Pagination>
                  </div>
                )}
              </>
            )}
            {/* <ProductView onEdit={(productId) => handleEdit(productId)} /> */}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default ProductsPage
