'use client'

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import {
  useGetFilteredProductListMutation,
  useGetProductseQuery,
  useGetProductceyQuery,
  useToggleProductStatusMutation,
  useGetProductcollQuery,
} from '@/store/features/apiSlice'

// ─── Stat card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, valueClass = '', icon, iconColor }) {
  return (
    <div className="po-stat-card">
      <div className="po-stat-card-inner">
        <div>
          <div className="po-stat-label">{label}</div>
          <div className={`po-stat-value ${valueClass}`}>{value}</div>
          {sub && <div className="po-stat-sub">{sub}</div>}
        </div>
        {icon && (
          <div className="po-stat-icon" style={{ color: iconColor }}>
            <Icon icon={icon} width={22} height={22} />
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Action button ────────────────────────────────────────────────────────────

function ActBtn({ colorCls, icon, label, onClick, title, loading = false, disabled = false }) {
  return (
    <button
      className={`po-act-btn ${colorCls} ${loading ? 'po-act-btn--loading' : ''}`}
      onClick={onClick}
      title={title}
      disabled={disabled || loading}>
      {loading ? <span className="po-btn-spinner" /> : <Icon icon={icon} width={12} height={12} />}
      {label && <span>{label}</span>}
    </button>
  )
}

// ─── Skeleton rows ────────────────────────────────────────────────────────────

function SkeletonRow() {
  return (
    <tr className="po-skeleton-row">
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 40 }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 160 }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 80 }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 90 }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 70 }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 60, marginLeft: 'auto' }} />
      </td>
      <td className="py-3 px-3">
        <div className="po-skeleton" style={{ width: 170, marginLeft: 'auto' }} />
      </td>
    </tr>
  )
}

function SkeletonCard() {
  return (
    <div className="po-mobile-card">
      <div className="po-skeleton" style={{ width: 60, marginBottom: 8, height: 12, borderRadius: 4 }} />
      <div className="po-skeleton" style={{ width: 140, marginBottom: 6, height: 12, borderRadius: 4 }} />
      <div className="po-skeleton" style={{ width: 100, height: 12, borderRadius: 4 }} />
    </div>
  )
}

// ─── Mobile product card ──────────────────────────────────────────────────────

function MobileProductCard({ product, currency, onView, onEdit, onToggle }) {
  const createdDate = product.created_at
    ? new Date(product.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' })
    : '—'

  return (
    <div className="po-mobile-card">
      <div className="po-mobile-card-header border-bottom pb-1 mb-2">
        <div>
          <span className="po-order-id">#{product.product_id}</span>
        </div>
        <div className="po-date-line">
          <span className="po-date">{createdDate}</span>
        </div>
      </div>

      <div className="po-mobile-card-body">
        <div style={{ display: 'flex', alignItems: 'start', gap: 8 }}>
          {product.media_url ? (
            <img
              src={product.media_url}
              alt={product.name}
              style={{ width: 40, height: 40, borderRadius: 6, objectFit: 'cover', flexShrink: 0, border: '0.5px solid var(--po-border)' }}
            />
          ) : (
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: 6,
                background: 'var(--po-bg-secondary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
                border: '0.5px solid var(--po-border)',
              }}>
              <Icon icon="mdi:image-outline" width={16} style={{ color: 'var(--po-subtle)' }} />
            </div>
          )}
          <div>
            <div className="po-client-name text-capitalize">{product.name}</div>
            {product.category ? <div className="po-client-phone text-capitalize">{product.category}</div> : <div></div>}
            {product.collections ? <div className="po-client-phone text-capitalize">{product.collections}</div> : <div></div>}
          </div>
        </div>
      </div>

      <div className="po-mobile-card-footer gap-1">
        <div className='pb-1 mb-1 border-bottom'>
          <span style={{ fontSize: 13, fontWeight: 700, marginLeft:'2px' }}>
            {currency} {product.price.toFixed(2)}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap', marginLeft: 'auto' }}>
          <ActBtn colorCls="btn-act-view" icon="mdi:eye-outline" label="View" onClick={onView} title="View product" />
          <ActBtn colorCls="btn-act-edit" icon="mdi:pencil" label="Edit" onClick={onEdit} title="Edit product" />
          <ActBtn colorCls="btn-act-inactive" icon="mdi:toggle-switch" label="Set inactive" onClick={onToggle} title="Set inactive" />
        </div>
      </div>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

function ProductsPage() {
  const [filters, setFilters] = useState({ keyword: '' })
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [selectedCollection, setSelectedCollection] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [totalEntries, setTotalEntries] = useState(0)
  const [currency, setCurrency] = useState('')
  const [limit, setLimit] = useState(10)

  const [searchProduct, setSearchProduct] = useState('')
  const [searchCategory, setSearchCategory] = useState('')
  const [searchCollection, setSearchCollection] = useState('')
  const [keywordInputValue, setKeywordInputValue] = useState('')
  const [isKeywordMenuOpen, setIsKeywordMenuOpen] = useState(false)
  const isKeywordSelectingRef = useRef(false)

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredProductListMutation()
  const [toggleProductStatus] = useToggleProductStatusMutation()

  const { data: productResults } = useGetProductseQuery(searchProduct, { skip: searchProduct.length < 2 })
  const { data: productCategory } = useGetProductceyQuery(searchCategory, { skip: searchCategory.length < 2 })
  const { data: productCollection } = useGetProductcollQuery(searchCollection, { skip: searchCollection.length < 2 })

  const keywordOptions = useMemo(
    () => productResults?.map((p) => ({ value: p.product_id, label: `${p.title} (${p.product_id})` })) || [],
    [productResults],
  )

  useEffect(() => {
    if (keywordOptions.length > 0) setIsKeywordMenuOpen(true)
  }, [keywordOptions])

  const debouncedSearchKeyword = useMemo(() => debounce((value) => setSearchProduct((value || '').trim()), 300), [])

  const debouncedSearchCategory = useCallback(
    debounce((v) => setSearchCategory(v), 300),
    [],
  )

  const debouncedSearchCollection = useCallback(
    debounce((v) => setSearchCollection(v), 300),
    [],
  )

  const categoryOptions = productCategory?.map((c) => ({ value: c.category_id, label: `${c.name} (${c.category_id})` })) || []
  const collectionOptions = productCollection?.map((c) => ({ value: c.collection_id, label: `${c.name} (${c.collection_id})` })) || []

  const normalizedProducts = logs.map((p) => ({
    product_id: p.product_id,
    name: p.product_name || 'No Name',
    category: p.categories || '—',
    collections: p.collections || '—',
    price: parseFloat(p.price),
    status: p.status || 'N/A',
    created_at: p.created_at,
    media_url: p.media_url || p.selected_image || null,
    initials: (p.product_name || 'NA').trim().slice(0, 2).toUpperCase(),
  }))

  const showingFrom = logs.length === 0 ? 0 : (currentPage - 1) * limit + 1
  const showingTo = (currentPage - 1) * limit + logs.length

  // ── Fetch — always hardcoded to active ────────────────────────────────────
  const fetchLogs = async (page, customLimit = limit) => {
    setLoading(true)
    try {
      const res = await fetchFilteredProducts({
        page,
        limit: customLimit,
        keyword: filters.keyword,
        product_state: 'active',
        category: selectedCategory?.value || '',
        collection: selectedCollection?.value || '',
        created_at: productDate,
        merchant_id: '20001',
      }).unwrap()

      setLogs(res.products || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
      setCurrentPage(page)
      setCurrency(res.products?.[0]?.currency || '')
      console.log('product', res.products)
    } catch (err) {
      console.error('Failed to fetch products:', err)
      Swal.fire({ icon: 'error', title: 'Failed to load products', text: 'Please check your connection and try again.' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages || page === currentPage) return
    fetchLogs(page, limit)
  }

  const handleToggleStatus = async (product_id) => {
    const product = logs.find((p) => p.product_id === product_id)
    if (!product) return

    const result = await Swal.fire({
      title: 'Set product inactive?',
      html: `Are you sure you want to set <strong>${product.product_name}</strong> to inactive? It will be removed from this list.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, set inactive',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })
    if (!result.isConfirmed) return

    try {
      await toggleProductStatus({ product_id, status: 'inactive' }).unwrap()
      Swal.fire('Success', 'Product set to inactive successfully!', 'success')
      setLogs((prev) => prev.filter((p) => p.product_id !== product_id))
    } catch {
      Swal.fire('Error', 'Failed to update product status.', 'error')
    }
  }

  const paginationPages = () => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, i) => i + 1)
    let start = Math.max(1, currentPage - 2)
    let end = Math.min(totalPages, start + 4)
    if (end - start < 4) start = Math.max(1, end - 4)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const selectStyles = {
    control: (base, state) => ({
      ...base,
      minHeight: '36px',
      height: '36px',
      fontSize: '13px',
      borderRadius: '8px',
      borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
      boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
      background: '#fff',
      transition: 'border-color .15s, box-shadow .15s',
    }),
    valueContainer: (b) => ({ ...b, padding: '0 10px' }),
    indicatorsContainer: (b) => ({ ...b, height: '36px' }),
    menu: (b) => ({ ...b, zIndex: 9999 }),
    menuPortal: (b) => ({ ...b, zIndex: 9999 }),
  }

  // ── Render ──────────────────────────────────────────────────────────────────

  return (
    <div className="container-fluid py-3">
      {/* ── Page header ─────────────────────────────────────────────────── */}
      <div className="d-flex align-items-center justify-content-between mb-3">
        <div>
          <h4 className="fw-bold mb-0" style={{ fontSize: 20, letterSpacing: '-.2px' }}>
            Active Products
          </h4>
          <p className="text-muted mb-0 mt-1" style={{ fontSize: 12.5 }}>
            All currently active and visible products in your catalogue
          </p>
        </div>
        <Link href="/products/add_products" passHref>
          <button className="btn btn-dark btn-sm d-inline-flex align-items-center gap-2">
            <Icon icon="mdi:plus" width={15} />
            Add product
          </button>
        </Link>
      </div>

      {/* ── Stat cards ──────────────────────────────────────────────────── */}
      <div className="row g-2 mb-3">
        <div className="col-6 col-md-4">
          <StatCard
            label="Total active"
            value={totalEntries.toLocaleString()}
            sub="listed & visible in store"
            valueClass="text-success"
            icon="mdi:package-variant-closed"
            iconColor="#065f46"
          />
        </div>
        <div className="col-6 col-md-4">
          <StatCard
            label="Total pages"
            value={totalPages}
            sub={`${limit} products per page`}
            icon="mdi:file-document-multiple-outline"
            iconColor="#374151"
          />
        </div>
        <div className="d-none d-md-block col-md-4">
          <StatCard
            label="This page"
            value={logs.length}
            sub={`page ${currentPage} of ${totalPages}`}
            icon="mdi:view-list-outline"
            iconColor="#374151"
          />
        </div>
      </div>

      {/* ── Filter bar ──────────────────────────────────────────────────── */}
      <div className="po-filter-bar mb-3">
        <div className="row g-2 align-items-end">
          <div className="col-6 col-sm-3 col-lg-2">
            <div className="po-filter-label">Date</div>
            <input type="date" className="form-control form-control-sm" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
          </div>

          <div className="col-12 col-sm-6 col-lg-3">
            <div className="po-filter-label">Keyword</div>
            <Select
              styles={{
                ...selectStyles,
                control: (b, s) => ({ ...selectStyles.control(b, s), borderRadius: '8px' }),
              }}
              menuPortal={typeof document !== 'undefined' ? document.body : null}
              menuPosition="fixed"
              options={keywordOptions}
              placeholder="ID, name, keyword…"
              isClearable
              isSearchable
              value={filters.keyword ? { label: filters.keyword, value: filters.keyword } : null}
              inputValue={keywordInputValue}
              menuIsOpen={isKeywordMenuOpen}
              filterOption={null}
              components={{ DropdownIndicator: null }}
              onInputChange={(value, { action }) => {
                if (isKeywordSelectingRef.current || action !== 'input-change') return
                setKeywordInputValue(value)
                setIsKeywordMenuOpen(true)
                debouncedSearchKeyword(value)
                setFilters((prev) => ({ ...prev, keyword: value }))
              }}
              onChange={(option) => {
                isKeywordSelectingRef.current = true
                if (option) {
                  const name = option.label.split('(')[0].trim()
                  setFilters((prev) => ({ ...prev, keyword: name }))
                  setSearchProduct(name)
                } else {
                  setFilters((prev) => ({ ...prev, keyword: '' }))
                  setSearchProduct('')
                }
                setKeywordInputValue('')
                setIsKeywordMenuOpen(false)
                setTimeout(() => {
                  isKeywordSelectingRef.current = false
                }, 0)
              }}
              onMenuClose={() => setIsKeywordMenuOpen(false)}
            />
          </div>

          <div className="col-6 col-sm-4 col-lg-2">
            <div className="po-filter-label">Category</div>
            <Select
              styles={selectStyles}
              menuPortal={typeof document !== 'undefined' ? document.body : null}
              menuPosition="fixed"
              options={categoryOptions}
              onInputChange={debouncedSearchCategory}
              onChange={(option) => setSelectedCategory(option)}
              placeholder="All categories"
              isClearable
              isSearchable
              value={selectedCategory}
            />
          </div>

          <div className="col-6 col-sm-4 col-lg-2">
            <div className="po-filter-label">Collection</div>
            <Select
              styles={selectStyles}
              menuPortal={typeof document !== 'undefined' ? document.body : null}
              menuPosition="fixed"
              options={collectionOptions}
              onInputChange={debouncedSearchCollection}
              onChange={(option) => setSelectedCollection(option)}
              placeholder="All collections"
              isClearable
              isSearchable
              value={selectedCollection}
            />
          </div>

          <div className="col-12 col-sm-4 col-lg-3">
            <div className="d-flex gap-2">
              <button
                className="btn btn-dark btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-2"
                onClick={() => fetchLogs(1, limit)}
                disabled={loading || isLoading}>
                {loading ? <span className="po-search-spinner" /> : <Icon icon="mdi:magnify" width={14} />}
                <span>{loading ? 'Searching…' : 'Search'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ── Table card ──────────────────────────────────────────────────── */}
      <div className="po-table-card">
        {/* Desktop table */}
        <div className="po-desktop-table table-responsive">
          <table className="table mb-0">
            <thead>
              <tr>
                <th>ID</th>
                <th>Product</th>
                <th>Category</th>
                <th>Collection</th>
                <th>Date</th>
                <th className="text-end">Price ({currency})</th>
                <th className="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading || isLoading ? (
                Array.from({ length: limit }).map((_, i) => <SkeletonRow key={i} />)
              ) : normalizedProducts.length > 0 ? (
                normalizedProducts.map((item, idx) => {
                  const createdDate = item.created_at ? new Date(item.created_at).toLocaleDateString('en-LK', { timeZone: 'Asia/Colombo' }) : '—'

                  return (
                    <tr key={item.product_id} className="po-row-appear" style={{ animationDelay: `${idx * 18}ms` }}>
                      {/* ID */}
                      <td>
                        <span className="po-order-id">#{item.product_id}</span>
                      </td>

                      {/* Product */}
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          {item.media_url ? (
                            <img
                              src={item.media_url}
                              alt={item.name}
                              style={{
                                width: 40,
                                height: 40,
                                borderRadius: 6,
                                objectFit: 'cover',
                                flexShrink: 0,
                                border: '0.5px solid var(--po-border)',
                              }}
                            />
                          ) : (
                            <div
                              style={{
                                width: 40,
                                height: 40,
                                borderRadius: 6,
                                flexShrink: 0,
                                background: '#e0e7ff',
                                border: '0.5px solid #c7d2fe',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: 11,
                                fontWeight: 700,
                                color: '#3730a3',
                                letterSpacing: '-.3px',
                                userSelect: 'none',
                              }}>
                              {item.initials}
                            </div>
                          )}
                          <div className="po-client-name">{item.name}</div>
                        </div>
                      </td>

                      {/* Category */}
                      <td>
                        {item.category !== '—' ? (
                          <span className="po-badge badge-category">
                            <Icon icon="mdi:tag-outline" width={10} />
                            {item.category}
                          </span>
                        ) : (
                          <span style={{ color: 'var(--po-subtle)', fontSize: 12 }}>—</span>
                        )}
                      </td>

                      {/* Collection */}
                      <td>
                        {item.collections !== '—' ? (
                          <span className="po-badge badge-collection">
                            <Icon icon="mdi:layers-outline" width={10} />
                            {item.collections}
                          </span>
                        ) : (
                          <span style={{ color: 'var(--po-subtle)', fontSize: 12 }}>—</span>
                        )}
                      </td>

                      {/* Date */}
                      <td>
                        <span className="po-date">{createdDate}</span>
                      </td>

                      {/* Price */}
                      <td className="text-end">
                        <span className="po-price">{item.price.toFixed(2)}</span>
                      </td>

                      {/* Actions */}
                      <td className="text-end">
                        <div className="d-flex align-items-center justify-content-end gap-1 flex-wrap">
                          <ActBtn
                            colorCls="btn-act-view"
                            icon="mdi:eye-outline"
                            label="View"
                            onClick={() => (window.location.href = `/products/product_view?product_id=${item.product_id}`)}
                            title="View product"
                          />
                          <ActBtn
                            colorCls="btn-act-edit"
                            icon="mdi:pencil"
                            label="Edit"
                            onClick={() => (window.location.href = `/products/update_product?product_id=${item.product_id}`)}
                            title="Edit product"
                          />
                          <ActBtn
                            colorCls="btn-act-inactive"
                            icon="mdi:toggle-switch"
                            label="Set inactive"
                            onClick={() => handleToggleStatus(item.product_id)}
                            title="Set inactive"
                          />
                        </div>
                      </td>
                    </tr>
                  )
                })
              ) : (
                <tr>
                  <td colSpan="7">
                    <div className="po-empty">
                      <Icon icon="mdi:package-variant-closed" width={40} height={40} className="po-empty-icon" />
                      <div className="po-empty-title">No active products found</div>
                      <div className="po-empty-sub">Try adjusting your filters or add a new product</div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile card list */}
        <div className="po-mobile-list">
          {loading || isLoading ? (
            Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
          ) : normalizedProducts.length > 0 ? (
            normalizedProducts.map((item) => (
              <MobileProductCard
                key={item.product_id}
                product={item}
                currency={currency}
                onView={() => (window.location.href = `/products/product_view?product_id=${item.product_id}`)}
                onEdit={() => (window.location.href = `/products/update_product?product_id=${item.product_id}`)}
                onToggle={() => handleToggleStatus(item.product_id)}
              />
            ))
          ) : (
            <div className="po-empty">
              <Icon icon="mdi:package-variant-closed" width={40} height={40} className="po-empty-icon" />
              <div className="po-empty-title">No active products found</div>
              <div className="po-empty-sub">Try adjusting your filters</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="po-footer d-flex align-items-center justify-content-between flex-wrap gap-3">
          <div className="d-flex align-items-center gap-2">
            <span className="text-muted" style={{ fontSize: 12 }}>
              Show
            </span>
            <select
              className="form-select form-select-sm w-auto"
              style={{ fontSize: 12, height: 30 }}
              value={limit}
              onChange={(e) => {
                const n = Number(e.target.value)
                setLimit(n)
                setCurrentPage(1)
                fetchLogs(1, n)
              }}>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="text-muted" style={{ fontSize: 12 }}>
              entries
            </span>
          </div>

          <span className="po-showing">
            {logs.length === 0 ? 'No results' : `Showing ${showingFrom}–${showingTo} of ${totalEntries.toLocaleString()} entries`}
          </span>

          {totalPages > 1 && (
            <nav aria-label="Products pagination">
              <ul className="pagination pagination-sm mb-0 gap-1">
                <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                  <button className="page-link po-page-btn" onClick={() => handlePageChange(currentPage - 1)} aria-label="Previous">
                    <Icon icon="mdi:chevron-left" width={14} />
                  </button>
                </li>
                {paginationPages().map((p) => (
                  <li key={p} className="page-item">
                    <button className={`page-link po-page-btn ${p === currentPage ? 'active' : ''}`} onClick={() => handlePageChange(p)}>
                      {p}
                    </button>
                  </li>
                ))}
                <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                  <button className="page-link po-page-btn" onClick={() => handlePageChange(currentPage + 1)} aria-label="Next">
                    <Icon icon="mdi:chevron-right" width={14} />
                  </button>
                </li>
              </ul>
            </nav>
          )}
        </div>
      </div>
    </div>
  )
}

export default ProductsPage
