'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, FormLabel, Form } from 'react-bootstrap'
import Select from 'react-select'
import { useGetReportsBrandsQuery, useGetProductBrandsMutation } from '@/store/features/apiSlice'

export default function BrandSelector({ productId = null, onSelectBrand, initialBrandId = null, value, errors = {} }) {
  const { data: brands = [], isLoading, isError } = useGetReportsBrandsQuery()
  const [getProductBrands, { data: productBrands = [], isLoading: isPBLoading }] = useGetProductBrandsMutation()

  const [selectedBrandId, setSelectedBrandId] = useState(initialBrandId ?? null)
  const [prefilledOnce, setPrefilledOnce] = useState(false)

  useEffect(() => {
    if (initialBrandId !== null && initialBrandId !== undefined) {
      setSelectedBrandId(initialBrandId)
    }
  }, [initialBrandId])

  useEffect(() => {
    if (!productId) return
    if (initialBrandId !== null && initialBrandId !== undefined) return
    getProductBrands({ product_id: Number(productId) })
  }, [productId, initialBrandId, getProductBrands])

  useEffect(() => {
    if (!productId) return
    if (initialBrandId !== null && initialBrandId !== undefined) return
    if (prefilledOnce) return
    if (!productBrands?.length) return

    const first = productBrands[0]
    if (first?.brand_id != null) {
      setSelectedBrandId(first.brand_id)
      onSelectBrand?.(first.brand_id)
      setPrefilledOnce(true)
    }
  }, [productId, productBrands, initialBrandId, prefilledOnce, onSelectBrand])

  const handleSelectBrand = (option) => {
    const id = option ? Number(option.value) : null
    setSelectedBrandId(id)
    onSelectBrand?.(id)
  }

  if (isLoading || (productId && isPBLoading)) return <p>Loading brands...</p>
  if (isError) return <p className="text-danger">Error loading brands. Please try again later.</p>

  const shownValue =
    value !== undefined
      ? value
        ? { value, label: brands.find((b) => b.brand_id === value)?.name ?? '' }
        : null
      : selectedBrandId
        ? { value: selectedBrandId, label: brands.find((b) => b.brand_id === selectedBrandId)?.name ?? '' }
        : null

  const options = brands.map((b) => ({
    value: b.brand_id,
    label: b.name,
  }))

  return (
    <div className="w-100 mb-1">
      <FormLabel className="col-form-label text-start">Brand</FormLabel>

      <Select
        value={shownValue}
        onChange={handleSelectBrand}
        options={options}
        isClearable
        placeholder="Select Brand"
        className="w-100"
        styles={{
          container: (base) => ({
            ...base,
            width: '100%', // 🔥 REQUIRED
          }),
          control: (base, state) => ({
            ...base,
            minHeight: '38px', // Bootstrap input height
            height: '38px',
            width: '100%',
            borderRadius: '999px',
             borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
            boxShadow: state.isFocused ? '0 0 0 0.25rem rgba(13,110,253,.25)' : base.boxShadow,
            '&:hover': { borderColor: '#86b7fe' },
          }),
          valueContainer: (base) => ({
            ...base,
            height: '38px',
            padding: '0 8px',
          }),
          indicatorsContainer: (base) => ({
            ...base,
            height: '38px',
          }),
          clearIndicator: (base) => ({
            ...base,
            padding: '2px',
          }),
          dropdownIndicator: (base) => ({
            ...base,
            padding: '2px',
          }),
          menu: (base) => ({
            ...base,
            zIndex: 9999,
          }),
        }}
      />

      <div style={{ minHeight: '16px' }}>
        <Form.Text className="text-danger">{errors.brand_id?.message || '\u00A0'}</Form.Text>
      </div>
    </div>
  )
}
