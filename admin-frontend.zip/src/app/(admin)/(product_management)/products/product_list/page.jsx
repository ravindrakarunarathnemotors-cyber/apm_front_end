'use client'

import React, { useState, useEffect, useCallback } from 'react'

import Link from 'next/link'
import { debounce } from 'lodash'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetFilteredProductListMutation, useGetProductseQuery, useGetProductceyQuery } from '@/store/features/apiSlice'

function ProductsPage() {
  const [productName, setProductName] = useState('')
  const [productId, setProductId] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [searchCategory, setSearchCategory] = useState('')
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [currency, setCurrency] = useState('')
  const logsPerPage = 25

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredProductListMutation()

  const { data: productResults } = useGetProductseQuery(searchProduct, {
    skip: searchProduct.length < 2,
  })

  const { data: productCategory } = useGetProductceyQuery(searchCategory, {
    skip: searchCategory.length < 2,
  })

  const productOptions =
    productResults?.map((product) => ({
      value: product.product_id,
      label: `${product.title} (${product.product_id})`,
    })) || []

  const categoryOptions =
    productCategory?.map((cat) => ({
      value: cat.category_id,
      label: `${cat.name} (${cat.category_id})`,
    })) || []

  const debouncedSearchProduct = debounce((value) => {
    setSearchProduct(value)
  }, 300)

  const debouncedSearchCategory = debounce((value) => {
    setSearchCategory(value)
  }, 300)

  const fetchLogs = useCallback(
    async (page) => {
      setLoading(true)
      try {
        const res = await fetchFilteredProducts({
          page,
          limit: logsPerPage,
          product_name: productName,
          category: selectedCategory?.value || '',
          created_at: productDate,
          id: productId,
          merchant_id: '20001',
        }).unwrap()

        setLogs(res.products || [])
        setTotalPages(res.totalPages || 1)
        setCurrentPage(page)
        setCurrency(res.currency || res.products?.[0]?.currency || '')
        setCurrency(res.products?.[0]?.currency || '')
      } catch (err) {
        console.error('Failed to fetch products:', err)
      } finally {
        setLoading(false)
      }
    },
    [productName, selectedCategory, productDate, productId, fetchFilteredProducts],
  )

  useEffect(() => {
    fetchLogs(1)
  }, [fetchLogs])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  const normalizedProducts = logs.map((p) => ({
    product_id: p.product_id,
    name: p.product_name || 'No Name',
    category: p.categories || '-',
    price: parseFloat(p.price),
    status: p.status || '-',
    created_at: p.created_at,
    image_url: p.selected_image || null,
  }))

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader
            className="py-2">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Products
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Link href="/products/add_products" passHref>
                  <Button type="button" className="btn btn-light">
                    <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Add Product
                  </Button>
                </Link>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-3 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Product ID</FormLabel>
                <Form.Control type="text" placeholder="Product ID" value={productId} onChange={(e) => setProductId(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Product Name</FormLabel>
                <Select
                  options={productOptions}
                  onInputChange={debouncedSearchProduct}
                  onChange={(option) => {
                    setSelectedProduct(option)
                    setProductName(option?.label?.split('(')[0].trim() || '')
                  }}
                  placeholder="Search Product..."
                  isClearable
                  isSearchable
                  value={selectedProduct}
                />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Product Date</FormLabel>
                <Form.Control type="date" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Product Category</FormLabel>
                <Select
                  options={categoryOptions}
                  onInputChange={debouncedSearchCategory}
                  onChange={(option) => {
                    setSelectedCategory(option)
                  }}
                  placeholder="Search Category..."
                  isClearable
                  isSearchable
                  value={selectedCategory}
                />
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-2">
                <Button variant="primary" onClick={() => fetchLogs(1)} className="w-100">
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading products...</p>
            ) : (
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Product Name</th>
                      <th>Created At</th>
                      <th>Category</th>
                      <th>Price ({currency})</th>
                      <th>Status</th>
                      <th className="text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {normalizedProducts.length === 0 ? (
                      <tr>
                        <td colSpan="7" className="text-center">
                          No products found.
                        </td>
                      </tr>
                    ) : (
                      normalizedProducts.map((item) => (
                        <tr key={item.product_id}>
                          <td>{item.product_id}</td>
                          <td>
                            {item.image_url && (
                              <Image src={item.image_url} alt={item.name} className="rounded-circle thumb-md me-1 d-inline" width={30} height={30} />
                            )}
                            {item.name}
                          </td>
                          <td>{new Date(item.created_at).toLocaleDateString()}</td>
                          <td>{item.category}</td>
                          <td>{item.price.toFixed(2)}</td>
                          <td>{item.status}</td>
                          <td className="text-end">
                            <span role="button">
                              <IconifyIcon icon="la:pen" className="text-secondary font-16" />
                            </span>
                            <span role="button" className="ms-2">
                              <IconifyIcon icon="la:trash-alt" className="text-secondary font-16" />
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>

                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
                    {getPaginationRange().map((pageNum) => (
                      <Pagination.Item key={pageNum} active={pageNum === currentPage} onClick={() => handlePageChange(pageNum)}>
                        {pageNum}
                      </Pagination.Item>
                    ))}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                  </Pagination>
                </div>
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default ProductsPage
