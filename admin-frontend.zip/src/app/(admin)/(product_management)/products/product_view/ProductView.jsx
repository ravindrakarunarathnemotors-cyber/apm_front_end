'use client'

import { useEffect, useMemo, useState } from 'react'
import { Badge, Button, Col, Row, Table, Pagination, Card, Image, Form } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Swal from 'sweetalert2'
import { slugify } from './slugify'
import Link from 'next/link'

// RTK hooks
import {
  useGetProductDetailsQuery,
  useGetActiveProductReviewsQuery,
  useUpdateReviewStatusMutation,
  useToggleProductStatusMutation,
  useGetDiscountCurrencyQuery,
} from '@/store/features/apiSlice'
const CLIENT_BASE = (process.env.NEXT_PUBLIC_CLIENT_WEB_URL || '').replace(/\/+$/, '')
const THUMBS_PAGE_SIZE = 4
const FALLBACK_IMG = '/defimage.png' // keep if you later add a real file in /public

// Zero-network, safe placeholder to avoid infinite 404 loops
const FALLBACK_PLACEHOLDER =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800">
       <rect width="100%" height="100%" fill="#f3f4f6"/>
       <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
             fill="#9ca3af" font-size="28" font-family="sans-serif">
         No Image
       </text>
     </svg>`,
  )

// one-shot error handler to prevent loops
const handleImgError = (e) => {
  e.currentTarget.onerror = null
  e.currentTarget.src = FALLBACK_PLACEHOLDER
}

// Deduplicate and keep truthy values
const uniqUrls = (arr = []) => Array.from(new Set(arr.filter(Boolean)))

// --- helpers: strip HTML safely & get first N sentences ---
const htmlToText = (html = '') => {
  if (!html) return ''
  const el = typeof window !== 'undefined' ? document.createElement('div') : null
  if (!el)
    return html
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
  el.innerHTML = html
  const text = el.textContent || el.innerText || ''
  return text.replace(/\s+/g, ' ').trim()
}

const firstNSentences = (text = '', n = 3) => {
  if (!text) return ''
  // split on sentence boundaries: ., !, ? followed by space/newline
  const parts = text.split(/(?<=[.!?])\s+/).filter(Boolean)
  if (parts.length <= n) return text
  return parts.slice(0, n).join(' ')
}

// -> Add this helper (near fmtRs / capitalize)
const formatPerUnitLabel = (amount, unit) => {
  if (amount === null || amount === undefined || amount === '') return null
  if (!unit) return `Per ${amount}`

  const u = String(unit).trim().toLowerCase()
  // Choose short display labels (matching your earlier style "Kg(s)")
  if (['kg', 'kgs', 'kilogram', 'kilograms'].includes(u)) return `Per ${amount} Kg(s)`
  if (['g', 'gram', 'grams'].includes(u)) return `Per ${amount} Gram(s)`
  if (['l', 'liter', 'litre', 'liters', 'litres', 'ltr', 'ltrs'].includes(u)) return `Per ${amount} L(s)`
  if (['ml', 'milliliter', 'millilitre', 'milliliters', 'millilitres'].includes(u)) return `Per ${amount} mL(s)`
  if (['pcs', 'pc', 'piece', 'pieces'].includes(u)) return `Per ${amount} Piece(s)`

  // Fallback: title-case unit + uppercase abbreviation
  const title = unit
    .toString()
    .split(/[_\s-]+/)
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase())
    .join(' ')
  return `Per ${amount} ${title}`
}

const ProductView = () => {
  const VARIANTS_PER_PAGE = 15
  const REVIEWS_PER_PAGE = 15

  const [variantPage, setVariantPage] = useState(1)
  const [reviewPage, setReviewPage] = useState(1)
  // const [descExpanded, setDescExpanded] = useState(false)

  const searchParams = useSearchParams()
  const router = useRouter()
  const productId = searchParams.get('product_id')

  const [updateReviewStatus] = useUpdateReviewStatusMutation()

  const { data: currencyData } = useGetDiscountCurrencyQuery()

  // RTK may return "USD" or { currency: "USD" }
  const currencySymbol = typeof currencyData === 'string' ? currencyData : currencyData?.currency || ''

  // RTK: fetch product & reviews
  const { data: productData, isLoading: isProductLoading, isFetching: isProductFetching } = useGetProductDetailsQuery(productId, { skip: !productId })

  const { data: reviewsResp } = useGetActiveProductReviewsQuery(productId, { skip: !productId })

  // Star rating renderer (full + half + empty)
  const StarRating = ({ value }) => {
    const v = Number(value) || 0
    return (
      <>
        {Array.from({ length: Math.floor(v) }).map((_, i) => (
          <Icon key={`full-${i}`} icon="mdi:star" color="#ffc107" width={18} height={18} />
        ))}
        {v % 1 >= 0.5 && <Icon icon="mdi:star-half-full" color="#ffc107" width={18} height={18} />}
        {Array.from({ length: 5 - Math.ceil(v) }).map((_, i) => (
          <Icon key={`empty-${i}`} icon="mdi:star-outline" color="#ffc107" width={18} height={18} />
        ))}
        <span className="ms-1 text-muted small">({v.toFixed(1)})</span>
      </>
    )
  }

  // Local product status
  const [status, setStatus] = useState('active')
  useEffect(() => {
    if (productData?.status) setStatus(productData.status)
  }, [productData?.status])

  const [toggleProductStatus] = useToggleProductStatusMutation()

  // ====== Gallery state ======
  const [gallery, setGallery] = useState([]) // list of URLs for thumbnails
  const [activeImg, setActiveImg] = useState('') // main image URL
  const [thumbStart, setThumbStart] = useState(0) // which 4 are visible

  useEffect(() => {
    // product-level
    const mainUrl = productData?.product_media?.main?.media_url || null
    const productSubUrls = (productData?.product_media?.sub || []).map((m) => m?.media_url)

    // variant-level (main + sub)
    const variantUrls = (productData?.variant_media || []).flatMap((v) => [
      v?.main?.media_url,
      ...(Array.isArray(v?.sub) ? v.sub.map((m) => m?.media_url) : []),
    ])

    // Order: product main (if present) → product subs → variant (main+sub)
    const ordered = [...(mainUrl ? [mainUrl] : []), ...productSubUrls, ...variantUrls]

    // Deduplicate
    const unique = uniqUrls(ordered)

    // Fallback
    const finalGallery = unique.length ? unique : [FALLBACK_PLACEHOLDER]

    setGallery(finalGallery)
    setActiveImg(unique.length ? mainUrl || unique[0] : FALLBACK_PLACEHOLDER)
    setThumbStart(0)
  }, [productData?.product_media, productData?.variant_media])

  // Thumb window (only 4)
  const visibleThumbs = useMemo(() => gallery.slice(thumbStart, thumbStart + THUMBS_PAGE_SIZE), [gallery, thumbStart])

  const canPageDown = gallery.length > thumbStart + THUMBS_PAGE_SIZE
  const canPageUp = thumbStart > 0

  const pageDown = () => {
    if (canPageDown) {
      setThumbStart(thumbStart + THUMBS_PAGE_SIZE)
    } else if (gallery.length > THUMBS_PAGE_SIZE) {
      setThumbStart(0) // loop back
    }
  }

  const pageUp = () => {
    if (canPageUp) {
      setThumbStart(Math.max(0, thumbStart - THUMBS_PAGE_SIZE))
    } else if (gallery.length > THUMBS_PAGE_SIZE) {
      const lastStart = (Math.ceil(gallery.length / THUMBS_PAGE_SIZE) - 1) * THUMBS_PAGE_SIZE
      setThumbStart(lastStart) // loop to last window
    }
  }

  // Helpers
  const fmtMoney = (n) => {
    if (n === null || n === undefined || n === '') return `0.00 ${currencySymbol}`
    const num = typeof n === 'number' ? n : Number(n)
    if (Number.isNaN(num)) return `0.00 ${currencySymbol}`
    return `${num.toFixed(2)} ${currencySymbol}`
  }

  const capitalize = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s)

  const handleToggleStatus = async () => {
    const newStatus = status === 'active' ? 'inactive' : 'active'
    const result = await Swal.fire({
      title: `Confirm Product ${newStatus === 'active' ? 'Activate' : 'Deactivate'}`,
      text: `Are you sure you want to ${newStatus} this product?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus === 'active' ? 'Activate' : 'Deactivate'}`,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })
    if (!result.isConfirmed) return

    try {
      
      await toggleProductStatus({ product_id: productId, status: newStatus }).unwrap()
      setStatus(newStatus)
      Swal.fire('Success', `Product status updated to ${newStatus}!`, 'success')
    } catch (error) {
      console.error('Failed to update product status:', error)
      Swal.fire('Error', 'Failed to update product status.', 'error')
    }
  }

  function ToggleStatusButton({ status, onToggle }) {
    return (
      <Button
        variant={status === 'active' ? 'success' : 'secondary'}
        className="flex-fill d-flex align-items-center justify-content-center text-white"
        onClick={onToggle}
        style={{ minWidth: 'auto', padding: '0.3rem 0.6rem', fontSize: '0.75rem', height: '35px', borderRadius: '4px' }}
        title={status === 'active' ? 'Set Inactive' : 'Set Active'}>
        <Icon icon={status === 'active' ? 'mdi:check-circle' : 'mdi:close-circle'} width={18} className="me-2" />
        {status === 'active' ? 'Active' : 'Inactive'}
      </Button>
    )
  }

  // ===== Variants mapping (from API) =====
  const mappedVariants = useMemo(() => {
    const src = Array.isArray(productData?.variants) ? productData.variants : []
    return src.map((v) => ({
      id: v.variant_id,
      name: v.variant_value ? String(v.variant_value) : v.variant_type || 'Variant',
      weight: String(v.weight ?? 0),
      quantity: Number(v.new_quantity ?? 0),
      reorder: Number(v.reorder_level ?? 0),
      sku: v.sku || '',
      cost_per_item: fmtMoney(Number(v.cost_per_item ?? 0)),
    }))
  }, [productData?.variants])

  // Variant search (name, sku, id)
  const [variantSearch, setVariantSearch] = useState('')
  const filteredVariants = useMemo(() => {
    const raw = (variantSearch || '').trim()
    if (!raw) return mappedVariants
    const q = raw.toLowerCase()
    const isNumeric = /^\d+$/.test(raw)
    return mappedVariants.filter((v) => {
      const nameMatch = (v.name || '').toLowerCase().includes(q)
      const skuMatch = (v.sku || '').toLowerCase().includes(q)
      const idMatch = String(v.id).includes(raw)
      const idPrefixedMatch = q.startsWith('id:') && String(v.id).includes(q.slice(3))
      return nameMatch || skuMatch || idMatch || (isNumeric && idMatch) || idPrefixedMatch
    })
  }, [mappedVariants, variantSearch])

  // Total available quantity across all variants
  const totalVariantQty = useMemo(() => mappedVariants.reduce((sum, v) => sum + (Number(v.quantity) || 0), 0), [mappedVariants])

  // ===== Reviews mapping (from API) =====
  const [reviews, setReviews] = useState([])
  useEffect(() => {
    const list = Array.isArray(reviewsResp) ? reviewsResp : reviewsResp?.reviews || []
    const mapped = list.map((r) => ({
      id: r.review_id,
      name: r.customer_name,
      type: r.user_id ? 'Registered' : 'Guest',
      stars: parseFloat(r.review ?? 0),
      comment: r.comment || '',
      visible: r.status === 'active',
    }))
    setReviews(mapped)
  }, [reviewsResp])

  // Average rating from reviews
  const averageRating = reviews.length ? reviews.reduce((sum, r) => sum + (Number.isFinite(r.stars) ? r.stars : 0), 0) / reviews.length : 0

  // Paginate helper
  const paginate = (data, pageSize, page) => data.slice((page - 1) * pageSize, page * pageSize)

  // Product text fields
  const productTitle = productData?.title || ''
  const productStatus = productData?.status || status
  const productPrice = productData?.price

  const productDescriptionHtml = productData?.description ?? ''
  const webPreviewHref = productId
    ? `${CLIENT_BASE}/product/${slugify(productTitle || 'product')}-${productId}`
    : `${CLIENT_BASE}/product/${slugify(productTitle || 'product')}`
  // NEW: plain-text + 3-sentence version
  const productDescriptionText = htmlToText(productDescriptionHtml)
  const productDescriptionShort = firstNSentences(productDescriptionText, 3)

  const showLoading = isProductLoading || isProductFetching

  // Pagination math + guards
  const variantTotalPages = Math.ceil((filteredVariants.length || 0) / VARIANTS_PER_PAGE) || 1
  const reviewTotalPages = Math.ceil((reviews.length || 0) / REVIEWS_PER_PAGE) || 1

  useEffect(() => {
    if (variantPage > variantTotalPages) setVariantPage(variantTotalPages)
  }, [variantTotalPages, variantPage])

  useEffect(() => {
    if (reviewPage > reviewTotalPages) setReviewPage(reviewTotalPages)
  }, [reviewTotalPages, reviewPage])

  return (
    <div className="bg-light pt-2 px-4 pb-4 mt-0">
      <style>{`
     .line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}

      .thumbs-rail { overflow-y: hidden; } /* original behavior */
      .thumb-btn { border: 1px solid transparent; border-radius: .3rem; padding: 4px; cursor: pointer; background: #fff; }
      .thumb-btn.active, .thumb-btn:hover { border-color: #000000ff; }
      .thumb-img { width: 100%; aspect-ratio: 1/1; object-fit: cover; border-radius: .35rem; }

      /* original image behavior (no fixed gallery height) */
      .main-img { width: 100%; height: 100%; object-fit: contain; background: #fff; border-radius: .5rem; box-shadow: 0 2px 6px rgba(0,0,0,.25); }

      .stars-large { font-size: 1.6rem; line-height: 1; letter-spacing: .15rem; }
      .loading-wrap { position: relative; min-height: 260px; } /* original */
      .loading-overlay {
        position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
        background: rgba(255,255,255,.6); border-radius: .5rem;
      }
    `}</style>

      <Row className="mb-4">
        <Col md={12}>
          <Card className="shadow-sm">
            {/* Header: Product ID (muted) + Title + Status (left), Back (right) */}
            <Card.Header className="bg-white border-0 pb-0">
              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div className="d-flex align-items-center gap-3 flex-wrap">
                  <h4 className="fw-bold mb-0 d-flex align-items-center gap-2" style={{ lineHeight: 1.2 }}>
                    <span className="text-muted">#{productId} - </span>
                    <span>{productTitle || 'Product'}</span>
                  </h4>
                  <Badge bg={productStatus === 'inactive' ? 'secondary' : 'primary'} className="px-2 py-1">
                    {capitalize(productStatus || 'Active')}
                  </Badge>
                </div>

                <Button variant="outline-secondary" size="sm" className="d-flex align-items-center" onClick={() => router.back()}>
                  <Icon icon="mdi:arrow-left" width={18} className="me-1" />
                  Back
                </Button>
              </div>

              {/* smooth, subtle divider under the title section */}
              <hr className="w-100 my-2" style={{ borderTop: '1px solid rgba(0,0,0,.1)' }} />
            </Card.Header>

            {/* Body closer to title */}
            <Card.Body className="px-4 pt-2 pb-4">
              <div className="loading-wrap">
                {showLoading && (
                  <div className="loading-overlay">
                    <div className="spinner-border text-primary" role="status" aria-label="Loading" />
                  </div>
                )}

                <Row style={{ minHeight: '100%' }}>
                  {/* LEFT: Gallery */}
                  <Col md={6} className="d-flex">
                    <Row className="flex-grow-1 g-3">
                      {/* Thumbnails rail - 4 visible + up/down arrows */}
                      <Col xs={3} className="thumbs-rail d-flex flex-column gap-2">
                        {gallery.length > THUMBS_PAGE_SIZE && (
                          <button
                            type="button"
                            className="thumb-btn d-flex align-items-center justify-content-center"
                            onClick={pageUp}
                            title={canPageUp ? 'Previous images' : 'Go to last images'}
                            aria-label="Previous images">
                            <Icon icon="mdi:chevron-up" width={20} />
                          </button>
                        )}

                        {visibleThumbs.map((src, idx) => {
                          const globalIndex = thumbStart + idx
                          const isActive = activeImg === src
                          return (
                            <div
                              key={globalIndex}
                              className={`thumb-btn ${isActive ? 'active' : ''}`}
                              onClick={() => setActiveImg(src)}
                              title={`thumb-${globalIndex + 1}`}>
                              <img src={src} alt={`thumb-${globalIndex + 1}`} className="thumb-img" onError={handleImgError} />
                            </div>
                          )
                        })}

                        {gallery.length > THUMBS_PAGE_SIZE && (
                          <button
                            type="button"
                            className="thumb-btn d-flex align-items-center justify-content-center"
                            onClick={pageDown}
                            title={canPageDown ? 'More images' : 'Back to first images'}
                            aria-label="More images">
                            <Icon icon="mdi:chevron-down" width={20} />
                          </button>
                        )}
                      </Col>

                      {/* Main image (original dynamic sizing) */}
                      <Col xs={9} className="d-flex">
                        <div className="flex-grow-1">
                          <Image src={activeImg || FALLBACK_PLACEHOLDER} alt="product" className="main-img shadow-sm" onError={handleImgError} />
                        </div>
                      </Col>
                    </Row>
                  </Col>

                  {/* RIGHT: Details */}
                  <Col md={6} className="d-flex flex-column">
                    <div>
                      {/* Description (HTML from backend) */}
                      <div className="text-muted mt-1 line-clamp-3">{htmlToText(productDescriptionHtml) || <span />}</div>

                      {/* Show "See More.." if description exists */}
                      {productDescriptionHtml && (
                        <a href={webPreviewHref} target="_blank" rel="noopener noreferrer" className="d-inline-block mt-1" title="Open web preview">
                          See More..
                        </a>
                      )}

                      <div className="d-flex align-items-center mb-2">
                        <span className="text-warning me-2 stars-large">
                          <StarRating value={averageRating} />
                        </span>
                        <span className="text-muted small">
                          ({reviews.length} Review{reviews.length === 1 ? '' : 's'})
                        </span>
                      </div>

                      <h6 className="fw-semibold mb-1">
                        Available Quantity: <Badge bg="success">{totalVariantQty}</Badge>
                      </h6>

                      <h5 className="text-danger fw-bold mb-0">{fmtMoney(productPrice)}</h5>
                      {productData?.measurement_value && !!productData?.amount_per_unit && (
                        <>
                          <div className="mt-1 fw-semibold" style={{ fontSize: '0.8rem' }}>
                            {formatPerUnitLabel(productData.amount_per_unit, productData.measurement_value)}
                          </div>

                          {/* Smooth muted divider */}
                          <hr
                            className="mt-2 mb-0"
                            style={{
                              border: 'none',
                              borderTop: '1px solid rgba(0,0,0,0.12)',
                            }}
                          />
                        </>
                      )}

                      {/* Live stats */}
                      <div className="pt-2">
                        <h6 className="fw-semibold mb-2">Live Stats</h6>
                        <Row className="g-2">
                          {[
                            { label: 'Views', count: Number(productData?.view_count ?? 0), icon: 'mdi:eye-outline', color: 'text-info' },
                            { label: 'Purchases', count: Number(productData?.purchase_count ?? 0), icon: 'mdi:cart-outline', color: 'text-success' },
                            { label: 'Reviews', count: reviews.length, icon: 'mdi:star-outline', color: 'text-warning' },
                            // ✅ CHANGED THIS TO USE REAL DATA
                            { label: 'Returns', count: Number(productData?.returned_items_count ?? 0), icon: 'mdi:undo', color: 'text-danger' },
                          ].map((stat, i) => (
                            <Col xs={6} key={i}>
                              <div
                                className="border rounded d-flex align-items-center"
                                style={{
                                  minHeight: 90,
                                  padding: '1rem',
                                  backgroundColor: '#ffffff',
                                  boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
                                  transition: 'transform 0.15s ease, box-shadow 0.15s ease, background-color 0.15s ease, color 0.15s ease',
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = 'translateY(-1px)'
                                  e.currentTarget.style.boxShadow = '0 4px 10px rgba(0,0,0,0.2)'
                                  e.currentTarget.style.backgroundColor = '#343a40'
                                  e.currentTarget.style.color = '#ffffff'
                                  e.currentTarget.style.cursor = 'pointer'

                                  const iconWrap = e.currentTarget.querySelector('.stat-icon')
                                  if (iconWrap) iconWrap.style.backgroundColor = '#495057'

                                  const iconSvg = e.currentTarget.querySelector('.stat-icon *')
                                  if (iconSvg) {
                                    iconSvg.style.color = '#ffffff'
                                    iconSvg.style.fill = '#ffffff'
                                  }
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = 'translateY(0)'
                                  e.currentTarget.style.boxShadow = '0 2px 6px rgba(0,0,0,0.1)'
                                  e.currentTarget.style.backgroundColor = '#ffffff'
                                  e.currentTarget.style.color = '#000000'

                                  const iconWrap = e.currentTarget.querySelector('.stat-icon')
                                  if (iconWrap) iconWrap.style.backgroundColor = '#f8f9fa'

                                  const iconSvg = e.currentTarget.querySelector('.stat-icon *')
                                  if (iconSvg) {
                                    iconSvg.style.color = ''
                                    iconSvg.style.fill = ''
                                  }
                                }}>
                                <div
                                  className="d-flex justify-content-center align-items-center rounded-circle bg-light me-3 stat-icon"
                                  style={{
                                    width: 48,
                                    height: 48,
                                    transition: 'background-color 0.15s ease, transform 0.15s ease',
                                  }}>
                                  <Icon
                                    icon={stat.icon}
                                    width={28}
                                    className={stat.color}
                                    style={{ transition: 'color 0.15s ease, fill 0.15s ease' }}
                                  />
                                </div>
                                <div>
                                  <div className="fw-bold" style={{ fontSize: '1.25rem' }}>
                                    {stat.count}
                                  </div>
                                  <div className="fw-semibold" style={{ fontSize: '1rem' }}>
                                    {stat.label}
                                  </div>
                                </div>
                              </div>
                            </Col>
                          ))}
                        </Row>
                      </div>

                      {/* Actions */}
                      <div className="d-flex gap-2 mt-3 flex-nowrap">
                        <Button
                          as={Link}
                          href={webPreviewHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          disabled={!productId}
                          title={!productId ? 'Product ID not available yet' : 'Open web preview'}
                          style={{
                            backgroundColor: '#00A9B7',
                            borderColor: '#0095A3',
                            height: '35px',
                            borderRadius: '4px',
                            padding: '0.3rem 0.6rem',
                            fontSize: '0.75rem',
                          }}
                          className="flex-fill d-flex align-items-center justify-content-center text-white">
                          <Icon icon="ph:globe-bold" width={20} className="me-2" />
                          Web Preview
                        </Button>

                        <ToggleStatusButton status={status} onToggle={handleToggleStatus} />

                        <Button
                          variant="warning"
                          className="flex-fill d-flex align-items-center justify-content-center text-white"
                          onClick={() => router.push(`/products/update_product?product_id=${productId}`)}
                          style={{ minWidth: 'auto', padding: '0.3rem 0.6rem', fontSize: '0.75rem', height: '35px', borderRadius: '4px' }}>
                          <Icon icon="mdi:pencil" width={18} className="me-2" />
                          Edit
                        </Button>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Variants */}
      <Card className="mb-4">
        <Card.Body>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <Card.Title className="fw-bold text-dark mb-0">Variants</Card.Title>
            <div className="d-flex">
              <input
                type="text"
                placeholder="Search variants by Name,ID..."
                className="form-control form-control-sm me-2"
                style={{ width: '200px' }}
                onChange={(e) => {
                  setVariantSearch(e.target.value)
                  setVariantPage(1)
                }}
              />
              <Button variant="primary" size="sm" onClick={() => {}}>
                <Icon icon="mdi:magnify" width={18} className="me-1" />
                Search
              </Button>
            </div>
          </div>

          <Table size="sm" striped bordered hover>
            <thead className="table-dark text-center">
              <tr>
                <th>Variant ID</th>
                <th>Name</th>
                <th>Weight</th>
                <th>Current Quantity</th>
                <th>Re-Order Level</th>
                <th>SKU</th>
                <th>Cost Per Item</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {paginate(filteredVariants, VARIANTS_PER_PAGE, variantPage).map((v) => (
                <tr key={v.id} style={{ height: '25px' }}>
                  <td>{v.id}</td>
                  <td>{v.name}</td>
                  <td>{v.weight}</td>
                  <td>{v.quantity}</td>
                  <td>{v.reorder}</td>
                  <td>{v.sku}</td>
                  <td>{v.cost_per_item}</td>
                </tr>
              ))}
            </tbody>
          </Table>

          {variantTotalPages > 1 && (
            <div className="d-flex justify-content-end">
              <Pagination>
                {Array.from({ length: variantTotalPages }).map((_, i) => (
                  <Pagination.Item key={i} active={i + 1 === variantPage} onClick={() => setVariantPage(i + 1)}>
                    {i + 1}
                  </Pagination.Item>
                ))}
              </Pagination>
            </div>
          )}
        </Card.Body>
      </Card>

      {/* Reviews */}
      <Card>
        <Card.Body>
          <Card.Title className="fw-bold text-dark">Reviews</Card.Title>
          <Table size="sm" striped bordered hover>
            <thead className="table-dark text-center">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Type</th>
                <th>Review</th>
                <th>Comment</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {reviews.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-muted py-3">
                    No reviews found for this product.
                  </td>
                </tr>
              ) : (
                paginate(reviews, REVIEWS_PER_PAGE, reviewPage).map((r) => (
                  <tr key={r.id} style={{ height: '25px' }}>
                    <td>{r.id}</td>
                    <td>{r.name}</td>
                    <td>{r.type}</td>
                    <td>
                      {Array.from({ length: Math.floor(r.stars) }).map((_, i) => (
                        <Icon key={`full-${i}`} icon="mdi:star" color="#ffc107" width={18} height={18} />
                      ))}
                      {r.stars % 1 >= 0.5 && <Icon icon="mdi:star-half-full" color="#ffc107" width={18} height={18} />}
                      {Array.from({ length: 5 - Math.ceil(r.stars) }).map((_, i) => (
                        <Icon key={`empty-${i}`} icon="mdi:star-outline" color="#ffc107" width={18} height={18} />
                      ))}
                      <span className="ms-1 text-muted small">({r.stars.toFixed(1)})</span>
                    </td>
                    <td>{r.comment}</td>
                  </tr>
                ))
              )}
            </tbody>
          </Table>

          {reviewTotalPages > 1 && (
            <div className="d-flex justify-content-end">
              <Pagination>
                {Array.from({ length: reviewTotalPages }).map((_, i) => (
                  <Pagination.Item key={i} active={i + 1 === reviewPage} onClick={() => setReviewPage(i + 1)}>
                    {i + 1}
                  </Pagination.Item>
                ))}
              </Pagination>
            </div>
          )}
        </Card.Body>
      </Card>
    </div>
  )
}

export default ProductView
