import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Product View',
}

const ProductView = dynamic(() => import('./ProductView'), { ssr: false })

export default function AddProductPage() {
  return <ProductView />
}