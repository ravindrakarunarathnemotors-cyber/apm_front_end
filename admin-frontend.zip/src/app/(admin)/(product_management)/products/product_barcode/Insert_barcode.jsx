'use client'

import React, { useEffect, useState, useRef } from 'react'
import { Form, FormLabel, InputGroup } from 'react-bootstrap'
import { useCheckProductBarcodeMutation } from '@/store/features/apiSlice'

export default function BarcodeInput({ value = '', onChange, errors = {}, maxLength = 30, debounceMs = 500 }) {
  const [barcode, setBarcode] = useState(value)
  const [localError, setLocalError] = useState('')
  const [isValid, setIsValid] = useState(false)
  const isUserEditingRef = useRef(false)

  const [checkBarcode] = useCheckProductBarcodeMutation()

  const debounceTimerRef = useRef(null)
  const lastCheckedRef = useRef('')
  const initialBarcodeRef = useRef('') // ✅ NEW (important)

  // keep in sync with parent + capture prefill ONCE
  useEffect(() => {
    // ❌ do NOT overwrite while user is editing
    if (isUserEditingRef.current) {
      isUserEditingRef.current = false
      return
    }

    const next = value || ''
    setBarcode(next)

    // capture prefill ONCE
    if (!initialBarcodeRef.current && next) {
      const trimmed = next.trim()
      initialBarcodeRef.current = trimmed
      lastCheckedRef.current = trimmed
    }

    // reset refs if parent truly cleared it
    if (!next) {
      initialBarcodeRef.current = ''
      lastCheckedRef.current = ''
    }
  }, [value])

  // 🔁 debounce + validate
  useEffect(() => {
    const val = barcode?.trim()

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    setIsValid(false)

    // skip empty
    if (!val) {
      setLocalError('')
      setIsValid(false)
      lastCheckedRef.current = '' // 🧼 reset cache
      return
    }

    // ✅ CRITICAL RULE:
    // do NOT validate if value === prefilled value
    if (val === initialBarcodeRef.current) {
      setLocalError('')
      return
    }

    // skip duplicate API call
    if (val === lastCheckedRef.current) return

    debounceTimerRef.current = setTimeout(async () => {
      try {
        lastCheckedRef.current = val
        const res = await checkBarcode(val).unwrap()

        if (res?.exists) {
          setLocalError('This barcode already exists.')
          setIsValid(false)
        } else {
          setLocalError('')
          setIsValid(true)
        }
      } catch {
        setLocalError('Failed to validate barcode.')
        setIsValid(false)
      }
    }, debounceMs)

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current)
      }
    }
  }, [barcode, debounceMs, checkBarcode])

  const handleChange = (e) => {
    const val = e.target.value
    if (val.length <= maxLength) {
      isUserEditingRef.current = true // 🔐 mark as user-driven
      setBarcode(val)
      setLocalError('')
      setIsValid(false)
      onChange?.(val)
    }
  }

  return (
    <Form.Group className="mb-1">
      <FormLabel className="col-form-label text-start">Barcode</FormLabel>

      <InputGroup>
        <Form.Control
          type="text"
          name="barcode"
          placeholder={`Enter barcode (max ${maxLength} characters)`}
          value={barcode}
          onChange={handleChange}
          maxLength={maxLength}
          isInvalid={!!localError || !!errors.barcode}
          isValid={isValid}
        />
      </InputGroup>

      <div className="d-flex justify-content-between">
        <Form.Text className="text-danger">{localError || errors.barcode?.message}</Form.Text>

        <Form.Text muted>
          {barcode.length}/{maxLength}
        </Form.Text>
      </div>

      {/* ✅ Bootstrap validation icon override */}
      <style jsx global>{`
        .form-control.is-valid {
          background-size: 0.85rem 0.85rem;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23198754' d='M6.564.75L3.59 4.63 1.564 2.75.75 3.564l2.5 2.5.686.686.686-.686 3.5-3.5z'/%3E%3C/svg%3E");
        }
      `}</style>
    </Form.Group>
  )
}
