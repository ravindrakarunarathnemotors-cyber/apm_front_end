'use client'

import { useSearchParams } from 'next/navigation'
import { Spinner, Button, Col, Form, FormControl, FormLabel, FormCheck, FormSelect, Row, Modal, FormGroup } from 'react-bootstrap'
import AsyncCreatableSelect from 'react-select/async-creatable'
import { Icon } from '@iconify/react'
import { OverlayTrigger, Tooltip } from 'react-bootstrap'
import InsertKeywords from '@/app/(admin)/(product_management)/products/product_keywords/insert_keywords'

import {
  useGetProductByIdQuery,
  useGetCategoryLineageByProductQuery,
  useGetCategoriesQuery,
  useUpdateProductWithRelationsMutation,
  useLazySearchTagsQuery,
  useGetCollectionsQuery,
  useCreateTagMutation,
  useGetActiveTagsByProductQuery,
  useGetCollectionsByProductQuery,
  useGetProductBrandsMutation,
  useGetDiscountCurrencyQuery,
} from '@/store/features/apiSlice'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useState, useEffect } from 'react'
import Swal from 'sweetalert2'
import dynamic from 'next/dynamic'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import CreatableSelect from 'react-select/creatable'
import Select from 'react-select'
import { Badge } from 'react-bootstrap'
import { useRouter } from 'next/navigation'
import CustomQuill from '@/components/CustomQuill'
import BrandSelector from '@/app/(admin)/(product_management)/products/brand_selector/BrandSelector' // adjust path to where you saved it
import BarcodeInput from '@/app/(admin)/(product_management)/products/product_barcode/Insert_barcode'

const VariantUploaderModal = dynamic(() => import('@/app/(admin)/media_uploader/VariantUploaderModal'), {
  ssr: false,
})
const MeasurementSelector = dynamic(() => import('@/app/(admin)/(product_management)/products/measurement_selector/MeasurementSelector'), {
  ssr: false,
  loading: () => <p>Loading Measurement...</p>,
})

const ReactQuill = dynamic(() => import('react-quill'), { ssr: false })
const VariantSelectorCardUpdate = dynamic(() => import('@/components/ProductManagement/Variants/VariantSelectorCardUpdate'), { ssr: false })
const MediaUploader = dynamic(() => import('@/app/(admin)/media_uploader/MediaUploader'), { ssr: false })

import 'react-quill/dist/quill.snow.css'

const schema = yup.object({
  title: yup.string().required('Title is required'),
  category: yup.string(),
  price: yup
    .string()
    .required('Price is required')
    .test('price-positive', 'Price must be greater than 0', (value) => parseFloat(value?.replace(/[^0-9.]/g, '')) > 0),
  comparePrice: yup.string(),
  cost: yup
    .string()
    .required('Cost is required')
    .test('cost-positive', 'Cost must be greater than 0', (value) => parseFloat(value?.replace(/[^0-9.]/g, '')) > 0),
  profit: yup
    .string()
    .required('Profit is required')
    .test('profit-positive', 'Profit must be 0 or more', (value) => parseFloat(value?.replace(/[^0-9.-]/g, '')) >= 0),
  margin: yup
    .string()
    .required('Margin is required')
    .test('margin-valid', 'Margin must be a valid number', (value) => {
      const num = parseFloat(value?.replace(/[^0-9.-]/g, ''))
      return !isNaN(num)
    }),
  tax: yup.boolean(),
  status: yup.number().oneOf([0, 1]).required('Status is required'),
  online: yup.boolean(),
  pos: yup.boolean(),
  type: yup.string(),
})

// ─── Tag helpers ───────────────────────────────────────────────────────────────
const toKey = (s) => (s ?? '').trim().toLowerCase()

const asExistingTag = (tag) => {
  // Accepts shapes like { name, tag_id } OR { label, value } OR { id }
  const label = tag?.name ?? tag?.label ?? ''
  const rawId = tag?.tag_id ?? tag?.id ?? tag?.value
  return {
    label,
    value: rawId != null ? Number(rawId) : null, // id
    source: 'existing',
  }
}

const asNewTag = (name) => ({
  label: name,
  value: null,
  source: 'new',
  __isNew__: true, // react-select hint
})
// ── MEDIA (PRODUCT-ONLY) HELPERS ──────────────────────────────────────────────

// Read the freshest media from sessionStorage (your modal writes here)
const getMediaFromSession = (productId) => {
  const raw = (productId && sessionStorage.getItem(`product_media_${productId}`)) || sessionStorage.getItem('media_staging')
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

// Build ONLY the product-level media payload (ignore variant media completely)
const toProductOnlyMedia = (input) => {
  // If MediaUploader already gave structured shape { product_main, product_sub, ... }
  // we’ll just use its product parts and ignore variant_media entirely.
  if (input && typeof input === 'object' && !Array.isArray(input)) {
    const { product_main = [], product_sub = [] } = input
    // Enforce a single main at index 0; the rest are subs with increasing sort_order
    const merged = [...product_main, ...product_sub].filter((m) => m?.status !== 'inactive' && m?.variant_id == null)
    if (merged.length === 0) return { product_main: [], product_sub: [] }

    // If any already has main:true, keep the first such item as main; else first is main
    let mainIdx = merged.findIndex((m) => m?.main === true)
    if (mainIdx === -1) mainIdx = 0

    const mainItem = { ...merged[mainIdx], main: true, sort_order: 0 }
    const subs = merged.filter((_, i) => i !== mainIdx).map((m, i) => ({ ...m, main: false, sort_order: i + 1 }))

    return { product_main: [mainItem], product_sub: subs }
  }

  // If we’re given a flat list (common in sessionStorage on older flows)
  const list = Array.isArray(input) ? input : []
  const activeProduct = list.filter((m) => m?.status !== 'inactive' && m?.variant_id == null)
  if (activeProduct.length === 0) return { product_main: [], product_sub: [] }

  let mainIdx = activeProduct.findIndex((m) => m?.main === true)
  if (mainIdx === -1) mainIdx = 0

  const mainItem = { ...activeProduct[mainIdx], main: true, sort_order: 0 }
  const subs = activeProduct.filter((_, i) => i !== mainIdx).map((m, i) => ({ ...m, main: false, sort_order: i + 1 }))

  return { product_main: [mainItem], product_sub: subs }
}

const UpdateProduct = () => {
  const { data: currencyData } = useGetDiscountCurrencyQuery()

  // RTK may return "USD" or { currency: "USD" }
  const currencySymbol = typeof currencyData === 'string' ? currencyData : currencyData?.currency || ''

  const searchParams = useSearchParams()
  const productId = searchParams.get('product_id')
  const [selectedTags, setSelectedTags] = useState([])
  const [selectedCollections, setSelectedCollections] = useState([])
  const [calculatedProfit, setCalculatedProfit] = useState('0.00')
  const [calculatedMargin, setCalculatedMargin] = useState('0.00')
  const [measurementId, setMeasurementId] = useState(null)
  const [showVariantModal, setShowVariantModal] = useState(false)
  const [activeVariantKey, setActiveVariantKey] = useState(null)
  const [mediaPayload, setMediaPayload] = useState({
    product_main: [],
    product_sub: [],
    variant_media: {},
  })
  const [showModal, setShowModal] = useState(false)
  const [selectedMain, setSelectedMain] = useState(null)
  const [selectedSub, setSelectedSub] = useState(null)
  const [showCategoryUpdate, setShowCategoryUpdate] = useState(false)
  const [searchEngineTitle, setSearchEngineTitle] = useState('')
  const [searchEngineDesc, setSearchEngineDesc] = useState('')
  const [publishToWeb, setPublishToWeb] = useState(false)

  const [description, setDescription] = useState('')
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [pendingSubmitData, setPendingSubmitData] = useState(null)
  const [customVariants, setCustomVariants] = useState([])
  const [initialVariants, setInitialVariants] = useState([])
  const [similarKeywords, setSimilarKeywords] = useState([])
  const [continueSelling, setContinueSelling] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  // measurement unit amout

  // Add next to measurementId/other state
  const [amountPerUnit, setAmountPerUnit] = useState('') // keep it as string to match input
  const [measurementShow, setMeasurementShow] = useState(true) // true = non-pcs (show variants by your logic)

  // track the raw unit string (from MeasurementSelector) and normalized token
  const [selectedMeasurementUnit, setSelectedMeasurementUnit] = useState('')

  // helper: normalize unit to canonical token
  const normalizeUnit = (raw) => {
    if (!raw) return ''
    const v = String(raw).trim().toLowerCase()
    if (['kgs', 'kg', 'kilogram', 'kilograms'].includes(v)) return 'kg'
    if (['g', 'gram', 'grams', 'gms'].includes(v)) return 'g'
    if (['l', 'liter', 'litre', 'liters', 'litres', 'ltr'].includes(v)) return 'l'
    if (['ml', 'milliliter', 'millilitre', 'milliliters', 'millilitres'].includes(v)) return 'ml'
    if (['pcs', 'pc', 'piece', 'pieces'].includes(v)) return 'pc'
    return v.endsWith('s') ? v.slice(0, -1) : v
  }

  const [searchTags] = useLazySearchTagsQuery()
  const { data: collections = [] } = useGetCollectionsQuery()
  const { data: existingCollectionsData } = useGetCollectionsByProductQuery(productId, { skip: !productId })
  const { data, isLoading, isError, error } = useGetProductByIdQuery(productId, { skip: !productId })
  const { product: productData } = data || {}
  const defaultVariantBarcode = productData?.variants?.find((v) => v.variant_type === 'Default' && v.variant_value === 'Default')?.barcode || ''

  const media = data?.media || {}
  const productMain = Array.isArray(media.product_main) ? media.product_main : media.product_main ? [media.product_main] : []
  const productSub = Array.isArray(media.product_sub) ? media.product_sub : []
  const variantMedia = typeof media.variant_media === 'object' && media.variant_media !== null ? media.variant_media : {}
  const { data: lineageData } = useGetCategoryLineageByProductQuery(productId, { skip: !productId })
  const { data: categoryList = [], isLoading: isCategoryLoading } = useGetCategoriesQuery()
  const [updateProductWithRelations, { isLoading: isUpdating }] = useUpdateProductWithRelationsMutation()
  const { data: activeTagsData, isLoading: isTagsLoading } = useGetActiveTagsByProductQuery(productId, { skip: !productId })
  const [createTag] = useCreateTagMutation()
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
    control,
    getValues,
    clearErrors,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
    defaultValues: {},
  })

  const parseMoney = (val) =>
    parseFloat(
      val
        ?.toString()
        .replace(/^Rs\.\s*/i, '') // backward compatibility
        .replace(new RegExp(`\\s*${currencySymbol}$`, 'i'), '')
        .replace(/,/g, '')
        .trim(),
    ) || 0

  const costPrice = parseMoney(watch('cost'))
  const sellingPrice = parseMoney(watch('price'))

  const handleFinalVariants = (finalVariants) => {
    setCustomVariants(finalVariants)
  }

  const normalizeKey = (value) => value.replace(/\s*\/\s*/g, '_').trim()

  useEffect(() => {
    if (productData) {
      setPublishToWeb(Boolean(productData.publish_to_web))
      setContinueSelling(
        productData.continue_selling !== undefined ? Boolean(productData.continue_selling) : true, // default fallback
      )
    }
  }, [productData])

  useEffect(() => {
    if (!productData || !variantMedia) return

    reset({
      title: productData.title || '',
      category: productData.category || '',
      price: productData.price ? `${parseFloat(productData.price).toFixed(2)} ${currencySymbol}` : '',

      comparePrice: productData.compare_at_price ? `${parseFloat(productData.compare_at_price).toFixed(2)} ${currencySymbol}` : '',

      tax: productData.charge_tax_on_product || false,
      cost: productData.cost_per_item ? `${parseFloat(productData.cost_per_item).toFixed(2)} ${currencySymbol}` : '',

      profit: productData.profit || '0.00',
      margin: productData.margin || '0.00',
      status: productData?.status === 'inactive' ? 0 : 1,

      online: productData.publishing_online || false,
      pos: productData.publishing_pos || false,
      type: productData.type || '',
      tags: productData.tags || '',
      brand_id: productData?.brand_id ?? '',
      barcode: defaultVariantBarcode,
    })

    // ✅ map product.default_weight into the input field shown to the user
    setValue(
      'weight_per_item',
      productData?.default_weight !== undefined && productData?.default_weight !== null
        ? String(productData.default_weight) // keeps "2.50" formatting
        : '',
    )

    setMeasurementId(productData?.measurement_id ?? null)
    setAmountPerUnit(productData?.amount_per_unit != null ? String(productData.amount_per_unit) : '')

    const rawVariants = productData.variants || []
    const normalizedVariants = rawVariants.map((v) => {
      const types = v.variant_type?.split(' / ') || []
      const values = v.variant_value?.split(' / ') || []
      const option_values = types.map((type, idx) => ({
        option_name: type.trim(),
        value: values[idx]?.trim() || '',
      }))
      const variantKey = normalizeKey(v.variant_value)
      const mediaUrl = variantMedia[v.variant_id]?.main?.media_url || v.media_url || null
      const storedImage = typeof window !== 'undefined' ? sessionStorage.getItem(`variant_image_${variantKey}`) : null

      return {
        variant_type: v.variant_type || '',
        variant_value: v.variant_value || '',
        option_values,
        sku: v.sku || '',
        barcode: v.barcode || '',
        price: parseFloat(v.price) || 0,
        cost: parseFloat(v.cost_per_item || v.cost) || 0,
        inventory_quantity: v.inventory_quantity || 0,
        track_quantity: v.track_quantity || false,
        is_physical_product: v.is_physical_product || false,
        weight: parseFloat(v.weight) || 0,
        weight_unit: v.weight_unit || null,
        continue_selling_oos: v.continue_selling_oos || false,
        shop_location_selling: v.shop_location_selling || '',
        customs_info: v.customs_info || '',
        variant_id: v.variant_id,
        variant_key: variantKey,
        media_url: storedImage || mediaUrl,
      }
    })

    console.log('🟨 normalizedVariants:', normalizedVariants)
    console.log('🟨 variantMedia:', variantMedia)
    setInitialVariants(normalizedVariants)
    setCustomVariants(normalizedVariants)
    setDescription(productData.description || '')
    setSearchEngineTitle(productData.search_engine_title || '')
    setSearchEngineDesc(productData.search_engine_desc || '')
    // ✅ Prefill Similar Keywords
    if (Array.isArray(productData?.similar_keywords)) {
      setSimilarKeywords(
        productData.similar_keywords.map((k) => ({
          label: k,
          value: k.toLowerCase(),
        })),
      )
    }
  }, [productData, variantMedia, reset])

  // Normalize + apply existing collections to the multi-select safely
  useEffect(() => {
    // Normalize shapes: could be array or object with `.collections`
    const existingList = Array.isArray(existingCollectionsData) ? existingCollectionsData : (existingCollectionsData?.collections ?? [])

    if (!Array.isArray(existingList) || existingList.length === 0) return
    if (!Array.isArray(collections) || collections.length === 0) return

    // If the user already has selected something, don't overwrite their choice.
    // Use length check to avoid overwriting after user interaction.
    if (selectedCollections && selectedCollections.length > 0) return

    const mapped = existingList.map((item) => {
      // item might have shape { collection_id, name } or just { collection_id }
      const itemId = Number(item.collection_id ?? item.value ?? item.collectionId)
      const match = collections.find((c) => Number(c.collection_id) === itemId)
      return {
        label: match?.name ?? item.name ?? `Collection ${itemId}`,
        value: itemId,
      }
    })

    // update local state shown in Select
    setSelectedCollections(mapped)

    // keep react-hook-form controller in sync
    // This ensures the Controller's internal value matches selectedCollections.
    try {
      setValue('collections', mapped, { shouldDirty: false, shouldTouch: false })
    } catch (e) {
      // setValue should exist from useForm; swallow any unexpected errors to avoid breaking UI
      console.warn('setValue collections failed', e)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existingCollectionsData, collections, /* intentionally exclude whole selectedCollections object */ selectedCollections?.length, setValue])

  useEffect(() => {
    console.log('collections (select options):', collections)
    console.log('existingCollectionsData:', existingCollectionsData)
    console.log('selectedCollections (value):', selectedCollections)
  }, [collections, existingCollectionsData, selectedCollections])

  // keep form field 'measurement_id' in sync with local measurementId state
  useEffect(() => {
    setValue('measurement_id', measurementId ?? '')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [measurementId])

  // hide/clear default weight when selected unit is grams or kilograms
  useEffect(() => {
    const norm = normalizeUnit(selectedMeasurementUnit)
    const hideFor = new Set(['g', 'kg'])
    if (hideFor.has(norm)) {
      // clear the form value & any validation errors so stale data isn't submitted
      setValue('weight_per_item', '')
      if (typeof clearErrors === 'function') {
        // If you don't have clearErrors from useForm, it's safe to omit
        try {
          clearErrors('weight_per_item')
        } catch (e) {}
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMeasurementUnit, setValue])

  useEffect(() => {
    if (activeTagsData?.tags && selectedTags.length === 0) {
      setSelectedTags(activeTagsData.tags.map(asExistingTag)) // mark fetched as existing
    }
  }, [activeTagsData, selectedTags.length])

  console.log('🟨 variant_media from API:', mediaPayload.variant_media)

  const transformVariantsForBackend = (variants) => {
    return variants.map((variant) => ({
      variant_id: variant.variant_id || null,
      variant_type: variant.option_values.map((opt) => opt.option_name).join('/'),
      variant_value: variant.option_values.map((opt) => opt.value).join('/'),
      cost: parseFloat(variant.cost) || 0,
      price: parseFloat(variant.price) || 0,
      inventory_quantity: variant.inventory_quantity || 0,
      track_quantity: variant.track_quantity || false,
      is_physical_product: variant.is_physical_product || false,
      weight: parseFloat(variant.weight) || 0,
      weight_unit: variant.weight_unit || null,
      continue_selling_oos: variant.continue_selling_oos || false,
      shop_location_selling: variant.shop_location_selling || null,
      customs_info: variant.customs_info || null,
      sku: variant.sku || null,
      variant_barcode: typeof variant.variant_barcode === 'string' && variant.variant_barcode.trim() ? variant.variant_barcode.trim() : null,
      media_url: variant.media_url || null,
    }))
  }
  const statusValue = watch('status')

  const onSubmit = (data) => {
    // ensure measurement selected
    if (!measurementId) {
      // set an error on the registered field so MeasurementSelector shows it
      // setValue already kept measurement_id in sync; use form-level error if available
      try {
        // set error if using react-hook-form's setError (if available)
        setError && setError('measurement_id', { type: 'required', message: 'Please select a measurement unit' })
      } catch (e) {}
      // focus scroll to measurement selector
      const el = document.querySelector('[name="measurement_id"], select')
      if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      return
    }

    // proceed as before
    setPendingSubmitData(data)
    setShowConfirmModal(true)
  }

  const handleConfirmedSubmit = async () => {
    if (isSubmitting) return
    setIsSubmitting(true)

    const { weight_per_item, barcode, ...restData } = pendingSubmitData || {}

    const data = pendingSubmitData

    // pull Default Weight (KG) from the form
    // pull Default Weight (KG) from the form
    const rawWeightInput = (() => {
      const s = (weight_per_item ?? '').toString().trim()
      return s === '' ? 0 : parseFloat(s)
    })()

    // number only for variant fallback calc; variants remain unchanged otherwise
    const defaultWeightNum = parseFloat(rawWeightInput || '0') || 0

    // ---- build normalized variantsPayload depending on measurementShow ----
    const defaultVariant = {
      variant_id: null,
      variant_type: 'Default',
      variant_value: 'Default',
      cost: parseMoney(data.cost),
      price: parseMoney(data.price),
      weight: defaultWeightNum,
      inventory_quantity: 0,
      track_quantity: false,
      is_physical_product: true,
      weight_unit: null,
      continue_selling_oos: false,
      shop_location_selling: null,
      customs_info: null,
      sku: null,
      barcode: null,
      media_url: null,
    }

    // If measurementShow is false -> ALWAYS send a single Default variant
    // If measurementShow is true -> send customVariants if present, otherwise send Default
    let variantsPayload = []

    if (!measurementShow) {
      // measurement disables variants (e.g., pcs/g/kg), but backend still expects a default variant object
      variantsPayload = [defaultVariant]
    } else {
      // measurement allows variants: include user-created variants if any, else default
      variantsPayload = customVariants && customVariants.length > 0 ? transformVariantsForBackend(customVariants) : [defaultVariant]
    }

    // split tags for backend "replace" semantics
    const tag_ids = selectedTags.filter((t) => t.source === 'existing' && t.value != null).map((t) => Number(t.value))

    const new_tags = selectedTags
      .filter((t) => t.source === 'new')
      .map((t) => t.label.trim())
      .filter(Boolean)

    // optional: labels for compatibility / display
    const tags_labels = selectedTags.map((t) => t.label.trim()).filter(Boolean)

    // Prefer the in-memory mediaPayload first; if empty, fall back to sessionStorage.
    const latestMediaStored = getMediaFromSession(productId)

    // Build product-only media (ignore variant images)
    const productOnlyMedia = toProductOnlyMedia(
      mediaPayload && (mediaPayload.product_main?.length || mediaPayload.product_sub?.length || (Array.isArray(mediaPayload) && mediaPayload.length)) // supports flat-list fallback
        ? mediaPayload
        : latestMediaStored,
    )

    // FINAL PAYLOAD (media => only product_main & product_sub)
    const payload = {
      ...restData,
      description,
      price: parseMoney(data.price),
      status: data.status === 1 ? 'active' : 'inactive',
      compare_at_price: parseMoney(data.comparePrice),
      cost_per_item: parseMoney(data.cost),
      profit: parseMoney(data.profit),
      margin: parseMoney(data.margin),
      search_engine_title: searchEngineTitle,
      search_engine_desc: searchEngineDesc,
      variants: variantsPayload, // keep variants as is
      measurement_id: measurementId,
      amount_per_unit: amountPerUnit !== '' ? parseFloat(amountPerUnit) : null,
      default_barcode: data.barcode || null,

      collections: selectedCollections.map((c) => c.value),
      default_weight: rawWeightInput,
      publish_to_web: publishToWeb,
      continue_selling: continueSelling,

      tag_ids,
      new_tags,
      tags: tags_labels,
      similar_keywords: similarKeywords.map((k) => k.label),

      //  Send ONLY product-level images:
      media: productOnlyMedia, // { product_main: [..one..], product_sub: [..many..] }
    }

    try {
      await updateProductWithRelations({ product_id: productId, data: payload }).unwrap()
      Swal.fire({ icon: 'success', title: 'Updated successfully', timer: 1500, showConfirmButton: false })
      reset()
      setShowConfirmModal(false)
      router.push('/products')
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Update failed',
        text: err?.data?.message || err.message || 'Something went wrong.',
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const watchedValues = watch(['cost', 'price', 'profit', 'margin'])

  useEffect(() => {
    const activeField = document.activeElement?.name
    const [costRaw, priceRaw, profitRaw, marginRaw] = watchedValues

    const cost = parseMoney(costRaw)
    const price = parseMoney(priceRaw)
    const profit = parseMoney(profitRaw)
    const margin = parseFloat(marginRaw)

    if (!cost || isNaN(cost)) return

    // CASE 1: user edits selling price
    if (activeField === 'price' && price > 0) {
      const newProfit = price - cost
      const newMargin = cost !== 0 ? ((newProfit / cost) * 100).toFixed(2) : '0.00'

      setValue('profit', newProfit.toFixed(2))
      setValue('margin', newMargin)
    }

    // CASE 2: user edits profit
    else if (activeField === 'profit' && profit >= 0) {
      const newPrice = cost + profit
      const newMargin = cost !== 0 ? ((profit / cost) * 100).toFixed(2) : '0.00'

      setValue('price', `${newPrice.toFixed(2)} ${currencySymbol}`)
      setValue('margin', newMargin)
    }

    // CASE 3: user edits margin
    else if (activeField === 'margin' && margin >= 0) {
      const newProfit = cost * (margin / 100)
      const newPrice = cost + newProfit

      setValue('profit', `${newProfit.toFixed(2)} ${currencySymbol}`)
      setValue('price', `${newPrice.toFixed(2)} ${currencySymbol}`)
    }
  }, [watchedValues, setValue, currencySymbol])

  if (isLoading) return <Spinner animation="border" className="m-3" />
  if (isError) return <p className="text-danger">Error: {error?.data?.error || 'Product not found'}</p>

  const getSubCategories = (parentId) => categoryList.filter((cat) => cat.category_under === parentId)
  const mainCategories = categoryList.filter((cat) => cat.category_under === null || cat.category_under === 0)

  const defaultSlug = (productData?.title || '')
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w\-]+/g, '')
    .replace(/\-\-+/g, '-')

  return (
    <>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <Row className="justify-content-center">
          <Col sm="10">
            <ComponentContainerCard title={`Update Product #${productId}`}>
              <FormLabel className="mt-3">Title</FormLabel>
              <FormControl {...register('title')} placeholder="Product Title" />
              <p className="text-danger">{errors.title?.message}</p>

              <Row className="mb-1">
                <Col md="12">
                  <FormLabel className="col-sm-4 col-form-label text-start">Description</FormLabel>
                  <Col>
                    <CustomQuill value={description} setValue={setDescription} />
                  </Col>
                </Col>
              </Row>

              {/* Card Title */}
              <div
                style={{
                  fontSize: '16px',
                  fontWeight: 600,
                  color: '#212529',
                  marginBottom: '6px',
                  marginTop: '25px',
                }}>
                Media Uploader
              </div>

              {/* Smooth divider */}
              <hr
                style={{
                  margin: '6px 0 18px',
                  borderColor: '#e9ecef',
                  opacity: 1,
                }}
              />
              <MediaUploader productId={productId} showModal={showModal} setShowModal={setShowModal} onMediaChange={setMediaPayload} />

              {(mediaPayload.product_main?.length > 0 || mediaPayload.product_sub?.length > 0) && (
                <>
                  <div className="d-flex flex-wrap gap-2">
                    {(mediaPayload.product_main || []).map((img, idx) => (
                      <div key={`main-${idx}`} className="border rounded p-1 text-center">
                        <small className="d-block text-primary">Main</small>
                        <img src={img.media_url} alt="Main" style={{ width: 100, height: 100, objectFit: 'contain' }} />
                      </div>
                    ))}

                    {(mediaPayload.product_sub || []).map((img, idx) => (
                      <div key={`sub-${idx}`} className="border rounded p-1 text-center">
                        <small className="d-block text-secondary">Sub</small>
                        <img src={img.media_url} alt={`Sub ${idx}`} style={{ width: 100, height: 100, objectFit: 'contain' }} />
                      </div>
                    ))}
                  </div>
                </>
              )}

              {/* ─────────── Row 1: Barcode + Brand ─────────── */}
              <Row className="mb-3 align-items-start">
                <Col md="4">
                  <BarcodeInput
                    value={watch('barcode') || defaultVariantBarcode}
                    maxLength={20}
                    onChange={(val) => {
                      setValue('barcode', val, { shouldDirty: true })
                      clearErrors('barcode')
                    }}
                    errors={errors}
                  />
                </Col>

                <Col md="4">
                  <BrandSelector
                    productId={productId}
                    initialBrandId={productData?.brand_id ?? null}
                    value={watch('brand_id') ?? null}
                    errors={errors}
                    onSelectBrand={(id) => setValue('brand_id', id, { shouldDirty: true })}
                  />
                </Col>

                {/* ✅ NEW: Similar Keywords (same width as Barcode) */}
                <Col md="4">
                  <InsertKeywords value={similarKeywords} onChange={setSimilarKeywords} />
                </Col>
              </Row>

              {/* ─────────── Row 2: Measurement + Default Weight ─────────── */}
              <Row className="mb-3 align-items-start">
                {/* Measurement Unit */}
                <Col md="4">
                  <MeasurementSelector
                    initialMeasurementId={productData?.measurement_id}
                    initialAmountPerUnit={amountPerUnit}
                    onSelectMeasurement={(id) => {
                      setMeasurementId(id)
                      setValue('measurement_id', id ?? null, { shouldDirty: true })
                    }}
                    onShowChange={(show) => setMeasurementShow(Boolean(show))}
                    onAmountPerUnitChange={(val) => {
                      setAmountPerUnit(val)
                      setValue('amount_per_unit', val === '' ? null : val, { shouldDirty: true })
                    }}
                    onMeasurementValueChange={(val) => {
                      setSelectedMeasurementUnit(String(val || ''))
                    }}
                    errors={errors}
                  />
                </Col>

                {/* Default Weight */}
                {(() => {
                  const norm = normalizeUnit(selectedMeasurementUnit)
                  const hideFor = new Set(['g', 'kg'])
                  const show = !hideFor.has(norm)

                  // keep grid alignment identical to Add Product
                  if (!show) return <Col md="4" />

                  return (
                    <Col md="4">
                      <FormLabel className="col-form-label text-start d-flex align-items-center gap-1">
                        Default Weight (KG)
                        <OverlayTrigger placement="right" overlay={<Tooltip>Recommended for invoicing and delivery billing accuracy.</Tooltip>}>
                          <span style={{ cursor: 'pointer' }}>
                            <Icon icon="mdi:information" width={16} color="#6c757d" />
                          </span>
                        </OverlayTrigger>
                      </FormLabel>

                      <FormControl type="number" inputMode="decimal" step="0.01" min={0} placeholder="e.g., 1.25" {...register('weight_per_item')} />

                      <div style={{ minHeight: '16px' }}>
                        <Form.Text className="text-danger">{errors.weight_per_item?.message || '\u00A0'}</Form.Text>
                      </div>
                    </Col>
                  )
                })()}
              </Row>
            </ComponentContainerCard>

            {(() => {
              const norm = normalizeUnit(selectedMeasurementUnit)
              const hideFor = new Set(['g', 'kg'])
              if (hideFor.has(norm)) return null
            })()}

            <ComponentContainerCard title="Category">
              {/* Card Content */}
              <div className="d-flex mt-3 gap-2 align-items-center">
                {lineageData?.category_lineage?.length > 0 ? (
                  <div
                    className=""
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      flexWrap: 'wrap',
                    }}>
                    {/* Path */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        gap: '6px',
                      }}>
                      {lineageData.category_lineage.map((cat, idx, arr) => {
                        const isLast = idx === arr.length - 1

                        return (
                          <span
                            key={cat.category_id}
                            style={{
                              display: 'inline-flex',
                              alignItems: 'center',
                              gap: '8px',
                            }}>
                            <span
                              style={{
                                padding: '4px 10px',
                                fontSize: '13px',
                                fontWeight: isLast ? 600 : 500,
                                borderRadius: '12px',
                                backgroundColor: isLast ? '#e7f1ff' : '#f1f3f5',
                                color: isLast ? '#0d6efd' : '#495057',
                                whiteSpace: 'nowrap',
                              }}>
                              {cat.name}
                            </span>

                            {!isLast && (
                              <span
                                style={{
                                  fontSize: '14px',
                                  fontWeight: 800, // 🔥 bold
                                  color: '#0d6efd', // 🔥 highlight
                                  lineHeight: 1,
                                }}>
                                &gt;
                              </span>
                            )}
                          </span>
                        )
                      })}
                    </div>
                  </div>
                ) : (
                  <p>No categories linked to this product.</p>
                )}

                <Button variant="outline-primary" onClick={() => setShowCategoryUpdate((prev) => !prev)}>
                  {showCategoryUpdate ? 'Cancel' : 'Update Categories'}
                </Button>
              </div>

              {showCategoryUpdate && (
                <>
                  <hr />
                  <FormLabel>Update Category</FormLabel>
                  {isCategoryLoading ? (
                    <p>Loading categories...</p>
                  ) : (
                    <Row>
                      <Col md="4" className="mb-3">
                        <FormSelect
                          onChange={(e) => {
                            const selected = Number(e.target.value)
                            setSelectedMain(selected)
                            setSelectedSub(null)
                            setValue('category', selected)
                          }}
                          value={selectedMain || ''}>
                          <option value="">Select Main Category</option>
                          {mainCategories.map((cat) => (
                            <option key={cat.category_id} value={cat.category_id}>
                              {cat.name}
                            </option>
                          ))}
                        </FormSelect>
                      </Col>

                      {selectedMain && getSubCategories(selectedMain).length > 0 && (
                        <Col md="4" className="mb-3">
                          <FormSelect
                            onChange={(e) => {
                              const selected = Number(e.target.value)
                              setSelectedSub(selected)
                              setValue('category', selected)
                            }}
                            value={selectedSub || ''}>
                            <option value="">Select Sub Category</option>
                            {getSubCategories(selectedMain).map((cat) => (
                              <option key={cat.category_id} value={cat.category_id}>
                                {cat.name}
                              </option>
                            ))}
                          </FormSelect>
                        </Col>
                      )}

                      {selectedSub && getSubCategories(selectedSub).length > 0 && (
                        <Col md="4" className="mb-3">
                          <FormSelect
                            onChange={(e) => {
                              const selected = Number(e.target.value)
                              setValue('category', selected)
                            }}>
                            <option value="">Select Child Category</option>
                            {getSubCategories(selectedSub).map((cat) => (
                              <option key={cat.category_id} value={cat.category_id}>
                                {cat.name}
                              </option>
                            ))}
                          </FormSelect>
                        </Col>
                      )}
                    </Row>
                  )}
                </>
              )}
            </ComponentContainerCard>

            <ComponentContainerCard title="Listing Settings">
              {/* ───── ALWAYS VISIBLE TOGGLES ───── */}
              <Row className="my-3">
                <Col md="4">
                  {/* Status */}
                  <FormGroup>
                    <FormLabel>Status</FormLabel>
                    <Form.Check
                      type="switch"
                      label={watch('status') === 1 ? 'Active' : 'Inactive'}
                      checked={watch('status') === 1}
                      onChange={(e) => setValue('status', e.target.checked ? 1 : 0)}
                    />
                  </FormGroup>
                </Col>

                <Col md="4">
                  {/* Publish */}
                  <FormGroup>
                    <FormLabel>Publish to Web</FormLabel>
                    <Form.Check
                      type="switch"
                      label={publishToWeb ? 'Published' : 'Unpublished'}
                      checked={publishToWeb}
                      onChange={(e) => setPublishToWeb(e.target.checked)}
                    />
                  </FormGroup>
                </Col>

                <Col md="4">
                  {/* Continue Selling */}
                  <FormGroup>
                    <FormLabel>Continue Selling</FormLabel>
                    <Form.Check
                      type="switch"
                      label={continueSelling ? 'Enabled' : 'Disabled'}
                      checked={continueSelling}
                      onChange={(e) => setContinueSelling(e.target.checked)}
                    />
                  </FormGroup>
                </Col>
              </Row>

              {/* Divider only when enabled */}
              {publishToWeb && (
                <hr
                  style={{
                    margin: '6px 0 16px',
                    borderColor: '#e9ecef',
                    opacity: 1,
                  }}
                />
              )}

              {/* ───── CONDITIONAL CONTENT ───── */}
              {publishToWeb && (
                <Row className="align-items-start">
                  {/* LEFT: LISTING */}
                  <Col md="6">
                    <div
                      style={{
                        fontSize: '12px',
                        fontWeight: 600,
                        color: '#6c757d',
                        letterSpacing: '0.4px',
                        textTransform: 'uppercase',
                        marginBottom: '10px',
                      }}>
                      Listing
                    </div>

                    {/* Collections */}
                    <FormGroup className="mb-3">
                      <FormLabel>Collections</FormLabel>
                      <Controller
                        name="collections"
                        control={control}
                        render={({ field }) => (
                          <Select
                            {...field}
                            isMulti
                            value={selectedCollections}
                            onChange={(val) => {
                              field.onChange(val)
                              setSelectedCollections(val)
                            }}
                            options={collections.map((c) => ({
                              label: c.name,
                              value: c.collection_id,
                            }))}
                          />
                        )}
                      />
                    </FormGroup>
                  </Col>

                  {/* RIGHT: SEARCH ENGINE */}
                  <Col md="6">
                    <div
                      style={{
                        fontSize: '12px',
                        fontWeight: 600,
                        color: '#6c757d',
                        letterSpacing: '0.4px',
                        textTransform: 'uppercase',
                        marginBottom: '10px',
                      }}>
                      Search Engine
                    </div>

                    {/* Tags */}
                    <FormGroup className="mb-3">
                      <FormLabel>Tags</FormLabel>
                      <AsyncCreatableSelect
                        isMulti
                        value={selectedTags}
                        onChange={setSelectedTags}
                        loadOptions={async (inputValue) => {
                          try {
                            const result = await searchTags(inputValue).unwrap()
                            return result.map((t) => ({
                              label: t.name,
                              value: t.tag_id,
                            }))
                          } catch {
                            return selectedTags
                          }
                        }}
                      />
                    </FormGroup>

                    {/* SEO Title */}
                    <FormGroup className="mb-3">
                      <FormLabel>Search Engine Title</FormLabel>
                      <FormControl
                        maxLength={70}
                        value={searchEngineTitle}
                        onChange={(e) => {
                          setSearchEngineTitle(e.target.value)
                          setValue('search_engine_title', e.target.value)
                        }}
                      />
                      <Form.Text className="text-muted">{searchEngineTitle.length}/70 characters</Form.Text>
                    </FormGroup>

                    {/* SEO Description */}
                    <FormGroup>
                      <FormLabel>Meta Description</FormLabel>
                      <FormControl
                        as="textarea"
                        rows={4}
                        maxLength={160}
                        value={searchEngineDesc}
                        onChange={(e) => {
                          setSearchEngineDesc(e.target.value)
                          setValue('search_engine_desc', e.target.value)
                        }}
                      />
                      <Form.Text className="text-muted">{searchEngineDesc.length}/160 characters</Form.Text>
                    </FormGroup>
                  </Col>
                </Row>
              )}
            </ComponentContainerCard>

            <ComponentContainerCard title={`Pricing ( ${currencySymbol} )`}>
              {/* ───────── FIELDS ───────── */}
              <Row className="g-3 my-2">
                <Col md={3}>
                  <FormLabel>Cost</FormLabel>
                  <FormControl
                    name="cost"
                    value={watch('cost') || ''}
                    onChange={(e) => setValue('cost', e.target.value)}
                    onBlur={() => {
                      const raw = parseMoney(watch('cost')).toFixed(2)
                      setValue('cost', `${raw} ${currencySymbol}`)
                    }}
                    placeholder={`0.00 ${currencySymbol}`}
                    isInvalid={!!errors.cost}
                  />
                  <Form.Text className="text-danger">{errors.cost?.message}</Form.Text>
                </Col>

                <Col md={3}>
                  <FormLabel>Margin (%)</FormLabel>
                  <FormControl
                    name="margin"
                    value={watch('margin') || ''}
                    onChange={(e) => setValue('margin', e.target.value)}
                    onBlur={() => {
                      const raw = parseMoney(watch('margin')).toFixed(2)
                      setValue('margin', `${raw}`)
                    }}
                    placeholder="0.00 %"
                    isInvalid={!!errors.margin}
                  />
                  <Form.Text className="text-danger">{errors.margin?.message}</Form.Text>
                </Col>

                <Col md={3}>
                  <FormLabel>Selling Price</FormLabel>
                  <FormControl
                    name="price"
                    value={watch('price') || ''}
                    onChange={(e) => setValue('price', e.target.value)}
                    onBlur={() => {
                      const raw = parseMoney(watch('price')).toFixed(2)
                      setValue('price', `${raw} ${currencySymbol}`)
                    }}
                    placeholder={`0.00 ${currencySymbol}`}
                    isInvalid={!!errors.price}
                  />
                  <Form.Text className="text-danger">{errors.price?.message}</Form.Text>
                </Col>

                <Col md={3}>
                  <FormLabel>Profit</FormLabel>
                  <FormControl
                    name="profit"
                    value={watch('profit') || ''}
                    onChange={(e) => setValue('profit', e.target.value)}
                    onBlur={() => {
                      const raw = parseMoney(watch('profit')).toFixed(2)
                      setValue('profit', `${raw} ${currencySymbol}`)
                    }}
                    placeholder={`0.00 ${currencySymbol}`}
                    isInvalid={!!errors.profit}
                  />
                  <Form.Text className="text-danger">{errors.profit?.message}</Form.Text>
                </Col>
              </Row>
            </ComponentContainerCard>

            {measurementShow && (
              <ComponentContainerCard title="Variants">
                <div className='my-3'>
                  <VariantSelectorCardUpdate
                    initialVariants={initialVariants}
                    basePrice={{
                      cost: costPrice,
                      selling: sellingPrice,
                      weight: parseFloat(watch('weight_per_item') || 0),
                    }}
                    productId={productId}
                    onFinalVariants={handleFinalVariants}
                    onMediaUploadClick={(variantId) => {
                      console.log('🔥 CLICKED VARIANT ID:', variantId)
                      setActiveVariantKey(variantId)
                      setShowVariantModal(true)
                    }}
                  />
                </div>
              </ComponentContainerCard>
            )}

            {measurementShow && customVariants.length > 0 && (
              <ComponentContainerCard title="Final Variant Output">
                <Row className="d-flex mx-1 gy-1 my-2">
                  {customVariants.map((v, idx) => (
                    <Col md="4" key={idx} className="d-flex flex-column justify-content-between p-1">
                      <div className="border rounded p-1">
                        <div className="d-flex gap-1 align-items-center py-1">
                          {Array.isArray(v.option_values) &&
                            v.option_values.map((opt, i) => (
                              <Badge key={i} bg="light" className="me-1 text-dark">
                                {opt.value}
                              </Badge>
                            ))}
                        </div>
                        <div className="d-flex justify-content-between px-1">
                          <span className="text-muted text-start">
                            Cost: <br /> Selling:
                          </span>
                          <span className="text-muted text-end">
                            {v.cost} {currencySymbol} <br />
                            {v.price} {currencySymbol}
                          </span>
                        </div>
                      </div>
                    </Col>
                  ))}
                </Row>
              </ComponentContainerCard>
            )}
            {/* ───────── ACTION BAR ───────── */}
            <div
              className="d-flex justify-content-end mt-0 pt-3 mb-3"
              style={{
                borderTop: '1px solid #e9ecef',
              }}>
              <Button type="submit" disabled={isSubmitting} className="px-4">
                {isSubmitting ? 'Updating…' : 'Update Product'}
              </Button>
            </div>
          </Col>
        </Row>
      </Form>

      <Modal show={showConfirmModal} onHide={() => setShowConfirmModal(false)} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Confirm Variants</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {measurementShow ? (
            <>
              <p className="mb-2">These are the variants you’ve added:</p>
              <Row className="d-flex mx-1 gy-1">
                {customVariants.map((v, idx) => (
                  <Col md="4" key={idx} className="d-flex flex-column justify-content-between p-1">
                    <div className="border rounded p-2 h-100">
                      <div className="d-flex gap-1 align-items-center py-1 flex-wrap">
                        {Array.isArray(v.option_values) &&
                          v.option_values.map((opt, i) => (
                            <Badge key={i} bg="light" className="me-1 text-dark mb-1">
                              {opt.value}
                            </Badge>
                          ))}
                      </div>
                      <div className="d-flex justify-content-between px-1 mt-2">
                        <span className="text-muted text-start">
                          Cost: <br /> Selling:
                        </span>
                        <span className="text-muted text-end">
                          {v.cost} {currencySymbol} <br />
                          {v.price} {currencySymbol}
                        </span>
                      </div>
                    </div>
                  </Col>
                ))}
              </Row>
            </>
          ) : (
            <p className="mb-2 text-muted">Variants are disabled for the selected measurement type.</p>
          )}

          <p className="mt-3">Do you want to confirm and proceed?</p>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirmModal(false)} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleConfirmedSubmit} disabled={isSubmitting}>
            {isSubmitting ? 'Updating...' : 'Confirm'}
          </Button>
        </Modal.Footer>
      </Modal>

      <VariantUploaderModal
        showModal={showVariantModal}
        setShowModal={setShowVariantModal}
        productId={productId}
        activeVariantKey={activeVariantKey}
        onMediaChange={(mediaList) => {
          console.log('🟢 Media list updated', mediaList)
        }}
      />
    </>
  )
}

export default UpdateProduct
