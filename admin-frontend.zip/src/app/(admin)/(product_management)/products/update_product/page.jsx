import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Update Product',
}

const UpdateProduct = dynamic(() => import('./UpdateProduct'), { ssr: false })

export default function UpdateProductPage() {
  return <UpdateProduct />
}