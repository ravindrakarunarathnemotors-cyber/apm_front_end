'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, FormLabel, FormSelect, Form, OverlayTrigger, Tooltip } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useGetActiveMeasurementsQuery } from '@/store/features/apiSlice'

export default function MeasurementSelector({
  onSelectMeasurement,
  initialMeasurementId = null,
  errors = {},
  onShowChange,
  onAmountPerUnitChange,
  initialAmountPerUnit = '',
  onAmountFieldVisibleChange, // NEW prop
  onMeasurementValueChange, // <-- add this
}) {
  const { data: measurements = [], isLoading, isError } = useGetActiveMeasurementsQuery()

  const [selectedMeasurementId, setSelectedMeasurementId] = useState(initialMeasurementId || '')
  const [amountPerUnit, setAmountPerUnit] = useState(initialAmountPerUnit || '')
  const [isPcs, setIsPcs] = useState(false)
  const [userHasInteracted, setUserHasInteracted] = useState(false)

  // compute visibility helper
  const amountFieldVisible = userHasInteracted && !isPcs

  // When measurements load (or initialMeasurementId changes), determine if selected is pcs.
  // When measurements load (or initialMeasurementId changes), determine if selected is pcs.
  useEffect(() => {
    if (!measurements || measurements.length === 0) return

    if (initialMeasurementId) {
      setSelectedMeasurementId(initialMeasurementId)
      const selected = measurements.find((m) => Number(m.measurement_id) === Number(initialMeasurementId))
      const nowIsPcs = !!(selected && String(selected.measurement_value).toLowerCase() === 'pcs')
      setIsPcs(nowIsPcs)

      // If there's an existing amount_per_unit, show the field (prefill case).
      if (!nowIsPcs && initialAmountPerUnit !== '' && initialAmountPerUnit !== null && initialAmountPerUnit !== undefined) {
        setUserHasInteracted(true)
      }

      // Notify parent of current show-state (so parent can hide variant card properly)
      if (typeof onShowChange === 'function') onShowChange(nowIsPcs)

      // Notify parent of initial amount_per_unit if present
      if (
        typeof onAmountPerUnitChange === 'function' &&
        initialAmountPerUnit !== '' &&
        initialAmountPerUnit !== null &&
        initialAmountPerUnit !== undefined
      ) {
        onAmountPerUnitChange(String(initialAmountPerUnit))
      }

      // NEW: notify parent of the selected measurement *value* so parent can decide
      // whether to show or hide fields dependent on unit (eg. weight hidden for g/kg).
      if (selected && typeof onMeasurementValueChange === 'function') {
        try {
          onMeasurementValueChange(String(selected.measurement_value))
        } catch (e) {
          // fail silently if parent doesn't accept it
        }
      } else if (typeof onMeasurementValueChange === 'function') {
        try {
          onMeasurementValueChange('')
        } catch (e) {}
      }
    } else {
      // No initialMeasurementId: still check if initialAmountPerUnit exists => show field
      if (initialAmountPerUnit !== '' && initialAmountPerUnit !== null && initialAmountPerUnit !== undefined) {
        setUserHasInteracted(true)
        if (typeof onAmountPerUnitChange === 'function') onAmountPerUnitChange(String(initialAmountPerUnit))
      }

      // Also inform parent that there's no selected measurement value on load.
      if (typeof onMeasurementValueChange === 'function') {
        try {
          onMeasurementValueChange('')
        } catch (e) {}
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [measurements, initialMeasurementId]) // intentionally not depending on onShowChange/onAmountPerUnitChange to avoid repeated calls

  // Inform parent when amount field visibility changes
  useEffect(() => {
    if (typeof onAmountFieldVisibleChange === 'function') {
      onAmountFieldVisibleChange(amountFieldVisible)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [amountFieldVisible])

  // Keep amountPerUnit in sync if parent changes initialAmountPerUnit
  useEffect(() => {
    setAmountPerUnit(initialAmountPerUnit || '')
  }, [initialAmountPerUnit])

  // When user types, update local state and notify parent
  const handleAmountPerUnitChange = (e) => {
    const val = e.target.value
    if (val === '' || /^[0-9]*\.?[0-9]*$/.test(val)) {
      setAmountPerUnit(val)
      if (typeof onAmountPerUnitChange === 'function') onAmountPerUnitChange(val)
    }
  }

  // Helper to build friendly label for dropdown
  const friendlyLabel = (val) => {
    if (!val) return ''

    const v = String(val).trim().toLowerCase()
    const singular = v.endsWith('s') ? v.slice(0, -1) : v

    // Kilograms
    if (['kg', 'kgs', 'kilogram', 'kilograms'].includes(v) || ['kg', 'kilogram'].includes(singular)) {
      return 'Kilogram(s) - KG'
    }

    // Grams
    if (['g', 'gram', 'grams'].includes(v) || ['g', 'gram'].includes(singular)) {
      return 'Gram(s) - G'
    }

    // Liters
    if (['l', 'liter', 'liters', 'ltr', 'ltrs'].includes(v) || ['l', 'liter'].includes(singular)) {
      return 'Liter(s) - L'
    }

    // Milliliters
    if (['ml', 'mls', 'milliliter', 'milliliters'].includes(v) || ['ml', 'milliliter'].includes(singular)) {
      return 'Milliliter(s) - ML'
    }

    // Pieces
    if (['pcs', 'pc', 'piece', 'pieces'].includes(v) || ['pc', 'piece'].includes(singular)) {
      return 'Piece(s) - PCS'
    }

    // Default fallback
    const title = val
      .toString()
      .split(/[_\s-]+/)
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase())
      .join(' ')

    return `${title} - ${String(val).toUpperCase()}`
  }

  const handleSelectMeasurement = (e) => {
    const raw = e.target.value
    const id = raw === '' ? '' : Number(raw)

    setSelectedMeasurementId(id)
    setUserHasInteracted(true)

    if (typeof onSelectMeasurement === 'function') onSelectMeasurement(id)

    const selected = measurements.find((m) => Number(m.measurement_id) === Number(id))
    const nowIsPcs = selected ? String(selected.measurement_value).toLowerCase() === 'pcs' : false
    setIsPcs(nowIsPcs)

    if (typeof onShowChange === 'function') onShowChange(nowIsPcs)

    // NEW: inform parent of selected measurement value (friendly UI hook)
    if (selected && typeof onMeasurementValueChange === 'function') {
      onMeasurementValueChange(String(selected.measurement_value))
    } else if (!selected && typeof onMeasurementValueChange === 'function') {
      onMeasurementValueChange('')
    }

    // Inform parent when amount field visibility changed (also done by effect, but do immediate update)
    if (typeof onAmountFieldVisibleChange === 'function') {
      onAmountFieldVisibleChange(userHasInteracted && !nowIsPcs)
    }

    if (nowIsPcs) {
      // clear amount when pcs selected
      setAmountPerUnit('')
      if (typeof onAmountPerUnitChange === 'function') onAmountPerUnitChange('')
    } else {
      // if measurement switched to non-pcs and there's an existing amountPerUnit, keep showing
      if (amountPerUnit !== '') {
        setUserHasInteracted(true)
        if (typeof onAmountPerUnitChange === 'function') onAmountPerUnitChange(amountPerUnit)
      }
    }
  }

  if (isLoading) return <p>Loading measurements...</p>
  if (isError) return <p className="text-danger">Error loading measurements. Please try again later.</p>

  return (
    <div className="w-100">
      {/* Measurement selector */}
      <div className="mb-1">
        <FormLabel className="col-form-label text-start">Measurement Unit *</FormLabel>

        <FormSelect className="w-100" value={selectedMeasurementId} onChange={handleSelectMeasurement} aria-required="true">
          <option value="" disabled hidden>
            Select Measurement Unit
          </option>
          {measurements.map((m) => (
            <option key={m.measurement_id} value={m.measurement_id}>
              {friendlyLabel(m.measurement_value)}
            </option>
          ))}
        </FormSelect>

        {/* reserve helper space */}
        <div style={{ minHeight: '16px' }}>
          <Form.Text className="text-danger">{errors.measurement_id?.message || '\u00A0'}</Form.Text>
        </div>
      </div>

      {/* Amount per unit */}
      {userHasInteracted && !isPcs && (
        <div className="mb-3">
          <FormLabel className="col-form-label text-start d-flex align-items-center gap-1">
            Amount per unit
            <OverlayTrigger
              placement="right"
              overlay={
                <Tooltip id="amount-info-tooltip">
                  Enter the base price for the minimum measurable amount.
                  <br />
                  Example: price for 100g, 1kg, 1L, etc.
                </Tooltip>
              }>
              <span style={{ cursor: 'pointer' }}>
                <Icon icon="mdi:information" width={16} color="#6c757d" />
              </span>
            </OverlayTrigger>
          </FormLabel>

          <Form.Control
            className="w-100"
            type="text"
            placeholder="Enter amount per unit"
            value={amountPerUnit}
            onChange={handleAmountPerUnitChange}
            name="amount_per_unit"
          />

          <div style={{ minHeight: '16px' }}>
            <Form.Text className="text-danger">{errors.amount_per_unit?.message || '\u00A0'}</Form.Text>
          </div>
        </div>
      )}
    </div>
  )
}
