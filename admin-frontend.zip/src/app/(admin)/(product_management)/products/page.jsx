import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Products',
}

const Products = dynamic(() => import('./Products'), { ssr: false })

export default function ProductsPage() {
  return <Products />
}