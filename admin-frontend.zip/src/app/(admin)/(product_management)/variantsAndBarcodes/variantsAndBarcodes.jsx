'use client'

import React, { useState, useEffect, useMemo, useRef } from 'react'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Modal, Row, Table } from 'react-bootstrap'
import Select from 'react-select'
import Pagination from '@/components/Pagination'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetVariantsnBarcodesMutation } from '@/store/features/sandoSlice'

/* ================= JsBarcode CDN ================= */
const loadJsBarcode = () =>
  new Promise((resolve, reject) => {
    if (window.JsBarcode) return resolve(window.JsBarcode)
    const script = document.createElement('script')
    script.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js'
    script.async = true
    script.onload = () => resolve(window.JsBarcode)
    script.onerror = reject
    document.body.appendChild(script)
  })

/* ================= Utils ================= */
const mmToPx = (mm, dpi) => (mm * dpi) / 25.4

const LABEL_PRESETS = {
  small: { label: 'Small (38×25 mm)', w: 38, h: 25 },
  medium: { label: 'Medium (50×30 mm)', w: 50, h: 30 },
  large: { label: 'Large (70×40 mm)', w: 70, h: 40 },
}

function VariantsAndBarcodes() {
  /* ================= Data ================= */
  const [keyword, setKeyword] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)

  const [suggestions, setSuggestions] = useState([])

  const [fetchVariants] = useGetVariantsnBarcodesMutation()

  /* ================= Print Modal ================= */
  const [showPrint, setShowPrint] = useState(false)
  const [printType, setPrintType] = useState('')
  const [preset, setPreset] = useState('')
  const [customW, setCustomW] = useState('')
  const [customH, setCustomH] = useState('')
  const [dpi, setDpi] = useState(203)
  const [itemsPerRow, setItemsPerRow] = useState(3)
  const [labelsPerPage, setLabelsPerPage] = useState(30)
  const [count, setCount] = useState('')
  const [valueObj, setValueObj] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const logsPerPage = 25
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const previewRef = useRef(null)

  /* ================= Fetch Main List ================= */
  const fetchLogs = async (page = 1, kw = keyword) => {
    setLoading(true)
    try {
      const res = await fetchVariants({
        page,
        limit,
        keyword: kw,
      }).unwrap()

      setLogs(res.products || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
      setTotalEntries(res.total || 0)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }
  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchLogs(page)
  }

  useEffect(() => {
    fetchLogs(1, '')
  }, [])

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  /* ================= Autocomplete (2+ chars) ================= */
  const debouncedSuggest = useMemo(
    () =>
      debounce(async (value) => {
        if (value.length < 2) {
          setSuggestions([])
          return
        }

        const res = await fetchVariants({
          keyword: value,
          limit: 10,
        }).unwrap()

        const opts =
          res.products?.map((p) => ({
            value,
            label: `${p.title} | PID:${p.product_id} | VID:${p.variant_id} | ${p.barcode || 'No barcode'}`,
          })) || []

        setSuggestions(opts)
      }, 300),
    [],
  )


  const handleLimitChange = async (e) => {
    const newLimit = Number(e.target.value)

    setLimit(newLimit)
    setCurrentPage(1)

    setLoading(true)

    try {
      const res = await fetchVariants({
        page: 1,
        limit: newLimit, // ✅ use new value directly
        keyword,
      }).unwrap()

      setLogs(res.products || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  /* ================= Print Modal ================= */
  const openPrintModal = (row) => {
    if (!row.variant_id && !row.barcode) {
      Swal.fire('Error', 'No Variant ID or Barcode available', 'error')
      return
    }

    setPrintType(row.barcode ? 'barcode' : 'variant_id')
    setPreset('')
    setCustomW('')
    setCustomH('')
    setCount('')
    setValueObj(row)

    if (previewRef.current) previewRef.current.innerHTML = ''
    setShowPrint(true)
  }

  /* ================= Preview ================= */
  const generatePreview = async () => {
    if (!printType || !count || count <= 0) {
      Swal.fire('Error', 'Select type and valid count', 'error')
      return
    }

    const JsBarcode = await loadJsBarcode()

    const labelWmm = preset ? LABEL_PRESETS[preset].w : Number(customW)
    const labelHmm = preset ? LABEL_PRESETS[preset].h : Number(customH)

    if (!labelWmm || !labelHmm) {
      Swal.fire('Error', 'Label size required', 'error')
      return
    }

    const labelWpx = mmToPx(labelWmm, dpi)
    const labelHpx = mmToPx(labelHmm, dpi)

    previewRef.current.innerHTML = ''
    previewRef.current.style.display = 'grid'
    previewRef.current.style.gridTemplateColumns = `repeat(${itemsPerRow}, ${labelWpx}px)`
    previewRef.current.style.gap = '10px'

    const value = String(valueObj[printType])

    for (let i = 0; i < count; i++) {
      if (i > 0 && i % labelsPerPage === 0) {
        const br = document.createElement('div')
        br.style.pageBreakAfter = 'always'
        previewRef.current.appendChild(br)
      }

      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
      svg.style.width = `${labelWpx}px`
      svg.style.height = `${labelHpx}px`

      JsBarcode(svg, value, {
        format: 'CODE128',
        width: 2,
        height: labelHpx * 0.6,
        displayValue: true,
        fontSize: 12,
        margin: 4,
      })

      previewRef.current.appendChild(svg)
    }
  }

  /* ================= Print / PDF ================= */
  const openOutput = () => {
    if (!previewRef.current.innerHTML) {
      Swal.fire('Error', 'Preview first', 'error')
      return
    }

    const win = window.open('', '_blank')
    win.document.write(`
      <html>
        <head>
          <title>Barcode Output</title>
          <style>
            body {
              display: grid;
              grid-template-columns: repeat(${itemsPerRow}, auto);
              gap: 10px;
            }
            svg { break-inside: avoid; }
          </style>
        </head>
        <body>${previewRef.current.innerHTML}</body>
      </html>
    `)
    win.document.close()
    win.focus()
    win.print()
  }

  /* ================= UI ================= */
  return (
    <Row>
      <Col>
        <Card>
          <CardHeader>
            <CardTitle>Variants & Barcodes</CardTitle>
          </CardHeader>

          <CardBody>
            {/* ===== Search ===== */}
            <Form className="row g-3 mb-3">
              <FormGroup className="col-md-9">
                <FormLabel>Keyword (ID / Name / Variant / Barcode)</FormLabel>
                <Select
                  isClearable
                  isSearchable
                  options={suggestions}
                  placeholder="Type at least 2 characters..."
                  onInputChange={(val, meta) => {
                    if (meta.action === 'input-change') {
                      setKeyword(val)
                      debouncedSuggest(val)
                    }
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  onChange={(opt) => {
                    const val = opt?.value || ''
                    setKeyword(val)
                    fetchLogs(1, val)
                  }}
                />
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end">
                <Button className="bg-primary border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1, keyword)}>
                  Search
                </Button>
              </FormGroup>
            </Form>

            {/* ===== Table ===== */}
            <div className="table-responsive">
              <Table striped className="table mb-0">
                <thead>
                  <tr>
                    <th>Variant ID</th>
                    <th>Product ID</th>
                    <th>Barcode</th>
                    <th>Title</th>
                    <th>Action</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {logs.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="text-center">
                        No records found
                      </td>
                    </tr>
                  ) : (
                    logs.map((r) => (
                      <tr key={r.variant_id}>
                        <td>{r.variant_id}</td>
                        <td>{r.product_id}</td>
                        <td>{r.barcode || '-'}</td>
                        <td>
                          {r.title}- {r.variant_value || '-'}
                        </td>
                        <td>
                          <Button size="sm" className="bg-dark border-dark" onClick={() => openPrintModal(r)}>
                            <IconifyIcon icon="mdi:printer" /> Print
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalEntries={totalEntries}
              limit={limit}
              onPageChange={handlePageChange}
              onLimitChange={(val) => {
                setLimit(val)
                setCurrentPage(1)
                handleLimitChange({ target: { value: val } })
              }}
              showingFrom={logs.length === 0 ? 0 : (currentPage - 1) * limit + 1}
              showingTo={(currentPage - 1) * limit + logs.length}
            />
          </CardBody>
        </Card>

        {/* ===== PRINT MODAL ===== */}
        <Modal show={showPrint} centered onHide={() => setShowPrint(false)} size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Label Settings</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <Form>
              <FormGroup>
                <Form.Check inline label="Variant ID" checked={printType === 'variant_id'} onChange={() => setPrintType('variant_id')} />
                <Form.Check inline label="Barcode" checked={printType === 'barcode'} onChange={() => setPrintType('barcode')} />
              </FormGroup>

              <FormGroup className="mt-2">
                <Row>
                  <Col>
                    <FormLabel>Preset</FormLabel>
                    <Form.Select onChange={(e) => setPreset(e.target.value)}>
                      <option value="">Custom</option>
                      {Object.entries(LABEL_PRESETS).map(([k, v]) => (
                        <option key={k} value={k}>
                          {v.label}
                        </option>
                      ))}
                    </Form.Select>
                  </Col>
                  <Col>
                    {/* <FormGroup className="mt-2"> */}
                    <FormLabel>Count</FormLabel>
                    <Form.Control type="number" value={count} onChange={(e) => setCount(e.target.value)} />
                    {/* </FormGroup> */}
                  </Col>
                </Row>
              </FormGroup>

              {!preset && (
                <Row className="mt-2">
                  <Col>
                    <FormLabel>Width (mm)</FormLabel>
                    <Form.Control value={customW} onChange={(e) => setCustomW(e.target.value)} />
                  </Col>
                  <Col>
                    <FormLabel>Height (mm)</FormLabel>
                    <Form.Control value={customH} onChange={(e) => setCustomH(e.target.value)} />
                  </Col>
                </Row>
              )}

              <Row className="mt-2">
                <Col>
                  <FormLabel>DPI</FormLabel>
                  <Form.Select value={dpi} onChange={(e) => setDpi(Number(e.target.value))}>
                    <option value={203}>203 DPI</option>
                    <option value={300}>300 DPI</option>
                  </Form.Select>
                </Col>
                <Col>
                  <FormLabel>Items / Row</FormLabel>
                  <Form.Control type="number" value={itemsPerRow} onChange={(e) => setItemsPerRow(Number(e.target.value))} />
                </Col>
                <Col>
                  <FormLabel>Labels / Page</FormLabel>
                  <Form.Control type="number" value={labelsPerPage} onChange={(e) => setLabelsPerPage(Number(e.target.value))} />
                </Col>
              </Row>

              <Button className="mt-3 bg-primary border border-primary gap-2 d-flex align-items-center" onClick={generatePreview}>
                <IconifyIcon icon="mdi:eye" width={16} height={16} />
                Preview
              </Button>

              <div ref={previewRef} className="border mt-3 p-2 rounded-1" />
            </Form>
          </Modal.Body>

          <Modal.Footer className="gap-2">
            <Button variant="primary" onClick={openOutput}>
              Print
            </Button>
            <Button variant="success" onClick={openOutput}>
              Save as PDF
            </Button>
          </Modal.Footer>
        </Modal>
      </Col>
    </Row>
  )
}

export default VariantsAndBarcodes
