import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Variants And Barcodes',
}

const VariantsAndBarcodes = dynamic(() => import('./variantsAndBarcodes'), { ssr: false })

export default function variantsAndBarcodesPage() {
  return <VariantsAndBarcodes />
}