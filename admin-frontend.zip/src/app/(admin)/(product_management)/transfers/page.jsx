import React from 'react'

function page() {
  return (
    <div>
      <h1>transfers page</h1>
    </div>
  )
}

export default page
