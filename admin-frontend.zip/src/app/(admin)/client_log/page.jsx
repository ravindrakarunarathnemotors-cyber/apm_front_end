'use client'

import React, { useState, useEffect, useCallback } from 'react'
import Select from 'react-select'
import { debounce } from 'lodash'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Table, Row, Form, FormGroup, FormLabel, Pagination } from 'react-bootstrap'
import { useGetFilteredclientlogMutation, useGetClientcollQuery } from '@/store/features/apiSlice'

function CollectionList() {
  const [logname, setLogname] = useState('')
  const [logdate, setLogDate] = useState('')
  const [description, setDescription] = useState('')
  const [searchCollection, setSearchCollection] = useState('')
  const [selectedOption, setSelectedOption] = useState(null)
  const [products, setProducts] = useState([])
  const [logId, setLogId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const logsPerPage = 25

  const [fetchFilteredCollection, { isLoading }] = useGetFilteredclientlogMutation()

  const { data: productColloection } = useGetClientcollQuery(searchCollection, {
    skip: searchCollection.length < 2,
  })

  const productOptions =
    productColloection?.map((collect) => ({
      value: collect.id,
      label: `${collect.title} (${collect.id})`,
    })) || []

  const debouncedSearchProduct = debounce((value) => {
    setSearchCollection(value)
  }, 300)

  const fetchLogs = useCallback(
    async (page, filters) => {
      setLoading(true)
      try {
        const res = await fetchFilteredCollection({
          page,
          limit: logsPerPage,
          ...filters,
          merchant_id: '20001',
        }).unwrap()

        setProducts(res.collections || [])
        setTotalPages(res.totalPages || 1)
        setCurrentPage(page)
      } catch (err) {
        console.error('Failed to fetch products:', err)
      } finally {
        setLoading(false)
      }
    },
    [fetchFilteredCollection],
  )

  useEffect(() => {
    fetchLogs(1, {
      logname,
      log_at: logdate,
      description,
      id: logId,
    })
  }, [])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  return (
    <Row className="justify-content-center">
      <Col className="rounded-md">
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Client Logs
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>ID</FormLabel>
                <Form.Control type="text" placeholder="Log ID" value={logId} onChange={(e) => setLogId(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-3">
                <FormLabel>Log Name:</FormLabel>
                <Select
                  options={productOptions}
                  onInputChange={(value) => debouncedSearchProduct(value)}
                  onChange={(option) => {
                    setSelectedOption(option)
                    setLogname(option?.label?.split('(')[0].trim() || '')
                  }}
                  placeholder="Search log..."
                  isClearable
                  isSearchable
                  value={selectedOption}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Description:</FormLabel>
                <Form.Control type="text" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2">
                <Form.Label>Log Date</Form.Label>
                <Form.Control type="date" value={logdate} onChange={(e) => setLogDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-2">
                <Button
                  variant="primary"
                  className="btn bg-primary border border-primary flex-grow-1"
                  onClick={() =>
                    fetchLogs(1, {
                      logname,
                      log_at: logdate,
                      description,
                      id: logId,
                    })
                  }>
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading Logs...</p>
            ) : (
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Module</th>
                      <th>Log</th>
                      <th>User ID</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products?.length === 0 ? (
                      <tr>
                        <td colSpan="5" className="text-center">
                          No collections found.
                        </td>
                      </tr>
                    ) : (
                      products.map((collection) => (
                        <tr key={collection.id}>
                          <td>{collection.id}</td>
                          <td>{new Date(collection.date).toLocaleDateString()}</td>
                          <td>{collection.title}</td>
                          <td>{collection.log || '—'}</td>
                          <td>{collection.user_id}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>

        {/* ================= NEW PAGINATION ================= */}
{totalPages > 1 && (
  <div className="d-flex justify-content-end mt-3">
    <Pagination>

      {(() => {
        const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
        const pages = []

        let start = safeCurrent - 2
        let end = safeCurrent + 2

        if (totalPages <= 5) {
          start = 1
          end = totalPages
        } else {
          if (start < 1) {
            start = 1
            end = 5
          }
          if (end > totalPages) {
            end = totalPages
            start = totalPages - 4
          }
        }

        for (let i = start; i <= end; i++) {
          pages.push(
            <Pagination.Item
              key={i}
              active={i === safeCurrent}
              onClick={() => handlePageChange(i)}
            >
              {i}
            </Pagination.Item>
          )
        }

        return (
          <>
            {/* FIRST */}
            <Pagination.Item
              disabled={safeCurrent === 1}
              onClick={() => handlePageChange(1)}
            >
              First
            </Pagination.Item>

            {/* PREV (<) */}
            <Pagination.Item
              disabled={safeCurrent === 1}
              onClick={() => handlePageChange(safeCurrent - 1)}
            >
              {'<'}
            </Pagination.Item>

            {pages}

            {/* NEXT (>) */}
            <Pagination.Item
              disabled={safeCurrent === totalPages}
              onClick={() => handlePageChange(safeCurrent + 1)}
            >
              {'>'}
            </Pagination.Item>

            {/* LAST */}
            <Pagination.Item
              disabled={safeCurrent === totalPages}
              onClick={() => handlePageChange(totalPages)}
            >
              Last
            </Pagination.Item>
          </>
        )
      })()}

    </Pagination>
  </div>
)}
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default CollectionList
