'use client'

import React, { useState, useCallback, useEffect, useRef } from 'react'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Pagination, Badge } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from '../pending_orders/components/view'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import Paymentmodal from '@/components/Order/paymentmodal'
import CancelModal from '@/components/Order/cancelModal'
import {
  useGetFilteredProcessingOrdersMutation,
  useGetRecipientnameQuery,
  useMarkOrderAsDispatchedMutation,
  useCancelProcessingOrderMutation,
  useConfirmOrdersOrderMutation,
} from '@/store/features/apiSlice'
import { debounce } from 'lodash'

function ProcessingOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
    keyword: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)
  const [viewModal, setViewModal] = useState({ show: false, orderId: null, context: '' })
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrderId, setCancelOrderId] = useState(null)
  const [selectedOrderId, setSelectedOrderId] = useState(null) // ✅ restored
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [cancellingProcessingIds, setCancellingProcessingIds] = useState(new Set())

  const [orders, setOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)

  const printRef = useRef()

  const [getFilteredProcessingOrders, { isLoading }] = useGetFilteredProcessingOrdersMutation()
  const [markOrderAsDispatched] = useMarkOrderAsDispatchedMutation()
  const [cancelProcessingOrder] = useCancelProcessingOrderMutation()
  const [confirmOrder] = useConfirmOrdersOrderMutation()
  const [searchRecipient, setSearchRecipient] = useState('')

  const handleView = (order, context) => {
    setViewModal({ show: true, orderId: order.order_id, context })
  }

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  useEffect(() => {
    handleSearch()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage])

  const debouncedSearch = useCallback(
    debounce((val) => {
      setSearchRecipient(val)
    }, 300),
    [],
  )

  const handleRecipientInput = (e) => {
    setRecipientName(e.target.value)
    debouncedSearch(e.target.value)
  }

   const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handleconfirmOrder = async (orderId) => {
    const user_id = sessionStorage.getItem('user_id')
    try {
      const res = await confirmOrder({
        order_id: orderId,
        status: 'confirmed',
        user_id,
      })

      Swal.fire({
        icon: 'success',
        title: 'Order moved to confirmOrder',
        text: res.message || 'Order status updated successfully.',
        timer: 2000,
        showConfirmButton: false,
      })
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }

  const handlePrint = () => {
    const printContents = printRef.current?.innerHTML ?? ''
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Processing Orders Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
          .no-print { display: none !important; }
        </style>
      </head>
      <body>
        <h2>Processing Orders Report</h2>
        ${printContents}
      </body>
    </html>
    `)
    newWindow.document.close()
    newWindow.print()
  }

  const handleOpenCancelModal = (orderId) => {
    setCancelOrderId(orderId)
    setShowCancelModal(true)
  }

  const handleConfirmCancelFromModal = async (orderId, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelProcessingOrder({
        order_id: orderId,
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh list
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await handleSearch()
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  const handleConfirm = (orderId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to mark order ${orderId} as dispatched?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Dispatch it!',
      cancelButtonText: 'Cancel',
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const user_id = sessionStorage.getItem("user_id");
          const payload = { order_id: orderId, dispatched: true, user_id };
          const res = await markOrderAsDispatched(payload).unwrap()

          if (res?.success && res.dispatched === 'success') {
            Swal.fire('Success', `Order ${orderId} marked as dispatched.`, 'success')
            handleSearch()
          } else {
            Swal.fire('Warning', 'Order could not be marked as dispatched.', 'warning')
          }
        } catch (err) {
          console.error('Error updating order:', err)
          Swal.fire('Error', 'Failed to mark order as dispatched.', 'error')
        }
      }
    })
  }

  const handleProcessOrComplete = async (order) => {
    const isStorePickup =
      String(order?.storepickup ?? '')
        .toLowerCase()
        .trim() === 'yes'
    const status = isStorePickup ? 'completed' : 'processing'
    const actionWord = isStorePickup ? 'complete' : 'set to processing'
    const user_id = sessionStorage.getItem('user_id')

    const confirm = await Swal.fire({
      title: isStorePickup ? 'Complete order?' : 'Set order to Processing?',
      text: `Do you want to ${actionWord} order ${order.order_id}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: isStorePickup ? 'Yes, complete it' : 'Yes, set processing',
      cancelButtonText: 'Cancel',
    })
    if (!confirm.isConfirmed) return

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/orders-sub/processing-order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: order.order_id, status, user_id }),
      }).then((r) => r.json())

      if (res?.success) {
        Swal.fire('Success', isStorePickup ? `Order ${order.order_id} marked as completed.` : `Order ${order.order_id} set to processing.`, 'success')
        await handleSearch()
      } else {
        Swal.fire('Warning', res?.message || 'Update failed.', 'warning')
      }
    } catch (err) {
      console.error('Status update error:', err)
      Swal.fire('Error', 'Failed to update order status.', 'error')
    }
  }

  const handleCancelProcessingOrder = async (orderId) => {
    const result = await Swal.fire({
      title: 'Cancel order?',
      text: `Do you really want to cancel order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, cancel it',
      cancelButtonText: 'No',
    })
    if (!result.isConfirmed) return

    setCancellingProcessingIds((prev) => new Set(prev).add(orderId))

    try {
      const res = await cancelProcessingOrder({ order_id: orderId }).unwrap()

      if (res?.success) {
        Swal.fire('Cancelled', `Order ${orderId} has been cancelled and stocks restored.`, 'success')
        await handleSearch()
      } else {
        Swal.fire('Warning', res?.message || 'Order could not be cancelled.', 'warning')
      }
    } catch (err) {
      console.error('Cancel error:', err)
      Swal.fire('Error', err?.data?.message || 'Failed to cancel the order.', 'error')
    } finally {
      setCancellingProcessingIds((prev) => {
        const next = new Set(prev)
        next.delete(orderId)
        return next
      })
    }
  }

  const handlePayment = (orderId, storepickupVal, paymentMethodId) => {
    setSelectedOrderId(orderId)
    setSelectedPickup(storepickupVal ?? 'no')
    setSelectedPaymentMethodId(paymentMethodId ?? null)
    setShowPaymentModal(true)
  }

  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) handleSearch() // ✅ use existing search
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) handleSearch() // ✅ use existing search
  }

  const handleSearch = async () => {
    const payload = {
      order_id: orderId || undefined,
      recipient_name: recipientName || undefined,
      mobile: mobileNo || undefined,
      date: date || undefined,
      todate: todate || undefined,
      page: currentPage,
      keyword: filters.keyword,
      limit: 10,
    }

    try {
      const res = await getFilteredProcessingOrders(payload).unwrap()
      setOrders(res.orders || [])
      setTotalPages(res.totalPages || 1)
    } catch (err) {
      console.error('Failed to fetch processing orders:', err)
    }
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'warning',
      refund: 'info',
      failed: 'danger',
    }
    const color = colorMap[status] || 'secondary'
    return <Badge className={`border border-${color} text-dark bg-transparent`}>{status}</Badge>
  }

  const handleModalConfirm = () => {
    if (!selectedPartner) {
      Swal.fire('Error', 'Please select a delivery partner', 'error')
      return
    }
    Swal.fire('Confirmed', `Order ${selectedOrderId} assigned to ${selectedPartner.label}.`, 'success')
    setShowModal(false)
    setSelectedOrderId(null)
    setSelectedPartner(null)
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) range.push(i)
    return range
  }

  const paymentStatusBadge5 = () => {
    return (
      <span
        style={{
          backgroundColor: '#fd7e14',
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        Processing
      </span>
    )
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Processing Orders
            </CardTitle>
          </CardHeader>

          <CardBody>

            <Form className="row g-1 mb-3">

              {/* Keyword Input - 4 columns */}
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value);
                      setSearchRecipient(value);
                      setRecipientName(value);
                      setFilters((prev) => ({ ...prev, keyword: value }));
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim();
                      setRecipientName(name);
                      setSearchRecipient(name);
                      setFilters((prev) => ({ ...prev, keyword: name }));
                    } else {
                      setRecipientName('');
                      setSearchRecipient('');
                      setFilters((prev) => ({ ...prev, keyword: '' }));
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{ DropdownIndicator: null }}
                />
              </FormGroup>

              {/* Date Inputs - 6 columns */}
              <FormGroup className="col-md-6">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                    />
                  </div>
                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={todate}
                      onChange={(e) => setToDate(e.target.value)}
                    />
                  </div>
                </div>
              </FormGroup>

              {/* Buttons - 2 columns */}
              <FormGroup className="col-md-2 d-flex align-items-end">
                <div className="d-flex gap-1 w-100">
                  <Button
                    className="bg-primary border border-primary flex-grow-1"
                    onClick={handleSearch}
                    disabled={isLoading}
                  >
                    {isLoading ? 'Searching…' : 'Search'}
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={handlePrint}
                    style={{ backgroundColor: '#6f42c1', borderColor: '#6f42c1' }}
                  >
                    Print
                  </Button>
                </div>
              </FormGroup>

            </Form>


            <div ref={printRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Total Items</th>
                    <th>Weight / Dimensions</th>
                    {/* <th>Delivery Type</th> */}
                    <th>Delivery Type</th>
                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center text-muted py-4">
                        No results were found.
                      </td>
                    </tr>
                  ) : (
                    orders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>{order.total_item}</td>
                        <td>
                          {order.total_weight ? `${order.total_weight} KG` : 'Not Set'} / {order.dimensions || 'Not Set'}
                        </td>
                        {/* <td>{order.delivery_type || '-'}</td> */}
                        <td>{order.currier_partner || '-'}</td>

                        <td className="text-end no-print">
                          <div className="d-flex justify-content-end align-items-center gap-2">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order, 'processing')}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>View</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.5rem',
                                fontSize: '1rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#28a745',
                                borderColor: '#28a745',
                                color: '#fff',
                              }}
                              onClick={() => handleConfirm(order.order_id)}>
                              <Icon icon="mdi:truck" width={20} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>Dispatch</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.5rem',
                                fontSize: '1rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#dc3545',
                                borderColor: '#dc3545',
                                color: '#fff',
                              }}
                              onClick={() => {
                                setCancelOrderId(order.order_id);
                                setShowCancelModal(true);
                              }}
                              disabled={cancellingProcessingIds.has(order.order_id)}
                            >
                              <Icon icon="mdi:close" width={20} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>
                                {cancellingProcessingIds.has(order.order_id) ? 'Cancelling…' : 'Cancel'}
                              </span>
                            </Button>


                            {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )}

                            {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handlePayment(order.order_id, order.storepickup, order.payment_method_id)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )}
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#18311eff',
                                borderColor: '#18311eff',
                                color: '#fff',
                              }}
                              onClick={() => handleconfirmOrder(order.order_id)}>
                              <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Back to Confirm</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  {/* FIRST */}
                  <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                    First
                  </Pagination.Item>

                  {/* PREVIOUS */}
                  <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                  {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                  {(() => {
                    let pages = []

                    if (totalPages <= 5) {
                      // SHOW ALL PAGES (1 → totalPages)
                      for (let i = 1; i <= totalPages; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    } else {
                      // CENTER CURRENT PAGE (MAX 5)
                      let start = currentPage - 2
                      let end = currentPage + 2

                      if (start < 1) {
                        start = 1
                        end = 5
                      }

                      if (end > totalPages) {
                        end = totalPages
                        start = totalPages - 4
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    }

                    return pages
                  })()}

                  {/* NEXT */}
                  <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                  {/* LAST */}
                  <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>

      <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      />

      <View
        show={viewModal.show}
        onClose={() => setViewModal({ ...viewModal, show: false })}
        order_id={viewModal.orderId}
        context={viewModal.context}
        onMarkAsDispatched={handleConfirm}
        payment_method_id={selectedPaymentMethodId}
      />

      {showPaymentModal && (
        <Paymentmodal show={showPaymentModal} onClose={handlePaymentClose} order_id={selectedOrderId} storepickup={selectedPickup} payment_method_id={selectedPaymentMethodId} />
      )}

      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
    </Row>
  )
}

export default ProcessingOrders
