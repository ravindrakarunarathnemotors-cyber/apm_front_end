import React from 'react'
import ProcessingOrders from '../processing_orders/ProcessOrders'

function page() {
  return (
    <>
    <ProcessingOrders/>
     
    </>
  )
}

export default page