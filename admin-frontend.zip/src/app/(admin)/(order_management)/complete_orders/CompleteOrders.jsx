'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Pagination, Badge } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from '../pending_orders/components/view'
import { useGetCompletedOrdersMutation, useGetRecipientnameQuery } from '@/store/features/apiSlice'
import { debounce } from 'lodash'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import Paymentmodal from '@/components/Order/paymentmodal'

function CompleteOrders() {
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [currency, setCurrency] = useState('')
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
  })

  const printRef = useRef()

  const [getCompletedOrders, { data, isLoading }] = useGetCompletedOrdersMutation()
  // const { data: recipientOptions = [], isLoading: isRecipientLoading } = useGetRecipientnameQuery(searchRecipient, { skip: !searchRecipient })
  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Completed Orders Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2ff; }
          .no-print { display: none !important; }
        </style>
      </head>
      <body>
        <h2>Completed Orders Report</h2>
        ${printContents}
      </body>
    </html>
  `)
    newWindow.document.close()
    newWindow.print()
  }

  const debouncedSearch = useCallback(
    debounce((val) => setSearchRecipient(val), 300),
    [],
  )

  const handleSearch = async () => {
    const payload = {
      order_id: orderId,
      recipient_name: recipientName,
      keyword: filters.keyword,
      mobile: mobileNo,
      date,
      todate,
      page: currentPage,
      limit: 10,
    }

    try {
      const res = await getCompletedOrders(payload)
      // res.data likely holds the API response
      const resp = res?.data || res // fallback if shape differs

      if (resp?.totalPages) setTotalPages(resp.totalPages)
      // orders array is used elsewhere, so read currency from there
      const firstOrderCurrency = resp?.orders?.[0]?.currency ?? ''
      setCurrency(firstOrderCurrency)
    } catch (err) {
      console.error('Failed to fetch completed orders', err)
    }
  }

  useEffect(() => {
    handleSearch()
  }, [currentPage])

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handlePageChange = (page) => {
    setCurrentPage(page)
  }

  const handlePayment = (orderId, storepickupVal, paymentMethodId) => {
    setSelectedOrderId(orderId)
    setSelectedPickup(storepickupVal ?? 'no')
    setSelectedPaymentMethodId(paymentMethodId ?? null)
    setShowPaymentModal(true)
  }

  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleView = (order) => {
    setSelectedOrderId(order.order_id)
    setShowViewModal(true)
  }
  const getPaginationRange = () => {
    return Array.from({ length: totalPages }, (_, i) => i + 1)
  }

  const paymentStatusBadge5 = () => {
    return (
      <span
        style={{
          backgroundColor: '#198754',
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        Complete
      </span>
    )
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Completed Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      // If cleared
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-5">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-1">
                <Button className="bg-primary border-primary flex-grow-1 " variant="success" onClick={handleSearch}>
                  Search
                </Button>
                {/* <Button variant="outline-success" onClick={handlePrint}>
                    Print
                  </Button> */}
                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  {/* <Icon icon="mdi:printer" width={16} style={{ marginRight: 4 }} /> */}
                  Print
                </Button>
              </FormGroup>
            </Form>

            <div ref={printRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Delivered At</th>
                    <th>Client</th>
                    <th>Recipient</th>
                    <th>Delivery Type</th>
                    <th className="text-end">Price ({currency})</th>
                    <center>
                      <th className="text-start no-print">Actions</th>
                    </center>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr>
                      <td colSpan="7" className="text-center">
                        Loading...
                      </td>
                    </tr>
                  ) : (data?.orders || []).length === 0 ? (
                    <tr>
                      <td colSpan="7" className="text-center">
                        No completed orders found.
                      </td>
                    </tr>
                  ) : (
                    data.orders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>{order.delivery_date ? new Date(order.delivery_date).toLocaleDateString() : '-'}</td>
                        <td> {order.client_name ? order.client_name.charAt(0).toUpperCase() + order.client_name.slice(1) : ''} </td>
                        <td> {order.recipient_name ? order.recipient_name.charAt(0).toUpperCase() + order.recipient_name.slice(1) : ''} </td>

                        <td>
                          <span className="badge rounded-pill bg-transparent border border-primary text-primary">
                            {order.currier_partner ? order.currier_partner.charAt(0).toUpperCase() + order.currier_partner.slice(1) : '-'}
                          </span>
                        </td>
                        <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>
                        <td className="no-print text-start">
                          <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>{'View'}</span>
                            </Button>
                            {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )}

                            {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handlePayment(order.order_id, order.storepickup, order.payment_method_id)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  {/* FIRST */}
                  <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                    First
                  </Pagination.Item>

                  {/* PREVIOUS */}
                  <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                  {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                  {(() => {
                    let pages = []

                    if (totalPages <= 5) {
                      // SHOW ALL PAGES (1 → totalPages)
                      for (let i = 1; i <= totalPages; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    } else {
                      // CENTER CURRENT PAGE (MAX 5)
                      let start = currentPage - 2
                      let end = currentPage + 2

                      if (start < 1) {
                        start = 1
                        end = 5
                      }

                      if (end > totalPages) {
                        end = totalPages
                        start = totalPages - 4
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    }

                    return pages
                  })()}

                  {/* NEXT */}
                  <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                  {/* LAST */}
                  <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <View show={showViewModal} onClose={() => setShowViewModal(false)} order_id={selectedOrderId} payment_method_id={selectedPaymentMethodId} />
      )}
      {showPaymentModal && (
        <Paymentmodal
          show={showPaymentModal}
          onClose={handlePaymentClose}
          order_id={selectedOrderId}
          storepickup={selectedPickup}
          payment_method_id={selectedPaymentMethodId}
        />
      )}

      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
    </Row>
  )
}

export default CompleteOrders
