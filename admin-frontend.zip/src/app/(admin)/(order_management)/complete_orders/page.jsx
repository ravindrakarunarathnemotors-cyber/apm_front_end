import React from 'react'
import CompleteOrders from '../complete_orders/CompleteOrders'

function page() {
  return (
    <>
    <CompleteOrders/>
     
    </>
  )
}

export default page