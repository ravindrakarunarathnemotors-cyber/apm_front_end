'use client'
import { useState, useEffect } from 'react'
import { Modal, Button, Form, InputGroup } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useUpdateApiConfigMutation } from '@/store/features/apiSlice'

const ApiConfigModal = ({ show, onHide, partner }) => {
  const [formData, setFormData] = useState({
    api_key: '',
    customer_id: '',
    api_status: 'disable',
    two_way_status: 'disable',
    email: '',
    password: '',
  })

  const [updateApiConfig] = useUpdateApiConfigMutation()
  const [showPassword, setShowPassword] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!partner) return

    if ([2, 3, 4].includes(partner.partner_id)) {
      setFormData({
        api_key: partner.api_key || '',
        customer_id: partner.customer_id || '',
        api_status: partner.api_status || 'disable',
        two_way_status: partner.two_way_status || 'disable',
      })
    } else if (partner.partner_id === 8) {
      setFormData({
        api_key: partner.api_key || '',
        customer_id: partner.customer_id || '',
        email: partner.email || '',
        password: partner.password || '',
        api_status: partner.api_status || 'disable',
        two_way_status: partner.two_way_status || 'disable',
      })
    }
  }, [partner])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleToggleApiStatus = () => {
    setFormData((prev) => ({
      ...prev,
      api_status: prev.api_status === 'enable' ? 'disable' : 'enable',
    }))
  }

  const handleCopy = async (text) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)

      setTimeout(() => {
        setCopied(false)
      }, 1500)
    } catch (err) {
      console.error("Copy failed", err)
    }
  }

  const handleToggleTwoWayStatus = () => {
    setFormData((prev) => ({
      ...prev,
      two_way_status: prev.two_way_status === 'enable' ? 'disable' : 'enable',
    }))
  }

  const formatPartnerName = (name) => {
    return name
      .trim()
      .replace(/\s+/g, '_')        // replace spaces with _
      .replace(/[^a-zA-Z0-9_]/g, '') // remove special chars
  }

  const getWebhookUrl = () => {
    if (!partner) return ''
    const systemDomain = process.env.NEXT_PUBLIC_BASE_URL
    const formattedName = formatPartnerName(partner.name)
    return `${systemDomain}/two_way/${formattedName}`
  }


  useEffect(() => {
    if (formData.api_status === 'disable') {
      setFormData((prev) => ({
        ...prev,
        two_way_status: 'disable',
      }))
    }
  }, [formData.api_status])

  const handleSave = async () => {
    if (!formData.api_key.trim()) {
      Swal.fire('Validation Error', 'API Key is required.', 'warning')
      return
    }

    const webhook_url =
      formData.two_way_status === 'enable'
        ? `${process.env.NEXT_PUBLIC_BASE_URL}/two_way/${formatPartnerName(partner.name)}`
        : ''


    try {
      await updateApiConfig({
        partner_id: partner.partner_id,
        api_key: formData.api_key,
        customer_id: formData.customer_id,
        api_status: formData.api_status,
        two_way_status: formData.two_way_status,
        webhook_url: webhook_url,
        email: formData.email,
        password: formData.password,
      }).unwrap()

      Swal.fire('Success', 'API config updated!', 'success')
      onHide()
      window.location.reload()
    } catch (error) {
      console.error('API config update failed:', error)
      Swal.fire('Error', 'Failed to update API config.', 'error')
    }
  }


  return (
    <Modal show={show} onHide={onHide} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>API Configuration {partner ? `- ${partner.name}` : ''}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {partner ? (
          [2, 4, 8].includes(partner.partner_id) ? (
            <>
              <Form.Group className="mb-3">
                <Form.Label>
                  <Icon icon="mdi:badge-account-outline" className="me-2" />
                  Customer ID
                </Form.Label>
                <Form.Control
                  type="text"
                  name="customer_id"
                  value={formData.customer_id}
                  onChange={handleChange}
                />
              </Form.Group>

              {partner.partner_id === 8 && (
                <>
                  <Form.Group className="mb-3">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                    />
                  </Form.Group>
                  <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>

                    <InputGroup>
                      <Form.Control
                        type={showPassword ? 'text' : 'password'}
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                      />

                      <Button
                        variant="outline-secondary"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        <Icon
                          icon={showPassword ? 'mdi:eye-off' : 'mdi:eye'}
                        />
                      </Button>
                    </InputGroup>
                  </Form.Group>
                </>
              )}

              <Form.Group className="mb-3">
                <Form.Label>
                  <Icon icon="mdi:key-variant" className="me-2" />
                  API Key
                </Form.Label>
                <InputGroup>
                  <Form.Control
                    type="text"
                    name="api_key"
                    value={formData.api_key}
                    onChange={handleChange}
                  />
                </InputGroup>
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>API Usage</Form.Label>
                <div
                  role="button"
                  className="d-flex align-items-center"
                  title={formData.api_status === 'enable' ? 'API Enabled' : 'API Disabled'}
                  onClick={handleToggleApiStatus}
                >
                  <Icon
                    icon={formData.api_status === 'enable' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                    style={{ fontSize: '50px' }}
                    className={formData.api_status === 'enable' ? 'text-success' : 'text-danger'}
                  />
                  <span className="ms-2 fw-semibold">{formData.api_status === 'enable' ? 'Enabled' : 'Disabled'}</span>
                </div>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Two Way API</Form.Label>
                <div
                  role="button"
                  className="d-flex align-items-center"
                  onClick={handleToggleTwoWayStatus}
                >
                  <Icon
                    icon={
                      formData.two_way_status === 'enable'
                        ? 'mdi:toggle-switch'
                        : 'mdi:toggle-switch-off'
                    }
                    style={{ fontSize: '50px' }}
                    className={
                      formData.two_way_status === 'enable'
                        ? 'text-success'
                        : 'text-danger'
                    }
                  />
                  <span className="ms-2 fw-semibold">
                    {formData.two_way_status === 'enable'
                      ? 'Enabled'
                      : 'Disabled'}
                  </span>
                </div>
              </Form.Group>


              {formData.two_way_status === 'enable' && (
                <Form.Group className="mb-3">
                  <Form.Label>Webhook URL</Form.Label>

                  <div className="d-flex align-items-center justify-content-between p-2 border rounded bg-light">

                   
                    <div className="text-truncate" style={{ maxWidth: "80%" }}>
                      {getWebhookUrl()}
                    </div>

                  
                    <Button
                      size="sm"
                      variant="outline-secondary"
                      onClick={() => handleCopy(getWebhookUrl())}
                      title={copied ? "Copied" : "Copy URL"}
                    >
                      <Icon icon={copied ? "mdi:check" : "mdi:content-copy"} />
                    </Button>
                  </div>

                  <small className="text-muted">
                    This is your API webhook endpoint
                  </small>
                </Form.Group>
              )}
            </>
          ) : (
            <div className="card bg-danger text-white p-3 text-center">
              <strong>
                API configuration for this partner is restricted. Please contact the administrator for assistance.
              </strong>
            </div>
          )
        ) : (
          <p>Loading partner data...</p>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        {[2, 3, 4, 8].includes(partner?.partner_id) && (
          <Button variant="primary" onClick={handleSave}>
            Save Changes
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  )
}

export default ApiConfigModal

