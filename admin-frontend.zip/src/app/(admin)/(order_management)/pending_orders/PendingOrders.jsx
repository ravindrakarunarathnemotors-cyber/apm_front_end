'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Button,
  Table,
  Badge,
} from 'react-bootstrap'
import { debounce } from 'lodash'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from './components/view'
import ConfirmModal from './components/confirmmodal'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import MarkAsPaidModal from '@/components/Order/MarkAsPaidModal'
import CancelModal from '@/components/Order/cancelModal'
import Pagination from '@/components/Pagination'

import {
  useGetFilteredPendingOrdersMutation,
  useGetRecipientnameQuery,
  useGetActiveDeliveryPartnersQuery,
  useCancelOrderMutation,
  useAssignOrderMutation,
} from '@/store/features/apiSlice'

function PendingOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
  })
  const router = useRouter()

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [fetchPendingOrders, { isLoading, error }] = useGetFilteredPendingOrdersMutation()
  const [pendingorders, setPendingOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [loading, setLoading] = useState(false)
  const [searchRecipient, setSearchRecipient] = useState('')
  const printSectionRef = useRef()
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrderId, setCancelOrderId] = useState(null)
  const [currency, setCurrency] = useState('')

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const { data: activePartnersData = [], isLoading: loadingPartners } = useGetActiveDeliveryPartnersQuery()
  const [cancelOrder] = useCancelOrderMutation()
  const [assignOrder] = useAssignOrderMutation()

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }


  useEffect(() => {
    fetchOrders(currentPage)
  }, [currentPage, limit])

  const handleModalConfirm = async ({ type, partnerId = null }) => {
    const payload = {
      order_id: selectedOrderId,
      status: 'confirmed',
      partnerId,
      ...(type === 'storepickup' ? { assignment_type: 'storepickup' } : { delivery_partner_id: partnerId }),
    }

    try {
      await assignOrder(payload).unwrap()

      Swal.fire('Success', 'Order assigned successfully!', 'success')

      setShowModal(false)
      setSelectedOrderId(null)

      await fetchOrders(currentPage)
    } catch (err) {
      const data = err?.data || err?.error?.data || err?.response?.data


      if (data?.error_code === 'INSUFFICIENT_STOCK' && Array.isArray(data.items)) {
        const rows = data.items
          .map(
            (item, index) => `
          <tr>
            <td style="padding:6px 8px;">${index + 1}</td>
            <td style="padding:6px 8px;">
              <strong>${item.variant_value || 'N/A'}</strong><br/>
              <small style="color:#6c757d">Variant ID: ${item.variant_id}</small>
            </td>
            <td style="padding:6px 8px; color:#198754;">
              ${item.current_stock}
            </td>
            <td style="padding:6px 8px; color:#dc3545;">
              ${item.required}
            </td>
          </tr>
        `,
          )
          .join('')

        await Swal.fire({
          icon: 'warning',
          title: 'Insufficient Stock',
          html: `
        <div style="text-align:left">
          <p style="margin-bottom:6px">
            The following item(s) do not have enough stock to confirm this order:
          </p>

          <table style="width:100%; border-collapse:collapse; font-size:13px">
            <thead>
              <tr style="background:#f8f9fa">
                <th style="padding:6px 8px">#</th>
                <th style="padding:6px 8px">Variant</th>
                <th style="padding:6px 8px">Available</th>
                <th style="padding:6px 8px">Required</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>

          <hr style="margin:10px 0"/>

          <p style="margin-bottom:4px; color:#dc3545">
            <strong>Continue Selling:</strong> OFF
          </p>
          <p style="font-size:12px; color:#6c757d">
            Stock cannot go below zero while <b>Continue Selling</b> is disabled.<br/>
            Enable it for these variants to allow negative stock.
          </p>
        </div>
      `,
          confirmButtonText: 'OK',
          confirmButtonColor: '#0d6efd',
          width: 600,
        })

        // keep modal flow aware of failure
        throw err
      }

      // 🔻 fallback for other errors
      await Swal.fire({
        icon: 'error',
        title: 'Assignment Failed',
        text: data?.message || err?.message || 'Failed to assign order',
      })

      throw err
    }
  }
  const handleView = (order) => {
    setViewOrder(order)
    setSelectedOrderId(order.order_id)
    setShowViewModal(true)
  }

  const handleConfirm = (orderId) => {
    setSelectedOrderId(orderId)
    setShowModal(true)
  }

  const handlePayment = (orderId, storepickupVal) => {
    setSelectedOrderId(orderId)
    setSelectedPickup(storepickupVal ?? 'no')
    setShowPaymentModal(true)
  }

  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const fetchOrders = async (page) => {
    setLoading(true)

    try {
      const res = await fetchPendingOrders({
        page,
        limit,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        keyword: filters.keyword,
        payment_status: paymentStatus,
        paymentMethod: paymentMethod,
        date,
        todate,
      }).unwrap()

      setPendingOrders(res.pendingorders || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
      setCurrentPage(page)

      setCurrency(res.currency || res.pendingorders?.[0]?.currency || '')
    } catch (err) {
      console.error('Failed to fetch orders:', err)
    } finally {
      setLoading(false)
    }
  }
  const handleSearch = () => {
    fetchOrders(1)
  }

  const handleOpenCancelModal = (orderId) => {
    setCancelOrderId(orderId)
    setShowCancelModal(true)
  }

  const handleConfirmCancelFromModal = async (orderIdToCancel, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelOrder({
        order_id: orderIdToCancel,
        status: 'cancelled',
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh lis
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await fetchOrders(currentPage)
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Pending Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  const showingFrom = pendingorders.length === 0 ? 0 : (currentPage - 1) * limit + 1
  const showingTo = (currentPage - 1) * limit + pendingorders.length

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Pending Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Keyword</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-4">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>Payment Status</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="paid">Paid</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="refund">Refund</option>
                  <option value="failed">Failed</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Payment Method</FormLabel>
                <Form.Select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="">All</option>
                  <option value="COD">COD</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Stripe">Stripe</option>
                  <option value="PayHere">PayHere</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchOrders(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>

            <div ref={printSectionRef}>
              <div className="table-responsive">
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Client</th>
                      <th>Payment</th>
                      <th>Method</th>
                      <th className="text-end">Price ({currency})</th>
                      <th className="text-center no-print">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingorders.length > 0 ? (
                      pendingorders.map((order) => (
                        <tr key={order.order_id}>
                          <td>
                            {order.order_id}
                            <br />
                          </td>
                          <td>{new Date(order.created_at).toLocaleDateString()}</td>
                          <td>
                            {order.customer_name}
                            <br />
                            <small>{order.contact_number}</small>
                          </td>
                          <td>
                            {/* main payment status badge */}
                            {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}
                            {/* show “Slip” button only if bank_slip exists */}
                            {hasSlip(order) && (
                              <div className="mt-1 no-print">
                                <Button
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.2rem 0.1rem',
                                    fontSize: '0.55rem',
                                    height: '20px',
                                    borderRadius: '15px',
                                    backgroundColor: '#3d3642ff',
                                    borderColor: '#3d3642ff',
                                    color: '#fff',
                                  }}
                                  variant="outline-primary"
                                  onClick={() => openSlip(order)}
                                  title="Open bank slip"
                                  className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                  <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                  Slip
                                </Button>
                              </div>
                            )}
                          </td>
                          <td>{order.payment_method_id2}</td>
                          <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>
                          <td className="text-end no-print">
                            <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#fd7e14',
                                  borderColor: '#fd7e14',
                                  color: '#fff',
                                }}
                                onClick={() => router.push(`/update_orders?order_id=${order.order_id}`)}>
                                <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Edit</span>
                              </Button>

                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#5f5f5f',
                                  borderColor: '#5f5f5f',
                                  color: '#fff',
                                }}
                                onClick={() => handleView(order)}>
                                <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>View</span>
                              </Button>

                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#28a745',
                                  borderColor: '#28a745',
                                  color: '#fff',
                                }}
                                onClick={() => handleConfirm(order.order_id)}>
                                <Icon icon="mdi:check" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Confirm</span>
                              </Button>
                              {order?.payment_status?.toLowerCase() === 'unpaid' && (
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#dc3545',
                                    borderColor: '#dc3545',
                                    color: '#fff',
                                  }}
                                  onClick={() => {
                                    setCancelOrderId(order.order_id)
                                    setShowCancelModal(true)
                                  }}>
                                  <Icon icon="mdi:close" width={18} className="me-1" />
                                  Cancel
                                </Button>
                              )}

                              {order?.payment_status?.toLowerCase() === 'paid' && (
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#7e111b',
                                    borderColor: '#7e111b',
                                    color: '#fff',
                                  }}
                                  onClick={() => handleUnpaidClick(order.order_id)}>
                                  <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                                </Button>
                              )}

                              {order?.payment_status?.toLowerCase() === 'unpaid' && (
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#035f1c',
                                    borderColor: '#035f1c',
                                    color: '#fff',
                                  }}
                                  onClick={() =>
                                    handlePayment(order.order_id, (order.storepickup ?? order.assignment_type === 'storepickup') ? 'yes' : 'no')
                                  }>
                                  <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                                </Button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="7" className="text-center py-4 text-muted">
                          {loading ? 'Loading pending orders...' : 'No pending orders found.'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </Table>
                </div>
              </div>
              {/* PAGINATION */}
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalEntries={totalEntries}
                limit={limit}
                onPageChange={handlePageChange}
                onLimitChange={(val) => {
                  setLimit(val)
                  setCurrentPage(1)
                }}
                showingFrom={showingFrom}
                showingTo={showingTo}
              />
          </CardBody>
        </Card>
      </Col>
      {showViewModal && (
        <View
          show={showViewModal}
          onClose={() => setShowViewModal(false)}
          order_id={selectedOrderId}
          context="pending"
          onConfirm={() => handleConfirm(selectedOrderId)}
          onCancel={handleOpenCancelModal}
          activePartnersData={activePartnersData}
          loadingPartners={loadingPartners}
          handleAssignConfirm={handleModalConfirm}
        />
      )}

      <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      />

      <ConfirmModal
        show={showModal}
        onClose={() => setShowModal(false)}
        selectedOrderId={selectedOrderId}
        orderDetails={pendingorders.find((o) => o.order_id === selectedOrderId)}
        handleAssignConfirm={handleModalConfirm}
        activePartnersData={activePartnersData}
        loadingPartners={loadingPartners}
        delivery_partner_id={pendingorders.find((o) => o.order_id === selectedOrderId)?.delivery_partner_id || null}
      />
      {showPaymentModal && (
        <MarkAsPaidModal show={showPaymentModal} onClose={handlePaymentClose} order={pendingorders.find((o) => o.order_id === selectedOrderId)} />
      )}
      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
    </Row>
  )
}

export default PendingOrders
