'use client'
import React, { useEffect, useState } from 'react'
import Swal from 'sweetalert2'
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Col,
  Row,
  Spinner,
  OverlayTrigger,
  Tooltip,
} from 'react-bootstrap'
import {
  useGetOrderDetailsQuery,
  useProcessingOrdersOrderMutation,
  useConfirmOrdersOrderMutation,
  useGetDeliveryDetailsQuery,
} from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'
import OrderTimeline from '@/app/(admin)/(order_management)/pending_orders/components/OrderTimeline'
import NotesCard from './NotesCard'
import DeliverpatDetails from './DeliverpatDetails'

import OrderInvoice from './OrderInvoice'
import Select from 'react-select'
import ShippingLabel from './ShippingLabel'
import ConfirmModal from './confirmmodal'
import Paymentmodal from '@/components/Order/paymentmodal'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'
import Link from 'next/link'

const View = ({
  show,
  onClose,
  order_id,
  storepickup,
  context = '',
  onMarkAsDispatched,
  onMarkAsCompleted,
  onProcess,
  onCancel,
  onConfirm,
  loadingPartners,
  activePartnersData,
  handleAssignConfirm,
  payment_method_id,
}) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false)

  const [assignmentType, setAssignmentType] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [showLabelModal, setShowLabelModal] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [url, setUrl] = useState('')

  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)

  const { data: order, isLoading, error, refetch } = useGetOrderDetailsQuery(order_id, { skip: !show })
  const { data: delivery, isLoading: deliveryLoading, isFetching: deliveryFetching } = useGetDeliveryDetailsQuery(order_id, { skip: !order_id })
  const [processingOrder] = useProcessingOrdersOrderMutation()
  const [confirmOrder] = useConfirmOrdersOrderMutation()

  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()

  useEffect(() => {
    console.log('storepickup value:', storepickup)
  }, [storepickup])

  useEffect(() => {
    if (show) {
      refetch()
      fetchUrl()
    }
  }, [show, refetch])

  const fetchUrl = async () => {
    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ordersmange/order_link`,
        { order_id: order_id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )

      if (response.status === 200) {
        setUrl(response.data.data)
      }
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return fetchUrl()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      } else if (error.response) {
        console.error('Error fetching URL:', error.response.data)
      }
    }
  }

  if (!show) return null

  if (isLoading)
    return (
      <div className="p-5 text-center">
        <Spinner animation="border" />
      </div>
    )

  if (error) return <div className="p-5 text-danger">Failed to load order</div>

  const printSection = (sectionId) => {
    const content = document.getElementById(sectionId)?.innerHTML
    if (!content) return

    const printWindow = window.open('', '_blank', 'width=800,height=600')
    printWindow.document.open()
    printWindow.document.write(`
    <html>
      <head>
        <title>Print</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" />
        <style>
          @page {
            size: auto;
            margin: 0;
          }

          html, body {
            background: #fff !important;
            color: #000;
            font-family: sans-serif;
            margin: 0;
            padding: 0;
          }

          body {
            padding: 20px;
          }

          .invoice-header-print {
            background: #bdbdbd !important;
            -webkit-print-color-adjust: exact !important;
            color: #000 !important;
          }

          @media print {
            h5, p, li, address {
              margin-top: 0 !important;
              margin-bottom: 0.25rem !important;
            }

            body {
              margin: 0;
            }
          }
        </style>
      </head>
      <body>
        ${content}
        <script>
          function waitForImagesAndPrint() {
            const images = document.images;
            let loaded = 0;
            if (images.length === 0) {
              window.print();
              window.close();
              return;
            }
            for (let i = 0; i < images.length; i++) {
              if (images[i].complete) {
                loaded++;
              } else {
                images[i].onload = images[i].onerror = () => {
                  loaded++;
                  if (loaded === images.length) {
                    window.print();
                    window.close();
                  }
                };
              }
            }
            if (loaded === images.length) {
              window.print();
              window.close();
            }
          }
          window.onload = waitForImagesAndPrint;
        </script>
      </body>
    </html>
  `)
    printWindow.document.close()
  }

  const colorMap = {
    processing: '#fd7e14',
    pending: '#6c757d',
    completed: '#198754',
    dispatched: '#0d6efd',
    returned: '#6f42c1',
    confirmed: '#20c997',
    cancelled: '#dc3545',
  }

  const handleProcessing = async (orderId) => {
    const user_id = sessionStorage.getItem('user_id')
    try {
      const res = await processingOrder({
        order_id: orderId,
        status: 'processing',
        user_id,
      }).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Order moved to Processing',
        text: res.message || 'Order status updated successfully.',
        timer: 2000,
        showConfirmButton: false,
      })

      refetch()
      onClose()
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }

  const handleconfirmOrder = async (orderId) => {
    const user_id = sessionStorage.getItem('user_id')
    try {
      const res = await confirmOrder({
        order_id: orderId,
        status: 'confirmed',
        user_id,
      }).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Order moved to confirmOrder',
        text: res.message || 'Order status updated successfully.',
        timer: 2000,
        showConfirmButton: false,
      })

      refetch()
      onClose()
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }

  const handlePayment = (orderId, storepickupVal, paymentMethodId) => {
    setSelectedOrderId(orderId)
    setSelectedPickup(storepickupVal)
    setSelectedPaymentMethodId(paymentMethodId ?? null)
    setShowModal(true)
  }

  const handleCloseModal = () => {
    setShowModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
  }
  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidCloseModal = () => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
  }

  const handleCopyUrl = async () => {
    if (!url) return
    try {
      await navigator.clipboard.writeText(url)
      Swal.fire({
        toast: true,
        icon: 'success',
        title: 'Link copied!',
        position: 'top-end',
        showConfirmButton: false,
        timer: 1600,
        timerProgressBar: true,
      })
    } catch (err) {
      // Fallback for older browsers / non-HTTPS
      const ta = document.createElement('textarea')
      ta.value = url
      ta.style.position = 'fixed'
      ta.style.top = '-9999px'
      document.body.appendChild(ta)
      ta.select()
      try {
        document.execCommand('copy')
      } finally {
        document.body.removeChild(ta)
      }
      Swal.fire({
        toast: true,
        icon: 'success',
        title: 'Link copied!',
        position: 'top-end',
        showConfirmButton: false,
        timer: 1600,
        timerProgressBar: true,
      })
    }
  }

  // disable-print when order status is pending
  const isPending = (order?.order_details?.order_status || '').toLowerCase() === 'pending'

  const handleSend = async () => {
    const response = await Swal.fire({
      title: 'Send invoice link?',
      text: 'This will send the invoice and order details link to the customer.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'OK',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (response.isConfirmed) {
      try {
        const response = await axios.post(
          `${process.env.NEXT_PUBLIC_BASE_URL}/ordersmange/send_order_link`,
          { order_id: order_id },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          },
        )

        if (response.status === 200) {
          Swal.fire({
            icon: 'success',
            title: 'Invoice link sent!',
            text: 'The customer has received the invoice and order details successfully.',
            confirmButtonText: 'OK',
          })
        }
      } catch (error) {
        if (error.response?.status === 401 || error.response?.status === 403) {
          const refreshToken = localStorage.getItem('refresh_token')
          if (refreshToken) {
            try {
              const response = await refreshtoken(refreshToken).unwrap()
              sessionStorage.setItem('access_token', response.access_token)
              token = response.access_token
              return handleSend()
            } catch (refreshError) {
              console.error('Error refreshing token:', refreshError)
              Logout()
            }
          } else {
            Logout()
          }
        } else if (error.response) {
          console.error('Error fetching URL:', error.response.data)
        }
      }
    } else if (response.isDismissed) {
      Swal.fire({
        title: 'Cancelled',
        icon: 'error',
        confirmButtonColor: '#3085d6',
      })
    }
  }
  const discountLabels = {
    payment_method: {
      type: 'Order payment',
      label: 'Payment Method Discount',
    },
    order: {
      type: 'General Order',
      label: 'Order Discount',
    },
    shipping: {
      type: 'Order Shipping',
      label: 'Shipping Discount',
    },
    buyx: {
      type: 'BuyXGetY',
      label: 'BuyXGetY Discount',
    },
    product: {
      type: 'General Product',
      label: 'Product Discount',
    },
  }

  const formatMeasurement = (raw = '') => {
    const v = raw.toLowerCase()
    if (v === 'g') return 'g'
    if (v === 'kg') return 'Kg'
    if (v === 'ml') return 'ml'
    if (v === 'l') return 'l'
    return raw
  }
  // Controls whether Discount column is shown
  //  show item discount column ONLY if any item has item_discount
  const hasItemDiscount = order?.order_items?.some((it) => Number(it.item_discount || 0) > 0)

  return (
    <Modal show={show} fullscreen onHide={onClose} className="fade p-6">
      <ModalHeader className="bg-primary d-flex align-items-center justify-content-between" closeButton closeVariant="white">
        <div className="d-flex align-items-center justify-content-between w-100">
          <div className="d-flex gap-2">
            <h6
              className="modal-title m-0"
              style={{
                fontWeight: 700,
                fontSize: '0.9rem',
                color: '#fff',
                opacity: 1,
              }}>
              Order ID: #{order_id}
              {order?.order_details?.created_at && (
                <> / Issue Date: {new Date(order.order_details.created_at).toISOString().split('T')[0].replace(/-/g, '.')}</>
              )}
            </h6>
            <h6 className="modal-title m-0 text-white">{order.recipient_address.name || 'N/A'}</h6>
          </div>
          <div className="d-flex align-items-center gap-2">
            {/* Print Order Button (green) */}
            <Button
              className="d-flex align-items-center"
              style={{
                padding: '0.35rem 0.7rem',
                fontSize: '0.75rem',
                borderRadius: '15px',
                backgroundColor: '#198754',
                borderColor: '#198754',
                color: '#fff',
                transition: 'all 0.2s ease-in-out',
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = '#157347'
                e.target.style.borderColor = '#157347'
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = '#198754'
                e.target.style.borderColor = '#198754'
              }}
              onClick={() => printSection('invoice-print-area')} // ✅ open modal
            >
              <Icon icon="mdi:printer" width={18} height={18} style={{ marginRight: '4px' }} />
              Print Order
            </Button>

            {/* Print Shipping Labels Button (light-blue) */}

            {isPending ? (
              <OverlayTrigger
                placement="bottom"
                overlay={
                  <Tooltip id={`tooltip-print-label-${order_id}`}>
                    Shipping label disabled. It will be available once the order is confirmed and the tracking ID is generated.
                  </Tooltip>
                }>
                <span style={{ display: 'inline-block' }}>
                  <Button
                    className="d-flex align-items-center"
                    style={{
                      padding: '0.35rem 0.7rem',
                      fontSize: '0.75rem',
                      borderRadius: '15px',
                      backgroundColor: '#4a0553ff', // keep original styling
                      borderColor: '#4a0553ff',
                      color: '#fff',
                      opacity: 0.6, // disabled look
                      cursor: 'not-allowed',
                    }}
                    disabled={true}
                    onClick={() => {}}>
                    <Icon icon="mdi:label" width={18} height={18} style={{ marginRight: '4px' }} />
                    Print Shipping Label
                  </Button>
                </span>
              </OverlayTrigger>
            ) : (
              <Button
                className="d-flex align-items-center"
                style={{
                  padding: '0.35rem 0.7rem',
                  fontSize: '0.75rem',
                  borderRadius: '15px',
                  backgroundColor: '#4a0553ff',
                  borderColor: '#4a0553ff',
                  color: '#fff',
                  transition: 'all 0.2s ease-in-out',
                }}
                onMouseEnter={(e) => {
                  e.target.style.backgroundColor = '#4a0553ff'
                  e.target.style.borderColor = '#4a0553ff'
                }}
                onMouseLeave={(e) => {
                  e.target.style.backgroundColor = '#4a0553ff'
                }}
                onClick={() => printSection('label-print-area')}>
                <Icon icon="mdi:label" width={18} height={18} style={{ marginRight: '4px' }} />
                Print Shipping Label
              </Button>
            )}
          </div>
        </div>
      </ModalHeader>

      <ModalBody style={{ backgroundColor: '#f8f9fa', color: '#000' }} className="px-8 py-8">
        <div className="w-75 mx-auto py-2">
          <Row>
            <Col lg={8}>
              {/* Order Items */}
              {/* Professional Compact Order Items Table */}
              {/* Professional Compact Order Items Table */}
              <CardBody style={{ padding: '0.75rem, 0rem' }}>
                <CardHeader
                  className="d-flex justify-content-between align-items-center bg-dark"
                  style={{
                    borderBottom: '1px solid #374151',
                    padding: '12px 18px',
                    borderTopLeftRadius: '8px',
                    borderTopRightRadius: '8px',
                  }}>
                  {/* Title */}
                  <CardTitle
                    as="h4"
                    className="m-0 d-flex align-items-center"
                    style={{
                      color: '#f9fafb',
                      fontSize: '0.95rem',
                      fontWeight: 700,
                      letterSpacing: '-0.2px',
                    }}>
                    Item Details&nbsp;
                    <span style={{ color: '#f9fafb' }}>for Order #{order?.order_details?.order_id ?? order_id}</span>
                  </CardTitle>

                  {/* Status Badges */}
                  <div className="d-flex align-items-center gap-2">
                    {/* Payment Status */}
                    {order.order_details?.payment_status && (
                      <span
                        className="badge rounded-pill text-capitalize"
                        style={{
                          fontSize: '0.7rem', // unchanged
                          padding: '4px 10px',
                          fontWeight: 600,
                          backgroundColor: '#e0e7ff', // VERY light blue
                          color: '#1e3a8a', // deep blue text
                          border: '1px solid #c7d2fe',
                        }}>
                        {order.order_details.payment_status}
                      </span>
                    )}

                    {/* Payment Method */}
                    {order.order_details?.method_name && (
                      <span
                        className="badge rounded-pill text-capitalize"
                        style={{
                          fontSize: '0.7rem', // unchanged
                          padding: '4px 10px',
                          fontWeight: 600,
                          backgroundColor: '#d1fae5', // very light green
                          color: '#065f46', // dark green text
                          border: '1px solid #a7f3d0',
                        }}>
                        {order.order_details.method_name}
                      </span>
                    )}

                    {/* Order Status */}
                    {order.order_details?.order_status && (
                      <span
                        className="badge rounded-pill text-capitalize"
                        style={{
                          fontSize: '0.7rem', // unchanged
                          padding: '4px 10px',
                          fontWeight: 600,
                          backgroundColor: colorMap[order.order_details.order_status.toLowerCase()] || '#6c757d',
                          color: '#fff',
                          border: 'none',
                        }}>
                        {order.order_details.order_status}
                      </span>
                    )}
                  </div>
                </CardHeader>
                {order.order_items.length === 0 ? (
                  <div className="text-muted p-2">No order items found for this order ID.</div>
                ) : (
                  <div className="table-responsive">
                    <table
                      className="table mb-0"
                      style={{
                        background: '#fff',
                        borderRadius: 8,
                        overflow: 'hidden',
                        boxShadow: '0 3px 10px rgba(0,0,0,0.05)',
                        fontFamily: '"Inter", system-ui, sans-serif',
                        fontSize: 12,
                      }}>
                      <thead style={{ background: '#f3f4f6' }}>
                        <tr>
                          <th style={{ width: 35, padding: '8px 12px', fontWeight: 600 }}>#</th>
                          <th style={{ padding: '8px 12px', fontWeight: 600 }}>Items</th>
                          <th style={{ width: 70, textAlign: 'center', padding: '8px 12px', fontWeight: 600 }}>Qty</th>
                          <th style={{ width: 70, textAlign: 'center', padding: '8px 12px', fontWeight: 600 }}>Unit</th>
                          {/* Safely get currency with fallback */}
                          {(() => {
                            var currency = order?.order_details?.currency || '-'
                            return (
                              <>
                                <th
                                  style={{
                                    width: 110,
                                    textAlign: 'right',
                                    padding: '8px 12px',
                                    fontWeight: 600,
                                    whiteSpace: 'nowrap',
                                  }}>
                                  Item&nbsp;Price&nbsp;({currency})
                                </th>

                                {hasItemDiscount && (
                                  <th
                                    style={{
                                      width: 120,
                                      textAlign: 'right',
                                      padding: '8px 12px',
                                      fontWeight: 600,
                                      color: '#dc2626',
                                    }}>
                                    Discount
                                  </th>
                                )}

                                <th style={{ width: 120, textAlign: 'right', padding: '8px 12px', fontWeight: 600 }}>Amount ({currency})</th>
                              </>
                            )
                          })()}
                        </tr>
                      </thead>

                      <tbody>
                        {order.order_items.map((item, idx) => {
                          const qty = Number(item.quantity) || 0
                          const freeQty = Number(item.free_quantity || 0)
                          const unitPrice = Number(item.unit_price) || 0

                          const explicitTotal = Number(item.total_price)
                          const lineTotal = Number.isFinite(explicitTotal) && explicitTotal > 0 ? explicitTotal : qty * unitPrice

                          // ✅ ADD THIS (missing variable)
                          const itemBaseTotal = qty * unitPrice

                          // ✅ item-level discount from backend
                          const itemDiscount = Number(item.item_discount || 0)

                          // per-unit discount × qty

                          const discountValue = itemDiscount

                          const hasDiscount = discountValue > 0

                          const discountedTotal = hasDiscount ? itemBaseTotal - discountValue : itemBaseTotal

                          //   console.log('ITEM DISCOUNT DEBUG:', {
                          //   discount: item.discount,
                          //   discount_type: item.discount_type,
                          //   total_price: item.total_price,
                          //   unit_price: item.unit_price,
                          // })

                          // --- UNIT NAME CONVERSIONS ---
                          const unitMap = {
                            g: 'Grams (g)',
                            kg: 'Kilograms (kg)',
                            mg: 'Milligrams (mg)',
                            l: 'Liters (l)',
                            ml: 'Milliliters (ml)',
                            pcs: 'Pieces',
                            pc: 'Pieces',
                            piece: 'Pieces',
                            unit: 'Units',
                          }

                          let rawUnit = item.measurement_value || item.amount_per_unit || item.weight_unit || '—'

                          rawUnit = String(rawUnit).toLowerCase()

                          const unitDisplay = unitMap[rawUnit] || unitMap[item.weight_unit?.toLowerCase()] || rawUnit.toUpperCase()

                          return (
                            <React.Fragment key={idx}>
                              {/* ================= ORIGINAL ROW (UNCHANGED) ================= */}
                              <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                                <td style={{ padding: '8px 12px', verticalAlign: 'middle', color: '#6b7280' }}>{idx + 1}</td>

                                <td style={{ padding: '8px 12px', verticalAlign: 'top' }}>
                                  <div className="d-flex" style={{ gap: 10 }}>
                                    <img
                                      src={item.media_url || '/package.png'}
                                      alt={item.product_title}
                                      onError={(e) => (e.target.src = '/placeholder.png')}
                                      style={{
                                        width: 42,
                                        height: 42,
                                        borderRadius: 6,
                                        objectFit: 'cover',
                                        border: '1px solid #e6edf3',
                                      }}
                                    />

                                    <div style={{ flex: 1 }}>
                                      <div
                                        style={{
                                          fontSize: 12,
                                          fontWeight: 600,
                                          color: '#111827',
                                          textAlign: 'justify',
                                          lineHeight: 1.35,
                                          whiteSpace: 'normal',
                                          wordBreak: 'break-word',
                                        }}>
                                        {item.product_title}
                                      </div>

                                      {item.variant_value && (
                                        <div className="mt-1 d-flex" style={{ gap: 4, flexWrap: 'wrap' }}>
                                          {(() => {
                                            const values = String(item.variant_value)
                                              .split('/')
                                              .map((v) => v.trim())
                                              .filter(Boolean)

                                            let idsRaw = item.variant_id ?? item.variant_ids ?? item.variant?.id ?? ''
                                            idsRaw = idsRaw == null ? '' : String(idsRaw)

                                            let idsArr = []
                                            if (idsRaw.includes('/')) idsArr = idsRaw.split('/')
                                            else if (idsRaw.includes(',')) idsArr = idsRaw.split(',')
                                            else if (idsRaw) idsArr = [idsRaw]

                                            while (idsArr.length < values.length) idsArr.push('')

                                            const variantType = (item.variant_type || '').toLowerCase()

                                            return values.map((v, i) => {
                                              const vid = idsArr[i] || ''

                                              return (
                                                <span
                                                  key={i}
                                                  style={{
                                                    fontSize: 10,
                                                    background: '#111827',
                                                    color: '#fff',
                                                    padding: '2px 6px',
                                                    borderRadius: 999,
                                                    lineHeight: '14px',
                                                  }}>
                                                  {variantType === 'default' ? vid : vid ? `${vid} - ${v}` : v}
                                                </span>
                                              )
                                            })
                                          })()}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </td>

                                {(() => {
                                  const measurementRaw = (item.measurement_value ?? '').toString().trim()
                                  const measurement = measurementRaw.toLowerCase()
                                  const amountPerUnitRaw = item.amount_per_unit ?? ''
                                  const amountPerUnit = amountPerUnitRaw != null ? String(amountPerUnitRaw).trim() : ''

                                  let compactUnit = ''
                                  if (amountPerUnit) {
                                    compactUnit = amountPerUnit + (/[a-zA-Z]/.test(amountPerUnit) ? '' : measurementRaw || '')
                                  } else {
                                    compactUnit = measurementRaw || ''
                                  }

                                  const isPieces = ['pcs', 'pc', 'piece', 'pieces'].includes(measurement)

                                  let qtyDisplay = ''
                                  if (isPieces) qtyDisplay = `${qty} ${measurementRaw || 'pcs'}`
                                  else if (compactUnit) qtyDisplay = `${qty} x ${compactUnit}`
                                  else qtyDisplay = `${qty}`

                                  return <td style={{ textAlign: 'center', padding: '8px 12px', fontWeight: 600 }}>{qtyDisplay}</td>
                                })()}

                                <td style={{ textAlign: 'center', padding: '8px 12px', fontSize: 11 }}>{unitDisplay}</td>

                                <td style={{ textAlign: 'right', padding: '8px 12px', fontWeight: 600 }}>{unitPrice.toFixed(2)}</td>
                                {hasItemDiscount && (
                                  <td style={{ textAlign: 'right', padding: '8px 12px', color: '#dc2626', fontWeight: 600 }}>
                                    {hasDiscount ? `-${discountValue.toFixed(2)}` : '—'}
                                  </td>
                                )}

                                <td style={{ textAlign: 'right', padding: '8px 12px', fontWeight: 700 }}>
                                  {hasDiscount ? (
                                    <div>
                                      <div
                                        style={{
                                          textDecoration: 'line-through',
                                          color: '#6b7280',
                                          fontSize: 11,
                                          fontWeight: 500,
                                        }}>
                                        {lineTotal.toFixed(2)}
                                      </div>
                                      <div style={{ color: '#111827', fontWeight: 700 }}>{discountedTotal.toFixed(2)}</div>
                                    </div>
                                  ) : (
                                    lineTotal.toFixed(2)
                                  )}
                                </td>
                              </tr>

                              {/* ================= FREE ROW (ADDED ONLY) ================= */}
                              {freeQty > 0 && (
                                <tr style={{ background: '#f0fdf4' }}>
                                  <td />

                                  <td style={{ padding: '8px 12px' }}>
                                    <div className="d-flex" style={{ gap: 10 }}>
                                      <div style={{ position: 'relative' }}>
                                        <img
                                          src={item.media_url || '/package.png'}
                                          alt={item.product_title}
                                          onError={(e) => (e.target.src = '/placeholder.png')}
                                          style={{
                                            width: 42,
                                            height: 42,
                                            borderRadius: 6,
                                            objectFit: 'cover',
                                            border: '1px solid #e6edf3',
                                          }}
                                        />
                                        <span
                                          style={{
                                            position: 'absolute',
                                            top: -6,
                                            right: -6,
                                            background: '#16a34a',
                                            color: '#fff',
                                            fontSize: 9,
                                            fontWeight: 700,
                                            padding: '2px 6px',
                                            borderRadius: 999,
                                          }}>
                                          FREE
                                        </span>
                                      </div>

                                      <div style={{ flex: 1 }}>
                                        <div
                                          style={{
                                            fontSize: 12,
                                            fontWeight: 600,
                                            color: '#111827',
                                            lineHeight: 1.35,
                                          }}>
                                          {item.product_title}
                                        </div>

                                        {item.variant_value && (
                                          <div className="mt-1 d-flex" style={{ gap: 4, flexWrap: 'wrap' }}>
                                            {(() => {
                                              const values = String(item.variant_value)
                                                .split('/')
                                                .map((v) => v.trim())
                                                .filter(Boolean)

                                              let idsRaw = item.variant_id ?? item.variant_ids ?? item.variant?.id ?? ''
                                              idsRaw = idsRaw == null ? '' : String(idsRaw)

                                              let idsArr = []
                                              if (idsRaw.includes('/')) idsArr = idsRaw.split('/')
                                              else if (idsRaw.includes(',')) idsArr = idsRaw.split(',')
                                              else if (idsRaw) idsArr = [idsRaw]

                                              while (idsArr.length < values.length) idsArr.push('')

                                              const variantType = (item.variant_type || '').toLowerCase()

                                              return values.map((v, i) => {
                                                const vid = idsArr[i] || ''

                                                return (
                                                  <span
                                                    key={i}
                                                    style={{
                                                      fontSize: 10,
                                                      background: '#16a34a',
                                                      color: '#fff',
                                                      padding: '2px 6px',
                                                      borderRadius: 999,
                                                      lineHeight: '14px',
                                                    }}>
                                                    {variantType === 'default' ? vid : vid ? `${vid} - ${v}` : v}
                                                  </span>
                                                )
                                              })
                                            })()}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </td>

                                  {/* Qty — FREE after qty */}
                                  <td
                                    style={{
                                      textAlign: 'center',
                                      padding: '8px 12px',
                                      fontWeight: 700,
                                      color: '#16a34a',
                                      whiteSpace: 'nowrap',
                                    }}>
                                    {(() => {
                                      const unitRaw = (item.measurement_value || '').toString().trim()
                                      const unit = unitRaw.toLowerCase()
                                      const perUnit = Number(item.amount_per_unit || 0)
                                      const isPCS = unit === 'pcs'

                                      if (isPCS) return `${freeQty} FREE`
                                      return `${freeQty * perUnit}${formatMeasurement(unitRaw)} FREE`
                                    })()}
                                  </td>

                                  <td style={{ textAlign: 'center', padding: '8px 12px', fontSize: 11 }}>{unitDisplay}</td>

                                  <td style={{ textAlign: 'right', padding: '8px 12px' }}>0.00</td>
                                  <td style={{ textAlign: 'right', padding: '8px 12px' }}>0.00</td>
                                </tr>
                              )}
                            </React.Fragment>
                          )
                        })}
                        {/* ================= PRODUCT DISCOUNT (TABLE TOTAL) ================= */}
                        {(() => {
                          const currency = order?.order_details?.currency || ''

                          const productDiscountTotal = order.order_items.reduce((sum, it) => {
                            const perItemDiscount = Number(it.item_discount || 0)
                            return sum + perItemDiscount
                          }, 0)

                          if (productDiscountTotal <= 0) return null

                          return (
                            <tr>
                              <td colSpan={hasItemDiscount ? 5 : 4}></td>

                              <td
                                style={{
                                  textAlign: 'right',
                                  padding: '10px 12px',
                                  fontWeight: 700,
                                  whiteSpace: 'nowrap',
                                }}>
                                Product Discount
                              </td>

                              <td
                                style={{
                                  textAlign: 'right',
                                  padding: '10px 12px',
                                  fontWeight: 800,
                                }}>
                                -{productDiscountTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')} {currency}
                              </td>
                            </tr>
                          )
                        })()}

                        {/* ================= SUBTOTAL (UNCHANGED) ================= */}
                        <tr>
                          <td colSpan={hasItemDiscount ? 5 : 4}></td>

                          <td
                            style={{
                              textAlign: 'right',
                              padding: '10px 12px',
                              fontWeight: 700,
                              whiteSpace: 'nowrap',
                            }}>
                            Subtotal
                          </td>

                          <td
                            style={{
                              textAlign: 'right',
                              padding: '10px 12px',
                              fontWeight: 800,
                            }}>
                            {(() => {
                              const currency = order?.order_details?.currency || ''
                              const subtotal = Number(order?.order_details?.total_value || 0)

                              return `${subtotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',')} ${currency}`
                            })()}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}{' '}
                {/* end of order items table conditional */}
                {/* calc block  */}
                <Card className="mb-3 p-3 mt-2">
                  <div className="mb-2">
                    <span
                      className="badge rounded-pill bg-transparent border border-primary text-primary text-capitalize"
                      style={{ fontSize: '0.68rem' }}>
                      {order.order_details.payment_status}
                    </span>
                  </div>

                  <div className="border rounded p-2">
                    {/* Subtotal */}
                    <div className="d-flex justify-content-between">
                      <span>Subtotal</span>
                      <span>
                        {order.order_details.total_value} {order.order_details.currency}
                      </span>
                    </div>

                    {/* Discount — order / manual / code / payment_method */}
                    {(() => {
                      const rawDiscount = order?.order_details?.discount ?? 0
                      const discountValue = parseFloat(rawDiscount) || 0

                      const discountTypeKey = order?.order_details?.discount_type

                      // Allowed discount types
                      const allowedTypes = ['order', 'manual', 'code', 'payment_method']

                      if (discountValue <= 0 || !allowedTypes.includes(discountTypeKey)) return null

                      // Label formatter (Promo Code override)
                      const formatLabel = (type) => {
                        if (type === 'code') return 'Promo Code'
                        return `${type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())} Discount`
                      }

                      const discountLabel = formatLabel(discountTypeKey)

                      const currency = order?.order_details?.currency || ''

                      return (
                        <div className="d-flex justify-content-between">
                          <span>Discount ({discountLabel})</span>
                          <span>
                            -{discountValue.toFixed(2)} {currency}
                          </span>
                        </div>
                      )
                    })()}

                    {/* Delivery Fee — show only if > 0 */}
                    {Number(order?.order_details?.delivery_fee || 0) > 0 && (
                      <div className="d-flex justify-content-between">
                        <span>Delivery Fee</span>
                        <span>
                          {Number(order.order_details.delivery_fee).toFixed(2)} {order.order_details.currency}
                        </span>
                      </div>
                    )}

                    {/* Delivery Fee Discount — show ONLY for shipping discounts */}
                    {(() => {
                      const rawDiscount = order?.order_details?.discount ?? 0
                      const discountValue = parseFloat(rawDiscount) || 0
                      const discountTypeKey = order?.order_details?.discount_type

                      if (discountTypeKey !== 'shipping' || discountValue <= 0) return null

                      const currency = order?.order_details?.currency || ''

                      return (
                        <div className="d-flex justify-content-between">
                          <span>Delivery Fee Discount</span>
                          <span>
                            -{discountValue.toFixed(2)} {currency}
                          </span>
                        </div>
                      )
                    })()}

                    {/* Tax */}
                    {order.order_details.tax && (
                      <div className="d-flex justify-content-between">
                        <span>{order.order_details?.tax?.name}</span>
                        <span>{`${parseFloat(order.order_details?.tax?.value || 0).toFixed(2)} ${order.order_details.currency}`}</span>
                      </div>
                    )}

                    {Number(order?.order_details?.transaction_fee || 0) > 0 && (
                      <div className="d-flex justify-content-between">
                        <span>Transaction Fee</span>
                        <span>
                          {Number(order.order_details.transaction_fee).toFixed(2)} {order.order_details.currency}
                        </span>
                      </div>
                    )}

                    {/* Elegant divider before totals — show ONLY when loyalty points are used */}
                    {Number(order?.order_details?.loyalty_points_spent || 0) > 0 && (
                      <div
                        style={{
                          height: '1px',
                          margin: '10px 0 8px',
                          backgroundImage:
                            'linear-gradient(to right, rgba(0,0,0,0) 0%, rgba(0,0,0,0.15) 20%, rgba(0,0,0,0.35) 50%, rgba(0,0,0,0.15) 80%, rgba(0,0,0,0) 100%)',
                        }}
                      />
                    )}

                    {/* Order Total — show ONLY when loyalty points are used */}
                    {(() => {
                      const loyalty = Number(order?.order_details?.loyalty_points_spent || 0)
                      if (loyalty <= 0) return null

                      const currency = order?.order_details?.currency || '-'
                      const fullAmount = parseFloat(order?.order_details?.full_amount || 0)

                      // Order Total = payable + loyalty used
                      const orderTotal = fullAmount + loyalty

                      return (
                        <div className="d-flex justify-content-between py-1">
                          <span>Total</span>
                          <span>{`${orderTotal.toFixed(2)} ${currency}`}</span>
                        </div>
                      )
                    })()}

                    {/* Loyalty points spent (show under discount when > 0) */}
                    {Number(order?.order_details?.loyalty_points_spent || 0) > 0 && (
                      <div className="d-flex justify-content-between">
                        <span>Loyalty Points Redeemed</span>

                        <span>{order.order_details.loyalty_points_spent}</span>
                      </div>
                    )}
                    <div
                      style={{
                        height: '1px',
                        margin: '6px 0 6px',
                        background: '#dee2e6',
                      }}
                    />

                    {/* Total / Balance — auto label based on loyalty */}
                    {(() => {
                      const currency = order?.order_details?.currency || '-'
                      const loyalty = Number(order?.order_details?.loyalty_points_spent || 0)

                      const hasFullAmount =
                        typeof order?.order_details?.full_amount !== 'undefined' &&
                        order?.order_details?.full_amount !== null &&
                        order?.order_details?.full_amount !== ''

                      const computedFallback =
                        (parseFloat(order.order_details.total_value || 0) || 0) +
                        (parseFloat(order.order_details.delivery_fee || 0) || 0) -
                        (parseFloat(order.order_details.discount || 0) || 0) +
                        (parseFloat(order.order_details?.tax?.value || 0) || 0)

                      const totalValue = hasFullAmount ? parseFloat(order.order_details.full_amount || 0) : computedFallback
                      const formattedTotal = Number.isFinite(totalValue) ? totalValue.toFixed(2) : '0.00'
                      const label = loyalty > 0 ? 'Balance' : 'Total'

                      const amountPaid = Number(order?.order_details?.amount_paid || 0)
                      const dueBalance = totalValue - amountPaid
                      const isFullyPaid = (order?.order_details?.payment_status || '').toLowerCase() === 'paid'

                      return (
                        <>
                          <div className="d-flex justify-content-between py-1 fw-semibold">
                            <span>{label}</span>
                            <span>{`${formattedTotal} ${currency}`}</span>
                          </div>

                          {amountPaid > 0 && !isFullyPaid && (
                            <>
                              <div className="d-flex justify-content-between py-1">
                                <span style={{ fontSize: '0.82rem', color: '#6b7280' }}>Paid</span>
                                <span
                                  style={{ fontSize: '0.82rem', fontWeight: 600, color: '#16a34a' }}>{`${amountPaid.toFixed(2)} ${currency}`}</span>
                              </div>
                              <div className="d-flex justify-content-between py-1">
                                <span style={{ fontSize: '0.82rem', color: '#6b7280' }}>Due Balance</span>
                                <span
                                  style={{ fontSize: '0.82rem', fontWeight: 700, color: '#dc2626' }}>{`${dueBalance.toFixed(2)} ${currency}`}</span>
                              </div>
                            </>
                          )}
                        </>
                      )
                    })()}
                  </div>
                </Card>
              </CardBody>

              {/* Timeline */}
              {/* Order Timeline */}
              <Card className="mb-3">
                <CardHeader className="bg-view py-2 d-flex align-items-center justify-content-between bg-dark">
                  <CardTitle as="h4" className="text-white mb-0">
                    Order Timeline
                  </CardTitle>
                </CardHeader>
                <CardBody>
                  <OrderTimeline order_id={order_id} />
                </CardBody>
              </Card>
            </Col>

            {/* Contact + Address Info */}
            <Col lg={4}>
              <Card className="mb-3">
                <CardHeader className="bg-view py-2 d-flex align-items-center justify-content-between bg-dark">
                  <div className="d-flex align-items-center gap-2">
                    <CardTitle as="h4" className="text-white mb-0">
                      Order Details
                    </CardTitle>

                    {/* Inline Order ID Badge */}
                    <span
                      style={{
                        fontFamily: 'monospace',
                        fontSize: '0.8rem',
                        background: '#e5e7eb', // soft gray
                        padding: '3px 8px',
                        borderRadius: '6px',
                        color: '#111827',
                        fontWeight: 600,
                      }}>
                      #{order?.order_details?.order_id ?? order_id}
                    </span>
                  </div>
                </CardHeader>

                {/* Order ID (professionally styled) */}
                {/* <div className="px-3 py-2 border-bottom">
                  <div className="fw-semibold text-muted" style={{ fontSize: '0.75rem' }}>
                    Order ID
                  </div>

                  <div
                    className="mt-1"
                    style={{
                      fontFamily: 'monospace',
                      fontSize: '0.9rem',
                      color: '#111827',
                      fontWeight: 600,
                      background: '#f3f4f6',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      display: 'inline-block',
                    }}
                  >
                    {order?.order_details?.order_id ?? order_id}
                  </div>
                </div> */}

                <CardBody>
                  <Card.Text className="d-flex flex-column gap-4">
                    {/* Customer Information */}
                    <div className="">
                      <div className="fw-bold d-flex align-items-center gap-1">
                        <Icon icon="mdi:account-circle" width={16} height={16} />
                        Customer Information
                      </div>

                      {/* Smooth HR */}
                      <div
                        style={{
                          display: 'block',
                          width: '100%',
                          height: '1px',
                          backgroundImage:
                            'linear-gradient(to right, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 70%, rgba(0,0,0,0) 100%)',
                          backgroundRepeat: 'no-repeat',
                          backgroundSize: '100% 1px',
                          margin: '6px 0 12px',
                          pointerEvents: 'none',
                        }}
                      />

                      {/* Name */}
                      <div>
                        <span className="text-muted">Name: </span>
                        {order.customer_address.name || 'N/A'}
                      </div>

                      {/* Address */}
                      <div>
                        <span className="text-muted">Address: </span>
                        {order.customer_address.address || 'N/A'}
                      </div>

                      <div>
                        <span className="text-muted">Address Line 2: </span>
                        {order.customer_address.apartment || 'N/A'}
                      </div>

                      {/* City */}
                      <div>
                        <span className="text-muted">City: </span>
                        {order.customer_address.city || 'N/A'}
                      </div>

                      {/* Postal Code */}
                      {/* <div>
                        <span className="text-muted">Postal Code: </span>
                        {order.customer_address.postal_code || 'N/A'}
                      </div> */}

                      {/* Country */}
                      <div>
                        <span className="text-muted">Country: </span>
                        {order.customer_address.country || 'N/A'}
                      </div>

                      {/* Email */}
                      <div>
                        <span className="text-muted">Email: </span>
                        {order.customer_address.email || 'N/A'}
                      </div>

                      {/* Phone */}
                      <div>
                        <span className="text-muted">Phone: </span>
                        {order.customer_address.contact_number_1 || 'N/A'}
                      </div>

                      {/* Alternate Phone */}
                      {order.customer_address.contact_number_2 && (
                        <div>
                          <span className="text-muted">Alternate Phone: </span>
                          {order.customer_address.contact_number_2}
                        </div>
                      )}
                    </div>

                    {/* Shipping Address */}
                    <div className="">
                      <div className="fw-bold d-flex align-items-center gap-1">
                        <Icon icon="mdi:truck-delivery" width={16} height={16} />
                        Shipping Address
                      </div>

                      {/* Smooth HR */}
                      <div
                        style={{
                          display: 'block',
                          width: '100%',
                          height: '1px',
                          backgroundImage:
                            'linear-gradient(to right, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 70%, rgba(0,0,0,0) 100%)',
                          backgroundRepeat: 'no-repeat',
                          backgroundSize: '100% 1px',
                          margin: '6px 0 12px',
                          pointerEvents: 'none',
                        }}
                      />

                      {/* Name */}
                      <div>
                        <span className="text-muted">Name: </span>
                        {order.recipient_address.name || 'N/A'}
                      </div>

                      {/* Address */}
                      <div>
                        <span className="text-muted">Address: </span>
                        {order.recipient_address.address || 'N/A'}
                      </div>

                      <div>
                        <span className="text-muted">Address Line 2: </span>
                        {order.recipient_address.address_2 ? order.recipient_address.address_2 : 'N/A'}
                      </div>

                      {/* City */}
                      <div>
                        <span className="text-muted">City: </span>
                        {order.recipient_address.city || 'N/A'}
                      </div>

                      {/* Postal Code */}
                      <div>
                        <span className="text-muted">Postal Code: </span>
                        {order.recipient_address.postal_code || 'N/A'}
                      </div>

                      {/* Country */}
                      <div>
                        <span className="text-muted">Country: </span>
                        {order.recipient_address.country || 'N/A'}
                      </div>

                      {/* Email */}
                      <div>
                        <span className="text-muted">Email: </span>
                        {order.recipient_contact_info.email || 'N/A'}
                      </div>

                      {/* Phone */}
                      <div>
                        <span className="text-muted">Phone: </span>
                        {order.recipient_contact_info.contact || 'N/A'}
                      </div>
                    </div>

                    {/* Delivery Details — render only when there's at least one value */}
                    {(() => {
                      const hasDelivery =
                        Boolean(delivery?.partner?.name) ||
                        Boolean(delivery?.tracking_id) ||
                        Boolean(delivery?.partner?.contact_number) ||
                        Boolean(delivery?.partner?.logo) ||
                        Boolean(delivery?.partner?.tracking_url && String(delivery.partner.tracking_url).startsWith('http'))

                      if (!hasDelivery) return null

                      return (
                        <div>
                          <div className="fw-bold d-flex align-items-center gap-1">
                            <Icon icon="mdi:map-marker-distance" width={16} height={16} />
                            Delivery Details
                          </div>

                          <div
                            style={{
                              display: 'block',
                              width: '100%',
                              height: '1px',
                              backgroundImage:
                                'linear-gradient(to right, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 70%, rgba(0,0,0,0) 100%)',
                              backgroundRepeat: 'no-repeat',
                              backgroundSize: '100% 1px',
                              margin: '6px 0 12px',
                              pointerEvents: 'none',
                            }}
                          />

                          <div style={{ lineHeight: '1.3' }}>
                            {/* Name */}
                            {delivery?.partner?.name && (
                              <div>
                                <span className="text-muted">Name: </span>
                                <span>{delivery.partner.name}</span>
                              </div>
                            )}

                            {/* Tracking ID */}
                            {delivery?.tracking_id && (
                              <div>
                                <span className="text-muted">Tracking ID: </span>
                                <span>{delivery.tracking_id}</span>
                              </div>
                            )}

                            {/* Contact */}
                            {delivery?.partner?.contact_number && (
                              <div>
                                <span className="text-muted">Contact: </span>
                                <span>{delivery.partner.contact_number}</span>
                              </div>
                            )}
                          </div>

                          {/* Logo + Button Row */}
                          <div className="d-flex align-items-center mt-2">
                            {/* Logo */}
                            {delivery?.partner?.logo && (
                              <img
                                src={delivery.partner.logo}
                                alt={delivery?.partner?.name || 'Delivery partner'}
                                style={{
                                  width: 55,
                                  height: 55,
                                  objectFit: 'contain',
                                  marginRight: '8px',
                                }}
                              />
                            )}

                            {/* Tracking Button */}
                            {delivery?.partner?.tracking_url?.startsWith('http') && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  height: '32px',
                                  borderRadius: '16px',
                                  backgroundColor: '#fd7e14',
                                  borderColor: '#fd7e14',
                                  padding: '0 12px',
                                  fontSize: '0.7rem',
                                }}
                                onClick={() => {
                                  const isSimpleExpress = delivery?.partner?.name === 'Simple Express'

                                  const url =
                                    isSimpleExpress && delivery?.tracking_id
                                      ? `${delivery.partner.tracking_url}?trackingNumber=${delivery.tracking_id}`
                                      : delivery.partner.tracking_url

                                  window.open(url, '_blank')
                                }}>
                                <Icon icon="mdi:map-marker-path" width={16} height={16} style={{ marginRight: '4px' }} />
                                Track
                              </Button>
                            )}
                          </div>
                        </div>
                      )
                    })()}

                    {/* Divider */}
                    {/* <hr
                      style={{
                        border: "none",
                        height: "1px",
                        background:
                          "linear-gradient(to right, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 70%, rgba(0,0,0,0) 100%)",
                        margin: "6px 0 12px",
                      }}
                    /> */}

                    {/* Billing Address */}
                    {/* <div className="mb-2">
                      <div className="fw-bold d-flex align-items-center gap-1">
                        <Icon icon="mdi:file-document-edit" width={16} height={16} />
                        Billing Address
                      </div>

                      <div
                        style={{
                          display: 'block',
                          width: '100%',
                          minHeight: '1px',
                          height: '1px',
                          backgroundImage:
                            'linear-gradient(to right, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 40%, rgba(0,0,0,0.05) 70%, rgba(0,0,0,0) 100%)',
                          backgroundRepeat: 'no-repeat',
                          backgroundSize: '100% 1px',
                          margin: '6px 0 12px',
                          pointerEvents: 'none',
                        }}
                      />

                      <div>{order.customer_address.name}</div>
                      <div>
                        {order.customer_address.address}, Apt: {order.customer_address.apartment}
                      </div>
                      <div>
                        {order.customer_address.city}, {order.recipient_address.country || 'N/A'}
                      </div>
                    </div> */}
                  </Card.Text>
                </CardBody>
              </Card>
              {/* conditional rendering buttons */}

              <Card className="mb-3">
                {/* --- Order & Payment Link Title --- */}
                <CardHeader className="bg-view py-2 d-flex align-items-center justify-content-between bg-dark" style={{ borderTop: 'none' }}>
                  <CardTitle as="h4" className="text-white mb-0">
                    Order & Payment Link
                  </CardTitle>
                </CardHeader>

                <CardBody
                  className="d-flex justify-content-start flex-wrap gap-2"
                  style={{ overflowWrap: 'break-word', wordBreak: 'break-word', whiteSpace: 'normal' }}>
                  <div className="w-100">
                    {/* URL pill */}
                    <div className="flex-grow-1 small bg-light border rounded px-3 py-2 text-break">{url || 'No link available'}</div>

                    {/* Actions */}
                    <div className="d-flex gap-2 mt-2">
                      <Button
                        className="d-inline-flex align-items-center gap-1"
                        style={{
                          padding: '0.45rem 0.9rem',
                          borderRadius: '9999px',
                        }}
                        variant="dark"
                        onClick={handleCopyUrl}
                        disabled={!url}
                        title="Copy link to clipboard">
                        <Icon icon="mdi:content-copy" width={18} height={18} />
                        <span className="d-none d-sm-inline">Copy Link</span>
                      </Button>

                      {url && (
                        <Button
                          className="d-inline-flex align-items-center gap-1"
                          style={{
                            padding: '0.45rem 0.9rem',
                            borderRadius: '9999px',
                          }}
                          variant="outline-dark"
                          onClick={handleSend}>
                          <Icon icon="material-symbols:send" width={18} height={18} />
                          <span className="d-none d-sm-inline">Send Link</span>
                        </Button>
                      )}
                    </div>
                  </div>
                </CardBody>

                <div
                  style={{
                    width: '100%',
                    height: '1px',
                    margin: '10px 0',
                    backgroundImage:
                      'linear-gradient(to right, rgba(0,0,0,0) 0%, rgba(0,0,0,0.12) 15%, rgba(0,0,0,0.2) 50%, rgba(0,0,0,0.12) 85%, rgba(0,0,0,0) 100%)',
                  }}
                />

                {/* --- Actions Title --- */}
                <CardHeader className="bg-view py-2">
                  <CardTitle as="h5" className="text-dark m-0">
                    Actions
                  </CardTitle>
                </CardHeader>

                <CardBody className="d-flex justify-content-start flex-wrap gap-2 pt-1">
                  {order?.order_details?.payment_status?.toLowerCase() === 'paid' && (
                    <Button
                      className="d-flex align-items-center"
                      style={{
                        padding: '0.3rem 0.6rem',
                        fontSize: '0.65rem',
                        height: '30px',
                        borderRadius: '15px',
                        backgroundColor: '#49060cff',
                        borderColor: '#49060cff',
                        color: '#fff',
                      }}
                      onClick={() => handleUnpaidClick(order_id)}>
                      <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                      <span>Mark As Unpaid</span>
                    </Button>
                  )}

                  {order?.order_details?.payment_status?.toLowerCase() === 'unpaid' && (
                    <Button
                      className="d-flex align-items-center"
                      style={{
                        padding: '0.3rem 0.6rem',
                        fontSize: '0.65rem',
                        height: '30px',
                        borderRadius: '15px',
                        backgroundColor: '#083514ff',
                        borderColor: '#083514ff',
                        color: '#fff',
                      }}
                      onClick={() => handlePayment(order_id, storepickup, payment_method_id)}>
                      <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                      <span>Mark As Paid</span>
                    </Button>
                  )}

                  {context === 'processing' && (
                    <>
                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.5rem',
                          fontSize: '1rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#28a745',
                          borderColor: '#28a745',
                          color: '#fff',
                        }}
                        onClick={() => onMarkAsDispatched(order_id)}>
                        <Icon icon="mdi:truck" width={20} height={20} style={{ marginRight: '4px' }} />
                        <span style={{ fontSize: '0.65rem' }}>Dispatched</span>
                      </Button>
                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#18311eff',
                          borderColor: '#18311eff',
                          color: '#fff',
                        }}
                        onClick={() => handleconfirmOrder(order_id)}>
                        <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                        <span>Back to Confirm</span>
                      </Button>
                    </>
                  )}

                  {context === 'confirmed' && (
                    <>
                      {String(storepickup).toLowerCase().trim() === 'yes' ? (
                        <Button
                          className="d-flex align-items-center"
                          style={{
                            padding: '0.3rem 0.6rem',
                            fontSize: '0.65rem',
                            height: '30px',
                            borderRadius: '15px',
                            backgroundColor: '#28a745ff',
                            borderColor: '#28a745ff',
                            color: '#fff',
                          }}
                          onClick={() => onProcess(order_id)}>
                          <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                          <span>Complete</span>
                        </Button>
                      ) : (
                        <Button
                          className="d-flex align-items-center"
                          style={{
                            padding: '0.3rem 0.6rem',
                            fontSize: '0.65rem',
                            height: '30px',
                            borderRadius: '15px',
                            backgroundColor: '#d37e39ff',
                            borderColor: '#d37e39ff',
                            color: '#fff',
                          }}
                          onClick={() => onProcess(order_id)}>
                          <Icon icon="mdi:clipboard-clock-outline" width={15} height={20} style={{ marginRight: '4px' }} />
                          <span>Process</span>
                        </Button>
                      )}
                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#dc3545',
                          borderColor: '#dc3545',
                          color: '#fff',
                        }}
                        onClick={() => onCancel(order_id)}>
                        <Icon icon="mdi:close" width={15} height={20} style={{ marginRight: '4px' }} />
                        <span>Cancel</span>
                      </Button>
                    </>
                  )}

                  {context === 'pending' && (
                    <>
                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#28a745ff',
                          borderColor: '#28a745',
                          color: '#fff',
                        }}
                        onClick={() => setShowConfirmModal(true)}>
                        <Icon icon="mdi:check" width={18} className="me-1" />
                        Confirm
                      </Button>

                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#dc3545',
                          borderColor: '#dc3545',
                          color: '#fff',
                        }}
                        onClick={() => onCancel(order_id)}>
                        <Icon icon="mdi:close" width={18} className="me-1" />
                        Cancel
                      </Button>
                    </>
                  )}

                  {context === 'dispatched' && (
                    <>
                      <Button
                        className="d-flex align-items-center "
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#28a745',
                          borderColor: '#28a745',
                          color: '#fff',
                        }}
                        onClick={() => onMarkAsCompleted(order_id)}>
                        <Icon icon="mdi:truck-check" width={15} height={20} style={{ marginRight: '4px' }} />
                        <span>Complete</span>
                      </Button>
                      <Button
                        className="d-flex align-items-center"
                        style={{
                          padding: '0.3rem 0.6rem',
                          fontSize: '0.65rem',
                          height: '30px',
                          borderRadius: '15px',
                          backgroundColor: '#fd7e14',
                          borderColor: '#fd7e14',
                          color: '#fff',
                        }}
                        onClick={() => handleProcessing(order_id)}>
                        <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                        <span>Back to Processing</span>
                      </Button>
                    </>
                  )}
                </CardBody>

                {/* subtle divider between sections */}
                {/* <div style={{ height: 1, background: '#e9ecef', margin: '0 1rem' }} /> */}
              </Card>
              <Card className="mb-3">
                <NotesCard orderId={order_id} show={show} />
              </Card>
            </Col>
          </Row>
        </div>
      </ModalBody>
      {/* 
      <Modal
        show={showInvoiceModal}
        onHide={() => setShowInvoiceModal(false)}
        size="lg"
        style={{ border: '1px solid #ccc' }}
        dialogClassName="custom-invoice-modal">
        <Modal.Header closeButton>
          <Modal.Title>Order Invoice Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body style={{ backgroundColor: '#f0f0f0' }}>
          {order ? <OrderInvoice order={order} onClose={() => setShowInvoiceModal(false)} /> : <div>Loading invoice...</div>}
        </Modal.Body>
        <Modal.Footer>
        </Modal.Footer>
      </Modal> */}

      <ModalFooter>
        <Button variant="secondary" size="sm" onClick={onClose}>
          Close
        </Button>
        {/* <Modal show={showLabelModal} onHide={() => setShowLabelModal(false)} size="md" dialogClassName="custom-invoice-modal">
          <Modal.Header closeButton>
            <Modal.Title>Shipping Label</Modal.Title>
          </Modal.Header>
          <Modal.Body className="d-flex justify-content-center">{order ? <ShippingLabel order={order} /> : <div>Loading label...</div>}</Modal.Body>
          <Modal.Footer>
            <Button variant="success" onClick={() => window.print()}>
              <Icon icon="mdi:printer" width={18} style={{ marginRight: '4px' }} />
              Print
            </Button>
          </Modal.Footer>
        </Modal> */}

        {/* Hidden Print Areas */}
        <div style={{ display: 'none' }}>
          {order && (
            <>
              <div id="invoice-print-area">
                <OrderInvoice order={order} />
              </div>

              <div id="label-print-area" style={{ width: '387px', margin: '0 auto', padding: '12px' }}>
                <ShippingLabel order={order} />
              </div>
            </>
          )}
        </div>
        <ConfirmModal
          show={showConfirmModal}
          onClose={() => setShowConfirmModal(false)}
          orderId={order_id}
          activePartnersData={activePartnersData}
          loadingPartners={loadingPartners}
          handleAssignConfirm={handleAssignConfirm}
        />
        <UnpaidModal show={showUnpaidModal} onClose={() => setShowUnpaidModal(false)} order_id={selectedOrderId} />
        {showModal && (
          <Paymentmodal
            show={showModal}
            onClose={handleCloseModal}
            order_id={selectedOrderId}
            storepickup={selectedPickup}
            payment_method_id={selectedPaymentMethodId}
          />
        )}
      </ModalFooter>
    </Modal>
  )
}

export default View
