'use client'

import React from 'react'
import SimplebarReactClient from 'simplebar-react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { CardBody, Card, Spinner } from 'react-bootstrap'
import { useGetOrderTimelineQuery } from '@/store/features/apiSlice'

const statusMap = {
  pending_date: {
    title: 'Pending Order',
    icon: 'mdi:clock-outline',
    variant: 'text-warning',
    comment: 'Order received',
  },
  confirmed_date: {
    title: 'Confirmed Order',
    icon: 'mdi:check-circle-outline',
    variant: 'text-success',
    comment: 'Order confirmed',
  },
  processing_date: {
    title: 'Processing Order',
    icon: 'mdi:progress-clock',
    variant: 'text-info',
    comment: 'Order is currently under processing and preparation.',
  },
  dispatched_date: {
    title: 'Dispatch Order',
    icon: 'mdi:truck-fast-outline',
    variant: 'text-primary',
    comment: 'Order dispatched',
  },
  cancelled_date: {
    title: 'Cancelled Order',
    icon: 'mdi:close-circle-outline',
    variant: 'text-danger',
    comment: 'Order cancelled',
  },
  returned_date: {
    title: 'Returned Order',
    icon: 'mdi:undo',
    variant: 'text-warning',
    comment: 'Order returned',
  },
  delivery_completed_date: {
    title: 'Completed Order',
    icon: 'mdi:clipboard-check-outline',
    variant: 'text-success',
    comment: 'Order delivered',
  },
}

const OrderTimeline = ({ order_id }) => {
  const { data, isLoading, error } = useGetOrderTimelineQuery(order_id)

  if (isLoading) return <Spinner animation="border" className="m-3" />
  if (error) return <div className="text-danger p-3">Failed to load timeline</div>

  // Include pending_date if present, otherwise fallback to created_at for pending_date
  const timelineObj = data?.timeline || {}

  // If pending_date doesn't exist in timeline, try to get it from created_at
  if (!timelineObj.pending_date && data?.created_at) {
    timelineObj.pending_date = data.created_at
  }

  // Convert timeline object to array of logs filtering non-null dates
  // Convert timeline object to array of logs filtering non-null dates
const timeline = Object.entries(timelineObj)
  .filter(([_, date]) => date !== null && date !== undefined)
  .map(([key, date], idx) => {
    let comment = statusMap[key]?.comment || ''

    if (key === 'pending_date') {
      switch (data.order_module) {
        case 'admin':
          comment = 'Order was received via the admin portal and is pending.'
          break
        case 'client':
          comment = 'Order was submitted through the web store and is pending.'
          break
        default:
          comment = `Order received from ${data.order_module || 'unknown'}`
      }
    }

//      if (key === 'confirmed_date') {
//   const confirmer = data.username || {}
  
//   comment = `The order was confirmed by ${data.username || 'unknown'} (User ID: ${data.user_id || '-'})${
//     data.delivery_partner ? ` and assigned delivery partner As ${data.delivery_partner}` : ''
//   }.`
// }

if (key === 'confirmed_date') {
  const confirmer = data.username || 'unknown';
  const userId = data.user_id || '-';
  const deliveryPartner = data.delivery_partner || '';

  if (deliveryPartner.toLowerCase() === 'store pickup') {
    comment = `Order confirmed by ${confirmer} (User ID: ${userId}) and assigned for store pickup. The customer will collect the order from the store.`;
  } else if (deliveryPartner) {
    comment = `The order was confirmed by ${confirmer} (User ID: ${userId}) and assigned delivery partner As ${deliveryPartner}.`;
  } else {
    comment = `The order was confirmed by ${confirmer} (User ID: ${userId}).`;
  }
}


   if (key === 'dispatched_date') {
  comment = `Order has been dispatched and handed over to ${data.delivery_partner || 'the assigned delivery partner'} for delivery.`
}
 
 if (key === 'delivery_completed_date') {
  let partnerName;
  
  if (data.delivery_partner === 'Store Pickup') {
    partnerName = 'Store Pickup';
    comment = `The order has been completed, and the customer, ${data.first_name}, has made the purchase at the store. Payment status: ${data.payment_status || 'unknown'}.`;
  } else {
    partnerName = data.delivery_partner || 'the assigned delivery partner';
    comment = `The order has been successfully completed and delivered to the customer, ${data.first_name}. Payment status: ${data.payment_status || 'unknown'}.`;
  }
}
if (key === 'returned_date') {
  comment = `The order has been returned for the following reason: ${data.reason_detail || 'not specified'}. The return was made by ${data.returned_person || 'the customer'}. Payment status: ${data.payment_status || 'unknown'}.`;
}

if (key === 'cancelled_date') {
  comment = `The order has been cancelled for the following reason: ${data.reason_detail || 'not specified'}.  Payment status: ${data.payment_status || 'unknown'}.`;
}




    return {
      id: idx,
      rawDate: new Date(date),
      title: statusMap[key]?.title || key,
      date: new Date(date).toLocaleString(),
      icon: statusMap[key]?.icon,
      variant: statusMap[key]?.variant,
      comment,
    }
  })
  .sort((a, b) => b.rawDate - a.rawDate)


  return (
    <CardBody className="pt-0 px-0">
      <SimplebarReactClient className="activity p-3 pt-0">
        {timeline.length === 0 ? (
          <div className="text-muted p-3">No timeline events found.</div>
        ) : (
          timeline.map(({ id, title, date, icon, variant, comment }) => (
            <div key={id} className="d-flex position-relative pb-2">
              <div
                className="position-absolute"
                style={{
                  borderLeft: '2px dashed #006daf',
                  height: '100%',
                  left: '20px',
                  top: 0,
                  zIndex: 0,
                }}></div>

              <div
                className="icon-info-activity"
                style={{
                  position: 'relative',
                  zIndex: 1,
                  width: '40px',
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'center',
                }}>
                <IconifyIcon
                  icon={icon || 'la:info-circle'}
                  height={40}
                  width={40}
                  className={variant || 'text-secondary'}
                  style={{
                    border: '2px solid #006daf',
                    borderRadius: '100%',
                    padding: '4px',
                    backgroundColor: '#fff',
                    alignSelf: 'flex-start',
                  }}
                />
              </div>
              <Card
                className="pt-2 px-3 ms-3 pe-4 w-100 shadow-sm bg-light border border-secondary-subtle position-relative"
                style={{ marginLeft: '40px' }} // Ensure space for arrow
              >
                {/* Arrow pointing to the timeline line */}
                <div
                  style={{
                    position: 'absolute',
                    left: '-8px',
                    top: '16px',
                    width: 0,
                    height: 0,
                    borderTop: '8px solid transparent',
                    borderBottom: '8px solid transparent',
                    borderRight: '8px solid #adb5bd', 
                  }}></div>

                <div className="activity-info-text">
                  <div className="d-flex justify-content-between align-items-center">
                    <h6 className="m-0 w-75 text-dark fw-semibold">{title}</h6>
                    <span className="text-dark small">{date}</span>
                  </div>
                  <p className="text-dark mt-3 mb-2">{comment}</p>
                </div>
              </Card>
            </div>
          ))
        )}
      </SimplebarReactClient>
    </CardBody>
  )
}

export default OrderTimeline
