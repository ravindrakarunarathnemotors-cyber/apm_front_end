// 'use client'

// import React, { useState } from 'react'
// import { Button, Spinner, Badge } from 'react-bootstrap'

// const ConfirmModal = ({
//   show,
//   onClose,
//   selectedOrderId,
//   handleAssignConfirm,
//   activePartnersData = [],
//   loadingPartners = false,
// }) => {
//     const [pendingKey, setPendingKey] = useState(null)
//     console.log('activePartnersData:', activePartnersData);
//   if (!show) return null

//   const runOnce = async (payload, key) => {
//     if (pendingKey) return          
//     try {
//       setPendingKey(key)            
//       await Promise.resolve(handleAssignConfirm?.(payload))
//     } finally {
//       setPendingKey(null)            
//     }
//   }

//   const allBlocked = Boolean(pendingKey)
//   const canClose = !allBlocked

// return (
//     <div
//       className="modal fade show d-block"
//       tabIndex="-1"
//       role="dialog"
//       style={{ backgroundColor: 'rgba(134, 136, 134, 0.5)' }}
//     >
//       <div className="modal-dialog" role="document">
//         <div className="modal-content">
//           <div className="modal-header">
//             <h5 className="modal-title">
//               Assign Courier Partner {selectedOrderId && `(Order #${selectedOrderId})`}
//             </h5>
//              <button
//               type="button"
//               className="btn-close"
//               onClick={canClose ? onClose : undefined}
//               disabled={!canClose}
//               aria-disabled={!canClose}
//               aria-busy={allBlocked}
//               title={!canClose ? 'Please wait…' : 'Close'}
//             />
//           </div>


//           <div className="modal-body" style={{ maxHeight: '65vh', overflowY: 'auto' }}>
//   {loadingPartners ? (
//     <div className="text-center my-3">
//       <Spinner animation="border" size="sm" />
//     </div>
//   ) : (
//     activePartnersData.map((partner) => {
//       const key = String(partner.value);
//       const isThisPending = pendingKey === key;
//       const isApi = partner.api_status === 'enable';
//       const isStorePickup = partner.label.toLowerCase().includes('store pickup');

//       return (
//         <Button
//           key={key}
//           variant="outline-primary"
//           className="mb-2 w-100 text-start d-flex justify-content-between align-items-center"
//           disabled={allBlocked}
//           onClick={() =>
//             runOnce(
//               isStorePickup
//                 ? { type: 'storepickup', partnerId: partner.value }
//                 : { type: 'delivery_partner', partnerId: partner.value },
//               key
//             )
//           }
//           aria-busy={isThisPending}
//         >
//           <span>
//             {isStorePickup ? '🏪' : '🚚'} {partner.label}
//           </span>

//           <span className="d-inline-flex align-items-center gap-2">
//             {isThisPending ? (
//               <Spinner animation="border" size="sm" />
//             ) : (
//               <span
//                 className={`badge rounded-pill bg-transparent ms-2 border ${
//                   isApi ? 'border-success text-dark' : 'border-danger text-dark'
//                 }`}
//               >
//                 {isApi ? 'Get API' : 'Get Waybill'}
//               </span>
//             )}
//           </span>
//         </Button>
//       );
//     })
//   )}
// </div>


//           <div className="modal-footer">
//             <Button
//               variant="secondary"
//               onClick={canClose ? onClose : undefined}
//               disabled={!canClose}
//             >
//               Cancel 
//             </Button>
//           </div>

//         </div>
//       </div>
//     </div>
//   )
// }

// export default ConfirmModal


// 'use client'

// import React, { useState, useEffect } from 'react'
// import { Button, Spinner,Form  } from 'react-bootstrap'
// import Swal from 'sweetalert2'   

// const ConfirmModal = ({
//   show,
//   onClose,
//   selectedOrderId,
//   handleAssignConfirm,
//   activePartnersData = [],
//   loadingPartners = false,
//   delivery_partner_id,
// }) => {
//   const [pendingKey, setPendingKey] = useState(null)
//   const [selectedKey, setSelectedKey] = useState(
//     delivery_partner_id ? String(delivery_partner_id) : null
//   )
//  console.log("delivery_partner_id",delivery_partner_id)

//   useEffect(() => {
//     if (delivery_partner_id) {
//       setSelectedKey(String(delivery_partner_id))
//     }
//   }, [delivery_partner_id])

//   if (!show) return null

// const confirmAndRun = async (payload, key) => {
//   if (pendingKey) return

//   const result = await Swal.fire({
//     title: 'Are you sure?',
//     text: 'Do you want to assign this Courier partner?',
//     icon: 'warning',
//     showCancelButton: true,
//     confirmButtonColor: '#3085d6',
//     cancelButtonColor: '#d33',
//     confirmButtonText: 'Yes, assign',
//     cancelButtonText: 'Cancel',
//     reverseButtons: true,
//   })

//   if (!result.isConfirmed) return

//   try {
//     setPendingKey(key)
//     const ok = await Promise.resolve(handleAssignConfirm?.(payload))
//    if (ok) onClose?.()
//   } catch (err) {
//     console.error("Assign error:", err);
//   } finally {
//     setPendingKey(null)
//   }
// }

//    const selectedPartner =
//     activePartnersData.find((p) => String(p.value) === selectedKey) || null

//   const handleAssignClick = () => {
//     if (!selectedPartner) return

//     const key = String(selectedPartner.value)
//     const isStorePickup = selectedPartner.label
//       .toLowerCase()
//       .includes('store pickup')

//     const payload = isStorePickup
//       ? { type: 'storepickup', partnerId: selectedPartner.value }
//       : { type: 'delivery_partner', partnerId: selectedPartner.value }

//     confirmAndRun(payload, key)
//   }

//    return (
//     <div
//       className="modal fade show d-block"
//       tabIndex="-1"
//       role="dialog"
//       style={{ backgroundColor: 'rgba(134, 136, 134, 0.5)' }}
//     >
//       <div className="modal-dialog modal-dialog-centered" role="document">

//         <div className="modal-content">
//           <div className="modal-header">
//             <h5 className="modal-title">
//               Assign Courier Partner{' '}
//               {selectedOrderId && `(Order #${selectedOrderId})`}
//             </h5>
//             <button
//               type="button"
//               className="btn-close"
//               onClick={onClose}
//             />
//           </div>

//           <div
//             className="modal-body"
//             style={{ maxHeight: '65vh', overflowY: 'auto' }}
//           >
//             {loadingPartners ? (
//               <div className="text-center my-3">
//                 <Spinner animation="border" size="sm" />
//               </div>
//             ) : (
//               activePartnersData.map((partner) => {
//                 const key = String(partner.value)
//                 const isThisPending = pendingKey === key
//                 const isApi = partner.api_status === 'enable'
//                 const isStorePickup = partner.label
//                   .toLowerCase()
//                   .includes('store pickup')
//                 const isChecked = selectedKey === key

//                 return (
//                   <div
//                     key={key}
//                     className="p-2 mb-2 border rounded d-flex justify-content-between align-items-center"
//                     style={{
//                       cursor: 'pointer',
//                       background: isChecked ? '#f8f9fa' : 'white',
//                     }}
//                     onClick={() => setSelectedKey(key)}
//                   >
//                     <div className="d-flex align-items-center gap-2">
//                       <Form.Check
//                         type="radio"
//                         name="delivery-partner"
//                         checked={isChecked}
//                         onChange={() => setSelectedKey(key)}
//                         onClick={(e) => e.stopPropagation()}
//                         className="custom-radio-green"
//                       />

//                       <span>
//                         {isStorePickup ? '🏪' : '🚚'} {partner.label}
//                       </span>
//                     </div>

//                     <span>
//                       {isThisPending ? (
//                         <Spinner animation="border" size="sm" />
//                       ) : (
//                         <span
//                           className={`badge rounded-pill bg-transparent ms-2 border ${
//                             isApi
//                               ? 'border-success text-dark'
//                               : 'border-danger text-dark'
//                           }`}
//                         >
//                           {isApi ? 'Get API' : 'Get Waybill'}
//                         </span>
//                       )}
//                     </span>
//                   </div>
//                 )
//               })
//             )}
//           </div>

//           <div className="modal-footer d-flex justify-content-between">
//             <Button variant="secondary" onClick={onClose}>
//               Cancel
//             </Button>

//             <Button
//               variant="primary"
//               onClick={handleAssignClick}
//               disabled={!selectedPartner || !!pendingKey}
//             >
//               {pendingKey ? (
//                 <>
//                   <Spinner animation="border" size="sm" className="me-2" />
//                   Assigning…
//                 </>
//               ) : (
//                 'Assign'
//               )}
//             </Button>
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

// export default ConfirmModal

'use client'

import React, { useState, useEffect } from 'react'
import { Button, Spinner, Form } from 'react-bootstrap'
import Swal from 'sweetalert2'

const ConfirmModal = ({
  show,
  onClose,
  selectedOrderId,
  handleAssignConfirm,
  activePartnersData = [],
  loadingPartners = false,
  delivery_partner_id,
}) => {
  const [pendingKey, setPendingKey] = useState(null)
  // selectedKey is string id of selected partner, or null when none selected
  const [selectedKey, setSelectedKey] = useState(
    delivery_partner_id ? String(delivery_partner_id) : null
  )

  useEffect(() => {
    if (delivery_partner_id) {
      setSelectedKey(String(delivery_partner_id))
    } else {
      setSelectedKey(null)
    }
  }, [delivery_partner_id])

  if (!show) return null

  const confirmAndRun = async (payload, key) => {
    if (pendingKey) return

    const result = await Swal.fire({
      title: 'Are you sure?',
      text: 'Do you want to assign this Courier partner?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, assign',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      setPendingKey(key)
      // handleAssignConfirm may return truthy on success
      const ok = await Promise.resolve(handleAssignConfirm?.(payload))
      if (ok) onClose?.()
    } catch (err) {
      console.error('Assign error:', err)
    } finally {
      setPendingKey(null)
    }
  }

  // Selected partner object (if any)
  const selectedPartner =
    selectedKey !== null
      ? activePartnersData.find((p) => String(p.value) === String(selectedKey)) || null
      : null

  const handleAssignClick = () => {
    // Allow partnerId to be null when nothing is selected
    const partnerId = selectedPartner ? selectedPartner.value : null

    const isStorePickup =
      selectedPartner && String(selectedPartner.label).toLowerCase().includes('store pickup')

    const payload = isStorePickup
      ? { type: 'storepickup', partnerId }
      : { type: 'delivery_partner', partnerId }

    // pending key: use 'null' for unassign/no partner
    const key = partnerId === null ? 'null' : String(partnerId)

    confirmAndRun(payload, key)
  }

  return (
    <div
      className="modal fade show d-block"
      tabIndex="-1"
      role="dialog"
      style={{ backgroundColor: 'rgba(134, 136, 134, 0.5)' }}
    >
      <div className="modal-dialog modal-dialog-centered" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">
              Assign Courier Partner {selectedOrderId && `(Order #${selectedOrderId})`}
            </h5>
            <button type="button" className="btn-close" onClick={onClose} />
          </div>

          <div className="modal-body" style={{ maxHeight: '65vh', overflowY: 'auto' }}>
            {loadingPartners ? (
              <div className="text-center my-3">
                <Spinner animation="border" size="sm" />
              </div>
            ) : (
              <>
                {activePartnersData.length === 0 ? (
                  <div className="text-center text-muted">No delivery partners available.</div>
                ) : (
                  activePartnersData.map((partner) => {
                    const key = String(partner.value)
                    const isThisPending = pendingKey === key
                    const isApi = partner.api_status === 'enable'
                    const isStorePickup = String(partner.label).toLowerCase().includes('store pickup')
                    const isChecked = selectedKey === key

                    return (
                      <div
                        key={key}
                        className="p-2 mb-2 border rounded d-flex justify-content-between align-items-center"
                        style={{
                          cursor: 'pointer',
                          background: isChecked ? '#f8f9fa' : 'white',
                        }}
                        onClick={() => setSelectedKey(key)}
                      >
                        <div className="d-flex align-items-center gap-2">
                          <Form.Check
                            type="radio"
                            name="delivery-partner"
                            checked={isChecked}
                            onChange={() => setSelectedKey(key)}
                            onClick={(e) => e.stopPropagation()}
                            className="custom-radio-green"
                          />

                          <span className="d-flex align-items-center gap-2">
                            <div style={{width:'120px'}}>

                            <img src={partner.logo} style={{maxWidth:'250px', width:'auto'}} alt={partner.label} height={20} />
                            </div>
                            {partner.label}
                          </span>
                        </div>

                        <span>
                          {isThisPending ? (
                            <Spinner animation="border" size="sm" />
                          ) : (
                            <span
                              className={`badge rounded-pill bg-transparent ms-2 border ${isApi ? 'border-success text-dark' : 'border-danger text-dark'
                                }`}
                            >
                              {isApi ? 'Get API' : 'Get Waybill'}
                            </span>
                          )}
                        </span>
                      </div>
                    )
                  })
                )}
              </>
            )}
          </div>

          <div className="modal-footer d-flex justify-content-between">
            <Button variant="secondary" onClick={onClose} disabled={!!pendingKey}>
              Cancel
            </Button>

            <Button variant="primary" onClick={handleAssignClick} disabled={!!pendingKey}>
              {pendingKey ? (
                <>
                  <Spinner animation="border" size="sm" className="me-2" />
                  Assigning…
                </>
              ) : (
                'Assign'
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ConfirmModal
