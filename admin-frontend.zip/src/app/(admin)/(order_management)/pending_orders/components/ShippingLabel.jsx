'use client'

import React, { useEffect, useRef, useState } from 'react'
import JsBarcode from 'jsbarcode'

const getFullUrl = (path) => {
  if (!path) return null
  if (path.startsWith('http')) return path
  return `https://yourdomain.com${path}`
}

const ShippingLabel4x4 = ({ order }) => {
  const canvasRef = useRef(null)
  const [barcodeImage, setBarcodeImage] = useState('')

  const {
    order_details = {},
    recipient_address = {},
    recipient_contact_info = {},
    customer_address = {},
    fromdetails = {}, // ✅ correct casing from API
  } = order || {}

  const trackingId = order_details?.tracking_id?.toString()
  const paymentReference = order_details?.payment_reference
  const currency = order_details?.currency || ''

  const formatAmount = (value) => {
    if (value === null || value === undefined || value === '') return '0.00'

    const num = Number(value)
    if (!Number.isFinite(num)) return '0.00'

    // Always force 2 decimal places
    return num.toFixed(2)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !trackingId) return

    const timeout = setTimeout(() => {
      try {
        JsBarcode(canvas, trackingId, {
          format: 'CODE128',
          lineColor: '#000',
          width: 1.5,
          height: 32,
          fontSize: 10,
          displayValue: false,
          margin: 0,
        })
        const dataUrl = canvas.toDataURL('image/png')
        if (dataUrl.length > 100) setBarcodeImage(dataUrl)
      } catch (err) {
        console.error('❌ Barcode generation failed:', err)
      }
    }, 50)

    return () => clearTimeout(timeout)
  }, [trackingId])

  return (
    <>
      <style>{`
  @page {
    size: 4in 4in;
    margin: 0;
  }
  html, body {
    margin: 0 !important;
    padding: 0 !important;
    box-sizing: border-box;
  }
  .page {
    width: 4in;
    height: 4in;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    page-break-after: always;
  }
  .label-wrapper {
    padding: 6mm;
    width: 100%;
    height: 100%;
    box-sizing: border-box;
  }
  .label-4x4 {
    width: 100%;
    height: 100%;
    border: 2px solid black;
    padding: 6px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-size: 11px;
  }
  .brand-logo {
    max-width: 45%;
  }
  .img-logo {
    max-height: 40px;
    max-width: 100%;
    object-fit: contain;
  }

  /* ✅ Fixed footer alignment */
  .footer-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 6px;
    margin-top: 4px;
  }
  .partner-logo,
  .barcode {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 40px; /* same height */
    box-sizing: border-box;
  }
  .partner-logo img,
  .barcode-img {
    height: 100%;
    width: auto;
    object-fit: contain;
    max-width: 100%;
  }
  .barcode {
    flex-direction: column;
  }
  .barcode-value {
    margin-top: 2px;
    font-size: 9px;
    text-align: center;
  }

  .hotline {
    text-align: center;
    font-weight: bold;
    font-size: 11px;
    margin-top: 1px;
  }
  .section-divider {
    border-top: 1px solid #ccc;
    margin: 2px 0;
  }
  .address-block {
    font-size: 12px;
    line-height: 1.3;
  }
  .address-block strong {
    font-size: 12px;
  }
  .note {
    font-size: 11px;
    margin-top: 2px;
  }
  canvas {
    display: none;
  }
`}</style>

      <div className="page">
        <div className="label-wrapper">
          <div className="label-4x4">
            {/* Header with Logo + Order info */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div className="brand-logo">
                {order_details.brand_logo ? <img src={getFullUrl(order_details.brand_logo)} alt="Brand Logo" className="img-logo" /> : 'brand_logo'}
              </div>
              <div style={{ textAlign: 'right', fontSize: '11px' }}>
                <div>
                  <strong>Order ID:</strong> {order_details.order_id || 'N/A'}
                </div>
                {trackingId && (
                  <div>
                    <strong>Tracking ID:</strong> {trackingId}
                  </div>
                )}
      {order_details.cod === true && (
                  <div
                    style={{
                      marginTop: '2px',
                      border: '1px solid black',
                      padding: '2px 6px',
                      display: 'inline-block',
                      fontWeight: 'bold',
                      fontSize: '12px',
                    }}>
                    {(() => {
                      const fullAmount = Number(order_details.full_amount || 0)
                      const amountPaid = Number(order_details.amount_paid || 0)
                      const isFullyPaid = (order_details.payment_status || '').toLowerCase() === 'paid'

                      if (amountPaid > 0 && !isFullyPaid) {
                        const due = fullAmount - amountPaid
                        return `COD: ${formatAmount(due)} ${currency}`
                      }

                      return `COD: ${formatAmount(fullAmount)} ${currency}`
                    })()}
                  </div>
                )}
              </div>
            </div>

            <div className="section-divider" />

            {/* Recipient */}
            <div className="address-block text-capitalize">
              <strong>To:</strong> {recipient_address.name || 'N/A'}
              <br />
              {recipient_address.address}  , {recipient_address.address_2 ? `${recipient_address.address_2}, ` : ''} 
              <br />
              {recipient_address.city}, {recipient_address.country}
              <br />
              <strong>Contact:</strong> {recipient_contact_info.contact || 'N/A'}
            </div>

            <div className="section-divider" />

            {/* From (always from fromdetails if available) */}
            <div className="address-block">
              <strong>From:</strong> {fromdetails.company_name || customer_address.name || 'N/A'}
              <br />
              {fromdetails.address_1 || customer_address.address}
              {fromdetails.address_2 && <>, {fromdetails.address_2}</>}
              <br />
              {fromdetails.hotline && (
                <>
                  <strong>Hotline:</strong> {fromdetails.hotline}
                </>
              )}
            </div>

            {/* Optional Notes */}
            {paymentReference && (
              <div className="note">
                <strong>Note:</strong> {paymentReference}
              </div>
            )}

            <div className="section-divider" />

            {/* Footer with Partner + Barcode */}
            <div className="footer-section ">
              <div className="partner-logo">
                {order_details.delivery_partner_logo ? (
                  <img src={getFullUrl(order_details.delivery_partner_logo)} alt="Partner Logo" className="img-logo" style={{ maxHeight: '28px' }} />
                ) : (
                  'Delivery Partner'
                )}
              </div>

              <div className="barcode">
                <canvas ref={canvasRef} width={140} height={40} />
                {barcodeImage ? (
                  <>
                    <img className="barcode-img" src={barcodeImage} alt="Barcode" />
                    <div className="barcode-value">{trackingId}</div>
                  </>
                ) : (
                  <span style={{ fontSize: 10, color: '#888' }}>Tracking ID not available</span>
                )}
              </div>
            </div>

            <div className="hotline">Hotline: {order_details.delivery_partner_contact || '+94XXXXXXX'}</div>
          </div>
        </div>
      </div>
    </>
  )
}

export default ShippingLabel4x4
