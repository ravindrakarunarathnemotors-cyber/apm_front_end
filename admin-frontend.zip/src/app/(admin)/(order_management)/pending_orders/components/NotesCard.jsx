'use client';

import { useEffect, useState } from 'react';
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Button,
  FormControl,
  Spinner,
} from 'react-bootstrap';
import {
  useGetOrderNoteQuery,
  useUpdateOrderNoteMutation,
} from '@/store/features/apiSlice'; // update path as needed

const NotesCard = ({ orderId, show }) => {
  const {
    data,
    isLoading,
    isFetching,
    refetch,    // <-- get refetch function
  } = useGetOrderNoteQuery(orderId, {
    skip: !orderId,
  });

  const [updateOrderNote, { isLoading: isUpdating }] = useUpdateOrderNoteMutation();

  const [noteText, setNoteText] = useState('');
  const [originalNote, setOriginalNote] = useState('');

  // Set note after fetched
  useEffect(() => {
    if (data?.note !== undefined) {
      setNoteText(data.note);
      setOriginalNote(data.note);
    }
  }, [data]);

  // Refetch when modal opens (show === true)
  useEffect(() => {
    if (show && orderId) {
      refetch();
    }
  }, [show, orderId, refetch]);

  const hasChanged = noteText.trim() !== originalNote.trim();

  const handleSaveOrUpdate = async () => {
    try {
      await updateOrderNote({ order_id: orderId, note: noteText }).unwrap();
      setOriginalNote(noteText);
    } catch (err) {
      console.error('Failed to update note:', err);
    }
  };

  return (
    <Card className="mb-3">
      <CardHeader className="bg-view py-2 d-flex justify-content-between align-items-center">
        <div>
          <CardTitle as="h4" className="text-dark mb-0">Notes</CardTitle>
          <small className="text-muted">Order ID: #{orderId || 'N/A'}</small>
        </div>
      </CardHeader>
      <CardBody>
        {!orderId ? (
          <div className="text-muted">Order ID is missing. Cannot load or update notes.</div>
        ) : isLoading || isFetching ? (
          <div className="d-flex align-items-center gap-2">
            <Spinner animation="border" size="sm" />
            <span>Loading note...</span>
          </div>
        ) : (
          <>
            <FormControl
              as="textarea"
              rows={3}
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Enter a note for this order..."
              className="mb-3"
            />
            {hasChanged && (
              <div className="d-flex justify-content-end">
                <Button
                  variant="primary"
                  onClick={handleSaveOrUpdate}
                  disabled={isUpdating}
                >
                  {isUpdating ? (
                    <>
                      <Spinner animation="border" size="sm" className="me-2" />
                      Saving...
                    </>
                  ) : (
                    originalNote ? 'Update' : 'Save'
                  )}
                </Button>
              </div>
            )}
          </>
        )}
      </CardBody>
    </Card>
  );
};

export default NotesCard;
