// 'use client';

// import { useEffect, useState } from 'react';
// import {
//   Card,
//   CardHeader,
//   CardTitle,
//   CardBody,
//   Button,
//   FormControl,
//   Spinner,
// } from 'react-bootstrap';

// import {
//   useGetDeliveryDetailsQuery,
//   useUpdateOrderNoteMutation,
// } from '@/store/features/apiSlice';

// const DeliverpatDetails = ({ orderId, show }) => {
//   const {
//     data,
//     isLoading,
//     isFetching,
//     refetch,
//   } = useGetDeliveryDetailsQuery(orderId, { skip: !orderId });

//   const [updateOrderNote, { isLoading: isUpdating }] =
//     useUpdateOrderNoteMutation();

//   const [noteText, setNoteText] = useState('');
//   const [originalNote, setOriginalNote] = useState('');

//   // Set note after fetch
//   useEffect(() => {
//     if (data?.note !== undefined) {
//       setNoteText(data.note);
//       setOriginalNote(data.note);
//     }
//   }, [data]);

//   // Refetch when modal opens
//   useEffect(() => {
//     if (show && orderId) {
//       refetch();
//     }
//   }, [show, orderId, refetch]);

//   const hasChanged = noteText.trim() !== originalNote.trim();

//   const handleSaveOrUpdate = async () => {
//     try {
//       await updateOrderNote({ order_id: orderId, note: noteText }).unwrap();
//       setOriginalNote(noteText);
//     } catch (err) {
//       console.error('Failed to update note:', err);
//     }
//   };

//   return (
//     <Card className="mb-3">
//       <CardHeader className="bg-view py-2 d-flex justify-content-between align-items-center">
//         <div>
//           <CardTitle as="h4" className="text-dark mb-0">Delivery Details</CardTitle>
       
//         </div>
//       </CardHeader>

//       <CardBody>
//         {!orderId ? (
//           <div className="text-muted">Order ID is missing. Cannot load details.</div>
//         ) : isLoading || isFetching ? (
//           <div className="d-flex align-items-center gap-2">
//             <Spinner animation="border" size="sm" />
//             <span>Loading details...</span>
//           </div>
//         ) : (
//           <>
//             {/* Partner Details */}
//             <div className="border rounded p-3 mb-3">
//               {/* <h5 className="mb-3">Partner Information</h5> */}
//               <div className="d-flex align-items-center gap-3 mb-2">
//                 <img
//                   src={data?.partner?.logo}
//                   alt={data?.partner?.name}
//                   style={{
//                     width: 60,
//                     height: 60,
//                     objectFit: 'contain',
//                     borderRadius: 8,
//                   }}
//                 />
//                 <div>
//                   <div><strong>Name:</strong> {data?.partner?.name || 'N/A'}</div>

//                   {/* Only show these fields if NOT Store Pickup */}
//                   {data?.partner?.name !== "Store Pickup" && (
//                     <>
//                       <div><strong>Tracking ID:</strong> {data?.tracking_id || 'N/A'}</div>
//                       <div><strong>Contact:</strong> {data?.partner?.contact_number || 'N/A'}</div>
//                       {/* <div><strong>Delivery Type ID:</strong> {data?.delivery_partner_id || 'N/A'}</div> */}
//                     </>
//                   )}
//                 </div>
//               </div>
//             </div>
// </>
//         )}
//       </CardBody>
//     </Card>
//   );
// };

// export default DeliverpatDetails;

'use client';

import { useEffect, useState } from 'react';
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Spinner,
} from 'react-bootstrap';

import {
  useGetDeliveryDetailsQuery,
  useUpdateOrderNoteMutation,
} from '@/store/features/apiSlice';

const DeliverpatDetails = ({ orderId, show }) => {
  const {
    data,
    isLoading,
    isFetching,
    refetch,
  } = useGetDeliveryDetailsQuery(orderId, { skip: !orderId });

  const [updateOrderNote, { isLoading: isUpdating }] =
    useUpdateOrderNoteMutation();

  const [noteText, setNoteText] = useState('');
  const [originalNote, setOriginalNote] = useState('');

  // Set note after fetch
  useEffect(() => {
    if (data?.note !== undefined) {
      setNoteText(data.note);
      setOriginalNote(data.note);
    }
  }, [data]);

  // Refetch when modal opens
  useEffect(() => {
    if (show && orderId) {
      refetch();
    }
  }, [show, orderId, refetch]);

  const hasChanged = noteText.trim() !== originalNote.trim();

  const handleSaveOrUpdate = async () => {
    try {
      await updateOrderNote({ order_id: orderId, note: noteText }).unwrap();
      setOriginalNote(noteText);
    } catch (err) {
      console.error('Failed to update note:', err);
    }
  };

  // Check if partner is assigned
  const partner = data?.partner;
  const noPartnerAssigned =
    !partner || // null or undefined
    (!partner?.name &&
      !partner?.logo &&
      !data?.tracking_id &&
      !partner?.contact_number);

  return (
    <Card className="mb-3">
      <CardHeader className="bg-view py-2 d-flex justify-content-between align-items-center">
        <div>
          <CardTitle as="h4" className="text-dark mb-0">Delivery Details</CardTitle>
        </div>
      </CardHeader>

      <CardBody>
        {!orderId ? (
          <div className="text-muted">Order ID is missing. Cannot load details.</div>
        ) : isLoading || isFetching ? (
          <div className="d-flex align-items-center gap-2">
            <Spinner animation="border" size="sm" />
            <span>Loading details...</span>
          </div>
        ) : (
          <>
            {/* Partner Details */}
            {noPartnerAssigned ? (
              <div className="">Delivery partner not assigned yet.</div>
            ) : (
              <div className="border rounded p-3 mb-3">
                <div className="d-flex align-items-center gap-3 mb-2">

                  {/* Only show logo if exists */}
                  {partner?.logo && (
                    <img
                      src={partner.logo}
                      alt={partner.name}
                      style={{
                        width: 60,
                        height: 60,
                        objectFit: 'contain',
                        borderRadius: 8,
                      }}
                    />
                  )}

                  <div>
                    <div><strong>Name:</strong> {partner?.name || 'N/A'}</div>

                    {/* Only show tracking/contact when NOT store pickup */}
                    {partner?.name !== "Store Pickup" && (
                      <>
                        {data?.tracking_id && (
                          <div><strong>Tracking ID:</strong> {data.tracking_id}</div>
                        )}
                        {partner?.contact_number && (
                          <div><strong>Contact:</strong> {partner.contact_number}</div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </CardBody>
    </Card>
  );
};

export default DeliverpatDetails;

