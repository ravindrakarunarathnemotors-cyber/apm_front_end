'use client'

import Image from 'next/image'
import { Button, Card, CardHeader, CardBody, Col, Row } from 'react-bootstrap'
import { currency } from '@/context/constants'
import logoSm from '@/assets/images/logo-sm.png'
import { Icon } from '@iconify/react'
import signature from '@/assets/images/extra/signature.png'
import { useState, useEffect } from 'react'

const Invoice = ({ order, onClose }) => {
  const orderDetails = order
  const [invoiceNumber, setInvoiceNumber] = useState('')
  const [issueDate, setIssueDate] = useState('')

  /**
   * Initialize a default invoice number and issue date when the component mounts
   * or when orderDetails becomes available.
   */
  useEffect(() => {
    if (!orderDetails) return

    // Default invoice number if none generated yet.
    if (!invoiceNumber) {
      // Prefer orderDetails.order_details.order_id (matches your data structure).
      const id = orderDetails?.order_details?.order_id ?? orderDetails?.order_id ?? '0000'
      // Keep consistent format: INV-<orderId>
      setInvoiceNumber(`${id}`)
    }

    // Default issue date shown on the invoice (human readable).
    if (!issueDate) {
      const now = new Date()
      setIssueDate(`${now.toLocaleDateString()} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`)
    }
  }, [orderDetails])

  // if (!orderDetails) return <div className="text-center p-5">No order data found.</div>

  const printInvoice = () => {
    const now = new Date()
    const formattedDate = now.toLocaleDateString()
    const formattedTime = now.toLocaleTimeString()
    setIssueDate(`${formattedDate} ${formattedTime}`)

    const randomSuffix = Math.floor(1000 + Math.random() * 9000)
    setInvoiceNumber(`INV-${order?.order_id}-${randomSuffix}`)

    setTimeout(() => {
      window.print()
    }, 200)
  }

  // normalize billing/shipping fields from API response to consistent local objects
  const bill = orderDetails?.customer_address ??
    orderDetails?.billing_address ??
    orderDetails?.bill_to ?? {
      name: orderDetails?.customer_name,
      address: orderDetails?.customer_address?.address,
      city: orderDetails?.customer_address?.city,
      postal_code: orderDetails?.customer_address?.postal_code,
      country: orderDetails?.customer_address?.country,
      email: orderDetails?.customer_address?.email,
      contact_number_1: orderDetails?.customer_contact || orderDetails?.customer_phone,
    }

  const ship = orderDetails?.recipient_address ??
    orderDetails?.shipping_address ??
    orderDetails?.ship_to ?? {
      name: orderDetails?.recipient_name,
      address: orderDetails?.recipient_address?.address,
      city: orderDetails?.recipient_address?.city,
      postal_code: orderDetails?.recipient_address?.postal_code,
      country: orderDetails?.recipient_address?.country,
      contact: orderDetails?.recipient_contact_info?.contact ?? orderDetails?.recipient_contact,
      email: orderDetails?.recipient_contact_info?.email ?? orderDetails?.recipient_email,
    }

  const normalizeText = (v = '') => v.toString().trim().toLowerCase().replace(/\s+/g, ' ')

  const normalizePhone = (v = '') => v.toString().replace(/\D/g, '')

  const normalizeAddress = (...parts) => parts.filter(Boolean).map(normalizeText).join(', ')

  const isSamePersonAndAddress = (() => {
    if (!bill || !ship) return false

    const sameName = normalizeText(bill.name) === normalizeText(ship.name)

    const sameAddress =
      normalizeAddress(bill.address, bill.city, bill.postal_code, bill.country) ===
      normalizeAddress(ship.address, ship.city, ship.postal_code, ship.country)

    // phone/email are OPTIONAL matches
    const phoneMatches = !ship.contact || normalizePhone(bill.contact_number_1) === normalizePhone(ship.contact)

    const emailMatches = !ship.email || normalizeText(bill.email) === normalizeText(ship.email)

    return sameName && sameAddress && phoneMatches && emailMatches
  })()

  // OPTIONAL: debug log (remove in production)
  useEffect(() => {
    console.log('Invoice received order object:', orderDetails)
    console.log('Mapped billing object (bill):', bill)
    console.log('Mapped shipping object (ship):', ship)
  }, [orderDetails])
  useEffect(() => {
    console.log('same?', isSamePersonAndAddress)
  }, [isSamePersonAndAddress])
  if (!orderDetails) return <div className="text-center p-5">No order data found.</div>

  // 🔹 Normalize measurement display casing
  const formatMeasurement = (raw = '') => {
    const v = raw.toLowerCase()
    if (v === 'g') return 'g'
    if (v === 'kg') return 'Kg'
    if (v === 'ml') return 'ml'
    if (v === 'l') return 'l'
    return raw
  }

  // ✅ show item discount column only if at least one item has item_discount
  const hasItemDiscount = orderDetails?.order_items?.some((it) => Number(it.item_discount || 0) > 0)

  // number of columns before the Amount column
  const summaryLabelColSpan = hasItemDiscount ? 3 : 2

  // summary must match table column count exactly
  const summaryCols = hasItemDiscount ? 5 : 4

  const summaryLabelStyle = {
    display: 'inline-flex',
    justifyContent: 'flex-end',
    minWidth: '100px',
  }

  return (
    <Row id="invoice-print">
      <Col xs={12}>
        <style jsx global>{`
          /* Absolute override for invoice header/background */
          /* Highest-specificity selectors: id + class + element + child */
          #invoice-print.invoice-root,
          #invoice-print.invoice-root .invoice-card,
          #invoice-print.invoice-root .invoice-card.card,
          #invoice-print.invoice-root .invoice-card.card > .card-body.invoice-header-print,
          #invoice-print.invoice-root .invoice-card.card > .card-header.invoice-header-print,
          #invoice-print.invoice-root .invoice-card.card > .card-body.invoice-header-print *,
          #invoice-print.invoice-root .invoice-card.card > .card-header.invoice-header-print * {
            background-color: #ffffff !important;
            background-image: none !important;
            box-shadow: none !important;
            color: #111827 !important;
            -webkit-print-color-adjust: exact !important;
            backdrop-filter: none !important;
          }

          /* clear gradient or image backgrounds applied to parent .card */
          #invoice-print.invoice-root .invoice-card,
          #invoice-print.invoice-root .invoice-card::before,
          #invoice-print.invoice-root .invoice-card::after {
            background-image: none !important;
            background: #ffffff !important;
            box-shadow: none !important;
            content: none !important;
          }

          /* clear utility BG classes within this invoice */
          #invoice-print.invoice-root .invoice-card .bg-light,
          #invoice-print.invoice-root .invoice-card .bg-secondary,
          #invoice-print.invoice-root .invoice-card .bg-gray,
          #invoice-print.invoice-root .invoice-card .bg-white {
            background: #ffffff !important;
            background-image: none !important;
          }

          /* remove any pseudo-element overlays on header */
          #invoice-print.invoice-root .invoice-card > .card-body.invoice-header-print::before,
          #invoice-print.invoice-root .invoice-card > .card-body.invoice-header-print::after,
          #invoice-print.invoice-root .invoice-card > .card-header.invoice-header-print::before,
          #invoice-print.invoice-root .invoice-card > .card-header.invoice-header-print::after {
            background-color: #ffffff !important;
            background-image: none !important;
            box-shadow: none !important;
            content: none !important;
          }

          /* print isolation + keep header white when printing */
          @media print {
            body * {
              visibility: hidden !important;
            }
            #invoice-print,
            #invoice-print * {
              visibility: visible !important;
            }
            #invoice-print.invoice-root {
              position: absolute !important;
              left: 50% !important;
              top: 0 !important;
              transform: translateX(-50%) !important;
              width: 794px !important;
              background: #ffffff !important;
              padding: 20px !important;
              z-index: 9999 !important;
              box-sizing: border-box !important;
              -webkit-print-color-adjust: exact !important;
              page-break-inside: avoid !important;
            }
            #invoice-print.invoice-root .invoice-card,
            #invoice-print.invoice-root .invoice-card > .card-body.invoice-header-print,
            #invoice-print.invoice-root .invoice-card > .card-header.invoice-header-print {
              background-color: #ffffff !important;
              background-image: none !important;
              color: #000 !important;
              box-shadow: none !important;
              border-bottom: 1px solid #e6e9ee !important;
            }
            .d-print-none {
              display: none !important;
            }
            img {
              -webkit-print-color-adjust: exact !important;
            }
          }

          /* small screens */
          @media (max-width: 820px) {
            #invoice-print.invoice-root {
              width: 100% !important;
              padding: 12px !important;
              left: 0 !important;
              transform: none !important;
            }
          }
        `}</style>

        <Card
          className="invoice-card bg-white"
          style={{
            border: '1px solid #e6e9ee',
            borderRadius: 8,
            boxShadow: '0 6px 18px rgba(16,24,40,0.06)',
            overflow: 'hidden',
            background: '#ffffff',
          }}>
          {/* header uses the invoice-header-print class for the CSS above to apply */}
          <CardHeader className=" py-3 px-4 bg-white border-bottom">
            <Row className="align-items-center">
              <Col xs={6} className="d-flex align-items-center ">
                {orderDetails?.order_details?.brand_logo && (
                  <Image
                    src={orderDetails.order_details.brand_logo}
                    alt="Brand Logo"
                    height={50}
                    width={120}
                    style={{
                      objectFit: 'contain',
                      borderRadius: 6,
                    }}
                  />
                )}
                {orderDetails?.order_details?.company_name && (
                  <div className="ms-3">
                    <h5 className="mb-0 fw-bold text-dark">{orderDetails.order_details.company_name}</h5>
                    {orderDetails?.order_details?.company_address && (
                      <small className="text-muted d-block">{orderDetails.order_details.company_address}</small>
                    )}
                  </div>
                )}
              </Col>

              <Col xs={6} className="text-end">
                <div
                  style={{
                    marginBottom: 6,
                    display: 'flex',
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                    gap: 8,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                  title={invoiceNumber || `INV-${orderDetails?.order_details?.order_id ?? orderDetails?.order_id ?? ''}`}>
                  <div
                    style={{
                      flex: '0 0 auto',
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      color: '#000000',
                    }}>
                    Order ID:
                  </div>

                  <div
                    style={{
                      flex: '0 1 auto',
                      minWidth: 0,
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      fontFamily: 'monospace',
                      color: '#000',
                    }}>
                    {invoiceNumber || `INV-${orderDetails?.order_details?.order_id ?? orderDetails?.order_id ?? ''}`}
                  </div>
                </div>

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'flex-end',
                    gap: 10,
                    alignItems: 'center',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                  title={
                    issueDate || `${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                  }>
                  {/* Label */}
                  <div
                    style={{
                      flex: '0 0 auto',
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      color: '#0d0d0e',
                    }}>
                    Issue Date:
                  </div>

                  {/* Value */}
                  <div
                    style={{
                      flex: '0 1 auto',
                      minWidth: 0,
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      color: '#000',
                    }}>
                    {issueDate || `${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                  </div>
                </div>
              </Col>
            </Row>
          </CardHeader>

          <CardBody className="py-3 px-4 bg-white">
            <Row className="g-3 mt-2 mb-3">
              {/* Invoice To */}
              <Col xs={12} md={6}>
                <div>
                  <h6 className="fw-bold text-uppercase mb-2" style={{ color: '#000', fontSize: '0.84rem', letterSpacing: '0.3px' }}>
                    {isSamePersonAndAddress ? 'Invoice & Ship To' : 'Invoice To'}
                  </h6>

                  <div style={{ fontSize: '0.81rem', lineHeight: 1.4 }} className="text-muted">
                    {bill?.name && <div style={{ textTransform: 'capitalize' }}>{bill.name}</div>}

                    {bill?.email && <div>{bill.email}</div>}

                    {(bill?.contact_number_1 || bill?.contact_number_2) && (
                      <div>{[bill.contact_number_1, bill.contact_number_2].filter(Boolean).join(' / ')}</div>
                    )}

                    {(bill?.address || bill?.city || bill?.postal_code || bill?.country) && (
                      <div>
                        {[bill.address, bill.city ? `${bill.city}${bill.postal_code ? ', ' + bill.postal_code : ''}` : null, bill.country]
                          .filter(Boolean)
                          .join(', ')}
                      </div>
                    )}
                  </div>
                </div>
              </Col>

              {/* Shipped To */}
              {!isSamePersonAndAddress && (
                <Col xs={12} md={6}>
                  <div>
                    <h6 className="fw-bold text-uppercase mb-2" style={{ color: '#0d6efd', fontSize: '0.84rem', letterSpacing: '0.3px' }}>
                      Shipped To
                    </h6>

                    <div style={{ fontSize: '0.81rem', lineHeight: 1.4 }} className="text-muted">
                      {ship?.name && <div style={{ textTransform: 'capitalize' }}>{ship.name}</div>}

                      {(orderDetails?.recipient_contact_info?.email || ship?.email) && (
                        <div>{orderDetails?.recipient_contact_info?.email ?? ship?.email}</div>
                      )}

                      {(orderDetails?.recipient_contact_info?.contact || ship?.contact) && (
                        <div>
                          {[orderDetails?.recipient_contact_info?.contact, orderDetails?.recipient_contact_info?.contact_two, ship?.contact]
                            .filter(Boolean)
                            .join(' / ')}
                        </div>
                      )}

                      {(ship?.address || ship?.city || ship?.postal_code || ship?.country) && (
                        <div>
                          {[ship.address, ship.city ? `${ship.city}${ship.postal_code ? ', ' + ship.postal_code : ''}` : null, ship.country]
                            .filter(Boolean)
                            .join(', ')}
                        </div>
                      )}
                    </div>
                  </div>
                </Col>
              )}
            </Row>

            <Row>
              <Col lg={12}>
                <div className="table-responsive project-invoice">
                  <table
                    className="table table-bordered mb-0 "
                    style={{ fontSize: '0.78rem' }} // <-- Smaller consistent font
                  >
                    <thead className="table-light py-2">
                      <tr>
                        <th>Order Details</th>
                        <th className="text-center text-nowrap">Quantity</th>
                        <th className="text-end text-nowrap">Unit Price ({orderDetails?.order_details?.currency})</th>

                        {hasItemDiscount && <th className="text-end text-nowrap">Discount</th>}

                        <th className="text-end text-nowrap">Amount ({orderDetails?.order_details?.currency})</th>
                      </tr>
                    </thead>

                    <tbody>
                      {orderDetails?.order_items?.map((item, index) => (
                        <tr key={index}>
                          <td>
                            <div
                              style={{
                                fontSize: '0.75rem',
                                fontWeight: 400,
                                marginBottom: '2px',
                                lineHeight: 1.2,
                                color: '#000',
                              }}>
                              {(() => {
                                // ===== GET VARIANT ID =====
                                let idsRaw = item.variant_id ?? item.variant_ids ?? item.variant?.id ?? ''
                                idsRaw = idsRaw == null ? '' : String(idsRaw)

                                let firstId = ''
                                if (idsRaw.includes('/')) firstId = idsRaw.split('/')[0]
                                else if (idsRaw.includes(',')) firstId = idsRaw.split(',')[0]
                                else firstId = idsRaw

                                // ===== GET VARIANT VALUES =====
                                const rawValues = String(item.variant_value || '')
                                  .split('/')
                                  .map((v) => v.trim())
                                  .filter(Boolean)

                                // ✅ hide ONLY if single value = default
                                const isOnlyDefault = rawValues.length === 1 && rawValues[0].toLowerCase() === 'default'

                                const variantText = !isOnlyDefault && rawValues.length ? rawValues.join(' / ') : ''

                                // ===== MEASUREMENT (HIDE PCS) =====
                                const rawMeasurement = (item.measurement_value || '').toString().trim().toLowerCase()

                                const hideMeasurement = ['pcs', 'pc', 'piece', 'pieces'].includes(rawMeasurement)

                                const measurement = !hideMeasurement && rawMeasurement ? ` ${item.measurement_value}` : ''

                                // ===== FINAL TEXT =====
                                let title = item.product_title

                                if (firstId) {
                                  title = `${firstId} - ${title}`
                                }

                                if (variantText) {
                                  title += ` (${variantText}${measurement})`
                                } else if (measurement) {
                                  title += ` (${measurement.trim()})`
                                }

                                return title
                              })()}
                            </div>
                          </td>
                          <td className="text-end text-nowrap">
                            {(() => {
                              const qty = Number(item.quantity || 0)
                              const freeQty = Number(item.free_quantity || 0)

                              const unitRaw = (item.measurement_value || '').toString().trim()
                              const unit = unitRaw.toLowerCase()
                              const perUnit = Number(item.amount_per_unit || 0)

                              const isPCS = ['pcs', 'pc', 'piece', 'pieces'].includes(unit)

                              // ===== MAIN QTY DISPLAY (MATCHES VIEW LOGIC) =====
                              let qtyText = ''
                              if (isPCS) {
                                qtyText = `${qty}`
                              } else if (perUnit > 0) {
                                qtyText = `${qty * perUnit}${formatMeasurement(unitRaw)}`
                              } else {
                                qtyText = `${qty}${formatMeasurement(unitRaw)}`
                              }

                              // ===== FREE QTY DISPLAY =====
                              let freeText = null
                              if (freeQty > 0) {
                                if (isPCS) {
                                  freeText = `${freeQty} FREE`
                                } else if (perUnit > 0) {
                                  freeText = `${freeQty * perUnit}${formatMeasurement(unitRaw)} FREE`
                                } else {
                                  freeText = `${freeQty}${formatMeasurement(unitRaw)} FREE`
                                }
                              }

                              return (
                                <>
                                  <span>{qtyText}</span>
                                  {freeText && (
                                    <>
                                      {' '}
                                      + <span className="text-success fw-semibold">{freeText}</span>
                                    </>
                                  )}
                                </>
                              )
                            })()}
                          </td>

                          {(() => {
                            const qty = Number(item.quantity) || 0
                            const unitPrice = Number(item.unit_price) || 0

                            const baseTotal = qty * unitPrice

                            const explicitTotal = Number(item.total_price)
                            const lineTotal = Number.isFinite(explicitTotal) && explicitTotal > 0 ? explicitTotal : baseTotal

                            const itemDiscount = Number(item.item_discount || 0)
                            const discountValue = itemDiscount * qty
                            const hasDiscount = discountValue > 0

                            const discountedTotal = hasDiscount ? lineTotal - discountValue : lineTotal

                            return (
                              <>
                                {/* Unit Price */}
                                <td className="text-end">{unitPrice.toFixed(2)}</td>

                                {/* Discount */}
                                {hasItemDiscount && <td className="text-end fw-semibold">{hasDiscount ? `-${discountValue.toFixed(2)}` : '—'}</td>}

                                {/* Amount */}
                                <td className="text-end">
                                  {hasDiscount ? (
                                    <>
                                      <div
                                        style={{
                                          textDecoration: 'line-through',
                                          color: '#6b7280',
                                          fontSize: '0.72rem',
                                        }}>
                                        {lineTotal.toFixed(2)}
                                      </div>
                                      <div>{discountedTotal.toFixed(2)}</div>
                                    </>
                                  ) : (
                                    lineTotal.toFixed(2)
                                  )}
                                </td>
                              </>
                            )
                          })()}
                        </tr>
                      ))}

                      {/* ===== SUMMARY (ALIGNED + COMPACT) ===== */}

                      {/* Subtotal */}
                      <tr className="border-0">
                        <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                          <b style={summaryLabelStyle}>Subtotal</b>
                        </td>
                        <td className="border-0 text-end ps-1">
                          <b>{Number(orderDetails?.order_details?.total_value || 0).toFixed(2)}</b>
                        </td>
                      </tr>

                      {/* Delivery Fee */}
                      {Number(orderDetails?.order_details?.delivery_fee || 0) > 0 && (
                        <tr className="border-0">
                          <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                            <b style={summaryLabelStyle}>Delivery Fee</b>
                          </td>
                          <td className="border-0 text-end ps-1">
                            <b>{Number(orderDetails?.order_details?.delivery_fee || 0).toFixed(2)}</b>
                          </td>
                        </tr>
                      )}

                      {/* Tax */}
                      {orderDetails?.order_details?.tax && Number(orderDetails.order_details.tax.value || 0) > 0 && (
                        <tr className="border-0">
                          <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                            <b style={summaryLabelStyle}>{orderDetails.order_details.tax.name || 'Tax'}</b>
                          </td>
                          <td className="border-0 text-end ps-1">
                            <b>{Number(orderDetails?.order_details?.tax?.value || 0).toFixed(2)}</b>
                          </td>
                        </tr>
                      )}

                      {/* Discount */}
                      {(() => {
                        const discount = Number(orderDetails?.order_details?.discount || 0)
                        const type = orderDetails?.order_details?.discount_type

                        const allowed = ['order', 'manual', 'code', 'payment_method']
                        if (discount <= 0 || !allowed.includes(type)) return null

                        const label = type === 'code' ? 'Promo Code' : `${type.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())} Discount`

                        return (
                          <tr className="border-0">
                            <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                              <b style={summaryLabelStyle}>{label}</b>
                            </td>
                            <td className="border-0 text-end ps-1">
                              <b>-{discount.toFixed(2)}</b>
                            </td>
                          </tr>
                        )
                      })()}

                      {(() => {
                        const discount = Number(orderDetails?.order_details?.discount || 0)
                        const type = orderDetails?.order_details?.discount_type

                        if (type !== 'shipping' || discount <= 0) return null

                        return (
                          <tr className="border-0">
                            <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                              <b style={summaryLabelStyle}>Delivery Fee Discount</b>
                            </td>
                            <td className="border-0 text-end ps-1">
                              <b>-{discount.toFixed(2)}</b>
                            </td>
                          </tr>
                        )
                      })()}

                      {/* Loyalty Points */}
                      {Number(orderDetails?.order_details?.loyalty_points_spent || 0) > 0 && (
                        <tr className="border-0">
                          <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                            <b
                              style={{
                                display: 'inline-flex',
                                justifyContent: 'flex-start',
                                minWidth: '100px',
                              }}>
                              Loyalty Points Redeemed
                            </b>
                          </td>
                          <td className="border-0 text-end ps-1">
                            <b>{orderDetails.order_details.loyalty_points_spent}</b>
                          </td>
                        </tr>
                      )}

                      {(() => {
                        const loyalty = Number(orderDetails?.order_details?.loyalty_points_spent || 0)
                        if (loyalty <= 0) return null

                        const currency = orderDetails?.order_details?.currency || ''
                        const fullAmount = Number(orderDetails?.order_details?.full_amount || 0)

                        return (
                          <tr className="border-0">
                            <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                              <b style={summaryLabelStyle}>Total</b>
                            </td>
                            <td className="border-0 text-end ps-1">
                              <b>
                                {(fullAmount + loyalty).toFixed(2)} {currency}
                              </b>
                            </td>
                          </tr>
                        )
                      })()}

           {/* Grand Total */}

                      <tr className="border-0">
                        <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                          <b style={summaryLabelStyle}>{Number(orderDetails?.order_details?.loyalty_points_spent || 0) > 0 ? 'Balance' : 'Total'}</b>
                        </td>

                        <td className="border-0 text-end ps-1">
                          <hr className="m-0 my-1" />
                          <b>
                            {(() => {
                              const currency = orderDetails?.order_details?.currency || ''

                              const loyalty = Number(orderDetails?.order_details?.loyalty_points_spent || 0)

                              const hasFullAmount =
                                orderDetails?.order_details?.full_amount !== null &&
                                orderDetails?.order_details?.full_amount !== undefined &&
                                orderDetails?.order_details?.full_amount !== ''

                              const computed =
                                Number(orderDetails?.order_details?.total_value || 0) +
                                Number(orderDetails?.order_details?.delivery_fee || 0) -
                                Number(orderDetails?.order_details?.discount || 0) +
                                Number(orderDetails?.order_details?.tax?.value || 0)

                              const total = hasFullAmount ? Number(orderDetails.order_details.full_amount) : computed

                              return Number.isFinite(total) ? `${total.toFixed(2)} ${currency}` : `0.00 ${currency}`
                            })()}
                          </b>
                          <hr className="m-0 my-1" />
                        </td>
                      </tr>

                      {/* Paid & Due Balance — only when partially paid */}
                      {(() => {
                        const amountPaid = Number(orderDetails?.order_details?.amount_paid || 0)
                        const isFullyPaid = (orderDetails?.order_details?.payment_status || '').toLowerCase() === 'paid'

                        if (amountPaid <= 0 || isFullyPaid) return null

                        const currency = orderDetails?.order_details?.currency || ''

                        const hasFullAmount =
                          orderDetails?.order_details?.full_amount !== null &&
                          orderDetails?.order_details?.full_amount !== undefined &&
                          orderDetails?.order_details?.full_amount !== ''

                        const computed =
                          Number(orderDetails?.order_details?.total_value || 0) +
                          Number(orderDetails?.order_details?.delivery_fee || 0) -
                          Number(orderDetails?.order_details?.discount || 0) +
                          Number(orderDetails?.order_details?.tax?.value || 0)

                        const totalValue = hasFullAmount ? Number(orderDetails.order_details.full_amount) : computed
                        const dueBalance = totalValue - amountPaid

                return (
                          <>
                            <tr className="border-0">
                              <td colSpan={summaryCols - 1} className="border-0 text-end pe-1">
                                <b style={summaryLabelStyle}>Paid</b>
                              </td>
                              <td className="border-0 text-end ps-1">
                                <b>{amountPaid.toFixed(2)} {currency}</b>
                              </td>
                            </tr>
                            <tr className="border-0">
                              <td colSpan={summaryCols - 1} className="border-0 text-end pe-1" style={{ borderTop: '2px solid #374151', borderBottom: '2px solid #374151', borderLeft: '2px solid #374151', borderRadius: '4px 0 0 4px', padding: '4px 4px 4px 8px' }}>
                                <b style={summaryLabelStyle}>Due Balance</b>
                              </td>
                              <td className="border-0 text-end ps-1" style={{ borderTop: '2px solid #374151', borderBottom: '2px solid #374151', borderRight: '2px solid #374151', borderRadius: '0 4px 4px 0', padding: '4px 8px 4px 4px' }}>
                                <b>{dueBalance.toFixed(2)} {currency}</b>
                              </td>
                            </tr>
                          </>
                        )
                      })()}
                    </tbody>
                  </table>
                </div>
              </Col>
            </Row>
            <Row className="d-flex justify-content-between align-items-start mt-2">
              <Col md={9} lg={6}>
                {/* Parse & render terms from API (defensive: handles JSON string or array) */}
                {(() => {
                  const raw = orderDetails?.system_settings?.terms_conditions ?? orderDetails?.system_settings?.terms_and_conditions ?? null

                  let termsArray = []

                  if (raw) {
                    try {
                      // If it's already an array, use it directly
                      if (Array.isArray(raw)) {
                        termsArray = raw
                      } else if (typeof raw === 'string') {
                        // Try to parse JSON string (common case)
                        const parsed = JSON.parse(raw)
                        if (Array.isArray(parsed)) termsArray = parsed
                        else if (typeof parsed === 'string' && parsed.length) termsArray = [parsed]
                      } else {
                        // fallback: coerce to string
                        termsArray = [String(raw)]
                      }
                    } catch (e) {
                      // fall back to splitting on newlines if JSON.parse fails
                      if (typeof raw === 'string') {
                        termsArray = raw
                          .split(/\r?\n/)
                          .map((s) => s.trim())
                          .filter(Boolean)
                      }
                    }
                  }

                  // If nothing found, show a friendly fallback
                  if (!termsArray || termsArray.length === 0) {
                    return (
                      <>
                        <h5 className="mt-4">Terms And Condition :</h5>
                        <p className="text-muted">
                          <small>No terms available.</small>
                        </p>
                      </>
                    )
                  }

                  // If first item contains the heading text, drop it from bullets
                  const headingCandidates = ['terms and condition', 'terms and conditions', 'terms_conditions']
                  let heading = 'Terms And Condition :'
                  if (termsArray.length > 0) {
                    const first = String(termsArray[0])
                      .toLowerCase()
                      .replace(/[:\s]+$/, '')
                      .trim()
                    if (headingCandidates.some((h) => first.includes(h.replace(/\s+/g, '')) || first.includes(h))) {
                      termsArray = termsArray.slice(1)
                    }
                  }

                  return (
                    <>
                      <h5
                        className="mt-4 pt-3"
                        style={{
                          fontSize: '0.78rem',
                          fontWeight: 'bold',
                        }}>
                        {heading}
                      </h5>
                      <ul
                        className="ps-4"
                        style={{
                          fontSize: '0.75rem',
                        }}>
                        {termsArray.map((t, i) => (
                          <li key={i}>
                            <small className="fs-12">{String(t)}</small>
                          </li>
                        ))}
                      </ul>
                    </>
                  )
                })()}
              </Col>

        <Col md={3} lg={6} className="align-self-end d-flex justify-content-end">
                {(() => {
                  const isFullyPaid = (orderDetails?.order_details?.payment_status || '').toLowerCase() === 'paid'
                  const amountPaid = Number(orderDetails?.order_details?.amount_paid || 0)
                  const isPartiallyPaid = !isFullyPaid && amountPaid > 0

                  const bg = isFullyPaid ? '#d4edda' : isPartiallyPaid ? '#fff3cd' : '#f8d7da'
                  const borderColor = isFullyPaid ? '#28a745' : isPartiallyPaid ? '#ffc107' : '#dc3545'
                  const color = isFullyPaid ? '#155724' : isPartiallyPaid ? '#856404' : '#721c24'
                  const label = isFullyPaid ? 'PAID' : isPartiallyPaid ? 'PARTIALLY PAID' : 'NOT PAID'

             return (
                    <div
                      className="d-flex flex-column align-items-center p-3 rounded shadow mt-4"
                      style={{
                        minWidth: '160px',
                        maxWidth: '200px',
                        backgroundColor: bg,
                        border: `2px solid ${borderColor}`,
                        color,
                        fontWeight: 'bold',
                        fontSize: '1rem',
                      }}>
                      <span style={{ fontSize: '0.9rem' }}>Payment Status</span>
                      <div
                        className="mt-2 text-uppercase text-center"
                        style={{
                          fontSize: isPartiallyPaid ? '0.75rem' : '1.2rem',
                          whiteSpace: 'nowrap',
                        }}>
                        {orderDetails?.order_details?.payment_status || label}
                      </div>
                    </div>
                  )
                })()}
              </Col>
            </Row>

            <hr />
            <Row className="d-flex justify-content-center">
              <Col lg={12} xl={4} className="ms-auto align-self-center">
                <div className="text-center">
                  <small
                    className="fs-12"
                    style={{
                      fontSize: '0.75rem',
                    }}>
                    Thank you very much for doing business with us.
                  </small>
                </div>
              </Col>
              <Col lg={12} xl={4}>
                <div className="float-end d-flex d-print-none mt-2 mt-md-0 gap-1">
                  <Button
                    variant="secondary"
                    title="Print Invoice"
                    onClick={() => {
                      // Format issue date
                      const now = new Date()
                      const formattedDate = now.toLocaleDateString()
                      const formattedTime = now.toLocaleTimeString()
                      setIssueDate(`${formattedDate} ${formattedTime}`)

                      // Generate invoice number (custom or use fallback)
                      const randomSuffix = Math.floor(1000 + Math.random() * 9000)
                      setInvoiceNumber(`INV-${order?.order_id}-${randomSuffix}`)

                      // Slight delay to ensure state updates before print
                      setTimeout(() => window.print(), 100)
                    }}>
                    <Icon icon="mdi:printer" width={18} style={{ marginRight: '4px' }} />
                    Print Invoice
                  </Button>

                  <Button variant="danger" onClick={onClose}>
                    Cancel
                  </Button>
                </div>
              </Col>
            </Row>
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default Invoice
