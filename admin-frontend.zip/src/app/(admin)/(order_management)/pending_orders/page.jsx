import React from 'react'
import PendingOrders from '../pending_orders/PendingOrders'

function page() {
  return (
    <>
    <PendingOrders/>
     
    </>
  )
}

export default page