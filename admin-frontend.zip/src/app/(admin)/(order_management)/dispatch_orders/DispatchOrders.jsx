'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Badge, Modal, Pagination } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import MarkAsPaidModal from '@/components/Order/MarkAsPaidModal'
import Select from 'react-select'
import View from '../pending_orders/components/view'
import {
  useGetFiltereddispatchedOrdersMutation,
  useGetRecipientnameQuery,
  useDeliverdOrderMutation,
  useReturnDispatchedOrderMutation,
  useProcessingOrdersOrderMutation,
  useGetResonsQuery,
} from '@/store/features/apiSlice'
import axios from 'axios'
import Swal from 'sweetalert2'
import axiosInstance from '@/lib/axiosInstance';

function DispatchOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
    keyword: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [dispatchedOrders, setDispatched] = useState([])
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const [searchRecipient, setSearchRecipient] = useState('')

  const [fetchcompletedOrders, { isLoading, error }] = useGetFiltereddispatchedOrdersMutation()
  const [deliverdOrder] = useDeliverdOrderMutation()
  const [processingOrder] = useProcessingOrdersOrderMutation()
  const [returnDispatchedOrder, { isLoading: isReturning }] = useReturnDispatchedOrderMutation()
  const { data: reasons, isLoading: isLoadingReasons, error: reasonsError } = useGetResonsQuery()

  const [showReturnModal, setShowReturnModal] = useState(false)
  const [selectedReason, setSelectedReason] = useState(null)
  const [customReason, setCustomReason] = useState('')
  const [returningIds, setReturningIds] = useState(new Set())

  const API_BASE = process.env.NEXT_PUBLIC_BASE_URL
  const [selectedPickup, setSelectedPickup] = useState(null) // 'yes' | 'no'
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)


  const postReturnOrder = async (order_id) => {
    const res = await axiosInstance.post(`/orders-sub/return-dispatched-order`, { order_id })
    return res.data
  }

  const handleClose = () => {
    setShowModal(false)
    setSelectedOrderId(null)
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)
    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  // normalize reasons
  const reasonList = Array.isArray(reasons) ? reasons : Array.isArray(reasons?.data) ? reasons.data : []
  const reasonOptions = (reasonList || []).map((r) => ({ value: r.reason_id, label: r.reason_detail }))
  const selectedOrder = dispatchedOrders.find((o) => o.order_id === selectedOrderId) || null
  const renderReturnReasonRadioButtons = () => {
    if (isLoadingReasons) return <p>Loading reasons...</p>
    if (reasonsError) return <p>Error fetching return reasons.</p>
    if (!reasonOptions.length) return <p>No reasons available.</p>
    const disableRadios = customReason.trim().length > 0
    const disableTextarea = !!selectedReason // if a radio is selected, disable textarea
    return (
      <>
        <Form>
          {reasonOptions.map((reason) => (
            <Form.Check
              key={reason.value}
              type="checkbox"
              label={reason.label}
              disabled={customReason.trim().length > 0} // disable checkbox when typing custom reason
              checked={selectedReason === reason.label} // only one checkbox checked
              onChange={(e) => {
                if (e.target.checked) {
                  setSelectedReason(reason.label) // store label text
                  setCustomReason('') // clear custom input
                } else {
                  setSelectedReason('') // uncheck
                }
              }}
            />
          ))}{' '}
        </Form>
        <Form.Group className="mt-3">
          <Form.Label>Or type your own reason:</Form.Label>
          <Form.Control
            as="textarea"
            rows={2}
            value={customReason}
            disabled={disableTextarea}
            onChange={(e) => {
              setCustomReason(e.target.value)
              if (e.target.value.trim().length > 0) setSelectedReason(null)
            }}
            placeholder="Write your reason here..."
          />
        </Form.Group>
      </>
    )
  }

  const handleReturn = (order_id) => {
    setSelectedOrderId(order_id)
    setSelectedReason(null)
    setCustomReason('')
    setShowReturnModal(true)
  }

  const handleCloseReturnModal = () => {
    setShowReturnModal(false)
    setSelectedOrderId(null)
    setCustomReason('')
    setSelectedReason(null)
  }

  const handleReturnConfirm = async () => {
    const reasonToSend = customReason.trim() || selectedReason

    if (!reasonToSend) {
      Swal.fire('Error', 'Please select a reason for returning the order.', 'error')
      return
    }

    try {
      const result = await Swal.fire({
        title: 'Return order?',
        text: `Do you want to mark order ${selectedOrderId} as returned?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, return it!',
        cancelButtonText: 'Cancel',
      })
      if (!result.isConfirmed) return

      await returnDispatchedOrder({
        order_id: selectedOrderId,
        reason_id: reasonToSend,
      }).unwrap()

      Swal.fire('Success', `Order ${selectedOrderId} has been marked as returned.`, 'success')
      setSelectedReason(null)
      setShowReturnModal(false)
      if (currentPage) fetchOrders(currentPage)
    } catch (err) {
      console.error('Return order error:', err)
      Swal.fire('Error', 'Failed to return order.', 'error')
    }
  }

  const printSectionRef = useRef(null)

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handlePayment = (ordId, storepickupVal, paymentMethodId) => {
    setSelectedOrderId(ordId)
    setSelectedPickup(storepickupVal ?? 'no')
    setSelectedPaymentMethodId(paymentMethodId ?? null)
    setShowPaymentModal(true)
  }

  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleUnpaidClick = (ordId) => {
    setSelectedOrderId(ordId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleDeliverd = async (ordId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to completed order ${ordId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, completed it!',
      cancelButtonText: 'No, keep it',
    })

    if (result.isConfirmed) {
      

      try {
        const res = await deliverdOrder({
          order_id: ordId,
          status: 'completed',
          user_id: 1,
        }).unwrap()

        Swal.fire('completed', res.message, 'success')
        fetchOrders(currentPage)
      } catch (err) {
        console.error('completed error:', err)
        Swal.fire('Error', 'Failed to completed the order.', 'error')
      }
    }
  }

  const fetchOrders = async (page, customLimit = limit) => {
    setLoading(true)

    try {
      const res = await fetchcompletedOrders({
        page,
        limit: customLimit,
        order_id: orderId,
        recipient_name: recipientName,
        keyword: filters.keyword,
        mobile: mobileNo,
        payment_status: paymentStatus,
        paymentMethod: paymentMethod,
        date,
        todate,
      }).unwrap()

      setDispatched(res.dispatchedOrders || [])
      setTotalPages(res.totalPages || 1)
      setTotalEntries(res.total || 0)
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch orders:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOrders(1)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleSearch = () => {
    fetchOrders(1)
  }

  const handleView = (order) => {
    setSelectedOrderId(order.order_id)
    setShowViewModal(true)
  }

  const activePartners = [
    { value: 'partner_a', label: 'Partner A' },
    { value: 'partner_b', label: 'Partner B' },
    { value: 'partner_c', label: 'Partner C' },
  ]

  const handleConfirm = (ordId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to Processing order ${ordId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Processing it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire('Processing', `Order ${ordId} has been Processing.`, 'info')
      }
    })
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'danger',
      refund: 'secondary',
      failed: 'danger',
    }
    const color = colorMap[status?.toLowerCase()] || 'secondary'
    const capitalizedStatus = status?.charAt(0).toUpperCase() + status?.slice(1)
    return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  }

  const handleModalConfirm = () => {
    if (!selectedPartner) {
      Swal.fire('Error', 'Please select a delivery partner', 'error')
      return
    }
    Swal.fire('Confirmed', `Order ${selectedOrderId} assigned to ${selectedPartner.label}.`, 'success')
    setShowModal(false)
    setSelectedOrderId(null)
    setSelectedPartner(null)
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) range.push(i)
    return range
  }

  const handleProcessing = async (ordId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to move order ${ordId} back to Processing?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, move it!',
      cancelButtonText: 'No, keep it',
    })

    if (!result.isConfirmed) return

    try {
      const res = await processingOrder({
        order_id: ordId,
        status: 'processing',
        user_id : 1,
      }).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Order moved to Processing',
        text: res.message || `Order ${ordId} status updated successfully.`,
        timer: 2000,
        showConfirmButton: false,
      })

      fetchOrders(currentPage)
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }

  const handlePrint = () => {
    if (!printSectionRef.current) return
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    if (!newWindow) return
    newWindow.document.write(`
      <html>
        <head>
          <title>Print Dispatch Orders</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
            .table-light { background-color: #f8f9fa; }
            .no-print { display: none !important; }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)
    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Dispatch Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({ ...prev, keyword: value }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({ ...prev, keyword: name }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({ ...prev, keyword: '' }))
                    }
                  }}
                  placeholder="ID, Client Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{ DropdownIndicator: null }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-5">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-2">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchOrders(1)}>
                  Search
                </Button>
                <Button variant="secondary" onClick={handlePrint} style={{ backgroundColor: '#6f42c1', borderColor: '#6f42c1' }}>
                  Print
                </Button>
              </FormGroup>
            </Form>

            <div ref={printSectionRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Tracking</th>
                    <th>Payment</th>
                    <th>Delivery Type</th>
                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {dispatchedOrders.length > 0 ? (
                    dispatchedOrders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>
                          {order.customer_name}
                          <br />
                          <small>{order.contact_number}</small>
                        </td>
                        <td>{order.tracking_id || '-'}</td>
                        <td>
                          {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}
                          {hasSlip(order) && (
                            <div className="mt-1 no-print">
                              <Button
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.2rem 0.1rem',
                                  fontSize: '0.55rem',
                                  height: '20px',
                                  borderRadius: '15px',
                                  backgroundColor: '#3d3642ff',
                                  borderColor: '#3d3642ff',
                                  color: '#fff',
                                }}
                                variant="outline-primary"
                                onClick={() => openSlip(order)}
                                title="Open bank slip"
                                className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                Slip
                              </Button>
                            </div>
                          )}
                        </td>
                        <td>{order.delivery_partner_name || '-'}</td>
                        <td className="text-end no-print">
                          <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => {
                                setSelectedOrderId(order.order_id)
                                setShowViewModal(true)
                              }}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>View</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#28a745',
                                borderColor: '#28a745',
                                color: '#fff',
                              }}
                              onClick={() => handleDeliverd(order.order_id)}>
                              <Icon icon="mdi:truck-check" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Completed</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#dc3545',
                                borderColor: '#dc3545',
                                color: '#fff',
                              }}
                              onClick={() => handleReturn(order.order_id)}
                              disabled={returningIds.has(order.order_id)}>
                              <Icon icon="mdi:undo" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>{returningIds.has(order.order_id) ? 'Returning...' : 'Return'}</span>
                            </Button>

                            {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )}

                            {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handlePayment(order.order_id, order.storepickup, order.payment_method_id)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )}

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#fd7e14',
                                borderColor: '#fd7e14',
                                color: '#fff',
                              }}
                              onClick={() => handleProcessing(order.order_id)}>
                              <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Back to Processing</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="text-center text-muted py-4">
                        No orders found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>

            {/* PAGINATION */}
            {/* PAGINATION */}
            <div className="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">

              {/* LEFT SIDE */}
              <div className="d-flex align-items-center gap-2">
                <span>Show</span>



                <Form.Select
                  value={limit}
                  onChange={(e) => {
                    const newLimit = Number(e.target.value)

                    setLimit(newLimit)
                    setCurrentPage(1)

                    fetchOrders(1, newLimit)
                  }}
                  style={{ width: '90px' }}
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </Form.Select>

                <span>entries</span>
              </div>

              {/* RIGHT SIDE */}
              <div className="d-flex align-items-center gap-3 flex-wrap">

                {/* SHOWING TEXT */}
                <div className="text-muted">
                  Showing{' '}
                  {dispatchedOrders.length === 0
                    ? 0
                    : (currentPage - 1) * limit + 1}
                  {' '}to{' '}
                  {(currentPage - 1) * limit + dispatchedOrders.length}
                  {' '}of {totalEntries} entries
                </div>

                {/* PAGINATION */}
                {totalPages > 1 && (
                  <Pagination className="mb-0">

                    {/* PREVIOUS */}
                    <Pagination.Prev
                      disabled={currentPage === 1}
                      onClick={() => fetchOrders(currentPage - 1)}
                    />

                    {/* PAGE NUMBERS */}
                    {(() => {
                      let pages = []

                      if (totalPages <= 5) {
                        for (let i = 1; i <= totalPages; i++) {
                          pages.push(
                            <Pagination.Item
                              key={i}
                              active={i === currentPage}
                              onClick={() => fetchOrders(i)}>
                              {i}
                            </Pagination.Item>,
                          )
                        }
                      } else {
                        let start = currentPage - 2
                        let end = currentPage + 2

                        if (start < 1) {
                          start = 1
                          end = 5
                        }

                        if (end > totalPages) {
                          end = totalPages
                          start = totalPages - 4
                        }

                        for (let i = start; i <= end; i++) {
                          pages.push(
                            <Pagination.Item
                              key={i}
                              active={i === currentPage}
                              onClick={() => fetchOrders(i)}>
                              {i}
                            </Pagination.Item>,
                          )
                        }
                      }

                      return pages
                    })()}

                    {/* NEXT */}
                    <Pagination.Next
                      disabled={currentPage === totalPages}
                      onClick={() => fetchOrders(currentPage + 1)}
                    />

                  </Pagination>
                )}
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>

      {showViewModal && (
        <View show={showViewModal} onClose={handleClose} order_id={selectedOrderId} context="dispatched" onMarkAsCompleted={handleDeliverd} />
      )}

      {showPaymentModal && selectedOrder && (
        <MarkAsPaidModal
          show={showPaymentModal}
          onClose={handlePaymentClose}
          order={selectedOrder}
          order_id={selectedOrderId}
          payment_method_id={selectedPaymentMethodId}
        />
      )}

      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}

      <Modal show={showReturnModal} onHide={handleCloseReturnModal} centered size="lg" style={{ border: '3px solid gray', borderRadius: '0.5rem' }}>
        <Modal.Header closeButton>
          <Modal.Title>Return Order ID {selectedOrderId}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h6 className="mb-2">Select Reason for Return</h6>
          {renderReturnReasonRadioButtons()}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseReturnModal}>
            Close
          </Button>
          <Button variant="danger" onClick={handleReturnConfirm} disabled={!(selectedReason || customReason.trim()) || isReturning}>
            {isReturning ? 'Returning…' : 'Confirm Return'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Row>
  )
}

export default DispatchOrders
