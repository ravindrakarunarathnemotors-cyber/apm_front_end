import React from 'react'
import DispatchOrders from '../dispatch_orders/DispatchOrders'

function page() {
  return (
    <>
    <DispatchOrders/>
     
    </>
  )
}

export default page