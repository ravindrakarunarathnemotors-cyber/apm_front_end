'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Button,
  Table,
  Pagination,
  Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from '../pending_orders/components/view'
import { useGetCancelledOrdersMutation, useGetRecipientnameQuery, useRestoreOrderMutation } from '@/store/features/apiSlice'
import { debounce } from 'lodash'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import MarkAsPaidModal from '@/components/Order/MarkAsPaidModal'

function CancelOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
  })

  // const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [getCancelledOrders, { data, isLoading }] = useGetCancelledOrdersMutation()
  const [restoreOrder, { isLoading: isRestoringOrder }] = useRestoreOrderMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showMarkAsPaidModal, setShowMarkAsPaidModal] = useState(false)
  const [selectedPaidOrder, setSelectedPaidOrder] = useState(null)
  const [currency, setCurrency] = useState('')

  const printRef = useRef()

  // const { data: recipientOptions = [], isLoading: isRecipientLoading } = useGetRecipientnameQuery(searchRecipient, { skip: !searchRecipient })
  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handlePageChange = (page) => {
    setCurrentPage(page)
    handleSearch()
  }

  useEffect(() => {
    handleSearch()
    setSearchTriggered(true)
  }, [currentPage]) // you can also include [] to only run on mount if you don't want page-based reloads

  const debouncedSearch = useCallback(
    debounce((val) => {
      setSearchRecipient(val)
    }, 300),
    [],
  )
  const handleMarkAsPaid = (order) => {
    setSelectedPaidOrder(order)
    setShowMarkAsPaidModal(true)
  }
  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleRestoreOrder = async (order) => {
    const result = await Swal.fire({
      title: 'Restore Cancelled Order?',
      html: `
      <div style="font-size:14px; text-align:left;">
        <p>
          Are you sure you want to restore
          <b>Order #${order.order_id}</b>?
        </p>

        <p>
          This order will be moved back to
          <b>Pending</b> status.
        </p>
      </div>
    `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#198754',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, Restore Order',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      const response = await restoreOrder({
        order_id: order.order_id,
      }).unwrap()

      await Swal.fire({
        title: 'Restored!',
        text: `Order #${order.order_id} has been restored to pending status.`,
        icon: 'success',
        timer: 2000,
        showConfirmButton: false,
      })

      handleSearch()
    } catch (error) {
      Swal.fire({
        title: 'Error',
        text: error?.data?.message || 'Failed to restore order',
        icon: 'error',
      })
    }
  }

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Cancelled Orders Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
          .no-print { display: none !important; }
        </style>
      </head>
      <body>
        <h2>Cancelled Orders Report</h2>
        ${printContents}
      </body>
    </html>
  `)
    newWindow.document.close()
    newWindow.print()
  }

  // Fetch cancelled orders on mount or filters/page change
  // useEffect(() => {
  //   const payload = {
  //     order_id: orderId,
  //     recipient_name: recipientName,
  //     mobile: mobileNo,
  //     date,
  //     page: currentPage,
  //     limit: 10,
  //   };

  //   getCancelledOrders(payload).then((res) => {
  //     if (res?.data?.totalPages) {
  //       setTotalPages(res.data.totalPages);
  //     }
  //   });
  // }, [orderId, recipientName, mobileNo, date, currentPage]);

  const [searchTriggered, setSearchTriggered] = useState(false)

  const handleSearch = async () => {
    const payload = {
      order_id: orderId,
      recipient_name: recipientName,
      mobile: mobileNo,
      keyword: filters.keyword,
      date,
      todate,
      page: currentPage,
      limit: 10,
    }

    const res = await getCancelledOrders(payload)
    const resp = res?.data ?? res
    if (res?.data?.totalPages) {
      setTotalPages(res.data.totalPages)
      setSearchTriggered(true) // prevent empty render before search
    }

    const firstCurrency = resp?.orders?.[0]?.currency ?? 'Rs.'
    setCurrency(firstCurrency)
  }

  // const totalPages = 1

  const handleView = (order) => {
    setSelectedOrderId(order.order_id) // ✅ Save correct ID
    setShowViewModal(true)
  }

  const activePartners = [
    { value: 'partner_a', label: 'Partner A' },
    { value: 'partner_b', label: 'Partner B' },
    { value: 'partner_c', label: 'Partner C' },
  ]

  const handleConfirm = (orderId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to Processing order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Processing it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire('Processing', `Order ${orderId} has been Processing.`, 'info')
      }
    })
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'danger',
      refund: 'secondary',
      failed: 'danger',
    }

    const color = colorMap[status] || 'secondary'
    const capitalizedStatus = status.charAt(0).toUpperCase() + status.slice(1)

    return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handleModalConfirm = () => {
    if (!selectedPartner) {
      Swal.fire('Error', 'Please select a delivery partner', 'error')
      return
    }

    Swal.fire('Confirmed', `Order ${selectedOrderId} assigned to ${selectedPartner.label}.`, 'success')
    setShowModal(false)
    setSelectedOrderId(null)
    setSelectedPartner(null)
  }

  const paymentStatusBadge5 = () => {
    return (
      <span
        style={{
          backgroundColor: '#dc3545',
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        Cancelled
      </span>
    )
  }
  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Cancelled Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-2">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      // If cleared
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-5">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" onClick={handleSearch}>
                  Search
                </Button>
                {/* <Button variant="outline-success" onClick={handlePrint}>
                    Print
                  </Button> */}
                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  {/* <Icon icon="mdi:printer" width={16} style={{ marginRight: 4 }} /> */}
                  Print
                </Button>
              </FormGroup>
            </Form>
            <div ref={printRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Cancelled Date</th>
                    <th>Client</th>
                    <th>Recipient</th>
                    <th>Delivery Type</th>
                    <th className="text-end">Price ({currency})</th>

                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr>
                      <td colSpan="7" className="text-center">
                        Loading...
                      </td>
                    </tr>
                  ) : (data?.orders || []).length === 0 ? (
                    <tr>
                      <td colSpan="7" className="text-center">
                        No cancelled orders found.
                      </td>
                    </tr>
                  ) : (
                    data.orders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>{order.cancelled_date ? new Date(order.cancelled_date).toLocaleDateString() : '-'}</td>
                        <td>
                          {order.client_name}
                          {/* <br />
          {paymentStatusBadge5('Cancel')} */}
                        </td>
                        <td>{order.recipient_name}</td>

                        <td>
                          <span className="badge rounded-pill bg-transparent border border-primary text-primary">
                            {order.currier_partner ? order.currier_partner.charAt(0).toUpperCase() + order.currier_partner.slice(1) : 'N/A'}
                          </span>
                        </td>
                        <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>
                        <td className="no-print">
                          <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>{'View'}</span>
                            </Button>
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#198754',
                                borderColor: '#198754',
                                color: '#fff',
                              }}
                              onClick={() => handleRestoreOrder(order)}
                              disabled={isRestoringOrder}>
                              <Icon icon="mdi:restore" width={15} height={20} style={{ marginRight: '4px' }} />

                              <span style={{ fontSize: '0.65rem' }}>Restore</span>
                            </Button>
                            {/* {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )} */}

                            {/* {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handleMarkAsPaid(order)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )} */}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  {/* FIRST */}
                  <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                    First
                  </Pagination.Item>

                  {/* PREVIOUS */}
                  <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                  {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                  {(() => {
                    let pages = []

                    if (totalPages <= 5) {
                      // SHOW ALL PAGES (1 → totalPages)
                      for (let i = 1; i <= totalPages; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    } else {
                      // CENTER CURRENT PAGE (MAX 5)
                      let start = currentPage - 2
                      let end = currentPage + 2

                      if (start < 1) {
                        start = 1
                        end = 5
                      }

                      if (end > totalPages) {
                        end = totalPages
                        start = totalPages - 4
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    }

                    return pages
                  })()}

                  {/* NEXT */}
                  <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                  {/* LAST */}
                  <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>
      {showViewModal && (
        <View show={showViewModal} onClose={() => setShowViewModal(false)} order_id={selectedOrderId} payment_method_id={selectedPaymentMethodId} />
      )}
      {showMarkAsPaidModal && selectedPaidOrder && (
        <MarkAsPaidModal
          show={showMarkAsPaidModal}
          order={selectedPaidOrder}
          onClose={() => {
            setShowMarkAsPaidModal(false)
            setSelectedPaidOrder(null)
          }}
          onSuccess={() => {
            handleSearch() // refresh list
          }}
        />
      )}
      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
    </Row>
  )
}

export default CancelOrders
