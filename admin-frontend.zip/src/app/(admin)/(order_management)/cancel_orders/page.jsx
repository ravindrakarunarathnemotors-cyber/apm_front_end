import React from 'react'
import CancelOrders from '../cancel_orders/CancelOrders'

function page() {
  return (
    <>
    <CancelOrders/>
     
    </>
  )
}

export default page