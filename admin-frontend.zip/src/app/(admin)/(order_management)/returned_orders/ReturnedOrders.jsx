'use client'

import React, { useState, useCallback, useEffect, useRef } from 'react'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, Button, Table, Pagination, Badge } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from '../pending_orders/components/view'
import { useGetRecipientnameQuery, useGetReturnedOrdersMutation } from '@/store/features/apiSlice'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import MarkAsPaidModal from '@/components/Order/MarkAsPaidModal'
import { debounce } from 'lodash'
function ReturnedOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')

  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [orders, setOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [searchRecipient, setSearchRecipient] = useState('')
  const printRef = useRef()
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [currency, setCurrency] = useState('')
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [getReturnedOrders, { isLoading }] = useGetReturnedOrdersMutation()

  // const { data: recipientOptions = [], isLoading: isRecipientLoading } = useGetRecipientnameQuery(recipientName, { skip: !recipientName })
  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const debouncedSearch = useCallback(
    debounce((val) => {
      setRecipientName(val)
    }, 300),
    [],
  )

  const handleRecipientInput = (e) => {
    setRecipientName(e.target.value)
    debouncedSearch(e.target.value)
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handlePayment = (order) => {
    setSelectedOrder(order)
    setSelectedPickup(order.storepickup ?? 'no')
    setSelectedPaymentMethodId(order.payment_method_id ?? null)
    setShowPaymentModal(true)
  }
  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrder(null)
    setSelectedPickup(null)
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  useEffect(() => {
    handleSearch()
  }, [currentPage, limit])

  const handleSearch = async () => {
  const payload = {
    order_id: orderId || undefined,
    recipient_name: recipientName || undefined,
    mobile: mobileNo || undefined,
    date: date || undefined,
    todate: todate || undefined,
    keyword: filters.keyword,
    page: currentPage,
    limit: limit, 
  }

  try {
    const res = await getReturnedOrders(payload).unwrap()

    setOrders(res.orders || [])

    
    setTotalPages(res.totalPages || 1)
    setTotalEntries(res.total || 0)

   
    setCurrency(res.currency || res.orders?.[0]?.currency || '')

  } catch (err) {
    console.error('Failed to fetch returned orders:', err)
  }
}
  const handleView = (order) => {
    setSelectedOrderId(order.order_id) 
    setShowViewModal(true)
  }

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Returned Orders Report</title>
     <style>
        body { font-family: Arial; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
        .no-print { display: none !important; }
      </style>
      </head>
      <body>
        <h2>Returned Orders Report</h2>
        ${printContents}
      </body>
    </html>
    `)
    newWindow.document.close()
    newWindow.print()
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'danger',
      refund: 'secondary',
      failed: 'danger',
    }

    const color = colorMap[status] || 'secondary'
    const capitalizedStatus = status.charAt(0).toUpperCase() + status.slice(1)

    return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  }

  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }
  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Returned Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      // If cleared
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-5">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-1">
                <Button className="bg-primary border-primary flex-grow-1" onClick={handleSearch}>
                  Search
                </Button>
                {/* <Button variant="outline-success" onClick={handlePrint}>
                    Print
                  </Button> */}
                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  {/* <Icon icon="mdi:printer" width={16} style={{ marginRight: 4 }} /> */}
                  Print
                </Button>
              </FormGroup>
            </Form>

            <div ref={printRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Returned Date</th>
                    <th>Returned By</th>
                    <th>Reason</th>
                    <th>Payment</th>
                    <th className="text-end">Total Price ({currency})</th>
                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center text-muted py-4">
                        No results were found.
                      </td>
                    </tr>
                  ) : (
                    orders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>{order.returned_date ? new Date(order.returned_date).toLocaleDateString() : '-'}</td>
                        <td>{order.returned_person || '-'}</td>

                        <td>{order.reason_id}</td>
                        <td>
                          {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}
                          {hasSlip(order) && (
                            <div className="mt-1 no-print">
                              <Button
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.2rem 0.1rem',
                                  fontSize: '0.55rem',
                                  height: '20px',
                                  borderRadius: '15px',
                                  backgroundColor: '#3d3642ff',
                                  borderColor: '#3d3642ff',
                                  color: '#fff',
                                }}
                                variant="outline-primary"
                                onClick={() => openSlip(order)}
                                title="Open bank slip"
                                className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                Slip
                              </Button>
                            </div>
                          )}
                        </td>
                        <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>
                        <td className="text-end no-print">
                          <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>{'View'}</span>
                            </Button>
                            {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )}
                            {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handlePayment(order)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )}{' '}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>

            <div className="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">

  {/* LEFT SIDE */}
  <div className="d-flex align-items-center gap-2">
    <span>Show</span>

    <Form.Select
      value={limit}
      onChange={(e) => {
        setLimit(Number(e.target.value))
        setCurrentPage(1)
      }}
      style={{
        width: '90px',
      }}
    >
      <option value={10}>10</option>
      <option value={25}>25</option>
      <option value={50}>50</option>
      <option value={100}>100</option>
    </Form.Select>

    <span>entries</span>
  </div>

  {/* RIGHT SIDE */}
  <div className="d-flex align-items-center gap-3 flex-wrap">

    {/* SHOWING TEXT */}
    <div className="text-muted">
      Showing{' '}
      {orders.length === 0
        ? 0
        : (currentPage - 1) * limit + 1}
      {' '}to{' '}
      {(currentPage - 1) * limit + orders.length}
      {' '}of {totalEntries} entries
    </div>

    {/* PAGINATION */}
    {totalPages > 1 && (
      <Pagination className="mb-0">

        {/* PREVIOUS */}
        <Pagination.Prev
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
        />

        {/* PAGE NUMBERS */}
        {(() => {
          let pages = []

          if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) {
              pages.push(
                <Pagination.Item
                  key={i}
                  active={i === currentPage}
                  onClick={() => handlePageChange(i)}
                >
                  {i}
                </Pagination.Item>,
              )
            }
          } else {
            let start = currentPage - 2
            let end = currentPage + 2

            if (start < 1) {
              start = 1
              end = 5
            }

            if (end > totalPages) {
              end = totalPages
              start = totalPages - 4
            }

            for (let i = start; i <= end; i++) {
              pages.push(
                <Pagination.Item
                  key={i}
                  active={i === currentPage}
                  onClick={() => handlePageChange(i)}
                >
                  {i}
                </Pagination.Item>,
              )
            }
          }

          return pages
        })()}

        {/* NEXT */}
        <Pagination.Next
          disabled={currentPage === totalPages}
          onClick={() => handlePageChange(currentPage + 1)}
        />

      </Pagination>
    )}
  </div>
</div>
          </CardBody>
        </Card>
      </Col>
      {showViewModal && (
        <View show={showViewModal} onClose={() => setShowViewModal(false)} order_id={selectedOrderId} payment_method_id={selectedPaymentMethodId} />
      )}
      {showPaymentModal && (
        <MarkAsPaidModal
          show={showPaymentModal}
          onClose={handlePaymentClose}
          order={selectedOrder}
          order_id={selectedOrder?.order_id}
          storepickup={selectedPickup}
          payment_method_id={selectedPaymentMethodId}
        />
      )}
      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
    </Row>
  )
}

export default ReturnedOrders
