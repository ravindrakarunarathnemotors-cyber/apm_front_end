import React from 'react'
import ReturnedOrders from '../returned_orders/ReturnedOrders'

function page() {
  return (
    <>
    <ReturnedOrders/>
     
    </>
  )
}

export default page