import React from 'react'
import UpdateOrder from '../update_orders/UpdateOrder'


function page({ searchParams }) {
  const order_id = searchParams?.order_id || null;
  return (
    <>
      <UpdateOrder order_id={order_id} />
    </>
  )
}

export default page


