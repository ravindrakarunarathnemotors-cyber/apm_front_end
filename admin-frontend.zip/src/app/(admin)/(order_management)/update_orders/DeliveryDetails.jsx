'use client'
import React, { useEffect, useState } from 'react'
import { Card, CardBody, Button, Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import { useSearchParams } from 'next/navigation'
import axios from 'axios'

const DeliveryDetailsSection = ({
  selectClient,
  clientOptions,
  setSelectClient,
  setShowEdit,
  setShowBilling,
  setShowCreateCustomer,
  handleClientSearch,

  // delivery-address props
  billingaddress,
  setBillingaddress,

  // legacy boolean (kept for compatibility, but radios drive the UI now)
  billingaddressSame,
  setBillingaddressSame,

  // optional externally-controlled selected value: 'same_as_billing' | 'default' | 'store_pickup'
  selected,
  setSelected,

  showBilling,
  showEdit,
  showCreateCustomer,
}) => {
  const searchParams = useSearchParams()
  const order_id = searchParams.get('order_id')

  const [showSearch, setShowSearch] = useState(false)
  const [billingSameTouched, setBillingSameTouched] = useState(false)

  // Support both controlled (via props.selected) and uncontrolled (local) modes
  const isControlled = typeof selected !== 'undefined' && typeof setSelected === 'function'
  const [localSelected, setLocalSelected] = useState('same_as_billing')
  const currentSelected = isControlled ? selected : localSelected
  const setCurrentSelected = isControlled ? setSelected : setLocalSelected

  // Populate billing & delivery from server if editing an existing order
  useEffect(() => {
    if (!order_id) return
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/update-order/delivery-details/${order_id}`)
      .then((res) => {
        const data = res.data

        if (data.billingDetails) {
          setBillingaddress(data.deliveryDetails || null)

          // Also set selected client for billing details
          const clientFromServer = {
            value: data.billingDetails.value,
            first_name: data.billingDetails.first_name,
            last_name: data.billingDetails.last_name,
            contact_number_1: data.billingDetails.contact_number_1,
            address: data.billingDetails.address,
            apartment: data.billingDetails.apartment,
            city: data.billingDetails.city,
            postal_code: data.billingDetails.postal_code,
            email: data.billingDetails.email,
            country: data.billingDetails.country || 'Sri Lanka',
          }
          setSelectClient(clientFromServer)
        }

        const same =
          data.billingDetails?.address === data.deliveryDetails?.address &&
          data.billingDetails?.city === data.deliveryDetails?.city &&
          data.billingDetails?.postal_code === data.deliveryDetails?.postal_code

        if (!billingSameTouched) {
          setBillingaddressSame?.(same)
          setCurrentSelected(same ? 'same_as_billing' : 'default')
        }
      })
      .catch((err) => console.error('Error fetching delivery details', err))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order_id, setSelectClient])

  const clientDetails = selectClient || null

  // Change handler for the radio buttons
  const handleRadioChange = (val) => {
    setCurrentSelected(val)

    // keep legacy boolean in sync for any parent logic that still reads it
    if (setBillingaddressSame) {
      setBillingSameTouched(true)
      setBillingaddressSame(val === 'same_as_billing')
    }

    // when user selects "Different Address", open delivery modal
    if (val === 'default') setShowBilling(true)
    // store_pickup specific behaviors (like fee=0) can be handled in parent if needed
  }

  return (
    <>
      <Card className="border">
        <CardBody>
          <div className="d-flex justify-content-between align-items-center">
            <div className="fw-bold" style={{ fontSize: '18px' }}>
              Billing & Delivery
            </div>

            {clientDetails && !showSearch && (
              <Dropdown>
                <DropdownToggle variant="secondaryyy" className="btn-sm text-dark p-0" type="button">
                  <Icon icon="mage:dots" width="20" height="20" />
                </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem
                    onClick={() => {
                      setSelectClient(null)
                      setBillingaddress(null)
                      setShowSearch(false)
                      setCurrentSelected('same_as_billing')
                      setBillingaddressSame?.(true)
                    }}>
                    Remove Customer
                  </DropdownItem>
                  <DropdownItem onClick={() => setShowEdit(true)}>Edit Customer</DropdownItem>
                  <DropdownItem onClick={() => setShowBilling(true)}>Edit Delivery Details</DropdownItem>
                </DropdownMenu>
              </Dropdown>
            )}
          </div>

          <div className="mt-2">
            {!clientDetails || showSearch ? (
              <Select
                options={[...clientOptions, { label: '➕ Add Customer', value: 'add_customer' }]}
                value={clientOptions.find((option) => option.value === clientDetails?.value) || null}
                onChange={(selectedOption) => {
                  if (selectedOption?.value === 'add_customer') {
                    setShowCreateCustomer(true)
                    setSelectClient(null)
                  } else {
                    setSelectClient(selectedOption || null)
                    setShowSearch(false)
                  }
                }}
                placeholder="Select Client"
                isClearable
                onInputChange={(inputValue, actionMeta) => {
                  if (actionMeta.action === 'input-change') {
                    handleClientSearch(inputValue)
                  }
                }}
                filterOption={() => true}
              />
            ) : (
              <Button
                variant="link"
                className="p-0 mt-1"
                onClick={() => {
                  setSelectClient(null)
                  setBillingaddress(null)
                  setShowSearch(true)
                }}>
                Change Customer
              </Button>
            )}

            {clientDetails && (
              <>
                <div className="d-flex border-bottom pt-1 mb-2 align-items-center">
                  <div className="fw-bold" style={{ fontSize: '15px' }}>
                    Billing Details
                  </div>
                  <Button variant="link" className="text-danger" onClick={() => setShowEdit(true)}>
                    <Icon icon="akar-icons:edit" width="18" height="18" style={{ color: '#8e8e8e' }} />
                  </Button>
                </div>
                <div
                  className="p-1 position-relative"
                  style={{
                    backgroundImage: "url('/invoice.png')",
                    opacity: 0.8,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right bottom',
                    backgroundSize: '120px',
                    minHeight: '120px',
                  }}>
                  #{clientDetails?.value} {clientDetails?.first_name} {clientDetails?.last_name}
                  <div className="text-primary text-break mb-1">{clientDetails?.email}</div>
                  <div className="text-muted small mb-1">{clientDetails?.contact_number_1 || 'No phone number'}</div>
                  <div className={`mb-1 ${clientDetails?.address ? '' : 'text-danger'}`}>{clientDetails?.address || 'No address'}</div>
                  <div className={`mb-1 ${clientDetails?.city ? '' : 'text-danger'}`}>{clientDetails?.city || 'No city'}</div>
                  <div className="mb-3">{clientDetails?.country || 'Sri Lanka'}</div>
                </div>
              </>
            )}
          </div>
        </CardBody>
      </Card>

      {clientDetails && (
        <Card className="mt-2 border">
          <CardBody>
            <div className="d-flex border-bottom pt-1 mb-2 align-items-center">
              <div className="fw-bold" style={{ fontSize: '15px' }}>
                Delivery Details
              </div>
              <Button variant="link" className="text-danger" onClick={() => setShowBilling(true)}>
                <Icon icon="akar-icons:edit" width="18" height="18" style={{ color: '#8e8e8e' }} />
              </Button>
            </div>

            {/* Radio group (three-way) */}
            <div className="btn-group" role="group" aria-label="Address option toggle group">
              <input
                type="radio"
                className="btn-check"
                name="addressOption"
                id="dd_same"
                autoComplete="off"
                value="same_as_billing"
                checked={currentSelected === 'same_as_billing'}
                onChange={() => handleRadioChange('same_as_billing')}
              />
              <label className="btn btn-outline-primary" htmlFor="dd_same">
                Same as Billing Address
              </label>

              <input
                type="radio"
                className="btn-check"
                name="addressOption"
                id="dd_diff"
                autoComplete="off"
                value="default"
                checked={currentSelected === 'default'}
                onChange={() => handleRadioChange('default')}
              />
              <label className="btn btn-outline-primary" htmlFor="dd_diff">
                Different Address
              </label>

              <input
                type="radio"
                className="btn-check"
                name="addressOption"
                id="dd_pickup"
                autoComplete="off"
                value="store_pickup"
                checked={currentSelected === 'store_pickup'}
                onChange={() => handleRadioChange('store_pickup')}
              />
              <label className="btn btn-outline-primary" htmlFor="dd_pickup">
                Store Pickup
              </label>
            </div>

            {/* Preview cards matching selection */}
            {currentSelected === 'store_pickup' && (
              <div
                className="p-1 position-relative"
                style={{
                  backgroundImage: "url('/store.png')",
                  opacity: 0.9,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'center',
                  backgroundSize: '140px',
                  minHeight: '120px',
                  marginTop: '20px',
                }}
              />
            )}

            {currentSelected === 'same_as_billing' && (
              <div
                className="p-1 position-relative"
                style={{
                  backgroundImage: "url('/delivery.png')",
                  opacity: 0.9,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right bottom',
                  backgroundSize: '120px',
                  minHeight: '120px',
                  marginTop: '20px',
                }}>
                <div className="mb-1">
                  {clientDetails?.first_name} {clientDetails?.last_name}
                </div>
                <div className="text-primary text-break mb-1">{clientDetails?.email}</div>
                <div className="text-muted small mb-1">{clientDetails?.contact_number_1 || 'No phone number'}</div>
                <div className=" mb-1">{clientDetails?.address || 'No address'}</div>
                <div className=" mb-1">{clientDetails?.city || 'No city'}</div>
                <div className=" mb-3">{clientDetails?.country || 'Sri Lanka'}</div>
              </div>
            )}

            {currentSelected === 'default' && (
              <div
                className="p-1 position-relative"
                style={{
                  backgroundImage: "url('/delivery.png')",
                  opacity: 0.9,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right bottom',
                  backgroundSize: '120px',
                  minHeight: '120px',
                  marginTop: '20px',
                }}>
                <div className="fw-semibold mb-1">Delivery to</div>
                <div className="mb-1">
                  {billingaddress?.first_name} {billingaddress?.last_name}
                </div>
                <div className="text-primary text-break mb-1">{billingaddress?.email}</div>
                <div className="text-muted small mb-1">{billingaddress?.contact_number_1 || 'No phone number'}</div>
                <div className=" mb-1">{billingaddress?.address || 'No address'}</div>
                <div className=" mb-1">{billingaddress?.city || 'No city'}</div>
                <div className=" mb-3">{billingaddress?.country || 'Sri Lanka'}</div>
              </div>
            )}
          </CardBody>
        </Card>
      )}
    </>
  )
}

export default DeliveryDetailsSection
