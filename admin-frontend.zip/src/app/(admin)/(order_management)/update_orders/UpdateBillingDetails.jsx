'use client'

import React, { useEffect, useState } from 'react'
import { Modal, ModalBody, ModalHeader, ModalFooter, Button } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { checkNumberFormat } from '@/utils/checkNumber'

const UpdateBillingDetails = ({ open, setOpen, clientDetails, setClientDetails, setBillingaddress, billingaddressSame, editCustomerDetails }) => {
  const handleClose = () => setOpen(false)

  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    contact_number_1: '',
    address: '',
    apartment: '',
    city: '',
    postal_code: '',
    email: '',
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setCustomerInfo((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

  const handleSubmit = () => {
    if (customerInfo.name.trim() === '' || customerInfo.address.trim() === '' || customerInfo.city.trim() === '') {
      Swal.fire({
        title: 'Error',
        text: 'Please fill all the required fields',
        icon: 'error',
        confirmButtonText: 'OK',
      })
      return
    }

    if (!customerInfo.contact_number_1 && !customerInfo.email) {
      Swal.fire({
        title: 'Error',
        text: 'Please fill at least one contact number or email',
        icon: 'error',
        confirmButtonText: 'OK',
      })
      return
    }

    if (customerInfo.contact_number_1) {
      const checkNumber = checkNumberFormat(customerInfo.contact_number_1)
      if (checkNumber.error) {
        Swal.fire({
          title: 'Error',
          text: checkNumber.error,
          icon: 'error',
          confirmButtonText: 'OK',
        })
        return
      }
    }

    if (customerInfo.email && !isValidEmail(customerInfo.email)) {
      Swal.fire({
        title: 'Error',
        text: 'Please enter a valid email address',
        icon: 'error',
        confirmButtonText: 'OK',
      })
      return
    }

    setClientDetails((prev) => ({
      ...prev,
      name: customerInfo.name.trim(),
      contact: customerInfo.contact_number_1 || '',
      address: customerInfo.address || '',
      apartment: customerInfo.apartment || '',
      city: customerInfo.city || '',
      postal_code: customerInfo.postal_code || '',
      email: customerInfo.email || '',
    }))

    setBillingaddress({
      name: customerInfo.name.trim(),
      email: customerInfo.email,
      contact: customerInfo.contact_number_1,
      address: customerInfo.address,
      city: customerInfo.city,
      country: 'Sri Lanka',
    })

    handleClose()
  }

  useEffect(() => {
    if (open) {
      const dataSource = billingaddressSame ? editCustomerDetails : clientDetails

      setCustomerInfo({
        name: dataSource?.name || '',
        contact_number_1: dataSource?.contact || '',
        address: dataSource?.address || '',
        apartment: dataSource?.apartment || '',
        city: dataSource?.city || '',
        postal_code: dataSource?.postal_code || '',
        email: dataSource?.email || '',
      })
    }
  }, [open, billingaddressSame, editCustomerDetails, clientDetails])

  return (
    <Modal show={open} onHide={handleClose} centered size="lg">
      <ModalHeader closeButton className="bg-light">
        <h6 className="modal-title m-0 text-black">Update Delivery Details</h6>
      </ModalHeader>
      <ModalBody>
        <div className="">
          <div className="row">
            <div className="col-6 mb-2">
              <label className="form-label">Name</label>
              <input type="text" className="form-control" placeholder="Full Name" name="name" value={customerInfo.name} onChange={handleChange} />
            </div>

            <div className="col-md-6 mb-2">
              <label className="form-label">Mobile Number</label>
              <input
                type="tel"
                className="form-control"
                placeholder="Phone number"
                name="contact_number_1"
                value={customerInfo.contact_number_1}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="row mt-1">
            <div className="col-md-6 mb-2">
              <label className="form-label">Email</label>
              <input type="email" className="form-control" placeholder="Email" name="email" value={customerInfo.email} onChange={handleChange} />
            </div>

            <div className="col-6 mb-2">
              <label className="form-label">Phone Number (Optional)</label>
              <input
                type="tel"
                className="form-control"
                placeholder="Phone number"
                name="contact_number_1"
                value={customerInfo.contact_number_1}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="mb-2">
            <label className="form-label">Address Line 1</label>
            <input type="text" className="form-control" placeholder="No.01" name="address" value={customerInfo.address} onChange={handleChange} />
          </div>

          <div className="mb-2">
            <label className="form-label">Address Line 2</label>
            <input
              type="text"
              className="form-control"
              placeholder="Wolf Street"
              name="apartment"
              value={customerInfo.apartment}
              onChange={handleChange}
            />
          </div>

          <div className="row">
            <div className="col-md-4 mb-2">
              <label className="form-label">City</label>
              <input type="text" className="form-control" placeholder="City" name="city" value={customerInfo.city} onChange={handleChange} />
            </div>

            <div className="col-md-4 mb-2">
              <label className="form-label">Postal Code (Optional)</label>
              <input
                type="text"
                className="form-control"
                placeholder="Postal code"
                name="postal_code"
                value={customerInfo.postal_code}
                onChange={handleChange}
              />
            </div>

            <div className="col-md-4 mb-2">
              <label className="form-label">Country/Region</label>
              <input type="text" className="form-control" value="Sri Lanka" readOnly />
            </div>
          </div>
        </div>
      </ModalBody>
      <ModalFooter>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
        <Button variant="primary" onClick={handleSubmit}>
          Save
        </Button>
      </ModalFooter>
    </Modal>
  )
}

export default UpdateBillingDetails
