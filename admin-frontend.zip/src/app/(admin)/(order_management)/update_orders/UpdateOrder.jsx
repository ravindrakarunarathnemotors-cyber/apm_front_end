'use client'

import React, { useEffect, useState, useCallback, useMemo } from 'react'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import {
  Table,
  Button,
  Form,
  Spinner,
  Badge,
  Row,
  Col,
  ListGroup,
  FormCheck,
  Card,
  Dropdown,
  DropdownDivider,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  CardBody,
  FormControl,
} from 'react-bootstrap'
import { useGetSystemSettingsQuery, useRefreshTokenMutation } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import RedCard from '@/components/Redcard'
import Link from 'next/link'
import useLogout from '@/hooks/useLogout'
// import { timeFormate } from '@/utils/date'
import Select from 'react-select'
import { debounce } from 'lodash'
import axios from 'axios'
import Image from 'next/image'
import ShowProduct from '@/components/CreateOrder/ShowProduct'
import EditCustomer from '@/components/CreateOrder/EditCustomer'
import UpdateBillingDetails from '../update_orders/UpdateBillingDetails'
import defaultimage from '@/assets/product-default.jpg'
import CreateCustomer from '@/components/CreateOrder/CreateCustomer'
import ShowPaymentUpdate from '@/components/UpdateOrder/ShowPaymentUpdate'
import DeliveryDetailsSection from '../update_orders/DeliveryDetails'
import { useSearchParams } from 'next/navigation'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'
import ProductMeasurementQuantity from '@/components/CreateOrder/ProductMeasurementQyantity'
import AddBillingDetails from '@/components/CreateOrder/AddBillingDetails'

const UpdateOrders = ({ order_id }) => {
  const [search, setSearch] = useState('')
  const [showProductModal, setShowProductModal] = useState(false)
  const [addedproducts, setAddedproducts] = useState([])
  const [allClient, setAllClient] = useState([])
  const [selectClient, setSelectClient] = useState(null)
  const [showEdit, setShowEdit] = useState(false)
  const [clientDetails, setClientDetails] = useState({
    value: 0,
    first_name: '',
    last_name: '',
    contact_number_1: '',
    address: '',
    apartment: '',
    city: '',
    postal_code: '',
    saveInfo: false,
    email: '',
    country: ''
  })
  const [billingaddressSame, setBillingaddressSame] = useState(true)
  const [showBilling, setShowBilling] = useState(false)
  const [billingaddress, setBillingaddress] = useState({
    first_name: '',
    last_name: '',
    contact_number_1: '',
    contact_number_2: '',
    address: '',
    apartment: '',
    city: '',
    postal_code: '',
    email: '',
    country: ''
  })
  const [showCreateCustomer, setShowCreateCustomer] = useState(false)
  const [allPaymentMethod, setAllPaymentMethod] = useState([])
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState(null)
  const [deliveryFee, setDeliveryFee] = useState('')
  const [showPayment, setShowPayment] = useState(false)

  const [taxFields, setTaxFields] = useState({ key: '', value: '' })
  const [taxEnabled, setTaxEnabled] = useState(false)
  const [selected, setSelected] = useState("default");
  const [countries, setCountries] = useState([])
  const [deliveryFeeDetails, setDeliveryFeeDetails] = useState(null)
  const [sellInternational, setSellInternational] = useState(false)

  //discount
  const [discount, setDiscount] = useState('')
  const [discountManualType, setDiscountManualType] = useState('fixed')
  const [discountType, setDiscountType] = useState('none')
  const [orderDiscount, setOrderDiscount] = useState(null)
  const [productDiscount, setProductDiscount] = useState(null)
  const [finalDiscount, setFinalDiscount] = useState(null);
  const [deliveryDiscount, setDeliveryDiscount] = useState(null)
  const [paymentMethodDiscount, setPaymentMethodDiscount] = useState(null)
  const [buyxDiscont, setBuyxDiscont] = useState(null)

  const [orderId, setOrderId] = useState(null)
  const [isPaid, setIsPaid] = useState(false)
  const [loading, setLoading] = useState(true)
  const [orderDetails, setOrderDetails] = useState(null)

  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token')
  }

  const [refreshtoken] = useRefreshTokenMutation()
  const { data, isLoading, error } = useGetSystemSettingsQuery()
  const { Logout } = useLogout()
  const { currency } = useCurrencySymbol()

  useEffect(() => {
    if (search.length > 1) {
      setShowProductModal(true)
    }
  }, [search])

  useEffect(() => {
    if (data?.data) {
      const Taxdata = data.data
      setTaxEnabled(Taxdata.tax)
      setSellInternational(Taxdata.sell_international)
      const key = Object.keys(Taxdata.tax_value)[0]
      const value = Taxdata.tax_value[key]
      setTaxFields({ key, value })
    }
  }, [data?.data])

  useEffect(() => {
    fetchPaymentMethod()
    fetchCountries()
  }, [])

  const totalAmount = useMemo(() => {
    return addedproducts.reduce((total, item) => total + item.price * item.selectedQty, 0)
  }, [addedproducts])

  //discount parts .................................................................

  useEffect(() => {
    if (addedproducts.length > 0 && selectClient) {
      autoBuyxDiscount()
      autoDiscount()
    }
  }, [addedproducts, selectClient])

  useEffect(() => {
    if (addedproducts.length === 0 || parseFloat(deliveryFee) === 0) return
    autoDeliveryDiscount()
  }, [addedproducts, deliveryFee, selectClient])

  // discount calculate ................................

  const totalDiscount = useMemo(() => {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };

    const orderValue = num(orderDiscount?.discount_value);
    const deliveryValue = num(deliveryDiscount?.discount_value);
    const productValue = num(productDiscount?.total_discount_value)
    const buyxValue = num(buyxDiscont?.total_discount_value)
    const paymentValue = num(paymentMethodDiscount?.discount_value);

    // If appliedCode is true, only use finalDiscount, but still keep object shape
    if (discount) {
      const discountValue = discountManualType === 'fixed' ? parseFloat(discount) : parseFloat(discount) * totalAmount / 100
      console.log(discountValue)
      // Only proceed if it's a valid number
      if (Number.isFinite(discountValue)) {
        return {
          discountValue,
          orderValue: 0,
          deliveryValue: 0,
          productValue: 0,
          buyxValue: 0,
          paymentValue: 0,
        };
      }
    }


    const discountValue = Math.max(orderValue, paymentValue, deliveryValue, productValue, buyxValue, 0);

    return {
      discountValue,
      orderValue,
      deliveryValue,
      productValue,
      buyxValue,
      paymentValue
    };
  }, [
    discount,
    discountManualType,
    finalDiscount,
    orderDiscount,
    productDiscount,
    paymentMethodDiscount,
    deliveryDiscount,
    buyxDiscont,
    selectClient
  ]);


  useEffect(() => {
    const { discountValue, orderValue, paymentValue, deliveryValue, productValue, buyxValue } = totalDiscount;

    if (discountValue === 0) {
      setDiscountType("none");
      return;
    }
    console.log(discountValue)
    console.log(orderValue, paymentValue, deliveryValue, productValue, buyxValue)
    switch (discountValue) {
      case orderValue:
        setDiscountType("order");
        break;
      case paymentValue:
        setDiscountType("payment_method");
        break;
      case deliveryValue:
        setDiscountType("shipping");
        break;
      case productValue:
        setDiscountType("product");
        break;
      case buyxValue:
        setDiscountType("buyx");
        break;
      default:
        setDiscountType("none");
    }
  }, [totalDiscount, discountType]);

  //........................................................................

  useEffect(() => {
    const fetchDeliveryFee = async () => {

      if (selected == "store_pickup") return


      if (!selectClient) return

      const sameAsBilling = selected
      const country = clientDetails.country

      const deliveryCountry = billingaddress.country


      if (!country) return
      let delCountry = sameAsBilling == 'same_as_billing' ? country : deliveryCountry;

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/system/get-delivery-fee`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ country: delCountry }),
      });

      const data = await response.json();

      if (response.status === 200) {
        setDeliveryFeeDetails(data.result)
      }

    };

    fetchDeliveryFee();
  }, [selected, clientDetails.country, billingaddress.country]);

  useEffect(() => {
    if (!order_id) return
    setOrderId(order_id)
  }, [order_id])


  useEffect(() => {

    if (!order_id) return

    const fetchOrderData = async () => {
      try {
        const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/update-order/get-products-by-order/${order_id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        const orderProducts = response.data.result || []
        console.log(orderProducts)
        //add all order details
        setOrderDetails(orderProducts ? orderProducts : null)

        // Flatten variant list with product info
        setAddedproducts(orderProducts.variants)

        //discount
        if (orderProducts?.discount_type == 'manual') setDiscount(Number(orderProducts?.discount))

        // client and recipient details
        const [first_name = '', last_name = ''] = orderProducts.sender_name?.split(' ') || [];
        setSelectClient((prev) => ({
          ...prev,
          first_name: first_name || '',
          last_name: last_name || '',
          contact_number_1: orderProducts.sender_phone || '',
          address: orderProducts.sender_address || '',
          city: orderProducts.sender_city || '',
          value: orderProducts.customer_id || 0,
          country: orderProducts.sender_country_id ? orderProducts.sender_country_id : '',
          country_name: orderProducts.sender_country_name || '',
          email: orderProducts.sender_email || '',
          loyalty_point: orderProducts.loyalty_point || 0
        }))


        // delivery details
        setBillingaddress((prev) => ({
          ...prev,
          first_name: orderProducts.recipient_name || '',
          contact_number_1: orderProducts.recipient_contact || '',
          contact_number_2: orderProducts.recipient_contact_two || '',
          address: orderProducts.recipient_address || '',
          city: orderProducts.recipient_city || '',
          postal_code: orderProducts.recipient_postal_code || '',
          country: orderProducts.recipient_country_id ? orderProducts.recipient_country_id : '',
          country_name: orderProducts.recipient_country_name || '',
          email: orderProducts.recipient_email || '',
        }))




      } catch (error) {
        console.error('Failed to fetch order data:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchOrderData()
  }, [order_id])

  useEffect(() => {
    if (selectClient) {
      setClientDetails((prev) => ({
        ...prev,
        first_name: selectClient.first_name || '',
        last_name: selectClient.last_name || '',
        contact_number_1: selectClient.contact_number_1 || '',
        address: selectClient.address || '',
        apartment: selectClient.apartment || '',
        city: selectClient.city || '',
        postal_code: selectClient.postal_code || '',
        value: selectClient.value || 0,
        country: selectClient.country || '',
        country_name: selectClient.country_name || '',
        email: selectClient.email || '',
      }))

    }


  }, [selectClient])

  const countryName = (id) => {
    const country = countries.find((country) => country.country_name == id)
    return country ? country.id : ''
  }

  const handleSearchChange = (e) => {
    const value = e.target.value
    setSearch(value)
  }

  const handleQtyInput = (variant_id, newVal) => {
    setAddedproducts((prev) =>
      prev.map((item) =>
        item.variant_id === variant_id
          ? {
            ...item,
            selectedQty: Math.max(1, Number(newVal) || 1),
          }
          : item,
      ),
    )
  }

  const handleRemove = (variant_id) => {
    setAddedproducts((prev) => prev.filter((item) => item.variant_id !== variant_id))
  }

  const fetchCountries = async () => {
    try {
      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/system/all-country`,
        {},
        {
          headers: {

          },
        })
      if (response.status == 200) {
        setCountries(response.data.result);
      }
    } catch (error) {
      console.error('Error fetching countries:', error)
    }
  }

  const handleClientSearch = async (value) => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/common/getAllCustomerUpdate?customer=${value}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.status === 200) {
        console.log(response.data.result)
        setAllClient(response.data.result)
      }
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return handleClientSearch(value)
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        console.error('Search failed:', error)
      }
    }
  }

  const handleBillingAdress = (e) => {
    // setBillingaddressSame(e.target.checked)
    setSelected(e)
    if (e == 'default') {
      setShowBilling(true)
    }
    if (e == 'store_pickup') {
      setDeliveryFee(0)
    }
  }

  const fetchPaymentMethod = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/common/getAllPaymentMethod`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      if (response.status === 200) {
        setAllPaymentMethod(response.data.result)
      }
    } catch (error) {
      console.error('Error fetching payment methods:', error)
    }
  }




  const customAddOption = { label: '➕ Add Customer', value: 'add_customer' }
  const clientOptions = [...allClient, customAddOption]

  //calculate quantity
  const totalQty = useMemo(() => {
    return addedproducts.reduce((total, item) => total + item.selectedQty, 0)
  }, [addedproducts])

  //calculate  totalamount


  const totalWight = useMemo(() => {
    return addedproducts.reduce((total, item) => {
      const qty = parseFloat(item.selectedQty) || 0

      // measurement_id === 3 → grams → kg
      if (item.measurement_id === 3) {
        const amountPerUnit = parseFloat(item.amount_per_unit) || 0
        return total + (amountPerUnit / 1000) * qty
      }

      // measurement_id === 4 → ml (no divide)
      if (item.measurement_id === 2) {
        const amountPerUnit = parseFloat(item.amount_per_unit) || 0
        return total + amountPerUnit * qty
      }

      // default → weight * quantity
      const weight = parseFloat(item.weight) || 0
      return total + weight * qty
    }, 0)
  }, [addedproducts])

  const totalTax = useMemo(() => {
    const Discount = discountType == 'buyx' ? 0 : parseFloat(totalDiscount?.discountValue) || 0
    const beforetaxAmount = parseFloat(totalAmount) - Discount + parseFloat(deliveryFee)

    return beforetaxAmount * (parseFloat(taxFields.value) / 100)
  }, [addedproducts, deliveryFee, totalDiscount?.discountValue, discountType])

  // delivery fee
  useEffect(() => {
    if (!deliveryFeeDetails) return
    const roundedWeight = Math.ceil(parseFloat(totalWight))
    if (roundedWeight > 1) {
      setDeliveryFee(parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1)))
    } else {
      setDeliveryFee(deliveryFeeDetails.fee)
    }

  }, [totalWight, deliveryFeeDetails])

  const lastSubTotal = useMemo(() => {
    const totalValue = parseFloat(totalAmount) || 0
    const discountValue = parseFloat(totalDiscount?.discountValue) || 0

    return discountType == 'product'
      ? totalValue - discountValue
      : totalValue
  }, [totalAmount, totalDiscount?.discountValue, discountType])


  const fullAmount = useMemo(() => {
    const fullDiscount = (discountType == 'buyx' || discountType == 'product') ? 0 : parseFloat(totalDiscount?.discountValue) || 0
    const parsedDeliveryFee = parseFloat(deliveryFee) || 0

    if (taxEnabled && billingaddressSame) {
      return lastSubTotal - fullDiscount + parsedDeliveryFee + totalTax
    } else {

      return lastSubTotal - fullDiscount + parsedDeliveryFee
    }
  }, [lastSubTotal, discount, deliveryFee, discountType, billingaddressSame, totalDiscount])

  //discount modules ............................................................................................................
  const autoDiscount = async () => {
    try {

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodiscountcheck`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value
        }),
      });

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json();

      if (response.status === 200) {
        setDiscountType(data.final)
        setOrderDiscount(data.data.order ? data.data.order : null)
        setProductDiscount(data.data.product ? data.data.product : null)
      }

    } catch (error) {
      console.log(error)
    }

  }

  const autoBuyxDiscount = async () => {
    try {

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodbuyxdiscount`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value
        }),
      });

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoBuyxDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }

      const data = await response.json();

      if (response.status === 200) {
        setBuyxDiscont(data.data ? data.data : null)
      }

    } catch (error) {
      console.log(error)
    }

  }

  const autoDeliveryDiscount = async () => {
    try {

      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodeliverdiscount`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          cart_products: addedproducts,
          user_id: selectClient.value,
          deliverFee: deliveryFee
        }),
      });

      if (response.status === 401 || response.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const response = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', response.access_token)
            token = response.access_token
            return autoDeliveryDiscount()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      }


      const data = await response.json();

      if (response.status === 200) {
        setDeliveryDiscount(data.data ? data.data : null)
      }

    } catch (error) {
      console.log(error)
    }

  }

  function getDiscountDetails() {
    console.log(discountType)
    // No discount at all
    if (discountType === 'none' && !discount) return null;

    // Manual discount
    if (discount) {
      return {
        discount_id: null,
        discount_value:
          discountManualType === 'fixed'
            ? parseFloat(discount)
            : (parseFloat(discount) * totalAmount) / 100,
        type: 'manual'
      };
    }



    // Order discount
    if (discountType === 'order') {
      if (!orderDiscount) return null; // prevents crash
      return {
        discount_id: orderDiscount.discount_id,
        discount_value: orderDiscount.discount_value,
        type: 'order'
      };
    }

    // Payment method discount
    if (discountType === 'payment_method') {
      if (!paymentMethodDiscount) return null;
      return {
        discount_id: paymentMethodDiscount.discount_id,
        discount_value: paymentMethodDiscount.discount_value,
        type: 'payment_method'
      };
    }

    // Shipping discount
    if (discountType === 'shipping') {
      console.log(deliveryDiscount)
      if (!deliveryDiscount) return null;
      return {
        discount_id: deliveryDiscount.discount_id,
        discount_value: deliveryDiscount.discount_value,
        type: 'shipping'
      };
    }

    // Product discount
    if (discountType === 'product') {
      if (!productDiscount) return null;
      return {
        discount_id: productDiscount.discount_id,
        discount_value: productDiscount.total_discount_value,
        type: 'product',
        discont_product: productDiscount.applicableProducts,
      };
    }

    // Buy X discount
    if (discountType === 'buyx') {
      if (!buyxDiscont) return null;
      return {
        discount_id: buyxDiscont.discount_id,
        discount_value: buyxDiscont.applicableProducts,
        type: 'buyx'
      };
    }

    return null;
  }

  const handleUpdateOrderSubmit = async () => {
    const searchParams = new URLSearchParams(window.location.search)
    const order_id = searchParams.get('order_id')

    if (!order_id) {
      Swal.fire('Error', 'Order ID is missing in the URL', 'error')
      return
    }

    try {
      const payload = {
        products: addedproducts.map((item) => ({
          variant_id: item.variant_id,
          quantity: item.selectedQty,
        })),
        client: selectClient?.value,
        billing_address: clientDetails,
        delivery_address: billingaddressSame ? clientDetails : billingaddress,
        billingaddressSame,
        delivery_fee: deliveryFee,
        discount: discount,
        discount_type: discountType,
        total_amount: fullAmount,
      }

      const response = await axios.put(`${process.env.NEXT_PUBLIC_BASE_URL}/update-order/edit-order/${order_id}`, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.data?.success) {
        Swal.fire('Success', 'Order updated successfully!', 'success')
      } else {
        Swal.fire('Error', response.data?.message || 'Failed to update order', 'error')
      }
    } catch (error) {
      console.error('Update failed:', error)
      Swal.fire('Error', 'Something went wrong while updating the order.', 'error')
    }
  }

  const handleAddProduct = async () => {
    if (addedproducts.length === 0) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please add products to the order',
      })
      return
    }

    if (!selectClient) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please select a customer',
      })
      return
    }

    if (!clientDetails.first_name || !clientDetails.last_name || !clientDetails.address || !clientDetails.city) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Please fill all the required customer fields',
      })
      return
    }

    if (!clientDetails.contact_number_1 && !clientDetails.email) {
      Swal.fire({
        title: 'Error',
        text: 'Please fill at least one contact number or email',
        icon: 'error',
        confirmButtonText: 'OK',
      })
      return
    }


    if (selected === "default") {
      if (!billingaddress.first_name || !billingaddress.address || !billingaddress.city) {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'Please fill all the required delivery details fields',
        })
        return
      }
    }

    if (selected === "default") {
      if (!billingaddress.contact_number_1 && !billingaddress.email) {
        Swal.fire({
          title: 'Error',
          text: 'Please fill at least one contact number or email',
          icon: 'error',
          confirmButtonText: 'OK',
        })
        return
      }
    }

    if (!sellInternational) {
      if (selected === "same_as_billing" && clientDetails.country != '162') {
        setSelected('default')
        setShowBilling(true)
        Swal.fire({
          title: 'Error',
          text: 'Please select Sri Lanka as the delivery country.',
          icon: 'error',
          confirmButtonText: 'OK',
        })
        return
      }

      if (selected === "default" && billingaddress.country != '162') {
        setShowBilling(true)
        Swal.fire({
          title: 'Error',
          text: 'Please select Sri Lanka as the delivery country.',
          icon: 'error',
          confirmButtonText: 'OK',
        })
        return
      }

    }

    setShowPayment(true)
  }

  const handleDiscount = (e) => {
    const value = e.target.value;

    // Allow empty input
    if (value === '') {
      setDiscount('');
      return;
    }

    // Only integers allowed
    const intRegex = /^\d+$/;
    if (!/^\d*\.?\d*$/.test(value)) return;

    const numericValue = Number(value);

    // If type is percent, max 100
    if (discountManualType === 'percent' && numericValue > 100) return;

    if (discountManualType === 'fixed' && numericValue > (parseFloat(totalAmount) || 0)) return

    setDiscount(value);
  };


  console.log(addedproducts)


  return (
    <div>
      <ComponentContainerCard title={`Update Order - ${order_id} `}>
        {loading ? (
          <div className="d-flex justify-content-center my-4">
            <Spinner animation="border" variant="primary" />
          </div>
        ) : (
          <Row className="py-3">
            <Col md={8}>
              {/* Add content for the first column here */}
              <div className="d-flex border rounded overflow-hidden">
                <input
                  type="search"
                  name="search"
                  className="form-control border-0 shadow-none"
                  placeholder="Search products"
                  value={search}
                  onChange={handleSearchChange}
                  autoComplete="off"
                />
                <button className="btn border-0 bg-white">
                  <Icon icon="iconoir:search" className="" />
                </button>
              </div>

              {/* add product details */}
              <div className="mt-2">
                {addedproducts.length > 0 && (
                  <Table responsive>
                    <thead>
                      <tr className="border-bottom my-2">
                        <th>Product</th>
                        <th style={{ width: 102, textAlign: 'center' }}>Weight (Kg)</th>
                        <th style={{ width: 30, textAlign: 'center' }}>Quantity</th>
                        <th style={{ textAlign: 'center' }}>Total ({currency})</th>
                        <th style={{ width: 30, textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {addedproducts.map((item) => {
                        const qty = Number(item.selectedQty ?? 1);
                        const originalTotal = Number(item.price || 0) * qty;

                        // product discount object for this variant (if any)
                        const productDiscForItem = (productDiscount?.applicableProducts || []).find(
                          (d) => d.variant_id === item.variant_id
                        );

                        // discountValue per unit (fallback 0)
                        const unitDiscountValue = Number(productDiscForItem?.discount_value || 0);

                        // total discount for this line
                        const totalDiscountAmount = originalTotal - unitDiscountValue

                        // final total after discount (don't go negative)
                        const finalTotal = Math.max(0, totalDiscountAmount);

                        return (
                          <tr key={item.variant_id}>
                            <td>
                              <div className="d-flex gap-2">
                                <Image
                                  src={item.main_img || item.first_extra_img || defaultimage}
                                  rounded
                                  width={48}
                                  height={48}
                                  style={{ objectFit: 'cover', border: '1px solid #ebebeb', borderRadius: '8px' }}
                                />
                                <div>
                                  <div className="fw-semibold ">#{item.variant_id} - {item.title}</div>
                                  {(item.option_values?.join(' ') || item.variant_value).split('/').map((val, idx) => (
                                    <span key={idx} className="badge badge-pill bg-dark text-light me-1">
                                      {val.trim()}
                                    </span>
                                  ))}


                                  {/* ⭐ Added FREE badge — only when discountType is 'buyx' */}
                                  {discountType === "buyx" &&
                                    buyxDiscont?.applicableProducts
                                      ?.filter((d) => d.variant_id === item.variant_id)
                                      .map((d, i) => (
                                        <div key={i}>
                                          <span className="badge bg-success text-light me-1">
                                            FREE × {d.free_count || 1}
                                          </span>
                                        </div>
                                      ))}

                                  <div className="text-primary mt-1">{currency} {Number(item.price).toFixed(2)}</div>
                                </div>
                              </div>
                            </td>
                            <td className="text-end">{item.weight}</td>
                            <td className="text-end">
                              <div className="d-flex align-items-center gap-2">
                                {item.measurement_needed ? (
                                  <div className='d-flex gap-1 align-items-center'>
                                    {/* <Form.Control
                                  type="number"
                                  size="sm"
                                  min={1}
                                  value={item.selectedQty ?? 1}
                                  onChange={(e) => handleQtyInput(item.variant_id, e.target.value)}
                                  style={{ width: 120, textAlign: 'end' }}
                                /> */}
                                    <ProductMeasurementQuantity
                                      setAddedproducts={setAddedproducts}
                                      item={item}
                                      count={item.count}
                                      value={item.amount_per_unit}
                                    />
                                    <span>{item.measurement_needed ? item.measurement_value : 'piece(s)'}</span>
                                  </div>
                                ) : (
                                  <div className='d-flex gap-1 align-items-center'>
                                    <Form.Control
                                      type="number"
                                      size="sm"
                                      min={1}
                                      value={item.selectedQty ?? 1}
                                      onChange={(e) => handleQtyInput(item.variant_id, e.target.value)}
                                      style={{ width: 80, textAlign: 'end' }}
                                    />
                                    <span>{item.measurement_needed ? item.measurement_value : 'piece(s)'}</span>
                                  </div>
                                )}
                              </div>
                            </td>

                            <td className="text-end">
                              {/* If discountType is 'product' and this item has a discount, show strike-through original and discounted total */}
                              {discountType === "product" && productDiscForItem ? (
                                <div className="d-flex flex-column align-items-end">
                                  <div style={{ textDecoration: "line-through", opacity: 0.6 }}>
                                    {originalTotal.toFixed(2)}
                                  </div>
                                  <div style={{ fontWeight: 600 }}>
                                    {finalTotal.toFixed(2)}
                                  </div>
                                </div>
                              ) : (
                                // default: no product discount applied
                                <div> {originalTotal.toFixed(2)}</div>
                              )}
                            </td>
                            <td className="">
                              <Button variant="link" className="text-danger" onClick={() => handleRemove(item.variant_id)}>
                                <Icon icon="material-symbols:delete" width="20" height="20" style={{ color: '#ff2626' }} />
                              </Button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </Table>
                )}
                {addedproducts.length < 1 && (
                  <div className="d-flex flex-column justify-content-center align-items-center">
                    <Image src={'/flat-modern-illustration-empty-cart.png'} rounded width={500} height={500} style={{ objectFit: 'cover' }} />
                    <div className="fw-semibold fs-5 text-muted">No products added</div>
                  </div>
                )}
              </div>

              {/* payment details */}
              {addedproducts.length > 0 && (
                <>
                  <div className="fw-semibold fs-5 mt-3">Payment</div>
                  <Card className="border mt-1">
                    <CardBody className="py-2">
                      <div className="d-flex justify-content-between align-items-center">
                        <div className="">Subtotal</div>
                        <div className="">{totalQty} items</div>
                        <div className="">
                          {currency}{' '}
                          {lastSubTotal.toFixed(2)}</div>
                      </div>
                      <div className="d-flex justify-content-between align-items-center mt-1">
                        <div className="d-flex gap-2 align-items-center flex-grow-1">
                          {{
                            order: 'Order Discount',
                            product: 'Product Discount',
                            payment_method: 'Payment Method Discount',
                            buyx: 'BuyXGetY Discount'
                          }[discountType] || 'Discount'}
                          <FormControl
                            type="text"
                            placeholder={discountManualType === 'percent' ? '0%' : '0.00'}
                            value={discount}
                            onChange={handleDiscount}
                            className="text-end"
                            style={{ maxWidth: '80px', height: 30 }}
                          />
                          <Form.Select
                            size="sm"
                            style={{ maxWidth: 90, height: 30 }}
                            value={discountManualType}
                            onChange={(e) => {
                              setDiscountManualType(e.target.value)
                              setDiscount('')
                            }}>
                            <option value="fixed">{currency}</option>
                            <option value="percent">%</option>
                          </Form.Select>
                        </div>
                        <div className="d-flex align-items-center gap-2">
                          {(discountType == 'order' || discountType == 'product' || discount || discountType == 'payment_method') ? (
                            <span className=" ms-2">{parseFloat(totalDiscount.discountValue).toFixed(2)}</span>
                          ) : (
                            <span className=" ms-2">{parseFloat(0).toFixed(2)}</span>

                          )}
                        </div>
                      </div>

                      <div className="d-flex justify-content-between align-items-center mt-1">
                        <div className="">Delivery Fee</div>
                        <div className=""></div>
                        <div className="">
                          <FormControl
                            type="text"
                            placeholder=""
                            value={deliveryFee}
                            onChange={(e) => {
                              const value = e.target.value
                              // Only integers allowed
                              const intRegex = /^\d+$/;
                              if (!intRegex.test(value)) return;

                              setDeliveryFee(value)
                            }}
                            className="text-end"
                            style={{ maxWidth: '100px' }}
                          />
                        </div>
                      </div>
                      {discountType == 'shipping' && (
                        <div className="d-flex justify-content-between align-items-center mt-2">
                          <div className="">Delivery Fee Discount</div>
                          <div className="">{currency} {parseFloat(totalDiscount.discountValue).toFixed(2)}</div>
                        </div>
                      )}
                      <div className="d-flex justify-content-between align-items-center mt-2">
                        <div className="">Weight</div>

                        <div className="">{totalWight.toFixed(2)} Kg</div>
                      </div>
                      {taxEnabled && (
                        <div className="d-flex justify-content-between align-items-center mt-2">
                          <div className="d-flex align-items-center gap-1">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="saveInfoCheck"
                              name="saveInfo"
                              checked={billingaddressSame}
                              onChange={(e) => setBillingaddressSame(e.target.checked)}
                            />
                            {taxFields.key} ({taxFields.value}%)
                          </div>

                          <div className="">{currency} {totalTax.toFixed(2)}</div>
                        </div>
                      )}
                      <div className="d-flex justify-content-between align-items-center mt-2">
                        <div className="fw-semibold">Total</div>
                        <div className="fw-semibold">{currency} {fullAmount.toFixed(2)}</div>
                      </div>
                    </CardBody>
                  </Card>
                </>
              )}

              {addedproducts.length > 0 && (
                <div className="text-end mt-2">
                  <Button variant="primary" className="bg-primary border-primary px-4" onClick={handleAddProduct}>
                    Update Order
                  </Button>
                </div>
              )}
            </Col>

            {/* Delivery and Billing compoenent  */}
            <Col md={4}>
              {/* Add content for the second column here */}
              <Card className="border">
                <CardBody>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className="fw-bold " style={{ fontSize: '18px' }}>Billing & Delivery</div>

                    {selectClient && (
                      <Dropdown>
                        <DropdownToggle variant="secondaryyy" className="btn-sm text-dark p-0" type="button">
                          <Icon icon="mage:dots" width="20" height="20" />
                        </DropdownToggle>
                        <DropdownMenu>
                          <DropdownItem href="" onClick={() => {
                            setSelectClient(null)
                            setClientDetails({
                              first_name: '',
                              last_name: '',
                              contact_number_1: '',
                              address: '',
                              apartment: '',
                              city: '',
                              postal_code: '',
                              email: '',
                              country: ''
                            })
                          }}>
                            Remove Customer
                          </DropdownItem>
                          <DropdownItem href="" onClick={() => setShowEdit(true)}>
                            Edit Customer
                          </DropdownItem>
                          <DropdownItem href="" onClick={() => setShowBilling(true)}>
                            Edit Delivery Details
                          </DropdownItem>
                        </DropdownMenu>
                      </Dropdown>
                    )}
                  </div>

                  <div className="mt-2">
                    {!selectClient && (
                      <Select
                        options={clientOptions}
                        value={clientOptions.find((option) => option.value === selectClient?.value) || null} // Set selected option correctly
                        onChange={(selectedOption) => {
                          if (selectedOption?.value === 'add_customer') {
                            setShowCreateCustomer(true)
                            setSelectClient(null) // reset selection
                          } else {
                            setSelectClient(selectedOption ? selectedOption : null)
                          }
                        }}
                        // onChange={(selectedOption) => setSelectClient(selectedOption ? selectedOption : null)}
                        placeholder="Select Client"
                        isClearable
                        onInputChange={(inputValue, actionMeta) => {
                          if (actionMeta.action === 'input-change') {
                            handleClientSearch(inputValue) // Call function to send search query to backend
                          }
                        }}
                        filterOption={() => true}
                      />
                    )}

                    {selectClient && (
                      <>
                        {/* Contact Info */}
                        <div className="d-flex  border-bottom pt-1 mb-2 align-items-center">
                          <div className="fw-bold" style={{ fontSize: '15px' }}>Billing Details</div>
                          <Button variant="link" className="text-danger" onClick={() => setShowEdit(true)}>
                            <Icon icon="akar-icons:edit" width="18" height="18" style={{ color: '#8e8e8e' }} />
                          </Button>
                        </div>
                        <div
                          className="p-1 position-relative"
                          style={{
                            backgroundImage: "url('/invoice.png')",
                            opacity: 0.8,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'right bottom',
                            backgroundSize: '120px', // Adjust size as needed
                            minHeight: '120px', // Optional, ensures image shows even if no text
                          }}>
                          #{clientDetails?.value} {clientDetails?.first_name} {clientDetails?.last_name}
                          <div className="text-primary text-break mb-1">{clientDetails?.email}</div>
                          <div className="text-muted small mb-1">{clientDetails?.contact_number_1 || 'No phone number'}</div>
                          <div className={`mb-1 ${clientDetails?.address ? '' : 'text-danger'}`}>{clientDetails?.address || 'No address'}</div>
                          <div className={`mb-1 ${clientDetails?.city ? '' : 'text-danger'}`}>
                            {clientDetails?.city ? clientDetails?.city : 'No city'}
                          </div>
                          <div className={`mb-1 `}>{clientDetails?.country_name ? (clientDetails?.country_name) : 'Sri Lanka'}</div>
                          {(Number(selectClient?.loyalty_point) + Number(orderDetails.loyalty_points_spent) + Number(orderDetails.loyalty_points_earned)) > 0 && (

                            <div
                              className="badge rounded-pill"
                              style={{ backgroundColor: '#7b4bff', color: 'white', fontSize: '10px', padding: '4px 8px' }}
                            >
                              <div className='d-flex align-items-center justify-content-center gap-1'>

                                <Icon icon="mdi:gift" className="" />
                                Loyalty: {(Number(selectClient?.loyalty_point) + Number(orderDetails.loyalty_points_spent) - Number(orderDetails.loyalty_points_earned)).toFixed(2)}
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                </CardBody>
              </Card>

              {/* Shipping Address */}
              {selectClient && (
                <Card className="mt-2 border">
                  <CardBody>
                    <div className="">
                      <div className="d-flex  border-bottom pt-1 mb-2 align-items-center">
                        <div className="fw-bold" style={{ fontSize: '15px' }}>Delivery Details</div>
                        <Button variant="link" className="text-danger" onClick={() => setShowBilling(true)}>
                          <Icon icon="akar-icons:edit" width="18" height="18" style={{ color: '#8e8e8e' }} />
                        </Button>
                      </div>

                      <div className="btn-group" role="group" aria-label="Address option toggle group">
                        <input
                          type="radio"
                          className="btn-check"
                          name="addressOption"
                          id="btnradio1"
                          autoComplete="off"
                          value="same_as_billing"
                          checked={selected === "same_as_billing"}
                          onChange={() => handleBillingAdress("same_as_billing")}
                        />
                        <label className="btn btn-outline-primary" htmlFor="btnradio1">
                          Same as Billing Address
                        </label>



                        <input
                          type="radio"
                          className="btn-check"
                          name="addressOption"
                          id="btnradio3"
                          autoComplete="off"
                          value="default"
                          checked={selected === "default"}
                          onChange={() => handleBillingAdress("default")}
                        />
                        <label className="btn btn-outline-primary" htmlFor="btnradio3">
                          Different Address
                        </label>

                        <input
                          type="radio"
                          className="btn-check"
                          name="addressOption"
                          id="btnradio2"
                          autoComplete="off"
                          value="store_pickup"
                          checked={selected === "store_pickup"}
                          onChange={() => handleBillingAdress("store_pickup")}
                        />
                        <label className="btn btn-outline-primary" htmlFor="btnradio2">
                          Store Pickup
                        </label>
                      </div>

                      {selected === "store_pickup" && (
                        <div
                          className="p-1 position-relative"
                          style={{
                            backgroundImage: "url('/store 2.png')",
                            opacity: 0.9,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'center',
                            backgroundSize: '140px', // Adjust size as needed
                            minHeight: '120px', // Optional, ensures image shows even if no text
                            marginTop: '20px',
                          }}>
                        </div>
                      )}

                      {selected === "same_as_billing" && (
                        <div
                          className="p-1 position-relative"
                          style={{
                            backgroundImage: "url('/delivery.png')",
                            opacity: 0.9,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'right bottom',
                            backgroundSize: '120px', // Adjust size as needed
                            minHeight: '120px', // Optional, ensures image shows even if no text
                            marginTop: '20px',
                          }}>
                          <>
                            {/* <div className="fw-semibold mb-1">Delivery to</div> */}
                            <div className="mb-1">
                              {clientDetails?.first_name} {clientDetails?.last_name}
                            </div>
                            <div className="text-primary text-break mb-1">{clientDetails?.email}</div>
                            <div className="text-muted small mb-1">{clientDetails?.contact_number_1 || 'No phone number'}</div>
                            <div className=" mb-1">{clientDetails?.address || 'No address'}</div>
                            <div className=" mb-1">{clientDetails?.city ? clientDetails?.city : 'No city'}</div>
                            <div className=" mb-3">{clientDetails?.country_name ? (clientDetails?.country_name) : 'Sri Lanka'}</div>
                          </>
                        </div>
                      )}

                      {selected === "default" && (
                        <div
                          className="p-1 position-relative"
                          style={{
                            backgroundImage: "url('/delivery.png')",
                            opacity: 0.9,
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'right bottom',
                            backgroundSize: '120px', // Adjust size as needed
                            minHeight: '120px', // Optional, ensures image shows even if no text
                            marginTop: '20px',
                          }}>
                          <div>
                            <div className="fw-semibold mb-1">Delivery to</div>
                            <div className="mb-1">{billingaddress?.first_name}</div>
                            <div className="text-primary text-break mb-1">{billingaddress?.email}</div>
                            <div className="text-muted small mb-1">{billingaddress?.contact_number_1 || 'No phone number'}</div>
                            <div className=" mb-1">{billingaddress?.address || 'No address'}</div>
                            <div className=" mb-1">{billingaddress?.city ? billingaddress?.city : 'No city'}</div>
                            <div className=" mb-3">{billingaddress?.country_name ? (billingaddress?.country_name) : 'Sri Lanka'}</div>
                          </div>
                        </div>
                      )}
                    </div>

                  </CardBody>
                </Card>
              )}
            </Col>
          </Row>
        )}
      </ComponentContainerCard>

      {showProductModal && (
        <ShowProduct
          open={showProductModal}
          setOpen={setShowProductModal}
          search={search}
          setAddedproducts={setAddedproducts}
          addedproducts={addedproducts}
          setSearch={setSearch}
        />
      )}

      {showEdit && <EditCustomer open={showEdit} setOpen={setShowEdit} clientDetails={clientDetails} setClientDetails={setClientDetails} countries={countries} />}

      {showBilling && (
        <AddBillingDetails open={showBilling} setOpen={setShowBilling} clientDetails={billingaddress} setClientDetails={setBillingaddress} countries={countries} />
      )}

      {showCreateCustomer && (
        <CreateCustomer 
        open={showCreateCustomer} 
        setOpen={setShowCreateCustomer} 
        clientDetails={clientDetails} 
        setClientDetails={setClientDetails} 
        countries={countries} 
        onCustomerCreated={(customer) => {
      // 1️⃣ add to select options
      setAllClient((prev) => [...prev, customer])

      // 2️⃣ auto select
      setSelectClient(customer)
    }}
        />
      )}

      {showPayment && (
        <ShowPaymentUpdate
          open={showPayment}
          setOpen={setShowPayment}
          allPaymentMethod={allPaymentMethod}
          selectedPaymentMethod={selectedPaymentMethod}
          setSelectedPaymentMethod={setSelectedPaymentMethod}
          fullAmount={fullAmount}
          addedproducts={addedproducts}
          selectClient={selectClient}
          clientDetails={clientDetails}
          billingaddressSame={billingaddressSame}
          billingaddress={billingaddress}
          deliveryFee={deliveryFee}
          discount={totalDiscount.discountValue}
          totalTax={totalTax}
          taxValue={taxFields.value}
          discountType={discountType}
          selected={selected}
          taxname={taxFields.key}
          currency={currency}
          totalAmount={totalAmount}
          setPaymentMethodDiscount={setPaymentMethodDiscount}
          getDiscountDetails={getDiscountDetails}
          orderId={order_id}
          orderDetails={orderDetails}
          lastSubTotal={lastSubTotal}
        />
      )}

    </div>
  )
}

export default UpdateOrders
