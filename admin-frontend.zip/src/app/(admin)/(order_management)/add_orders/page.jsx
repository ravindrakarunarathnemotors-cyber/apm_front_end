import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Add Order',
}

const AddOrders = dynamic(() => import('./AddOrders'), { ssr: false })

export default function AddOrdersPage() {
  return <AddOrders />
}