'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import EditOrderModal from './EditOrderModal'

import { useRouter } from 'next/navigation'

import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Button,
  Table,
  Pagination,
  Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import View from '../pending_orders/components/view'
import MarkAsPaidModal from '@/components/Order/MarkAsPaidModal'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import CancelModal from '@/components/Order/cancelModal'
import ConfirmModal from '../pending_orders/components/confirmmodal'
import {
  useGetFilteredAllOrdersMutation,
  useGetRecipientnameQuery,
  useGetActiveDeliveryPartnersQuery,
  useAssignOrderMutation,
  useProcessingOrdersOrderMutation,
  useCancelOrderMutation,
  useMarkOrderAsDispatchedMutation,
  useDeliverdOrderMutation,
  useConfirmOrdersOrderMutation,
} from '@/store/features/apiSlice'

function AllOrders() {

  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })
 
  const [orderStatuses, setOrderStatuses] = useState([])
  const [fetchFilteredOrders, { isLoading, error }] = useGetFilteredAllOrdersMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [totalPages, setTotalPages] = useState(1)
  const [orders, setLogs] = useState([])
  const [totalEntries, setTotalEntries] = useState(0)
  const logsPerPage = 25
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [loading, setLoading] = useState(false)
  const [showViewModal, setShowViewModal] = useState(false)
  const [showMarkAsPaidModal, setShowMarkAsPaidModal] = useState(false)
  const [selectedPaidOrder, setSelectedPaidOrder] = useState(null)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showEditModal, setShowEditModal] = useState(false)
  const [editOrderData, setEditOrderData] = useState(null)
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrderId, setCancelOrderId] = useState(null)
  const [currency, setCurrency] = useState('')
  const [limit, setLimit] = useState(10)
  

  const printSectionRef = useRef()
  const router = useRouter()

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })
  const [assignOrder] = useAssignOrderMutation()
  const [processingOrder] = useProcessingOrdersOrderMutation()
  const [cancelOrder] = useCancelOrderMutation()
  const [markOrderAsDispatched] = useMarkOrderAsDispatchedMutation()
  const [deliverdOrder] = useDeliverdOrderMutation()
  const [confirmOrder] = useConfirmOrdersOrderMutation()

  const { data: activePartnersData = [], isLoading: loadingPartners } = useGetActiveDeliveryPartnersQuery()
  const orderStatusOptions = [
    { label: 'Pending', value: 'pending' },
    { label: 'Confirmed', value: 'confirmed' },
    { label: 'Processing', value: 'processing' },
    { label: 'Dispatched', value: 'dispatched' },
    { label: 'Completed', value: 'completed' },
    { label: 'Returned', value: 'returned' },
  ]
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handleView = (order) => {
    setSelectedOrderId(order)
    setShowViewModal(true)
  }

  const handleMarkAsPaid = (order) => {
    setSelectedPaidOrder(order)
    setShowMarkAsPaidModal(true)
  }

  const handleUnpaidClick = (order_id) => {
    setSelectedOrderId(order_id)
    setShowUnpaidModal(true)
  }

  const handleUnpaidCloseModal = () => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
  }


  

  const fetchLogs = async (page, customLimit = logsPerPage) => {
  setLoading(true)

  const payload = {
    page,
    limit: customLimit,
    keyword: filters.keyword,
    order_id: orderId,
    recipient_name: recipientName,
    mobile: mobileNo,
    payment_status: paymentStatus,
    date,
    todate,
    order_status: orderStatuses.map((s) => s.value),
  }

  try {
    const res = await fetchFilteredOrders(payload).unwrap()

    setLogs(res.orders || [])
    setTotalPages(res.totalPages || 1)
    setCurrentPage(page)
    setTotalEntries(res.total || 0) 
    // ✅ FIXED (no duplicate setState)
    setCurrency(res.currency || res.orders?.[0]?.currency || '')

  } catch (err) {
    console.error('Failed to fetch orders:', err)

  } finally {
    setLoading(false)
  }
}

  useEffect(() => {
    fetchLogs(1, limit)
  }, [])

  // const handleConfirm = (orderId) => {
  //   setSelectedOrderId(orderId)
  //   setShowModal(true)
  // }
  const handleConfirm = (order) => {
    setSelectedOrder(order)
    setSelectedOrderId(order?.order_id ?? null)
    setShowModal(true)
  }

 

  const handlePageChange = (page) => {
  setCurrentPage(page)
  fetchLogs(page, limit)
}

const handleLimitChange = (e) => {
  const newLimit = Number(e.target.value)

  setLimit(newLimit)
  setCurrentPage(1)

  fetchLogs(1, newLimit)
}

  const paymentStatusBadge5 = (status) => {
    const colorMap = {
      processing: '#fd7e14',
      pending: '#6c757d',
      completed: '#198754',
      dispatched: '#0d6efd',
      returned: '#6f42c1',
      confirmed: '#20c997',
      cancelled: '#dc3545',
    }

    const backgroundColor = colorMap[status?.toLowerCase()] || '#adb5bd'

    return (
      <span
        style={{
          backgroundColor,
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        {status}
      </span>
    )
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'danger',
      refund: 'secondary',
      failed: 'danger',
    }

    const color = colorMap[status] || 'secondary'
    const capitalizedStatus = status.charAt(0).toUpperCase() + status.slice(1)

    return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  }

  const handleModalConfirm = async ({ type, partnerId = null }) => {
   
   
    const orderId = selectedOrderId?.order_id || selectedOrderId

    const payload = {
      order_id: orderId,
      status: 'confirmed',
      partnerId,
      ...(type === 'storepickup' ? { assignment_type: 'storepickup' } : { delivery_partner_id: partnerId }),
    }

    try {
      const res = await assignOrder(payload).unwrap()
      // IMPORTANT: API may return 200 with success:false → treat as an error
      if (!res?.success) {
        throw new Error(res?.message || 'Failed to assign order')
      }

      await Swal.fire('Success', 'Order assigned successfully!', 'success')
      await fetchLogs(currentPage)
      setShowModal(false)
      setSelectedOrderId(null)
      // optionally: refresh list here if you need
      // await fetchLogs(currentPage)
      return true // return truthy so child can know it really succeeded if needed
    } catch (err) {
      const data = err?.data || err?.error?.data || err?.response?.data || err

      //  INSF STOCK HANDLING (same UX as Pending Orders)
      if (data?.error_code === 'INSUFFICIENT_STOCK' && Array.isArray(data.items)) {
        const rows = data.items
          .map(
            (item, index) => `
          <tr>
            <td style="padding:6px 8px;">${index + 1}</td>
            <td style="padding:6px 8px;">
              <strong>${item.variant_value || 'N/A'}</strong><br/>
              <small style="color:#6c757d">
                Variant ID: ${item.variant_id}
              </small>
            </td>
            <td style="padding:6px 8px; color:#198754;">
              ${item.current_stock}
            </td>
            <td style="padding:6px 8px; color:#dc3545;">
              ${item.required}
            </td>
          </tr>
        `,
          )
          .join('')

        await Swal.fire({
          icon: 'warning',
          title: 'Insufficient Stock',
          html: `
        <div style="text-align:left">
          <p>
            The following item(s) do not have enough stock
            to confirm this order:
          </p>

          <table style="width:100%; border-collapse:collapse; font-size:13px">
            <thead>
              <tr style="background:#f8f9fa">
                <th style="padding:6px 8px">#</th>
                <th style="padding:6px 8px">Variant</th>
                <th style="padding:6px 8px">Available</th>
                <th style="padding:6px 8px">Required</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>

          <hr style="margin:10px 0"/>

          <p style="margin-bottom:4px; color:#dc3545">
            <strong>Continue Selling:</strong> OFF
          </p>

          <p style="font-size:12px; color:#6c757d">
            Stock cannot go below zero while
            <b> Continue Selling </b> is disabled.
          </p>
        </div>
      `,
          confirmButtonText: 'OK',
          confirmButtonColor: '#0d6efd',
          width: 600,
        })

        // STOP FLOW — modal stays open
        throw err
      }

      // fallback for all other errors
      await Swal.fire('Error', data?.message || err?.message || 'Failed to assign order', 'error')

      throw err
    }
  }

  //Complete

  const handleProcessOrComplete = async (order) => {
    const isStorePickup =
      String(order?.storepickup ?? '')
        .toLowerCase()
        .trim() === 'yes'
    const status = isStorePickup ? 'completed' : 'processing'
   

    const result = await Swal.fire({
      title: isStorePickup ? 'Complete order?' : 'Set order to Processing?',
      text: `Do you really want to ${isStorePickup ? 'complete' : 'set processing for'} order ${order.order_id}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: isStorePickup ? 'Yes, complete it!' : 'Yes, set processing!',
      cancelButtonText: 'No, keep it',
    })

    if (!result.isConfirmed) return

    try {
      const res = await processingOrder({
        order_id: order.order_id,
        status,
      })

      await Swal.fire({
        title: 'Success',
        text: res.message || (isStorePickup ? 'Order marked as completed.' : 'Order set to processing.'),
        icon: 'success',
      })

      await fetchLogs(currentPage)
    } catch (err) {
      console.error('Error:', err)
      await Swal.fire({
        title: 'Error',
        text: err.message || 'Something went wrong while processing the order.',
        icon: 'error',
      })
    }
  }
  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  const handleProcessing = async (orderId) => {
    
    try {
      const res = await processingOrder({
        order_id: orderId,
        status: 'processing',
        
      })

      Swal.fire({
        icon: 'success',
        title: 'Order moved to Processing',
        text: res.message || 'Order status updated successfully.',
        timer: 2000,
        showConfirmButton: false,
      })
      await fetchLogs(currentPage)
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }
  //Cancel
  const handleCancel = async (orderId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to cancel order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, cancel it!',
      cancelButtonText: 'No, keep it',
    })

    if (result.isConfirmed) {
    
      try {
        const res = await cancelOrder({
          order_id: orderId,
          status: 'cancelled',
        }).unwrap()

        Swal.fire('Cancelled', res.message, 'success')
        fetchOrders(currentPage)
      } catch (err) {
        console.error('Cancel error:', err)
        Swal.fire('Error', 'Failed to cancel the order.', 'error')
      }
    }
  }

  const handleCancel1 = async (orderId) => {
    try {
      const { isConfirmed } = await Swal.fire({
        title: 'Are you sure?',
        text: `Do you really want to cancel order ${orderId}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, cancel it!',
        cancelButtonText: 'No, keep it',
      })

      if (!isConfirmed) return

     
     

      await cancelOrder({
        order_id: orderId,
        status: 'cancelled',
        
      }).unwrap()

      await Swal.fire('Cancelled', `Order ${orderId} was cancelled successfully.`, 'success')
      await fetchLogs(currentPage)
    } catch (err) {
      const msg = err?.data?.message || err?.error || err?.message || 'Something went wrong while cancelling the order.'
      await Swal.fire('Error', msg, 'error')
    }
  }

  //Processing dispatch

  const handleDispatch = (orderId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to mark order ${orderId} as dispatched?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Dispatch it!',
      cancelButtonText: 'Cancel',
    }).then(async (result) => {
      if (!result.isConfirmed) return

    

      try {
        const payload = {
          order_id: orderId,
          dispatched: true,
         
        }

        const res = await markOrderAsDispatched(payload).unwrap()

        if (res?.success && res.dispatched === 'success') {
          await Swal.fire('Success', `Order ${orderId} marked as dispatched.`, 'success')
          await fetchLogs(currentPage)
        } else {
          Swal.fire('Warning', 'Order could not be marked as dispatched.', 'warning')
        }
      } catch (err) {
        console.error('Error updating order:', err)
      }
    })
  }

  const handleDeliverd = async (orderId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to complete order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, complete it!',
      cancelButtonText: 'No, keep it',
    })

    if (!result.isConfirmed) return

   

    try {
      const response = await deliverdOrder({
        order_id: orderId,
        status: 'completed',
      }).unwrap()

      const message = response?.message || `Order ${orderId} marked as completed.`

      await Swal.fire('Completed', message, 'success')
      await fetchLogs(currentPage)
    } catch (err) {
      console.error('Completed error:', err)
    }
  }

  const handleconfirmOrder = async (orderId) => {
   
    try {
      const res = await confirmOrder({
        order_id: orderId,
        status: 'confirmed',
        
      })

      Swal.fire({
        icon: 'success',
        title: 'Order moved to confirmOrder',
        text: res.message || 'Order status updated successfully.',
        timer: 2000,
        showConfirmButton: false,
      })
      await fetchLogs(currentPage)
    } catch (err) {
      console.error('Failed to move order to processing:', err)
      Swal.fire({
        icon: 'error',
        title: 'Failed to update order status',
        text: err?.data?.message || 'An unexpected error occurred.',
      })
    }
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }

  const handleOpenCancelModal = (orderId) => {
    setCancelOrderId(orderId)
    setShowCancelModal(true)
  }

  const handleConfirmCancelFromModal = async (orderIdToCancel, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelOrder({
        order_id: orderIdToCancel,
        status: 'cancelled',
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh list
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await fetchLogs(currentPage)
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              All Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Keyword</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-1">
                <FormLabel>Payment</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="paid">Paid</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="refund">Refund</option>
                  <option value="failed">Failed</option>
                </Form.Select>
              </FormGroup>
              <FormGroup className="col-md-4">
                <FormLabel>Order Status</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderStatusOptions}
                  isMulti
                  placeholder="Select Status"
                  value={orderStatuses}
                  onChange={(selectedOptions) => setOrderStatuses(selectedOptions)}
                />
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>
            {isLoading ? (
              <p>Loading Orders...</p>
            ) : error ? (
              <p>Error Loading Orders.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <Table striped className="table my-2">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Client</th>
                        <td>City</td>
                        <th>Courier</th>
                        <th>Tracking</th>
                        <th>Payment</th>
                        <th className="text-end">Total ({currency})</th>

                        <th className="text-center no-print">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="text-center">
                            No Orders found.
                          </td>
                        </tr>
                      ) : (
                        orders.map((order) => (
                          <tr key={order.order_id}>
                            <td>
                              {order.order_id}
                              <br />
                              <td>{paymentStatusBadge5(order.order_status)}</td>
                            </td>
                            <td>
                              {new Date(order.created_at).toLocaleDateString('en-LK', {
                                timeZone: 'Asia/Colombo',
                              })}
                            </td>
                            <td>
                              {order.customer_name}
                              <br />
                              <small>{order.contact_number}</small>
                            </td>
                            <td>
                              {order.recipient_city ? order.recipient_city.charAt(0).toUpperCase() + order.recipient_city.slice(1).toLowerCase() : ''}
                            </td>
                            <td> {order.delivery_partner_name || '-'}</td>
                            <td>{order.tracking_id || '-'}</td>
                            <td>
                              {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : ''}

                              {hasSlip(order) && (
                                <div className="mt-1 no-print">
                                  <Button
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.2rem 0.1rem',
                                      fontSize: '0.55rem',
                                      height: '20px',
                                      borderRadius: '15px',
                                      backgroundColor: '#3d3642ff',
                                      borderColor: '#3d3642ff',
                                      color: '#fff',
                                    }}
                                    variant="outline-primary"
                                    onClick={() => openSlip(order)}
                                    title="Open bank slip"
                                    className="d-inline-flex align-items-center gap-1 px-2 py-1">
                                    <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                    Slip
                                  </Button>
                                </div>
                              )}
                            </td>
                            <td className="text-end">{Number(order.full_amount).toFixed(2)}</td>

                            <td className="text-end no-print">
                              <div className="d-flex flex-row align-items-center justify-content-end gap-2">
                                {order.order_status?.toLowerCase() === 'pending' && order.payment_status.toLowerCase() === 'unpaid' && (
                                  <>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#fd7e14',
                                        borderColor: '#fd7e14',
                                        color: '#fff',
                                      }}
                                      onClick={() => router.push(`/update_orders?order_id=${order.order_id}`)}>
                                      <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Edit</span>
                                    </Button>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#28a745',
                                        borderColor: '#28a745',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleConfirm(order)}>
                                      <Icon icon="mdi:check" width={18} className="me-1" />
                                      Confirm
                                    </Button>
                                    {/* <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#dc3545',
                                        borderColor: '#dc3545',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleCancel1(order.order_id)}>
                                      <Icon icon="mdi:close" width={18} className="me-1" />
                                      Cancel
                                    </Button> */}
                                    {order.payment_status?.toLowerCase() === 'unpaid' && (
                                      <Button
                                        className="d-flex align-items-center"
                                        style={{
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#dc3545',
                                          borderColor: '#dc3545',
                                          color: '#fff',
                                        }}
                                        onClick={() => {
                                          setCancelOrderId(order.order_id)
                                          setShowCancelModal(true)
                                        }}>
                                        <Icon icon="mdi:close" width={18} className="me-1" />
                                        Cancel
                                      </Button>
                                    )}
                                  </>
                                )}
                                {order.order_status?.toLowerCase() === 'confirmed' && (
                                  <>
                                    {String(order?.storepickup ?? '')
                                      .toLowerCase()
                                      .trim() === 'yes' ? (
                                      <Button
                                        className="d-flex align-items-center justify-content-center"
                                        style={{
                                          minWidth: '90px',
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#055318ff',
                                          borderColor: '#055318ff',
                                          color: '#fff',
                                        }}
                                        onClick={() => handleProcessOrComplete(order)}>
                                        <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                        <span>Complete</span>
                                      </Button>
                                    ) : (
                                      <Button
                                        className="d-flex align-items-center justify-content-center"
                                        style={{
                                          minWidth: '90px',
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                          backgroundColor: '#d37e39ff',
                                          borderColor: '#d37e39ff',
                                          color: '#fff',
                                        }}
                                        onClick={() => handleProcessOrComplete(order)}>
                                        <Icon icon="mdi:clipboard-clock-outline" width={15} height={20} style={{ marginRight: '4px' }} />
                                        <span>Processing</span>
                                      </Button>
                                    )}

                                    {/* <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#dc3545',
                                        borderColor: '#dc3545',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleCancel1(order.order_id)}>
                                      <Icon icon="mdi:close" width={18} className="me-1" />
                                      Cancel
                                    </Button> */}
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#dc3545',
                                        borderColor: '#dc3545',
                                        color: '#fff',
                                      }}
                                      onClick={() => {
                                        setCancelOrderId(order.order_id)
                                        setShowCancelModal(true)
                                      }}>
                                      <Icon icon="mdi:close" width={18} className="me-1" />
                                      Cancel
                                    </Button>
                                  </>
                                )}

                                {order.order_status?.toLowerCase() === 'dispatched' && (
                                  <>
                                    <Button
                                      className="d-flex align-items-center justify-content-center"
                                      style={{
                                        minWidth: '90px',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#28a745',
                                        borderColor: '#28a745',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleDeliverd(order.order_id)}>
                                      <Icon icon="mdi:truck-check" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Complete</span>
                                    </Button>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#fd7e14',
                                        borderColor: '#fd7e14',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleProcessing(order.order_id)}>
                                      <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Back to Processing</span>
                                    </Button>
                                  </>
                                )}

                                {order.order_status?.toLowerCase() === 'processing' && (
                                  <>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.5rem',
                                        fontSize: '1rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#28a745',
                                        borderColor: '#28a745',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleDispatch(order.order_id)}>
                                      <Icon icon="mdi:truck" width={20} height={20} style={{ marginRight: '4px' }} />
                                      <span style={{ fontSize: '0.65rem' }}>Dispatched</span>
                                    </Button>
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#18311eff',
                                        borderColor: '#18311eff',
                                        color: '#fff',
                                      }}
                                      onClick={() => handleconfirmOrder(order.order_id)}>
                                      <Icon icon="mdi:arrow-left-bold" width={15} height={20} style={{ marginRight: '4px' }} />
                                      <span>Back to Confirm</span>
                                    </Button>
                                  </>
                                )}

                                {order.payment_status?.toLowerCase() === 'unpaid' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#035f1c',
                                      borderColor: '#035f1c',
                                      color: '#fff',
                                      whiteSpace: 'nowrap',
                                    }}
                                    onClick={() => handleMarkAsPaid(order)}>
                                    <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                                  </Button>
                                )}
                                {order.payment_status?.toLowerCase() === 'paid' && (
                                  <Button
                                    className="d-flex align-items-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      backgroundColor: '#7e111b',
                                      borderColor: '#7e111b',
                                      color: '#fff',
                                      whiteSpace: 'nowrap',
                                    }}
                                    onClick={() => handleUnpaidClick(order.order_id)}>
                                    <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                                  </Button>
                                )}
                                <Button
                                  className="d-flex align-items-center"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#5f5f5f',
                                    borderColor: '#5f5f5f',
                                    color: '#fff',
                                  }}
                                  onClick={() => handleView(order)}>
                                  <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>View</span>
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>
                <div className="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-3">

  {/* LEFT SIDE */}
  <div className="d-flex align-items-center gap-2">
    <span>Show</span>

    <Form.Select
      value={limit}
      onChange={handleLimitChange}
      style={{ width: '90px' }}
    >
      <option value={10}>10</option>
      <option value={25}>25</option>
      <option value={50}>50</option>
      <option value={100}>100</option>
    </Form.Select>

    <span>entries</span>
  </div>

  {/* RIGHT SIDE */}
  <div className="d-flex align-items-center gap-3 flex-wrap">

    {/* SHOWING TEXT */}
    <div className="text-muted">
      Showing{' '}
      {orders.length === 0
        ? 0
        : (currentPage - 1) * limit + 1}
      {' '}to{' '}
      {(currentPage - 1) * limit + orders.length}
      {' '}of {totalEntries} entries
    </div>

    {/* PAGINATION */}
    {totalPages > 1 && (
      <Pagination className="mb-0">

        <Pagination.Prev
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
        />

        {(() => {
          let pages = []

          if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) {
              pages.push(
                <Pagination.Item
                  key={i}
                  active={i === currentPage}
                  onClick={() => handlePageChange(i)}
                >
                  {i}
                </Pagination.Item>
              )
            }
          } else {
            let start = currentPage - 2
            let end = currentPage + 2

            if (start < 1) {
              start = 1
              end = 5
            }

            if (end > totalPages) {
              end = totalPages
              start = totalPages - 4
            }

            for (let i = start; i <= end; i++) {
              pages.push(
                <Pagination.Item
                  key={i}
                  active={i === currentPage}
                  onClick={() => handlePageChange(i)}
                >
                  {i}
                </Pagination.Item>
              )
            }
          }

          return pages
        })()}

        <Pagination.Next
          disabled={currentPage === totalPages}
          onClick={() => handlePageChange(currentPage + 1)}
        />

      </Pagination>
    )}
  </div>
</div>
              </>
            )}
          </CardBody>
        </Card>
      </Col>

      {showViewModal && selectedOrderId && (
        <View
          show={showViewModal}
          onClose={() => setShowViewModal(false)}
          order_id={selectedOrderId.order_id}
          storepickup={selectedOrderId.storepickup}
          context={selectedOrderId.order_status}
          activePartnersData={activePartnersData}
          loadingPartners={loadingPartners}
          handleAssignConfirm={handleModalConfirm}
          onProcess={() => handleProcessOrComplete(selectedOrderId)}
          onCancel={handleOpenCancelModal}
          onMarkAsDispatched={handleDispatch}
          onMarkAsCompleted={handleDeliverd}
          payment_method_id={selectedOrderId.payment_method_id}
        />
      )}
      {showMarkAsPaidModal && selectedPaidOrder && (
        <MarkAsPaidModal
          show={showMarkAsPaidModal}
          onClose={() => {
            setShowMarkAsPaidModal(false)
            setSelectedPaidOrder(null)
          }}
          order={selectedPaidOrder}
          onSuccess={() => fetchLogs(currentPage)}
        />
      )}

      <UnpaidModal show={showUnpaidModal} onClose={() => setShowUnpaidModal(false)} order_id={selectedOrderId} />
      <ConfirmModal
        show={showModal}
        onClose={() => setShowModal(false)}
        handleAssignConfirm={handleModalConfirm}
        activePartnersData={activePartnersData}
        loadingPartners={loadingPartners}
        delivery_partner_id={selectedOrder?.delivery_partner_id ?? null}
        order_id={selectedOrderId}
      />
      <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      />
    </Row>
  )
}

export default AllOrders
