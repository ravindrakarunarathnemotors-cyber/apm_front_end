import React, { useEffect, useState } from 'react'
import { Modal, Button, Form } from 'react-bootstrap'
import Select from 'react-select'
import { useUpdateOrderMutation } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'

const EditOrderModal = ({ show, onHide, order, onSave }) => {
  const [status, setStatus] = useState('')
  const [payment, setPayment] = useState('')
  const [total, setTotal] = useState('')
  const [updateOrder, { isLoading }] = useUpdateOrderMutation()


  useEffect(() => {
    if (order) {
      setStatus(order.order_status || '')
      setPayment(order.payment_status || '')
      setTotal(order.total_value || '')
   
    }
  }, [order])

  const statusOptions = [
  { label: 'Pending', value: 'pending' },
  { label: 'Confirmed', value: 'confirmed' },
  { label: 'Processing', value: 'processing' },
  { label: 'Dispatched', value: 'dispatched' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' },
]

  const paymentOptions = [
    { label: 'Paid', value: 'paid' },
    { label: 'Unpaid', value: 'unpaid' },
    { label: 'Refund', value: 'refund' },
    { label: 'Failed', value: 'failed' },
  ]

 

  const handleSubmit = async () => {
  const payload = {
    order_id: order?.order_id,
    order_status: status,
    payment_status: payment,
    total_value: parseFloat(total),
  }

  try {
    const response = await updateOrder(payload).unwrap()
    Swal.fire('Success', 'Order updated successfully', 'success')
    onSave?.(response)
    onHide()
  } catch (error) {
    console.error('Update failed:', error)
    Swal.fire('Error', 'Failed to update order. Please try again.', 'error')
  }
}


  return (
    <Modal show={show} onHide={onHide} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Edit Order #{order?.order_id}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Status</Form.Label>
            <Select
              options={statusOptions}
              value={statusOptions.find((o) => o.value === status)}
              onChange={(option) => setStatus(option.value)}
            />
          </Form.Group>
         
          <Form.Group className="mb-3">
            <Form.Label>Payment</Form.Label>
            <Select
              options={paymentOptions}
              value={paymentOptions.find((o) => o.value === payment)}
              onChange={(option) => setPayment(option.value)}
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Total Price</Form.Label>
            <Form.Control
              type="number"
              value={total}
              onChange={(e) => setTotal(e.target.value)}
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>Cancel</Button>
        <Button variant="primary" onClick={handleSubmit}>Save</Button>
      </Modal.Footer>
    </Modal>
  )
}

export default EditOrderModal
