import React from 'react'
import AllOrders from '../all_orders/AllOrders'

function page() {
  return (
    <>
    <AllOrders/>
     
    </>
  )
}

export default page