import React from 'react'
import ConfirmedOrders from '../confirmed_orders/ConfirmOrders'

function page() {
  return (
    <>
    <ConfirmedOrders/>
     
    </>
  )
}

export default page