'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Button,
  Table,
  Pagination,
  Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import UnpaidModal from '@/components/Order/paymentunpaidmodal'
import Paymentmodal from '@/components/Order/paymentmodal'
import CancelModal from '@/components/Order/cancelModal'
import View from '../pending_orders/components/view'
import {
  useGetFilteredcomfiremdOrdersMutation,
  useGetRecipientnameQuery,
  useProcessingOrdersOrderMutation,
  useCancelOrderMutation,
} from '@/store/features/apiSlice'

function ConfirmedOrders() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
    todate: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const logsPerPage = 25
  const [confirmedOrders, setComfireOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [fetchComfireOrders, { isLoading, error }] = useGetFilteredcomfiremdOrdersMutation()
  const [cancelOrder] = useCancelOrderMutation()
  const [processingOrder] = useProcessingOrdersOrderMutation()
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [showUnpaidModal, setShowUnpaidModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const printSectionRef = useRef()
  const [showCancelModal, setShowCancelModal] = useState(false)
  const [cancelOrderId, setCancelOrderId] = useState(null)
  const [currency, setCurrency] = useState('');

  const { data: RecipientResults } = useGetRecipientnameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.recipient_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)



  const handleOpenCancelModal = (orderId) => {
    setCancelOrderId(orderId)
    setShowCancelModal(true)
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages || page === currentPage) return
    fetchOrders(page)
  }

  const handleConfirmCancelFromModal = async (orderIdToCancel, customReason) => {
    // keep the same logic you used before, but return or throw depending on result
    try {
      const res = await cancelOrder({
        order_id: orderIdToCancel,
        status: 'cancelled',
        custom_reason: customReason.trim(),
      }).unwrap()

      // If API returns success:false treat it as error
      if (res && res.success === false) {
        throw new Error(res.message || 'Failed to cancel order')
      }

      // show success toast and refresh list
      await Swal.fire('Cancelled', res.message || `Order ${orderIdToCancel} was cancelled.`, 'success')
      await fetchOrders(currentPage)
      return res
    } catch (err) {
      // standardize errors: rethrow so modal can display via catch
      throw err
    }
  }

  const handleCancel = async (orderId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to cancel order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, cancel it!',
      cancelButtonText: 'No, keep it',
    })

    if (result.isConfirmed) {
      const user_id = sessionStorage.getItem('user_id')

      if (!user_id) {
        Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error')
        return
      }

      try {
        const res = await cancelOrder({
          order_id: orderId,
          status: 'cancelled',
          user_id,
        }).unwrap()

        Swal.fire('Cancelled', res.message, 'success')
        fetchOrders(currentPage)
      } catch (err) {
        console.error('Cancel error:', err)
        Swal.fire('Error', 'Failed to cancel the order.', 'error')
      }
    }
  }

  const handleProcessOrComplete = async (order) => {
    const isStorePickup =
      String(order?.storepickup ?? '')
        .toLowerCase()
        .trim() === 'yes'
    const status = isStorePickup ? 'completed' : 'processing'
    const user_id = sessionStorage.getItem('user_id')

    if (!user_id) {
      Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error')
      return
    }

    const result = await Swal.fire({
      title: isStorePickup ? 'Complete order?' : 'Set order to Processing?',
      text: `Do you really want to ${isStorePickup ? 'complete' : 'set processing for'} order ${order.order_id}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: isStorePickup ? 'Yes, complete it!' : 'Yes, set processing!',
      cancelButtonText: 'No, keep it',
    })

    if (!result.isConfirmed) return

    try {
      const res = await processingOrder({
        order_id: order.order_id,
        status,
        user_id,
      }).unwrap()

      Swal.fire(
        isStorePickup ? 'Completed' : 'Processing',
        res.message || (isStorePickup ? 'Order marked as completed.' : 'Order set to processing.'),
        'success',
      )
      fetchOrders(currentPage)
    } catch (err) {
      console.error('processing/completing error:', err)
      Swal.fire('Error', 'Failed to update the order status.', 'error')
    }
  }

  const handleView = (order) => {
    setViewOrder(order)
    setShowViewModal(true)
  }

  const activePartners = [
    { value: 'partner_a', label: 'Partner A' },
    { value: 'partner_b', label: 'Partner B' },
    { value: 'partner_c', label: 'Partner C' },
  ]

  const paymentStatusBadge5 = () => {
    return (
      <span
        style={{
          backgroundColor: '#20c997',
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.55rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}>
        Confirmed
      </span>
    )
  }

  const fetchOrders = async (page) => {
    setLoading(true)
    try {
      const res = await fetchComfireOrders({
        page,
        limit: logsPerPage,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        payment_status: paymentStatus,
        keyword: filters.keyword,
        paymentMethod: paymentMethod,
        date: date,
        todate: todate,
      }).unwrap()

      setComfireOrders(res.confirmedOrders || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
      setCurrency(res.currency || res.confirmedOrders?.[0]?.currency || ''); setCurrency(res.confirmedOrders?.[0]?.currency || '');
      console.log("Currency", res.confirmedOrders?.[0]?.currency);
    } catch (err) {
      console.error('Failed to fetch orders:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOrders(1)
  }, [])

  const handleSearch = () => {
    fetchOrders(1)
  }

  // const handlePayment = (orderId, storepickupVal) => {
  //   setSelectedOrderId(orderId)
  //   setSelectedPickup(storepickupVal ?? 'no')
  //   setShowPaymentModal(true)
  // }

  const handlePayment = (order) => {
    setSelectedOrderId(order)
    setShowPaymentModal(true)
  }

  const handlePaymentClose = (didUpdate = false) => {
    setShowPaymentModal(false)
    setSelectedOrderId(null)
    setSelectedPickup(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const handleUnpaidClick = (orderId) => {
    setSelectedOrderId(orderId)
    setShowUnpaidModal(true)
  }

  const handleUnpaidClose = (didUpdate = false) => {
    setShowUnpaidModal(false)
    setSelectedOrderId(null)
    if (didUpdate) fetchOrders(currentPage)
  }

  const paymentStatusBadge = (status) => {
    const colorMap = {
      paid: 'success',
      unpaid: 'danger',
      refund: 'secondary',
      failed: 'danger',
    }

    const color = colorMap[status] || 'secondary'
    const capitalizedStatus = status.charAt(0).toUpperCase() + status.slice(1)

    return <Badge className={`bg-${color} text-white border-${color} px-3 py-1`}>{capitalizedStatus}</Badge>
  }

  const handleModalConfirm = () => {
    if (!selectedPartner) {
      Swal.fire('Error', 'Please select a delivery partner', 'error')
      return
    }

    Swal.fire('Confirmed', `Order ${selectedOrderId} assigned to ${selectedPartner.label}.`, 'success')
    setShowModal(false)
    setSelectedOrderId(null)
    setSelectedPartner(null)
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }



  const getPageWindow = (current = 1, total = 1, windowSize = 5) => {
    const half = Math.floor(windowSize / 2)
    let start = Math.max(1, current - half)
    let end = Math.min(total, start + windowSize - 1)
    start = Math.max(1, end - windowSize + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const handlePrint = () => {
    const printContents = printSectionRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')

    newWindow.document.write(`
      <html>
        <head>
          <title>Print Confirm Orders</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 20px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ccc;
              padding: 6px;
              text-align: left;
            }
            .table-light {
              background-color: #f8f9fa;
            }
            .no-print {
              display: none !important;
            }
          </style>
        </head>
        <body>
          ${printContents}
        </body>
      </html>
    `)

    newWindow.document.close()
    newWindow.focus()
    newWindow.print()
    newWindow.close()
  }
  const hasSlip = (o) => Boolean(o?.bank_slip && String(o.bank_slip).trim() !== '')

  const openSlip = (o) => {
    try {
      // If your API returns relative paths, prepend your file host here if needed.
      const url = String(o.bank_slip)
      const win = window.open(url, '_blank', 'noopener,noreferrer')
      if (win) win.opener = null
    } catch (e) {
      console.error('Failed to open slip:', e)
      Swal.fire('Error', 'Could not open the bank slip.', 'error')
    }
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader
            className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Confirmed Orders
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-2">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      // If cleared
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}

                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                    />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control
                      type="date"
                      value={todate}
                      onChange={(e) => setToDate(e.target.value)}
                    />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>Payment Status</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="paid">Paid</option>
                  <option value="unpaid">Unpaid</option>
                  <option value="refund">Refund</option>
                  <option value="failed">Failed</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-3">
                <FormLabel>Payment Method</FormLabel>
                <Form.Select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                  <option value="">All</option>
                  <option value="COD">COD</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Stripe">Stripe</option>
                  <option value="PayHere">PayHere</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchOrders(1)}>
                  {/* <Icon icon="mdi:magnify" width={16} style={{ marginRight: 4 }} /> */}
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  {/* <Icon icon="mdi:printer" width={16} style={{ marginRight: 4 }} /> */}
                  Print
                </Button>
              </FormGroup>
            </Form>
            <div ref={printSectionRef}>
              <Table striped className="table my-2">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Confirmed Date</th>
                    <th>Confirmed By</th>
                    <th>Client</th>
                    <th>Payment</th>
                    <th>Delivery Type</th>
                    <th className="text-end">Price ({currency})</th>
                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {confirmedOrders.length > 0 ? (
                    confirmedOrders.map((order) => (
                      <tr key={order.order_id}>
                        <td>{order.order_id}</td>
                        <td>
                          {new Date(order.confirmed_date).toLocaleDateString()}
                          <br />
                        </td>
                        <td>
                          {(() => {
                            const full = [order.confirmed_by_first_name, order.confirmed_by_last_name].filter(Boolean).join(' ').trim()
                            return full || order.confiremed_by || '-'
                          })()}
                        </td>
                        <td>
                          {order.customer_name}
                          <br />
                          <small>{order.contact_number}</small>
                        </td>
                        <td>
                          {/* main payment status badge */}
                          {order.payment_status
                            ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1)
                            : ''}
                          {/* show “Slip” button only if bank_slip exists */}
                          {hasSlip(order) && (
                            <div className="mt-1 no-print">
                              <Button
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.2rem 0.1rem',
                                  fontSize: '0.55rem',
                                  height: '20px',
                                  borderRadius: '15px',
                                  backgroundColor: '#3d3642ff',
                                  borderColor: '#3d3642ff',
                                  color: '#fff',
                                }}
                                variant="outline-primary"
                                onClick={() => openSlip(order)}
                                title="Open bank slip"
                                className="d-inline-flex align-items-center gap-1 px-2 py-1"
                              >
                                <Icon icon="solar:bill-list-bold" width={15} height={15} />
                                Slip
                              </Button>
                            </div>
                          )}
                        </td>
                        <td>{order.delivery_partner_name || '-'}</td>
                        <td className="text-end">
                          {Number(order.full_amount).toFixed(2)}
                        </td>
                        <td className="text-end no-print">
                          <div className="d-flex flex-row align-items-center justify-content-end gap-2 flex-wrap">
                            {/* View */}
                            <Button
                              className="d-flex align-items-center justify-content-center"
                              style={{
                                minWidth: '90px',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>View</span>
                            </Button>

                            {/* Complete / Processing */}
                            {String(order?.storepickup ?? '')
                              .toLowerCase()
                              .trim() === 'yes' ? (
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: '90px',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#28a745',
                                  borderColor: '#28a745',
                                  color: '#fff',
                                }}
                                onClick={() => handleProcessOrComplete(order)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '70px' }}>Complete</span>
                              </Button>
                            ) : (
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: '90px',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#d37e39ff',
                                  borderColor: '#d37e39ff',
                                  color: '#fff',
                                }}
                                onClick={() => handleProcessOrComplete(order)}>
                                <Icon icon="mdi:clipboard-clock-outline" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '70px' }}>Processing</span>
                              </Button>
                            )}

                            {/* Cancel */}
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#dc3545',
                                borderColor: '#dc3545',
                                color: '#fff',
                              }}
                              onClick={() => {
                                setCancelOrderId(order.order_id)
                                setShowCancelModal(true)
                              }}>
                              <Icon icon="mdi:close" width={18} className="me-1" />
                              Cancel
                            </Button>

                            {order?.payment_status?.toLowerCase() === 'paid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#7e111b',
                                  borderColor: '#7e111b',
                                  color: '#fff',
                                }}
                                onClick={() => handleUnpaidClick(order.order_id)}>
                                <Icon icon="mdi:close-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Unpaid</span>
                              </Button>
                            )}

                            {order?.payment_status?.toLowerCase() === 'unpaid' && (
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#035f1c',
                                  borderColor: '#035f1c',
                                  color: '#fff',
                                }}
                                onClick={() => handlePayment(order)}>
                                <Icon icon="mdi:check-circle" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span style={{ minWidth: '85px' }}>Mark As Paid</span>
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8" className="text-center">
                        {loading ? 'Loading orders...' : 'No orders found'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  {/* FIRST */}
                  <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                    First
                  </Pagination.Item>

                  {/* PREVIOUS */}
                  <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                  {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                  {(() => {
                    let pages = []

                    if (totalPages <= 5) {
                      // SHOW ALL PAGES (1 → totalPages)
                      for (let i = 1; i <= totalPages; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    } else {
                      // CENTER CURRENT PAGE (MAX 5)
                      let start = currentPage - 2
                      let end = currentPage + 2

                      if (start < 1) {
                        start = 1
                        end = 5
                      }

                      if (end > totalPages) {
                        end = totalPages
                        start = totalPages - 4
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }
                    }

                    return pages
                  })()}

                  {/* NEXT */}
                  <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                  {/* LAST */}
                  <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>
      <CancelModal
        show={showCancelModal}
        onClose={() => {
          setShowCancelModal(false)
          setCancelOrderId(null)
        }}
        orderId={cancelOrderId}
        onConfirmCancel={handleConfirmCancelFromModal}
      />
      {showViewModal && (
        <View
          show={showViewModal}
          onClose={() => setShowViewModal(false)}
          order_id={viewOrder?.order_id}
          storepickup={viewOrder?.storepickup}
          context="confirmed"
          onProcess={() => handleProcessOrComplete(viewOrder)}
          onCancel={handleOpenCancelModal}
          payment_method_id={viewOrder?.payment_method_id}
        />
      )}
      {/* {showPaymentModal && (
        <Paymentmodal show={showPaymentModal} onClose={handlePaymentClose} order_id={selectedOrderId} storepickup={selectedPickup} />
      )} */}

      {showPaymentModal && selectedOrderId && (
        <Paymentmodal
          show={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          order_id={selectedOrderId.order_id}
          storepickup={selectedOrderId.storepickup}
          payment_method_id={selectedOrderId.payment_method_id}
        />
      )}
      {showUnpaidModal && <UnpaidModal show={showUnpaidModal} onClose={handleUnpaidClose} order_id={selectedOrderId} />}
      {showModal && (
        <div className="modal fade show d-block" tabIndex="-1" role="dialog" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Assign Delivery Partner {selectedOrderId && `(Order #${selectedOrderId})`}</h5>
                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              <div className="modal-body">
                <FormGroup>
                  <FormLabel>Select Active Delivery Partner</FormLabel>
                  <Select
                    options={activePartners}
                    value={selectedPartner}
                    onChange={(option) => setSelectedPartner(option)}
                    placeholder="Select Partner"
                  />
                </FormGroup>
              </div>
              <div className="modal-footer">
                <Button variant="secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </Button>
                <Button variant="primary" onClick={handleModalConfirm}>
                  Confirm
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </Row>
  )
}

export default ConfirmedOrders
