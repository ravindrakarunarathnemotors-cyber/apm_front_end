'use client'

import React, {useState} from 'react'
import { Button, Col, Form, FormControl, FormLabel,  Row, Modal, Card, CardHeader, CardBody, CardTitle, Table } from 'react-bootstrap'
import { Icon } from '@iconify/react/dist/iconify.js'
import { useUpdateEmployeeShiftMutation, useGetShiftsQuery,useGetAllEmployeeOnboardingQuery,useGetAllEmployeePreboardingQuery } from '@/store/features/emsSlice'


const Onboarding = () => {

    const { data: onboardingList = [], isLoading, refetch } = useGetAllEmployeeOnboardingQuery();
    const { data: preboardingList = [], isLoading: isLoadingPreboarding } = useGetAllEmployeePreboardingQuery();



    const [updateEmployeeShift] = useUpdateEmployeeShiftMutation()


    const [showModal, setShowModal] = useState(false);
    const [selectedEmployee, setSelectedEmployee] = useState({});
    const [currentStep, setCurrentStep] = useState(1);
    const [selectedShift, setSelectedShift] = useState(null);
    const [contactError, setContactError] = useState('');

    const handleOpenModal = (employee, shiftID) => {
    setSelectedEmployee(employee);
    setSelectedShift(shiftID || ''); 
    setCurrentStep(1);
    setShowModal(true);
     }


     const handleCloseModal = () => {
    setShowModal(false);
    setSelectedShift('');
    setContactError('');
}

   const handleSave = async () => {
    if (!selectedShift) return;
    if (contactError) {
        alert('Please fix the contact number before saving.');
        return;
    }
    try {
        await updateEmployeeShift({ 
            employeeId: selectedEmployee.employee_id, 
            shiftId: selectedShift 
        }).unwrap();
        console.log('Employee shift updated successfully');
        handleCloseModal();
        refetch(); 
    } catch (error) {
        console.error('Failed to update employee shift:', error);
        alert('Failed to update employee shift. Please try again.');
    }
};


    const nextStep = () => setCurrentStep(2)
    const prevStep = () => setCurrentStep(1)

   const[preboardingFilter, setPreboardingFilter]= useState('')
   const[onboardingFilter, setOnboardingFilter]= useState('')


      const columnConfig = {
        Preboarding: [
            { key: 'employee_id', label: 'Employee ID' },
            { key: 'first_name', label: 'First Name' },
            { key: 'last_name', label: 'Last Name' },
            { key: 'email', label: 'Email' },
            { key: 'joined_date', label: 'Joined Date' },
            { key: 'preboard_date', label: 'Preboarding Date' },
            { key: 'designation', label: 'Designation' },
            { key: 'progress', label: 'Progress' }
            ],
        Onboarding: [
            { key: 'employee_id', label: 'Employee ID' },
            { key: 'first_name', label: 'First Name' },
            { key: 'last_name', label: 'Last Name' },
            { key: 'email', label: 'Email' },
            { key: 'joined_date', label: 'Joined Date' },
            { key: 'department', label: 'Department' },
            { key: 'designation', label: 'Designation' },
            { key: 'progress', label: 'Progress' } 
        ]
      }

    const filteredPreboarding = preboardingList.filter(item =>
        item.employee_id.toLowerCase().includes(preboardingFilter.toLowerCase()) ||
        `${item.first_name} ${item.last_name}`.toLowerCase().includes(preboardingFilter.toLowerCase()) ||
        item.designation.toLowerCase().includes(preboardingFilter.toLowerCase())
    );
    const filteredOnboarding = onboardingList.filter(item =>
        item.employee_id.toLowerCase().includes(onboardingFilter.toLowerCase()) ||
        `${item.first_name} ${item.last_name}`.toLowerCase().includes(onboardingFilter.toLowerCase()) ||
        item.designation.toLowerCase().includes(onboardingFilter.toLowerCase())
    );


    const tabStyle = (stepNumber) => ({
        cursor: 'pointer',
        paddingBottom: '5px',
        marginRight: '20px',
        fontWeight: currentStep === stepNumber ? '600' : '400',
        color: currentStep === stepNumber ? '#22c55e' : '#6c757d', 
        borderBottom: currentStep === stepNumber ? '2px solid #22c55e' : 'none'
    })
    
    
    const formatDateForInput = (isoDate) => {
    if (!isoDate) return ''; 
    return new Date(isoDate).toISOString().split('T')[0];
    }

    const validateContact = (value) => {
    if (!value) {
        setContactError('');
        return;
    }
    if (!/^\d+$/.test(value)) {
        setContactError('Mobile number must contain digits only');
    } else if (!value.startsWith('94')) {
        setContactError('Mobile number must start with 94 (e.g., 94771234567)');
    } else if (value.length !== 11) {
        setContactError('Mobile number must be 11 digits starting with 94');
    } else {
        setContactError('');
    }
};

    return (
     <> 

    <Card className="mt-4">

        <CardHeader className="py-3 bg-light">
           <Row className="align-items-center">
            <Col className="d-flex justify-content-between align-items-center">
                <CardTitle as="h4" style={{ fontSize:'18px'}}>Employee Preboarding List</CardTitle>

            <div className="d-flex" style={{ gap: '10px' }}>
                <input
                    type="text"
                    id="filterText"
                    name="filterText"
                    value={preboardingFilter}
                    onChange = {(e) => setPreboardingFilter(e.target.value)}
                    className="form-control"
                    placeholder="Search by ID, Name, or Designation"
                    style={{ width: '250px' }}
                              />
                              <Button className="btn bg-primary border border-primary">
                                <div className="d-flex align-items-center gap-1 px-3">
                                  <Icon icon="material-symbols:search-rounded" width="24" height="20" />
                                  Search
                                </div>
                              </Button>
            </div>
                
            </Col>
           </Row> 
        </CardHeader>

        <CardBody>
            <div>
                <Table>
                    <thead>
                        <tr>
                            {columnConfig.Preboarding.map((col) => (
                                <th key={col.key} scope='col'>{col.label}</th>
                            ))}
                            <th scope='col'>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {filteredPreboarding.length > 0 ? (
                            filteredPreboarding.map((item, index) => (
                                <tr key={index}>
                                  {columnConfig.Preboarding.map((col) => ( 
                                    <td key={col.key}>{item[col.key]}</td>
                                  ))}
                                    <td className="d-flex">
                                    <div className="d-flex align-items-center gap-2">
                                    <Button
                                    className="d-flex align-items-center"
                                    onClick={() => handleOpenModal(item)}
                                    style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#007bff',
                                        borderColor: '#007bff',
                                        color: '#fff',
                                    }}>
                                    <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>View</span>
                                    </Button>
                                </div>
                                </td>
                            </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4" className="text-center">No Preboarding found.</td>
                            </tr>
                        )}
                        </tbody>
                    </Table>
            </div>
        </CardBody>
    </Card>

    <Card className="mt-4">

        <CardHeader className="py-3 bg-light">
           <Row className="align-items-center">
            <Col className="d-flex justify-content-between align-items-center">
                <CardTitle as="h4" style={{ fontSize:'18px'}}>Employee Onboarding List</CardTitle>

            <div className="d-flex" style={{ gap: '10px' }}>
                <input
                    type="text"
                    id="filterText"
                    name="filterText"
                    value={onboardingFilter}
                    onChange = {(e) => setOnboardingFilter(e.target.value)}
                    className="form-control"
                    placeholder="Search by ID, Name, or Designation"
                    style={{ width: '250px' }}
                              />
                              <Button className="btn bg-primary border border-primary">
                                <div className="d-flex align-items-center gap-1 px-3">
                                  <Icon icon="material-symbols:search-rounded" width="24" height="20" />
                                  Search
                                </div>
                              </Button>
            </div>
                
            </Col>
           </Row> 
        </CardHeader>

        <CardBody>
            <div>
                <Table>
                    <thead>
                        <tr>
                            {columnConfig.Onboarding.map((col) => (
                                <th key={col.key} scope='col'>{col.label}</th>
                            ))}
                            <th scope='col'>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {filteredOnboarding.length > 0 ? (
                            filteredOnboarding.map((item, index) => (
                                <tr key={index}>
                                  {columnConfig.Onboarding.map((col) => ( 
                                    <td key={col.key}>{item[col.key]}</td>
                                  ))}
                                    <td className="d-flex">
                                    <div className="d-flex align-items-center gap-2">
                                    <Button
                                    className="d-flex align-items-center"
                                    onClick={() => handleOpenModal(item,item.shift_id)}
                                    style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#007bff',
                                        borderColor: '#007bff',
                                        color: '#fff',
                                    }}>
                                    <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                    <span>View</span>
                                    </Button>
                                </div>
                                </td>
                            </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4" className="text-center">No Onboarding found.</td>
                            </tr>
                        )}
                        </tbody>
                    </Table>
            </div>
        </CardBody>
    </Card>

   

   <Modal show={showModal} onHide={handleCloseModal} size="xl" centered>
                <Modal.Header closeButton className="border-0 pb-2">
                    <Modal.Title className="fw-bold fs-5">Employee Details</Modal.Title>
                </Modal.Header>

                <Modal.Body className="pt-2">
                    
                    <div className="d-flex mb-4 border-bottom pb-2">
                        <span style={tabStyle(1)} onClick={() => setCurrentStep(1)}>Personal Details</span>
                        <span style={tabStyle(2)} onClick={() => setCurrentStep(2)}>Employment Details</span>
                    </div>

                    <Form>
                        
                        {currentStep === 1 ? (
                            <Row>
                                
                                <Col md={9}>
                                    
                                    <Row className="mb-3">
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">Employee ID</FormLabel>
                                            <FormControl type="text" value={selectedEmployee?.employee_id || ''} readOnly disabled className="bg-light" />
                                        </Col>
                                        <Col md={8}>
                                            <FormLabel className="text-muted small">Employee Full Name</FormLabel>
                                            <FormControl type="text" value={`${selectedEmployee?.first_name || ''} ${selectedEmployee?.last_name || ''}`} readOnly />
                                        </Col>
                                    </Row>

                                   
                                    <Row className="mb-3">
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">Joined Date</FormLabel>
                                            <FormControl type="date" value={formatDateForInput(selectedEmployee?.joined_date)} readOnly />
                                        </Col>
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">Location</FormLabel>
                                            <FormControl type="text" value={selectedEmployee?.location || ''} readOnly />
                                        </Col>
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">NIC Number</FormLabel>
                                            <FormControl type="text" value={selectedEmployee?.nic || ''} readOnly />
                                        </Col>
                                    </Row>

                                   
                                    <Row className="mb-3">
                                        <Col md={4}>
                                        <FormLabel className="text-muted small">Contact Number</FormLabel>
                                        <FormControl 
                                            type="text" 
                                            value={selectedEmployee?.contact_no || ''}
                                            onChange={(e) => {
                                                setSelectedEmployee({ ...selectedEmployee, contact_no: e.target.value });
                                                validateContact(e.target.value);
                                            }}
                                            isInvalid={!!contactError}
                                            maxLength={11}
                                        />
                                        {contactError ? (
                                            <Form.Control.Feedback type="invalid">
                                                {contactError}
                                            </Form.Control.Feedback>
                                        ) : (
                                            <small className="text-muted">Format: 94XXXXXXXXX (11 digits)</small>
                                        )}
                                    </Col>
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">Email</FormLabel>
                                            <FormControl type="email" value={selectedEmployee?.email || ''} readOnly />
                                        </Col>
                                        <Col md={4}>
                                            <FormLabel className="text-muted small">Date Of Birth</FormLabel>
                                            <FormControl type="date" value={formatDateForInput(selectedEmployee?.date_of_birth )} readOnly />
                                        </Col>
                                    </Row>
                                </Col>
                                <Col md={3} className="d-flex flex-column align-items-center pt-2">
                                    <div 
                                        className="shadow-sm border"
                                        style={{ 
                                            width: '140px', 
                                            height: '140px', 
                                            borderRadius: '50%', 
                                            backgroundColor: '#f8f9fa', 
                                            display: 'flex', 
                                            alignItems: 'center', 
                                            justifyContent: 'center',
                                            overflow: 'hidden'
                                        }}
                                    >
                                        {selectedEmployee?.profilePic ? (
                                            <img src={selectedEmployee.profilePic} alt="Profile" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                        ) : (
                                            <Icon icon="mdi:user" width="80" color="#dee2e6" />
                                        )}
                                    </div>
                                    <div className="mt-2 text-muted small">Profile Picture</div>
                                </Col>
                            </Row>
                        ) : null}

                        {currentStep === 2 ? (
                            <Row>
                                <Col md={6} className="mb-3">
                                    <FormLabel className="text-muted small">Probation End Date</FormLabel>
                                    <FormControl type="date" value={selectedEmployee?.probationEndDate || ''} readOnly />
                                </Col>
                                <Col md={6} className="mb-3">
                                    <FormLabel className="text-muted small">Designation</FormLabel>
                                    <FormControl type="text" value={selectedEmployee?.designation || ''} readOnly />
                                </Col>
                                <Col md={6} className="mb-3">
                                    <FormLabel className="text-muted small">Employment Status</FormLabel>
                                    <FormControl type="text" value="Active" readOnly />
                                </Col>
                                <Col md={6} className="mb-3">
                                    <FormLabel className="text-muted small">Job Category</FormLabel>
                                    <FormControl type="text" value={selectedEmployee?.jobCategory || ''} readOnly />
                                </Col>
                                <Col md={6} className="mb-3">
                                    <FormLabel className="text-muted small">Shift Name <span className="text-danger">*</span></FormLabel>
                                    <Form.Select 
                                        value={selectedShift}
                                        onChange={(e) => setSelectedShift(e.target.value)}
                                        
                                    >
                                        <option value="">Select a shift</option>
                                        {shifts.map((shift) => (
                                            <option key={shift.id} value={shift.id}>
                                                {shift.shift_name}
                                            </option>
                                        ))}
                                    </Form.Select>
                                    {isLoadingShifts && <small className="text-muted">Loading shifts...</small>}
                                </Col>
                            </Row>
                        ) : null}
                    </Form>
                </Modal.Body>

                <Modal.Footer className="border-0">
                    {currentStep === 2 && (
                        <Button variant="secondary" onClick={prevStep}>Previous</Button>
                    )}

                    {currentStep === 1 ? (
                        <Button variant="success" onClick={nextStep} style={{ minWidth: '100px', backgroundColor: '#22c55e', border: 'none' }}>
                            Next
                        </Button>
                    ) : (
                        <Button 
                            variant="primary" 
                            onClick={handleSave} 
                            style={{ minWidth: '100px', backgroundColor: '#007bff', border: 'none' }}
                            disabled={!selectedShift}>
                            Save
                        </Button>
                    )}
                </Modal.Footer>
            </Modal>
    </>    
  )
}
  
export default Onboarding