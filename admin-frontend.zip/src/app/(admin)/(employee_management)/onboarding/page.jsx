import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Onboarding - Employee Management',
}

const Onboarding = dynamic(() => import('./Onboarding'), { ssr: false })

export default function OnboardingPage() {
  return <Onboarding />
}