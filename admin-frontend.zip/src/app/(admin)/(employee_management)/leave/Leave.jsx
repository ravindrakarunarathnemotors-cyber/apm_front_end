'use client'

import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import React, { useState, useMemo, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  Row, Col, Card, CardHeader, CardBody, CardTitle,
  Form, FormGroup, FormLabel, Button, Table, Spinner, Badge, Modal, Pagination
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import {
  useGetAllLeavesQuery,
  useGetLeaveTypesQuery,
  useCreateLeaveMutation,
  useUpdateLeaveStatusMutation,
  useGetFilteredAllEmpolyeesMutation,
  useGetEmployeeByIdQuery,
  useGetLeaveBalanceQuery,
  useGetEmployeenameQuery,
  useGetAllLeavessMutation,
} from '@/store/features/emsSlice'
import { useForm } from 'react-hook-form'
import { useAdminLog } from '@/hooks/useAdminLog'
import { UnsavedChangesModal } from '@/components/UnsavedChangesModal'
import Swal from 'sweetalert2'

const leaveFormSchema = yup.object({
  employeeId: yup.string().required('Employee is required'),
  leave_type_id: yup.string().required('Leave type is required'),
  status: yup.string().required(),
  duration: yup.string().required(),
  date: yup.string().required('Date is required'),
  to_date: yup.string().when('duration', {
    is: 'Multiple',
    then: (s) => s.required('End date is required'),
    otherwise: (s) => s.optional(),
  }),
  reason: yup.string().required('Reason is required'),
  admin_note: yup.string().optional(),
})


// ─────────────────────────────────────────────
// Confirmation Modal
// ─────────────────────────────────────────────
function ConfirmModal({ title, message, details, confirmLabel, confirmColor, onConfirm, onCancel, loading }) {
  return (
    <Modal show onHide={onCancel} centered size="md" style={{ zIndex: 1060 }}>
      <Modal.Header style={{ background: '#fff', borderBottom: '1px solid #f3f4f6', padding: '14px 24px' }} closeButton={false}>
        <div className="d-flex align-items-center justify-content-between w-100">
          <span style={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>{title}</span>
          <button onClick={onCancel} style={{ border: 'none', background: '#f3f4f6', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#6b7280' }}>
            <Icon icon="mdi:close" width={18} />
          </button>
        </div>
      </Modal.Header>
      <Modal.Body style={{ padding: '24px' }}>
        <p style={{ fontSize: '0.88rem', color: '#374151', marginBottom: '16px' }}>{message}</p>
        {details && (
          <div style={{ background: '#f9fafb', borderRadius: '10px', padding: '14px 18px', fontSize: '0.82rem', color: '#374151', marginBottom: '8px' }}>
            {Object.entries(details).map(([k, v]) => (
              <div key={k} className="d-flex py-1" style={{ borderBottom: '1px solid #f3f4f6' }}>
                <span style={{ width: 160, color: '#9ca3af', fontWeight: 500 }}>{k}</span>
                <span style={{ fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </div>
        )}
        <div className="d-flex gap-2 mt-3">
          <Button
            onClick={onConfirm}
            disabled={loading}
            style={{ backgroundColor: confirmColor || '#0d6efd', borderColor: confirmColor || '#0d6efd', borderRadius: '8px', fontWeight: 600, fontSize: '0.85rem', padding: '8px 22px', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            {loading ? <Spinner animation="border" size="sm" /> : <Icon icon="mdi:check" width={16} />}
            {confirmLabel || 'Confirm'}
          </Button>
          <Button variant="link" onClick={onCancel} style={{ color: '#6b7280', fontWeight: 500, fontSize: '0.85rem', textDecoration: 'none' }}>
            Cancel
          </Button>
        </div>
      </Modal.Body>
    </Modal>
  )
}


// ─────────────────────────────────────────────
// LeaveFormModal (Create / Edit)
// ─────────────────────────────────────────────
function LeaveFormModal({ leave, onClose, onSaved, allLeaves = [] }) {
  const isEdit = !!leave

  const [selectedEmpId, setSelectedEmpId] = useState(leave?.employee_id ?? null)
  const [showUnsavedModal, setShowUnsavedModal] = useState(false)
  const { data: employeeData } = useGetEmployeeByIdQuery(selectedEmpId, { skip: !selectedEmpId })

  const initialEmployee =
    leave && employeeData
      ? { value: employeeData.employee_id, label: employeeData.full_name }
      : leave
        ? { value: leave.employee_id, label: [leave.first_name, leave.last_name].filter(Boolean).join(' ') || leave.employee_name || '' }
        : null

  const empRef = useRef(initialEmployee)
  const [empDisplay, setEmpDisplay] = useState(initialEmployee)
  const { sendLog } = useAdminLog()
  const [leaveFile, setLeaveFile] = useState(null)
  const [leaveDragOver, setLeaveDragOver] = useState(false)
  const [leaveFileError, setLeaveFileError] = useState('')
  const [leaveUploading, setLeaveUploading] = useState(false)
  const leaveFileInputRef = useRef(null)

  useEffect(() => {
    if (employeeData && isEdit) {
      const opt = { value: employeeData.employee_id, label: employeeData.full_name }
      empRef.current = opt
      setEmpDisplay(opt)
    }
  }, [employeeData, isEdit])

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting, isDirty },
    watch,
    setValue,
    reset,
  } = useForm({
    resolver: yupResolver(leaveFormSchema),
    defaultValues: {
      employeeId:    leave?.employee_id ? String(leave.employee_id) : '',
      leave_type_id: leave?.leave_type_id ? String(leave.leave_type_id) : '',
      status:        leave?.status || 'Approved',
      duration:
        leave?.duration_type === 'full_day'    ? 'Full Day'
        : leave?.duration_type === 'first_half'  ? 'First Half'
        : leave?.duration_type === 'second_half' ? 'Second Half'
        : leave?.duration_type === 'multiple'    ? 'Multiple'
        : 'Full Day',
      date:     leave?.from_date ? leave.from_date.slice(0, 10) : new Date().toISOString().split('T')[0],
      to_date:  leave?.to_date   ? leave.to_date.slice(0, 10)  : '',
      reason:   leave?.reason    || '',
      admin_note: leave?.admin_note || '',
    },
  })

  const handleSafeClose = () => {
  if (isDirty) {
    setShowUnsavedModal(true)
  } else {
    onClose()
  }
}
  const duration      = watch('duration')
  const leaveTypeId   = watch('leave_type_id')
  const leaveTypeLabel = watch('leave_type_label') || ''

  const { data: leaveTypes = [] } = useGetLeaveTypesQuery()
  const { data: leaveBalances = [] } = useGetLeaveBalanceQuery(selectedEmpId, { skip: !selectedEmpId })

  const selectedBalance = leaveBalances.find(
    (b) => String(b.leave_type_id) === String(leaveTypeId)
  )

  const [apiQuery, setApiQuery] = useState('')
  const debouncedSetApiQuery = useMemo(() => debounce((v) => setApiQuery(v), 300), [])
  useEffect(() => () => debouncedSetApiQuery.cancel(), [debouncedSetApiQuery])

  const [createLeave]      = useCreateLeaveMutation()
  const [updateLeaveStatus] = useUpdateLeaveStatusMutation()
  const [getEmployees, { data: empResultsFromApi = [] }] = useGetFilteredAllEmpolyeesMutation()

  useEffect(() => {
    if (apiQuery && apiQuery.length >= 2) getEmployees({ keyword: apiQuery })
  }, [apiQuery, getEmployees])

  const empOptions = useMemo(() => {
    const list = Array.isArray(empResultsFromApi) ? empResultsFromApi
      : Array.isArray(empResultsFromApi?.data)      ? empResultsFromApi.data
      : Array.isArray(empResultsFromApi?.employees)  ? empResultsFromApi.employees : []
    return list.map((e) => ({
      label: e.full_name || e.employee_name || [e.first_name, e.last_name].filter(Boolean).join(' ') || 'Unknown',
      value: e.employee_id ?? e.id ?? e.emp_id ?? '',
    })).filter((opt) => opt.value)
  }, [empResultsFromApi])

  const leaveTypeOptions = leaveTypes.map((lt) => ({ label: lt.name, value: lt.leave_type_id }))

  const onSubmit = async (data) => {
    try {
      if (isEdit) {
        if (!['Approved', 'Rejected'].includes(data.status)) return
        await updateLeaveStatus({ id: leave.leave_id, status: data.status, admin_note: data.admin_note || null }).unwrap()
        await sendLog('Leave', `Leave status updated to ${data.status} for employee ID: ${leave.employee_id}`)
      } else {
        const durationTypeMap = {
          'Full Day':    'full_day',
          'First Half':  'first_half',
          'Second Half': 'second_half',
          'Multiple':    'multiple',
        }
        let fileUrl = null
        if (leaveFile) {
          setLeaveUploading(true)
          try {
            const formData = new FormData()
            formData.append('file', leaveFile)
            formData.append('file_type', 'leave_documents')
            const uploadRes = await fetch(
              `${process.env.NEXT_PUBLIC_BASE_URL}/emsUpload/upload-ems`,
              { method: 'POST', headers: {}, body: formData, credentials: 'include' }
            )
            if (!uploadRes.ok) throw new Error('Upload failed')
            const uploadData = await uploadRes.json()
            fileUrl = uploadData.url
          } catch (uploadErr) {
            setLeaveFileError('File upload failed. Please try again.')
            setLeaveUploading(false)
            return
          } finally {
            setLeaveUploading(false)
          }
        }

        await createLeave({
          employee_id:    empRef.current.value,
          leave_type_id:  data.leave_type_id,
          from_date:      data.date,
          to_date:        data.duration === 'Multiple' && data.to_date ? data.to_date : data.date,
          reason:         data.reason,
          duration_type:  durationTypeMap[data.duration] || 'full_day',
          file_url:       fileUrl,   // ← attached S3 URL
        }).unwrap()
        await sendLog('Leave', `New leave created for employee: ${empRef.current.label} | Type: ${leaveTypeLabel} | Date: ${data.date} | Duration: ${data.duration}`)
      }
      onSaved()
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Save Failed', text: err?.data?.message || 'Unknown error' })
    }
  }

  const selectStyles = {
    control: (base, state) => ({
      ...base,
      borderRadius: '6px',
      borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6',
      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb),.25)' : 'none',
      minHeight: '38px',
    }),
  }

  return (
    <Modal show onHide={handleSafeClose} size="xl" centered>
      <Modal.Header style={{ background: '#fff', borderBottom: '1px solid #f3f4f6', padding: '14px 24px' }} closeButton={false}>
        <div className="d-flex align-items-center justify-content-between w-100">
          <span style={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>{isEdit ? 'Edit Leave' : 'New Leave'}</span>
          <button onClick={handleSafeClose} style={{ border: 'none', background: '#f3f4f6', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#6b7280' }}>
            <Icon icon="mdi:close" width={18} />
          </button>
        </div>
      </Modal.Header>

      <Modal.Body style={{ backgroundColor: '#f9fafb', padding: '28px' }}>
        <Form noValidate onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-3 mt-1">
            <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '1px' }}>Assign Leave</span>
            <hr style={{ marginTop: '6px', marginBottom: '16px', borderColor: '#f3f4f6' }} />
          </div>

          <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)' }}>
            <CardBody style={{ padding: '28px 24px' }}>
              <Row className="g-3">

                {/* Employee */}
                <Col md={4}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Employee Name <span className="text-danger">*</span>
                  </FormLabel>
                  {isEdit ? (
                    <div style={{ padding: '8px 12px', borderRadius: '6px', backgroundColor: '#f3f4f6', border: '1px solid #dee2e6', fontSize: '0.85rem', fontWeight: 600, color: '#374151', minHeight: '38px', display: 'flex', alignItems: 'center' }}>
                      {[leave?.first_name, leave?.last_name].filter(Boolean).join(' ') || leave?.employee_name || '--'}
                    </div>
                  ) : (
                    <>
                      <Select
                        styles={selectStyles}
                        options={empOptions}
                        value={empDisplay}
                        onInputChange={(value, { action }) => {
                          if (action === 'input-change') debouncedSetApiQuery(value)
                        }}
                        onChange={(opt) => {
                          if (!opt) {
                            empRef.current = null
                            setEmpDisplay(null)
                            setSelectedEmpId(null)
                            setValue('employeeId', '')
                            debouncedSetApiQuery('')
                            return
                          }
                          empRef.current = { value: opt.value, label: opt.label }
                          setEmpDisplay({ value: opt.value, label: opt.label })
                          setSelectedEmpId(opt.value)
                          setValue('employeeId', String(opt.value), { shouldValidate: true })
                        }}
                        placeholder="Type to search employee..."
                        isClearable
                        isSearchable
                        filterOption={() => true}
                        noOptionsMessage={({ inputValue }) =>
                          inputValue.length < 2 ? 'Type at least 2 characters...' : 'No employees found'
                        }
                      />
                      {errors.employeeId && (
                        <div className="text-danger mt-1" style={{ fontSize: 12 }}>{errors.employeeId.message}</div>
                      )}
                    </>
                  )}
                </Col>

                {/* Leave Type */}
                <Col md={4}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Leave Type <span className="text-danger">*</span>
                  </FormLabel>
                  <Select
                    styles={selectStyles}
                    options={leaveTypeOptions}
                    onChange={(opt) => {
                      setValue('leave_type_id', opt?.value ? String(opt.value) : '', { shouldValidate: true })
                      setValue('leave_type_label', opt?.label || '')
                    }}
                    value={leaveTypeId ? { label: leaveTypeLabel, value: leaveTypeId } : null}
                    placeholder="-- Select Type"
                    isClearable
                  />
                  {errors.leave_type_id && (
                    <div className="text-danger mt-1" style={{ fontSize: 12 }}>{errors.leave_type_id.message}</div>
                  )}
                  {/* Hidden inputs for RHF registration */}
                  <input type="hidden" {...register('leave_type_id')} />
                  <input type="hidden" {...register('leave_type_label')} />
                  <input type="hidden" {...register('employeeId')} />
                </Col>

                {/* Leave Balance */}
                <Col md={4} className="d-flex flex-column justify-content-end">
                  {leaveTypeId && selectedEmpId && !isEdit ? (
                    <div style={{
                      padding: '10px 14px', borderRadius: '8px',
                      backgroundColor: selectedBalance?.remaining > 0 ? '#f0fdf4' : '#fef2f2',
                      border: `1px solid ${selectedBalance?.remaining > 0 ? '#bbf7d0' : '#fecaca'}`,
                    }}>
                      <div style={{ fontSize: '0.7rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>Leave Balance</div>
                      {selectedBalance ? (
                        <div className="d-flex align-items-center gap-2">
                          <Icon
                            icon={selectedBalance.remaining > 0 ? 'mdi:calendar-check' : 'mdi:calendar-remove'}
                            width={18}
                            style={{ color: selectedBalance.remaining > 0 ? '#16a34a' : '#dc2626' }}
                          />
                          <div style={{ fontSize: '0.85rem' }}>
                            <span style={{ fontWeight: 700, color: selectedBalance.remaining > 0 ? '#16a34a' : '#dc2626', fontSize: '1.1rem' }}>
                              {selectedBalance.remaining}
                            </span>
                            <span style={{ color: '#6b7280', fontSize: '0.78rem' }}> / {selectedBalance.allocated} days remaining</span>
                          </div>
                        </div>
                      ) : (
                        <span style={{ color: '#9ca3af', fontSize: '0.8rem' }}>No allocation configured</span>
                      )}
                    </div>
                  ) : (
                    <div style={{ padding: '10px 14px', borderRadius: '8px', backgroundColor: '#f9fafb', border: '1px dashed #e5e7eb', color: '#d1d5db', fontSize: '0.78rem', textAlign: 'center' }}>
                      Select employee &amp; leave type to view balance
                    </div>
                  )}
                </Col>

                {/* Status (edit only) */}
                {isEdit && (
                  <Col md={3}>
                    <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Status</FormLabel>
                    <Form.Select {...register('status')} style={{ borderRadius: '6px', fontSize: '0.85rem' }}>
                      <option value="Approved">Approved</option>
                      <option value="Rejected">Rejected</option>
                    </Form.Select>
                  </Col>
                )}

                {/* Duration */}
                <Col md={5}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Select Duration</FormLabel>
                  <div className="d-flex flex-wrap gap-3 mt-1">
                    {['Full Day', 'Multiple', 'First Half', 'Second Half'].map((d) => (
                      <Form.Check
                        key={d} type="radio" id={`dur-${d}`} label={d} name="duration"
                        value={d}
                        {...register('duration')}
                        style={{ fontSize: '0.85rem' }}
                      />
                    ))}
                  </div>
                </Col>

                {/* Date(s) */}
                <Col md={isEdit ? 12 : 7}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Date {duration === 'Multiple' && '(From – To)'}
                  </FormLabel>
                  <div className="d-flex gap-2">
                    <div className="flex-fill">
                      <Form.Control
                        type="date"
                        {...register('date')}
                        isInvalid={!!errors.date}
                        style={{ borderRadius: '6px', fontSize: '0.85rem' }}
                      />
                      {errors.date && <div className="text-danger" style={{ fontSize: 12 }}>{errors.date.message}</div>}
                    </div>
                    {duration === 'Multiple' && (
                      <div className="flex-fill">
                        <Form.Control
                          type="date"
                          {...register('to_date')}
                          isInvalid={!!errors.to_date}
                          style={{ borderRadius: '6px', fontSize: '0.85rem' }}
                        />
                        {errors.to_date && <div className="text-danger" style={{ fontSize: 12 }}>{errors.to_date.message}</div>}
                      </div>
                    )}
                  </div>
                </Col>

                {/* Reason */}
                <Col md={12}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>
                    Reason for absence <span className="text-danger">*</span>
                  </FormLabel>
                  <Form.Control
                    as="textarea" rows={3}
                    placeholder="e.g. Feeling not well"
                    {...register('reason')}
                    isInvalid={!!errors.reason}
                    style={{ borderRadius: '6px', fontSize: '0.85rem', resize: 'vertical' }}
                  />
                  {errors.reason && <div className="text-danger" style={{ fontSize: 12 }}>{errors.reason.message}</div>}
                </Col>

                {/* Admin Note (edit only) */}
                {isEdit && (
                  <Col md={12}>
                    <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Admin Note</FormLabel>
                    <Form.Control
                      as="textarea" rows={2}
                      placeholder="e.g. Approved — medical emergency confirmed"
                      {...register('admin_note')}
                      style={{ borderRadius: '6px', fontSize: '0.85rem', resize: 'vertical' }}
                    />
                  </Col>
                )}

                {/* File Upload (new only) */}
                {!isEdit && (
                <Col md={12}>
                  <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Add File</FormLabel>
                  <div
                    onDragOver={(e) => { e.preventDefault(); setLeaveDragOver(true) }}
                    onDragLeave={() => setLeaveDragOver(false)}
                    onDrop={(e) => {
                      e.preventDefault()
                      setLeaveDragOver(false)
                      const dropped = e.dataTransfer.files[0]
                      if (dropped) { setLeaveFile(dropped); setLeaveFileError('') }
                    }}
                    onClick={() => leaveFileInputRef.current?.click()}
                    style={{
                      border: `1.5px dashed ${leaveDragOver ? 'var(--bs-primary)' : leaveFileError ? '#dc3545' : '#dee2e6'}`,
                      borderRadius: '8px',
                      backgroundColor: leaveDragOver ? 'rgba(var(--bs-primary-rgb),0.04)' : '#fff',
                      padding: '32px',
                      textAlign: 'center',
                      cursor: 'pointer',
                      color: '#9ca3af',
                      fontSize: '0.85rem',
                      transition: 'all 0.15s',
                    }}
                  >
                    <Icon icon={leaveFile ? 'mdi:file-check-outline' : 'mdi:cloud-upload-outline'} width={28}
                      style={{ display: 'block', margin: '0 auto 6px', color: leaveFile ? 'var(--bs-primary)' : '#9ca3af' }} />
                    {leaveFile
                      ? `${leaveFile.name}  (${(leaveFile.size / 1024).toFixed(1)} KB)`
                      : 'Click or drag & drop a file here'}
                  </div>
                  <input ref={leaveFileInputRef} type="file" hidden onChange={(e) => {
                    const f = e.target.files[0]
                    if (f) { setLeaveFile(f); setLeaveFileError('') }
                  }} />
                  {leaveFileError && (
                    <div style={{ color: '#dc3545', fontSize: '0.75rem', marginTop: '4px' }}>{leaveFileError}</div>
                  )}
                  {leaveUploading && (
                    <div className="d-flex align-items-center gap-2 mt-2" style={{ fontSize: '0.78rem', color: 'var(--bs-primary)' }}>
                      <Spinner animation="border" size="sm" /> Uploading file...
                    </div>
                  )}
                </Col>
              )}
              </Row>

              <div className="d-flex gap-2 mt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  style={{ backgroundColor: '#0d6efd', borderColor: '#0d6efd', borderRadius: '8px', fontWeight: 600, fontSize: '0.85rem', padding: '8px 22px', display: 'flex', alignItems: 'center', gap: '6px' }}
                >
                  {isSubmitting
                    ? <><Spinner animation="border" size="sm" /> Saving…</>
                    : <><Icon icon="mdi:check" width={16} /> Save</>}
                </Button>
                <Button variant="link" onClick={handleSafeClose} disabled={isSubmitting} style={{ color: '#6b7280', fontWeight: 500, fontSize: '0.85rem', textDecoration: 'none' }}>
                  Cancel
                </Button>
              </div>
            </CardBody>
          </Card>
        </Form>
      </Modal.Body>
       {showUnsavedModal && (
        <UnsavedChangesModal
          show={showUnsavedModal}
          onContinue={() => setShowUnsavedModal(false)}
          onDiscard={() => { setShowUnsavedModal(false); onClose() }}
        />
      )}
    </Modal>
  )
}


// ─────────────────────────────────────────────
// StatusDot & LeaveTypeBadge helpers
// ─────────────────────────────────────────────
function StatusDot({ status }) {
  const color = status === 'Approved' ? '#198754' : status === 'Rejected' ? '#dc3545' : '#ffc107'
  return (
    <span className="d-flex align-items-center gap-1" style={{ fontSize: '0.82rem', fontWeight: 500, color: '#374151' }}>
      <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: color, display: 'inline-block' }} />
      {status}
    </span>
  )
}

function LeaveTypeBadge({ type, half }) {
  const colors = { Casual: '#198754', Annual: '#0d6efd', Medical: '#6f42c1', Maternity: '#e83e8c' }
  const bg = colors[type] || '#6c757d'
  return (
    <span className="d-flex align-items-center gap-1 flex-wrap">
      <span style={{ backgroundColor: bg, color: '#fff', borderRadius: '4px', padding: '2px 8px', fontSize: '0.7rem', fontWeight: 600 }}>{type}</span>
      {half && (
        <span style={{ backgroundColor: '#6c757d', color: '#fff', borderRadius: '4px', padding: '2px 8px', fontSize: '0.7rem', fontWeight: 600 }}>{half}</span>
      )}
    </span>
  )
}


// ─────────────────────────────────────────────
// LeaveViewModal
// ─────────────────────────────────────────────
function LeaveViewModal({ leave, onClose, onStatusChange }) {
  const [adminNote, setAdminNote] = useState(leave?.admin_note || '')
  const [paidStatus, setPaidStatus] = useState(leave?.paid_status || 'unpaid')
  const [updating, setUpdating] = useState(false)
  const [confirmState, setConfirmState] = useState(null)

  const { sendLog } = useAdminLog()

  const [updateLeaveStatus] = useUpdateLeaveStatusMutation()
  const { data: leaveBalances = [] } = useGetLeaveBalanceQuery(leave?.employee_id, { skip: !leave?.employee_id })

  const [typeName, halfLabel] = (leave.leave_type_name || '').split(' - ')
  const selectedBalance = leaveBalances.find((b) => String(b.leave_type_id) === String(leave.leave_type_id))

  const fullName = [leave.first_name, leave.last_name].filter(Boolean).join(' ')
  const initials = [leave.first_name, leave.last_name].filter(Boolean).map((n) => n[0]).join('').toUpperCase()

  const calcDays = () => {
    if (leave.duration_type === 'multiple' && leave.from_date && leave.to_date) {
      const from = new Date(leave.from_date)
      const to = new Date(leave.to_date)
      let count = 0
      const cur = new Date(from)
      while (cur <= to) {
        const day = cur.getDay()
        if (day !== 0 && day !== 6) count++
        cur.setDate(cur.getDate() + 1)
      }
      return count
    }
    if (leave.duration_type === 'first_half' || leave.duration_type === 'second_half') return 0.5
    return 1
  }
  const daysRequested = calcDays()

  const remainingAfterApproval = selectedBalance ? selectedBalance.remaining - daysRequested : null
  const hasBalance = selectedBalance ? selectedBalance.remaining >= daysRequested : false
  const canApprovePaid = leave.status === 'Pending'
  const canApproveUnpaid = leave.status === 'Pending' && !hasBalance

  const requestConfirm = (action, paidOverride) => setConfirmState({ action, paidOverride })

  const executeAction = async () => {
    const { action, paidOverride } = confirmState
     setUpdating(true)
    try {
      await updateLeaveStatus({
        id: leave.leave_id,
        status: action,
        admin_note: adminNote || null,
        paid_status: paidOverride !== null && paidOverride !== undefined ? paidOverride : paidStatus,
      }).unwrap()
      await sendLog('Leave', `Leave ${action} for ${fullName} | Type: ${typeName} | Paid: ${paidOverride ?? paidStatus} | Date: ${leave.from_date}`)
      setConfirmState(null)
      onStatusChange()
    } catch (err) {
    
      Swal.fire({ icon: 'error', title: 'Update Failed', text: err?.data?.message || 'Unknown error' })
    } finally {
      setUpdating(false)
    }
  }

  const InfoRow = ({ label, children }) => (
    <div className="d-flex py-2" style={{ borderBottom: '1px solid #f3f4f6' }}>
      <div style={{ width: 200, flexShrink: 0, fontSize: '0.82rem', color: '#9ca3af', fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: '0.85rem', color: '#111827', fontWeight: 500 }}>{children}</div>
    </div>
  )

  const confirmDetails = confirmState ? {
    'Employee': fullName,
    'Leave Type': typeName,
    'Date': leave.from_date ? new Date(leave.from_date).toLocaleDateString('en-GB') : '--',
    'Duration': `${daysRequested} day(s)`,
    'Action': confirmState.action,
    'Paid Status': confirmState.action === 'Approved' ? (confirmState.paidOverride ?? paidStatus) : '--',
  } : {}

  return (
    <>
      {confirmState && (
        <ConfirmModal
          title={`Confirm ${confirmState.action}`}
          message={`Are you sure you want to ${confirmState.action.toLowerCase()} this leave request? This action will update the leave record.`}
          details={confirmDetails}
          confirmLabel={confirmState.action}
          confirmColor={confirmState.action === 'Approved' ? '#198754' : '#dc3545'}
          onConfirm={executeAction}
          onCancel={() => setConfirmState(null)}
          loading={updating}
        />
      )}

      <Modal show onHide={onClose} size="lg" centered>
        <Modal.Header style={{ background: '#fff', borderBottom: '1px solid #f3f4f6', padding: '14px 24px' }} closeButton={false}>
          <div className="d-flex align-items-center justify-content-between w-100">
            <div className="d-flex flex-column">
              <span style={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>Leave Details</span>
              <span style={{ fontSize: '0.72rem', color: '#9ca3af', marginTop: '2px' }}>
                Apply Date —{' '}
                {leave.created_at
                  ? new Date(leave.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })
                  + ' ' + new Date(leave.created_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
                  : '--'}
              </span>
            </div>
            <button onClick={onClose} style={{ border: 'none', background: '#f3f4f6', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#6b7280' }}>
              <Icon icon="mdi:close" width={18} />
            </button>
          </div>
        </Modal.Header>

        <Modal.Body style={{ backgroundColor: '#f9fafb', padding: '28px' }}>

          {/* Leave Balance Summary */}
          {selectedBalance && (
            <div style={{ marginBottom: '20px', padding: '16px 20px', borderRadius: '12px', background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)', border: '1px solid #bae6fd' }}>
              <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#0284c7', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '10px' }}>
                Leave Balance — {typeName}
              </div>
              <div className="d-flex gap-4 flex-wrap">
                <div className="text-center">
                  <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0284c7', lineHeight: 1 }}>{selectedBalance.allocated}</div>
                  <div style={{ fontSize: '0.72rem', color: '#6b7280', marginTop: '2px' }}>Allocated</div>
                </div>
                <div className="text-center">
                  <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#dc2626', lineHeight: 1 }}>
                    {selectedBalance.allocated - selectedBalance.remaining}
                  </div>
                  <div style={{ fontSize: '0.72rem', color: '#6b7280', marginTop: '2px' }}>Used</div>
                </div>
                <div className="text-center">
                  <div style={{ fontSize: '1.6rem', fontWeight: 800, color: selectedBalance.remaining > 0 ? '#16a34a' : '#dc2626', lineHeight: 1 }}>
                    {selectedBalance.remaining}
                  </div>
                  <div style={{ fontSize: '0.72rem', color: '#6b7280', marginTop: '2px' }}>Remaining</div>
                </div>
                <div className="text-center">
                  <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#7c3aed', lineHeight: 1 }}>{daysRequested}</div>
                  <div style={{ fontSize: '0.72rem', color: '#6b7280', marginTop: '2px' }}>Requested</div>
                </div>
                {leave.status === 'Pending' && remainingAfterApproval !== null && (
                  <div className="text-center">
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: remainingAfterApproval >= 0 ? '#0284c7' : '#dc2626', lineHeight: 1 }}>
                      {remainingAfterApproval}
                    </div>
                    <div style={{ fontSize: '0.72rem', color: '#6b7280', marginTop: '2px' }}>After Approval</div>
                  </div>
                )}
              </div>
              {leave.status === 'Pending' && !hasBalance && selectedBalance && (
                <div style={{ marginTop: '10px', padding: '6px 10px', background: '#fef2f2', borderRadius: '6px', fontSize: '0.75rem', color: '#dc2626', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Icon icon="mdi:alert-circle" width={14} />
                  Insufficient balance for paid approval ({selectedBalance.remaining} remaining, {daysRequested} requested)
                </div>
              )}
            </div>
          )}

          {/* Details Card */}
          <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)', marginBottom: '20px' }}>
            <CardBody style={{ padding: '24px 28px' }}>
              <InfoRow label="Applicant Name">
                <div className="d-flex align-items-center gap-2">
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, var(--bs-primary) 0%, #6f42c1 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                    {initials}
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{leave.salutation} {fullName}</div>
                    <div style={{ fontSize: '0.72rem', color: '#6b7280' }}>{leave.job_specification || leave.designation_name || ''}</div>
                  </div>
                </div>
              </InfoRow>

              <InfoRow label="Leave Date">
                <div>
                  <div>{leave.from_date ? new Date(leave.from_date).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '--'}</div>
                  {leave.duration_type === 'multiple' && leave.to_date && (
                    <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>
                      To: {new Date(leave.to_date).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                      <span style={{ marginLeft: '8px', fontWeight: 600, color: '#374151' }}>({daysRequested} working days)</span>
                    </div>
                  )}
                </div>
              </InfoRow>

              <InfoRow label="Leave Type"><LeaveTypeBadge type={typeName} half={halfLabel} /></InfoRow>

              <InfoRow label="Paid">
                <Badge style={{ backgroundColor: paidStatus === 'paid' ? '#198754' : '#6c757d', fontSize: '0.7rem', borderRadius: '4px' }}>
                  {paidStatus === 'paid' ? 'Paid' : 'Unpaid'}
                </Badge>
              </InfoRow>

              <InfoRow label="Duration">
                <span style={{ fontSize: '0.85rem' }}>{leave.duration_type}</span>
                {halfLabel && (
                  <span style={{ marginLeft: '8px', backgroundColor: '#374151', color: '#fff', borderRadius: '4px', padding: '2px 8px', fontSize: '0.7rem', fontWeight: 600 }}>{halfLabel}</span>
                )}
              </InfoRow>

              <InfoRow label="Reason for absence">{leave.reason || '--'}</InfoRow>

              <InfoRow label="Status">
                <span className="d-flex align-items-center gap-1">
                  <span style={{ width: 8, height: 8, borderRadius: '50%', display: 'inline-block', backgroundColor: leave.status === 'Approved' ? '#198754' : leave.status === 'Rejected' ? '#dc3545' : '#ffc107' }} />
                  {leave.status}
                </span>
              </InfoRow>

              <InfoRow label="Actioned By">
                {leave.actioned_by_name ? (
                  <div className="d-flex align-items-center gap-2">
                    <div style={{ width: 32, height: 32, borderRadius: '50%', backgroundColor: '#e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700, color: '#374151' }}>
                      {leave.actioned_by_name?.split(' ').map((n) => n[0]).join('').toUpperCase()}
                    </div>
                    <div>
                      <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>{leave.actioned_by_name}</div>
                      <div style={{ fontSize: '0.72rem', color: '#6b7280' }}>{leave.actioned_by_designation || ''}</div>
                    </div>
                  </div>
                ) : '--'}
              </InfoRow>

              <InfoRow label="Actioned At">
                {leave.actioned_at
                  ? new Date(leave.actioned_at).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })
                  + ' ' + new Date(leave.actioned_at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
                  : '--'}
              </InfoRow>

              <InfoRow label="Admin Note">{leave.admin_note || '--'}</InfoRow>

              <InfoRow label="Files">
                {leave.file_url ? (
                  <a href={leave.file_url} target="_blank" rel="noreferrer" style={{ fontSize: '0.85rem' }}>
                    <Icon icon="mdi:file-outline" width={20} /> View File
                  </a>
                ) : (
                  <div className="text-center py-3" style={{ color: '#9ca3af' }}>
                    <Icon icon="mdi:file-outline" width={32} style={{ display: 'block', margin: '0 auto 6px', opacity: 0.4 }} />
                    <div style={{ fontSize: '0.78rem' }}>- No file uploaded. -</div>
                  </div>
                )}
              </InfoRow>
            </CardBody>
          </Card>

          {/* Action Panel */}
          <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)' }}>
            <CardBody style={{ padding: '24px 28px' }}>
              <div style={{ fontSize: '0.7rem', fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '16px' }}>
                Action
              </div>

              <div className="mb-3">
                <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Approve / Reject Note</FormLabel>
                <Form.Control
                  as="textarea" rows={3} placeholder="e.g. Approved — medical emergency confirmed"
                  value={adminNote} onChange={(e) => setAdminNote(e.target.value)}
                  style={{ borderRadius: '6px', fontSize: '0.85rem', resize: 'vertical' }}
                />
              </div>

              <div className="mb-3">
                <FormLabel style={{ fontSize: '0.8rem', fontWeight: 600 }}>Paid Status</FormLabel>
                <div className="d-flex gap-3">
                  {['paid', 'unpaid'].map((p) => (
                    <div
                      key={p}
                      onClick={() => setPaidStatus(p)}
                      style={{
                        padding: '8px 20px', borderRadius: '8px', cursor: 'pointer', fontSize: '0.83rem', fontWeight: 600,
                        border: `2px solid ${paidStatus === p ? (p === 'paid' ? '#198754' : '#6c757d') : '#e5e7eb'}`,
                        backgroundColor: paidStatus === p ? (p === 'paid' ? '#f0fdf4' : '#f3f4f6') : '#fff',
                        color: paidStatus === p ? (p === 'paid' ? '#16a34a' : '#374151') : '#9ca3af',
                        transition: 'all 0.15s',
                      }}
                    >
                      <Icon icon={p === 'paid' ? 'mdi:currency-usd' : 'mdi:currency-usd-off'} width={14} style={{ marginRight: '4px' }} />
                      {p === 'paid' ? 'Paid' : 'Unpaid'}
                    </div>
                  ))}
                </div>
              </div>

              <div className="d-flex gap-2 flex-wrap">
                <Button
                  onClick={() => requestConfirm('Approved', paidStatus)}
                  disabled={updating || !canApprovePaid}
                  title={!canApprovePaid ? 'Leave is not pending' : ''}
                  style={{ backgroundColor: '#198754', borderColor: '#198754', borderRadius: '8px', fontWeight: 600, fontSize: '0.85rem', padding: '8px 18px', display: 'flex', alignItems: 'center', gap: '6px', opacity: !canApprovePaid ? 0.5 : 1 }}
                >
                  {updating ? <Spinner animation="border" size="sm" /> : <Icon icon="mdi:check-circle" width={16} />}
                  Approve
                </Button>

                <Button
                  onClick={() => requestConfirm('Rejected', null)}
                  disabled={updating || leave.status === 'Rejected'}
                  style={{ backgroundColor: '#dc3545', borderColor: '#dc3545', borderRadius: '8px', fontWeight: 600, fontSize: '0.85rem', padding: '8px 18px', display: 'flex', alignItems: 'center', gap: '6px', opacity: leave.status === 'Rejected' ? 0.5 : 1 }}
                >
                  {updating ? <Spinner animation="border" size="sm" /> : <Icon icon="mdi:close-circle" width={16} />}
                  Reject
                </Button>

                <Button variant="link" onClick={onClose} style={{ color: '#6b7280', fontWeight: 500, fontSize: '0.85rem', textDecoration: 'none' }}>
                  Cancel
                </Button>
              </div>

              {leave.status !== 'Pending' && (
                <div style={{ marginTop: '12px', padding: '8px 12px', background: '#f9fafb', borderRadius: '8px', fontSize: '0.78rem', color: '#6b7280', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Icon icon="mdi:information-outline" width={14} />
                  This leave is already <strong style={{ marginLeft: 2 }}>{leave.status}</strong>. Some actions may be restricted.
                </div>
              )}
            </CardBody>
          </Card>

        </Modal.Body>
      </Modal>
    </>
  )
}


// ─────────────────────────────────────────────
// Main LeaveDetails page
// ─────────────────────────────────────────────
function LeaveDetails() {
  const [viewingLeave, setViewingLeave] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [editingLeave, setEditingLeave] = useState(null)
  const [currentPage, setCurrentPage] = useState(1)
  const [searchEmploye, SetSearchEmploye] = useState('')
  const [selectedEmployee, setSelectedEmployee] = useState(null)
  const [employeName, setEmployeName] = useState('')
  const logsPerPage = 10

  // ── Filter state ──
  const [filters, setFilters] = useState({})
  const [selectedEmp, setSelectedEmp] = useState(null)   // { label, value }
  const [empSearchInput, setEmpSearchInput] = useState('')     // controlled input value
  const [statusFilter, setStatus] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [leaves, setLeaves] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(false)
  const [showUnsavedModal, setShowUnsavedModal] = useState(false)

  // ── Data ──
  // const [fetchLeavesApi] = useGetAllLeavessMutation()
  const [getAllLeaves, { isLoading }] = useGetAllLeavessMutation()
  

  // ── Employee name search via RTK Query (same pattern as payroll template names) ──
  // const { data: empNameData } = useGetEmployeenameQuery(empSearchInput, {
  //   skip: !empSearchInput || empSearchInput.length < 1,
  // })
  const { data: RecipientResults } = useGetEmployeenameQuery(searchEmploye, {
    skip: searchEmploye.length < 2,
  })

  const orderOptions = RecipientResults?.map((order) => ({ label: `${order.full_name}` })) || []
  const debouncedSearchRecipient = debounce((value) => { SetSearchEmploye(value) }, 300)
  // const empNameOptions = useMemo(() => {
  //   return (Array.isArray(empNameData) ? empNameData : []).map((e) => ({
  //     label: e.full_name,
  //     value: e.full_name,
  //   }))
  // }, [empNameData])

  // ── Pagination ──
  // const filteredLeaves = allLeaves
  // const totalPages = Math.ceil(filteredLeaves.length / logsPerPage) || 1
  // const leaves = filteredLeaves.slice((currentPage - 1) * logsPerPage, currentPage * logsPerPage)

  // const handlePageChange = (page) => {
  //   if (page < 1 || page > totalPages) return
  //   setCurrentPage(page)
  // }
const handlePageChange = (page) => {
  if (page < 1 || page > totalPages) return
  fetchLogs(page) 
}
  const handleSaved = () => {
    setShowForm(false)
    setEditingLeave(null)
    setCurrentPage(1)
    // refetch()
    fetchLogs(currentPage)
  }


//   const fetchLogs = async (page = 1) => {
//   setLoading(true)
//   try {
//     const res = await fetchLeavesApi({
//       page,
//       limit: logsPerPage,
//       keyword: filters.keyword,
//       status: filters.status,
//       from_date: filters.from_date,
//       to_date: filters.to_date,
//     }).unwrap()

//     setLeaves(res.leaves || [])
//     setTotalPages(res.totalPages || 1)
//     setCurrentPage(page)

//   } catch (err) {
//     console.error("Failed to fetch leaves:", err)
//   } finally {
//     setLoading(false)
//   }
// }
const fetchLogs = async (page = 1) => {
  try {
    const res = await getAllLeaves({
      page,
      limit: 10,
      keyword: filters.keyword || '',
      status: filters.status || '',
      from_date: filters.from_date || '',
      to_date: filters.to_date || '',
    }).unwrap()

    setLeaves(res.leaves)
    setTotalPages(res.totalPages)
    setCurrentPage(res.currentPage)

  } catch (err) {
  }
}

  // ── Search ──
  // const handleSearch = () => {
  //   const newFilters = {}
  //   if (selectedEmp?.value) newFilters.keyword = selectedEmp.value
  //   else if (empSearchInput) newFilters.keyword = empSearchInput
  //   if (statusFilter) newFilters.status = statusFilter
  //   if (fromDate) newFilters.from_date = fromDate
  //   if (toDate) newFilters.to_date = toDate
  //   setFilters(newFilters)
  //   setCurrentPage(1)
  // }

  const handleSearch = () => {
  const newFilters = {}

  if (employeName) newFilters.keyword = employeName
  if (statusFilter) newFilters.status = statusFilter
  if (fromDate) newFilters.from_date = fromDate
  if (toDate) newFilters.to_date = toDate

  setFilters(newFilters)

  fetchLogs(1) 
}

useEffect(() => {
  fetchLogs(1)
}, [])



  const formatDate = (d) => {
    if (!d) return '-'
    return (
      new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) +
      ' (' + new Date(d).toLocaleDateString('en-GB', { weekday: 'long' }) + ')'
    )
  }

  return (
   <>
    {showForm && (
      <LeaveFormModal
        leave={editingLeave}
        onClose={() => { setShowForm(false); setEditingLeave(null) }}
        onSaved={handleSaved}
      />
    )}

    {viewingLeave && (
      <LeaveViewModal
        leave={viewingLeave}
        onClose={() => setViewingLeave(null)}
        onStatusChange={() => { setViewingLeave(null); fetchLogs(currentPage) }}
      />
    )}

    <Row className="justify-content-center">
        <Col>
          <Card>
            <CardHeader className="py-3 bg-light">
              <Row className="align-items-center justify-content-between">
                <Col>
                  <CardTitle as="h4" className="mb-0">Leave List</CardTitle>
                </Col>
                <Col xs="auto" className="d-flex gap-2">
                  <Button
                    type="button"
                    style={{ backgroundColor: '#fff', borderColor: '#dee2e6', color: '#374151', fontWeight: 600, fontSize: '0.82rem', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}
                  >
                    <Icon icon="mdi:export" width={16} /> Export as CSV
                  </Button>
                  <Button
                    type="button"
                    className="btn bg-primary border border-primary"
                    onClick={() => { setEditingLeave(null); setShowForm(true) }}
                  >
                    <IconifyIcon icon="fa6-solid:plus" className="me-1" /> New Leave
                  </Button>
                </Col>
              </Row>
            </CardHeader>

            <CardBody>
              {/* ── Filters ── */}
              <Form className="row g-1 mb-3" onSubmit={(e) => { e.preventDefault(); handleSearch() }}>

                <FormGroup className="col-md-3">
                  <FormLabel>Keyword</FormLabel>
                  <Select
                    styles={{
                      control: (base, state) => ({
                        ...base, borderRadius: '999px',
                        borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                        boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                      }),
                    }}
                    options={orderOptions}
                    onInputChange={(value, { action }) => {
                      if (action === 'input-change') {
                        debouncedSearchRecipient(value)
                        SetSearchEmploye(value)
                        setEmployeName(value)
                        setFilters((prev) => ({ ...prev, keyword: value }))
                      }
                    }}
                    onChange={(option) => {
                      if (option) {
                        const name = option.label?.split('(')[0].trim()
                        setEmployeName(name)
                        SetSearchEmploye(name)
                        setFilters((prev) => ({ ...prev, keyword: name }))
                      } else {
                        setEmployeName('')
                        SetSearchEmploye('')
                        setFilters((prev) => ({ ...prev, keyword: '' }))
                      }
                    }}
                    placeholder="ID, Name"
                    isClearable isSearchable
                    value={employeName ? { label: employeName, value: employeName } : null}
                    components={{ DropdownIndicator: null }}
                  />
                </FormGroup>

                {/* Employee */}
                {/* <FormGroup className="col-md-3">
                  <FormLabel>Employee</FormLabel>
                  <Select
                    styles={{
                      control: (base, state) => ({
                        ...base,
                        borderRadius: '999px',
                        borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                        boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                      }),
                    }}
                    options={empNameOptions}
                    inputValue={empSearchInput}
                    value={selectedEmp}
                    onInputChange={(value, { action }) => {
                      if (action === 'input-change') {
                        setEmpSearchInput(value)
                        if (!value) setSelectedEmp(null)
                      }
                    }}
                    onChange={(option) => {
                      if (option) {
                        setSelectedEmp(option)
                        setEmpSearchInput(option.label)
                      } else {
                        setSelectedEmp(null)
                        setEmpSearchInput('')
                      }
                    }}
                    placeholder="Search by name..."
                    isClearable
                    isSearchable
                    filterOption={() => true}
                    noOptionsMessage={({ inputValue }) =>
                      inputValue.length < 1 ? 'Type to search...' : 'No employees found'
                    }
                    components={{ DropdownIndicator: null }}
                  />
                </FormGroup> */}

                {/* Date range */}
                <FormGroup className="col-md-4">
                  <div className="row g-1">
                    <div className="col-6">
                      <FormLabel>From Date</FormLabel>
                      <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
                    </div>
                    <div className="col-6">
                      <FormLabel>To Date</FormLabel>
                      <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                    </div>
                  </div>
                </FormGroup>

                {/* Status */}
                <FormGroup className="col-md-3">
                  <FormLabel>Status</FormLabel>
                  <Form.Select value={statusFilter} onChange={(e) => setStatus(e.target.value)}>
                    <option value="">All</option>
                    <option value="Pending">Pending</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                  </Form.Select>
                </FormGroup>

                {/* Buttons */}
                <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                  <Button
                    type="submit"
                    className="bg-primary border border-primary flex-grow-1"
                    variant="primary"
                    onClick={handleSearch}
                  >
                    Search
                  </Button>
                </FormGroup>
              </Form>

              {/* ── Table ── */}
              <Table striped bordered hover responsive>
                <thead className="table-light">
                  <tr>
                    <th>Employee</th>
                    <th>Leave Date</th>
                    <th>Duration</th>
                    <th>Leave Status</th>
                    <th>Leave Type</th>
                    <th>Paid</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="7" className="text-center">
                        <Spinner animation="border" size="sm" /> Loading...
                      </td>
                    </tr>
                  ) : leaves.length > 0 ? (
                    leaves.map((leave) => {
                      const fullName = [leave.first_name, leave.last_name].filter(Boolean).join(' ')
                      const [typeName, halfLabel] = (leave.leave_type_name || '').split(' - ')
                      return (
                        <tr key={leave.leave_id}>
                          <td>{fullName}</td>
                          <td>{formatDate(leave.from_date)}</td>
                          <td>
                            {leave.duration_type === 'multiple' ? (
                              <div>
                                <div style={{ fontSize: '0.82rem' }}>Multiple</div>
                                <Badge bg="secondary">
                                  {leave.days_count || (() => {
                                    if (!leave.from_date || !leave.to_date) return '?'
                                    const from = new Date(leave.from_date)
                                    const to = new Date(leave.to_date)
                                    let count = 0
                                    const cur = new Date(from)
                                    while (cur <= to) {
                                      const day = cur.getDay()
                                      if (day !== 0 && day !== 6) count++
                                      cur.setDate(cur.getDate() + 1)
                                    }
                                    return count
                                  })()} Days
                                </Badge>
                              </div>
                            ) : (
                              <span style={{ textTransform: 'capitalize' }}>{leave.duration_type?.replace('_', ' ') || '-'}</span>
                            )}
                          </td>
                          <td><StatusDot status={leave.status} /></td>
                          <td><LeaveTypeBadge type={typeName} half={halfLabel} /></td>
                          <td>
                            <Badge style={{ backgroundColor: leave.paid_status === 'paid' ? '#198754' : '#6c757d', fontSize: '0.7rem', fontWeight: 600, borderRadius: '4px' }}>
                              {leave.paid_status === 'paid' ? 'Paid' : 'Unpaid'}
                            </Badge>
                          </td>
                          <td className="text-end no-print">
                            <div className="d-flex justify-content-end align-items-center gap-2">
                              <Button
                                className="d-flex align-items-center"
                                onClick={() => setViewingLeave(leave)}
                                style={{ minWidth: 'auto', padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: '30px', borderRadius: '15px', backgroundColor: '#5f5f5f', borderColor: '#5f5f5f', color: '#fff' }}
                              >
                                <Icon icon="mdi:eye" width={15} style={{ marginRight: '4px' }} /><span>View</span>
                              </Button>
                              <Button
                                className="d-flex align-items-center"
                                onClick={() => { setEditingLeave(leave); setShowForm(true) }}
                                style={{ minWidth: 'auto', padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: '30px', borderRadius: '15px', backgroundColor: '#fd7e14', borderColor: '#fd7e14', color: '#fff' }}
                              >
                                <Icon icon="mdi:pencil" width={15} style={{ marginRight: '4px' }} /><span>Edit</span>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      )
                    })
                  ) : (
                    <tr><td colSpan="7" className="text-center">No Leaves Found</td></tr>
                  )}
                </tbody>
              </Table>

              {/* ── Pagination ── */}
              {totalPages > 1 && (
                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>First</Pagination.Item>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
                    {(() => {
                      const pages = []
                      let start = currentPage - 2
                      let end = currentPage + 2
                      if (start < 1) { start = 1; end = Math.min(5, totalPages) }
                      if (end > totalPages) { end = totalPages; start = Math.max(1, totalPages - 4) }
                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                            {i}
                          </Pagination.Item>
                        )
                      }
                      return pages
                    })()}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                    <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>Last</Pagination.Item>
                  </Pagination>
                </div>
              )}

            </CardBody>
          </Card>
        </Col>
      </Row>
    </>
  )
}

export default LeaveDetails