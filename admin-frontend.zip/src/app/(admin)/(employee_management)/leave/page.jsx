import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Leave - Employee Management',
}


const Leave = dynamic(() => import('./Leave'), { ssr: false })

export default function AddDesignationPage() {
  return <Leave />
}