import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Shift Roster - Employee Management',
}


const ShiftRoster = dynamic(() => import('./ShiftRoster'), { ssr: false })

export default function AddDesignationPage() {
  return <ShiftRoster/>
}