'use client'

import React, { useState, useMemo, useEffect } from 'react'
import {
  Button, Col, Form, FormControl, FormLabel, FormSelect,
  Row, Modal, Card, CardHeader, CardBody, CardTitle, Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import {
  useGetRosterByMonthQuery,
  useCreateRosterEntryMutation,
  useGetFilteredAllEmpolyeesMutation, 
  useGetShiftsQuery,
} from '@/store/features/emsSlice'

const MONTH_NAMES = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
]
const DAY_SHORT = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']

const SHIFT_COLORS = [
  '#0d6efd','#198754','#fd7e14','#6610f2','#6c757d',
  '#dc3545','#20c997','#0dcaf0','#ffc107','#d63384',
]

function getDaysInMonth(year, month) {
  const days = []
  const d = new Date(year, month, 1)
  while (d.getMonth() === month) { days.push(new Date(d)); d.setDate(d.getDate() + 1) }
  return days
}

const toKey = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

const isWeekend = (d) => d.getDay() === 0 || d.getDay() === 6

const getDatesInRange = (from, to) => {
  const dates = []
  const cur = new Date(from)
  const end = new Date(to)
  while (cur <= end) {
    dates.push(new Date(cur))
    cur.setDate(cur.getDate() + 1)
  }
  return dates
}

const fmtDate = (d) =>
  `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`

const Avatar = ({ name = '', size = 28 }) => {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
  const palette  = ['#0d6efd','#198754','#fd7e14','#6610f2','#dc3545','#20c997']
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: palette[name.charCodeAt(0) % palette.length],
      color: '#fff', display: 'inline-flex', alignItems: 'center',
      justifyContent: 'center', fontSize: size * 0.38, fontWeight: 600, flexShrink: 0,
    }}>
      {initials}
    </div>
  )
}

const ShiftRoster = () => {
  const today = new Date()

  const [currentYear,  setCurrentYear]  = useState(today.getFullYear())
  const [currentMonth, setCurrentMonth] = useState(today.getMonth())
  const [showModal,    setShowModal]    = useState(false)
  const [selDate,      setSelDate]      = useState(null)
  const [selEmps,      setSelEmps]      = useState([])
  const [shift,        setShift]        = useState('')
  const [remark,       setRemark]       = useState('')
  const [file,         setFile]         = useState(null)
  const [saving,       setSaving]       = useState(false)
  const [empSearch,    setEmpSearch]    = useState('')
  const [dateMode, setDateMode]   = useState('single')   
  const [dateFrom, setDateFrom]   = useState('')
  const [dateTo,   setDateTo]     = useState('')

  const [getEmployees, { data: empResultsFromApi = [], isLoading: empsLoading }] = useGetFilteredAllEmpolyeesMutation()
  const { data: shifts = [],    isLoading: shiftsLoading } = useGetShiftsQuery()
  const { data: rosterData = [], isLoading: rosterLoading } = useGetRosterByMonthQuery({
    year:  currentYear,
    month: currentMonth + 1,
  })
  const [createRosterEntry] = useCreateRosterEntryMutation()

  useEffect(() => {
  getEmployees({ keyword: '' }) 
}, [getEmployees])


const employees = useMemo(() => {
  const list = Array.isArray(empResultsFromApi)
    ? empResultsFromApi
    : Array.isArray(empResultsFromApi?.data)
    ? empResultsFromApi.data
    : Array.isArray(empResultsFromApi?.employees)
    ? empResultsFromApi.employees
    : []

  return list.map(e => ({
    employee_id: e.employee_id ?? e.id ?? e.emp_id ?? '',
    name: e.full_name || e.employee_name || 
          [e.first_name, e.last_name].filter(Boolean).join(' ') || 'Unknown',
    designation: e.designation_name || e.designation || '',
  }))
}, [empResultsFromApi])

 
  const days = getDaysInMonth(currentYear, currentMonth)

  const shiftColorMap = useMemo(() => {
    const map = {}
    shifts.forEach((s, i) => {
      map[s.id] = SHIFT_COLORS[i % SHIFT_COLORS.length]
    })
    return map
  }, [shifts])

  
  const shiftAbbrMap = useMemo(() => {
    const map = {}
    shifts.forEach(s => {
      
      map[s.id] = (s.shift_name || s.name || 'S')
        .split(' ')
        .map(w => w[0])
        .join('')
        .toUpperCase()
        .slice(0, 3)
    })
    return map
  }, [shifts])

 
const roster = useMemo(() => {
  const map = {}
  rosterData.forEach(entry => {
    if (!map[entry.employee_id]) map[entry.employee_id] = {}

    const raw = entry.roster_date?.slice(0, 10)
    if (!raw) return
    
    const [y, m, d] = raw.split('-').map(Number)
    const dateKey = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`

    map[entry.employee_id][dateKey] = entry
  })
  return map
}, [rosterData])

useEffect(() => {
  if (rosterData.length > 0) {
    console.log('First roster entry roster_date:', rosterData[0].roster_date)
    console.log('Type:', typeof rosterData[0].roster_date)
  }
}, [rosterData])

  const defaultShiftId = shifts[0]?.id ?? ''

  
  const countOnDate = (d) =>
    employees.filter(e => roster[e.employee_id]?.[toKey(d)]).length

  const prevMonth = () => {
    if (currentMonth === 0) { setCurrentYear(y => y - 1); setCurrentMonth(11) }
    else setCurrentMonth(m => m - 1)
  }
  const nextMonth = () => {
    if (currentMonth === 11) { setCurrentYear(y => y + 1); setCurrentMonth(0) }
    else setCurrentMonth(m => m + 1)
  }

  const openModal = (day) => {
    setSelDate(day)
    setSelEmps([])
    setShift(defaultShiftId)
    setRemark('')
    setFile(null)
    setEmpSearch('')
    setShowModal(true)
  }

  const toggleEmp = (id) =>
    setSelEmps(p => p.includes(id) ? p.filter(e => e !== id) : [...p, id])


const handleSave = async () => {
  if (!selEmps.length || !shift) return

  // Conflict check across all selected dates
  for (const empId of selEmps) {
    const conflict = hasShiftConflict(empId, shift, selectedDates)
    if (conflict) {
      const emp = employees.find(e => e.employee_id === empId)
      alert(
        `Conflict: ${emp?.name} already has overlapping shift "${conflict.existingShift.shift_name}" on ${conflict.date}.\n\nCannot assign a new shift during the same hours.`
      )
      return
    }
  }

  setSaving(true)
  try {
    for (const date of selectedDates) {
      const rosterDateStr = fmtDate(date)
      await createRosterEntry({
        employee_ids: selEmps,
        shift_id:     shift,
        roster_date:  rosterDateStr,
        remarks:      remark,
      }).unwrap()
    }
    setShowModal(false)
  } catch (err) {
    console.error('Failed to save roster:', err)
  } finally {
    setSaving(false)
  }
}

  
const visibleEmps = employees
  .filter(e => e.name.toLowerCase().includes(empSearch.toLowerCase()))
  .sort((a, b) => {
    const aChecked = selEmps.includes(a.employee_id)
    const bChecked = selEmps.includes(b.employee_id)
    if (aChecked && !bChecked) return -1
    if (!aChecked && bChecked) return 1
    return 0
  })

  const isLoading = empsLoading || shiftsLoading || rosterLoading

 
const hasShiftConflict = (empId, targetShiftId, targetDates) => {
  if (!targetShiftId) return false
  const targetShift = shifts.find(s => s.id === Number(targetShiftId))
  if (!targetShift) return false

  const [tInH, tInM]   = String(targetShift.shift_in_time).split(':').map(Number)
  const [tOutH, tOutM] = String(targetShift.shift_out_time).split(':').map(Number)
  const tIn  = tInH  * 60 + tInM
  const tOut = tOutH * 60 + tOutM

  for (const date of targetDates) {
    const key     = toKey(date)
    const existing = roster[empId]?.[key]
    if (!existing) continue

    // Same shift on same day — this is an update, not a conflict
    if (existing.shift_id === Number(targetShiftId)) continue

    const existingShift = shifts.find(s => s.id === existing.shift_id)
    if (!existingShift) continue

    const [eInH, eInM]   = String(existingShift.shift_in_time).split(':').map(Number)
    const [eOutH, eOutM] = String(existingShift.shift_out_time).split(':').map(Number)
    const eIn  = eInH  * 60 + eInM
    const eOut = eOutH * 60 + eOutM

    // Overlap check: two shifts overlap if one starts before the other ends
    const overlaps = tIn < eOut && tOut > eIn
    if (overlaps) return { date: key, existingShift }
  }
  return false
}


const selectedDates = useMemo(() => {
  if (dateMode === 'single' && selDate) return [selDate]
  if (dateMode === 'range' && dateFrom && dateTo) {
    return getDatesInRange(dateFrom, dateTo)
  }
  return selDate ? [selDate] : []
}, [dateMode, selDate, dateFrom, dateTo])

  return (
    <>
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center">
            <Col>
              <CardTitle as="h4" style={{ fontSize: '18px' }} className="mb-0">
                Shift Roster
              </CardTitle>
              <p className="text-muted mb-0" style={{ fontSize: '13px' }}>
                Click on any date to assign or update shifts
              </p>
            </Col>

            <Col xs="auto" className="d-flex align-items-center gap-2 flex-wrap">
            
              <div className="d-flex align-items-center gap-3 flex-wrap me-2">
                {shifts.map(s => (
                  <span key={s.id} className="d-flex align-items-center gap-1"
                    style={{ fontSize: '11px', color: '#495057' }}>
                    <span style={{
                      width: 9, height: 9, borderRadius: 2,
                      background: shiftColorMap[s.id],
                      display: 'inline-block',
                    }} />
                    {s.shift_name || s.name}
                  </span>
                ))}
                <span className="d-flex align-items-center gap-1" style={{ fontSize: '11px', color: '#495057' }}>
                  <Icon icon="mdi:star" width={11} style={{ color: '#ffc107' }} /> Holiday
                </span>
              </div>

              <Button variant="outline-secondary" size="sm" onClick={prevMonth}
                style={{ borderRadius: '50%', width: 32, height: 32, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon icon="mdi:chevron-left" width={18} />
              </Button>
              <span style={{ fontSize: '14px', fontWeight: 600, minWidth: 150, textAlign: 'center' }}>
                {MONTH_NAMES[currentMonth]} {currentYear}
              </span>
              <Button variant="outline-secondary" size="sm" onClick={nextMonth}
                style={{ borderRadius: '50%', width: 32, height: 32, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon icon="mdi:chevron-right" width={18} />
              </Button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody className="p-0">
          {isLoading ? (
            <div className="text-center py-5 text-muted" style={{ fontSize: '13px' }}>
              <Icon icon="mdi:loading" width={28} className="spin" style={{ display: 'block', margin: '0 auto 8px' }} />
              Loading roster...
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ borderCollapse: 'collapse', width: '100%', tableLayout: 'fixed', minWidth: 320 }}>

               
                <thead>
                  <tr>
                    {days.map(d => {
                      const weekend  = isWeekend(d)
                      const isToday  = toKey(d) === toKey(today)
                      const assigned = countOnDate(d)

                      return (
                        <th
                          key={d.getDate()}
                          onClick={() => openModal(d)}
                          title={`${d.toDateString()} — click to assign`}
                          style={{
                            padding: '10px 2px 8px',
                            textAlign: 'center',
                            cursor: 'pointer',
                            borderRight: '1px solid #dee2e6',
                            borderBottom: '2px solid #dee2e6',
                            background: isToday ? '#e8f4fd' : weekend ? '#fff8f8' : '#f8f9fa',
                            transition: 'background 0.15s',
                            userSelect: 'none',
                          }}
                          onMouseEnter={e => e.currentTarget.style.background = '#dbeeff'}
                          onMouseLeave={e => e.currentTarget.style.background = isToday ? '#e8f4fd' : weekend ? '#fff8f8' : '#f8f9fa'}
                        >
                          <div style={{
                            fontSize: '15px',
                            fontWeight: isToday ? 700 : 600,
                            color: isToday ? '#0d6efd' : weekend ? '#dc3545' : '#212529',
                            lineHeight: 1,
                          }}>
                            {d.getDate()}
                          </div>
                          <div style={{ fontSize: '9px', color: '#6c757d', letterSpacing: '0.03em', marginTop: 2 }}>
                            {DAY_SHORT[d.getDay()]}
                          </div>
                          <div style={{ marginTop: 4, minHeight: 16 }}>
                            {assigned > 0 ? (
                              <span style={{
                                background: '#0d6efd', color: '#fff',
                                borderRadius: 10, fontSize: '9px',
                                padding: '1px 5px', fontWeight: 600,
                              }}>
                                {assigned}
                              </span>
                            ) : isToday ? (
                              <span style={{
                                width: 5, height: 5, borderRadius: '50%',
                                background: '#0d6efd', display: 'inline-block',
                              }} />
                            ) : null}
                          </div>
                        </th>
                      )
                    })}
                  </tr>
                </thead>

                <tbody>
                  {shifts.map(s => {
                    const hasAny = days.some(d =>
                      employees.some(e => roster[e.employee_id]?.[toKey(d)]?.shift_id === s.id)
                    )
                    if (!hasAny) return null

                    return (
                      <tr key={s.id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                        {days.map(d => {
                          const cnt = employees.filter(e =>
                            roster[e.employee_id]?.[toKey(d)]?.shift_id === s.id
                          ).length

                          return (
                            <td key={d.getDate()}
                              onClick={() => openModal(d)}
                              style={{
                                padding: '5px 2px', textAlign: 'center',
                                cursor: 'pointer', borderRight: '1px solid #f0f0f0',
                                background: isWeekend(d) ? '#fffbfb' : '#fff',
                              }}
                              onMouseEnter={e => e.currentTarget.style.background = '#f0f7ff'}
                              onMouseLeave={e => e.currentTarget.style.background = isWeekend(d) ? '#fffbfb' : '#fff'}
                            >
                              {cnt > 0 ? (
                                <span style={{
                                  display: 'inline-block',
                                  background: shiftColorMap[s.id],
                                  color: '#fff', borderRadius: 4,
                                  fontSize: '9px', padding: '2px 5px', fontWeight: 600,
                                }}>
                                  {shiftAbbrMap[s.id]} ×{cnt}
                                </span>
                              ) : (
                                <span style={{ color: '#e9ecef', fontSize: '10px' }}>—</span>
                              )}
                            </td>
                          )
                        })}
                      </tr>
                    )
                  })}

 
                  {!days.some(d => employees.some(e => roster[e.employee_id]?.[toKey(d)])) && (
                    <tr>
                      <td colSpan={days.length}
                        style={{ textAlign: 'center', padding: '36px 0', color: '#adb5bd', fontSize: '13px' }}>
                        <Icon icon="mdi:calendar-blank-outline" width={30}
                          style={{ display: 'block', margin: '0 auto 8px' }} />
                        No shifts assigned yet — click any date to get started
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>

      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="xl">
        <Modal.Header closeButton>
          <Modal.Title style={{ fontSize: '16px', fontWeight: 600 }}>
            Assign Shift
          </Modal.Title>
        </Modal.Header>

       
<Modal.Body style={{ padding: 0 }}>
  <div style={{ display: 'flex', minHeight: 520 }}>

    {/* ── LEFT COLUMN ── */}
    <div style={{ flex: '0 0 55%', padding: '20px', borderRight: '1px solid #dee2e6', overflowY: 'auto' }}>

      {/* Date selector */}
      <Form.Group className="mb-3">
        <FormLabel style={{ fontSize: '13px', fontWeight: 600 }}>Date Selection</FormLabel>
        <div className="d-flex gap-2 mb-2">
          <Button
            size="sm"
            variant={dateMode === 'single' ? 'primary' : 'outline-secondary'}
            onClick={() => setDateMode('single')}
            style={{ borderRadius: 20, fontSize: '12px' }}>
            Single Date
          </Button>
          <Button
            size="sm"
            variant={dateMode === 'range' ? 'primary' : 'outline-secondary'}
            onClick={() => setDateMode('range')}
            style={{ borderRadius: 20, fontSize: '12px' }}>
            Date Range
          </Button>
        </div>

        {dateMode === 'single' && selDate && (
          <div className="p-2 rounded d-flex align-items-center gap-2"
            style={{ background: '#f0f6ff', border: '1px solid #cce0ff' }}>
            <Icon icon="mdi:calendar" width={15} style={{ color: '#0d6efd' }} />
            <span style={{ fontSize: '13px', fontWeight: 600, color: '#0d6efd' }}>
              {selDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric', weekday: 'long' })}
            </span>
          </div>
        )}

        {dateMode === 'range' && (
          <div className="d-flex gap-2 align-items-center">
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', color: '#6c757d', marginBottom: 3 }}>From</div>
              <FormControl
                type="date" size="sm"
                value={dateFrom}
                onChange={e => setDateFrom(e.target.value)}
                style={{ fontSize: '13px' }} />
            </div>
            <div style={{ paddingTop: 18, color: '#6c757d' }}>→</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', color: '#6c757d', marginBottom: 3 }}>To</div>
              <FormControl
                type="date" size="sm"
                value={dateTo}
                min={dateFrom}
                onChange={e => setDateTo(e.target.value)}
                style={{ fontSize: '13px' }} />
            </div>
          </div>
        )}

        {selectedDates.length > 1 && (
          <div style={{ fontSize: '11px', color: '#198754', marginTop: 6 }}>
            <Icon icon="mdi:check-circle" width={12} /> {selectedDates.length} days selected
            ({fmtDate(selectedDates[0])} → {fmtDate(selectedDates[selectedDates.length - 1])})
          </div>
        )}
      </Form.Group>

      {/* Shift selector */}
      <Form.Group className="mb-3">
        <FormLabel style={{ fontSize: '13px', fontWeight: 600 }}>Employee Shift</FormLabel>
        <div className="position-relative">
          <span style={{
            position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)',
            width: 9, height: 9, borderRadius: '50%', zIndex: 1,
            background: shiftColorMap[shift] || '#6c757d', pointerEvents: 'none',
          }} />
          <FormSelect size="sm" value={shift}
            onChange={e => setShift(Number(e.target.value))}
            style={{ paddingLeft: 26, fontSize: '13px' }}>
            <option value="">Select shift...</option>
            {shifts.map(s => (
              <option key={s.id} value={s.id}>
                {s.shift_name || s.name}
                {s.shift_in_time && s.shift_out_time
                  ? ` (${String(s.shift_in_time).slice(0,5)} – ${String(s.shift_out_time).slice(0,5)})`
                  : ''}
              </option>
            ))}
          </FormSelect>
        </div>
      </Form.Group>

      {/* Employee picker */}
      <Form.Group className="mb-3">
        <FormLabel style={{ fontSize: '13px', fontWeight: 600 }}>
          Select Employees
          {selEmps.length > 0 && (
            <Badge bg="primary" className="ms-2" style={{ fontSize: '10px' }}>
              {selEmps.length} selected
            </Badge>
          )}
        </FormLabel>

        <div className="position-relative mb-2">
          <Icon icon="material-symbols:search-rounded" width={15}
            style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', color: '#adb5bd' }} />
          <FormControl size="sm" type="text"
            placeholder="Search employees..."
            value={empSearch}
            onChange={e => setEmpSearch(e.target.value)}
            style={{ paddingLeft: 30, fontSize: '13px' }} />
        </div>

        <div style={{ maxHeight: 210, overflowY: 'auto', border: '1px solid #dee2e6', borderRadius: 6 }}>
          {visibleEmps.length === 0
            ? <div className="text-center text-muted py-3" style={{ fontSize: '13px' }}>No employees found</div>
            : visibleEmps.map(emp => {
                const empId    = emp.employee_id
                const empName  = emp.name || ''
                const checked  = selEmps.includes(empId)

                // Conflict indicator for first selected date
                const conflict = shift && selectedDates.length > 0
                  ? hasShiftConflict(empId, shift, selectedDates)
                  : false

                return (
                  <div key={empId} onClick={() => toggleEmp(empId)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 10,
                      padding: '8px 12px', cursor: 'pointer',
                      background: conflict ? '#fff8f0' : checked ? '#e8f4fd' : 'transparent',
                      borderLeft: `3px solid ${conflict ? '#fd7e14' : checked ? '#0d6efd' : 'transparent'}`,
                      borderBottom: '1px solid #f8f8f8',
                    }}
                    onMouseEnter={e => { if (!checked && !conflict) e.currentTarget.style.background = '#f8f9fa' }}
                    onMouseLeave={e => { if (!checked && !conflict) e.currentTarget.style.background = 'transparent' }}
                  >
                    <Form.Check type="checkbox" checked={checked}
                      onChange={() => toggleEmp(empId)}
                      onClick={e => e.stopPropagation()}
                      style={{ pointerEvents: 'none' }} />
                    <Avatar name={empName} size={28} />
                    <div style={{ lineHeight: 1.3, flex: 1 }}>
                      <div style={{ fontSize: '13px', fontWeight: checked ? 600 : 400 }}>{empName}</div>
                      {emp.designation && (
                        <div style={{ fontSize: '11px', color: '#6c757d' }}>{emp.designation}</div>
                      )}
                    </div>
                    {conflict && (
                      <span title={`Shift overlap on ${conflict.date}`}
                        style={{ fontSize: '9px', background: '#fd7e14', color: '#fff',
                          borderRadius: 4, padding: '2px 5px', fontWeight: 600, flexShrink: 0 }}>
                        ⚠ Conflict
                      </span>
                    )}
                  </div>
                )
              })
          }
        </div>
        {selEmps.length === 0 && (
          <div className="text-danger mt-1" style={{ fontSize: '11px' }}>
            Please select at least one employee
          </div>
        )}
      </Form.Group>

      {/* Remark */}
      <Form.Group className="mb-3">
        <FormLabel style={{ fontSize: '13px', fontWeight: 600 }}>Remark</FormLabel>
        <FormControl as="textarea" rows={2} size="sm"
          placeholder="Add a remark (optional)"
          value={remark} onChange={e => setRemark(e.target.value)}
          style={{ fontSize: '13px', resize: 'none' }} />
      </Form.Group>
    </div>

    {/* ── RIGHT COLUMN ── */}
    <div style={{ flex: '0 0 45%', padding: '20px', background: '#f8f9fa', overflowY: 'auto' }}>
      <div style={{ fontSize: '13px', fontWeight: 700, marginBottom: 12, color: '#212529' }}>
        Assignment Preview
      </div>

      {selEmps.length === 0 ? (
        <div style={{ textAlign: 'center', color: '#adb5bd', marginTop: 60 }}>
          <Icon icon="mdi:account-group-outline" width={40} style={{ display: 'block', margin: '0 auto 8px' }} />
          <div style={{ fontSize: '12px' }}>Select employees to preview assignment</div>
        </div>
      ) : (
        <>
          {/* Summary strip */}
          <div style={{
            background: '#fff', borderRadius: 8, padding: '10px 14px',
            marginBottom: 12, border: '1px solid #dee2e6',
            display: 'flex', gap: 16, flexWrap: 'wrap',
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#0d6efd' }}>{selEmps.length}</div>
              <div style={{ fontSize: '10px', color: '#6c757d' }}>Employees</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#198754' }}>{selectedDates.length}</div>
              <div style={{ fontSize: '10px', color: '#6c757d' }}>Days</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#6610f2' }}>
                {selEmps.length * selectedDates.length}
              </div>
              <div style={{ fontSize: '10px', color: '#6c757d' }}>Total Slots</div>
            </div>
            {shift && shifts.find(s => s.id === Number(shift)) && (
              <div style={{ flex: 1, textAlign: 'right' }}>
                <span style={{
                  background: shiftColorMap[shift], color: '#fff',
                  borderRadius: 6, fontSize: '11px', padding: '3px 10px', fontWeight: 600,
                }}>
                  {shifts.find(s => s.id === Number(shift))?.shift_name}
                </span>
                <div style={{ fontSize: '10px', color: '#6c757d', marginTop: 3 }}>
                  {String(shifts.find(s => s.id === Number(shift))?.shift_in_time || '').slice(0,5)}
                  {' – '}
                  {String(shifts.find(s => s.id === Number(shift))?.shift_out_time || '').slice(0,5)}
                </div>
              </div>
            )}
          </div>

          {/* Employee cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {selEmps.map(empId => {
              const emp      = employees.find(e => e.employee_id === empId)
              const empName  = emp?.name || 'Unknown'
              const conflict = shift && selectedDates.length > 0
                ? hasShiftConflict(empId, shift, selectedDates)
                : false

              // Count days this employee already has a roster entry in selected dates
              const alreadyAssigned = selectedDates.filter(d => roster[empId]?.[toKey(d)])
              const isUpdate        = alreadyAssigned.length > 0

              return (
                <div key={empId} style={{
                  background: '#fff', borderRadius: 8, padding: '10px 12px',
                  border: `1px solid ${conflict ? '#fd7e14' : isUpdate ? '#ffc107' : '#dee2e6'}`,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <Avatar name={empName} size={24} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '13px', fontWeight: 600 }}>{empName}</div>
                      {emp?.designation && (
                        <div style={{ fontSize: '10px', color: '#6c757d' }}>{emp.designation}</div>
                      )}
                    </div>
                    <button
                      onClick={() => toggleEmp(empId)}
                      style={{ background: 'none', border: 'none', color: '#dc3545',
                        cursor: 'pointer', fontSize: '16px', lineHeight: 1, padding: 0 }}
                      title="Remove">×</button>
                  </div>

                  {/* Per-date breakdown */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    {selectedDates.slice(0, 5).map(d => {
                      const key          = toKey(d)
                      const existing     = roster[empId]?.[key]
                      const existShift   = existing ? shifts.find(s => s.id === existing.shift_id) : null
                      const dayConflict  = shift && existShift && existShift.id !== Number(shift)
                        ? hasShiftConflict(empId, shift, [d])
                        : false

                      return (
                        <div key={key} style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          fontSize: '11px', padding: '2px 6px', borderRadius: 4,
                          background: dayConflict ? '#fff3e0' : existing ? '#e8f4fd' : '#f8f9fa',
                        }}>
                          <span style={{ color: '#495057' }}>
                            {d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', weekday: 'short' })}
                          </span>
                          <span>
                            {dayConflict
                              ? <span style={{ color: '#fd7e14', fontWeight: 600 }}>⚠ Overlap with {existShift?.shift_name}</span>
                              : existShift
                              ? <span style={{ color: '#0d6efd', fontWeight: 600 }}>Update: {existShift.shift_name} → new</span>
                              : <span style={{ color: '#198754' }}>New</span>
                            }
                          </span>
                        </div>
                      )
                    })}
                    {selectedDates.length > 5 && (
                      <div style={{ fontSize: '10px', color: '#6c757d', textAlign: 'center', padding: '2px 0' }}>
                        +{selectedDates.length - 5} more days
                      </div>
                    )}
                  </div>

                  {conflict && (
                    <div style={{
                      marginTop: 6, fontSize: '11px', color: '#fd7e14',
                      background: '#fff3e0', borderRadius: 4, padding: '4px 8px',
                    }}>
                     {`⚠ Shift overlap on ${conflict.date} with "${conflict.existingShift.shift_name}"`}
                    </div>
                  )}
                  {!conflict && isUpdate && (
                    <div style={{
                      marginTop: 6, fontSize: '11px', color: '#856404',
                      background: '#fff9e6', borderRadius: 4, padding: '4px 8px',
                    }}>
                      ℹ {alreadyAssigned.length} day(s) will be updated
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>

  </div>
</Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}
            style={{ borderRadius: '15px', padding: '0.3rem 0.7rem', fontSize: '13px' }}>
            Close
          </Button>
        
          <Button className="bg-primary border-primary d-flex align-items-center gap-1"
            onClick={handleSave}
            disabled={
              saving ||
              selEmps.length === 0 ||
              !shift ||
              // disable if ANY selected employee has a conflict
              selEmps.some(id => shift && selectedDates.length > 0 && hasShiftConflict(id, shift, selectedDates))
            }
            style={{ borderRadius: '15px', padding: '0.3rem 0.8rem', fontSize: '13px' }}>
            <Icon icon="mdi:check" width={15} />
            {saving
              ? 'Saving...'
              : `Save${selectedDates.length > 1 ? ` (${selectedDates.length} days)` : ''}`}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default ShiftRoster