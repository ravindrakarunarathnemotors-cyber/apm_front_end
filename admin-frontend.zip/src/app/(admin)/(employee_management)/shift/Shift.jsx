'use client'

import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import Swal from 'sweetalert2'
import { Button, Col, Form, FormControl, FormLabel, Row, Modal, Table, Spinner } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { Icon } from '@iconify/react/dist/iconify.js'
import { useGetShiftsQuery, useCreateShiftMutation, useUpdateShiftMutation } from '@/store/features/emsSlice'
import { UnsavedChangesModal } from '@/components/UnsavedChangesModal'

const Shift = () => {
  const [queryParams, setQueryParams] = useState({})
  const { data: shifts = [], isLoading: isLoadingShifts, refetch } = useGetShiftsQuery(queryParams)
  const [createShift, { isLoading: isCreatingShift }] = useCreateShiftMutation()
  const [updateShift, { isLoading: isUpdatingShift }]  = useUpdateShiftMutation()

  const [show, setShow] = useState(false)
  const [editMode, setEditMode] = useState(false)
  const [selectedShift, setSelectedShift] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [viewShiftId, setViewShiftId] = useState(null)
  const viewShift = shifts.find(s => s.id === viewShiftId) ?? null


  const [searchKeyword, setSearchKeyword] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [showUnsavedModal, setShowUnsavedModal] = useState(false)
  


 const daysObj = {
  monday:    { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  tuesday:   { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  wednesday: { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  thursday:  { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  friday:    { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  saturday:  { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
  sunday:    { enabled: false, inTime: '09:00', outTime: '17:00', nextDay: false },
}

  const schema = yup.object({
    name: yup.string().matches(/^[A-Za-z\s]+$/, 'Shift name can only contain letters and spaces').required('Shift name is required'),
    gracePeriod: yup.number().typeError('Late mark time must be a number').min(0).required('Late mark time is required'),
    earlyOT: yup.number().typeError('Early OT must be a number').min(0).required('Early OT is required'),
    afterOT: yup.number().typeError('After OT must be a number').min(0).required('After OT is required'),
    maxOT: yup.number().typeError('Max OT must be a number').min(0).required('Max OT is required'),
    holidayOT: yup.number().typeError('Holiday OT must be a number').min(0).required('Holiday OT is required'),
  })

  const { register, handleSubmit, formState: { errors, isDirty }, reset, setValue, watch } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
    defaultValues: {
      name: '',
      gracePeriod: '',
      earlyOT: '',
      afterOT: '',
      maxOT: '',
      holidayOT: '',
      days: daysObj
    }
  })

  const handleClose = () => {
    setShow(false)
    setEditMode(false)
    setSelectedShift(null)
  
    reset({ days: daysObj })
  }

  const handleSafeClose = () => {
  if (isDirty) {
    setShowUnsavedModal(true)
  } else {
    handleClose()
  }
}

  const handleShow = () => {
    setEditMode(false)
    setSelectedShift(null)
    reset({ days: daysObj })
    setShow(true)
  }

const handleEdit = (shift) => {
  setEditMode(true);
  setSelectedShift(shift);

  const activeDays = (shift.weekday || '').split(', ');
  const updatedDays = {};

  Object.keys(daysObj).forEach(key => {
    updatedDays[key] = {
      enabled: activeDays.map(d => d.trim().toLowerCase()).includes(key),
      inTime: activeDays.map(d => d.trim().toLowerCase()).includes(key) ? shift.shift_in_time : '09:00',
      outTime: activeDays.map(d => d.trim().toLowerCase()).includes(key) ? shift.shift_out_time : '17:00',
      nextDay: shift.is_next_day ?? false,  // ← new field
    };
  });

  reset({
    name: shift.shift_name,
    gracePeriod: shift.grace_period_minutes,
    earlyOT: shift.early_ot_minutes,
    afterOT: shift.after_ot_minutes,
    maxOT: shift.max_ot_minutes,
    holidayOT: shift.holiday_ot_minutes,
    days: updatedDays,
  });

  setShow(true);
};

  const OnSubmit = async (data) => {
    const enabledDays = Object.entries(data.days || {})
      .filter(([_, dayData]) => dayData.enabled)
      .map(([day, dayData]) => ({
        weekday: day.charAt(0).toUpperCase() + day.slice(1),
        inTime: dayData.inTime || '09:00',
        outTime: dayData.outTime || '17:00',
        nextDay: dayData.nextDay ?? false,  
      }))

    if (enabledDays.length === 0) {
      Swal.fire({ icon: 'warning', title: 'Validation', text: 'Please select at least one weekday' })
      return
    }

    try {
      if (editMode && selectedShift) {
        const day = enabledDays[0]
        const payload = {
          shift_name: data.name,
          weekday: day.weekday,
          shift_in_time: day.inTime,
          shift_out_time: day.outTime,
          is_next_day: day.nextDay,   
          grace_period_minutes: parseInt(data.gracePeriod) || 0,
          early_ot_minutes: parseInt(data.earlyOT) || 0,
          after_ot_minutes: parseInt(data.afterOT) || 0,
          max_ot_minutes: parseInt(data.maxOT) || 0,
          holiday_ot_minutes: parseInt(data.holidayOT) || 0
        }
         await updateShift({ id: selectedShift.id, ...payload }).unwrap()

      
        Swal.fire({ icon: 'success', title: 'Shift updated successfully!', toast: true, timer: 2000, position: 'top-end', showConfirmButton: false })
      } else {
        // Construct the payload with the array of selected weekdays
        const payload = {
          shift_name: data.name,
          days: enabledDays, // Send the entire array
          grace_period_minutes: parseInt(data.gracePeriod) || 0,
          early_ot_minutes: parseInt(data.earlyOT) || 0,
          after_ot_minutes: parseInt(data.afterOT) || 0,
          max_ot_minutes: parseInt(data.maxOT) || 0,
          holiday_ot_minutes: parseInt(data.holidayOT) || 0
        }
        
        await createShift(payload).unwrap()
        Swal.fire({ icon: 'success', title: 'Shift created successfully!', toast: true, timer: 2000, position: 'top-end', showConfirmButton: false })
      }
      handleClose()
      refetch()
    } catch (err) {
      console.error('RTK Error:', err)
      Swal.fire({ icon: 'error', title: 'Error', text: err?.data?.message || 'Failed to save shift' })
    }
  }

  const totalEntries = shifts.length
  const totalPages = Math.max(1, Math.ceil(totalEntries / limit))
  const paginatedShifts = shifts.slice((currentPage - 1) * limit, currentPage * limit)

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  return (
    <>
      <Row>
        <Col>
          <ComponentContainerCard title={<div className="d-flex justify-content-between align-items-center w-100">Shift Management</div>}>
            <Row className="justify-content-end align-items-center g-2 py-3">
            <Col md={4}>
              <FormControl
                type="text"
                placeholder="Search shifts..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                  onKeyDown={(e) => {
                  if (e.key === 'Enter') { setCurrentPage(1); setQueryParams({ keyword: searchKeyword }) }
                }}
              />
            </Col>
            <Col xs="auto">
              <Button
                variant="primary"
                className="d-flex align-items-center gap-1"
                onClick={() => { setCurrentPage(1); setQueryParams({ keyword: searchKeyword }) }}
              >
                <Icon icon="material-symbols:search" width="20" />
                Search
              </Button>
            </Col>
            <Col xs="auto">
              <Button variant="success" onClick={handleShow} className="d-flex align-items-center gap-1">
                <Icon icon="material-symbols:add" width="20" />
                Add Shift
              </Button>
            </Col>
          </Row>

            <div>
              <Table>
                <thead className="bg-light">
                  <tr>
                    <th>Shift name</th>
                    <th>In time</th>
                    <th>Out time</th>
                    <th>Late mark (min)</th>
                    <th>Early OT (min)</th>
                    <th>After OT (min)</th>
                    <th>Max OT (min)</th>
                    <th>Holiday OT (min)</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoadingShifts ? (
                    <tr><td colSpan="9" className="text-center py-4">Loading shifts...</td></tr>
                  ) : paginatedShifts.length > 0 ? (
                    paginatedShifts.map((shift, index) => (
                      <tr key={index}>
                        <td>{shift.shift_name}</td>
                        <td>{shift.shift_in_time}</td>
                        <td>{shift.shift_out_time}</td>
                        <td>{shift.grace_period_minutes}</td>
                        <td>{shift.early_ot_minutes}</td>
                        <td>{shift.after_ot_minutes}</td>
                        <td>{shift.max_ot_minutes}</td>
                        <td>{shift.holiday_ot_minutes}</td>
                        <td>
                          <div className="d-flex align-items-center gap-2">
                            <div className="d-flex align-items-center gap-2">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#007bff',
                                borderColor: '#007bff',
                                color: '#fff',
                              }}
                              onClick={() => { setViewShiftId(shift.id); setShowViewModal(true) }}

                            >
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              View
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#fd7e14',
                                borderColor: '#fd7e14',
                                color: '#fff',
                              }}
                              onClick={() => handleEdit(shift)}
                            >
                              <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                              Edit
                            </Button>
                          </div>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr><td colSpan="9" className="text-center py-4">No shifts found.</td></tr>
                  )}
                </tbody>
              </Table>
            </div>
             <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalEntries={totalEntries}
              limit={limit}
              onPageChange={handlePageChange}
              onLimitChange={(newLimit) => {
                setLimit(newLimit)
                setCurrentPage(1)
              }}
              showingFrom={paginatedShifts.length === 0 ? 0 : (currentPage - 1) * limit + 1}
              showingTo={paginatedShifts.length === 0 ? 0 : (currentPage - 1) * limit + paginatedShifts.length}
            />
          </ComponentContainerCard>
        </Col>
      </Row>

      <Modal show={show} onHide={handleSafeClose} size="lg" centered backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>{editMode ? 'Edit Shift' : 'Add New Shift'}</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit(OnSubmit)}>
          <Modal.Body>
            <h6 className="fw-bold text-primary mb-3">Shift Information</h6>
            <Row className="mb-3">
              <Col md={12}>
                <FormLabel>Shift Name</FormLabel>
                <FormControl type="text" {...register('name')} isInvalid={!!errors.name} placeholder="e.g. Morning Shift" />
                <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
              </Col>
            </Row>

            <hr />
            <h6 className="fw-bold text-primary mb-3">Weekday Scheduling</h6>
            <div className="border rounded p-3 bg-light">
              <Row className="mb-2 d-none d-md-flex text-secondary fw-bold small">
                <Col md={4}>Weekday</Col><Col md={4}>Shift-In</Col><Col md={4}>Shift-Out</Col> <Col md={5}>Next Day Out</Col>
              </Row>
              {Object.keys(daysObj).map((dayKey) => {
              const dayLabel = dayKey.charAt(0).toUpperCase() + dayKey.slice(1)
              const isEnabled = watch(`days.${dayKey}.enabled`)
              const inTime = watch(`days.${dayKey}.inTime`)
              const outTime = watch(`days.${dayKey}.outTime`)

              // Detect if out < in (crosses midnight) to auto-hint
              const crossesMidnight = inTime && outTime && outTime <= inTime

              return (
                <Row key={dayKey} className="align-items-center my-2 g-2 bg-white p-2 rounded border-bottom">
                  {/* Day checkbox */}
                  <Col md={3} xs={12}>
                    <Form.Check
                      type="checkbox"
                      label={dayLabel}
                      {...register(`days.${dayKey}.enabled`)}
                    />
                  </Col>

                  {/* Shift-In */}
                  <Col md={2} xs={5}>
                    <FormControl
                      type="time"
                      size="sm"
                      {...register(`days.${dayKey}.inTime`)}
                      disabled={!isEnabled}
                    />
                  </Col>

                  {/* Shift-Out */}
                  <Col md={2} xs={5}>
                    <FormControl
                      type="time"
                      size="sm"
                      {...register(`days.${dayKey}.outTime`)}
                      disabled={!isEnabled}
                    />
                  </Col>

                  {/* Next Day toggle */}
                  <Col md={5} xs={12}>
                    <div className="d-flex align-items-center gap-2">
                      <Form.Check
                        type="checkbox"
                        id={`nextDay-${dayKey}`}
                        {...register(`days.${dayKey}.nextDay`)}
                        disabled={!isEnabled}
                      />
                      <FormLabel
                        htmlFor={`nextDay-${dayKey}`}
                        className="mb-0 small"
                        style={{ cursor: isEnabled ? 'pointer' : 'default', color: isEnabled ? 'inherit' : '#aaa' }}
                      >
                        Out on next day
                      </FormLabel>

                      {/* Auto-hint badge when times suggest overnight */}
                      {isEnabled && crossesMidnight && (
                        <span
                          className="badge ms-1"
                          style={{ backgroundColor: '#5f83e7', fontSize: '0.6rem' }}
                          title="Shift-out time is earlier than shift-in — this looks like a night shift"
                        >
                          🌙 Night shift detected
                        </span>
                      )}
                    </div>
                  </Col>
                </Row>
              )
            })}
            </div>

            <hr />
            <h6 className="fw-bold text-primary mb-3">Shift Configuration</h6>
            <Row className="mb-3">
              <Col md={4}><FormLabel>Late Mark Time (min)</FormLabel><FormControl type="number" {...register('gracePeriod')} isInvalid={!!errors.gracePeriod} /></Col>
              <Col md={4}><FormLabel>Early OT (min)</FormLabel><FormControl type="number" {...register('earlyOT')} isInvalid={!!errors.earlyOT} /></Col>
              <Col md={4}><FormLabel>After OT (min)</FormLabel><FormControl type="number" {...register('afterOT')} isInvalid={!!errors.afterOT} /></Col>
            </Row>
            <Row className="mb-3">
              <Col md={4}><FormLabel>Max OT (min)</FormLabel><FormControl type="number" {...register('maxOT')} isInvalid={!!errors.maxOT} /></Col>
              <Col md={4}><FormLabel>Holiday OT (min)</FormLabel><FormControl type="number" {...register('holidayOT')} isInvalid={!!errors.holidayOT} /></Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="outline-secondary" onClick={handleSafeClose} disabled={isCreatingShift || isUpdatingShift}>
              Cancel
            </Button>
            <Button variant="primary" type="submit" disabled={isCreatingShift || isUpdatingShift}>
              {isCreatingShift || isUpdatingShift
                ? <><Spinner animation="border" size="sm" className="me-1" /> Saving…</>
                : 'Save Shift'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

     <Modal
  show={showViewModal}
  onHide={() => { setShowViewModal(false); setViewShiftId(null) }}
  centered
  size="md"
  backdrop={true}
  keyboard={true}
>
  <Modal.Header closeButton>
    <Modal.Title>Shift Details</Modal.Title>
  </Modal.Header>

  <Modal.Body className="p-0">
    {viewShift ? (
      <div className="w-100 overflow-hidden border-0" style={{ backgroundColor: '#f8f9fa' }}>

        {/* ── Coloured top band ── */}
        <div
          className="text-white text-center py-4 position-relative"
          style={{ backgroundColor: '#5f83e7' }}
        >
          {/* Shift In badge – top-left */}
          <span style={{
            backgroundColor: '#020c07cc',
            color: 'white',
            padding: '4px 10px',
            borderRadius: '12px',
            fontSize: '0.6rem',
            position: 'absolute',
            top: 10,
            left: 10,
          }}>
            In: {viewShift.shift_in_time}
          </span>

          {/* Shift Out badge – top-right */}
          <span style={{
            backgroundColor: '#020c07cc',
            color: 'white',
            padding: '4px 10px',
            borderRadius: '12px',
            fontSize: '0.6rem',
            position: 'absolute',
            top: 10,
            right: 10,
          }}>
            Out: {viewShift.shift_out_time}
          </span>

          {/* Icon circle */}
          <div
            className="mx-auto mb-2 d-flex align-items-center justify-content-center rounded-circle bg-white"
            style={{ width: 90, height: 90 }}
          >
            <Icon icon="mdi:clock-time-four-outline" width={52} style={{ color: '#5f83e7' }} />
          </div>

          {/* Shift name as title */}
          <h5 className="mb-1 fw-bold">{viewShift.shift_name}</h5>
          <small className="opacity-75" style={{ fontSize: '0.75rem' }}>
            {viewShift.weekday}
          </small>
        </div>

        {/* ── Info rows ── */}
        <div className="px-4 py-3">
          <div className="d-flex flex-column gap-2">

            {/* Timing section */}
            <p className="text-muted small fw-semibold mb-0 text-uppercase" style={{ letterSpacing: '0.05em' }}>
              Timing
            </p>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:clock-in" width={18} className="text-success flex-shrink-0" />
              <span className="text-muted small">Shift In</span>
              <span className="fw-semibold small ms-auto">{viewShift.shift_in_time}</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:clock-out" width={18} className="text-danger flex-shrink-0" />
              <span className="text-muted small">Shift Out</span>
              <span className="fw-semibold small ms-auto">{viewShift.shift_out_time}</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:calendar-week" width={18} className="text-primary flex-shrink-0" />
              <span className="text-muted small">Assigned Day</span>
              <span className="fw-semibold small ms-auto">{viewShift.weekday}</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:weather-night" width={18} className="text-secondary flex-shrink-0" />
              <span className="text-muted small">Out on Next Day</span>
              <span className={`fw-semibold small ms-auto badge ${viewShift.is_next_day ? 'bg-primary' : 'bg-secondary'}`}>
                {viewShift.is_next_day ? 'Yes (crosses midnight)' : 'No'}
              </span>
            </div>

            <hr className="my-1" />

            {/* OT & Grace section */}
            <p className="text-muted small fw-semibold mb-0 text-uppercase" style={{ letterSpacing: '0.05em' }}>
              Overtime & Grace Period
            </p>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:timer-alert-outline" width={18} className="text-warning flex-shrink-0" />
              <span className="text-muted small">Late Mark Grace</span>
              <span className="fw-semibold small ms-auto">{viewShift.grace_period_minutes} min</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:clock-fast" width={18} className="text-info flex-shrink-0" />
              <span className="text-muted small">Early OT</span>
              <span className="fw-semibold small ms-auto">{viewShift.early_ot_minutes} min</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:clock-end" width={18} className="text-info flex-shrink-0" />
              <span className="text-muted small">After OT</span>
              <span className="fw-semibold small ms-auto">{viewShift.after_ot_minutes} min</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:clock-check-outline" width={18} className="text-secondary flex-shrink-0" />
              <span className="text-muted small">Max OT</span>
              <span className="fw-semibold small ms-auto">{viewShift.max_ot_minutes} min</span>
            </div>

            <div className="d-flex align-items-center gap-2">
              <Icon icon="mdi:calendar-star" width={18} className="text-danger flex-shrink-0" />
              <span className="text-muted small">Holiday OT</span>
              <span className="fw-semibold small ms-auto">{viewShift.holiday_ot_minutes} min</span>
            </div>

          </div>
        </div>
      </div>
    ) : (
      <p className="p-3">Loading...</p>
    )}
  </Modal.Body>

  <Modal.Footer>
    <Button variant="secondary" onClick={() => { setShowViewModal(false); setViewShiftId(null) }}>
      Close
    </Button>
  </Modal.Footer>
</Modal>

<UnsavedChangesModal
  show={showUnsavedModal}
  onContinue={() => setShowUnsavedModal(false)}
  onDiscard={() => { setShowUnsavedModal(false); handleClose() }}
/>
    </>
  )
}

export default Shift