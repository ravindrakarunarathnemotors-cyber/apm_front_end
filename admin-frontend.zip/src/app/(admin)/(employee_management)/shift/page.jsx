import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Shift - Employee Management',
}


const Shift = dynamic(() => import('./Shift'), { ssr: false })

export default function ShiftPage() {
  return <Shift />
}