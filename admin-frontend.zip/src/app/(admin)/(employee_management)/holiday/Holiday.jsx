'use client'

import React, { useState, useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'  
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  Button, Col, Form, FormControl, FormLabel, FormSelect, FormGroup,
  Row, Modal, Card, CardHeader, CardBody, CardTitle, Table, Badge, Alert,Spinner
} from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import { Icon } from '@iconify/react/dist/iconify.js'
import { debounce } from 'lodash'
import Select from 'react-select'
import {
  useGetHolidaysQuery,
  useCreateHolidayMutation,
  useUpdateHolidayMutation,
  useGetDepartmentsQuery,
  useGetDesignationsQuery,
  useGetHolidayNamesQuery, 
} from '@/store/features/emsSlice'
import Swal from 'sweetalert2'



const selectStyles = {
  control: (base, state) => ({
    ...base,
    borderColor: state.isFocused ? '#86b7fe' : '#ced4da',
    boxShadow: state.isFocused ? '0 0 0 0.25rem rgba(13,110,253,.25)' : 'none',
    '&:hover': { borderColor: '#86b7fe' },
    minHeight: '38px',
  }),
  multiValue: (base) => ({ ...base, backgroundColor: '#e7f0ff' }),
  multiValueLabel: (base) => ({ ...base, color: '#0d6efd', fontSize: '0.8rem' }),
  multiValueRemove: (base) => ({
    ...base,
    color: '#0d6efd',
    '&:hover': { backgroundColor: '#0d6efd', color: '#fff' },
  }),
}


const schema = yup.object({
  holiday_name:      yup.string().required('Holiday name is required'),
  holiday_date:      yup.string().required('Date is required'),
  holiday_type:      yup.string().required('Holiday type is required'),
  occasion:          yup.string().nullable(),
  employment_status: yup.string().required('Employment status is required'),
  department_ids:    yup.array().nullable(),   
  designation_ids:   yup.array().nullable(),  
})

const EMPTY_FORM = {
  holiday_name:      '',
  holiday_date:      '',
  holiday_type:      '',
  occasion:          '',
  employment_status: '',
  department_ids:    [],
  designation_ids:   [],
}

const HOLIDAY_TYPES = ['Public', 'Optional', 'Restricted', 'Company', 'Government']
const EMPLOYMENT_STATUSES = [
  'PERMANENT', 
  'CONTRACT', 
  'PROBATION',   
  'INTERN', 
  'RESIGNED', 
  'TERMINATED'
]

const typeColor = (type) => {
  const map = { Public: 'primary', Optional: 'info', Restricted: 'warning', Company: 'success', Government: 'secondary' }
  return map[type] || 'secondary'
}


const AddHoliday = () => {

  const [searchParams, setSearchParams] = useState({})
  const [currentPage, setCurrentPage] = useState(1)
  const [limit, setLimit] = useState(10)

  const { data: holidaysData = [], isLoading, refetch } = useGetHolidaysQuery(searchParams)
  const [createHoliday, { isLoading: isCreating }] = useCreateHolidayMutation()
  const [updateHoliday, { isLoading: isUpdating }] = useUpdateHolidayMutation()
  const { data: departmentsData  = [] } = useGetDepartmentsQuery()
  const { data: designationsData = [] } = useGetDesignationsQuery()
  


  const departmentOptions  = departmentsData.map(d => ({ value: d.department_id,   label: d.department_name }))
  const designationOptions = designationsData.map(d => ({ value: d.designation_id, label: d.designation_name }))



 
  const [filterName,   setFilterName]   = useState('')
  const [filterType,   setFilterType]   = useState('')   
  const [dateFrom,     setDateFrom]     = useState('')
  const [dateTo,       setDateTo]       = useState('')
  const [showModal,    setShowModal]    = useState(false)
  const [mode,         setMode]         = useState('create') 
  const [viewData,     setViewData]     = useState(null)
  const [successMsg,   setSuccessMsg]   = useState('')
  const [formKey,      setFormKey]      = useState(0)
  const [searchHoliday,   setSearchHoliday]   = useState('')
  const [selectedKeyword, setSelectedKeyword] = useState('')

    const { data: holidayNameResults = [] } = useGetHolidayNamesQuery(searchHoliday, {
    skip: searchHoliday.length < 2,
  })

  const holidayNameOptions = holidayNameResults.map(h => ({
    label: h.holiday_name,
    value: h.holiday_name,
  }))

  const debouncedHolidaySearch = debounce((value) => {
    setSearchHoliday(value)
  }, 300)

  const { register, handleSubmit, control, formState: { errors }, reset } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
    defaultValues: EMPTY_FORM,
  })


  const deptLabel  = (ids = []) => ids.length === 0 ? 'All'
    : ids.map(id => departmentsData.find(d => d.department_id === id)?.department_name ?? id).join(', ')

  const desigLabel = (ids = []) => ids.length === 0 ? 'All'
    : ids.map(id => designationsData.find(d => d.designation_id === id)?.designation_name ?? id).join(', ')


   const handleSearch = () => {
      setCurrentPage(1)
      setSearchParams({
        ...(filterName.trim()  && { keyword:      filterName.trim() }),
        ...(filterType         && { holiday_type: filterType }),
        ...(dateFrom           && { date_from:    dateFrom }),
        ...(dateTo             && { date_to:      dateTo }),
      })
    }


  const openCreate = () => {
    setMode('create')
    setViewData(null)
    setSuccessMsg('')
    setFormKey(prev => prev + 1)
    setShowModal(true)
  }

  
  const openEdit = (item) => {
    setMode('edit')
    setViewData(item)
    setSuccessMsg('')
    reset({
      holiday_name:      item.holiday_name,
      holiday_date:      item.holiday_date?.split('T')[0] ?? '',
      holiday_type:      item.holiday_type,
      occasion:          item.occasion ?? '',
      employment_status: item.employment_status,
     
      department_ids: (item.department_ids || []).map(id => ({
        value: id,
        label: departmentsData.find(d => d.department_id === id)?.department_name ?? String(id),
      })),
      designation_ids: (item.designation_ids || []).map(id => ({
        value: id,
        label: designationsData.find(d => d.designation_id === id)?.designation_name ?? String(id),
      })),
    })
    setShowModal(true)
  }

  const openView = (item) => {
    setMode('view')
    setViewData(item)
    setShowModal(true)
  }

  const closeModal = () => {
    setShowModal(false)
    setViewData(null)
    setSuccessMsg('')
  }


  const onSubmit = async (data) => {
  try {
    const payload = {
      holiday_date:      data.holiday_date?.trim(),
      holiday_name:      data.holiday_name?.trim(),
      holiday_type:      data.holiday_type?.trim(),
      occasion:          data.occasion?.trim() || null,
      employment_status: data.employment_status?.trim().toUpperCase(),
      department_ids:    (data.department_ids || []).map(d => d.value ?? d),
      designation_ids:   (data.designation_ids || []).map(d => d.value ?? d),
    }

    if (mode === 'edit' && viewData) {
      await updateHoliday({ id: viewData.holiday_id, ...payload }).unwrap()
      Swal.fire({ icon: 'success', title: mode === 'edit' ? 'Holiday updated' : 'Holiday created', toast: true, timer: 2000, position: 'top-end', showConfirmButton: false })
      setSuccessMsg('Holiday updated successfully')
    } else {
      await createHoliday(payload).unwrap()
      setSuccessMsg('Holiday created successfully')
    }

    refetch()
    setTimeout(() => closeModal(), 1200)

  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Error', text: err?.data?.message || 'Failed to save holiday' })
  }
}

  const totalEntries = holidaysData.length
  const totalPages = Math.max(1, Math.ceil(totalEntries / limit))
  const paginatedHolidays = holidaysData.slice((currentPage - 1) * limit, currentPage * limit)

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }
 
  return (
    <>
      {/* ── MAIN CARD ── */}
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center">
            <Col>
              <CardTitle as="h4" style={{ fontSize: '18px' }} className="mb-0">Holidays</CardTitle>
            </Col>
            <Col xs="auto">
              <Button variant="success" onClick={openCreate} style={{ whiteSpace: 'nowrap' }}>
                <Icon icon="mdi:plus" className="me-1" />Add Holiday
              </Button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          {/* ── Filters ── */}
          <Form className="row g-2 mb-3">
            <FormGroup className="col-md-3">
            <FormLabel>Keyword</FormLabel>
            <Select
              options={holidayNameOptions}
              onInputChange={(value, { action }) => {
                if (action === 'input-change') {
                  debouncedHolidaySearch(value)
                  setSelectedKeyword(value)
                  setFilterName(value)
                }
              }}
              onChange={(option) => {
                if (option) {
                  setFilterName(option.value)
                  setSelectedKeyword(option.value)
                  setSearchHoliday(option.value)
                } else {
                  setFilterName('')
                  setSelectedKeyword('')
                  setSearchHoliday('')
                }
              }}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              placeholder="Search by ID or Name"
              isClearable
              isSearchable
              value={selectedKeyword ? { label: selectedKeyword, value: selectedKeyword } : null}
              components={{ DropdownIndicator: null }}
              styles={{
                control: (base, state) => ({
                  ...base,
                  borderRadius: '999px',
                  borderColor: state.isFocused ? '#86b7fe' : '#ced4da',
                  boxShadow: state.isFocused ? '0 0 0 0.25rem rgba(13,110,253,.25)' : 'none',
                  '&:hover': { borderColor: '#86b7fe' },
                  minHeight: '38px',
                }),
              }}
            />
          </FormGroup>

            <FormGroup className="col-md-4">
              <div className="row g-1">
                <div className="col-6">
                  <FormLabel>From Date</FormLabel>
                  <FormControl type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
                </div>
                <div className="col-6">
                  <FormLabel>To Date</FormLabel>
                  <FormControl type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
                </div>
              </div>
            </FormGroup>

            {/* ✅ filter by holiday_type, not a generic "status" */}
            <FormGroup className="col-md-3">
              <FormLabel>Holiday Type</FormLabel>
              <FormSelect value={filterType} onChange={e => setFilterType(e.target.value)}>
                <option value="">All</option>
                {HOLIDAY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </FormSelect>
            </FormGroup>

            <FormGroup className="col-md-2 d-flex align-items-end">
              <Button className="bg-primary border-primary flex-grow-1" onClick={handleSearch}>
                <Icon icon="material-symbols:search-rounded" width="18" height="18" className="me-1" />
                Search
              </Button>
            </FormGroup>
          </Form>

          {/* ── Table ── */}
          <Table striped hover responsive>
            <thead>
              <tr>
                <th>#</th>
                <th>Holiday Name</th>
                <th>Date</th>
                <th>Type</th>
                <th>Occasion</th>
                <th>Employment Status</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan="9" className="text-center py-4">Loading holidays...</td></tr>
              ) : paginatedHolidays.length > 0 ? (
                paginatedHolidays.map((item, idx) => (
                  <tr key={item.holiday_id}>
                    <td>{(currentPage - 1) * limit + idx + 1}</td>
                    <td style={{ textTransform: 'capitalize', fontWeight: 500 }}>{item.holiday_name}</td>
               
                    <td className="small">{item.holiday_date?.split('T')[0]}</td>
                    <td>
                      <Badge bg={typeColor(item.holiday_type)} style={{ fontSize: '0.7rem' }}>
                        {item.holiday_type}
                      </Badge>
                    </td>
                    <td className="small text-muted">{item.occasion || '—'}</td>
          
                    <td className="small">{item.employment_status}</td>
       
                    <td className="small">{deptLabel(item.department_ids)}</td>
                    <td className="small">{desigLabel(item.designation_ids)}</td>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <Button size="sm" className="d-flex align-items-center" onClick={() => openView(item)}
                          style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#007bff', borderColor: '#007bff', color: '#fff' }}>
                          <Icon icon="mdi:eye" width={15} style={{ marginRight: 4 }} />View
                        </Button>
                        <Button size="sm" className="d-flex align-items-center" onClick={() => openEdit(item)}
                          style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#fd7e14', borderColor: '#fd7e14', color: '#fff' }}>
                          <Icon icon="mdi:pencil" width={15} style={{ marginRight: 4 }} />Edit
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="9" className="text-center py-4">No holidays found.</td></tr>
              )}
            </tbody>
          </Table>

          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            totalEntries={totalEntries}
            limit={limit}
            onPageChange={handlePageChange}
            onLimitChange={(newLimit) => {
              setLimit(newLimit)
              setCurrentPage(1)
            }}
            showingFrom={paginatedHolidays.length === 0 ? 0 : (currentPage - 1) * limit + 1}
            showingTo={paginatedHolidays.length === 0 ? 0 : (currentPage - 1) * limit + paginatedHolidays.length}
          />
        </CardBody>
      </Card>

      {/* ── UNIFIED MODAL ── */}
      <Modal show={showModal} onHide={closeModal} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>
            {mode === 'create' ? 'Add Holiday' : mode === 'edit' ? 'Edit Holiday' : 'Holiday Details'}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {successMsg && <Alert variant="success">{successMsg}</Alert>}

          {/* ── VIEW ── */}
          {mode === 'view' && viewData ? (
            <>
              <div
                className="text-white text-center py-4 position-relative rounded mb-3"
                style={{ backgroundColor: '#28a745' }}
              >
                <span style={{ backgroundColor: '#020c07cc', color: 'white', padding: '4px 10px', borderRadius: 12, fontSize: '0.6rem', position: 'absolute', top: 10, right: 10 }}>
                  {viewData.holiday_type}
                </span>
                <div className="mx-auto mb-2 d-flex align-items-center justify-content-center rounded-circle bg-white" style={{ width: 80, height: 80 }}>
                  <Icon icon="mdi:calendar-star" width={46} style={{ color: '#28a745' }} />
                </div>
                <h5 className="mb-1 fw-bold" style={{ textTransform: 'capitalize' }}>{viewData.holiday_name}</h5>
           
                <span className="small text-white opacity-75">{viewData.employment_status}</span>
              </div>

              <div className="d-flex flex-column gap-2 px-1">
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:calendar-month-outline" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Date</span>
           
                  <span className="fw-semibold small ms-auto">{viewData.holiday_date?.split('T')[0]}</span>
                </div>
                <hr className="my-1" />
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:tag-outline" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Holiday Type</span>
                  <span className="ms-auto">
                    <Badge bg={typeColor(viewData.holiday_type)} style={{ fontSize: '0.7rem' }}>
                      {viewData.holiday_type}
                    </Badge>
                  </span>
                </div>
                <hr className="my-1" />
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:text" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Occasion</span>
                  <span className="fw-semibold small ms-auto">{viewData.occasion || '—'}</span>
                </div>
                <hr className="my-1" />
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:briefcase-account-outline" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Employment Status</span>
             
                  <span className="fw-semibold small ms-auto">{viewData.employment_status}</span>
                </div>
                <hr className="my-1" />
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:domain" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Department</span>
               
                  <span className="fw-semibold small ms-auto">{deptLabel(viewData.department_ids)}</span>
                </div>
                <hr className="my-1" />
                <div className="d-flex align-items-center gap-2">
                  <Icon icon="mdi:briefcase-outline" width={18} className="text-muted flex-shrink-0" />
                  <span className="text-muted small">Designation</span>
              
                  <span className="fw-semibold small ms-auto">{desigLabel(viewData.designation_ids)}</span>
                </div>
              </div>
            </>
          ) : (
            /* ── CREATE / EDIT ── */
            <Form id="holiday-form" key={formKey} onSubmit={handleSubmit(onSubmit)}>
              <Row className="g-3">
                <Col md={6}>
                  <FormLabel>Holiday Name <span className="text-danger">*</span></FormLabel>
                  <FormControl type="text" placeholder="e.g. Eid ul Fitr"
                    {...register('holiday_name')} isInvalid={!!errors.holiday_name} />
                  {errors.holiday_name && <p className="text-danger small mb-0">{errors.holiday_name.message}</p>}
                </Col>

          
                <Col md={6}>
                  <FormLabel>Date <span className="text-danger">*</span></FormLabel>
                  <FormControl type="date"
                    {...register('holiday_date')} isInvalid={!!errors.holiday_date} />
                  {errors.holiday_date && <p className="text-danger small mb-0">{errors.holiday_date.message}</p>}
                </Col>

          
                <Col md={6}>
                  <FormLabel>Holiday Type <span className="text-danger">*</span></FormLabel>
                  <FormSelect {...register('holiday_type')} isInvalid={!!errors.holiday_type}>
                    <option value="">Select Type</option>
                    {HOLIDAY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </FormSelect>
                  {errors.holiday_type && <p className="text-danger small mb-0">{errors.holiday_type.message}</p>}
                </Col>

         
                <Col md={6}>
                  <FormLabel>Employment Status <span className="text-danger">*</span></FormLabel>
                  <FormSelect {...register('employment_status')} isInvalid={!!errors.employment_status}>
                    <option value="">Select Status</option>
                    {EMPLOYMENT_STATUSES.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </FormSelect>
                  {errors.employment_status && <p className="text-danger small mb-0">{errors.employment_status.message}</p>}
                </Col>

                <Col md={12}>
                  <FormLabel>Occasion</FormLabel>
                  <FormControl type="text" placeholder="e.g. New Year's Day celebration"
                    {...register('occasion')} />
                </Col>

           
                <Col md={6}>
                  <FormLabel>Departments</FormLabel>
                  <Controller name="department_ids" control={control}
                    render={({ field }) => (
                      <Select {...field} isMulti options={departmentOptions}
                        styles={selectStyles} placeholder="All Departments" />
                    )} />
                </Col>

                <Col md={6}>
                  <FormLabel>Designations</FormLabel>
                  <Controller name="designation_ids" control={control}
                    render={({ field }) => (
                      <Select {...field} isMulti options={designationOptions}
                        styles={selectStyles} placeholder="All Designations" />
                    )} />
                </Col>
              </Row>
            </Form>
          )}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" disabled={isCreating || isUpdating} onClick={closeModal}>Close</Button>
          {mode !== 'view' && (
            <Button type="submit" form="holiday-form" variant="success" disabled={isCreating || isUpdating}>
            {isCreating || isUpdating
              ? <><Spinner animation="border" size="sm" className="me-1" /> Saving…</>
              : mode === 'edit' ? 'Update Holiday' : 'Save Holiday'}
          </Button>
          )}
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default AddHoliday
