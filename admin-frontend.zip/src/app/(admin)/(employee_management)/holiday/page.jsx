import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Holiday - Employee Management',
}


const Holiday = dynamic(() => import('./Holiday'), { ssr: false })

export default function AddDesignationPage() {
  return <Holiday />
}