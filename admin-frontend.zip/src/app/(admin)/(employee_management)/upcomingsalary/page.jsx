import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Upcoming Salary - Employee Management',
}


const UpcomingSalary = dynamic(() => import('./UpcomingSalary'), { ssr: false })

export default function AddDesignationPage() {
  return <UpcomingSalary/>
}