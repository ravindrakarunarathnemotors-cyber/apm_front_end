'use client'

import React, { useState, useMemo } from 'react'
import {
  Row, Col, Card, CardHeader, CardBody, CardTitle,
  Form, FormGroup, FormLabel, Button, Table, Spinner, Badge,
  OverlayTrigger, Tooltip,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import { debounce } from 'lodash'
import {
  useGetAllPaysheetsQuery,
  useGetEmployeenameQuery,
  useGetAllPayrollTemplateDetailsQuery,
  useGetAllEarningsDeductionsQuery,
  useGetDepartmentsQuery,
} from '@/store/features/emsSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Returns the upcoming salary month label, e.g. "May 2026"
 * Based on the latest salary_range_end from any paysheet row.
 */
function getUpcomingMonthLabel(sheets) {
  if (!sheets || sheets.length === 0) {
    const now = new Date()
    const next = new Date(now.getFullYear(), now.getMonth() + 1, 1)
    return next.toLocaleString('en-US', { month: 'long', year: 'numeric' })
  }
  // Find the most recent salary_range_end across all sheets
  const latest = sheets
    .map((s) => s.salary_range_end)
    .filter(Boolean)
    .sort()
    .pop()
  if (!latest) {
    const now = new Date()
    const next = new Date(now.getFullYear(), now.getMonth() + 1, 1)
    return next.toLocaleString('en-US', { month: 'long', year: 'numeric' })
  }
  const d = new Date(latest)
  d.setMonth(d.getMonth() + 1)
  return d.toLocaleString('en-US', { month: 'long', year: 'numeric' })
}

/**
 * Given a salary_range_end date, compute the next salary date (same day next month)
 * with overflow protection (e.g. Jan 31 → Feb 28).
 */
function nextSalaryDate(dateStr) {
  if (!dateStr) return '-'
  const d = new Date(dateStr)
  const targetMonth = d.getMonth() + 1
  const nextDate = new Date(d.getFullYear(), targetMonth, d.getDate())
  // If month overflowed (e.g. Feb 31 → Mar 3), snap back to last day of target month
  if (nextDate.getMonth() !== targetMonth % 12) {
    return new Date(d.getFullYear(), targetMonth + 1, 0).toISOString().split('T')[0]
  }
  return nextDate.toISOString().split('T')[0]
}

/**
 * Safely unwrap RTK responses.
 * Handles: plain array | { data: [] } | { results: [] } | undefined/null
 */
function unwrapArray(raw) {
  if (!raw) return []
  if (Array.isArray(raw)) return raw
  if (Array.isArray(raw.data)) return raw.data
  if (Array.isArray(raw.results)) return raw.results
  return []
}

/**
 * Normalise type strings to 'earning' | 'deduction'
 * Handles: EARNINGS, EARNING, DEDUCTIONS, DEDUCTION (all cases)
 */
function normaliseType(raw) {
  const s = String(raw ?? '').toUpperCase()
  if (s.startsWith('DED')) return 'deduction'
  return 'earning'
}

// ─── Source indicator config ──────────────────────────────────────────────────
// 'actual'   — forecast carried from last paysheet net (no template items found)
// 'template' — forecast built purely from payroll template details
// 'blended'  — template items exist AND last paysheet exists; template used as base
const SOURCE_LABELS = {
  actual:   { label: 'Actual',   bg: 'success', title: 'Carried from last paysheet net' },
  template: { label: 'Template', bg: 'warning',  title: 'Built from payroll template' },
  blended:  { label: 'Blended',  bg: 'info',     title: 'Template items + last paysheet context' },
}

// ─── Component ────────────────────────────────────────────────────────────────

function UpcomingSalaryForecast() {
  const { currency } = useCurrencySymbol()
  const currencySymbol = currency ?? 'LKR'

  // ── Filter state ─────────────────────────────────────────────────────────
  const [keyword, setKeyword]             = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [deptFilter, setDeptFilter]       = useState('')
  const [typeFilter, setTypeFilter]       = useState('')
  const [srcFilter, setSrcFilter]         = useState('')   // NEW: filter by source type
  const [expandedRow, setExpandedRow]     = useState(null)

  // ── Queries ──────────────────────────────────────────────────────────────

  // GET /ems/paysheet — latest paysheet per employee (most recent month)
  const {
    data: paysheetsData,
    isLoading: isLoadingSheets,
    refetch,
  } = useGetAllPaysheetsQuery({ keyword, per_page: 200 })

  // GET /emsp/employeename?search= — name search autocomplete
  const { data: RecipientResults } = useGetEmployeenameQuery(searchKeyword, {
    skip: searchKeyword.length < 2,
  })

  // GET /ems/payroll-template-details
  const {
    data: templateDetailsRaw,
    isLoading: isLoadingTemplates,
  } = useGetAllPayrollTemplateDetailsQuery()

  // GET /ems/earnings-deductions
  const {
    data: earningsDeductionsRaw,
    isLoading: isLoadingED,
  } = useGetAllEarningsDeductionsQuery()

  // GET /ems/departments
  const { data: departmentsRaw } = useGetDepartmentsQuery()

  // Normalise to plain arrays
  const templateDetails    = useMemo(() => unwrapArray(templateDetailsRaw),    [templateDetailsRaw])
  const earningsDeductions = useMemo(() => unwrapArray(earningsDeductionsRaw), [earningsDeductionsRaw])
  const departments        = useMemo(() => unwrapArray(departmentsRaw),        [departmentsRaw])

  const isLoading = isLoadingSheets || isLoadingTemplates || isLoadingED

  // ── Dropdowns ─────────────────────────────────────────────────────────────
  const orderOptions = (RecipientResults ?? []).map((emp) => ({
    label: emp.full_name,
    value: emp.full_name,
  }))

  const debouncedSearch = useMemo(
    () => debounce((val) => setSearchKeyword(val), 300), []
  )

  const deptOptions = useMemo(() => [
    { label: 'All Departments', value: '' },
    ...departments.map((d) => ({
      label: d.department_name || d.name,
      value: String(d.department_id || d.id),
    })),
  ], [departments])

  // ── Deduplicate paysheets — keep only the LATEST per employee ─────────────
  // The API may return multiple paysheets per employee (one per month).
  // For the forecast we only want the most recent one as the "last paysheet".
  const latestSheetPerEmployee = useMemo(() => {
    const map = new Map()
    unwrapArray(paysheetsData).forEach((s) => {
      const existing = map.get(s.employee_id)
      if (!existing) {
        map.set(s.employee_id, s)
      } else {
        // Compare by payroll_year DESC then payroll_month DESC
        const existingOrder = existing.payroll_year * 100 + existing.payroll_month
        const newOrder      = s.payroll_year * 100 + s.payroll_month
        if (newOrder > existingOrder) map.set(s.employee_id, s)
      }
    })
    return Array.from(map.values())
  }, [paysheetsData])

  // ── Apply client-side filters ─────────────────────────────────────────────
  const sheets = useMemo(() => {
    return latestSheetPerEmployee.filter((s) => {
      if (deptFilter && String(s.department_id) !== deptFilter) return false
      if (typeFilter === 'auto'   && (s.paysheet_type || '').toLowerCase() !== 'auto')   return false
      if (typeFilter === 'manual' && (s.paysheet_type || '').toLowerCase() !== 'manual') return false
      return true
    })
  }, [latestSheetPerEmployee, deptFilter, typeFilter])

  // ── Build earnings/deductions lookup map ──────────────────────────────────
  const edMap = useMemo(() => {
    const m = {}
    earningsDeductions.forEach((ed) => {
      // The earnings_deductions table uses `id` as PK (not earning_deduction_id)
      const key = String(ed.id ?? ed.earning_deduction_id ?? '')
      if (key) m[key] = ed
    })
    return m
  }, [earningsDeductions])

  // ── Forecast map ─────────────────────────────────────────────────────────
  //
  // For each employee's latest paysheet, build a forecast for the NEXT month.
  //
  // Join chain:
  //   paysheet.payroll_template_id
  //     → payroll_template_details (filter by payroll_template_id)
  //       → earnings_deductions    (lookup by earning_deduction_id / id)
  //
  // Source logic:
  //   - If template has line items  → use template amounts → source = 'template'
  //   - If template has line items AND last paysheet exists → source = 'blended'
  //     (template is the base but we surface the delta vs last actuals)
  //   - If template has NO items but paysheet has net_salary → carry forward → source = 'actual'
  //
  const forecastMap = useMemo(() => {
    const map = {}

    sheets.forEach((sheet) => {
      const templateId = String(sheet.payroll_template_id ?? '')

      // ── Step 1: resolve template line items ────────────────────────────
      const lineItems = templateDetails.filter(
        (td) => String(td.payroll_template_id) === templateId
      )

      let forecastEarnings   = 0
      let forecastDeductions = 0
      const breakdown        = []

      lineItems.forEach((td) => {
        // The getAllPayrollTemplateDetails query already JOINs earnings_deductions
        // and returns earning_deduction_name, master_type, calculation_type.
        // So we prefer the joined fields first, then fall back to edMap lookup.
        const edKey  = String(td.earning_deduction_id ?? '')
        const master = edMap[edKey]

        // Name resolution priority: joined name > master name > fallback
        const name = td.earning_deduction_name
          ?? master?.name
          ?? td.name
          ?? `Item #${td.earning_deduction_id}`

        // Type resolution: joined master_type > master.type > td.type
        const rawType = td.master_type ?? master?.type ?? td.type ?? td.earning_type ?? ''
        const type    = normaliseType(rawType)

        // Amount resolution:
        //   td.amount — direct fixed amount stored on the template detail (AMOUNT type)
        //   td.value  — percentage value (for PERCENTAGE type, amount=0)
        //   master.amount / master.value — fallback
        const isPercentage = (td.calculation_type === 'PERCENTAGE') ||
          (parseFloat(td.amount) === 0 && parseFloat(td.value) > 0)

        let amount = 0
        if (isPercentage) {
          // Can't compute percentage without knowing the base salary at forecast time.
          // Use value as a direct amount estimate (approximation).
          amount = parseFloat(td.value) || 0
        } else {
          amount = parseFloat(td.amount) || parseFloat(td.value) ||
                   parseFloat(master?.amount) || parseFloat(master?.value) || 0
        }

        if (type === 'deduction') forecastDeductions += amount
        else                      forecastEarnings   += amount

        breakdown.push({ name, type, amount, isPercentage })
      })

      // ── Step 2: determine source and adjust if needed ──────────────────
      const lastNet          = parseFloat(sheet.net_salary      || 0)
      const lastEarnings     = parseFloat(sheet.total_earnings  || 0)
      const lastDeductions   = parseFloat(sheet.total_deductions|| 0)
      const hasTemplateItems = lineItems.length > 0
      const hasLastPaysheet  = lastNet > 0

      let sourceType = 'template'

      if (!hasTemplateItems && hasLastPaysheet) {
        // No template details at all — carry forward last net
        forecastEarnings   = lastEarnings || lastNet
        forecastDeductions = lastDeductions
        sourceType = 'actual'
        if (breakdown.length === 0) {
          breakdown.push({
            name: 'Carried from last paysheet',
            type: 'earning',
            amount: lastNet,
            isPercentage: false,
          })
        }
      } else if (hasTemplateItems && hasLastPaysheet) {
        // Both exist — template is the primary forecast, flag as blended
        sourceType = 'blended'
      }

      const forecastNet = forecastEarnings - forecastDeductions

      // ── Step 3: compute change vs last paysheet ────────────────────────
      const change    = hasLastPaysheet ? forecastNet - lastNet : 0
      const changePct = hasLastPaysheet && lastNet !== 0
        ? (change / lastNet) * 100
        : 0

      // ── Step 4: template name ──────────────────────────────────────────
      const templateName =
        sheet.template_name
        || sheet.payroll_template_name
        || (sheet.payroll_template_id ? `Template #${sheet.payroll_template_id}` : '-')

      map[sheet.employee_id] = {
        forecastEarnings,
        forecastDeductions,
        forecastNet,
        lastNet,
        lastEarnings,
        lastDeductions,
        change,
        changePct,
        sourceType,
        templateName,
        breakdown,
      }
    })

    return map
  }, [sheets, templateDetails, edMap])

  // ── Apply source filter (after forecast is built) ─────────────────────────
  const filteredSheets = useMemo(() => {
    if (!srcFilter) return sheets
    return sheets.filter((s) => forecastMap[s.employee_id]?.sourceType === srcFilter)
  }, [sheets, forecastMap, srcFilter])

  // ── Grand totals ──────────────────────────────────────────────────────────
  const totals = useMemo(() =>
    filteredSheets.reduce(
      (acc, s) => {
        const f = forecastMap[s.employee_id] || {}
        return {
          earnings:   acc.earnings   + (f.forecastEarnings   || 0),
          deductions: acc.deductions + (f.forecastDeductions  || 0),
          net:        acc.net        + (f.forecastNet         || 0),
          lastNet:    acc.lastNet    + (f.lastNet             || 0),
        }
      },
      { earnings: 0, deductions: 0, net: 0, lastNet: 0 }
    )
  , [filteredSheets, forecastMap])

  // ── Upcoming month label ──────────────────────────────────────────────────
  const upcomingMonthLabel = useMemo(
    () => getUpcomingMonthLabel(sheets),
    [sheets]
  )

  // ── Formatter ─────────────────────────────────────────────────────────────
  const fmt = (val) =>
    Number(val || 0).toLocaleString('en-LK', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })

  const selectStyles = {
    control: (base, state) => ({
      ...base,
      borderRadius: '8px',
      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
      minHeight: '38px',
    }),
  }

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <Row className="justify-content-center">
      <Col>
        <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)' }}>

          {/* ── Header ──────────────────────────────────────────────── */}
          <CardHeader className="py-3 bg-light d-flex align-items-center justify-content-between flex-wrap gap-2">
            <div>
              <CardTitle as="h4" className="mb-0">Upcoming Salary Forecast</CardTitle>
              <small className="text-muted">
                Predicted payroll for <strong>{upcomingMonthLabel}</strong>
              </small>
            </div>
            {/* Summary pills */}
            <div className="d-flex gap-2 flex-wrap">
              <span className="badge bg-light border text-dark py-2 px-3" style={{ fontSize: '0.78rem' }}>
                Employees: <strong>{filteredSheets.length}</strong>
              </span>
              <span className="badge bg-success-subtle border border-success text-success py-2 px-3" style={{ fontSize: '0.78rem' }}>
                Earnings: <strong>{currencySymbol} {fmt(totals.earnings)}</strong>
              </span>
              <span className="badge bg-danger-subtle border border-danger text-danger py-2 px-3" style={{ fontSize: '0.78rem' }}>
                Deductions: <strong>{currencySymbol} {fmt(totals.deductions)}</strong>
              </span>
              <span className="badge bg-primary-subtle border border-primary text-primary py-2 px-3" style={{ fontSize: '0.78rem' }}>
                Net Payable: <strong>{currencySymbol} {fmt(totals.net)}</strong>
              </span>
            </div>
          </CardHeader>

          <CardBody>
            {/* ── Filters ──────────────────────────────────────────── */}
            <Form className="row g-2 mb-3 align-items-end">

              {/* Employee search */}
              <FormGroup className="col-md-3 mb-0">
                <FormLabel className="small mb-1">Employee</FormLabel>
                <Select
                  styles={selectStyles}
                  options={orderOptions}
                  placeholder="Search by name..."
                  isClearable
                  isSearchable
                  onInputChange={(val) => debouncedSearch(val)}
                  onChange={(opt) => setKeyword(opt ? opt.label : '')}
                />
              </FormGroup>

              {/* Department */}
              <FormGroup className="col-md-2 mb-0">
                <FormLabel className="small mb-1">Department</FormLabel>
                <Select
                  styles={selectStyles}
                  options={deptOptions}
                  placeholder="All departments"
                  isClearable
                  onChange={(opt) => setDeptFilter(opt ? opt.value : '')}
                />
              </FormGroup>

              {/* Paysheet type */}
              <FormGroup className="col-md-2 mb-0">
                <FormLabel className="small mb-1">Paysheet type</FormLabel>
                <Form.Select
                  size="sm"
                  style={{ height: '38px', borderRadius: '8px' }}
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                >
                  <option value="">All types</option>
                  <option value="auto">Auto</option>
                  <option value="manual">Manual</option>
                </Form.Select>
              </FormGroup>

              {/* Forecast source */}
              <FormGroup className="col-md-2 mb-0">
                <FormLabel className="small mb-1">Forecast source</FormLabel>
                <Form.Select
                  size="sm"
                  style={{ height: '38px', borderRadius: '8px' }}
                  value={srcFilter}
                  onChange={(e) => setSrcFilter(e.target.value)}
                >
                  <option value="">All sources</option>
                  <option value="actual">Actual (last paysheet)</option>
                  <option value="template">Template only</option>
                  <option value="blended">Blended</option>
                </Form.Select>
              </FormGroup>

              <FormGroup className="col-md-3 mb-0 d-flex gap-2">
                <Button
                  className="flex-grow-1"
                  variant="primary"
                  onClick={() => refetch()}
                >
                  <Icon icon="solar:refresh-bold" width={14} className="me-1" />
                  Refresh
                </Button>
              </FormGroup>
            </Form>

            {/* ── Legend ───────────────────────────────────────────── */}
            <div className="d-flex flex-wrap gap-3 mb-3">
              {Object.entries(SOURCE_LABELS).map(([key, cfg]) => (
                <div key={key} className="d-flex align-items-center gap-1" style={{ fontSize: '0.75rem', color: '#6c757d' }}>
                  <Badge bg={cfg.bg} pill style={{ fontSize: '0.65rem' }}>{cfg.label}</Badge>
                  <span>{cfg.title}</span>
                </div>
              ))}
            </div>

            {/* ── Table ────────────────────────────────────────────── */}
            <Table striped bordered hover responsive className="mb-0 align-middle" style={{ fontSize: '0.85rem' }}>
              <thead className="table-light">
                <tr>
                  <th style={{ width: 28 }} />
                  <th>Name</th>
                  <th>Emp ID</th>
                  <th>Department</th>
                  <th>Template</th>
                  <th className="text-center">Type</th>
                  <th className="text-center">Source</th>
                  <th className="text-end">Last Net ({currencySymbol})</th>
                  <th className="text-end">
                    Forecast Net ({currencySymbol})
                    <div style={{ fontSize: '0.65rem', fontWeight: 400, color: '#6c757d' }}>
                      {upcomingMonthLabel}
                    </div>
                  </th>
                  <th className="text-end">Change</th>
                  <th>Next Salary Date</th>
                </tr>
              </thead>

              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan="11" className="text-center py-5" style={{ color: '#6c757d' }}>
                      <Spinner animation="border" size="sm" variant="primary" className="me-2" />
                      Loading forecast data...
                    </td>
                  </tr>
                ) : filteredSheets.length > 0 ? (
                  filteredSheets.map((s) => {
                    const f          = forecastMap[s.employee_id] || {}
                    const isExpanded = expandedRow === s.employee_id
                    const typeIsAuto = (s.paysheet_type || '').toLowerCase() === 'auto'
                    const srcCfg     = SOURCE_LABELS[f.sourceType] || SOURCE_LABELS.template

                    // Change indicator
                    const changeAbs    = f.change ?? 0
                    const changePct    = f.changePct ?? 0
                    const changeUp     = changeAbs > 0.005
                    const changeDown   = changeAbs < -0.005
                    const changeColor  = changeUp ? 'text-success' : changeDown ? 'text-danger' : 'text-muted'
                    const changeIcon   = changeUp
                      ? 'solar:arrow-up-bold'
                      : changeDown
                        ? 'solar:arrow-down-bold'
                        : 'solar:minus-bold'

                    // Department name
                    const deptName = s.department_name
                      || departments.find(
                          (d) => String(d.department_id || d.id) === String(s.department_id)
                        )?.department_name
                      || '-'

                    return (
                      <React.Fragment key={`${s.paysheet_id}-${s.employee_id}`}>
                        <tr
                          style={{ cursor: f.breakdown?.length ? 'pointer' : 'default' }}
                          onClick={() =>
                            f.breakdown?.length &&
                            setExpandedRow(isExpanded ? null : s.employee_id)
                          }
                        >
                          {/* Expand toggle */}
                          <td className="text-center">
                            {f.breakdown?.length > 0 && (
                              <Icon
                                icon={isExpanded
                                  ? 'solar:alt-arrow-down-bold'
                                  : 'solar:alt-arrow-right-bold'}
                                color="#0d6efd"
                                width={13}
                              />
                            )}
                          </td>

                          {/* Name */}
                          <td className="fw-semibold">
                            {s.employee_full_name || s.employee_name || '-'}
                          </td>

                          {/* EMP ID */}
                          <td className="text-muted">
                            EMP-{String(s.employee_id).padStart(4, '0')}
                          </td>

                          {/* Department */}
                          <td>{deptName}</td>

                          {/* Template */}
                          <td style={{ maxWidth: 140 }}>
                            <OverlayTrigger
                              placement="top"
                              overlay={<Tooltip>{f.templateName || 'N/A'}</Tooltip>}
                            >
                              <span style={{
                                display: 'block',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                              }}>
                                {f.templateName || '-'}
                              </span>
                            </OverlayTrigger>
                          </td>

                          {/* Paysheet type badge */}
                          <td className="text-center">
                            <Badge
                              bg={typeIsAuto ? 'success' : 'warning'}
                              text={typeIsAuto ? 'white' : 'dark'}
                              pill
                              style={{ fontSize: '0.65rem' }}
                            >
                              {typeIsAuto ? 'Auto' : 'Manual'}
                            </Badge>
                          </td>

                          {/* Forecast source badge */}
                          <td className="text-center">
                            <OverlayTrigger
                              placement="top"
                              overlay={<Tooltip>{srcCfg.title}</Tooltip>}
                            >
                              <Badge bg={srcCfg.bg} pill style={{ fontSize: '0.65rem' }}>
                                {srcCfg.label}
                              </Badge>
                            </OverlayTrigger>
                          </td>

                          {/* Last net salary */}
                          <td className="text-end text-muted">
                            {f.lastNet > 0 ? fmt(f.lastNet) : '—'}
                          </td>

                          {/* Forecast net salary */}
                          <td className="text-end fw-semibold">
                            {fmt(f.forecastNet)}
                          </td>

                          {/* Change vs last month */}
                          <td className="text-end">
                            {f.lastNet > 0 ? (
                              <span className={changeColor} style={{ fontSize: '0.8rem' }}>
                                <Icon icon={changeIcon} width={12} className="me-1" />
                                {changeAbs === 0 ? '—' : (
                                  <>
                                    {changeAbs > 0 ? '+' : ''}{fmt(changeAbs)}
                                    <span className="ms-1" style={{ fontSize: '0.7rem' }}>
                                      ({changeAbs > 0 ? '+' : ''}{changePct.toFixed(1)}%)
                                    </span>
                                  </>
                                )}
                              </span>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </td>

                          {/* Next salary date */}
                          <td className="text-muted" style={{ fontSize: '0.8rem' }}>
                            {nextSalaryDate(s.salary_range_end)}
                          </td>
                        </tr>

                        {/* ── Expandable breakdown ────────────────────── */}
                        {isExpanded && f.breakdown?.length > 0 && (
                          <tr style={{ background: '#f8fbff' }}>
                            <td colSpan="11" className="px-4 py-2">
                              <div className="mb-1" style={{ fontSize: '0.75rem', color: '#6c757d', fontWeight: 600 }}>
                                Template breakdown (forecast basis):
                              </div>
                              <div className="d-flex flex-wrap gap-1">
                                {f.breakdown.map((item, i) => (
                                  <Badge
                                    key={i}
                                    bg={item.type === 'deduction' ? 'danger' : 'success'}
                                    className="px-2 py-1"
                                    style={{ fontWeight: 500, fontSize: '0.72rem', opacity: 0.88 }}
                                  >
                                    {item.type === 'deduction' ? '−' : '+'} {item.name}:{' '}
                                    {item.isPercentage
                                      ? `${item.amount}%`
                                      : Number(item.amount).toLocaleString('en-LK', {
                                          minimumFractionDigits: 2,
                                          maximumFractionDigits: 2,
                                        })
                                    }
                                  </Badge>
                                ))}
                              </div>
                              {/* Mini totals row */}
                              <div className="d-flex gap-3 mt-2" style={{ fontSize: '0.75rem' }}>
                                <span className="text-success">
                                  Earnings: <strong>{currencySymbol} {fmt(f.forecastEarnings)}</strong>
                                </span>
                                <span className="text-danger">
                                  Deductions: <strong>{currencySymbol} {fmt(f.forecastDeductions)}</strong>
                                </span>
                                <span className="text-primary">
                                  Net: <strong>{currencySymbol} {fmt(f.forecastNet)}</strong>
                                </span>
                                {f.lastNet > 0 && (
                                  <span className="text-muted">
                                    vs last month: <strong>{currencySymbol} {fmt(f.lastNet)}</strong>
                                    {' '}
                                    <span className={changeColor}>
                                      ({changeAbs >= 0 ? '+' : ''}{fmt(changeAbs)})
                                    </span>
                                  </span>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    )
                  })
                ) : (
                  <tr>
                    <td colSpan="11" className="text-center py-4 text-muted">
                      No records found.
                    </td>
                  </tr>
                )}
              </tbody>

              {/* ── Footer totals ──────────────────────────────────── */}
              <tfoot className="table-light" style={{ borderTop: '2px solid #DEE2E6' }}>
                <tr>
                  <td colSpan="7" className="text-end fw-bold py-2 pe-3" style={{ fontSize: '0.85rem' }}>
                    Total ({filteredSheets.length} employees):
                  </td>
                  <td className="text-end text-muted py-2" style={{ fontSize: '0.85rem' }}>
                    {totals.lastNet > 0 ? `${currencySymbol} ${fmt(totals.lastNet)}` : '—'}
                  </td>
                  <td className="text-end fw-bold py-2" style={{ fontSize: '0.95rem', color: 'var(--bs-primary)' }}>
                    {currencySymbol} {fmt(totals.net)}
                  </td>
                  <td className="text-end py-2">
                    {totals.lastNet > 0 && (
                      <span className={
                        totals.net - totals.lastNet > 0 ? 'text-success' :
                        totals.net - totals.lastNet < 0 ? 'text-danger' : 'text-muted'
                      } style={{ fontSize: '0.8rem' }}>
                        {totals.net - totals.lastNet >= 0 ? '+' : ''}
                        {fmt(totals.net - totals.lastNet)}
                      </span>
                    )}
                  </td>
                  <td />
                </tr>
              </tfoot>
            </Table>
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default UpcomingSalaryForecast
