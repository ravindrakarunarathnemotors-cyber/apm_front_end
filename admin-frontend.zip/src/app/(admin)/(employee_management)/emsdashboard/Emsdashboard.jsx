'use client'

import React, { useMemo } from 'react'
import { createPortal } from 'react-dom'
import { useRouter } from 'next/navigation'
import {
  useGetAllEmployeesListQuery,
  useGetAllLeavesQuery,
  useGetDepartmentsQuery,
  useGetHolidaysQuery,
} from '@/store/features/emsSlice'

// ─── Date helpers ─────────────────────────────────────────────────────────────
function toDateStr(d) {
  if (!d) return ''
  return String(d).split('T')[0]
}

function isOnLeaveToday(leave, todayStr) {
  if (leave.status !== 'Approved') return false
  const from = toDateStr(leave.from_date)
  const to   = toDateStr(leave.to_date)
  if (!from || !to) return false
  return todayStr >= from && todayStr <= to
}

function isOnboardedThisMonth(emp, thisYear, thisMonth) {
  if (!emp.joined_date) return false
  const d = new Date(emp.joined_date)
  return d.getFullYear() === thisYear && d.getMonth() === thisMonth
}

// ─── Icons ────────────────────────────────────────────────────────────────────
const Icons = {
  Users: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  UserCheck: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <polyline points="16 11 18 13 22 9"/>
    </svg>
  ),
  Umbrella: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M23 12a11.05 11.05 0 0 0-22 0zm-5 7a3 3 0 0 1-6 0v-7"/>
    </svg>
  ),
  UserPlus: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <line x1="19" y1="8" x2="19" y2="14"/>
      <line x1="22" y1="11" x2="16" y2="11"/>
    </svg>
  ),
  Building: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2"/>
      <path d="M3 9h18"/>
      <path d="M9 21V9"/>
    </svg>
  ),
  Clock: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
    </svg>
  ),
  Calendar: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2"/>
      <line x1="16" y1="2" x2="16" y2="6"/>
      <line x1="8" y1="2" x2="8" y2="6"/>
      <line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  ),
  Briefcase: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="7" width="20" height="14" rx="2"/>
      <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
    </svg>
  ),
  Loader: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
    </svg>
  ),
  Arrow: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: 14, height: 14 }}>
      <line x1="5" y1="12" x2="19" y2="12"/>
      <polyline points="12 5 19 12 12 19"/>
    </svg>
  ),
  Dot: ({ color }) => (
    <span style={{
      display: 'inline-block', width: 8, height: 8,
      borderRadius: '50%', background: color, flexShrink: 0,
    }} />
  ),
}

// ─── Palettes & Colors ────────────────────────────────────────────────────────
const PALETTE = {
  total:      { bg: '#f0f4ff', accent: '#4f6ef7', text: '#3451d1', soft: '#dde4ff' },
  active:     { bg: '#f0fdf4', accent: '#22c55e', text: '#166534', soft: '#dcfce7' },
  onLeave:    { bg: '#fff7ed', accent: '#f97316', text: '#9a3412', soft: '#ffedd5' },
  onboarding: { bg: '#fdf4ff', accent: '#a855f7', text: '#7e22ce', soft: '#f3e8ff' },
}

const DEPT_COLORS = ['#4f6ef7','#22c55e','#f97316','#a855f7','#ec4899','#0ea5e9','#14b8a6','#eab308']

// ─── Shared helpers ───────────────────────────────────────────────────────────
const cardWrap = (borderColor) => ({
  background: '#fff',
  borderRadius: 14,
  boxShadow: '0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.04)',
  border: `1px solid ${borderColor}`,
  overflow: 'hidden',
  height: '100%',
  boxSizing: 'border-box',
})

function CardHeader({ icon: Icon, iconBg, iconColor, title, sub }) {
  return (
    <div style={{
      padding: '13px 18px',
      borderBottom: '1px solid #f3f4f6',
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 9,
        background: iconBg,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: iconColor, flexShrink: 0,
      }}>
        <div style={{ width: 17, height: 17 }}><Icon /></div>
      </div>
      <div>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>{title}</div>
        <div style={{ fontSize: 11, color: '#9ca3af' }}>{sub}</div>
      </div>
    </div>
  )
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ icon: Icon, label, value, sub, palette, loading, badge }) {
  return (
    <div
      style={{
        background: '#fff',
        borderRadius: 14,
        padding: '16px 18px',
        height: '100%',
        boxSizing: 'border-box',
        boxShadow: '0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.04)',
        border: `1px solid ${palette.soft}`,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        transition: 'box-shadow 0.2s, transform 0.2s',
        cursor: 'default',
        position: 'relative',
        overflow: 'hidden',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.boxShadow = `0 4px 20px rgba(0,0,0,0.1), 0 0 0 2px ${palette.soft}`
        e.currentTarget.style.transform = 'translateY(-2px)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.boxShadow = '0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.04)'
        e.currentTarget.style.transform = 'translateY(0)'
      }}
    >
      <div style={{
        position: 'absolute', top: -14, right: -14,
        width: 72, height: 72, borderRadius: '50%',
        background: palette.soft, opacity: 0.4, pointerEvents: 'none',
      }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{
          width: 38, height: 38, borderRadius: 10,
          background: palette.bg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: palette.accent,
        }}>
          <div style={{ width: 19, height: 19 }}><Icon /></div>
        </div>
        {badge != null && (
          <span style={{
            fontSize: 11, fontWeight: 700, letterSpacing: '0.03em',
            background: palette.soft, color: palette.text,
            borderRadius: 20, padding: '3px 10px',
          }}>{badge}</span>
        )}
      </div>
      <div>
        <div style={{
          fontSize: 11, fontWeight: 700,
          color: palette.accent,
          textTransform: 'uppercase',
          letterSpacing: '0.07em',
          marginBottom: 3,
        }}>
          {label}
        </div>
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#9ca3af' }}>
            <div style={{ width: 15, height: 15, animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            <span style={{ fontSize: 12 }}>Loading…</span>
          </div>
        ) : (
          <div style={{ fontSize: 32, fontWeight: 800, color: '#111827', lineHeight: 1, letterSpacing: '-0.03em' }}>
            {value ?? '—'}
          </div>
        )}
        {sub && !loading && (
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>{sub}</div>
        )}
      </div>
    </div>
  )
}

// ─── Pending Leave Card ───────────────────────────────────────────────────────
function PendingLeavesCard({ stats, loading }) {
  return (
    <div style={cardWrap('#fef3c7')}>
      <CardHeader icon={Icons.Clock} iconBg="#fff7ed" iconColor="#f59e0b"
        title="Pending Leave Requests" sub="Awaiting approval" />
      <div style={{
        padding: '16px 18px',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 5,
      }}>
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#9ca3af' }}>
            <div style={{ width: 15, height: 15, animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            <span style={{ fontSize: 12 }}>Loading…</span>
          </div>
        ) : (
          <>
            <div style={{ fontSize: 44, fontWeight: 800, color: '#f59e0b', lineHeight: 1, letterSpacing: '-0.03em' }}>
              {stats.pendingLeaves}
            </div>
            <div style={{ fontSize: 12, color: '#6b7280', fontWeight: 500 }}>requests pending</div>
            <span style={{
              marginTop: 6, fontSize: 11, fontWeight: 700,
              background: '#fef3c7', color: '#92400e',
              borderRadius: 20, padding: '3px 12px',
            }}>Needs Action</span>
          </>
        )}
      </div>
    </div>
  )
}

// ─── Approved Leave Card ──────────────────────────────────────────────────────
function ApprovedLeavesCard({ stats, loading }) {
  return (
    <div style={cardWrap('#d1fae5')}>
      <CardHeader icon={Icons.UserCheck} iconBg="#f0fdf4" iconColor="#22c55e"
        title="Approved Leave Requests" sub="Approved this period" />
      <div style={{
        padding: '16px 18px',
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 5,
      }}>
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#9ca3af' }}>
            <div style={{ width: 15, height: 15, animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            <span style={{ fontSize: 12 }}>Loading…</span>
          </div>
        ) : (
          <>
            <div style={{ fontSize: 44, fontWeight: 800, color: '#22c55e', lineHeight: 1, letterSpacing: '-0.03em' }}>
              {stats.approvedLeaves}
            </div>
            <div style={{ fontSize: 12, color: '#6b7280', fontWeight: 500 }}>requests approved</div>
            <span style={{
              marginTop: 6, fontSize: 11, fontWeight: 700,
              background: '#dcfce7', color: '#166534',
              borderRadius: 20, padding: '3px 12px',
            }}>Approved</span>
          </>
        )}
      </div>
    </div>
  )
}

// ─── Holidays Card ────────────────────────────────────────────────────────────
function HolidaysCard({ holidaysThisMonth, upcomingHolidays, loading }) {
  const monthName = new Date().toLocaleString('default', { month: 'long' })
  return (
    <div style={cardWrap('#dbeafe')}>
      <CardHeader icon={Icons.Calendar} iconBg="#eff6ff" iconColor="#3b82f6"
        title="Holidays"
        sub={`${holidaysThisMonth.length} holiday${holidaysThisMonth.length !== 1 ? 's' : ''} in ${monthName}`} />
      <div style={{ padding: '10px 18px 14px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '18px 0' }}>
            <div style={{ width: 15, height: 15, margin: '0 auto 8px', animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            Loading…
          </div>
        ) : upcomingHolidays.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '18px 0' }}>
            No upcoming holidays
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
            {upcomingHolidays.map((h, i) => {
              const date    = new Date(h.holiday_date)
              const isToday = date.toDateString() === new Date().toDateString()
              const day     = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
              const weekday = date.toLocaleDateString('en-GB', { weekday: 'short' })
              return (
                <div key={h.holiday_id ?? i} style={{
                  display: 'flex', alignItems: 'center', gap: 9,
                  padding: '7px 9px',
                  background: isToday ? '#eff6ff' : '#f9fafb',
                  borderRadius: 9,
                  border: `1px solid ${isToday ? '#bfdbfe' : '#f3f4f6'}`,
                }}>
                  <div style={{
                    minWidth: 36, textAlign: 'center',
                    background: isToday ? '#3b82f6' : '#e5e7eb',
                    borderRadius: 7, padding: '3px 5px', flexShrink: 0,
                  }}>
                    <div style={{ fontSize: 12, fontWeight: 800, color: isToday ? '#fff' : '#111827', lineHeight: 1 }}>
                      {date.getDate()}
                    </div>
                    <div style={{ fontSize: 9, fontWeight: 600, color: isToday ? '#bfdbfe' : '#6b7280', marginTop: 1 }}>
                      {weekday.toUpperCase()}
                    </div>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                      fontSize: 12, fontWeight: 600, color: '#111827',
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                    }}>
                      {h.name ?? h.holiday_name ?? 'Holiday'}
                    </div>
                    <div style={{ fontSize: 10, color: '#6b7280' }}>{day}</div>
                  </div>
                  {isToday && (
                    <span style={{
                      fontSize: 10, fontWeight: 700,
                      background: '#dbeafe', color: '#1d4ed8',
                      borderRadius: 20, padding: '2px 7px', flexShrink: 0,
                    }}>Today</span>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Top Roles Card ───────────────────────────────────────────────────────────
function TopRolesCard({ topRoles, total, loading }) {
  return (
    <div style={cardWrap('#fef3c7')}>
      <CardHeader icon={Icons.Briefcase} iconBg="#fff7ed" iconColor="#f59e0b"
        title="Top Designations" sub="Most common employee roles" />
      <div style={{ padding: '8px 18px 14px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '18px 0' }}>
            <div style={{ width: 15, height: 15, margin: '0 auto 8px', animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            Loading…
          </div>
        ) : topRoles.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '18px 0' }}>No data</div>
        ) : (
          topRoles.map(([role, count], i) => {
            const pct = total > 0 ? Math.round((count / total) * 100) : 0
            return (
              <div key={role} style={{
                padding: '7px 0',
                borderBottom: i < topRoles.length - 1 ? '1px solid #f3f4f6' : 'none',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#111827' }}>{role}</span>
                  <span style={{ fontSize: 11, color: '#6b7280' }}>{count} · {pct}%</span>
                </div>
                <div style={{ height: 4, background: '#f3f4f6', borderRadius: 99 }}>
                  <div style={{
                    height: '100%', width: `${pct}%`,
                    background: DEPT_COLORS[i % DEPT_COLORS.length],
                    borderRadius: 99, transition: 'width 0.8s ease',
                  }} />
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}

// ─── On Leave Members Card ────────────────────────────────────────────────────
function OnLeaveMembersCard({ employees, leaves, todayStr, loading }) {
  const onLeaveToday = useMemo(() => {
    const onLeaveIds = new Set(
      leaves.filter(l => isOnLeaveToday(l, todayStr)).map(l => l.employee_id)
    )
    return employees.filter(e => onLeaveIds.has(e.employee_id))
  }, [employees, leaves, todayStr])

  return (
    <div style={{
      background: '#fff', borderRadius: 14,
      boxShadow: '0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.04)',
      border: '1px solid #ffedd5', overflow: 'hidden', marginBottom: 18,
    }}>
      <div style={{
        padding: '13px 20px', borderBottom: '1px solid #f3f4f6',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 9, background: '#fff7ed',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#f97316',
          }}>
            <div style={{ width: 17, height: 17 }}><Icons.Umbrella /></div>
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>On Leave Today</div>
            <div style={{ fontSize: 11, color: '#9ca3af' }}>
              {loading ? 'Loading…' : `${onLeaveToday.length} member${onLeaveToday.length !== 1 ? 's' : ''} on approved leave`}
            </div>
          </div>
        </div>
        {!loading && onLeaveToday.length > 0 && (
          <span style={{
            fontSize: 11, fontWeight: 700, background: '#ffedd5', color: '#9a3412',
            borderRadius: 20, padding: '3px 10px',
          }}>Live</span>
        )}
      </div>
      <div style={{ padding: '8px 20px 14px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '22px 0', color: '#9ca3af', fontSize: 13 }}>
            <div style={{ width: 18, height: 18, margin: '0 auto 8px', animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
            Loading members…
          </div>
        ) : onLeaveToday.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '22px 0', color: '#9ca3af', fontSize: 13 }}>
            No employees on leave today 🎉
          </div>
        ) : (
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
            gap: 8, paddingTop: 9,
          }}>
            {onLeaveToday.map((emp, i) => (
              <div key={emp.employee_id} style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 10px', background: '#fff7ed',
                borderRadius: 9, border: '1px solid #ffedd5',
              }}>
                <div style={{
                  width: 30, height: 30, borderRadius: '50%',
                  background: DEPT_COLORS[i % DEPT_COLORS.length],
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0,
                }}>
                  {(emp.first_name?.[0] ?? '?').toUpperCase()}
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{
                    fontSize: 12, fontWeight: 600, color: '#111827',
                    whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                  }}>
                    {emp.first_name} {emp.last_name}
                  </div>
                  <div style={{ fontSize: 10, color: '#f97316', fontWeight: 500 }}>
                    {emp.designation ?? emp.department_name ?? 'On Leave'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Department Row ───────────────────────────────────────────────────────────
function DeptRow({ dept, empCount, total, color, rank, onClick }) {
  const pct = total > 0 ? Math.round((empCount / total) * 100) : 0
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '8px 0', borderBottom: '1px solid #f3f4f6',
    }}>
      <div style={{
        width: 28, height: 28, borderRadius: 7,
        background: `${color}18`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 11, fontWeight: 700, color, flexShrink: 0,
      }}>{rank}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12, fontWeight: 600, color: '#111827', marginBottom: 4,
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>
          {dept.department_name}
        </div>
        <div style={{ height: 3, background: '#f3f4f6', borderRadius: 99, overflow: 'hidden' }}>
          <div style={{
            height: '100%', width: `${pct}%`, background: color, borderRadius: 99,
            transition: 'width 0.8s cubic-bezier(0.4,0,0.2,1)',
          }} />
        </div>
      </div>
      <div style={{ flexShrink: 0, textAlign: 'right' }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#111827' }}>{empCount}</div>
        <div style={{ fontSize: 10, color: '#9ca3af' }}>{pct}%</div>
      </div>
      <div
        onClick={onClick}
        style={{
          width: 24, height: 24, borderRadius: 6,
          background: `${color}12`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color, opacity: 0.7, cursor: 'pointer',
          transition: 'opacity 0.15s',
        }}
        onMouseEnter={e => e.currentTarget.style.opacity = '1'}
        onMouseLeave={e => e.currentTarget.style.opacity = '0.7'}
      >
        <Icons.Arrow />
      </div>
    </div>
  )
}

// ─── Department Employees Modal ───────────────────────────────────────────────
function DeptEmployeesModal({ dept, employees, color, onClose }) {
  const deptEmployees = employees.filter(e => e.department_id === dept.department_id)

  if (typeof window === 'undefined') return null

  return createPortal(
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.45)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 20,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#fff', borderRadius: 16, width: '100%', maxWidth: 620,
          maxHeight: '80vh', display: 'flex', flexDirection: 'column',
          boxShadow: '0 8px 40px rgba(0,0,0,0.22)',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div style={{
          padding: '16px 20px', borderBottom: '1px solid #f3f4f6',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 9,
              background: `${color}20`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color,
            }}>
              <div style={{ width: 17, height: 17 }}><Icons.Building /></div>
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>
                {dept.department_name}
              </div>
              <div style={{ fontSize: 11, color: '#9ca3af' }}>
                {deptEmployees.length} employee{deptEmployees.length !== 1 ? 's' : ''}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              border: 'none', background: '#f3f4f6', borderRadius: 8,
              width: 30, height: 30, cursor: 'pointer', fontSize: 18, lineHeight: 1,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#6b7280', flexShrink: 0,
            }}
          >×</button>
        </div>

        {/* Employee List */}
        <div style={{ overflowY: 'auto', padding: '10px 20px 18px', flex: 1 }}>
          {deptEmployees.length === 0 ? (
            <div style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '36px 0' }}>
              No employees in this department
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 8 }}>
              {deptEmployees.map((emp, i) => (
                <div key={emp.employee_id} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: '10px 12px', borderRadius: 10,
                  background: '#f9fafb', border: '1px solid #f3f4f6',
                }}>
                  {/* Avatar */}
                  <div style={{
                    width: 38, height: 38, borderRadius: '50%',
                    background: DEPT_COLORS[i % DEPT_COLORS.length],
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 700, color: '#fff', flexShrink: 0,
                  }}>
                    {(emp.first_name?.[0] ?? '?').toUpperCase()}
                  </div>

                  {/* Name + Designation */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#111827' }}>
                      {emp.first_name} {emp.last_name}
                    </div>
                    <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>
                      {emp.designation_name ?? emp.designation ?? '—'}
                    </div>
                  </div>

                  {/* Shift badge */}
                  <div style={{
                    fontSize: 11, fontWeight: 600,
                    background: emp.shift_name ? '#eff6ff' : '#f3f4f6',
                    color: emp.shift_name ? '#3b82f6' : '#9ca3af',
                    borderRadius: 20, padding: '3px 10px', flexShrink: 0,
                    border: `1px solid ${emp.shift_name ? '#bfdbfe' : '#e5e7eb'}`,
                    whiteSpace: 'nowrap',
                  }}>
                    {emp.shift_name ?? 'No Shift'}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  )
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
const EMSDashboard = () => {
  const router = useRouter()
  const [selectedDept, setSelectedDept] = React.useState(null)

  const { data: allEmployees = [], isLoading: empLoading     } = useGetAllEmployeesListQuery()
  const { data: allLeaves    = [], isLoading: leaveLoading   } = useGetAllLeavesQuery()
  const { data: departments  = [], isLoading: deptLoading    } = useGetDepartmentsQuery()
  const { data: holidays     = [], isLoading: holidayLoading } = useGetHolidaysQuery()

  const today    = useMemo(() => new Date(), [])
  const todayStr = useMemo(() => {
    const y = today.getFullYear()
    const m = String(today.getMonth() + 1).padStart(2, '0')
    const d = String(today.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }, [today])
  const thisYear  = today.getFullYear()
  const thisMonth = today.getMonth()

  const stats = useMemo(() => {
    const total      = allEmployees.length
    const onLeaveIds = new Set(allLeaves.filter(l => isOnLeaveToday(l, todayStr)).map(l => l.employee_id))
    const onLeave    = onLeaveIds.size
    const active     = total - onLeave
    const onboarding = allEmployees.filter(e => isOnboardedThisMonth(e, thisYear, thisMonth)).length

    const deptMap = {}
    allEmployees.forEach(e => {
      const key = e.department_id ?? 'other'
      deptMap[key] = (deptMap[key] || 0) + 1
    })
    const deptsWithCount = departments
      .map(d => ({ ...d, empCount: deptMap[d.department_id] || 0 }))
      .sort((a, b) => b.empCount - a.empCount)

    const pendingLeaves  = allLeaves.filter(l => l.status === 'Pending').length
    const approvedLeaves = allLeaves.filter(l => l.status === 'Approved').length

    const roleMap = {}
    allEmployees.forEach(e => {
      const role = e.designation || e.role || 'Unspecified'
      roleMap[role] = (roleMap[role] || 0) + 1
    })
    const topRoles = Object.entries(roleMap).sort((a, b) => b[1] - a[1]).slice(0, 5)

    const now = new Date()
    const holidaysThisMonth = holidays.filter(h => {
      if (!h.holiday_date) return false
      const d = new Date(h.holiday_date)
      return d.getFullYear() === thisYear && d.getMonth() === thisMonth
    })
    const upcomingHolidays = holidays
      .filter(h => h.holiday_date && new Date(h.holiday_date) >= now)
      .sort((a, b) => new Date(a.holiday_date) - new Date(b.holiday_date))
      .slice(0, 4)

    return {
      total, active, onLeave, onboarding, deptsWithCount,
      pendingLeaves, approvedLeaves, topRoles,
      holidaysThisMonth, upcomingHolidays,
    }
  }, [allEmployees, allLeaves, departments, holidays, todayStr, thisYear, thisMonth])

  const isLoading = empLoading || leaveLoading
  const monthName = today.toLocaleString('default', { month: 'long' })

  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .ems-card { animation: fadeUp 0.35s ease both; }
        .ems-card:nth-child(1) { animation-delay: 0.04s }
        .ems-card:nth-child(2) { animation-delay: 0.08s }
        .ems-card:nth-child(3) { animation-delay: 0.12s }
        .ems-card:nth-child(4) { animation-delay: 0.16s }
      `}</style>

      <div style={{
        fontFamily: '"DM Sans", "Segoe UI", sans-serif',
        padding: '22px 20px',
        background: '#f9fafb',
        minHeight: '100vh',
      }}>

        {/* ── Page Header ── */}
        <div style={{ marginBottom: 20 }}>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#111827', margin: 0, letterSpacing: '-0.02em' }}>
            HR Overview
          </h1>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '3px 0 0' }}>
            {today.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>

        {/* ── Row 1: 4 Stat Cards ── */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 12, marginBottom: 12, alignItems: 'stretch',
        }}>
          <div className="ems-card" onClick={() => router.push('/employee_profile')} style={{ cursor: 'pointer' }}>
            <StatCard
              icon={Icons.Users}
              label="Total Employees"
              value={stats.total}
              sub="Across all departments"
              palette={PALETTE.total}
              loading={isLoading}
            />
          </div>
          <div className="ems-card" onClick={() => router.push('/employee_profile')} style={{ cursor: 'pointer' }}>
            <StatCard
              icon={Icons.UserCheck}
              label="Active Employees"
              value={stats.active}
              sub="Present or working remotely"
              palette={PALETTE.active}
              loading={isLoading}
              badge={stats.total ? `${Math.round((stats.active / stats.total) * 100)}%` : null}
            />
          </div>
          <div className="ems-card" onClick={() => router.push('/leave')} style={{ cursor: 'pointer' }}>
            <StatCard
              icon={Icons.Umbrella}
              label="On Leave Today"
              value={stats.onLeave}
              sub="Approved leave as of today"
              palette={PALETTE.onLeave}
              loading={empLoading || leaveLoading}
              badge={stats.onLeave > 0 ? 'Live' : null}
            />
          </div>
          <div className="ems-card" onClick={() => router.push('/employee_profile')} style={{ cursor: 'pointer' }}>
            <StatCard
              icon={Icons.UserPlus}
              label={`Onboarding · ${monthName}`}
              value={stats.onboarding}
              sub="New joins this month"
              palette={PALETTE.onboarding}
              loading={isLoading}
            />
          </div>
        </div>

        {/* ── Row 2: 4 Cards ── */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 12, marginBottom: 18, alignItems: 'stretch',
        }}>
          <div className="ems-card" onClick={() => router.push('/leave')} style={{ cursor: 'pointer' }}>
            <PendingLeavesCard stats={stats} loading={empLoading || leaveLoading} />
          </div>
          <div className="ems-card" onClick={() => router.push('/leave')} style={{ cursor: 'pointer' }}>
            <ApprovedLeavesCard stats={stats} loading={empLoading || leaveLoading} />
          </div>
          <div className="ems-card" onClick={() => router.push('/holiday')} style={{ cursor: 'pointer' }}>
            <HolidaysCard
              holidaysThisMonth={stats.holidaysThisMonth}
              upcomingHolidays={stats.upcomingHolidays}
              loading={holidayLoading}
            />
          </div>
          <div className="ems-card">
            <TopRolesCard topRoles={stats.topRoles} total={stats.total} loading={isLoading} />
          </div>
        </div>

        {/* ── On Leave Members ── */}
        <OnLeaveMembersCard
          employees={allEmployees}
          leaves={allLeaves}
          todayStr={todayStr}
          loading={empLoading || leaveLoading}
        />

        {/* ── Departments ── */}
        <div style={{
          background: '#fff', borderRadius: 14,
          boxShadow: '0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.04)',
          border: '1px solid #f3f4f6', overflow: 'hidden',
        }}>
          <div style={{
            padding: '13px 20px', borderBottom: '1px solid #f3f4f6',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 9, background: '#f0f4ff',
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4f6ef7',
              }}>
                <div style={{ width: 17, height: 17 }}><Icons.Building /></div>
              </div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>Departments</div>
                <div style={{ fontSize: 11, color: '#9ca3af' }}>
                  {deptLoading ? 'Loading…' : `${departments.length} departments · ${stats.total} employees`}
                </div>
              </div>
            </div>
            {!deptLoading && stats.deptsWithCount.length > 0 && (
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                {stats.deptsWithCount.slice(0, 4).map((d, i) => (
                  <div key={d.department_id} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <Icons.Dot color={DEPT_COLORS[i % DEPT_COLORS.length]} />
                    <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 500 }}>{d.department_name}</span>
                  </div>
                ))}
                {stats.deptsWithCount.length > 4 && (
                  <span style={{ fontSize: 11, color: '#9ca3af' }}>+{stats.deptsWithCount.length - 4} more</span>
                )}
              </div>
            )}
          </div>

          <div style={{ padding: '6px 20px 12px' }}>
            {deptLoading ? (
              <div style={{ textAlign: 'center', padding: '24px 0', color: '#9ca3af', fontSize: 13 }}>
                <div style={{ width: 18, height: 18, margin: '0 auto 8px', animation: 'spin 1s linear infinite' }}><Icons.Loader /></div>
                Loading departments…
              </div>
            ) : stats.deptsWithCount.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '24px 0', color: '#9ca3af', fontSize: 13 }}>
                No departments found
              </div>
            ) : (
              stats.deptsWithCount.map((d, i) => (
                <DeptRow
                  key={d.department_id}
                  dept={d}
                  empCount={d.empCount}
                  total={stats.total}
                  color={DEPT_COLORS[i % DEPT_COLORS.length]}
                  rank={i + 1}
                  onClick={() => setSelectedDept({ dept: d, color: DEPT_COLORS[i % DEPT_COLORS.length] })}
                />
              ))
            )}
          </div>

          {!deptLoading && stats.deptsWithCount.length > 0 && (
            <div style={{
              padding: '8px 20px', background: '#f9fafb', borderTop: '1px solid #f3f4f6',
              display: 'flex', gap: 5, alignItems: 'center', flexWrap: 'wrap',
            }}>
              {stats.deptsWithCount.map((d, i) => {
                const pct = stats.total > 0 ? (d.empCount / stats.total) * 100 : 0
                return (
                  <div key={d.department_id} title={`${d.department_name}: ${d.empCount}`} style={{
                    height: 5, borderRadius: 99,
                    background: DEPT_COLORS[i % DEPT_COLORS.length],
                    width: `${Math.max(pct, 1.5)}%`,
                    transition: 'width 0.8s ease', cursor: 'pointer',
                  }} />
                )
              })}
            </div>
          )}
        </div>

      </div>

      {/* ── Modal renders via portal into document.body ── */}
      {selectedDept && (
        <DeptEmployeesModal
          dept={selectedDept.dept}
          employees={allEmployees}
          color={selectedDept.color}
          onClose={() => setSelectedDept(null)}
        />
      )}
    </>
  )
}

export default EMSDashboard