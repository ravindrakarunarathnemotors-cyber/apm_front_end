import dynamic from 'next/dynamic'

export const metadata = {
  title: 'EMS Dashboard - Employee Management',
}


const EMSDashboard = dynamic(() => import('./Emsdashboard'), { ssr: false })

export default function AddEarningDeductionpage() {
  return <EMSDashboard />
}