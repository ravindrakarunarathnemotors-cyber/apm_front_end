import dynamic from 'next/dynamic'

export const metadata = {
  title: 'PayRoll - Employee Management',
}

const PayRoll = dynamic(() => import('./PayRoll'), { ssr: false })

export default function PayRollPage() {
  return <PayRoll />
}