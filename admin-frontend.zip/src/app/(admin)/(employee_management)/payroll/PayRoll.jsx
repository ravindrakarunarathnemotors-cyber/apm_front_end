'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import {
  Button, Col, Card, CardHeader, CardBody, CardTitle,
  FormControl, FormLabel, FormGroup, FormSelect,
  Row, Modal, Table, Alert, Form, InputGroup, Pagination, Spinner
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import {
  useGetPayrollTemplatesMutation,
  useCreatePayrollTemplateMutation,
  useUpdatePayrollTemplateMutation,
  useGetAllEarningsDeductionsQuery,
  useGetPayrollTemplateDetailsQuery,
  useCreatePayrollTemplateDetailMutation,
  useDeletePayrollTemplateDetailsMutation,

} from '@/store/features/emsSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'
import Select from 'react-select'
import { debounce } from 'lodash'



// ─── AmountCell ───────────────────────────────────────────────────────────────
const AmountCell = ({ value, amountType, onValueChange, onTypeChange, disabled, currency }) => {
  const handleAmountChange = (e) => {
    let val = e.target.value
    if (amountType === 'PERCENTAGE') {
      const numVal = parseFloat(val)
      if (!isNaN(numVal) && numVal > 100) val = '100'
      if (!isNaN(numVal) && numVal < 0) val = '0'
    }
    onValueChange(val)
  }

  return (
    <InputGroup size="sm">
      <FormControl
        type="number"
        min="0"
        max={amountType === 'PERCENTAGE' ? 100 : undefined}
        step={amountType === 'PERCENTAGE' ? '0.01' : '1'}
        placeholder="0.00"
        disabled={disabled}
        value={value ?? ''}
        onChange={handleAmountChange}
        style={{ minWidth: '80px' }}
      />
      <FormSelect
        disabled={disabled}
        value={amountType || currency}
        onChange={(e) => {
          onTypeChange(e.target.value)
          if (e.target.value === 'PERCENTAGE' && parseFloat(value) > 100) {
            onValueChange('100')
          }
        }}
        style={{ maxWidth: '90px', fontSize: '0.78rem' }}
      >
        <option value={currency}>{currency}</option>
        <option value="PERCENTAGE">%</option>
      </FormSelect>
    </InputGroup>
  )
}


// ─── LineItemTable ────────────────────────────────────────────────────────────
const LineItemTable = ({
  title, colorClass, headerClass, rows,
  onCheck, onUpdate, onAdd, addLabel, mode, currency,
}) => (
  <Col md={6}>
    <h6 className={`text-${colorClass} mb-2`}>
      <Icon icon={colorClass === 'success' ? 'mdi:trending-up' : 'mdi:trending-down'} className="me-1" />
      {title}
    </h6>

    <Table bordered size="sm" className="mb-2" style={{ tableLayout: 'fixed' }}>
      <colgroup>
        {mode !== 'view' && <col style={{ width: '42px' }} />}
        <col />
        <col style={{ width: '205px' }} />
      </colgroup>
      <thead className={headerClass}>
        <tr>
          {mode !== 'view' && <th className="text-center">✓</th>}
          <th>Name</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((row) => (
          <tr
            key={row.uid}
            style={{
              opacity: mode !== 'view' && !row.checked ? 0.35 : 1,
              transition: 'opacity 0.15s',
              background: mode !== 'view' && !row.checked ? '#f8f9fa' : undefined,
            }}
          >
            {mode !== 'view' && (
              <td className="text-center align-middle">
                <input
                  type="checkbox"
                  checked={row.checked === true}
                  onChange={(e) => onCheck(row.uid, e.target.checked)}
                  style={{ cursor: 'pointer' }}
                />
              </td>
            )}

            <td className="align-middle">
              <FormControl
                size="sm"
                disabled={mode === 'view' || !row.isCustom}
                value={row.name || ''}
                onChange={(e) => onUpdate(row.uid, 'name', e.target.value)}
              />
            </td>

            <td>
              {mode === 'view' ? (
                <FormControl size="sm" disabled value={row.amount ?? ''} />
              ) : (
                <AmountCell
                  value={row.amount || ''}
                  amountType={row.amountType || currency}
                  disabled={false}
                  onValueChange={(val) => onUpdate(row.uid, 'amount', val)}
                  onTypeChange={(val) => onUpdate(row.uid, 'amountType', val)}
                  currency={currency}
                />
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </Table>

    {mode !== 'view' && (
      <Button size="sm" variant={`outline-${colorClass}`} onClick={onAdd}>
        <Icon icon="mdi:plus" className="me-1" />
        {addLabel}
      </Button>
    )}
  </Col>
)


// ─── Helpers ──────────────────────────────────────────────────────────────────
const genUid = (prefix = 'c') => `${prefix}-${Math.random().toString(36).slice(2, 9)}`
const makeRow = (obj) => ({
  ...obj,
  uid: obj.earning_deduction_id ? `m-${obj.earning_deduction_id}` : genUid(),
})


// ─── Main Component ───────────────────────────────────────────────────────────
const PayrollTemplate = () => {
  const [fetchTemplates, { data: templatesData, isLoading }] = useGetPayrollTemplatesMutation()
  const templates = templatesData?.payroll_templates ?? []

  // masterList kept in case other parts of the page need it
  const { data: masterList = [] } = useGetAllEarningsDeductionsQuery()

  const [createTemplateDetail] = useCreatePayrollTemplateDetailMutation()
  const [deleteTemplateDetails] = useDeletePayrollTemplateDetailsMutation()
  const [createTemplate, { isLoading: saving }] = useCreatePayrollTemplateMutation()
  const [updateTemplate] = useUpdatePayrollTemplateMutation()
  const [keywordSuggestions, setKeywordSuggestions] = useState([])
  const [showSuggestions, setShowSuggestions] = useState(false)


  const [filterName, setFilterName] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  //const [filteredTemplates, setFilteredTemplates] = useState([])
  const [currentPage, setCurrentPage] = useState(1)
  const logsPerPage = 10
  const [searchInput, setSearchInput] = useState('')
  const [templateNameOptions, setTemplateNameOptions] = useState([])


  // ── Modal State ───────────────────────────────────────────────────────────
  const [showModal, setShowModal] = useState(false)
  const [mode, setMode] = useState('create')
  const [viewData, setViewData] = useState(null)
  const [templateName, setTemplateName] = useState('')
  const [payrollType, setPayrollType] = useState('MONTHLY')
  const [successMsg, setSuccessMsg] = useState('')
  const [earnings, setEarnings] = useState([])
  const [deductions, setDeductions] = useState([])
  const [percentageBase, setPercentageBase] = useState('BASIC_SALARY')
  const [otHourRate, setOtHourRate] = useState('')
  const [holidayOtHourRate, setHolidayOtHourRate] = useState('')
  const [noPayDeductionRate, setNoPayDeductionRate] = useState('')
  const [templateStatus, setTemplateStatus] = useState('ACTIVE')

  const { currency } = useCurrencySymbol()

  // ── Ref guard: prevents detail-loading useEffect from re-running on every render ──
  const detailsLoadedRef = useRef(false)

  // ── RTK Query: load details for the selected template (edit mode only) ────
  // NOTE: useGetAllPayrollTemplateDetailsQuery is intentionally NOT used here.
  // That query triggers a re-render after every POST (because it has
  // invalidatesTags: ['PayrollTemplates']), which resets detailsLoadedRef
  // and causes the save loop to fire twice. The per-template query below
  // is sufficient and does not cause this problem.
  const { data: templateDetails = [] } = useGetPayrollTemplateDetailsQuery(
    viewData?.id,
    { skip: !viewData?.id || mode === 'create' }
  )



  // ── Effects ───────────────────────────────────────────────────────────────

  useEffect(() => {
    fetchTemplates({
      page: currentPage,
      limit: logsPerPage,
    })
  }, [currentPage])
  //useEffect(() => { setFilteredTemplates(templates) }, [templates])

  // 3. Load template details into earnings/deductions when editing.
  //    detailsLoadedRef prevents this from re-running when setEarnings/setDeductions
  //    causes a re-render (which would overwrite the user's edits mid-session).
  useEffect(() => {
    if (!showModal || mode !== 'edit') return
    if (!templateDetails || templateDetails.length === 0) return
    if (detailsLoadedRef.current) return  // guard: only load once per modal open

    const belongsToCurrentTemplate = templateDetails.every(
      d => d.payroll_template_id === viewData?.id
    )
    if (!belongsToCurrentTemplate) return

    detailsLoadedRef.current = true  // mark as loaded before calling setters

    setEarnings(
      templateDetails
        .filter(d => d.type === 'EARNINGS')
        .map(d => makeRow({
          earning_deduction_id: d.earning_deduction_id,
          name: d.earning_deduction_name || d.name || '',
          amount: d.calculation_type === 'PERCENTAGE' ? (d.value ? Number(d.value) : '') : (d.amount ?? ''),
          amountType: d.calculation_type === 'PERCENTAGE' ? 'PERCENTAGE' : currency,
          checked: true,
          isCustom: !d.earning_deduction_id,
        }))
    )
    setDeductions(
      templateDetails
        .filter(d => d.type === 'DEDUCTIONS')
        .map(d => makeRow({
          earning_deduction_id: d.earning_deduction_id,
          name: d.earning_deduction_name || d.name || '',
          amount: d.calculation_type === 'PERCENTAGE' ? (d.value ? Number(d.value) : '') : (d.amount ?? ''),
          amountType: d.calculation_type === 'PERCENTAGE' ? 'PERCENTAGE' : currency,
          checked: true,
          isCustom: !d.earning_deduction_id,
        }))
    )
  }, [showModal, mode, templateDetails, viewData?.id])

  // 4. Reset the guard whenever modal opens/closes or switches to a different record.
  //    MUST come AFTER effect #3 so the reset does not clear the guard before
  //    the load effect runs on the same render cycle.
  useEffect(() => {
    detailsLoadedRef.current = false
  }, [showModal, viewData?.id])



  useEffect(() => {
    if (!searchInput || searchInput.length < 1) {
      setTemplateNameOptions([])
      return
    }
    const fetchTemplateNames = async () => {

      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/ems/payrolltemplatename?search=${searchInput}`,
          {
            credentials: 'include',
          }
        )

        if (res.status === 401 || res.status === 403) {
          try {
            await refresh()

            return fetchTemplateNames()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
            return
          }
        }

        const data = await res.json()

        const options = (Array.isArray(data) ? data : []).map((t) => ({
          label: t.name,
          value: t.name,
        }))

        setTemplateNameOptions(options)
      } catch (err) {
        console.error('Template name search error:', err)
      }
    }

    fetchTemplateNames()
  }, [searchInput])



  // ── Search / Filter ───────────────────────────────────────────────────────

  const debouncedSearch = useCallback(
    debounce((value) => setSearchInput(value), 300),
    []
  )
  const handleSearch = () => {
    setCurrentPage(1)

    fetchTemplates({
      page: 1,
      limit: logsPerPage,
      keyword: filterName || undefined,
      from_date: dateFrom || undefined,
      to_date: dateTo || undefined,
      status: filterStatus || undefined,
    })
  }

  //   const totalPages = Math.ceil(filteredTemplates.length / logsPerPage) || 1
  //   const pagedTemplates = filteredTemplates.slice(
  //   (currentPage - 1) * logsPerPage,
  //   currentPage * logsPerPage
  // )

  const totalPages = templatesData?.totalPages || 1

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }


  //   fetchTemplates({
  //     page,
  //     limit: logsPerPage,
  //     keyword: filterName || undefined,
  //     from_date: dateFrom || undefined,
  //     to_date: dateTo || undefined,
  //     status: filterStatus || undefined,
  //   })
  // }
  // ── open modal ────────────────────────────────────────────────────────────
  const openCreate = () => {
    setEarnings(
      masterList
        .filter(item => item.type === 'EARNINGS')
        .map(item => ({
          uid: `m-${item.id}`,
          earning_deduction_id: item.id,
          name: item.name,
          amount: '',
          amountType: item.calculation_type === 'PERCENTAGE' ? 'PERCENTAGE' : currency,
          checked: true,
          isCustom: false,
        }))
    )
    setDeductions(
      masterList
        .filter(item => item.type === 'DEDUCTIONS')
        .map(item => ({
          uid: `m-${item.id}`,
          earning_deduction_id: item.id,
          name: item.name,
          amount: '',
          amountType: item.calculation_type === 'PERCENTAGE' ? 'PERCENTAGE' : currency,
          checked: true,
          isCustom: false,
        }))
    )
    setViewData(null)
    setMode('create')
    setTemplateName('')
    setPayrollType('MONTHLY')
    setSuccessMsg('')
    setPercentageBase('BASIC_SALARY')
    setOtHourRate('')
    setHolidayOtHourRate('')
    setNoPayDeductionRate('')
    setTemplateStatus('ACTIVE') 
    setShowModal(true)
  }
  const openEdit = (row) => {
    setEarnings([])
    setDeductions([])
    setViewData(row)
    setTemplateName(row.name || '')
    setPayrollType(row.payroll_type || 'MONTHLY')
    setPercentageBase(row.percentage_base || 'BASIC_SALARY')
    setOtHourRate(row.ot_hour_rate ?? '')
    setHolidayOtHourRate(row.holiday_ot_hour_rate ?? '')
    setNoPayDeductionRate(row.no_pay_deduction_rate ?? '')
    setTemplateStatus(row.status || 'ACTIVE')
    setMode('edit')
    setSuccessMsg('')
    setShowModal(true)
  }

  // ── Save ──────────────────────────────────────────────────────────────────
  const handleSave = async () => {
    try {
      if (!templateName.trim()) {
        alert('Template Name is required')
        return
      }

      const checkedEarnings = earnings.filter((e) => e.checked)
      const checkedDeductions = deductions.filter((d) => d.checked)

      for (const row of [...checkedEarnings, ...checkedDeductions]) {
        if (row.amount === '' || row.amount === undefined || isNaN(parseFloat(row.amount))) {
          alert(`Please enter a valid amount for: ${row.name || 'a custom row'}`)
          return
        }
        if (row.isCustom && !row.name.trim()) {
          alert('Custom rows must have a name')
          return
        }
        if (!row.isCustom && !row.earning_deduction_id) {
          alert(`Missing master ID for: ${row.name}`)
          return
        }
      }

      let payrollTemplateId

      if (mode === 'create') {
        const createdTemplate = await createTemplate({
          name: templateName.trim(),
          status: templateStatus, 
          payroll_type: payrollType,
          percentage_base: percentageBase,
          ot_hour_rate: otHourRate !== '' ? Number(otHourRate) : 0,
          holiday_ot_hour_rate: holidayOtHourRate !== '' ? Number(holidayOtHourRate) : 0,
          no_pay_deduction_rate: noPayDeductionRate !== '' ? Number(noPayDeductionRate) : 0,
        }).unwrap()

        payrollTemplateId = createdTemplate?.template?.id
        if (!payrollTemplateId) return alert('Failed to create payroll template')

      } else {
        const updated = await updateTemplate({
          id: viewData.id,
          name: templateName.trim(),
          status: templateStatus,
          payroll_type: payrollType,
          percentage_base: percentageBase,
          ot_hour_rate: otHourRate !== '' ? Number(otHourRate) : 0,
          holiday_ot_hour_rate: holidayOtHourRate !== '' ? Number(holidayOtHourRate) : 0,
          no_pay_deduction_rate: noPayDeductionRate !== '' ? Number(noPayDeductionRate) : 0,
        }).unwrap()

        payrollTemplateId = updated?.data?.id ?? updated?.id ?? viewData.id
        if (!payrollTemplateId) return alert('Failed to update payroll template')
      }

      // ── Delete existing details before posting new ones ───────────────────
      // Prevents duplicates on both create and edit.
      // 404 is non-fatal (template had no details yet) so we only warn.
      try {
        await deleteTemplateDetails(payrollTemplateId).unwrap()
      } catch (err) {
      }

      const buildDetailPayload = (row, type) => {
        const base = {
          payroll_template_id: payrollTemplateId,
          type,
          earning_deduction_id: row.isCustom ? null : row.earning_deduction_id,
          name: row.name || '',
        }
        if (row.amountType === 'PERCENTAGE') {
          return { ...base, amount: 0, value: Number(row.amount) }
        }
        return { ...base, amount: Number(row.amount), value: null }
      }

      for (const row of checkedEarnings) {
        try {
          await createTemplateDetail(buildDetailPayload(row, 'EARNINGS')).unwrap()
        } catch (err) {

        }
      }

      for (const row of checkedDeductions) {
        try {
          await createTemplateDetail(buildDetailPayload(row, 'DEDUCTIONS')).unwrap()
        } catch (err) {

        }
      }

      setSuccessMsg(
        mode === 'create'
          ? 'Payroll template created successfully'
          : 'Payroll template updated successfully'
      )
      fetchTemplates({})
      setTimeout(() => setShowModal(false), 1200)

    } catch (err) {
      alert(err?.data?.message || 'Failed to save payroll template')
    }
  }

  // ── Row Updaters ──────────────────────────────────────────────────────────
  const updateEarning = (uid, field, value) =>
    setEarnings((prev) => prev.map((item) => item.uid === uid ? { ...item, [field]: value } : item))

  const updateDeduction = (uid, field, value) =>
    setDeductions((prev) => prev.map((item) => item.uid === uid ? { ...item, [field]: value } : item))

  const checkEarning = (uid, checked) =>
    setEarnings((prev) => prev.map((item) => item.uid === uid ? { ...item, checked } : item))

  const checkDeduction = (uid, checked) =>
    setDeductions((prev) => prev.map((item) => item.uid === uid ? { ...item, checked } : item))

  const addEarning = () => {
    setEarnings((prev) => [
      ...prev,
      {
        uid: genUid(),
        earning_deduction_id: null,
        name: '',
        amount: '',
        amountType: currency,
        checked: true,
        isCustom: true,
      },
    ])
  }

  const addDeduction = () => {
    setDeductions((prev) => [
      ...prev,
      {
        uid: genUid(),
        earning_deduction_id: null,
        name: '',
        amount: '',
        amountType: currency,
        checked: true,
        isCustom: true,
      },
    ])
  }


  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <>
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center">
            <Col>
              <CardTitle as="h4" style={{ fontSize: '18px' }} className="mb-0">
                Payroll Templates
              </CardTitle>
            </Col>
            <Col xs="auto">
              <Button variant="success" onClick={openCreate} style={{ whiteSpace: 'nowrap' }}>
                <Icon icon="mdi:plus" className="me-1" />
                New Template
              </Button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          {/* ── Filters ── */}
          <Form className="row g-1 mb-3">
            <FormGroup className="col-md-3">
              <FormLabel>Keyword</FormLabel>
              <Select
                styles={{
                  control: (base, state) => ({
                    ...base,
                    borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                    boxShadow: state.isFocused
                      ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)'
                      : 'none',
                  }),
                }}
                options={templateNameOptions}
                onInputChange={(value, { action }) => {
                  if (action === 'input-change') {
                    setFilterName(value)
                    debouncedSearch(value)
                  }
                }}
                onChange={(option) => {
                  if (option) {
                    setFilterName(option.value)
                    setSearchInput(option.value)
                    setTemplateNameOptions([])
                  } else {
                    setFilterName('')
                    setSearchInput('')
                    setTemplateNameOptions([])
                  }
                }}
                placeholder="Search by ID or Name"
                isClearable
                isSearchable
                value={filterName ? { label: filterName, value: filterName } : null}
                components={{ DropdownIndicator: null }}
              />
            </FormGroup>

            <FormGroup className="col-md-4">
              <div className="row g-1">
                <div className="col-6">
                  <FormLabel>From Date</FormLabel>
                  <FormControl type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                </div>
                <div className="col-6">
                  <FormLabel>To Date</FormLabel>
                  <FormControl type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                </div>
              </div>
            </FormGroup>

            <FormGroup className="col-md-3">
              <FormLabel>Status</FormLabel>
              <FormSelect value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                <option value="">All</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </FormSelect>
            </FormGroup>

            <FormGroup className="col-md-2 d-flex align-items-end">
              <div className="d-flex w-100 gap-2">

                {/* 🟢 SEARCH BUTTON */}
                <Button
                  variant="primary"
                  className="flex-grow-1"
                  onClick={handleSearch}
                >
                  <Icon icon="material-symbols:search-rounded" width="18" height="18" className="me-1" />
                  Search
                </Button>

                {/* 🟢 RESET BUTTON */}
                <Button
                  variant="secondary"
                  onClick={() => {
                    setFilterName('')
                    setFilterStatus('')
                    setDateFrom('')
                    setDateTo('')
                    setSearchInput('')
                    setTemplateNameOptions([])
                    setCurrentPage(1)

                    fetchTemplates({
                      page: 1,
                      limit: logsPerPage,
                    })
                  }}
                >
                  Reset
                </Button>

              </div>
            </FormGroup>
          </Form>

          {/* ── Table ── */}
          <Table striped hover responsive>
            <thead>
              <tr>
                <th>Template ID</th>
                <th>Name</th>
                <th>Created Date</th>
                <th>Employee Count</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan="6" className="text-center py-4">
                    Loading payroll templates...
                  </td>
                </tr>
              ) : templates.length ? (
                templates.map((t) => (
                  <tr key={t.id}>
                    <td>{t.id}</td>
                    <td>{t.name}</td>
                    <td>{t.created_date ? String(t.created_date).split('T')[0] : '—'}</td>
                    <td>
                      <span className="badge text-dark fs-6">
                        {t.employee_count ?? 0}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`badge bg-${t.status === 'ACTIVE' ? 'success' : 'danger'
                          }`}
                      >
                        {t.status === 'ACTIVE' ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <Button size="sm" variant="primary" onClick={() => openEdit(t)}>
                        Edit
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-center py-4">
                    No payroll templates found
                  </td>
                </tr>
              )}
            </tbody>
          </Table>

          {/* ── Pagination ── */}
          {totalPages > 1 && (
            <div className="d-flex justify-content-end mt-3">
              <Pagination>
                <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                  First
                </Pagination.Item>
                <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                {(() => {
                  let pages = []
                  if (totalPages <= 5) {
                    for (let i = 1; i <= totalPages; i++) {
                      pages.push(
                        <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                          {i}
                        </Pagination.Item>
                      )
                    }
                  } else {
                    let start = currentPage - 2
                    let end = currentPage + 2
                    if (start < 1) { start = 1; end = 5 }
                    if (end > totalPages) { end = totalPages; start = totalPages - 4 }
                    for (let i = start; i <= end; i++) {
                      pages.push(
                        <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                          {i}
                        </Pagination.Item>
                      )
                    }
                  }
                  return pages
                })()}

                <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                  Last
                </Pagination.Item>
              </Pagination>
            </div>
          )}
        </CardBody>
      </Card>

      {/* ── Modal ── */}
      <Modal show={showModal} onHide={() => setShowModal(false)} size="xl" centered>
        <Modal.Header closeButton>
          <Modal.Title>
            {mode === 'create' ? 'Create Payroll Template' : 'Edit Payroll Template'}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {successMsg && <Alert variant="success">{successMsg}</Alert>}

          <Row className="mb-4">
            <Col md={4}>
              <FormLabel>Template Name</FormLabel>
              <FormControl
                placeholder="Enter template name"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
              />
            </Col>
            <Col md={4}>
              <FormLabel>Payroll Type</FormLabel>
              <FormSelect value={payrollType} onChange={(e) => setPayrollType(e.target.value)}>
                <option value="DAILY">Daily</option>
                <option value="WEEKLY">Weekly</option>
                <option value="MONTHLY">Monthly</option>
              </FormSelect>
            </Col>
             <Col md={4}>
              <FormLabel>Status</FormLabel>
              <FormSelect
                value={templateStatus}
                onChange={(e) => setTemplateStatus(e.target.value)}
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </FormSelect>
            </Col>

          </Row>

          <Row className="mb-3">
            <Col md={4}>
              <FormLabel>
                OT Hour Rate <small className="text-muted">{currency}</small>
              </FormLabel>
              <FormControl
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={otHourRate}
                onChange={(e) => setOtHourRate(e.target.value)}
              />
            </Col>
            <Col md={4}>
              <FormLabel>
                Holiday OT Hour Rate <small className="text-muted">{currency}</small>
              </FormLabel>
              <FormControl
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={holidayOtHourRate}
                onChange={(e) => setHolidayOtHourRate(e.target.value)}
              />
            </Col>
            <Col md={4}>
              <FormLabel>
                No Pay Deduction Rate <small className="text-muted">{currency}</small>
              </FormLabel>
              <FormControl
                type="number"
                min="0"
                step="0.01"
                placeholder="0.00"
                value={noPayDeductionRate}
                onChange={(e) => setNoPayDeductionRate(e.target.value)}
              />
            </Col>
          </Row>

          <Row className="g-3">
            <LineItemTable
              title="Earnings"
              colorClass="success"
              headerClass="table-success"
              rows={earnings}
              onCheck={checkEarning}
              onUpdate={updateEarning}
              onAdd={addEarning}
              addLabel="Add Earning"
              mode={mode}
              currency={currency}
            />
            <LineItemTable
              title="Deductions"
              colorClass="danger"
              headerClass="table-danger"
              rows={deductions}
              onCheck={checkDeduction}
              onUpdate={updateDeduction}
              onAdd={addDeduction}
              addLabel="Add Deduction"
              mode={mode}
              currency={currency}
            />
          </Row>

          <Row className="mt-3">
            <Col>
              <FormGroup>
                <Form.Check
                  type="radio"
                  name="percentageBase"
                  id="baseBasic"
                  label="Percentage based on Basic Salary"
                  checked={percentageBase === 'BASIC_SALARY'}
                  onChange={() => setPercentageBase('BASIC_SALARY')}
                />
                <Form.Check
                  type="radio"
                  name="percentageBase"
                  id="baseTotal"
                  label="Percentage based on Total Earnings"
                  checked={percentageBase === 'TOTAL_EARNINGS'}
                  onChange={() => setPercentageBase('TOTAL_EARNINGS')}
                />
              </FormGroup>
            </Col>
          </Row>
        </Modal.Body>

        <Modal.Footer className="justify-content-between">
          <small className="text-muted">System Currency: <b>{currency}</b></small>
          <Button onClick={handleSave} disabled={saving} variant="success">
            {saving
              ? <><Spinner animation="border" size="sm" className="me-1" />{mode === 'create' ? 'Saving…' : 'Updating…'}</>
              : mode === 'create' ? 'Save Payroll Template' : 'Update Payroll Template'}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default PayrollTemplate
