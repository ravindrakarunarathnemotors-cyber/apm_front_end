'use client'

import React, { useState, useEffect, useRef } from 'react'
import { debounce } from 'lodash'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  Button,
  Table,
  Spinner,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'


import { useGetFilteredAllEmpolyeesMutation, useGetEmployeenameQuery } from '@/store/features/emsSlice'
import EmployeeEditModal from '@/components/EmployeeEditModal'
import EmployeeViewModal from '@/components/EmployeeViewModal'

function EmployeDetatils() {
  const router = useRouter() 
  
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })
  const [fetchFilteredEmployees, { isLoading, error }] = useGetFilteredAllEmpolyeesMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [employees, setEmployees] = useState([])
  const logsPerPage = 25
  const [employeName, setEmployeName] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [loading, setLoading] = useState(false)
  const [status, setStatus] = useState('')
  const [searchEmploye, SetSearchEmploye] = useState('')
  const [editEmployee, setEditEmployee] = useState(null)
  const [viewEmployee, setViewEmployee] = useState(null)
  const { data: RecipientResults } = useGetEmployeenameQuery(searchEmploye, {
    skip: searchEmploye.length < 2,
  })

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.full_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    SetSearchEmploye(value)
  }, 300)

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      
      const res = await fetchFilteredEmployees({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        status: status,
        date: date,
        todate: todate,
      }).unwrap()
      setEmployees(res.employees || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)

    } catch (err) {
      console.error('Failed to fetch orders:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) {
      range.push(i)
    }
    return range
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  useEffect(() => {
    fetchLogs(currentPage)
  }, [currentPage])

  return (
    <>
      <Row className="justify-content-center">
        <Col>
          <Card>
            <CardHeader className="py-3 bg-light">
              <Row className="align-items-center justify-content-between">
                <Col>
                  <CardTitle as="h4" className="mb-0">
                    Employee List
                  </CardTitle>
                </Col>
                <Col xs="auto">
                  <Link href="/add_employee" passHref>
                    <Button type="button" className="btn bg-primary border border-primary">
                      <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Add Employee
                    </Button>
                  </Link>
                </Col>
              </Row>
            </CardHeader>

            <CardBody>
              <Form className="row g-1 mb-3">
                <FormGroup className="col-md-3">
                  <FormLabel>Keyword</FormLabel>
                  <Select
                    styles={{
                      control: (base, state) => ({
                        ...base,
                        borderRadius: '999px',
                        borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                        boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                      }),
                    }}
                    options={orderOptions}
                    onInputChange={(value, { action }) => {
                      if (action === 'input-change') {
                        debouncedSearchRecipient(value)
                        SetSearchEmploye(value)
                        setEmployeName(value)
                        setFilters((prev) => ({ ...prev, keyword: value }))
                      }
                    }}
                    onChange={(option) => {
                      if (option) {
                        const name = option.label?.split('(')[0].trim()
                        setEmployeName(name)
                        SetSearchEmploye(name)
                        setFilters((prev) => ({ ...prev, keyword: name }))
                      } else {
                        setEmployeName('')
                        SetSearchEmploye('')
                        setFilters((prev) => ({ ...prev, keyword: '' }))
                      }
                    }}
                    placeholder="ID, Name, Mobile"
                    isClearable
                    isSearchable
                    value={employeName ? { label: employeName, value: employeName } : null}
                    components={{ DropdownIndicator: null }}
                  />
                </FormGroup>

                <FormGroup className="col-md-4">
                  <div className="row g-1">
                    <div className="col-6">
                      <FormLabel>From Date</FormLabel>
                      <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                    </div>
                    <div className="col-6">
                      <FormLabel>To Date</FormLabel>
                      <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                    </div>
                  </div>
                </FormGroup>

                <FormGroup className="col-md-3">
                  <FormLabel>Status</FormLabel>
                  <Form.Select value={status} onChange={(e) => setStatus(e.target.value)}>
                    <option value="">All</option>
                    <option value="CONTRACT">CONTRACT</option>
                    <option value="PROBATION">PROBATION</option>
                    <option value="PERMANENT">PERMANENT</option>
                  </Form.Select>
                </FormGroup>

                <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                  <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                    Search
                  </Button>
                </FormGroup>
              </Form>

              <Table striped bordered hover responsive>
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Job Title</th>
                    <th>NIC</th>
                    <th>Mobile NO</th>
                    <th>Status</th>
                    <th>Department</th>
                    <th>Location</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="10" className="text-center">
                        <Spinner animation="border" size="sm" /> Loading...
                      </td>
                    </tr>
                  ) : employees.length > 0 ? (
                    employees.map((emp) => (
                      <tr key={emp.employee_id}>
                        <td>{emp.employee_id}</td>
                        <td>
                          {emp.joined_date
                            ? new Date(emp.joined_date).toISOString().split('T')[0]
                            : '-'}
                        </td>
                        <td>{emp.first_name} {emp.middle_name} {emp.last_name}</td>
                        <td>{emp.job_specification || '-'}</td>
                        <td>{emp.nic || '-'}</td>
                        <td>{emp.contact_no || '-'}</td>
                        <td>{emp.employment_status}</td>
                        <td>{emp.job_category || '-'}</td>
                        <td>
                          {emp.city ? emp.city.charAt(0).toUpperCase() + emp.city.slice(1) : '-'}
                        </td>
                        <td className="text-end no-print">
                          <div className="d-flex justify-content-end align-items-center gap-2">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#fd7e14',
                                borderColor: '#fd7e14',
                                color: '#fff',
                              }}
                              onClick={() => setEditEmployee(emp)}
                            >
                              <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Edit</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                              }}
                              onClick={() => setViewEmployee(emp)}
                            >
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>View</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="10" className="text-center">
                        No Employees Found
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>

              {totalPages > 1 && (
                <nav aria-label="Page navigation" className="mt-3">
                  <ul className="pagination justify-content-end mb-0">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                      <button className="page-link" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>
                        Previous
                      </button>
                    </li>
                    {getPageWindow(currentPage, totalPages, 5).map((page) => (
                      <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(page)}>
                          {page}
                        </button>
                      </li>
                    ))}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                      <button
                        className="page-link"
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}>
                        Next
                      </button>
                    </li>
                  </ul>
                </nav>
              )}
            </CardBody>
          </Card>
        </Col>
      </Row>

      {editEmployee && (
        <EmployeeEditModal
          employee={editEmployee}
          onClose={() => setEditEmployee(null)}
          onSaved={(updated) => {
            setEmployees(prev =>
              prev.map(e => e.employee_id === updated.employee_id ? { ...e, ...updated } : e)
            )
            setEditEmployee(null)
          }}
        />
      )}

      {viewEmployee && (
        <EmployeeViewModal
          employee={viewEmployee}
          onClose={() => setViewEmployee(null)}
        />
      )}
    </>
  )
}

export default EmployeDetatils