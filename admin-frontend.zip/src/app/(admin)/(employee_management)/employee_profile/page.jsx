'use client'

import React, { useState, useEffect } from 'react'
import { debounce } from 'lodash'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  Row, Col, Card, CardHeader, CardBody, CardTitle,
  Form, FormGroup, FormLabel, Button, Table, Spinner, Badge, Modal,Pagination
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import { useGetFilteredAllEmpolyeesMutation, useGetEmployeenameQuery, useGetDesignationsQuery, useGetDepartmentsQuery, useGetEmployeeByIdQuery } from '@/store/features/emsSlice'
import EmployeeAttendanceTab from '@/components/EmployeeAttendanceTab'
import EmployeeLeavesTab from '@/components/EmployeeLeavesTab'
import EmployeeDocumentsTab from '@/components/EmployeeDocumentsTab'
import EmployeeAppreciationTab from '@/components/EmployeeAppreciationTab'
import EmployeeEmergencyContactTab from '@/components/EmployeeEmergencyContactTab'
import EmployeeEditModal from '@/components/EmployeeEditModal'
import EmployeeLogTab from '@/components/EmployeeLogTab'
import EmployeeDashboardSection from '@/components/EmployeeDashboardTab'
import EmployeePaysheetTab from '@/components/EmployeePaysheetTab'
import EmployeeSettingsTab from '@/components/EmployeeSettingsTab'
import EmployeeIncrementTab from '@/components/EmployeeIncrementTab'


function EmployeeProfileModal({ employee, onClose, onEmployeeUpdate }) {
  // ← default to Dashboard so content loads immediately with no white space
  const [activeTab, setActiveTab] = useState('Dashboard')

  const tabs = [
    { key: 'Dashboard',              label: 'Dashboard'              },
    { key: 'Attendance',             label: 'Attendance'             },
    { key: 'Leaves',                 label: 'Leaves'                 },
    { key: 'Documents',              label: 'Documents'              },
    { key: 'Emergency Contacts',     label: 'Emergency Contacts'     },
    { key: 'Appreciation',           label: 'Appreciation'           },
    { key: 'Increment & Promotions', label: 'Increment & Promotions' },
    { key: 'Employee Log',           label: 'Employee Log'           },
    { key: 'Paysheet',               label: 'Paysheet'               },
    { key: 'Settings',               label: 'Settings'               },
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case 'PERMANENT': return '#198754'
      case 'CONTRACT':  return '#ffc107'
      case 'PROBATION': return '#0dcaf0'
      default:          return '#6c757d'
    }
  }

  const fullName = [employee.first_name, employee.middle_name, employee.last_name]
    .filter(Boolean).join(' ')
  const initials = [employee.first_name, employee.last_name]
    .filter(Boolean).map((n) => n[0]).join('').toUpperCase()

  const InfoRow = ({ icon, label, value }) => (
    <div className="d-flex align-items-start gap-2 mb-3">
      <div style={{
        minWidth: '34px', height: '34px', borderRadius: '8px',
        backgroundColor: 'rgba(var(--bs-primary-rgb), 0.08)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}>
        <Icon icon={icon} width={16} style={{ color: 'var(--bs-primary)' }} />
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: '0.68rem', color: '#9ca3af', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: '1px' }}>
          {label}
        </div>
        <div style={{ fontSize: '0.85rem', color: '#111827', fontWeight: 500, wordBreak: 'break-word' }}>
          {value || '—'}
        </div>
      </div>
    </div>
  )

  const SectionTitle = ({ title }) => (
    <div className="mb-3 mt-1">
      <span style={{ fontSize: '0.7rem', fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '1px' }}>
        {title}
      </span>
      <hr style={{ marginTop: '6px', marginBottom: '12px', borderColor: '#f3f4f6' }} />
    </div>
  )

  return (
    <Modal show onHide={onClose} fullscreen dialogClassName="employee-profile-modal">

      <Modal.Header style={{ background: '#fff', borderBottom: '1px solid #f3f4f6', padding: '14px 24px' }} closeButton={false}>
        <div className="d-flex align-items-center justify-content-between w-100">
          <span style={{ fontWeight: 600, fontSize: '0.95rem', color: '#111827' }}>
            Employee Profile
          </span>
          <button
            onClick={onClose}
            style={{
              border: 'none', background: '#f3f4f6', borderRadius: '50%',
              width: '32px', height: '32px', display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: '#6b7280',
            }}
          >
            <Icon icon="mdi:close" width={18} />
          </button>
        </div>
      </Modal.Header>

      <Modal.Body style={{ backgroundColor: '#f9fafb', padding: '24px', overflowY: 'auto' }}>
        <Row className="g-3 h-100">

          {/* ── Left sidebar ── */}
          <Col lg={4} xl={3}>
            <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)', height: '100%' }}>
              <CardBody style={{ padding: '28px 24px', overflowY: 'auto' }}>

                <div className="text-center mb-4">
                  <div style={{
                    width: '100px', height: '100px', borderRadius: '50%',
                    background: 'linear-gradient(135deg, var(--bs-primary) 0%, #6f42c1 100%)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    margin: '0 auto 14px', fontSize: '1.5rem', fontWeight: 700, color: '#fff',
                    boxShadow: '0 4px 14px rgba(var(--bs-primary-rgb), 0.3)',
                  }}>
                    {initials}
                  </div>
                  <h5 style={{ fontWeight: 700, color: '#111827', marginBottom: '4px', fontSize: '1rem' }}>{fullName}</h5>
                  <p style={{ color: '#6b7280', marginBottom: '10px' }}>
                    {employee.job_specification || 'Employee'}
                  </p>
                  <span style={{
                    display: 'inline-block', borderRadius: '20px', padding: '4px 14px',
                    fontWeight: 500, color: '#fff',
                    backgroundColor: getStatusColor(employee.employment_status),
                  }}>
                    {employee.employment_status}
                  </span>
                </div>

                <div style={{
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  backgroundColor: '#f3f4f6', borderRadius: '10px', padding: '10px 14px', marginBottom: '20px',
                }}>
                  <span style={{ fontSize: '0.75rem', color: '#6b7280', fontWeight: 500 }}>Employee ID</span>
                  <span style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--bs-primary)' }}>
                    #{employee.employee_id}
                  </span>
                </div>

                <SectionTitle title="Personal Information" />
                <InfoRow icon="mdi:email-outline"                label="Email"          value={employee.email} />
                <InfoRow icon="mdi:phone-outline"                label="Phone"          value={employee.contact_no} />
                <InfoRow icon="mdi:cake-variant-outline"         label="Date of Birth"
                  value={employee.date_of_birth
                    ? new Date(employee.date_of_birth).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })
                    : null}
                />
                <InfoRow icon="mdi:gender-male-female"           label="Gender"         value={employee.gender} />
                <InfoRow icon="mdi:heart-outline"                label="Marital Status" value={employee.marital_status} />
                <InfoRow icon="mdi:flag-outline"                 label="Nationality"    value={employee.nationality} />
                <InfoRow icon="mdi:card-account-details-outline" label="NIC"            value={employee.nic} />

                <SectionTitle title="Address" />
                <InfoRow
                  icon="mdi:map-marker-outline"
                  label="Address"
                  value={[
                    employee.address,
                    employee.city ? employee.city.charAt(0).toUpperCase() + employee.city.slice(1) : null,
                    employee.country,
                  ].filter(Boolean).join(', ')}
                />

                <SectionTitle title="Bank Details" />
                <InfoRow icon="mdi:bank-outline"            label="Account No"     value={employee.bank_account_no} />
                <InfoRow icon="mdi:account-outline"         label="Account Holder" value={employee.account_holder_name} />
                <InfoRow icon="mdi:office-building-outline" label="Branch"         value={employee.bank_branch} />
                <InfoRow icon="mdi:credit-card-outline"     label="Account Type"   value={employee.account_type} />

              </CardBody>
            </Card>
          </Col>

          {/* ── Right panel ── */}
          <Col lg={8} xl={9}>
            <Card style={{ borderRadius: '14px', border: 'none', boxShadow: '0 1px 8px rgba(0,0,0,0.07)', minHeight: '500px' }}>

              {/* Tab bar */}
              <div style={{ borderBottom: '1px solid #f3f4f6', padding: '0 24px', display: 'flex', gap: '2px', overflowX: 'auto' }}>
                {tabs.map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    style={{
                      border: 'none', background: 'none', padding: '15px 20px',
                      fontWeight: activeTab === tab.key ? 600 : 400,
                      color: activeTab === tab.key ? 'var(--bs-primary)' : '#9ca3af',
                      borderBottom: activeTab === tab.key ? '2px solid var(--bs-primary)' : '2px solid transparent',
                      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '7px',
                      transition: 'color 0.15s', marginBottom: '-1px', whiteSpace: 'nowrap',
                    }}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Tab content — Dashboard gets zero padding so its internal padding matches original */}
              <CardBody style={{ padding: activeTab === 'Dashboard' ? '0' : '32px 28px' }}>
                {activeTab === 'Dashboard' ? (
                  <EmployeeDashboardSection employee={employee} />
                ) : activeTab === 'Attendance' ? (
                  <EmployeeAttendanceTab employeeId={employee.employee_id} />
                ) : activeTab === 'Leaves' ? (
                  <EmployeeLeavesTab employeeId={employee.employee_id} />
                ) : activeTab === 'Documents' ? (
                  <EmployeeDocumentsTab employeeId={employee.employee_id} />
                ) : activeTab === 'Appreciation' ? (
                  <EmployeeAppreciationTab employeeId={employee.employee_id} />
                ) : activeTab === 'Increment & Promotions' ? (
                  <EmployeeIncrementTab employeeId={employee.employee_id} />
                ) : activeTab === 'Emergency Contacts' ? (
                  <EmployeeEmergencyContactTab employee={employee} />
                ) : activeTab === 'Employee Log' ? (
                  <EmployeeLogTab employeeId={employee.employee_id} />
                ) : activeTab === 'Paysheet' ? (
                  <EmployeePaysheetTab employeeId={employee.employee_id} />
                ) : activeTab === 'Settings' ? (
                  <EmployeeSettingsTab employee={employee} onEmployeeUpdate={onEmployeeUpdate} />
                ) : (
                  <div className="d-flex align-items-center justify-content-center" style={{ minHeight: '380px', color: '#d1d5db' }}>
                    <div className="text-center">
                      <Icon icon="mdi:dots-horizontal" width={56} />
                      <p style={{ marginTop: '12px', fontSize: '0.875rem', color: '#9ca3af' }}>
                        {tabs.find(t => t.key === activeTab)?.label}
                      </p>
                    </div>
                  </div>
                )}
              </CardBody>

            </Card>
          </Col>
        </Row>
      </Modal.Body>
    </Modal>
  )
}


function EmployeDetatils() {
  const Logout = () => {
    sessionStorage.clear()
    localStorage.clear()
    window.location.href = '/auth/login'
  }

  const [filters, setFilters] = useState({ order_number: '', recipient_name: '', mobile: '', date: '' })
  const [refreshtoken] = useRefreshTokenMutation()
  const [fetchFilteredEmployees] = useGetFilteredAllEmpolyeesMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [employees, setEmployees] = useState([])
  const logsPerPage = 25
  const [employeName, setEmployeName] = useState('')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [loading, setLoading] = useState(false)
  const [status, setStatus] = useState('')
  const [searchEmploye, SetSearchEmploye] = useState('')
  const [selectedEmployee, setSelectedEmployee] = useState(null)
  const [rawEmployees, setRawEmployees] = useState([])
  const [editEmployee, setEditEmployee] = useState(null)

  const { data: fetchedEmployee } = useGetEmployeeByIdQuery(
    selectedEmployee?.employee_id,
    { skip: !selectedEmployee?.employee_id }
  )

  const { data: RecipientResults } = useGetEmployeenameQuery(searchEmploye, {
    skip: searchEmploye.length < 2,
  })
  const { data: designations = [] } = useGetDesignationsQuery()
  const { data: departments = [] } = useGetDepartmentsQuery()

  const orderOptions = RecipientResults?.map((order) => ({ label: `${order.full_name}` })) || []
  const debouncedSearchRecipient = debounce((value) => { SetSearchEmploye(value) }, 300)
  const handlePageChange = (page) => {
  if (page < 1 || page > totalPages) return
  setCurrentPage(page)
}

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredEmployees({
        page, limit: logsPerPage,
        keyword: filters.keyword,
        status, date, todate,
      }).unwrap()

      setRawEmployees(res.employees || [])
      console.log(res.employees?.[0])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch employees:', err)
      const errStatus = err?.status || err?.originalStatus || err?.data?.status
      if (errStatus === 401 || errStatus === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const refreshed = await refreshtoken(refreshToken).unwrap()
            if (refreshed?.access_token) sessionStorage.setItem('access_token', refreshed.access_token)
            const retry = await fetchFilteredEmployees({
              page, limit: logsPerPage,
              keyword: filters.keyword,
              status, date, todate,
            }).unwrap()
            setRawEmployees(retry.employees || [])
            setTotalPages(retry.totalPages || 1)
            setCurrentPage(page)
          } catch { Logout() }
        } else { Logout() }
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchLogs(1) }, [])
  useEffect(() => { fetchLogs(currentPage) }, [currentPage])
  useEffect(() => {
    if (rawEmployees.length === 0) return
    const enriched = rawEmployees.map((emp) => ({
      ...emp,
      designation_name: designations.find(d => d.designation_id === emp.designation_id)?.designation_name || '-',
      department_name:  departments.find(d => d.department_id  === emp.department_id)?.department_name  || '-',
    }))
    setEmployees(enriched)
  }, [rawEmployees, designations, departments])

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)
    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  return (
    <>
      {selectedEmployee && (
        <EmployeeProfileModal
          employee={fetchedEmployee ?? selectedEmployee}
          onClose={() => setSelectedEmployee(null)}
        />
      )}

      <Row className="justify-content-center">
        <Col>
          <Card>
            <CardHeader className="py-3 bg-light">
              <Row className="align-items-center justify-content-between">
                <Col>
                  <CardTitle as="h4" className="mb-0">Employee List</CardTitle>
                </Col>
                <Col xs="auto">
                  <Link href="/add_employee" passHref>
                    <Button type="button" className="btn bg-primary border border-primary">
                      <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Employee Onboarding
                    </Button>
                  </Link>
                </Col>
              </Row>
            </CardHeader>

            <CardBody>
              <Form className="row g-1 mb-3">
                <FormGroup className="col-md-3">
                  <FormLabel>Keyword</FormLabel>
                  <Select
                    styles={{
                      control: (base, state) => ({
                        ...base, borderRadius: '999px',
                        borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                        boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                      }),
                    }}
                    options={orderOptions}
                    onInputChange={(value, { action }) => {
                      if (action === 'input-change') {
                        debouncedSearchRecipient(value)
                        SetSearchEmploye(value)
                        setEmployeName(value)
                        setFilters((prev) => ({ ...prev, keyword: value }))
                      }
                    }}
                    onChange={(option) => {
                      if (option) {
                        const name = option.label?.split('(')[0].trim()
                        setEmployeName(name)
                        SetSearchEmploye(name)
                        setFilters((prev) => ({ ...prev, keyword: name }))
                      } else {
                        setEmployeName('')
                        SetSearchEmploye('')
                        setFilters((prev) => ({ ...prev, keyword: '' }))
                      }
                    }}
                    placeholder="ID, Name, Mobile"
                    isClearable isSearchable
                    value={employeName ? { label: employeName, value: employeName } : null}
                    components={{ DropdownIndicator: null }}
                  />
                </FormGroup>

                <FormGroup className="col-md-4">
                  <div className="row g-1">
                    <div className="col-6">
                      <FormLabel>From Date</FormLabel>
                      <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                    </div>
                    <div className="col-6">
                      <FormLabel>To Date</FormLabel>
                      <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                    </div>
                  </div>
                </FormGroup>

                <FormGroup className="col-md-3">
                  <FormLabel>Status</FormLabel>
                  <Form.Select value={status} onChange={(e) => setStatus(e.target.value)}>
                    <option value="">All</option>
                    <option value="CONTRACT">CONTRACT</option>
                    <option value="PROBATION">PROBATION</option>
                    <option value="PERMANENT">PERMANENT</option>
                  </Form.Select>
                </FormGroup>

                <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                  <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                    Search
                  </Button>
                </FormGroup>
              </Form>

              <Table striped bordered hover responsive>
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Job Title</th>
                    <th>Email</th>
                    <th>Mobile NO</th>
                    <th>Status</th>
                    <th>Department</th>
                    <th>Location</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="10" className="text-center">
                        <Spinner animation="border" size="sm" /> Loading...
                      </td>
                    </tr>
                  ) : employees.length > 0 ? (
                    employees.map((emp) => (
                      <tr key={emp.employee_id}>
                        <td>{emp.employee_id}</td>
                        <td>
                          {emp.joined_date
                            ? new Date(emp.joined_date).toISOString().split('T')[0]
                            : '-'}
                        </td>
                        <td>
                          {[emp.first_name, emp.middle_name, emp.last_name]
                            .filter(Boolean)
                            .map(n => n.charAt(0).toUpperCase() + n.slice(1).toLowerCase())
                            .join(' ')}
                        </td>
                        <td>{emp.designation_name || '-'}</td>
                        <td>{emp.email || '-'}</td>
                        <td>{emp.contact_no || '-'}</td>
                        <td>{emp.employment_status}</td>
                        <td>{emp.department_name || '-'}</td>
                        <td>
                          {emp.city ? emp.city.charAt(0).toUpperCase() + emp.city.slice(1) : '-'}
                        </td>
                        <td className="text-end no-print">
                          <div className="d-flex justify-content-end align-items-center gap-2">
                            <Button
                              onClick={() => setEditEmployee(emp)}
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto', padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem', height: '30px', borderRadius: '15px',
                                backgroundColor: '#fd7e14', borderColor: '#fd7e14', color: '#fff',
                              }}
                            >
                              <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Edit</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center"
                              onClick={() => setSelectedEmployee(emp)}
                              style={{
                                minWidth: 'auto', padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem', height: '30px', borderRadius: '15px',
                                backgroundColor: '#5f5f5f', borderColor: '#5f5f5f', color: '#fff',
                              }}
                            >
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>View</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="10" className="text-center">No Employees Found</td>
                    </tr>
                  )}
                </tbody>
              </Table>

              {/* ================= PAGINATION ================= */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {/* FIRST */}
                      <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>
                        First
                      </Pagination.Item>

                      {/* PREVIOUS */}
                      <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />

                      {/* PAGE NUMBERS (MAX 5, CURRENT CENTERED) */}
                      {(() => {
                        let pages = []

                        if (totalPages <= 5) {
                          // SHOW ALL PAGES (1 → totalPages)
                          for (let i = 1; i <= totalPages; i++) {
                            pages.push(
                              <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                                {i}
                              </Pagination.Item>,
                            )
                          }
                        } else {
                          // CENTER CURRENT PAGE (MAX 5)
                          let start = currentPage - 2
                          let end = currentPage + 2

                          if (start < 1) {
                            start = 1
                            end = 5
                          }

                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }

                          for (let i = start; i <= end; i++) {
                            pages.push(
                              <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>
                                {i}
                              </Pagination.Item>,
                            )
                          }
                        }

                        return pages
                      })()}

                      {/* NEXT */}
                      <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />

                      {/* LAST */}
                      <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>
                        Last
                      </Pagination.Item>
                    </Pagination>
                  </div>
                )}
            </CardBody>
          </Card>
        </Col>
      </Row>

      {editEmployee && (
        <EmployeeEditModal
          employee={editEmployee}
          onClose={() => setEditEmployee(null)}
          onSaved={(updated) => {
            setEmployees(prev =>
              prev.map(e =>
                e.employee_id === updated.employee_id ? { ...e, ...updated } : e
              )
            )
            setEditEmployee(null)
          }}
        />
      )}
    </>
  )
}

export default EmployeDetatils
