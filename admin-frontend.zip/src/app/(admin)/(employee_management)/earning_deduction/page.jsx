import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Earning_Deduction - Employee Management',
}


const Earning_Deduction = dynamic(() => import('./earning_deduction'), { ssr: false })

export default function AddEarningDeductionpage() {
  return <Earning_Deduction />
}