'use client'

import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  Button, Col, Form, FormControl, FormLabel, FormSelect, Row,
  Modal, Card, CardHeader, CardBody, CardTitle, Table, Alert,Spinner,
} from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { Icon } from '@iconify/react/dist/iconify.js'
import {
  useGetAllEarningsDeductionsQuery,
  useCreateEarningDeductionMutation,
  useUpdateEarningDeductionMutation,
} from '@/store/features/emsSlice'

// ─── Schema ───────────────────────────────────────────────────────────────────
const schema = yup.object({
  name: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'Name can only contain letters')
    .required('Name is required'),
  type: yup
    .string()
    .oneOf(['EARNINGS', 'DEDUCTIONS'], 'Type is required')
    .required('Type is required'),
  calculation_type: yup
    .string()
    .oneOf(['AMOUNT', 'PERCENTAGE'], 'Calculation type is required')
    .required('Calculation type is required'),
  status: yup
    .string()
    .oneOf(['ACTIVE', 'INACTIVE'])
    .required('Status is required'),
})

const EMPTY_FORM = {
  name: '',
  type: '',
  calculation_type: '',
  status: 'ACTIVE',
}

const typeColor = (type) => type === 'EARNINGS' ? 'success' : type === 'DEDUCTIONS' ? 'danger' : 'secondary'
const calcIcon  = (c)    => c === 'AMOUNT' ? 'mdi:currency-usd' : 'mdi:percent'

// ─── Component ────────────────────────────────────────────────────────────────
const AddEarningDeduction = () => {
  const { data: allRecords = [], isLoading, error, refetch } = useGetAllEarningsDeductionsQuery()
  const [createEarningDeduction, { isLoading: isCreating }] = useCreateEarningDeductionMutation()
  const [updateEarningDeduction, { isLoading: isUpdating }] = useUpdateEarningDeductionMutation()

  const { register, handleSubmit, formState: { errors }, reset } =
    useForm({ resolver: yupResolver(schema), mode: 'onChange', defaultValues: EMPTY_FORM })

  const { register: regEdit, handleSubmit: handleEditSubmit, formState: { errors: editErrors }, reset: resetEdit } =
    useForm({ resolver: yupResolver(schema), mode: 'onChange' })

  const [showEditModal, setShowEditModal] = useState(false)
  const [showViewModal, setShowViewModal] = useState(false)
  const [viewRecord,    setViewRecord]    = useState(null)
  const [editRecord,    setEditRecord]    = useState(null)
  const [successMsg,    setSuccessMsg]    = useState('')
  const [filterType,    setFilterType]    = useState('ALL')
  const [searchTerm,    setSearchTerm]    = useState('')

  // ── Create ───────────────────────────────────────────────────────────────────
  const onSubmit = async (data) => {
    try {
      await createEarningDeduction({ ...data, created_by: 1 }).unwrap()
      reset(EMPTY_FORM)
      refetch()
    } catch (err) {
      alert(err?.data?.message || 'Failed to save')
    }
  }

  // ── Edit ─────────────────────────────────────────────────────────────────────
  const openEdit = (item) => {
    setEditRecord(item)
    setSuccessMsg('')
    resetEdit({
      name:             item.name,
      type:             item.type,
      calculation_type: item.calculation_type,
      status:           item.status,
    })
    setShowEditModal(true)
  }

  const onEditSubmit = async (data) => {
    try {
      await updateEarningDeduction({ id: editRecord.id, ...data }).unwrap()
      setSuccessMsg('Record updated successfully!')
      refetch()
      setTimeout(() => { setShowEditModal(false); setSuccessMsg('') }, 1200)
    } catch (err) {
      alert(err?.data?.message || 'Failed to update')
    }
  }

  // ── Filter + Search ──────────────────────────────────────────────────────────
  const displayed = allRecords
    .filter((r) => filterType === 'ALL' || r.type === filterType)
    .filter((r) => r.name.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <>
      {/* ── Add Form ── */}
      <ComponentContainerCard title="Add Earning / Deduction">
        <Form onSubmit={handleSubmit(onSubmit)}>

          {/* Row 1 — Name · Type · Status */}
          <Row className="mt-3 mb-2 g-3 align-items-end">
            <Col md={3}>
              <FormLabel>Name <span className="text-danger">*</span></FormLabel>
              <FormControl
                type="text"
                placeholder="e.g. Basic Salary, EPF Deduction"
                {...register('name')}
                isInvalid={!!errors.name}
              />
              {errors.name && <p className="text-danger small mb-0">{errors.name.message}</p>}
            </Col>

            <Col md={3}>
              <FormLabel>Type <span className="text-danger">*</span></FormLabel>
              <FormSelect {...register('type')} isInvalid={!!errors.type}>
                <option value="">Select Type</option>
                <option value="EARNINGS">Earnings</option>
                <option value="DEDUCTIONS">Deductions</option>
              </FormSelect>
              {errors.type && <p className="text-danger small mb-0">{errors.type.message}</p>}
            </Col>

            <Col md={2}>
              <FormLabel>Status <span className="text-danger">*</span></FormLabel>
              <FormSelect {...register('status')} isInvalid={!!errors.status}>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </FormSelect>
              {errors.status && <p className="text-danger small mb-0">{errors.status.message}</p>}
            </Col>
             <Col md={2}>
              <FormLabel>Calculation Type <span className="text-danger">*</span></FormLabel>
              <FormSelect {...register('calculation_type')} isInvalid={!!errors.calculation_type}>
                <option value="">Select Calculation</option>
                <option value="AMOUNT">Amount (Fixed Value)</option>
                <option value="PERCENTAGE">Percentage (%)</option>
              </FormSelect>
              {errors.calculation_type && (
                <p className="text-danger small mb-0">{errors.calculation_type.message}</p>
              )}
            </Col>

            <Col md={2}>
              <Button className="btn bg-primary border-primary w-100" type="submit" disabled={isCreating}>
                <div className="d-flex align-items-center justify-content-center gap-2">
                  {isCreating
                    ? <><Spinner animation="border" size="sm" /> Saving…</>
                    : <><Icon icon="mdi:plus-circle" width={18} /> Add Record</>}
                </div>
              </Button>
            </Col>
          </Row>

    

        </Form>
      </ComponentContainerCard>

      {/* ── Table Card ── */}
      <Card className="mt-4">
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center g-2">
            <Col>
              <CardTitle className="mb-0">Earnings &amp; Deductions List</CardTitle>
            </Col>

            {/* Search */}
            <Col md={3}>
              <FormControl
                type="text"
                placeholder="Search by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </Col>

            {/* Filter buttons — same pill style as Shift page */}
            <Col xs="auto">
              <div className="d-flex gap-2">
                {[
                  { key: 'ALL',        label: 'All' },
                  { key: 'EARNINGS',   label: 'Earnings' },
                  { key: 'DEDUCTIONS', label: 'Deductions' },
                ].map(({ key, label }) => (
                  <Button
                    key={key}
                    size="sm"
                    variant={filterType === key ? 'primary' : 'outline-secondary'}
                    onClick={() => setFilterType(key)}
                    style={{ borderRadius: 15, fontSize: '0.75rem', padding: '0.3rem 0.8rem' }}
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          <div className="table-responsive">
            <Table striped hover>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Calculation</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan="7" className="text-center py-4">Loading records...</td></tr>
                ) : error ? (
                  <tr><td colSpan="7" className="text-center text-danger py-4">{error?.data?.message || 'Failed to load records'}</td></tr>
                ) : displayed.length > 0 ? (
                  displayed.map((item, idx) => (
                    <tr key={item.id}>
                      <td className="text-muted small">{idx + 1}</td>
                      <td style={{ textTransform: 'capitalize', fontWeight: 500 }}>{item.name}</td>
                      <td>
                        <span className={`badge bg-${typeColor(item.type)}`}>
                          {item.type === 'EARNINGS' ? 'Earning' : 'Deduction'}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex align-items-center gap-1">
                          <Icon icon={calcIcon(item.calculation_type)} width={14} className="text-muted" />
                          <span className="small">{item.calculation_type}</span>
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${item.status === 'ACTIVE' ? 'bg-success' : 'bg-secondary'}`}>
                          {item.status}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex align-items-center gap-2">
                          <Button
                            size="sm"
                            className="d-flex align-items-center"
                            onClick={() => { setViewRecord(item); setShowViewModal(true) }}
                            style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#007bff', borderColor: '#007bff', color: '#fff' }}
                          >
                            <Icon icon="mdi:eye" width={15} style={{ marginRight: 4 }} />View
                          </Button>
                          <Button
                            size="sm"
                            className="d-flex align-items-center"
                            onClick={() => openEdit(item)}
                            style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#fd7e14', borderColor: '#fd7e14', color: '#fff' }}
                          >
                            <Icon icon="mdi:pencil" width={15} style={{ marginRight: 4 }} />Edit
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan="7" className="text-center py-4">No records found.</td></tr>
                )}
              </tbody>
            </Table>
          </div>
        </CardBody>
      </Card>

      {/* ── Edit Modal ── */}
      <Modal show={showEditModal} onHide={() => { setShowEditModal(false); setSuccessMsg('') }} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Earning / Deduction</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {successMsg && <Alert variant="success">{successMsg}</Alert>}
          <Form id="edit-earning-form" onSubmit={handleEditSubmit(onEditSubmit)}>
            <Row className="g-3">
              <Col md={6}>
                <FormLabel>Name <span className="text-danger">*</span></FormLabel>
                <FormControl type="text" placeholder="Name" {...regEdit('name')} isInvalid={!!editErrors.name} />
                {editErrors.name && <p className="text-danger small mb-0">{editErrors.name.message}</p>}
              </Col>

              <Col md={6}>
                <FormLabel>Type <span className="text-danger">*</span></FormLabel>
                <FormSelect {...regEdit('type')} isInvalid={!!editErrors.type}>
                  <option value="">Select Type</option>
                  <option value="EARNINGS">Earnings</option>
                  <option value="DEDUCTIONS">Deductions</option>
                </FormSelect>
                {editErrors.type && <p className="text-danger small mb-0">{editErrors.type.message}</p>}
              </Col>

              <Col md={6}>
                <FormLabel>Calculation Type <span className="text-danger">*</span></FormLabel>
                <FormSelect {...regEdit('calculation_type')} isInvalid={!!editErrors.calculation_type}>
                  <option value="">Select Calculation</option>
                  <option value="AMOUNT">Amount (Fixed)</option>
                  <option value="PERCENTAGE">Percentage (%)</option>
                </FormSelect>
                {editErrors.calculation_type && <p className="text-danger small mb-0">{editErrors.calculation_type.message}</p>}
              </Col>

              <Col md={3}>
                <FormLabel>Value <span className="text-danger">*</span></FormLabel>
                <FormControl type="number" min={0} step="0.01" placeholder="0" {...regEdit('value')} isInvalid={!!editErrors.value} />
                {editErrors.value && <p className="text-danger small mb-0">{editErrors.value.message}</p>}
              </Col>

              <Col md={3}>
                <FormLabel>Status <span className="text-danger">*</span></FormLabel>
                <FormSelect {...regEdit('status')} isInvalid={!!editErrors.status}>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </FormSelect>
                {editErrors.status && <p className="text-danger small mb-0">{editErrors.status.message}</p>}
              </Col>
            </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" disabled={isUpdating} onClick={() => { setShowEditModal(false); setSuccessMsg('') }}>Close</Button>
          <Button type="submit" form="edit-earning-form" variant="warning" disabled={isUpdating}>
            {isUpdating
              ? <><Spinner animation="border" size="sm" className="me-1" /> Saving…</>
              : 'Update Record'}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* ── View Modal ── */}
      <Modal show={showViewModal} onHide={() => setShowViewModal(false)} centered size="md">
        <Modal.Header closeButton>
          <Modal.Title>Record Details</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-0">
          {viewRecord ? (
            <Card className="w-100 overflow-hidden border-0 rounded-0" style={{ backgroundColor: '#f8f9fa' }}>
              <div
                className="text-white text-center py-4 position-relative"
                style={{ backgroundColor: viewRecord.type === 'EARNINGS' ? '#28a745' : '#dc3545' }}
              >
                <span style={{ backgroundColor: '#020c07cc', color: 'white', padding: '4px 10px', borderRadius: 12, fontSize: '0.6rem', position: 'absolute', top: 10, right: 10, textTransform: 'uppercase' }}>
                  {viewRecord.status}
                </span>
                <div className="mx-auto mb-2 d-flex align-items-center justify-content-center rounded-circle bg-white" style={{ width: 90, height: 90 }}>
                  <Icon
                    icon={viewRecord.type === 'EARNINGS' ? 'mdi:trending-up' : 'mdi:trending-down'}
                    width={52}
                    style={{ color: viewRecord.type === 'EARNINGS' ? '#28a745' : '#dc3545' }}
                  />
                </div>
                <h5 className="mb-0 fw-bold" style={{ textTransform: 'capitalize' }}>{viewRecord.name}</h5>
                <small className="opacity-75">{viewRecord.type === 'EARNINGS' ? 'Earning' : 'Deduction'}</small>
              </div>

              <Card.Body className="px-4 py-3">
                <div className="d-flex flex-column gap-2">
                  {[
                    { icon: 'mdi:tag-outline',  label: 'Name',        value: viewRecord.name },
                    { icon: 'mdi:swap-vertical', label: 'Type',        value: viewRecord.type },
                    { icon: calcIcon(viewRecord.calculation_type), label: 'Calculation', value: viewRecord.calculation_type },
                    {
                      icon: 'mdi:cash',
                      label: 'Value',
                      value: viewRecord.calculation_type === 'PERCENTAGE'
                        ? `${viewRecord.value}%`
                        : Number(viewRecord.value).toLocaleString(),
                    },
                  ].map(({ icon, label, value }, i, arr) => (
                    <React.Fragment key={label}>
                      <div className="d-flex align-items-center gap-2">
                        <Icon icon={icon} width={18} className="text-muted flex-shrink-0" />
                        <span className="text-muted small">{label}</span>
                        <span className="fw-semibold small ms-auto" style={{ textTransform: 'capitalize' }}>{value}</span>
                      </div>
                      {i < arr.length - 1 && <hr className="my-1" />}
                    </React.Fragment>
                  ))}
                  <hr className="my-1" />
                  <div className="d-flex align-items-center gap-2">
                    <Icon
                      icon={viewRecord.status === 'ACTIVE' ? 'mdi:check-circle' : 'mdi:close-circle'}
                      width={18}
                      className={viewRecord.status === 'ACTIVE' ? 'text-success flex-shrink-0' : 'text-secondary flex-shrink-0'}
                    />
                    <span className="text-muted small">Status</span>
                    <span className="ms-auto">
                      <span className={`badge ${viewRecord.status === 'ACTIVE' ? 'bg-success' : 'bg-secondary'}`} style={{ fontSize: '0.7rem' }}>
                        {viewRecord.status}
                      </span>
                    </span>
                  </div>
                </div>
              </Card.Body>
            </Card>
          ) : (
            <p className="p-3">Loading...</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowViewModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default AddEarningDeduction
