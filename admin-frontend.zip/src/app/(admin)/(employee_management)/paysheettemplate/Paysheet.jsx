'use client'

import React, { useState, useMemo, useRef, useEffect } from 'react'
import {
  Button, Card, CardHeader, CardBody, CardTitle,
  Col, Row, Table, Modal, Badge, Form,
  FormControl, FormLabel, FormGroup, Spinner, Alert, InputGroup, FormSelect, Pagination
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import { useGetAllEmployeesListQuery } from '@/store/features/emsSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'
import UseLogout from '@/hooks/useLogout'
import useRefreshToken from '@/hooks/useRefreshToken'

// ── Import all styles from the single CSS file ────────────────────────────────
import './payslip-print.css'

// ─── helpers ──────────────────────────────────────────────────────────────────
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

const makeFmt = (currency) => (n) =>
  `${currency ?? 'LKR'} ${Number(n || 0).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

function numberToWords(num) {
  const n = Math.round(Number(num) || 0)
  if (n === 0) return 'Zero'
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen']
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']
  function chunk(x) {
    if (x < 20) return ones[x]
    if (x < 100) return tens[Math.floor(x / 10)] + (x % 10 ? ' ' + ones[x % 10] : '')
    return ones[Math.floor(x / 100)] + ' Hundred' + (x % 100 ? ' ' + chunk(x % 100) : '')
  }
  let rem = n; const parts = []
  if (rem >= 10000000) { parts.push(chunk(Math.floor(rem / 10000000)) + ' Crore'); rem %= 10000000 }
  if (rem >= 100000) { parts.push(chunk(Math.floor(rem / 100000)) + ' Lakh'); rem %= 100000 }
  if (rem >= 1000) { parts.push(chunk(Math.floor(rem / 1000)) + ' Thousand'); rem %= 1000 }
  if (rem > 0) { parts.push(chunk(rem)) }
  return parts.join(' ')
}

const statusBadge = (s) => {
  const map = {
    PAID: ['success', 'Paid'],
    PENDING: ['warning text-dark', 'Pending'],
    DRAFT: ['secondary', 'Draft'],
    GENERATED: ['info text-dark', 'Generated'],
    APPROVED: ['primary', 'Approved'],
  }
  const [, label] = map[s] ?? ['secondary', s ?? 'Draft']
  return <span className="fw-semibold">{label}</span>
}

const resolveToLKR = (amount, amountType, base) => {
  const val = parseFloat(amount) || 0
  if (amountType === 'PERCENTAGE') return (val / 100) * base
  return val
}

// ─── PRINT_CSS string — used only for the print popup window ─────────────────
// We keep this constant so the opened print window gets the styles inlined,
// since it cannot access the Next.js-bundled CSS file.
const PRINT_CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#f0f2f5;color:#1a2332;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{background:#fff;max-width:780px;margin:24px auto;box-shadow:0 4px 40px rgba(0,0,0,.13)}
.slip-header{background:linear-gradient(135deg,#0b2447 0%,#19376d 55%,#1565c0 100%);color:#fff;padding:28px 36px 26px;position:relative;overflow:hidden}
.slip-header::after{content:'';position:absolute;right:-50px;top:-50px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.05)}
.slip-header::before{content:'';position:absolute;right:70px;bottom:-70px;width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.04)}
.header-row{display:flex;justify-content:space-between;align-items:flex-start;position:relative;z-index:1}
.company-name{font-family:'DM Serif Display',serif;font-size:21px;letter-spacing:.3px;margin-bottom:3px}
.slip-subtitle{font-size:10.5px;text-transform:uppercase;letter-spacing:2.5px;opacity:.65;font-weight:500}
.slip-meta{text-align:right}
.pay-period-label{font-size:12px;font-weight:600;opacity:.88;margin-bottom:3px}
.slip-id-label{font-size:10.5px;opacity:.5}
.emp-band{background:#f7f9fc;border-bottom:1px solid #e4eaf3;padding:18px 36px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.ef label{font-size:9.5px;text-transform:uppercase;letter-spacing:1.2px;color:#7a8aa0;font-weight:700;display:block;margin-bottom:3px}
.ef span{font-size:13px;font-weight:600;color:#1a2332}
.summary-strip{display:grid;grid-template-columns:repeat(5,1fr);border-bottom:2px solid #e4eaf3}
.sc{padding:13px 0;text-align:center;border-right:1px solid #eef1f7}
.sc:last-child{border-right:none}
.sc .sv{font-size:14.5px;font-weight:700}
.sc .sl{font-size:9.5px;text-transform:uppercase;letter-spacing:.8px;color:#7a8aa0;font-weight:700;margin-top:2px}
.ed-grid{display:grid;grid-template-columns:1fr 1fr}
.ed-col{border-right:1px solid #e4eaf3}
.ed-col:last-child{border-right:none}
.ed-head{display:flex;justify-content:space-between;padding:9px 22px;font-size:9.5px;text-transform:uppercase;letter-spacing:1.2px;font-weight:700}
.ed-earn .ed-head{background:#edfaf3;color:#1b6c3e}
.ed-dedu .ed-head{background:#fff0f0;color:#9b2222}
.ed-table{width:100%;border-collapse:collapse}
.ed-table td{padding:8px 22px;font-size:12.5px;border-bottom:1px solid #f4f6f9;color:#2d3a4a}
.ed-table td:last-child{text-align:right;font-weight:500;white-space:nowrap;color:#374151}
.ed-table .st td{font-weight:700;font-size:13px;background:#fafbfd;border-top:2px solid #e4eaf3;border-bottom:none;padding-top:10px;padding-bottom:10px}
.ed-earn .st td{color:#1b6c3e}
.ed-dedu .st td{color:#9b2222}
.ed-table .empty td{color:#b0bac8;font-style:italic;font-size:11.5px}
.net-bar{background:linear-gradient(90deg,#0b2447,#19376d);color:#fff;padding:16px 36px;display:flex;justify-content:space-between;align-items:center}
.net-label-wrap .nl{font-size:9.5px;text-transform:uppercase;letter-spacing:2px;opacity:.65;font-weight:600}
.net-label-wrap .nf{font-size:10.5px;opacity:.45;margin-top:2px}
.net-amount-wrap{text-align:right}
.net-cur{font-size:12px;opacity:.7;margin-right:3px}
.net-val{font-family:'DM Serif Display',serif;font-size:26px;letter-spacing:.5px}
.words-bar{background:#f7f9fc;border-top:1px solid #e4eaf3;padding:11px 36px;font-size:11.5px;color:#4a5568}
.words-bar strong{font-weight:700;color:#1a2332}
.slip-footer{padding:16px 36px;border-top:2px solid #e4eaf3;display:flex;justify-content:space-between;align-items:flex-end}
.fn{font-size:10px;color:#9ba8ba;line-height:1.6}
.sig .sig-line{width:130px;height:1px;background:#b0bac8;margin-bottom:5px;margin-left:auto}
.sig span{font-size:10px;color:#7a8aa0;font-weight:700;letter-spacing:.5px}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:100%}}
`

// ─── PayslipDocument ───────────────────────────────────────────────────────────
const PayslipDocument = ({ paysheet, details, employee, companyName = 'Your Company', currencySymbol = 'LKR' }) => {
  const fmt = makeFmt(currencySymbol)
  if (!paysheet) return null
  const month = paysheet.payroll_month ? MONTHS[paysheet.payroll_month - 1] : '—'
  const year = paysheet.payroll_year ?? '—'
  const empName = paysheet.first_name
    ? `${paysheet.first_name} ${paysheet.last_name ?? ''}`.trim()
    : employee
      ? `${employee.first_name ?? ''} ${employee.last_name ?? ''}`.trim()
      : `Employee #${paysheet.employee_id}`
  const designation = employee?.designation_name ?? '—'
  const department = employee?.department_name ?? '—'
  const empId = `EMP-${String(paysheet.employee_id).padStart(4, '0')}`
  const payDate = paysheet.salary_range_end
    ? String(paysheet.salary_range_end).split('T')[0] : '—'

  const isEarning = (t) => ['EARNING', 'EARNINGS'].includes((t ?? '').toUpperCase().trim())
  const isDeduction = (t) => ['DEDUCTION', 'DEDUCTIONS'].includes((t ?? '').toUpperCase().trim())
  const earnRows = (details ?? []).filter(r => isEarning(r.type))
  const deducRows = (details ?? []).filter(r => isDeduction(r.type))

  const grossEarnings = parseFloat(paysheet.total_earnings || 0)
  const totalDeductions = parseFloat(paysheet.total_deductions || 0)
  const netSalary = parseFloat(paysheet.net_salary || 0)
  const paidDays = paysheet.present_days ?? paysheet.total_working_days ?? '—'
  const lopDays = paysheet.absent_days ?? 0
  const halfDays = paysheet.half_days ?? 0
  const cents = Math.round((netSalary % 1) * 100)
  const wordsStr = netSalary > 0
    ? `${numberToWords(Math.floor(netSalary))}${cents ? ` and ${String(cents).padStart(2, '0')}/100` : ''} ${currencySymbol} Only`
    : `Zero ${currencySymbol} Only`

  return (
    <div className="page">
      <div className="slip-header">
        <div className="header-row">
          <div>
            <div className="company-name">{companyName}</div>
            <div className="slip-subtitle">Employee Payslip</div>
          </div>
          <div className="slip-meta">
            <div className="pay-period-label">Payslip for {month} {year}</div>
            <div className="slip-id-label">#{paysheet.paysheet_id} &nbsp;·&nbsp; {new Date().toLocaleDateString('en-GB')}</div>
          </div>
        </div>
      </div>

      <div className="emp-band">
        {[['Employee Name', empName], ['Employee ID', empId], ['Designation', designation], ['Department', department]].map(([label, value]) => (
          <div className="ef" key={label}><label>{label}</label><span>{value}</span></div>
        ))}
      </div>

      <div className="summary-strip">
        {[
          ['Paid Days', paidDays, '#1565c0'], ['LOP Days', lopDays, '#c0392b'],
          ['Half Days', halfDays, '#c77b00'], ['Pay Date', payDate, '#0d7a55'],
          ['Pay Period', `${month} ${year}`, '#6d3fa8'],
        ].map(([lbl, val, color]) => (
          // NOTE: color here is data-driven per cell — kept as inline intentionally
          <div className="sc" key={lbl}><div className="sv" style={{ color }}>{val}</div><div className="sl">{lbl}</div></div>
        ))}
      </div>

      <div className="ed-grid">
        <div className="ed-col ed-earn">
          <div className="ed-head"><span>Earnings</span><span>Amount ({currencySymbol})</span></div>
          <table className="ed-table"><tbody>
            {earnRows.length ? earnRows.map((r, i) => (
              <tr key={i}><td>{r.earning_deduction_name ?? r.name ?? '—'}</td><td>{fmt(r.amount)}</td></tr>
            )) : <tr className="empty"><td colSpan={2}>No earnings line items</td></tr>}
            <tr className="st"><td>Gross Earnings</td><td>{fmt(grossEarnings)}</td></tr>
          </tbody></table>
        </div>
        <div className="ed-col ed-dedu">
          <div className="ed-head"><span>Deductions</span><span>Amount ({currencySymbol})</span></div>
          <table className="ed-table"><tbody>
            {deducRows.length ? deducRows.map((r, i) => (
              <tr key={i}><td>{r.earning_deduction_name ?? r.name ?? '—'}</td><td>{fmt(r.amount)}</td></tr>
            )) : <tr className="empty"><td colSpan={2}>No deductions listed</td></tr>}
            <tr className="st"><td>Total Deductions</td><td>{fmt(totalDeductions)}</td></tr>
          </tbody></table>
        </div>
      </div>

      <div className="net-bar">
        <div className="net-label-wrap">
          <div className="nl">Total Net Payable</div>
          <div className="nf">Gross Earnings − Total Deductions</div>
        </div>
        <div className="net-amount-wrap">
          <span className="net-cur">{currencySymbol}</span>
          <span className="net-val">{fmt(netSalary)}</span>
        </div>
      </div>

      <div className="words-bar">Amount in words: &nbsp;<strong>{wordsStr}</strong></div>

      <div className="slip-footer">
        <div className="fn">
          This is a computer-generated payslip and does not require a physical signature.<br />
          For queries, please contact the HR department.
        </div>
        <div className="sig"><div className="sig-line" /><span>Authorised Signatory</span></div>
      </div>
    </div>
  )
}

// ─── PayslipModal ──────────────────────────────────────────────────────────────
const PayslipModal = ({ show, onHide, paysheet, details, employee, detailsLoading, companyName, currencySymbol }) => {
  const printRef = useRef(null)

  const handlePrint = () => {
    const html = printRef.current?.innerHTML
    if (!html) return
    const w = window.open('', '', 'width=900,height=720')
    w.document.write(`<!DOCTYPE html><html><head>
      <meta charset="utf-8"/>
      <title>Payslip — ${paysheet?.paysheet_id}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet"/>
      <style>${PRINT_CSS}</style>
    </head><body>${html}</body></html>`)
    w.document.close(); w.focus()
    setTimeout(() => { w.print(); w.close() }, 700)
  }

  return (
    <Modal show={show} onHide={onHide} size="xl" centered dialogClassName="payslip-dlg">
      {/* No more <style> tag here — styles live in payslip-print.css */}
      <Modal.Header closeButton className="modal-header-dark">
        <Modal.Title>
          <Icon icon="mdi:file-document-outline" className="modal-title-icon" />
          Payslip Preview
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {detailsLoading ? (
          <div className="d-flex justify-content-center align-items-center py-5 my-4">
            <Spinner animation="border" variant="primary" />
            <span className="ms-3 text-muted">Loading payslip details…</span>
          </div>
        ) : (
          <div className="ps-preview" ref={printRef}>
            <PayslipDocument
              paysheet={paysheet}
              details={details}
              employee={employee}
              companyName={companyName}
              currencySymbol={currencySymbol}
            />
          </div>
        )}
      </Modal.Body>

      <Modal.Footer className="bg-light border-top justify-content-between">
        <small className="text-muted">
          Paysheet&nbsp;ID:&nbsp;<strong>#{paysheet?.paysheet_id}</strong>
          &nbsp;·&nbsp;Currency:&nbsp;<strong>{currencySymbol}</strong>
        </small>
        <div className="d-flex gap-2">
          <Button variant="outline-secondary" onClick={onHide}>Close</Button>
          <Button
            onClick={handlePrint}
            disabled={detailsLoading}
            className="btn-navy"
          >
            <Icon icon="mdi:printer" className="me-1" />Print / Download PDF
          </Button>
        </div>
      </Modal.Footer>
    </Modal>
  )
}

// ─── AmountCell ────────────────────────────────────────────────────────────────
const AmountCell = ({ value, amountType, onValueChange, onTypeChange, disabled, resolvedLKR, currencySymbol }) => (
  <div>
    <InputGroup size="sm">
      <FormControl
        type="number" min="0"
        max={amountType === 'PERCENTAGE' ? 100 : undefined}
        step={amountType === 'PERCENTAGE' ? '0.01' : '1'}
        placeholder="0.00"
        disabled={disabled}
        value={value}
        onChange={(e) => {
          let val = e.target.value
          if (amountType === 'PERCENTAGE' && parseFloat(val) > 100) val = '100'
          onValueChange(val)
        }}
        className="amount-input-min"
      />
      <FormSelect
        disabled={disabled}
        value={amountType}
        onChange={(e) => {
          onTypeChange(e.target.value)
          if (e.target.value === 'PERCENTAGE' && parseFloat(value) > 100) onValueChange('100')
        }}
        className="amount-type-select"
      >
        <option value="LKR">{currencySymbol ?? 'LKR'}</option>
        <option value="PERCENTAGE">%</option>
      </FormSelect>
    </InputGroup>
    {amountType === 'PERCENTAGE' && resolvedLKR !== undefined && (
      <div className="amount-resolved-hint">
        = {currencySymbol} {Number(resolvedLKR).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </div>
    )}
  </div>
)

// ─── LineItemTable ─────────────────────────────────────────────────────────────
const LineItemTable = ({ title, colorClass, headerClass, rows, onCheck, onUpdate, onAdd, onRemove, addLabel, grossEarningsBase, currencySymbol }) => (
  <Col md={6}>
    <h6 className={`text-${colorClass} mb-2`}>
      <Icon icon={colorClass === 'success' ? 'mdi:trending-up' : 'mdi:trending-down'} className="me-1" />
      {title}
    </h6>
    <Table bordered size="sm" className="mb-2 table-fixed">
      <colgroup>
        <col className="col-check" /><col /><col className="col-amount" /><col className="col-remove" />
      </colgroup>
      <thead className={headerClass}>
        <tr><th className="text-center">✓</th><th>Name</th><th>Amount</th><th></th></tr>
      </thead>
      <tbody>
        {rows.map((row, i) => {
          const resolvedLKR = row.amountType === 'PERCENTAGE'
            ? resolveToLKR(row.amount, 'PERCENTAGE', grossEarningsBase) : undefined
          return (
            <tr
              key={i}
              className={!row.checked ? 'row-unchecked' : ''}
            >
              <td className="text-center align-middle">
                <Form.Check type="checkbox" checked={row.checked} onChange={(e) => onCheck(i, e.target.checked)} />
              </td>
              <td className="align-middle">
                <div className="d-flex align-items-center gap-1">
                  <FormControl
                    size="sm"
                    placeholder={colorClass === 'success' ? 'e.g. Basic Salary' : 'e.g. Tax'}
                    disabled={!row.isCustom}
                    value={row.name}
                    onChange={(e) => onUpdate(i, 'name', e.target.value)}
                  />
                  {row.isCustom && <span className="custom-item-badge">CUSTOM</span>}
                </div>
              </td>
              <td>
                <AmountCell
                  value={row.amount}
                  amountType={row.amountType}
                  disabled={!row.checked}
                  onValueChange={(val) => onUpdate(i, 'amount', val)}
                  onTypeChange={(val) => onUpdate(i, 'amountType', val)}
                  resolvedLKR={resolvedLKR}
                  currencySymbol={currencySymbol}
                />
              </td>
              <td className="text-center align-middle">
                {row.isCustom && (
                  <button onClick={() => onRemove(i)} className="btn-remove-item">
                    <Icon icon="mdi:close" />
                  </button>
                )}
              </td>
            </tr>
          )
        })}
      </tbody>
    </Table>
    <Button size="sm" variant={`outline-${colorClass}`} onClick={onAdd}>
      <Icon icon="mdi:plus" className="me-1" />{addLabel}
    </Button>
  </Col>
)

// ─── PaymentModal ──────────────────────────────────────────────────────────────
const PaymentModal = ({ show, onHide, paysheet, details, employee, detailsLoading, companyName, onPaySuccess, refetchSheets, currencySymbol }) => {
  const fmt = makeFmt(currencySymbol)
  const printRef = useRef(null)

  const [payRef, setPayRef] = useState('')
  const [adminNote, setAdminNote] = useState('')
  const [uploadedFile, setUploadedFile] = useState(null)
  const [uploadedUrl, setUploadedUrl] = useState(null)
  const [uploading, setUploading] = useState(false)
  const [emailAddr, setEmailAddr] = useState('')
  const [paying, setPaying] = useState(false)
  const [emailing, setEmailing] = useState(false)
  const [msg, setMsg] = useState(null)
  const [paymentMethods, setPaymentMethods] = useState([])
  const [payMethodId, setPayMethodId] = useState('')
  const [payMethodName, setPayMethodName] = useState('')
  const [methodsLoading, setMethodsLoading] = useState(false)
  const [bankAccounts, setBankAccounts] = useState([])
  const [selectedBankAccountId, setSelectedBankAccountId] = useState('')
  const [accountsLoading, setAccountsLoading] = useState(false)

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  const isBankTransfer = paymentMethods
    .find(m => String(m.id) === String(payMethodId))
    ?.name?.toLowerCase() === 'bank transfer'


  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: {
        'Content-Type': 'application/json',
        ...(opts.headers ?? {}),
      },
      credentials: 'include',
    })

  useEffect(() => {
    if (show) {
      setPayRef(''); setAdminNote('')
      setUploadedFile(null); setUploadedUrl(null)
      setEmailAddr(employee?.email ?? ''); setMsg(null)
      setPayMethodId(''); setPayMethodName('')
      setSelectedBankAccountId('')
      fetchPaymentMethods()
    }
  }, [show, employee])

  const fetchPaymentMethods = async () => {
    setMethodsLoading(true)
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/payment-methods`,
        {
          headers: {},
          credentials: 'include',
        }
      )
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return fetchPaymentMethods()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) throw new Error()
      const methods = await res.json()
      setPaymentMethods(Array.isArray(methods) ? methods : [])
      if (methods.length > 0) {
        setPayMethodId(String(methods[0].id))
        setPayMethodName(methods[0].name)
      }
    } catch {
      setPaymentMethods([])
    } finally {
      setMethodsLoading(false)
    }
  }

  useEffect(() => {
    if (isBankTransfer) { fetchBankAccounts() }
    else { setBankAccounts([]); setSelectedBankAccountId('') }
  }, [payMethodId, isBankTransfer])

  const fetchBankAccounts = async () => {
    setAccountsLoading(true)
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/bank-accounts`,
        {
          headers: {},
          credentials: 'include',
        }
      )
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return fetchBankAccounts()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) throw new Error()
      const accounts = await res.json()
      setBankAccounts(Array.isArray(accounts) ? accounts : [])
      if (accounts.length > 0) setSelectedBankAccountId(String(accounts[0].id))
    } catch {
      setBankAccounts([])
    } finally {
      setAccountsLoading(false)
    }
  }

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadedFile(file); setUploadedUrl(null); setUploading(true); setMsg(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('file_type', 'payslip')
      const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/emsupload/upload-ems`, {
        method: 'POST',
        headers: {},
        body: formData,
      })
      const data = await res.json()
      if (!res.ok || !data.url) throw new Error(data.error ?? 'Upload failed')
      setUploadedUrl(data.url)
      setMsg({ type: 'success', text: 'Payslip document uploaded successfully.' })
    } catch (err) {
      setMsg({ type: 'danger', text: err.message ?? 'File upload failed.' })
      setUploadedFile(null)
    } finally {
      setUploading(false)
    }
  }

  const removeUpload = () => { setUploadedFile(null); setUploadedUrl(null) }

  const handlePrint = () => {
    const html = printRef.current?.innerHTML
    if (!html) return
    const w = window.open('', '', 'width=900,height=720')
    w.document.write(`<!DOCTYPE html><html><head>
      <meta charset="utf-8"/>
      <title>Payslip — ${paysheet?.paysheet_id}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet"/>
      <style>${PRINT_CSS}</style>
    </head><body>${html}</body></html>`)
    w.document.close(); w.focus()
    setTimeout(() => { w.print(); w.close() }, 700)
  }

  const handleEmail = async () => {
    if (!emailAddr) { setMsg({ type: 'warning', text: 'Please enter an email address.' }); return }
    setEmailing(true); setMsg(null)
    try {
      const res = await authFetch(`/ems/paysheet/${paysheet.paysheet_id}/email`, {
        method: 'POST',
        body: JSON.stringify({ email: emailAddr }),
      })
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return handleEmail()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) throw new Error('Failed to send email')
      setMsg({ type: 'success', text: `Payslip emailed to ${emailAddr} successfully!` })
    } catch (e) {
      setMsg({ type: 'danger', text: e.message ?? 'Failed to send email.' })
    } finally {
      setEmailing(false)
    }
  }

  const postTransaction = async ({ netSalary, empName, monthLabel, yearLabel }) => {
    let userId = 1
    
    const accountId = isBankTransfer && selectedBankAccountId ? selectedBankAccountId : null
    if (!accountId) return

    const transactionPayload = {
      account_id: Number(accountId),
      category_id: 4,
      transaction_type: 'expense',
      note: adminNote || `EMS Payroll — ${monthLabel} ${yearLabel} salary for ${empName}`,
      by_user_id: userId,
      payer_payee_id: paysheet?.employee_id ?? null,
      log_module: 'ems',
      log_message: `Salary paid to ${empName} for ${monthLabel} ${yearLabel} — Amount: ${currencySymbol} ${Number(netSalary).toLocaleString('en-LK', { minimumFractionDigits: 2 })}`,
      amount: netSalary,
    }

    try {
      const res = await authFetch('/transaction-uploader', {
        method: 'POST',
        body: JSON.stringify(transactionPayload),
      })
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return postTransaction({ netSalary, empName, monthLabel, yearLabel })
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      const resBody = await res.json().catch(() => ({}))
      if (!res.ok) console.warn('[Transaction] Failed:', res.status, resBody)
      else console.log('[Transaction] Success:', resBody)
    } catch (err) {
      console.warn('[Transaction] Error (non-blocking):', err)
    }
  }

  const handlePay = async () => {
    if (!payRef.trim()) { setMsg({ type: 'warning', text: 'Payment reference is required.' }); return }
    if (isBankTransfer && !selectedBankAccountId) { setMsg({ type: 'warning', text: 'Please select a bank account.' }); return }

    setPaying(true); setMsg(null)
    try {
      const statusRes = await authFetch(`/ems/paysheet/${paysheet.paysheet_id}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status: 'PAID', payslip_url: uploadedUrl ?? '' }),
      })
      if (statusRes.status === 401 || statusRes.status === 403) {
        try {
          await refresh()
          return handlePay()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!statusRes.ok) throw new Error('Failed to update paysheet status')

      let userId = 1
      
      const netSalary = parseFloat(paysheet?.net_salary || 0)
      const grossEarnings = parseFloat(paysheet?.total_earnings || 0)
      const totalDeducs = parseFloat(paysheet?.total_deductions || 0)
      const empName = employee
        ? `${employee.first_name ?? ''} ${employee.last_name ?? ''}`.trim()
        : paysheet.employee_name ?? `Employee #${paysheet.employee_id}`
      const monthLabel = MONTHS[(paysheet.payroll_month ?? 1) - 1]
      const yearLabel = paysheet.payroll_year ?? new Date().getFullYear()
      const selectedMethod = paymentMethods.find(m => String(m.id) === String(payMethodId))
      const methodLabel = selectedMethod?.name ?? payMethodId
      const noteStr = adminNote
        ? `[EMS Payroll] ${monthLabel} ${yearLabel} | ${methodLabel} | ${adminNote}`
        : `[EMS Payroll] ${monthLabel} ${yearLabel} | ${methodLabel}`

      const detailRes = await authFetch(`/ems/paysheet-details/${paysheet.paysheet_id}`)
      if (detailRes.status === 401 || detailRes.status === 403) {
        try {
          await refresh()
          return handlePay()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      let firstDetailId = null
      if (detailRes.ok) {
        const detailData = await detailRes.json()
        const detailsList = Array.isArray(detailData) ? detailData : (detailData?.data ?? [])
        if (detailsList.length > 0) firstDetailId = detailsList[0].paysheet_detail_id
      }

      const invoicePayload = {
        paysheet_detail_id: firstDetailId,
        payment_reference: payRef.trim(),
        paid_by: userId ? String(userId) : (empName ?? 'Admin'),
        payment_status: 'PAID',
        admin_note: noteStr,
        payslip_url: uploadedUrl ?? null,
        account_id: (isBankTransfer && selectedBankAccountId) ? Number(selectedBankAccountId) : null,
        account_name: isBankTransfer
          ? bankAccounts.find(a => String(a.id) === String(selectedBankAccountId))?.name ?? null
          : null,
        bank_account: isBankTransfer,
        payment_method: payMethodName,
      }

      const paysheetInvoiceRes = await authFetch('/ems/paysheet-invoices', {
        method: 'POST', body: JSON.stringify(invoicePayload),
      })
      if (paysheetInvoiceRes.status === 401 || paysheetInvoiceRes.status === 403) {
        try {
          await refresh()
          return handlePay()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!paysheetInvoiceRes.ok) {
        const errBody = await paysheetInvoiceRes.json().catch(() => ({}))
        console.warn('Paysheet invoice creation warning:', errBody)
      }

      const invoicePayloadHeader = {
        total_value: netSalary, full_amount: grossEarnings, amount_paid: netSalary,
        discount: totalDeducs, delivery_fee: 0, balance: 0,
        loyalty_points_earned: 0, loyalty_points_spent: 0, total_item: 1, total_weight: 0,
        payment_status: 'PAID', order_status: 'COMPLETED', currency: currencySymbol ?? 'LKR',
        paid_at: new Date().toISOString(),
        payment_method_id: payMethodId || null,
        payment_reference: payRef.trim(), note: noteStr,
        bank_slip: uploadedUrl ?? null,
        bank_account_id: (isBankTransfer && selectedBankAccountId) ? selectedBankAccountId : null,
        sender_name: empName, sender_email: employee?.email ?? null,
        sender_phone: employee?.contact_no ?? employee?.mobile_number ?? null,
        sender_address: employee?.address ?? null, sender_city: employee?.city ?? null,
        sender_country: employee?.country ?? null, sender_postal_code: null,
        user_id: userId, interface: 'ems_payroll',
        payments: JSON.stringify([{
          method: methodLabel, reference: payRef.trim(), amount: netSalary,
          date: new Date().toISOString().split('T')[0],
          paysheet_id: paysheet.paysheet_id, employee_id: paysheet.employee_id,
          employee_name: empName, payroll_month: paysheet.payroll_month,
          payroll_year: paysheet.payroll_year, pay_period: `${monthLabel} ${yearLabel}`,
          gross_earnings: grossEarnings, total_deductions: totalDeducs,
          bank_account_id: (isBankTransfer && selectedBankAccountId) ? selectedBankAccountId : null,
        }]),
      }

      const invoiceRes = await authFetch('/invoice-headers', {
        method: 'POST', body: JSON.stringify(invoicePayloadHeader),
      })
      if (invoiceRes.status === 401 || invoiceRes.status === 403) {
        try {
          await refresh()
          return handlePay()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!invoiceRes.ok) {
        const errBody = await invoiceRes.json().catch(() => ({}))
        console.warn('Invoice header creation warning:', errBody)
      }

      await postTransaction({ netSalary, empName, monthLabel, yearLabel })

      setMsg({ type: 'success', text: `Payment processed! Reference: ${payRef}. Paysheet marked as PAID.` })
      setTimeout(() => { onHide(); onPaySuccess?.(); refetchSheets?.() }, 2200)
    } catch (e) {
      setMsg({ type: 'danger', text: e.message ?? 'Payment failed. Please try again.' })
    } finally {
      setPaying(false)
    }
  }

  const month = paysheet?.payroll_month ? MONTHS[paysheet.payroll_month - 1] : '—'
  const year = paysheet?.payroll_year ?? '—'
  const netSal = parseFloat(paysheet?.net_salary || 0)
  const isPaid = (paysheet?.payroll_status ?? '') === 'PAID'

  return (
    <Modal show={show} onHide={onHide} size="xl" centered dialogClassName="pay-modal-dlg">
      {/* No <style> block — all styles are in payslip-print.css */}
      <Modal.Header closeButton>
        <Modal.Title>
          <Icon icon="mdi:cash-check" className="me-2" />
          Process Payment
          <span className="pay-modal-period">
            &nbsp;·&nbsp; #{paysheet?.paysheet_id} &nbsp;·&nbsp; {month} {year}
          </span>
          {isPaid && (
            <span className="pay-status-pill paid ms-2">
              <Icon icon="mdi:check-circle" /> PAID
            </span>
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body className="p-0">
        <Row className="m-0">
          {/* Left — payslip preview */}
          <Col md={7} className="p-0">
            <div className="pay-slip-pane">
              {detailsLoading ? (
                <div className="d-flex justify-content-center align-items-center" style={{ minHeight: 300 }}>
                  <Spinner animation="border" variant="primary" />
                  <span className="ms-3 text-muted">Loading payslip…</span>
                </div>
              ) : (
                <div ref={printRef}>
                  <PayslipDocument
                    paysheet={paysheet}
                    details={details}
                    employee={employee}
                    companyName={companyName}
                    currencySymbol={currencySymbol}
                  />
                </div>
              )}
            </div>
          </Col>

          {/* Right — payment form */}
          <Col md={5} className="p-0">
            <div className="pay-form-pane">
              {msg && <Alert variant={msg.type} className="mb-3 py-2 small">{msg.text}</Alert>}

              {/* Net Payable */}
              <div className="pay-net-card">
                <div className="pnc-label">Net Payable</div>
                <div className="pnc-amount">
                  {currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                </div>
                <div className="pnc-sub">{numberToWords(Math.floor(netSal))} {currencySymbol} Only</div>
              </div>

              {/* Quick Actions */}
              <div className="pay-section-title">Quick Actions</div>
              <div className="pay-tool-row">
                <button className="pay-tool-btn print" onClick={handlePrint} disabled={detailsLoading}>
                  <Icon icon="mdi:printer-outline" /> Download PDF
                </button>
                <button className="pay-tool-btn email" onClick={handleEmail} disabled={emailing || !emailAddr}>
                  {emailing
                    ? <><Spinner size="sm" className="me-1" style={{ width: 12, height: 12 }} /> Sending…</>
                    : <><Icon icon="mdi:email-send-outline" /> Email Payslip</>}
                </button>
              </div>

              {/* Email */}
              <div className="mt-2">
                <label className="form-label-xs">Email Address</label>
                <FormControl
                  size="sm" type="email" placeholder="employee@company.com"
                  value={emailAddr} onChange={e => setEmailAddr(e.target.value)}
                />
              </div>

              {/* Payment Details */}
              <div className="pay-section-title">Payment Details</div>

              <FormGroup className="mb-2">
                <label className="form-label-xs">Payment Method *</label>
                {methodsLoading ? (
                  <div className="d-flex align-items-center gap-2 py-1">
                    <Spinner size="sm" variant="primary" style={{ width: 14, height: 14 }} />
                    <span className="text-muted small">Loading payment methods…</span>
                  </div>
                ) : (
                  <FormSelect
                    size="sm"
                    value={payMethodId}
                    onChange={e => {
                      const selected = paymentMethods.find(m => String(m.id) === e.target.value)
                      setPayMethodId(e.target.value)
                      setPayMethodName(selected?.name ?? '')
                      setSelectedBankAccountId('')
                    }}
                    disabled={isPaid}
                  >
                    <option value="">— Select Payment Method —</option>
                    {paymentMethods.map(m => (
                      <option key={m.id} value={String(m.id)}>{m.name}</option>
                    ))}
                  </FormSelect>
                )}
              </FormGroup>

              {isBankTransfer && (
                <div className="pay-bank-account-box mb-2">
                  <div className="pba-title">
                    <Icon icon="mdi:bank-outline" /> Select Bank Account
                  </div>
                  {accountsLoading ? (
                    <div className="d-flex align-items-center gap-2">
                      <Spinner size="sm" variant="primary" style={{ width: 14, height: 14 }} />
                      <span className="text-muted small">Loading bank accounts…</span>
                    </div>
                  ) : bankAccounts.length === 0 ? (
                    <div className="text-danger small d-flex align-items-center gap-1">
                      <Icon icon="mdi:alert-outline" />
                      No bank accounts found. Please add one in Accounts.
                    </div>
                  ) : (
                    <FormSelect
                      size="sm"
                      value={selectedBankAccountId}
                      onChange={e => setSelectedBankAccountId(e.target.value)}
                      disabled={isPaid}
                    >
                      <option value="">— Select Bank Account —</option>
                      {bankAccounts.map(acc => (
                        <option key={acc.id} value={String(acc.id)}>
                          {acc.name}
                          {acc.balance !== undefined
                            ? ` — ${currencySymbol} ${Number(acc.balance).toLocaleString('en-LK', { minimumFractionDigits: 2 })}`
                            : ''}
                        </option>
                      ))}
                    </FormSelect>
                  )}
                </div>
              )}

              <FormGroup className="mb-2">
                <label className="form-label-xs">Payment Reference *</label>
                <FormControl
                  size="sm" placeholder="e.g. TXN-20240301-001 or Cheque #12345"
                  value={payRef} onChange={e => setPayRef(e.target.value)} disabled={isPaid}
                />
                <div className="text-muted mt-1" style={{ fontSize: 10.5 }}>
                  Transaction ID, cheque number, or payment receipt number
                </div>
              </FormGroup>

              <FormGroup className="mb-3">
                <label className="form-label-xs">Admin Note</label>
                <FormControl
                  as="textarea" rows={3} size="sm"
                  placeholder="Optional internal note about this payment…"
                  value={adminNote} onChange={e => setAdminNote(e.target.value)}
                  disabled={isPaid} className="resize-none"
                />
                <div className="text-muted mt-1" style={{ fontSize: 10.5 }}>
                  This note will be included in the transaction log
                </div>
              </FormGroup>

              {/* Upload */}
              <div className="pay-section-title">Upload Payslip Document</div>
              <label className={`pay-upload-zone${uploading ? ' uploading-state' : ''}`}>
                <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} disabled={uploading} />
                {uploading ? (
                  <div className="d-flex align-items-center gap-2 justify-content-center">
                    <Spinner size="sm" variant="primary" />
                    <span className="text-primary fw-semibold small">Uploading to S3…</span>
                  </div>
                ) : uploadedUrl ? (
                  <div className="d-flex align-items-center gap-2 justify-content-center">
                    <Icon icon="mdi:cloud-check-outline" className="text-success fs-4" />
                    <span className="fw-semibold text-success small">Uploaded — click to replace</span>
                  </div>
                ) : (
                  <>
                    <div className="puz-icon"><Icon icon="mdi:cloud-upload-outline" /></div>
                    <div className="puz-text">Click to upload payslip</div>
                    <div className="puz-sub">PDF, JPG, PNG — max 10 MB · Saved to S3</div>
                  </>
                )}
              </label>

              {uploadedFile && (
                <div className="pay-file-chip">
                  <Icon icon="mdi:file-pdf-box" className="text-danger fs-5" />
                  <span className="pfc-name">{uploadedFile.name}</span>
                  {uploadedUrl && (
                    <a href={uploadedUrl} target="_blank" rel="noreferrer" className="pfc-s3-link">
                      <Icon icon="mdi:open-in-new" /> View
                    </a>
                  )}
                  <button className="pfc-remove" onClick={removeUpload} disabled={uploading}>
                    <Icon icon="mdi:close-circle" />
                  </button>
                </div>
              )}

              {/* Info note */}
              <div className="info-note">
                <Icon icon="mdi:information-outline" className="flex-shrink-0 mt-1" />
                <span>
                  Clicking <strong>Pay</strong> will mark this paysheet as <strong>PAID</strong>,
                  save the payslip to S3 (if uploaded), create an <strong>invoice_header</strong> record,
                  and post an <strong>expense transaction</strong> to the selected account.
                </span>
              </div>
            </div>
          </Col>
        </Row>
      </Modal.Body>

      <Modal.Footer className="justify-content-between">
        <small className="text-muted">
          Paysheet <strong>#{paysheet?.paysheet_id}</strong>
          &nbsp;·&nbsp; Period: <strong>{month} {year}</strong>
          &nbsp;·&nbsp; Net: <strong>{currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</strong>
        </small>
        <div className="d-flex gap-2 align-items-center">
          <Button variant="outline-secondary" onClick={onHide}>Close</Button>
          {isPaid ? (
            <button className="pay-action-btn already-paid" disabled>
              <Icon icon="mdi:check-circle" /> Already Paid
            </button>
          ) : (
            <button
              className="pay-action-btn"
              onClick={handlePay}
              disabled={paying || !payRef.trim() || uploading || (isBankTransfer && !selectedBankAccountId)}
            >
              {paying
                ? <><Spinner size="sm" style={{ width: 16, height: 16 }} /> Processing…</>
                : <><Icon icon="mdi:cash-check" /> Pay {currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</>}
            </button>
          )}
        </div>
      </Modal.Footer>
    </Modal>
  )
}

// ─── Week helpers ──────────────────────────────────────────────────────────────
function getWeeksInMonth(year, month) {
  const firstDay = new Date(year, month - 1, 1)
  const lastDay = new Date(year, month, 0)
  const weeks = []
  let cursor = new Date(firstDay)
  const dow = cursor.getDay()
  const diff = dow === 0 ? -6 : 1 - dow
  cursor.setDate(cursor.getDate() + diff)
  let weekNum = 1
  while (cursor <= lastDay) {
    const start = new Date(cursor)
    const end = new Date(cursor)
    end.setDate(end.getDate() + 6)
    const overlapStart = start < firstDay ? firstDay : start
    const overlapEnd = end > lastDay ? lastDay : end
    const fmtDate = (d) => d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })
    weeks.push({
      label: `Week ${weekNum} · ${fmtDate(overlapStart)} – ${fmtDate(overlapEnd)}`,
      weekStart: toDateStr(start),
      weekEnd: toDateStr(end),
      rangeStart: toDateStr(overlapStart),
      rangeEnd: toDateStr(overlapEnd),
      weekNum,
    })
    cursor.setDate(cursor.getDate() + 7)
    weekNum++
  }
  return weeks
}

const toDateStr = (d) => {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// ─── WeekDayStrip — uses CSS classes instead of inline styles ─────────────────
const WeekDayStrip = ({ weekStart, month, year }) => {
  const days = []
  const cursor = new Date(weekStart + 'T00:00:00')
  const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  for (let i = 0; i < 7; i++) {
    const d = new Date(cursor)
    d.setDate(cursor.getDate() + i)
    const inMonth = d.getMonth() + 1 === month && d.getFullYear() === year
    days.push({ date: d.getDate(), label: DAY_LABELS[i], inMonth })
  }
  return (
    <div className="week-day-strip">
      {days.map((d, i) => (
        <div key={i} className={`week-day-cell ${d.inMonth ? 'in-month' : 'out-of-month'}`}>
          <span className="week-day-label">{d.label}</span>
          <span className="week-day-number">{d.date}</span>
        </div>
      ))}
    </div>
  )
}

// ─── PayrollPeriodSelector ─────────────────────────────────────────────────────
const PayrollPeriodSelector = ({
  payrollType, month, setMonth, year, setYear,
  selectedDate, setSelectedDate, selectedWeek, setSelectedWeek, years,
}) => {
  const type = (payrollType || 'MONTHLY').toUpperCase()
  const weeks = useMemo(() => {
    if (type !== 'WEEKLY' || !month || !year) return []
    return getWeeksInMonth(Number(year), Number(month))
  }, [type, month, year])
  useEffect(() => { setSelectedWeek(null) }, [month, year])

  if (type === 'DAILY') return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Date</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>
            Date <span className="text-danger">*</span>
            <Badge bg="info" text="dark" className="ms-2 small">DAILY</Badge>
          </FormLabel>
          <FormControl type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} />
          {selectedDate && (
            <div className="text-muted mt-1 small">
              Payroll for: <strong>
                {new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })}
              </strong>
            </div>
          )}
        </Col>
        <Col md={6}>
          <FormLabel>Day of Week</FormLabel>
          <FormControl
            readOnly className="bg-light" placeholder="Auto-filled"
            value={selectedDate ? new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'long' }) : ''}
          />
        </Col>
      </Row>
    </>
  )

  if (type === 'WEEKLY') return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Period</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>
            Month <span className="text-danger">*</span>
            <Badge bg="warning" text="dark" className="ms-2 small">WEEKLY</Badge>
          </FormLabel>
          <FormSelect value={month} onChange={e => setMonth(e.target.value)}>
            <option value="">— Select Month —</option>
            {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
          </FormSelect>
        </Col>
        <Col md={6}>
          <FormLabel>Year <span className="text-danger">*</span></FormLabel>
          <FormSelect value={year} onChange={e => setYear(e.target.value)}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </FormSelect>
        </Col>
      </Row>
      {month && year && (
        <div className="mt-3">
          <FormLabel>Select Week <span className="text-danger">*</span></FormLabel>
          <div className="d-flex flex-column gap-2">
            {weeks.map((w) => {
              const isSelected = selectedWeek?.weekNum === w.weekNum
              return (
                <button
                  key={w.weekNum} type="button"
                  onClick={() => setSelectedWeek(w)}
                  className={`week-btn ${isSelected ? 'selected' : ''}`}
                >
                  <div className="d-flex justify-content-between align-items-center">
                    <span className="week-btn-label">{w.label}</span>
                    {isSelected && <Icon icon="mdi:check-circle" className="text-success fs-5" />}
                  </div>
                  <WeekDayStrip weekStart={w.weekStart} month={Number(month)} year={Number(year)} />
                </button>
              )
            })}
          </div>
          {selectedWeek && (
            <div className="week-range-note">
              Salary range: <strong>{selectedWeek.rangeStart}</strong> → <strong>{selectedWeek.rangeEnd}</strong>
            </div>
          )}
        </div>
      )}
    </>
  )

  return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Period</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>
            Month <span className="text-danger">*</span>
            <Badge bg="secondary" className="ms-2 small">MONTHLY</Badge>
          </FormLabel>
          <FormSelect value={month} onChange={e => setMonth(e.target.value)}>
            <option value="">— Select Month —</option>
            {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
          </FormSelect>
        </Col>
        <Col md={6}>
          <FormLabel>Year <span className="text-danger">*</span></FormLabel>
          <FormSelect value={year} onChange={e => setYear(e.target.value)}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </FormSelect>
        </Col>
      </Row>
    </>
  )
}

// ─── GenerateWizardModal ───────────────────────────────────────────────────────
const GenerateWizardModal = ({ show, onHide, employees, onSuccess, currencySymbol }) => {
  const fmt = makeFmt(currencySymbol)
  const cy = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => cy - 2 + i)

  const [step, setStep] = useState(1)
  const [empId, setEmpId] = useState('')
  const [month, setMonth] = useState('')
  const [year, setYear] = useState(String(cy))
  const [selectedDate, setSelectedDate] = useState('')
  const [selectedWeek, setSelectedWeek] = useState(null)
  const [payrollType, setPayrollType] = useState('MONTHLY')
  const [msg, setMsg] = useState(null)
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(false)
  const [earnings, setEarnings] = useState([])
  const [deductions, setDeductions] = useState([])

  const [pendingLeaves, setPendingLeaves] = useState([])
  const [pendingChecked, setPendingChecked] = useState(false)
  const [generateAnyway, setGenerateAnyway] = useState(false)
  const [showAnywayCfm, setShowAnywayCfm] = useState(false)

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  const [autoCalc, setAutoCalc] = useState({
    normalOtHours: 0, holidayOtHours: 0, earlyOtHours: 0,
    normalOtAmount: 0, holidayOtAmount: 0, earlyOtAmount: 0,
    noPayAmount: 0, lateDeductionAmount: 0, absentDays: 0,
    unpaidLeaveDays: 0, lateNoPayDays: 0, totalNoPayDays: 0,
    otHourRate: 0, holidayOtRate: 0, noPayRate: 0, lateCount: 0, loaded: false,
  })

  
  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: {
        'Content-Type': 'application/json', ...(opts.headers ?? {})
      },
      credentials: 'include',
    })

  const selectedEmp = employees.find(e => String(e.employee_id) === String(empId))

  const salaryRange = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY') return selectedDate ? { start: selectedDate, end: selectedDate } : null
    if (type === 'WEEKLY') return selectedWeek ? { start: selectedWeek.weekStart, end: selectedWeek.weekEnd } : null
    if (!month || !year) return null
    const m = Number(month), y = Number(year)
    const start = `${y}-${String(m).padStart(2, '0')}-01`
    const lastDay = new Date(y, m, 0).getDate()
    return { start, end: `${y}-${String(m).padStart(2, '0')}-${lastDay}` }
  }, [payrollType, month, year, selectedDate, selectedWeek])

  const periodLabel = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY' && selectedDate) return new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })
    if (type === 'WEEKLY' && selectedWeek) return selectedWeek.label
    if (month && year) return `${MONTHS[Number(month) - 1]} ${year}`
    return '—'
  }, [payrollType, month, year, selectedDate, selectedWeek])

  const isPeriodValid = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY') return !!selectedDate
    if (type === 'WEEKLY') return !!month && !!year && !!selectedWeek
    return !!month && !!year
  }, [payrollType, month, year, selectedDate, selectedWeek])

  useEffect(() => {
    if (show) {
      setStep(1); setEmpId(''); setMonth(''); setYear(String(cy))
      setSelectedDate(''); setSelectedWeek(null); setPayrollType('MONTHLY')
      setMsg(null); setBusy(false); setEarnings([]); setDeductions([])
      setAutoCalc({ normalOtHours: 0, holidayOtHours: 0, earlyOtHours: 0, normalOtAmount: 0, holidayOtAmount: 0, earlyOtAmount: 0, noPayAmount: 0, lateDeductionAmount: 0, absentDays: 0, unpaidLeaveDays: 0, lateNoPayDays: 0, totalNoPayDays: 0, otHourRate: 0, holidayOtRate: 0, noPayRate: 0, lateCount: 0, loaded: false })
      setPendingLeaves([]); setPendingChecked(false); setGenerateAnyway(false); setShowAnywayCfm(false)
    }
  }, [show])

  const fixedEarningsBase = useMemo(() =>
    earnings.filter(e => e.checked && e.amountType === 'LKR').reduce((s, r) => s + (parseFloat(r.amount) || 0), 0), [earnings])

  const grossEarnings = useMemo(() =>
    earnings.filter(e => e.checked).reduce((s, r) => s + resolveToLKR(r.amount, r.amountType, fixedEarningsBase), 0), [earnings, fixedEarningsBase])

  const totalDeductions = useMemo(() =>
    deductions.filter(d => d.checked).reduce((s, r) => s + resolveToLKR(r.amount, r.amountType, grossEarnings), 0), [deductions, grossEarnings])

  const estTotalEarnings = grossEarnings + autoCalc.normalOtAmount + autoCalc.earlyOtAmount + autoCalc.holidayOtAmount
  const estTotalDeductions = totalDeductions + autoCalc.noPayAmount + autoCalc.lateDeductionAmount
  const estNetSalary = estTotalEarnings - estTotalDeductions

  const handleNext = async () => {
    if (!empId) { setMsg({ type: 'danger', text: 'Please select an employee.' }); return }
    if (!isPeriodValid) {
      const type = (payrollType || 'MONTHLY').toUpperCase()
      setMsg({ type: 'danger', text: type === 'DAILY' ? 'Please select a date.' : type === 'WEEKLY' ? 'Please select a month, year and week.' : 'Please select a month and year.' })
      return
    }
    setMsg(null); setLoading(true)
    try {
      const { start, end } = salaryRange
      const rangeDate = new Date(start + 'T00:00:00')
      const pMonth = rangeDate.getMonth() + 1
      const pYear = rangeDate.getFullYear()
      const empRes = await authFetch(`/ems/employees/${empId}`)

      if (empRes.status === 401 || empRes.status === 403) {
        try {
          await refresh()
          return handleNext()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!empRes.ok) throw new Error('Failed to fetch employee')
      const empData = await empRes.json()
      const templateId = empData?.payroll_template_id
      if (!templateId) { setMsg({ type: 'warning', text: 'This employee has no payroll template assigned.' }); return }

      const empGenType = empData?.salary_generation_type ?? 'MANUAL'
      if (empGenType === 'AUTO') {
        setMsg({ type: 'warning', text: `${empData.first_name} ${empData.last_name} is set to AUTO paysheet generation. Manual generation is disabled.` })
        setLoading(false); return
      }

      const tplRes = await authFetch(`/ems/payroll-templates/${templateId}`)
      if (tplRes.status === 401 || tplRes.status === 403) {
        try {
          await refresh()
          return handleNext()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!tplRes.ok) throw new Error('Failed to fetch payroll template')
      const tplData = await tplRes.json()
      setPayrollType((tplData?.payroll_type ?? 'MONTHLY').toUpperCase())

      const otHourRate = Number(tplData?.ot_hour_rate) || 0
      const holidayOtRate = Number(tplData?.holiday_ot_hour_rate) || 0
      const noPayRate = Number(tplData?.no_pay_deduction_rate) || 0

      const detRes = await authFetch(`/ems/payroll-template/${templateId}`)
      if (detRes.status === 401 || detRes.status === 403) {
        try {
          await refresh()
          return handleNext()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!detRes.ok) throw new Error('Failed to fetch template details')
      const detData = await detRes.json()
      const rows = Array.isArray(detData) ? detData : (detData?.data ?? [])
      if (rows.length === 0) { setMsg({ type: 'warning', text: 'This payroll template has no earnings or deductions configured.' }); return }

      const getName = (r) => r.earning_deduction_name ?? r.ed_master_name ?? r.name ?? '—'
      const buildRow = (r) => {
        const storedValue = Number(r.value ?? 0)
        const storedAmount = Number(r.amount ?? 0)
        const isPercent = storedValue > 0 && storedAmount === 0
        return {
          earning_deduction_id: r.earning_deduction_id ?? null,
          name: getName(r),
          amount: isPercent ? String(storedValue) : String(storedAmount),
          amountType: isPercent ? 'PERCENTAGE' : 'LKR',
          checked: true, isCustom: false,
        }
      }
      setEarnings(rows.filter(r => ['EARNING', 'EARNINGS'].includes((r.type ?? '').toUpperCase())).map(buildRow))
      setDeductions(rows.filter(r => ['DEDUCTION', 'DEDUCTIONS'].includes((r.type ?? '').toUpperCase())).map(buildRow))

      let attData = {}
      try {
        const attRes = await authFetch(`/ems/attendance-summary?employee_id=${empId}&start=${start}&end=${end}`)
        if (attRes.status === 401 || attRes.status === 403) {
          try {
            await refresh()
            return handleNext()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        }
        if (attRes.ok) attData = await attRes.json()
      } catch { /* graceful */ }

      const normalOtHours = Number(attData.normal_overtime_minutes || 0) / 60
      const holidayOtHours = Number(attData.holiday_overtime_minutes || 0) / 60
      const earlyOtHours = Number(attData.early_overtime_minutes || 0) / 60
      const absentDays = Number(attData.absent_days || 0)
      const unpaidLeaveDays = Number(attData.unpaid_leave_days || 0)
      const lateCount = Number(attData.late_count || 0)
      const lateNoPayDays = Math.floor(lateCount / 3)
      const noPayOnlyDays = absentDays + unpaidLeaveDays

      setAutoCalc({
        normalOtHours, holidayOtHours, earlyOtHours,
        normalOtAmount: parseFloat((normalOtHours * otHourRate).toFixed(2)),
        holidayOtAmount: parseFloat((holidayOtHours * holidayOtRate).toFixed(2)),
        earlyOtAmount: parseFloat((earlyOtHours * otHourRate).toFixed(2)),
        noPayAmount: parseFloat((noPayOnlyDays * noPayRate).toFixed(2)),
        lateDeductionAmount: parseFloat((lateNoPayDays * noPayRate).toFixed(2)),
        absentDays, unpaidLeaveDays, lateNoPayDays,
        totalNoPayDays: absentDays + unpaidLeaveDays + lateNoPayDays,
        otHourRate, holidayOtRate, noPayRate, lateCount, loaded: true,
      })

      try {
        if (salaryRange?.start && salaryRange?.end) {
          const pendingRes = await authFetch(
            `/ems/leaves/query?employee_id=${empId}&status=Pending&from_date=${salaryRange.start}&to_date=${salaryRange.end}`
          )
          if (pendingRes.status === 401 || pendingRes.status === 403) {
            try {
              await refresh()
              return handleNext()
            } catch (refreshError) {
              console.error('Error refreshing token:', refreshError)
              Logout()
            }
          }
          if (pendingRes.ok) {
            const pendingData = await pendingRes.json()
            setPendingLeaves(Array.isArray(pendingData) ? pendingData : [])
          }
        }
      } catch { /* non-blocking */ }

      setPendingChecked(true); setGenerateAnyway(false); setShowAnywayCfm(false)
      setStep(2)
    } catch (err) {
      setMsg({ type: 'danger', text: err.message ?? 'Failed to load template details.' })
    } finally { setLoading(false) }
  }

  const handleGenerate = async () => {
    setMsg(null); setBusy(true)
    try {
      const { start, end } = salaryRange
      const rangeDate = new Date(start + 'T00:00:00')
      const pMonth = rangeDate.getMonth() + 1
      const pYear = rangeDate.getFullYear()

      const earningItems = earnings.filter(e => e.checked && e.name).map(e => {
        const lkr = resolveToLKR(e.amount, e.amountType, fixedEarningsBase)
        return lkr > 0 ? { earning_deduction_id: e.earning_deduction_id ?? null, name: e.name, type: 'EARNINGS', amount: parseFloat(lkr.toFixed(2)) } : null
      }).filter(Boolean)

      const deductionItems = deductions.filter(d => d.checked && d.name).map(d => {
        const lkr = resolveToLKR(d.amount, d.amountType, grossEarnings)
        return lkr > 0 ? { earning_deduction_id: d.earning_deduction_id ?? null, name: d.name, type: 'DEDUCTIONS', amount: parseFloat(lkr.toFixed(2)) } : null
      }).filter(Boolean)

      const calcEarnings = earningItems.reduce((s, r) => s + r.amount, 0)
      const calcDeductions = deductionItems.reduce((s, r) => s + r.amount, 0)

      const payload = {
        employee_id: Number(empId), payroll_month: pMonth, payroll_year: pYear,
        salary_range_start: start, salary_range_end: end,
        total_earnings: calcEarnings, total_deductions: calcDeductions,
        net_salary: calcEarnings - calcDeductions,
        line_items: [...earningItems, ...deductionItems],
      }

      const res = await authFetch('/ems/paysheet', { method: 'POST', body: JSON.stringify(payload) })
      console.log(res)
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return handleGenerate()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) { const e = await res.json(); throw new Error(e?.message ?? 'Generation failed') }
      const result = await res.json()

      const extras = []
      if (result.normal_ot_amount > 0) extras.push(`Normal OT +${currencySymbol} ${fmt(result.normal_ot_amount)}`)
      if (result.early_ot_amount > 0) extras.push(`Early OT +${currencySymbol} ${fmt(result.early_ot_amount)}`)
      if (result.holiday_ot_amount > 0) extras.push(`Holiday OT +${currencySymbol} ${fmt(result.holiday_ot_amount)}`)
      if (result.no_pay_amount > 0) extras.push(`No-Pay −${currencySymbol} ${fmt(result.no_pay_amount)}`)
      if (result.late_deduction_amount > 0) extras.push(`Late Deduction −${currencySymbol} ${fmt(result.late_deduction_amount)}`)

      setMsg({ type: 'success', text: `Paysheet for ${periodLabel} generated! Net: ${currencySymbol} ${fmt(result.net_salary)}${extras.length ? ' · ' + extras.join(' · ') : ''}` })
      setTimeout(() => { onHide(); onSuccess?.() }, 2400)
    } catch (e) {
      setMsg({ type: 'danger', text: e?.message ?? 'Failed to generate paysheet.' })
    } finally { setBusy(false) }
  }

  const makeUpdater = (setter) => (idx, field, val) =>
    setter(prev => prev.map((item, i) => i === idx ? { ...item, [field]: val } : item))
  const updE = makeUpdater(setEarnings)
  const updD = makeUpdater(setDeductions)
  const addEarning = () => setEarnings(p => [...p, { earning_deduction_id: null, name: '', amount: '', amountType: 'LKR', checked: true, isCustom: true }])
  const addDeduction = () => setDeductions(p => [...p, { earning_deduction_id: null, name: '', amount: '', amountType: 'LKR', checked: true, isCustom: true }])
  const removeEarning = (idx) => setEarnings(p => p.filter((_, i) => i !== idx))
  const removeDeduction = (idx) => setDeductions(p => p.filter((_, i) => i !== idx))

  const handleEmployeeChange = async (newEmpId) => {
    setEmpId(newEmpId)
    setMsg(null)

    setMonth('')
    setSelectedDate('')
    setSelectedWeek(null)
    setPayrollType('MONTHLY')

    if (!newEmpId) return
    try {
      console.log("hii")

      const empRes = await authFetch(`/ems/employees/${newEmpId}`)
      if (empRes.status === 401 || empRes.status === 403) {
        try {
          await refresh()
          return handleEmployeeChange(newEmpId)
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!empRes.ok) return
      const empData = await empRes.json()
      const templateId = empData?.payroll_template_id
      if (!templateId) return
      const tplRes = await authFetch(`/ems/payroll-templates/${templateId}`)
      if (tplRes.status === 401 || tplRes.status === 403) {
        try {
          await refresh()
          return handleEmployeeChange(newEmpId)
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!tplRes.ok) return
      const tplData = await tplRes.json()
      setPayrollType((tplData?.payroll_type ?? 'MONTHLY').toUpperCase())
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <Modal show={show} onHide={onHide} size="xl" centered scrollable>
      {/* No <style> tag — all classes are defined in payslip-print.css */}
      <Modal.Header closeButton>
        <Modal.Title className="d-flex align-items-center gap-2">
          Generate Paysheet
          {step === 2 && (
            <span className={`gw-type-pill ${(payrollType || 'MONTHLY').toUpperCase()}`}>
              <Icon icon={payrollType === 'DAILY' ? 'mdi:calendar-today' : payrollType === 'WEEKLY' ? 'mdi:calendar-week' : 'mdi:calendar-month'} />
              {(payrollType || 'MONTHLY').toUpperCase()}
            </span>
          )}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="px-2 pt-2">
          {/* Progress bar */}
          <div className="gw-progress-wrap">
            {[1, 2].map((s) => {
              const labels = ['Employee & Period', 'Earnings & Deductions']
              const isCompleted = step > s
              const isActive = step === s
              return (
                <React.Fragment key={s}>
                  {s > 1 && (
                    <div className="gw-connector">
                      <div className={`gw-connector-fill ${isCompleted ? 'filled' : ''}`} />
                    </div>
                  )}
                  <div className={`gw-step-node ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`}>
                    <div className="gw-step-circle">
                      {isCompleted ? <Icon icon="solar:check-circle-bold" /> : s}
                    </div>
                    <span className="gw-step-label">{labels[s - 1]}</span>
                  </div>
                </React.Fragment>
              )
            })}
          </div>

          {msg && <Alert variant={msg.type} className="mb-3">{msg.text}</Alert>}

          {/* ── Step 1 ── */}
          {step === 1 && (
            <div className="gw-fade">
              <h6 className="gw-section-divider"><span>Select Employee</span></h6>
              <Row className="g-3 my-0">
                <Col md={12}>
                  <FormLabel>Employee <span className="text-danger">*</span></FormLabel>
                  <FormSelect value={empId} onChange={e => handleEmployeeChange(e.target.value)}>
                    <option value="">— Select Employee —</option>
                    {employees.map(e => (
                      <option key={e.employee_id} value={e.employee_id}>
                        {e.first_name} {e.last_name} · #{e.employee_id}
                      </option>
                    ))}
                  </FormSelect>
                </Col>
                <Col md={6}>
                  <FormLabel>Employee ID</FormLabel>
                  <FormControl readOnly className="bg-light" placeholder="Auto-filled"
                    value={selectedEmp ? `EMP-${String(selectedEmp.employee_id).padStart(4, '0')}` : ''} />
                </Col>
                <Col md={6}>
                  <FormLabel>Department</FormLabel>
                  <FormControl readOnly className="bg-light" placeholder="Auto-filled"
                    value={selectedEmp?.department_name ?? ''} />
                </Col>
              </Row>

              <PayrollPeriodSelector
                payrollType={payrollType}
                month={month} setMonth={setMonth}
                year={year} setYear={setYear}
                selectedDate={selectedDate} setSelectedDate={setSelectedDate}
                selectedWeek={selectedWeek} setSelectedWeek={setSelectedWeek}
                years={years}
              />

              {selectedEmp && (
                <>
                  <h6 className="gw-section-divider"><span>Employee Details</span></h6>
                  <div className="border rounded p-3 bg-light">
                    <Row className="g-2">
                      {[
                        ['Name', `${selectedEmp.first_name} ${selectedEmp.last_name ?? ''}`],
                        ['Designation', selectedEmp.designation_name ?? '—'],
                        ['Department', selectedEmp.department_name ?? '—'],
                        ['Template', selectedEmp.payroll_template_name ?? 'Not assigned'],
                      ].map(([label, value]) => (
                        <Col md={3} key={label}>
                          <small className="text-muted d-block text-uppercase fw-semibold" style={{ fontSize: '0.7rem', letterSpacing: '0.5px' }}>{label}</small>
                          <span className="fw-semibold">{value}</span>
                        </Col>
                      ))}
                    </Row>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ── Step 2 ── */}
          {step === 2 && (
            <div className="gw-fade">

              {/* Pending leave warning */}
              {pendingChecked && pendingLeaves.length > 0 && !generateAnyway && (
                <div className="mb-3">
                  <div className="pending-leave-warning">
                    <div className="d-flex gap-2 mb-2">
                      <Icon icon="mdi:clock-alert-outline" width={16} className="flex-shrink-0 mt-1" style={{ color: '#854F0B' }} />
                      <div>
                        <div className="pending-leave-warning-title">
                          {pendingLeaves.length} pending leave request{pendingLeaves.length > 1 ? 's' : ''} in this pay period
                        </div>
                        <div className="pending-leave-warning-body">
                          These days have <strong>no attendance record</strong> yet.
                          If unresolved, they will be counted as <strong>absent</strong> and
                          trigger a <strong>no-pay deduction</strong> in the paysheet.
                          Approve or reject them first for an accurate result.
                        </div>
                      </div>
                    </div>

                    <div className="pending-leave-table-wrap">
                      <div className="pending-leave-table-head">
                        <span>From</span><span>To</span><span>Leave type</span><span>If not approved</span>
                      </div>
                      {pendingLeaves.slice(0, 5).map((lv, i) => (
                        <div key={i} className="pending-leave-table-row">
                          <span>{lv.from_date?.slice(0, 10) ?? '—'}</span>
                          <span>{lv.to_date?.slice(0, 10) ?? lv.from_date?.slice(0, 10) ?? '—'}</span>
                          <span>{lv.leave_type_name ?? '—'}</span>
                          <span className="fw-semibold" style={{ color: '#854F0B' }}>Absent → no-pay</span>
                        </div>
                      ))}
                      {pendingLeaves.length > 5 && (
                        <div className="pending-leave-table-more">
                          +{pendingLeaves.length - 5} more pending requests
                        </div>
                      )}
                    </div>

                    <div className="d-flex gap-2">
                      <Button size="sm" onClick={onHide} className="btn-resolve">
                        <Icon icon="mdi:check-decagram-outline" width={13} className="me-1" />
                        Resolve leaves first
                      </Button>
                      <Button size="sm" variant="outline-secondary" className="rounded-2"
                        onClick={() => setShowAnywayCfm(true)} disabled={showAnywayCfm}>
                        Generate anyway
                      </Button>
                    </div>
                  </div>

                  {showAnywayCfm && (
                    <div className="generate-anyway-confirm">
                      <div className="generate-anyway-confirm-body">
                        <Icon icon="mdi:alert-outline" width={16} className="me-1" style={{ color: '#A32D2D' }} />
                        <strong>The paysheet will treat pending leave days as absent.</strong>{' '}
                        No-pay deductions will be applied. If you approve those leaves later,
                        you will need to regenerate or manually correct this paysheet.
                        Are you sure you want to continue?
                      </div>
                      <div className="d-flex gap-2">
                        <Button size="sm" className="btn-generate-anyway-confirm"
                          onClick={() => { setGenerateAnyway(true); setShowAnywayCfm(false) }}>
                          <Icon icon="mdi:alert-decagram-outline" width={13} className="me-1" />
                          Yes, generate anyway
                        </Button>
                        <Button size="sm" variant="outline-secondary" className="rounded-2"
                          onClick={() => setShowAnywayCfm(false)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Employee summary */}
              <div className="border rounded p-3 bg-light mb-2">
                <Row className="g-2">
                  {[
                    ['Employee', `${selectedEmp?.first_name ?? ''} ${selectedEmp?.last_name ?? ''}`],
                    ['Employee ID', `EMP-${String(selectedEmp?.employee_id ?? 0).padStart(4, '0')}`],
                    ['Pay Period', periodLabel],
                    ['Template', selectedEmp?.payroll_template_name ?? '—'],
                  ].map(([label, value]) => (
                    <Col md={3} key={label}>
                      <small className="text-muted d-block text-uppercase fw-semibold" style={{ fontSize: '0.7rem', letterSpacing: '0.5px' }}>{label}</small>
                      <span className="fw-semibold">{value}</span>
                    </Col>
                  ))}
                </Row>
                {salaryRange && (
                  <div className="text-muted mt-2 small">
                    Salary range: <strong>{salaryRange.start}</strong> → <strong>{salaryRange.end}</strong>
                  </div>
                )}
              </div>

              <h6 className="gw-section-divider"><span>Earnings &amp; Deductions</span></h6>
              <Row className="g-3">
                <LineItemTable
                  title="Earnings" colorClass="success" headerClass="table-success"
                  rows={earnings}
                  onCheck={(i, v) => updE(i, 'checked', v)}
                  onUpdate={updE} onAdd={addEarning} onRemove={removeEarning}
                  addLabel="Add Earning" grossEarningsBase={fixedEarningsBase} currencySymbol={currencySymbol}
                />
                <LineItemTable
                  title="Deductions" colorClass="danger" headerClass="table-danger"
                  rows={deductions}
                  onCheck={(i, v) => updD(i, 'checked', v)}
                  onUpdate={updD} onAdd={addDeduction} onRemove={removeDeduction}
                  addLabel="Add Deduction" grossEarningsBase={grossEarnings} currencySymbol={currencySymbol}
                />
              </Row>

              {/* Auto-calc panel */}
              <div className="gw-autocalc-panel">
                <div className="gw-autocalc-title">
                  <Icon icon="mdi:cog-sync-outline" />
                  Auto-Calculated by Server
                  <Badge bg={autoCalc.loaded ? 'success' : 'secondary'} className="fw-normal small">
                    {autoCalc.loaded ? 'Estimated' : 'No attendance data'}
                  </Badge>
                </div>
                <div className="gw-ac-grid">
                  {[
                    { label: 'Normal Overtime', amount: autoCalc.normalOtAmount, sub: autoCalc.normalOtHours > 0 ? `${autoCalc.normalOtHours.toFixed(2)} hrs × ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr` : `Rate: ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr · No OT`, type: 'earn' },
                    { label: 'Early Overtime', amount: autoCalc.earlyOtAmount, sub: autoCalc.earlyOtHours > 0 ? `${autoCalc.earlyOtHours.toFixed(2)} hrs × ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr` : `Rate: ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr · No early OT`, type: 'earn' },
                    { label: 'Holiday Overtime', amount: autoCalc.holidayOtAmount, sub: autoCalc.holidayOtHours > 0 ? `${autoCalc.holidayOtHours.toFixed(2)} hrs × ${currencySymbol} ${fmt(autoCalc.holidayOtRate)}/hr` : `Rate: ${currencySymbol} ${fmt(autoCalc.holidayOtRate)}/hr · No holiday OT`, type: 'earn' },
                    { label: 'No-Pay Deduction', amount: autoCalc.noPayAmount, sub: autoCalc.noPayAmount > 0 ? `${autoCalc.absentDays} absent + ${autoCalc.unpaidLeaveDays} unpaid × ${currencySymbol} ${fmt(autoCalc.noPayRate)}/day` : `Rate: ${currencySymbol} ${fmt(autoCalc.noPayRate)}/day · No absent/unpaid`, type: 'dedu', negative: true },
                    { label: 'Late Deduction', amount: autoCalc.lateDeductionAmount, sub: autoCalc.lateCount > 0 ? `${autoCalc.lateCount} late → ${autoCalc.lateNoPayDays} day(s) deducted` : `Every 3 lates = 1 day · No lates`, type: 'dedu', negative: true },
                  ].map(({ label, amount, sub, type, negative }) => (
                    <div key={label} className={`gw-ac-card ${amount > 0 ? type : 'zero'}`}>
                      <div className="ac-label">{label}</div>
                      <div className="ac-value">
                        {amount > 0 ? `${negative ? '−' : '+'}${currencySymbol} ${fmt(amount)}` : '—'}
                      </div>
                      <div className="ac-sub">{sub}</div>
                    </div>
                  ))}
                </div>
                <div className="gw-ac-note">
                  <Icon icon="mdi:information-outline" className="flex-shrink-0 mt-1" />
                  Estimated from attendance data for <strong>{periodLabel}</strong>. Server recalculates on generation.
                </div>
              </div>

              {/* Estimated net row */}
              <div className="gw-net-row">
                <div>
                  <div className="nl">
                    Estimated Net Payable <span className="gw-est-badge">ESTIMATE</span>
                  </div>
                  <div className="nw">
                    {estNetSalary > 0
                      ? `${numberToWords(Math.floor(estNetSalary))} ${currencySymbol} Only`
                      : `Zero ${currencySymbol} Only`}
                  </div>
                </div>
                <div className="text-end">
                  <span className="nc">{currencySymbol}</span>
                  <span className="nv">{Number(estNetSalary).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </Modal.Body>

      <Modal.Footer className="justify-content-between">
        <small className="text-muted">
          Currency: <strong>{currencySymbol}</strong>
          {step === 2 && <>&nbsp;·&nbsp; Period: <strong>{periodLabel}</strong>&nbsp;·&nbsp; Type: <strong>{(payrollType || 'MONTHLY').toUpperCase()}</strong></>}
        </small>
        <div className="d-flex gap-2">
          {step === 1 ? (
            <>
              <Button variant="light" onClick={onHide}>Cancel</Button>
              <Button variant="primary" onClick={handleNext} disabled={loading || !empId || !isPeriodValid}>
                {loading
                  ? <><Spinner size="sm" className="me-1" />Loading…</>
                  : <>Continue <Icon icon="solar:alt-arrow-right-linear" /></>}
              </Button>
            </>
          ) : (
            <>
              <Button variant="light" onClick={() => { setStep(1); setMsg(null) }}>
                <Icon icon="solar:alt-arrow-left-linear" /> Previous
              </Button>
              <Button variant="success" onClick={handleGenerate} disabled={busy}>
                {busy
                  ? <><Spinner size="sm" className="me-1" />Generating…</>
                  : <><Icon icon="solar:check-read-linear" className="me-1" />Generate &amp; Save</>}
              </Button>
            </>
          )}
        </div>
      </Modal.Footer>
    </Modal>
  )
}

// ─── PaysheetList (main page) ──────────────────────────────────────────────────
const PaysheetList = ({ companyName = 'OZONE DESK' }) => {
  const { currency } = useCurrencySymbol()
  const currencySymbol = currency ?? 'LKR'

  const cy = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => cy - 2 + i)

  const [filterKeyword, setFilterKeyword] = useState('')
  const [filterDateFrom, setFilterDateFrom] = useState('')
  const [filterDateTo, setFilterDateTo] = useState('')
  const [filterStatus, setFilterStatus] = useState('')

  const [sheets, setSheets] = useState([])
  const [sheetsLoading, setSheetsLoading] = useState(false)
  const [fetchError, setFetchError] = useState(false)

  const { data: employees = [] } = useGetAllEmployeesListQuery()

  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const PAGE_SIZE = 10

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()


  const fetchSheets = async (overrides = {}) => {
    setSheetsLoading(true); setFetchError(false)
    try {
      const kw = 'keyword' in overrides ? overrides.keyword : filterKeyword
      const dateFrom = 'dateFrom' in overrides ? overrides.dateFrom : filterDateFrom
      const dateTo = 'dateTo' in overrides ? overrides.dateTo : filterDateTo
      const status = 'status' in overrides ? overrides.status : filterStatus
      const page = 'page' in overrides ? overrides.page : currentPage

      const params = new URLSearchParams()
      if (kw) params.append('keyword', kw)
      if (dateFrom) params.append('date_from', dateFrom)
      if (dateTo) params.append('date_to', dateTo)
      if (status) params.append('status', status)
      params.append('page', page)
      params.append('per_page', PAGE_SIZE)

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/paysheet?${params.toString()}`,
        { method: 'GET', headers: {}, credentials: 'include', }
      )
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return fetchSheets(overrides)
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setSheets(Array.isArray(data?.data) ? data.data : [])
      setTotalPages(data?.totalPages ?? 1)
      setCurrentPage(page)
    } catch (err) {
      console.error('fetchSheets error:', err)
      setFetchError(true)
    } finally {
      setSheetsLoading(false)
    }
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchSheets({ page })
  }

  const handleReset = () => {
    setFilterKeyword(''); setFilterDateFrom(''); setFilterDateTo(''); setFilterStatus('')
    setCurrentPage(1)
    fetchSheets({ keyword: '', dateFrom: '', dateTo: '', status: '', page: 1 })
  }

  useEffect(() => {
    fetchSheets({ keyword: '', month: '', year: '', status: '' })
    fetchPendingLeaves()
  }, [])

  const [modalOpen, setModalOpen] = useState(false)
  const [activeSheet, setActiveSheet] = useState(null)
  const [activeDetails, setActiveDetails] = useState([])
  const [detailsLoading, setDetailsLoading] = useState(false)
  const [payModalOpen, setPayModalOpen] = useState(false)
  const [paySheet, setPaySheet] = useState(null)
  const [payDetails, setPayDetails] = useState([])
  const [payDetailsLoading, setPayDetailsLoading] = useState(false)
  const [genOpen, setGenOpen] = useState(false)
  const [pendingLeavesMap, setPendingLeavesMap] = useState({})

  const fetchPendingLeaves = async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/leaves/query?status=Pending`,
        { headers: {}, credentials: 'include', }
      )
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return fetchPendingLeaves()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (!res.ok) return
      const data = await res.json()
      const map = {}
        ; (Array.isArray(data) ? data : []).forEach((leave) => {
          const id = String(leave.employee_id)
          map[id] = (map[id] || 0) + 1
        })
      setPendingLeavesMap(map)
    } catch { /* non-blocking */ }
  }

  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: {
        'Content-Type': 'application/json',
        ...(opts.headers ?? {}),
      },
      credentials: 'include',
    })

  const fetchDetails = async (paysheetId) => {
    try {
      const res = await authFetch(`/ems/paysheet-details/${paysheetId}`)
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return fetchDetails(paysheetId)
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      const data = await res.json()
      return Array.isArray(data) ? data : (data?.data ?? [])
    } catch { return [] }
  }

  const openSlip = async (s) => {
    setActiveSheet(s); setActiveDetails([]); setModalOpen(true); setDetailsLoading(true)
    const details = await fetchDetails(s.paysheet_id)
    setActiveDetails(details); setDetailsLoading(false)
  }

  const openPay = async (s) => {
    setPaySheet(s); setPayDetails([]); setPayModalOpen(true); setPayDetailsLoading(true)
    const details = await fetchDetails(s.paysheet_id)
    setPayDetails(details); setPayDetailsLoading(false)
  }

  const activeEmpObj = employees.find(e => String(e.employee_id) === String(activeSheet?.employee_id))
  const payEmpObj = employees.find(e => String(e.employee_id) === String(paySheet?.employee_id))

  return (
    <>
      {/* No <style> tag — all styles are in payslip-print.css */}
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center">
            <Col>
              <CardTitle as="h4" className="mb-0 fs-5">
                <Icon icon="mdi:file-chart-outline" className="me-2 text-primary" />
                Paysheetss
              </CardTitle>
            </Col>
            <Col xs="auto">
              <Button variant="success" onClick={() => setGenOpen(true)}>
                <Icon icon="mdi:plus" className="me-1" />Generate Paysheet
              </Button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          {/* Filter bar */}
          <Form className="row g-2 mb-3">
            <FormGroup className="col-md-3">
              <FormLabel>Keyword</FormLabel>
              <FormControl
                type="text" placeholder="Search by ID or Name"
                value={filterKeyword} onChange={e => setFilterKeyword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && fetchSheets({ page: 1 })}
              />
            </FormGroup>

            <FormGroup className="col-md-4">
              <div className="row g-1">
                <div className="col-6">
                  <FormLabel>From Date</FormLabel>
                  <FormControl type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} />
                </div>
                <div className="col-6">
                  <FormLabel>To Date</FormLabel>
                  <FormControl type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} />
                </div>
              </div>
            </FormGroup>

            <FormGroup className="col-md-3">
              <FormLabel>Status</FormLabel>
              <FormSelect value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                <option value="">All Statuses</option>
                <option value="PAID">Paid</option>
                <option value="PENDING">Pending</option>
                <option value="DRAFT">Draft</option>
                <option value="GENERATED">Generated</option>
                <option value="APPROVED">Approved</option>
              </FormSelect>
            </FormGroup>

            <FormGroup className="col-md-2 d-flex align-items-end">
              <Button
                className="bg-primary border-primary flex-grow-1"
                onClick={() => fetchSheets({ page: 1 })}
                disabled={sheetsLoading}
              >
                <Icon icon="material-symbols:search-rounded" width={18} height={18} className="me-1" />
                Search
              </Button>
            </FormGroup>
          </Form>

          {/* Table */}
          {fetchError ? (
            <Alert variant="danger">Failed to load paysheets. Please try again.</Alert>
          ) : sheetsLoading ? (
            <div className="d-flex justify-content-center align-items-center py-5">
              <Spinner animation="border" variant="primary" />
              <span className="ms-3 text-muted">Loading paysheets…</span>
            </div>
          ) : (
            <>
              <div className="d-flex justify-content-between align-items-center mb-2">
                <small className="text-muted">
                  Showing <strong>{sheets.length}</strong> paysheet{sheets.length !== 1 ? 's' : ''}
                </small>
              </div>
              <Table striped hover responsive>
                <thead>
                  <tr>
                    <th>Paysheet ID</th>
                    <th>Employee Name</th>
                    <th>Employee ID</th>
                    <th className="text-end">Pay Period</th>
                    <th className="text-end">Working Days</th>
                    <th className="text-end">Gross Earnings</th>
                    <th className="text-end">Deductions</th>
                    <th className="text-end">Net Salary ({currencySymbol})</th>
                    <th className="text-end">Status</th>
                    <th className="text-end" style={{ minWidth: 130 }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sheets.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="text-center py-5 text-muted">
                        <Icon icon="mdi:file-search-outline" width={32} className="mb-2 d-block mx-auto" />
                        No paysheets found
                      </td>
                    </tr>
                  ) : sheets.map(s => {
                    const emp = employees.find(e => String(e.employee_id) === String(s.employee_id))
                    const toTitleCase = (str) => str.toLowerCase().replace(/\b\w/g, c => c.toUpperCase())
                    const rawName = s.employee_name || s.employee_full_name
                      || (emp ? `${emp.first_name} ${emp.last_name}` : `#${s.employee_id}`)
                    const name = toTitleCase(rawName)
                    const isPaid = (s.payroll_status ?? '') === 'PAID'

                    return (
                      <tr key={s.paysheet_id}>
                        <td className="fw-semibold">#{s.paysheet_id}</td>
                        <td>
                          <div className="d-flex align-items-center gap-2 flex-wrap">
                            {name}
                            {pendingLeavesMap[String(s.employee_id)] > 0 && (
                              <span
                                className="pending-leave-badge"
                                title="This employee has pending leave requests that may affect paysheet accuracy"
                              >
                                <Icon icon="mdi:clock-alert-outline" width={11} />
                                {pendingLeavesMap[String(s.employee_id)]} pending leave
                                {pendingLeavesMap[String(s.employee_id)] > 1 ? 's' : ''}
                              </span>
                            )}
                          </div>
                        </td>
                        <td>
                          <Badge bg="light" text="dark" className="border">
                            EMP-{String(s.employee_id).padStart(4, '0')}
                          </Badge>
                        </td>
                        <td className="text-end">
                          {s.payroll_month && s.payroll_year
                            ? `${MONTHS[s.payroll_month - 1]} ${s.payroll_year}` : '—'}
                        </td>
                        <td className="text-end">{s.total_working_days ?? '—'}</td>
                        <td className="text-end text-success fw-semibold">
                          {Number(s.total_earnings || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="text-end text-danger">
                          {Number(s.total_deductions || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="text-end">
                          {/* text-navy is defined in payslip-print.css */}
                          <span className="fw-bold text-navy">
                            {Number(s.net_salary || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                          </span>
                        </td>
                        <td className="text-end">{statusBadge(s.payroll_status)}</td>
                        <td className="text-end">
                          <div className="d-flex gap-1 align-items-center justify-content-end">
                            <Button
                              size="sm" variant="primary"
                              className="rounded-pill px-3"
                              onClick={() => openSlip(s)}
                            >
                              <Icon icon="mdi:eye" className="me-1" />View
                            </Button>
                            <button
                              className={`pay-btn-action${isPaid ? ' already-paid' : ''}`}
                              onClick={() => !isPaid && openPay(s)}
                              title={isPaid ? 'Already Paid' : 'Process Payment'}
                            >
                              {isPaid
                                ? <><Icon icon="mdi:check-circle-outline" /> Paid</>
                                : <><Icon icon="mdi:cash-check" /> Pay</>}
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>
            </>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="d-flex justify-content-end mt-3">
              <Pagination>
                <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>First</Pagination.Item>
                <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
                {(() => {
                  const pages = []
                  let start = totalPages <= 5 ? 1 : Math.max(1, currentPage - 2)
                  let end = totalPages <= 5 ? totalPages : Math.min(totalPages, currentPage + 2)
                  if (start === 1) end = Math.min(totalPages, 5)
                  if (end === totalPages) start = Math.max(1, totalPages - 4)
                  for (let i = start; i <= end; i++)
                    pages.push(
                      <Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>{i}</Pagination.Item>
                    )
                  return pages
                })()}
                <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>Last</Pagination.Item>
              </Pagination>
            </div>
          )}
        </CardBody>
      </Card>

      <PayslipModal
        show={modalOpen} onHide={() => setModalOpen(false)}
        paysheet={activeSheet} details={activeDetails}
        employee={activeEmpObj} detailsLoading={detailsLoading}
        companyName={companyName} currencySymbol={currencySymbol}
      />

      <PaymentModal
        show={payModalOpen} onHide={() => setPayModalOpen(false)}
        paysheet={paySheet} details={payDetails}
        employee={payEmpObj} detailsLoading={payDetailsLoading}
        companyName={companyName} onPaySuccess={() => { }}
        refetchSheets={() => fetchSheets({ keyword: '', month: '', year: '', status: '' })}
        currencySymbol={currencySymbol}
      />

      <GenerateWizardModal
        show={genOpen} onHide={() => setGenOpen(false)}
        employees={employees}
        onSuccess={() => fetchSheets({ keyword: '', month: '', year: '', status: '' })}
        currencySymbol={currencySymbol}
      />
    </>
  )
}

export default PaysheetList