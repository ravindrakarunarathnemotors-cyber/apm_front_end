'use client'

import React, { useState, useMemo, useRef, useEffect } from 'react'
import {
  Button, Card, CardHeader, CardBody, CardTitle,
  Col, Row, Table, Modal, Badge, Form,
  FormControl, FormLabel, FormGroup, Spinner, Alert, InputGroup, FormSelect,Pagination
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import { useGetAllEmployeesListQuery } from '@/store/features/emsSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'

// ─── helpers ──────────────────────────────────────────────────────────────────
const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
]

// Updated fmt to use currency symbol from hook
const makeFmt = (currency) => (n) =>
  `${currency ?? 'LKR'} ${Number(n || 0).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`

function numberToWords(num) {
  const n = Math.round(Number(num) || 0)
  if (n === 0) return 'Zero'
  const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
    'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen',
    'Seventeen','Eighteen','Nineteen']
  const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety']
  function chunk(x) {
    if (x < 20) return ones[x]
    if (x < 100) return tens[Math.floor(x/10)] + (x % 10 ? ' ' + ones[x % 10] : '')
    return ones[Math.floor(x/100)] + ' Hundred' + (x % 100 ? ' ' + chunk(x % 100) : '')
  }
  let rem = n; const parts = []
  if (rem >= 10000000) { parts.push(chunk(Math.floor(rem/10000000))+' Crore'); rem %= 10000000 }
  if (rem >= 100000)   { parts.push(chunk(Math.floor(rem/100000))+' Lakh');   rem %= 100000   }
  if (rem >= 1000)     { parts.push(chunk(Math.floor(rem/1000))+' Thousand'); rem %= 1000     }
  if (rem > 0)         { parts.push(chunk(rem)) }
  return parts.join(' ')
}

const statusBadge = (s) => {
  const map = {
    PAID:      ['success',           'Paid'],
    PENDING:   ['warning text-dark', 'Pending'],
    DRAFT:     ['secondary',         'Draft'],
    GENERATED: ['info text-dark',    'Generated'],
    APPROVED:  ['primary',           'Approved'],
  }
  const [bg, label] = map[s] ?? ['secondary', s ?? 'Draft']
  return <span style={{ fontWeight: 600 }}>{label}</span>
}

const resolveToLKR = (amount, amountType, base) => {
  const val = parseFloat(amount) || 0
  if (amountType === 'PERCENTAGE') return (val / 100) * base
  return val
}

// ─── Print CSS ─────────────────────────────────────────────────────────────────
const PRINT_CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#f0f2f5;color:#1a2332;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.page{background:#fff;max-width:780px;margin:24px auto;box-shadow:0 4px 40px rgba(0,0,0,.13)}
.slip-header{background:linear-gradient(135deg,#0b2447 0%,#19376d 55%,#1565c0 100%);color:#fff;padding:28px 36px 26px;position:relative;overflow:hidden}
.slip-header::after{content:'';position:absolute;right:-50px;top:-50px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.05)}
.slip-header::before{content:'';position:absolute;right:70px;bottom:-70px;width:150px;height:150px;border-radius:50%;background:rgba(255,255,255,.04)}
.header-row{display:flex;justify-content:space-between;align-items:flex-start;position:relative;z-index:1}
.company-name{font-family:'DM Serif Display',serif;font-size:21px;letter-spacing:.3px;margin-bottom:3px}
.slip-subtitle{font-size:10.5px;text-transform:uppercase;letter-spacing:2.5px;opacity:.65;font-weight:500}
.slip-meta{text-align:right}
.pay-period-label{font-size:12px;font-weight:600;opacity:.88;margin-bottom:3px}
.slip-id-label{font-size:10.5px;opacity:.5}
.emp-band{background:#f7f9fc;border-bottom:1px solid #e4eaf3;padding:18px 36px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.ef label{font-size:9.5px;text-transform:uppercase;letter-spacing:1.2px;color:#7a8aa0;font-weight:700;display:block;margin-bottom:3px}
.ef span{font-size:13px;font-weight:600;color:#1a2332}
.summary-strip{display:grid;grid-template-columns:repeat(5,1fr);border-bottom:2px solid #e4eaf3}
.sc{padding:13px 0;text-align:center;border-right:1px solid #eef1f7}
.sc:last-child{border-right:none}
.sc .sv{font-size:14.5px;font-weight:700}
.sc .sl{font-size:9.5px;text-transform:uppercase;letter-spacing:.8px;color:#7a8aa0;font-weight:700;margin-top:2px}
.ed-grid{display:grid;grid-template-columns:1fr 1fr}
.ed-col{border-right:1px solid #e4eaf3}
.ed-col:last-child{border-right:none}
.ed-head{display:flex;justify-content:space-between;padding:9px 22px;font-size:9.5px;text-transform:uppercase;letter-spacing:1.2px;font-weight:700}
.ed-earn .ed-head{background:#edfaf3;color:#1b6c3e}
.ed-dedu .ed-head{background:#fff0f0;color:#9b2222}
.ed-table{width:100%;border-collapse:collapse}
.ed-table td{padding:8px 22px;font-size:12.5px;border-bottom:1px solid #f4f6f9;color:#2d3a4a}
.ed-table td:last-child{text-align:right;font-weight:500;white-space:nowrap;color:#374151}
.ed-table .st td{font-weight:700;font-size:13px;background:#fafbfd;border-top:2px solid #e4eaf3;border-bottom:none;padding-top:10px;padding-bottom:10px}
.ed-earn .st td{color:#1b6c3e}
.ed-dedu .st td{color:#9b2222}
.ed-table .empty td{color:#b0bac8;font-style:italic;font-size:11.5px}
.net-bar{background:linear-gradient(90deg,#0b2447,#19376d);color:#fff;padding:16px 36px;display:flex;justify-content:space-between;align-items:center}
.net-label-wrap .nl{font-size:9.5px;text-transform:uppercase;letter-spacing:2px;opacity:.65;font-weight:600}
.net-label-wrap .nf{font-size:10.5px;opacity:.45;margin-top:2px}
.net-amount-wrap{text-align:right}
.net-cur{font-size:12px;opacity:.7;margin-right:3px}
.net-val{font-family:'DM Serif Display',serif;font-size:26px;letter-spacing:.5px}
.words-bar{background:#f7f9fc;border-top:1px solid #e4eaf3;padding:11px 36px;font-size:11.5px;color:#4a5568}
.words-bar strong{font-weight:700;color:#1a2332}
.slip-footer{padding:16px 36px;border-top:2px solid #e4eaf3;display:flex;justify-content:space-between;align-items:flex-end}
.fn{font-size:10px;color:#9ba8ba;line-height:1.6}
.sig .sig-line{width:130px;height:1px;background:#b0bac8;margin-bottom:5px;margin-left:auto}
.sig span{font-size:10px;color:#7a8aa0;font-weight:700;letter-spacing:.5px}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:100%}}
`

// ─── PayslipDocument ───────────────────────────────────────────────────────────
const PayslipDocument = ({ paysheet, details, employee, companyName = 'Your Company', currencySymbol = 'LKR' }) => {
  const fmt = makeFmt(currencySymbol)
  if (!paysheet) return null
  const month   = paysheet.payroll_month ? MONTHS[paysheet.payroll_month - 1] : '—'
  const year    = paysheet.payroll_year  ?? '—'
  const empName = paysheet.first_name
    ? `${paysheet.first_name} ${paysheet.last_name ?? ''}`.trim()
    : employee
    ? `${employee.first_name ?? ''} ${employee.last_name ?? ''}`.trim()
    : `Employee #${paysheet.employee_id}`
  const designation = employee?.designation_name ?? '—'
  const department  = employee?.department_name  ?? '—'
  const empId       = `EMP-${String(paysheet.employee_id).padStart(4, '0')}`
  const payDate     = paysheet.salary_range_end
    ? String(paysheet.salary_range_end).split('T')[0] : '—'

  const isEarning   = (t) => ['EARNING','EARNINGS'].includes((t ?? '').toUpperCase().trim())
  const isDeduction = (t) => ['DEDUCTION','DEDUCTIONS'].includes((t ?? '').toUpperCase().trim())
  const earnRows    = (details ?? []).filter(r => isEarning(r.type))
  const deducRows   = (details ?? []).filter(r => isDeduction(r.type))

  const grossEarnings   = parseFloat(paysheet.total_earnings   || 0)
  const totalDeductions = parseFloat(paysheet.total_deductions || 0)
  const netSalary       = parseFloat(paysheet.net_salary       || 0)
  const paidDays        = paysheet.present_days ?? paysheet.total_working_days ?? '—'
  const lopDays         = paysheet.absent_days  ?? 0
  const halfDays        = paysheet.half_days    ?? 0
  const cents           = Math.round((netSalary % 1) * 100)
  const wordsStr        = netSalary > 0
    ? `${numberToWords(Math.floor(netSalary))}${cents ? ` and ${String(cents).padStart(2,'0')}/100` : ''} ${currencySymbol} Only`
    : `Zero ${currencySymbol} Only`

  return (
    <div className="page">
      <div className="slip-header">
        <div className="header-row">
          <div>
            <div className="company-name">{companyName}</div>
            <div className="slip-subtitle">Employee Payslip</div>
          </div>
          <div className="slip-meta">
            <div className="pay-period-label">Payslip for {month} {year}</div>
            <div className="slip-id-label">#{paysheet.paysheet_id} &nbsp;·&nbsp; {new Date().toLocaleDateString('en-GB')}</div>
          </div>
        </div>
      </div>
      <div className="emp-band">
        {[['Employee Name',empName],['Employee ID',empId],['Designation',designation],['Department',department]].map(([label,value]) => (
          <div className="ef" key={label}><label>{label}</label><span>{value}</span></div>
        ))}
      </div>
      <div className="summary-strip">
        {[
          ['Paid Days',paidDays,'#1565c0'],['LOP Days',lopDays,'#c0392b'],
          ['Half Days',halfDays,'#c77b00'],['Pay Date',payDate,'#0d7a55'],
          ['Pay Period',`${month} ${year}`,'#6d3fa8'],
        ].map(([lbl,val,color]) => (
          <div className="sc" key={lbl}><div className="sv" style={{color}}>{val}</div><div className="sl">{lbl}</div></div>
        ))}
      </div>
      <div className="ed-grid">
        <div className="ed-col ed-earn">
          <div className="ed-head"><span>Earnings</span><span>Amount ({currencySymbol})</span></div>
          <table className="ed-table"><tbody>
            {earnRows.length ? earnRows.map((r,i) => (
              <tr key={i}><td>{r.earning_deduction_name ?? r.name ?? '—'}</td><td>{fmt(r.amount)}</td></tr>
            )) : <tr className="empty"><td colSpan={2}>No earnings line items</td></tr>}
            <tr className="st"><td>Gross Earnings</td><td>{fmt(grossEarnings)}</td></tr>
          </tbody></table>
        </div>
        <div className="ed-col ed-dedu">
          <div className="ed-head"><span>Deductions</span><span>Amount ({currencySymbol})</span></div>
          <table className="ed-table"><tbody>
            {deducRows.length ? deducRows.map((r,i) => (
              <tr key={i}><td>{r.earning_deduction_name ?? r.name ?? '—'}</td><td>{fmt(r.amount)}</td></tr>
            )) : <tr className="empty"><td colSpan={2}>No deductions listed</td></tr>}
            <tr className="st"><td>Total Deductions</td><td>{fmt(totalDeductions)}</td></tr>
          </tbody></table>
        </div>
      </div>
      <div className="net-bar">
        <div className="net-label-wrap">
          <div className="nl">Total Net Payable</div>
          <div className="nf">Gross Earnings − Total Deductions</div>
        </div>
        <div className="net-amount-wrap">
          <span className="net-cur">{currencySymbol}</span>
          <span className="net-val">{fmt(netSalary)}</span>
        </div>
      </div>
      <div className="words-bar">Amount in words: &nbsp;<strong>{wordsStr}</strong></div>
      <div className="slip-footer">
        <div className="fn">
          This is a computer-generated payslip and does not require a physical signature.<br/>
          For queries, please contact the HR department.
        </div>
        <div className="sig"><div className="sig-line"/><span>Authorised Signatory</span></div>
      </div>
    </div>
  )
}

// ─── PayslipModal ──────────────────────────────────────────────────────────────
const PayslipModal = ({ show, onHide, paysheet, details, employee, detailsLoading, companyName, currencySymbol }) => {
  const fmt = makeFmt(currencySymbol)
  const printRef = useRef(null)
  const handlePrint = () => {
    const html = printRef.current?.innerHTML
    if (!html) return
    const w = window.open('', '', 'width=900,height=720')
    w.document.write(`<!DOCTYPE html><html><head>
      <meta charset="utf-8"/>
      <title>Payslip — ${paysheet?.paysheet_id}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet"/>
      <style>${PRINT_CSS}</style>
    </head><body>${html}</body></html>`)
    w.document.close(); w.focus()
    setTimeout(() => { w.print(); w.close() }, 700)
  }
  return (
    <Modal show={show} onHide={onHide} size="xl" centered dialogClassName="payslip-dlg">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
        .payslip-dlg .modal-content{border:none;border-radius:14px;overflow:hidden;box-shadow:0 24px 64px rgba(0,0,0,.22)}
        .payslip-dlg .modal-body{padding:0;background:#f0f2f5}
        .ps-preview{padding:20px;overflow-y:auto;max-height:78vh}
        ${PRINT_CSS.replace(/body\{/g,'.ps-preview {')}
      `}</style>
      <Modal.Header closeButton style={{background:'#0b2447',border:'none',padding:'14px 22px'}}>
        <Modal.Title style={{color:'#fff',fontFamily:"'DM Serif Display',serif",fontSize:'17px',fontWeight:400}}>
          <Icon icon="mdi:file-document-outline" style={{marginRight:8,verticalAlign:'middle',fontSize:20}}/>
          Payslip Preview
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {detailsLoading ? (
          <div className="d-flex justify-content-center align-items-center" style={{padding:'60px 0'}}>
            <Spinner animation="border" variant="primary"/>
            <span className="ms-3 text-muted">Loading payslip details…</span>
          </div>
        ) : (
          <div className="ps-preview" ref={printRef}>
            <PayslipDocument paysheet={paysheet} details={details} employee={employee} companyName={companyName} currencySymbol={currencySymbol}/>
          </div>
        )}
      </Modal.Body>
      <Modal.Footer style={{background:'#f0f2f5',borderTop:'1px solid #dee2e6',justifyContent:'space-between'}}>
        <small className="text-muted">
          Paysheet&nbsp;ID:&nbsp;<strong>#{paysheet?.paysheet_id}</strong>
          &nbsp;·&nbsp;Currency:&nbsp;<strong>{currencySymbol}</strong>
        </small>
        <div className="d-flex gap-2">
          <Button variant="outline-secondary" onClick={onHide}>Close</Button>
          <Button onClick={handlePrint} disabled={detailsLoading}
            style={{background:'#0b2447',border:'none',color:'#fff'}}>
            <Icon icon="mdi:printer" style={{marginRight:6}}/>Print / Download PDF
          </Button>
        </div>
      </Modal.Footer>
    </Modal>
  )
}


const AmountCell = ({ value, amountType, onValueChange, onTypeChange, disabled, resolvedLKR, currencySymbol }) => (
  <div>
    <InputGroup size="sm">
      <FormControl
        type="number" min="0"
        max={amountType === 'PERCENTAGE' ? 100 : undefined}
        step={amountType === 'PERCENTAGE' ? '0.01' : '1'}
        placeholder="0.00" disabled={disabled} value={value}
        onChange={(e) => {
          let val = e.target.value
          if (amountType === 'PERCENTAGE' && parseFloat(val) > 100) val = '100'
          onValueChange(val)
        }}
        style={{ minWidth: '80px' }}
      />
      <FormSelect disabled={disabled} value={amountType}
        onChange={(e) => {
          onTypeChange(e.target.value)
          if (e.target.value === 'PERCENTAGE' && parseFloat(value) > 100) onValueChange('100')
        }}
        style={{ maxWidth: '90px', fontSize: '0.78rem' }}>
        <option value="LKR">{currencySymbol ?? 'LKR'}</option>
        <option value="PERCENTAGE">%</option>
      </FormSelect>
    </InputGroup>
    {amountType === 'PERCENTAGE' && resolvedLKR !== undefined && (
      <div style={{ fontSize: '10px', color: '#0d6efd', marginTop: '2px', fontWeight: 600, paddingLeft: '2px' }}>
        = {currencySymbol} {Number(resolvedLKR).toLocaleString('en-LK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </div>
    )}
  </div>
)


const LineItemTable = ({ title, colorClass, headerClass, rows, onCheck, onUpdate, onAdd, onRemove, addLabel, grossEarningsBase, currencySymbol }) => (
  <Col md={6}>
    <h6 className={`text-${colorClass} mb-2`}>
      <Icon icon={colorClass === 'success' ? 'mdi:trending-up' : 'mdi:trending-down'} className="me-1"/>
      {title}
    </h6>
    <Table bordered size="sm" className="mb-2" style={{ tableLayout: 'fixed' }}>
      <colgroup>
        <col style={{ width: '42px' }}/><col/><col style={{ width: '205px' }}/><col style={{ width: '36px' }}/>
      </colgroup>
      <thead className={headerClass}>
        <tr><th className="text-center">✓</th><th>Name</th><th>Amount</th><th></th></tr>
      </thead>
      <tbody>
        {rows.map((row, i) => {
          const resolvedLKR = row.amountType === 'PERCENTAGE'
            ? resolveToLKR(row.amount, 'PERCENTAGE', grossEarningsBase) : undefined
          return (
            <tr key={i} style={{ opacity: !row.checked ? 0.35 : 1, transition: 'opacity 0.15s', background: !row.checked ? '#f8f9fa' : undefined }}>
              <td className="text-center align-middle">
                <Form.Check type="checkbox" checked={row.checked} onChange={(e) => onCheck(i, e.target.checked)}/>
              </td>
              <td className="align-middle">
                <div className="d-flex align-items-center gap-1">
                  <FormControl size="sm" placeholder={colorClass === 'success' ? 'e.g. Basic Salary' : 'e.g. Tax'}
                    disabled={!row.isCustom} value={row.name} onChange={(e) => onUpdate(i, 'name', e.target.value)}/>
                  {row.isCustom && (
                    <span style={{ display:'inline-block',fontSize:'9px',background:'#e9ecef',color:'#6c757d',borderRadius:'3px',padding:'0 4px',fontWeight:700,letterSpacing:'.3px',whiteSpace:'nowrap' }}>CUSTOM</span>
                  )}
                </div>
              </td>
              <td>
                <AmountCell value={row.amount} amountType={row.amountType} disabled={!row.checked}
                  onValueChange={(val) => onUpdate(i, 'amount', val)} onTypeChange={(val) => onUpdate(i, 'amountType', val)} resolvedLKR={resolvedLKR} currencySymbol={currencySymbol}/>
              </td>
              <td className="text-center align-middle">
                {row.isCustom && (
                  <button onClick={() => onRemove(i)} style={{ background:'none',border:'none',color:'#dc3545',cursor:'pointer',padding:'0 2px',fontSize:14 }}>
                    <Icon icon="mdi:close"/>
                  </button>
                )}
              </td>
            </tr>
          )
        })}
      </tbody>
    </Table>
    <Button size="sm" variant={`outline-${colorClass}`} onClick={onAdd}>
      <Icon icon="mdi:plus" className="me-1"/>{addLabel}
    </Button>
  </Col>
)


const PaymentModal = ({ show, onHide, paysheet, details, employee, detailsLoading, companyName, onPaySuccess, refetchSheets, currencySymbol }) => {
  const fmt = makeFmt(currencySymbol)
  const printRef = useRef(null)

  const [payRef,          setPayRef]          = useState('')
  const [adminNote,       setAdminNote]       = useState('')
  const [uploadedFile,    setUploadedFile]    = useState(null)
  const [uploadedUrl,     setUploadedUrl]     = useState(null)
  const [uploading,       setUploading]       = useState(false)
  const [emailAddr,       setEmailAddr]       = useState('')
  const [paying,          setPaying]          = useState(false)
  const [emailing,        setEmailing]        = useState(false)
  const [msg,             setMsg]             = useState(null)


  const [paymentMethods,       setPaymentMethods]       = useState([])
  const [payMethodId,          setPayMethodId]          = useState('')
  const [payMethodName,        setPayMethodName]        = useState('')
  const [methodsLoading,       setMethodsLoading]       = useState(false)

 
  const [bankAccounts,         setBankAccounts]         = useState([])
  const [selectedBankAccountId, setSelectedBankAccountId] = useState('')
  const [accountsLoading,      setAccountsLoading]      = useState(false)

  const isBankTransfer = paymentMethods
  .find(m => String(m.id) === String(payMethodId))
  ?.name?.toLowerCase() === 'bank transfer'

  useEffect(() => {
    if (show) {
      setPayRef(''); setAdminNote('')
      setUploadedFile(null); setUploadedUrl(null)
      setEmailAddr(employee?.email ?? ''); setMsg(null)
      setPayMethodId(''); setPayMethodName('')
      setSelectedBankAccountId('')
      fetchPaymentMethods()
    }
  }, [show, employee])


  const fetchPaymentMethods = async () => {
  setMethodsLoading(true)
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL}/ems/payment-methods`,
      { headers: { Authorization: `Bearer ${token()}` } }
    )
    if (!res.ok) throw new Error()
    const methods = await res.json()
    setPaymentMethods(Array.isArray(methods) ? methods : [])
    if (methods.length > 0) {
      setPayMethodId(String(methods[0].id))
      setPayMethodName(methods[0].name)
    }
  } catch {
    setPaymentMethods([])
  } finally {
    setMethodsLoading(false)
  }
}

 
  useEffect(() => {
    if (isBankTransfer) {
      fetchBankAccounts()
    } else {
      setBankAccounts([])
      setSelectedBankAccountId('')
    }
  }, [payMethodId, isBankTransfer])

  const fetchBankAccounts = async () => {
  setAccountsLoading(true)
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL}/ems/bank-accounts`,
      { headers: { Authorization: `Bearer ${token()}` } }
    )
    if (!res.ok) throw new Error()
    const accounts = await res.json()
    setBankAccounts(Array.isArray(accounts) ? accounts : [])
    if (accounts.length > 0) setSelectedBankAccountId(String(accounts[0].id))
  } catch {
    setBankAccounts([])
  } finally {
    setAccountsLoading(false)
  }
}


  const token = () =>
    typeof window !== 'undefined' ? sessionStorage.getItem('access_token') ?? '' : ''

  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: {
        Authorization: `Bearer ${token()}`,
        'Content-Type': 'application/json',
        ...(opts.headers ?? {}),
      },
    })

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadedFile(file)
    setUploadedUrl(null)
    setUploading(true)
    setMsg(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('file_type', 'payslip')
      const res  = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/emsupload/upload-ems`, {
        method:  'POST',
        headers: { Authorization: `Bearer ${token()}` },
        body:    formData,
      })
      const data = await res.json()
      if (!res.ok || !data.url) throw new Error(data.error ?? 'Upload failed')
      setUploadedUrl(data.url)
      setMsg({ type: 'success', text: 'Payslip document uploaded successfully.' })
    } catch (err) {
      setMsg({ type: 'danger', text: err.message ?? 'File upload failed.' })
      setUploadedFile(null)
    } finally {
      setUploading(false)
    }
  }

  const removeUpload = () => { setUploadedFile(null); setUploadedUrl(null) }

  const handlePrint = () => {
    const html = printRef.current?.innerHTML
    if (!html) return
    const w = window.open('', '', 'width=900,height=720')
    w.document.write(`<!DOCTYPE html><html><head>
      <meta charset="utf-8"/>
      <title>Payslip — ${paysheet?.paysheet_id}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet"/>
      <style>${PRINT_CSS}</style>
    </head><body>${html}</body></html>`)
    w.document.close(); w.focus()
    setTimeout(() => { w.print(); w.close() }, 700)
  }

  const handleEmail = async () => {
    if (!emailAddr) { setMsg({ type: 'warning', text: 'Please enter an email address.' }); return }
    setEmailing(true); setMsg(null)
    try {
      const res = await authFetch(`/ems/paysheet/${paysheet.paysheet_id}/email`, {
        method: 'POST',
        body: JSON.stringify({ email: emailAddr }),
      })
      if (!res.ok) throw new Error('Failed to send email')
      setMsg({ type: 'success', text: `Payslip emailed to ${emailAddr} successfully!` })
    } catch (e) {
      setMsg({ type: 'danger', text: e.message ?? 'Failed to send email.' })
    } finally {
      setEmailing(false)
    }
  }


  const postTransaction = async ({ netSalary, empName, monthLabel, yearLabel }) => {
  let userId = null
  try {
    const raw = typeof window !== 'undefined' ? sessionStorage.getItem('user') : null
    if (raw) { const u = JSON.parse(raw); userId = u?.user_id ?? u?.id ?? null }
  } catch { /* ignore */ }

  const accountId = isBankTransfer && selectedBankAccountId ? selectedBankAccountId : null
  if (!accountId) {
    console.warn('[Transaction] Skipped — no account_id (non-bank-transfer or no account selected)')
    return
  }

  const transactionPayload = {
    account_id:       Number(accountId),
    category_id:      4,
    transaction_type: 'expense',
    note:             adminNote || `EMS Payroll — ${monthLabel} ${yearLabel} salary for ${empName}`,
    by_user_id:       userId,
    payer_payee_id:   paysheet?.employee_id ?? null,
    log_module:       'ems',
    log_message:      `Salary paid to ${empName} for ${monthLabel} ${yearLabel} — Amount: ${currencySymbol} ${Number(netSalary).toLocaleString('en-LK', { minimumFractionDigits: 2 })}`,
    amount:           netSalary,
  }

  console.log('[Transaction] Sending payload:', transactionPayload)

  try {
    const res = await authFetch('/transaction-uploader', {
      method: 'POST',
      body: JSON.stringify(transactionPayload),
    })
    const resBody = await res.json().catch(() => ({}))
    if (!res.ok) {
      console.warn('[Transaction] Failed — status:', res.status, '| response:', resBody)
    } else {
      console.log('[Transaction] Success:', resBody)
    }
  } catch (err) {
    console.warn('[Transaction] Error (non-blocking):', err)
  }
}

  const handlePay = async () => {
    if (!payRef.trim()) { setMsg({ type: 'warning', text: 'Payment reference is required.' }); return }
    if (isBankTransfer && !selectedBankAccountId) { setMsg({ type: 'warning', text: 'Please select a bank account.' }); return }

    setPaying(true); setMsg(null)
    try {
    
      const statusRes = await authFetch(`/ems/paysheet/${paysheet.paysheet_id}/status`, {
          method: 'PUT',
          body: JSON.stringify({ 
              status: 'PAID',
              payslip_url: uploadedUrl ?? ''   // ← pass the S3 URL here
          }),
      })

      if (!statusRes.ok) throw new Error('Failed to update paysheet status')

      let userId = null
      try {
        const raw = typeof window !== 'undefined' ? sessionStorage.getItem('user') : null
        if (raw) { const u = JSON.parse(raw); userId = u?.user_id ?? u?.id ?? null }
      } catch { /* ignore */ }

      const netSalary     = parseFloat(paysheet?.net_salary        || 0)
      const grossEarnings = parseFloat(paysheet?.total_earnings    || 0)
      const totalDeducs   = parseFloat(paysheet?.total_deductions  || 0)
      const empName  = employee
        ? `${employee.first_name ?? ''} ${employee.last_name ?? ''}`.trim()
        : paysheet.employee_name ?? `Employee #${paysheet.employee_id}`
      const monthLabel = MONTHS[(paysheet.payroll_month ?? 1) - 1]
      const yearLabel  = paysheet.payroll_year ?? new Date().getFullYear()
      const selectedMethod = paymentMethods.find(m => String(m.id) === String(payMethodId))
      const methodLabel = selectedMethod?.name ?? payMethodId

      const noteStr    = adminNote
        ? `[EMS Payroll] ${monthLabel} ${yearLabel} | ${methodLabel} | ${adminNote}`
        : `[EMS Payroll] ${monthLabel} ${yearLabel} | ${methodLabel}`

      // 2. Create paysheet invoice record
      const detailRes = await authFetch(`/ems/paysheet-details/${paysheet.paysheet_id}`)
      let firstDetailId = null
      if (detailRes.ok) {
        const detailData = await detailRes.json()
        const detailsList = Array.isArray(detailData) ? detailData : (detailData?.data ?? [])
        if (detailsList.length > 0) {
          firstDetailId = detailsList[0].paysheet_detail_id
        }
      }

      const invoicePayload = {
        paysheet_detail_id: firstDetailId,
        payment_reference:  payRef.trim(),
        paid_by:            userId ? String(userId) : (empName ?? 'Admin'),
        payment_status:     'PAID',
        admin_note:         noteStr,
        payslip_url:        uploadedUrl ?? null,
        account_id:         (isBankTransfer && selectedBankAccountId) ? Number(selectedBankAccountId) : null,
        account_name:       isBankTransfer
                              ? bankAccounts.find(a => String(a.id) === String(selectedBankAccountId))?.name ?? null
                              : null,
        bank_account:       isBankTransfer,
        payment_method:     payMethodName,  
      }

      const paysheetInvoiceRes = await authFetch('/ems/paysheet-invoices', {
        method: 'POST',
        body: JSON.stringify(invoicePayload),
      })
      if (!paysheetInvoiceRes.ok) {
        const errBody = await paysheetInvoiceRes.json().catch(() => ({}))
        console.warn('Paysheet invoice creation warning:', errBody)
      }

      // 3. Create invoice_header record
      const invoicePayloadHeader = {
        total_value: netSalary, full_amount: grossEarnings, amount_paid: netSalary,
        discount: totalDeducs, delivery_fee: 0, balance: 0,
        loyalty_points_earned: 0, loyalty_points_spent: 0, total_item: 1, total_weight: 0,
        payment_status: 'PAID', order_status: 'COMPLETED', currency: currencySymbol ?? 'LKR',
        paid_at: new Date().toISOString(),
        payment_method_id: payMethodId || null,
        payment_reference: payRef.trim(), note: noteStr,
        bank_slip: uploadedUrl ?? null,
        bank_account_id: (isBankTransfer && selectedBankAccountId) ? selectedBankAccountId : null,
        sender_name: empName, sender_email: employee?.email ?? null,
        sender_phone: employee?.contact_no ?? employee?.mobile_number ?? null,
        sender_address: employee?.address ?? null, sender_city: employee?.city ?? null,
        sender_country: employee?.country ?? null, sender_postal_code: null,
        user_id: userId, interface: 'ems_payroll',
        payments: JSON.stringify([{
          method: methodLabel, reference: payRef.trim(), amount: netSalary, date: new Date().toISOString().split('T')[0],
          paysheet_id: paysheet.paysheet_id, employee_id: paysheet.employee_id,
          employee_name: empName, payroll_month: paysheet.payroll_month,
          payroll_year: paysheet.payroll_year, pay_period: `${monthLabel} ${yearLabel}`,
          gross_earnings: grossEarnings, total_deductions: totalDeducs,
          bank_account_id: (isBankTransfer && selectedBankAccountId) ? selectedBankAccountId : null,
        }]),
      }

      const invoiceRes = await authFetch('/invoice-headers', {
        method: 'POST', body: JSON.stringify(invoicePayloadHeader),
      })
      if (!invoiceRes.ok) {
        const errBody = await invoiceRes.json().catch(() => ({}))
        console.warn('Invoice header creation warning:', errBody)
      }

      // 4. Post transaction to transaction uploader
      await postTransaction({ netSalary, empName, monthLabel, yearLabel })

      setMsg({ type: 'success', text: `Payment processed! Reference: ${payRef}. Paysheet marked as PAID.` })
      setTimeout(() => { onHide(); onPaySuccess?.(); refetchSheets?.() }, 2200)
    } catch (e) {
      setMsg({ type: 'danger', text: e.message ?? 'Payment failed. Please try again.' })
    } finally {
      setPaying(false)
    }
  }

  const month  = paysheet?.payroll_month ? MONTHS[paysheet.payroll_month - 1] : '—'
  const year   = paysheet?.payroll_year ?? '—'
  const netSal = parseFloat(paysheet?.net_salary || 0)
  const isPaid = (paysheet?.payroll_status ?? '') === 'PAID'

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap');
        .pay-modal-dlg .modal-content{border:none;border-radius:16px;overflow:hidden;box-shadow:0 28px 80px rgba(0,0,0,.28)}
        .pay-modal-dlg .modal-header{background:linear-gradient(135deg,#0b2447 0%,#19376d 60%,#1565c0 100%);border:none;padding:18px 26px}
        .pay-modal-dlg .modal-footer{background:#f8fafc;border-top:1px solid #e4eaf3;padding:14px 26px}
        .pay-slip-pane{background:#f0f2f5;padding:16px;overflow-y:auto;max-height:520px;border-right:1px solid #e4eaf3}
        .pay-slip-pane .page{margin:0 auto;box-shadow:0 2px 16px rgba(0,0,0,.10)}
        .pay-form-pane{padding:22px 24px;overflow-y:auto;max-height:520px;background:#fff}
        .pay-net-card{background:linear-gradient(135deg,#0b2447,#1565c0);color:#fff;border-radius:12px;padding:16px 20px;margin-bottom:18px}
        .pay-net-card .pnc-label{font-size:10px;text-transform:uppercase;letter-spacing:2px;opacity:.6;font-weight:700}
        .pay-net-card .pnc-amount{font-family:'DM Serif Display',serif;font-size:28px;letter-spacing:.5px;margin-top:2px}
        .pay-net-card .pnc-sub{font-size:11px;opacity:.5;margin-top:4px}
        .pay-section-title{font-size:10.5px;text-transform:uppercase;letter-spacing:1.5px;color:#7a8aa0;font-weight:700;margin-bottom:10px;margin-top:18px;padding-bottom:6px;border-bottom:1px solid #f0f2f5}
        .pay-section-title:first-of-type{margin-top:0}
        .pay-upload-zone{border:2px dashed #c8d8f0;border-radius:10px;padding:16px;text-align:center;cursor:pointer;transition:all .2s;background:#f7f9fc;display:block}
        .pay-upload-zone:hover{border-color:#1565c0;background:#edf2ff}
        .pay-upload-zone input{display:none}
        .pay-upload-zone .puz-icon{font-size:28px;color:#a0b4cc;margin-bottom:6px}
        .pay-upload-zone .puz-text{font-size:12.5px;color:#6c757d;font-weight:500}
        .pay-upload-zone .puz-sub{font-size:11px;color:#adb5bd;margin-top:2px}
        .pay-upload-zone.uploading-state{border-color:#0d6efd;background:#edf2ff;pointer-events:none}
        .pay-file-chip{display:flex;align-items:center;gap:8px;background:#edf2ff;border:1px solid #c8d8f0;border-radius:8px;padding:8px 12px;margin-top:8px}
        .pay-file-chip .pfc-name{font-size:12.5px;font-weight:600;color:#1a2332;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .pay-file-chip .pfc-remove{background:none;border:none;color:#dc3545;cursor:pointer;font-size:16px;padding:0;line-height:1}
        .pay-file-chip .pfc-s3-link{font-size:10.5px;color:#0d6efd;text-decoration:none;margin-left:4px}
        .pay-file-chip .pfc-s3-link:hover{text-decoration:underline}
        .pay-action-btn{background:linear-gradient(135deg,#1b6c3e,#20c997);border:none;color:#fff;font-weight:700;font-size:14px;padding:11px 28px;border-radius:10px;display:flex;align-items:center;gap:8px;transition:all .2s;letter-spacing:.3px}
        .pay-action-btn:hover:not(:disabled){background:linear-gradient(135deg,#155a33,#1aab83);transform:translateY(-1px);box-shadow:0 6px 20px rgba(32,201,151,.35)}
        .pay-action-btn:disabled{opacity:.6;cursor:not-allowed}
        .pay-action-btn.already-paid{background:linear-gradient(135deg,#6c757d,#495057)}
        .pay-tool-row{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:4px}
        .pay-tool-btn{display:flex;align-items:center;gap:5px;padding:7px 14px;border-radius:8px;font-size:12.5px;font-weight:600;border:1.5px solid;cursor:pointer;transition:all .15s;background:#fff}
        .pay-tool-btn:hover{filter:brightness(.95);transform:translateY(-1px)}
        .pay-tool-btn.print{border-color:#0b2447;color:#0b2447}
        .pay-tool-btn.print:hover{background:#0b2447;color:#fff}
        .pay-tool-btn.email{border-color:#0d6efd;color:#0d6efd}
        .pay-tool-btn.email:hover{background:#0d6efd;color:#fff}
        .pay-status-pill{display:inline-flex;align-items:center;gap:5px;padding:4px 12px;border-radius:20px;font-size:11.5px;font-weight:700;letter-spacing:.3px}
        .pay-status-pill.paid{background:#d1fae5;color:#065f46}
        .pay-bank-account-box{background:#f0f7ff;border:1.5px solid #c8d8f0;border-radius:10px;padding:12px 14px;margin-top:8px}
        .pay-bank-account-box .pba-title{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#3d5a80;font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:5px}
        .pay-slip-pane::-webkit-scrollbar,.pay-form-pane::-webkit-scrollbar{width:5px}
        .pay-slip-pane::-webkit-scrollbar-track,.pay-form-pane::-webkit-scrollbar-track{background:#f0f2f5}
        .pay-slip-pane::-webkit-scrollbar-thumb,.pay-form-pane::-webkit-scrollbar-thumb{background:#c8d8f0;border-radius:4px}
        ${PRINT_CSS.replace(/body\{/g,'.pay-slip-pane {')}
      `}</style>

      <Modal show={show} onHide={onHide} size="xl" centered dialogClassName="pay-modal-dlg">
        <Modal.Header closeButton>
          <Modal.Title style={{ color:'#fff', fontFamily:"'DM Serif Display',serif", fontSize:'18px', fontWeight:400, display:'flex', alignItems:'center', gap:10 }}>
            <Icon icon="mdi:cash-check" style={{ fontSize:22 }}/>
            Process Payment
            <span style={{ fontSize:'13px', opacity:.65, fontFamily:'DM Sans,sans-serif', fontWeight:500 }}>
              &nbsp;·&nbsp; #{paysheet?.paysheet_id} &nbsp;·&nbsp; {month} {year}
            </span>
            {isPaid && (
              <span className="pay-status-pill paid" style={{ marginLeft:4 }}>
                <Icon icon="mdi:check-circle" style={{ fontSize:14 }}/> PAID
              </span>
            )}
          </Modal.Title>
        </Modal.Header>

        <Modal.Body style={{ padding:0 }}>
          <Row style={{ margin:0 }}>
            <Col md={7} style={{ padding:0 }}>
              <div className="pay-slip-pane">
                {detailsLoading ? (
                  <div className="d-flex justify-content-center align-items-center" style={{ minHeight:300 }}>
                    <Spinner animation="border" variant="primary"/>
                    <span className="ms-3 text-muted">Loading payslip…</span>
                  </div>
                ) : (
                  <div ref={printRef}>
                    <PayslipDocument paysheet={paysheet} details={details} employee={employee} companyName={companyName} currencySymbol={currencySymbol}/>
                  </div>
                )}
              </div>
            </Col>

            <Col md={5} style={{ padding:0 }}>
              <div className="pay-form-pane">
                {msg && <Alert variant={msg.type} className="mb-3 py-2" style={{ fontSize:13 }}>{msg.text}</Alert>}

                {/* 1. Net Payable card */}
                <div className="pay-net-card">
                  <div className="pnc-label">Net Payable</div>
                  <div className="pnc-amount">{currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</div>
                  <div className="pnc-sub">{numberToWords(Math.floor(netSal))} {currencySymbol} Only</div>
                </div>

                {/* 2. Quick Actions (print + email buttons) */}
                <div className="pay-section-title">Quick Actions</div>
                <div className="pay-tool-row">
                  <button className="pay-tool-btn print" onClick={handlePrint} disabled={detailsLoading}>
                    <Icon icon="mdi:printer-outline" style={{ fontSize:15 }}/> Download PDF
                  </button>
                  <button className="pay-tool-btn email" onClick={handleEmail} disabled={emailing || !emailAddr}>
                    {emailing
                      ? <><Spinner size="sm" style={{ width:12, height:12 }}/> Sending…</>
                      : <><Icon icon="mdi:email-send-outline" style={{ fontSize:15 }}/> Email Payslip</>}
                  </button>
                </div>

                {/* 3. Email address input */}
                <div style={{ marginTop:8 }}>
                  <FormLabel style={{ fontSize:11, fontWeight:600, color:'#6c757d', textTransform:'uppercase', letterSpacing:'.5px' }}>
                    Email Address
                  </FormLabel>
                  <FormControl size="sm" type="email" placeholder="employee@company.com"
                    value={emailAddr} onChange={e => setEmailAddr(e.target.value)}/>
                </div>

                {/* 4. Payment Details (method + bank account + reference) */}
                <div className="pay-section-title">Payment Details</div>

                <FormGroup className="mb-2">
                  <FormLabel style={{ fontSize:11, fontWeight:600, color:'#6c757d', textTransform:'uppercase', letterSpacing:'.5px' }}>
                    Payment Method *
                  </FormLabel>
                  {methodsLoading ? (
                    <div className="d-flex align-items-center gap-2 py-1">
                      <Spinner size="sm" variant="primary" style={{ width:14, height:14 }}/>
                      <span style={{ fontSize:12, color:'#6c757d' }}>Loading payment methods…</span>
                    </div>
                  ) : (
                    <FormSelect
                      size="sm"
                      value={payMethodId}
                      onChange={e => {
                        const selected = paymentMethods.find(m => String(m.id) === e.target.value)
                        setPayMethodId(e.target.value)
                        setPayMethodName(selected?.name ?? '')
                        setSelectedBankAccountId('')
                      }}
                      disabled={isPaid}
                    >
                      <option value="">— Select Payment Method —</option>
                      {paymentMethods.map(m => (
                        <option key={m.id} value={String(m.id)}>{m.name}</option>
                      ))}
                    </FormSelect>
                  )}
                </FormGroup>

                {/* Bank account — only shows when Bank Transfer selected */}
                {isBankTransfer && (
                  <div className="pay-bank-account-box mb-2">
                    <div className="pba-title">
                      <Icon icon="mdi:bank-outline" style={{ fontSize:13 }}/>
                      Select Bank Account
                    </div>
                    {accountsLoading ? (
                      <div className="d-flex align-items-center gap-2">
                        <Spinner size="sm" variant="primary" style={{ width:14, height:14 }}/>
                        <span style={{ fontSize:12, color:'#6c757d' }}>Loading bank accounts…</span>
                      </div>
                    ) : bankAccounts.length === 0 ? (
                      <div style={{ fontSize:12, color:'#9b2222', display:'flex', alignItems:'center', gap:5 }}>
                        <Icon icon="mdi:alert-outline" style={{ fontSize:14 }}/>
                        No bank accounts found. Please add one in Accounts.
                      </div>
                    ) : (
                      <FormSelect
                        size="sm"
                        value={selectedBankAccountId}
                        onChange={e => setSelectedBankAccountId(e.target.value)}
                        disabled={isPaid}
                      >
                        <option value="">— Select Bank Account —</option>
                        {bankAccounts.map(acc => (
                          <option key={acc.id} value={String(acc.id)}>
                            {acc.name}
                            {acc.balance !== undefined
                              ? ` — ${currencySymbol} ${Number(acc.balance).toLocaleString('en-LK', { minimumFractionDigits: 2 })}`
                              : ''}
                          </option>
                        ))}
                      </FormSelect>
                    )}
                  </div>
                )}

                <FormGroup className="mb-2">
                  <FormLabel style={{ fontSize:11, fontWeight:600, color:'#6c757d', textTransform:'uppercase', letterSpacing:'.5px' }}>
                    Payment Reference *
                  </FormLabel>
                  <FormControl size="sm" placeholder="e.g. TXN-20240301-001 or Cheque #12345"
                    value={payRef} onChange={e => setPayRef(e.target.value)} disabled={isPaid}/>
                  <div style={{ fontSize:10.5, color:'#adb5bd', marginTop:3 }}>
                    Transaction ID, cheque number, or payment receipt number
                  </div>
                </FormGroup>

                {/* 5. Admin Note */}
                <FormGroup className="mb-3">
                  <FormLabel style={{ fontSize:11, fontWeight:600, color:'#6c757d', textTransform:'uppercase', letterSpacing:'.5px' }}>
                    Admin Note
                  </FormLabel>
                  <FormControl as="textarea" rows={3} size="sm"
                    placeholder="Optional internal note about this payment…"
                    value={adminNote} onChange={e => setAdminNote(e.target.value)} disabled={isPaid}
                    style={{ resize:'none' }}/>
                  <div style={{ fontSize:10.5, color:'#adb5bd', marginTop:3 }}>
                    This note will be included in the transaction log
                  </div>
                </FormGroup>

                {/* 6. Upload Payslip — now LAST */}
                <div className="pay-section-title">Upload Payslip Document</div>
                <label className={`pay-upload-zone${uploading ? ' uploading-state' : ''}`}>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} disabled={uploading}/>
                  {uploading ? (
                    <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'center' }}>
                      <Spinner size="sm" variant="primary"/>
                      <span style={{ fontSize:12.5, color:'#0d6efd', fontWeight:600 }}>Uploading to S3…</span>
                    </div>
                  ) : uploadedUrl ? (
                    <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'center' }}>
                      <Icon icon="mdi:cloud-check-outline" style={{ fontSize:24, color:'#1b6c3e' }}/>
                      <span style={{ fontSize:12.5, fontWeight:600, color:'#1b6c3e' }}>Uploaded — click to replace</span>
                    </div>
                  ) : (
                    <>
                      <div className="puz-icon"><Icon icon="mdi:cloud-upload-outline"/></div>
                      <div className="puz-text">Click to upload payslip</div>
                      <div className="puz-sub">PDF, JPG, PNG — max 10 MB · Saved to S3</div>
                    </>
                  )}
                </label>
                {uploadedFile && (
                  <div className="pay-file-chip">
                    <Icon icon="mdi:file-pdf-box" style={{ fontSize:20, color:'#dc3545' }}/>
                    <span className="pfc-name">{uploadedFile.name}</span>
                    {uploadedUrl && (
                      <a href={uploadedUrl} target="_blank" rel="noreferrer" className="pfc-s3-link">
                        <Icon icon="mdi:open-in-new" style={{ fontSize:12 }}/> View
                      </a>
                    )}
                    <button className="pfc-remove" onClick={removeUpload} disabled={uploading}>
                      <Icon icon="mdi:close-circle"/>
                    </button>
                  </div>
                )}

                {/* 7. Info note */}
                <div style={{ background:'#f0f7ff', border:'1px solid #c8d8f0', borderRadius:8, padding:'10px 12px', marginTop:16, marginBottom:16, fontSize:12, color:'#3d5a80' }}>
                  <Icon icon="mdi:information-outline" style={{ marginRight:5, verticalAlign:'middle' }}/>
                  Clicking <strong>Pay</strong> will mark this paysheet as <strong>PAID</strong>,
                  save the payslip to S3 (if uploaded), create an <strong>invoice_header</strong> record,
                  and post an <strong>expense transaction</strong> to the selected account.
                </div>
              </div>
            </Col>
          </Row>
        </Modal.Body>

        <Modal.Footer style={{ justifyContent:'space-between' }}>
          <small className="text-muted">
            Paysheet <strong>#{paysheet?.paysheet_id}</strong>
            &nbsp;·&nbsp; Period: <strong>{month} {year}</strong>
            &nbsp;·&nbsp; Net: <strong>{currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</strong>
          </small>
          <div className="d-flex gap-2 align-items-center">
            <Button variant="outline-secondary" onClick={onHide}>Close</Button>
            {isPaid ? (
              <button className="pay-action-btn already-paid" disabled>
                <Icon icon="mdi:check-circle" style={{ fontSize:18 }}/> Already Paid
              </button>
            ) : (
              <button className="pay-action-btn" onClick={handlePay}
                disabled={paying || !payRef.trim() || uploading || (isBankTransfer && !selectedBankAccountId)}>
                {paying
                  ? <><Spinner size="sm" style={{ width:16, height:16 }}/> Processing…</>
                  : <><Icon icon="mdi:cash-check" style={{ fontSize:18 }}/> Pay {currencySymbol} {Number(netSal).toLocaleString('en-LK', { minimumFractionDigits: 2 })}</>}
              </button>
            )}
          </div>
        </Modal.Footer>
      </Modal>
    </>
  )
}

// ─── Week helpers ──────────────────────────────────────────────────────────────
function getWeeksInMonth(year, month) {
  const firstDay = new Date(year, month - 1, 1)
  const lastDay  = new Date(year, month, 0)
  const weeks    = []
  let cursor     = new Date(firstDay)
  const dow = cursor.getDay()
  const diff = dow === 0 ? -6 : 1 - dow
  cursor.setDate(cursor.getDate() + diff)
  let weekNum = 1
  while (cursor <= lastDay) {
    const start = new Date(cursor)
    const end   = new Date(cursor)
    end.setDate(end.getDate() + 6)
    const overlapStart = start < firstDay ? firstDay : start
    const overlapEnd   = end   > lastDay  ? lastDay  : end
    const fmt = (d) => d.toLocaleDateString('en-GB', { day:'2-digit', month:'short' })
    weeks.push({
      label:      `Week ${weekNum} · ${fmt(overlapStart)} – ${fmt(overlapEnd)}`,
      weekStart:  toDateStr(start),
      weekEnd:    toDateStr(end),
      rangeStart: toDateStr(overlapStart),
      rangeEnd:   toDateStr(overlapEnd),
      weekNum,
    })
    cursor.setDate(cursor.getDate() + 7)
    weekNum++
  }
  return weeks
}

const toDateStr = (d) => {
  const y   = d.getFullYear()
  const m   = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

const WeekDayStrip = ({ weekStart, month, year }) => {
  const days = []
  const cursor = new Date(weekStart + 'T00:00:00')
  const DAY_LABELS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
  for (let i = 0; i < 7; i++) {
    const d = new Date(cursor)
    d.setDate(cursor.getDate() + i)
    const inMonth = d.getMonth() + 1 === month && d.getFullYear() === year
    days.push({ date: d.getDate(), label: DAY_LABELS[i], inMonth })
  }
  return (
    <div style={{ display:'flex', gap:4, marginTop:8, flexWrap:'wrap' }}>
      {days.map((d, i) => (
        <div key={i} style={{
          display:'flex', flexDirection:'column', alignItems:'center',
          width:34, padding:'4px 2px', borderRadius:6,
          background: d.inMonth ? '#d1fae5' : '#f1f3f5',
          border: d.inMonth ? '1px solid #a7f3d0' : '1px solid #e9ecef',
          opacity: d.inMonth ? 1 : 0.45,
        }}>
          <span style={{ fontSize:'8.5px', color: d.inMonth ? '#065f46' : '#9ca3af', fontWeight:700, textTransform:'uppercase' }}>
            {d.label}
          </span>
          <span style={{ fontSize:'12px', fontWeight:700, color: d.inMonth ? '#064e3b' : '#6b7280', lineHeight:1.3 }}>
            {d.date}
          </span>
        </div>
      ))}
    </div>
  )
}

const PayrollPeriodSelector = ({
  payrollType, month, setMonth, year, setYear,
  selectedDate, setSelectedDate, selectedWeek, setSelectedWeek, years,
}) => {
  const type = (payrollType || 'MONTHLY').toUpperCase()
  const weeks = useMemo(() => {
    if (type !== 'WEEKLY' || !month || !year) return []
    return getWeeksInMonth(Number(year), Number(month))
  }, [type, month, year])
  useEffect(() => { setSelectedWeek(null) }, [month, year])

  if (type === 'DAILY') return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Date</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>Date <span style={{ color:'#dc3545' }}>*</span>
            <span className="ms-2 badge bg-info text-dark" style={{ fontSize:'10px' }}>DAILY</span>
          </FormLabel>
          <FormControl type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}/>
          {selectedDate && (
            <div style={{ fontSize:'11px', color:'#6c757d', marginTop:4 }}>
              Payroll for: <strong>{new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { weekday:'long', day:'2-digit', month:'long', year:'numeric' })}</strong>
            </div>
          )}
        </Col>
        <Col md={6}>
          <FormLabel>Day of Week</FormLabel>
          <FormControl readOnly className="bg-light" placeholder="Auto-filled"
            value={selectedDate ? new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { weekday:'long' }) : ''}/>
        </Col>
      </Row>
    </>
  )

  if (type === 'WEEKLY') return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Period</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>Month <span style={{ color:'#dc3545' }}>*</span>
            <span className="ms-2 badge bg-warning text-dark" style={{ fontSize:'10px' }}>WEEKLY</span>
          </FormLabel>
          <FormSelect value={month} onChange={e => setMonth(e.target.value)}>
            <option value="">— Select Month —</option>
            {MONTHS.map((m, i) => <option key={i} value={i+1}>{m}</option>)}
          </FormSelect>
        </Col>
        <Col md={6}>
          <FormLabel>Year <span style={{ color:'#dc3545' }}>*</span></FormLabel>
          <FormSelect value={year} onChange={e => setYear(e.target.value)}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </FormSelect>
        </Col>
      </Row>
      {month && year && (
        <div style={{ marginTop:16 }}>
          <FormLabel>Select Week <span style={{ color:'#dc3545' }}>*</span></FormLabel>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {weeks.map((w) => {
              const isSelected = selectedWeek?.weekNum === w.weekNum
              return (
                <button key={w.weekNum} type="button" onClick={() => setSelectedWeek(w)} style={{
                  border: isSelected ? '2px solid #198754' : '1.5px solid #dee2e6',
                  borderRadius:10, padding:'10px 14px',
                  background: isSelected ? '#edfaf3' : '#fff',
                  cursor:'pointer', textAlign:'left',
                }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontWeight:700, fontSize:13, color: isSelected ? '#1b6c3e' : '#1a2332' }}>{w.label}</span>
                    {isSelected && <Icon icon="mdi:check-circle" style={{ color:'#198754', fontSize:18 }}/>}
                  </div>
                  <WeekDayStrip weekStart={w.weekStart} month={Number(month)} year={Number(year)}/>
                </button>
              )
            })}
          </div>
          {selectedWeek && (
            <div style={{ marginTop:10, padding:'8px 12px', background:'#f0f7ff', border:'1px solid #c8d8f0', borderRadius:8, fontSize:12, color:'#3d5a80' }}>
              Salary range: <strong>{selectedWeek.rangeStart}</strong> → <strong>{selectedWeek.rangeEnd}</strong>
            </div>
          )}
        </div>
      )}
    </>
  )

  return (
    <>
      <h6 className="gw-section-divider"><span>Payroll Period</span></h6>
      <Row className="g-3 my-0">
        <Col md={6}>
          <FormLabel>Month <span style={{ color:'#dc3545' }}>*</span>
            <span className="ms-2 badge bg-secondary" style={{ fontSize:'10px' }}>MONTHLY</span>
          </FormLabel>
          <FormSelect value={month} onChange={e => setMonth(e.target.value)}>
            <option value="">— Select Month —</option>
            {MONTHS.map((m, i) => <option key={i} value={i+1}>{m}</option>)}
          </FormSelect>
        </Col>
        <Col md={6}>
          <FormLabel>Year <span style={{ color:'#dc3545' }}>*</span></FormLabel>
          <FormSelect value={year} onChange={e => setYear(e.target.value)}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </FormSelect>
        </Col>
      </Row>
    </>
  )
}
// ─── GenerateWizardModal ───────────────────────────────────────────────────────
// ─── GenerateWizardModal ───────────────────────────────────────────────────────
const GenerateWizardModal = ({ show, onHide, employees, onSuccess, currencySymbol }) => {
  const fmt = makeFmt(currencySymbol)
  const cy    = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => cy - 2 + i)

  const [step,         setStep]         = useState(1)
  const [empId,        setEmpId]        = useState('')
  const [month,        setMonth]        = useState('')
  const [year,         setYear]         = useState(String(cy))
  const [selectedDate, setSelectedDate] = useState('')
  const [selectedWeek, setSelectedWeek] = useState(null)
  const [payrollType,  setPayrollType]  = useState('MONTHLY')
  const [msg,          setMsg]          = useState(null)
  const [busy,         setBusy]         = useState(false)
  const [loading,      setLoading]      = useState(false)
  const [earnings,     setEarnings]     = useState([])
  const [deductions,   setDeductions]   = useState([])

  const [autoCalc, setAutoCalc] = useState({
    normalOtHours:0, holidayOtHours:0, normalOtAmount:0, holidayOtAmount:0,
    noPayAmount:0,lateDeductionAmount:0,absentDays:0, unpaidLeaveDays:0, lateNoPayDays:0,
    totalNoPayDays:0, otHourRate:0, holidayOtRate:0, noPayRate:0,
    lateCount:0, loaded:false, 
  })

  const token = () =>
    typeof window !== 'undefined' ? sessionStorage.getItem('access_token') ?? '' : ''
  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: { Authorization: `Bearer ${token()}`, 'Content-Type': 'application/json', ...(opts.headers ?? {}) },
    })

  const selectedEmp = employees.find(e => String(e.employee_id) === String(empId))

  const salaryRange = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY')  return selectedDate ? { start: selectedDate, end: selectedDate } : null
    if (type === 'WEEKLY') return selectedWeek ? { start: selectedWeek.weekStart, end: selectedWeek.weekEnd } : null
    if (!month || !year)   return null
    const m = Number(month), y = Number(year)
    const start = `${y}-${String(m).padStart(2,'0')}-01`
    const lastDay = new Date(y, m, 0).getDate()
    return { start, end: `${y}-${String(m).padStart(2,'0')}-${lastDay}` }
  }, [payrollType, month, year, selectedDate, selectedWeek])

  const periodLabel = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY'  && selectedDate)  return new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-GB', { day:'2-digit', month:'long', year:'numeric' })
    if (type === 'WEEKLY' && selectedWeek)  return selectedWeek.label
    if (month && year) return `${MONTHS[Number(month)-1]} ${year}`
    return '—'
  }, [payrollType, month, year, selectedDate, selectedWeek])

  const isPeriodValid = useMemo(() => {
    const type = (payrollType || 'MONTHLY').toUpperCase()
    if (type === 'DAILY')  return !!selectedDate
    if (type === 'WEEKLY') return !!month && !!year && !!selectedWeek
    return !!month && !!year
  }, [payrollType, month, year, selectedDate, selectedWeek])

  useEffect(() => {
    if (show) {
      setStep(1); setEmpId(''); setMonth(''); setYear(String(cy))
      setSelectedDate(''); setSelectedWeek(null); setPayrollType('MONTHLY')
      setMsg(null); setBusy(false); setEarnings([]); setDeductions([])
      setAutoCalc({ normalOtHours:0, holidayOtHours:0, normalOtAmount:0, holidayOtAmount:0, noPayAmount:0, lateDeductionAmount:0, absentDays:0, unpaidLeaveDays:0, lateNoPayDays:0, totalNoPayDays:0, otHourRate:0, holidayOtRate:0, noPayRate:0, lateCount:0, loaded:false })
    }
  }, [show])

  const fixedEarningsBase = useMemo(() =>
    earnings.filter(e => e.checked && e.amountType === 'LKR').reduce((s,r) => s + (parseFloat(r.amount)||0), 0), [earnings])

  const grossEarnings = useMemo(() =>
    earnings.filter(e => e.checked).reduce((s,r) => s + resolveToLKR(r.amount, r.amountType, fixedEarningsBase), 0), [earnings, fixedEarningsBase])

  const totalDeductions = useMemo(() =>
    deductions.filter(d => d.checked).reduce((s,r) => s + resolveToLKR(r.amount, r.amountType, grossEarnings), 0), [deductions, grossEarnings])

  const estTotalEarnings   = grossEarnings   + autoCalc.normalOtAmount + autoCalc.holidayOtAmount
  const estTotalDeductions = totalDeductions + autoCalc.noPayAmount    + autoCalc.lateDeductionAmount
  const estNetSalary       = estTotalEarnings - estTotalDeductions

  const handleNext = async () => {
    if (!empId) { setMsg({ type:'danger', text:'Please select an employee.' }); return }
    if (!isPeriodValid) {
      const type = (payrollType || 'MONTHLY').toUpperCase()
      setMsg({ type:'danger', text: type === 'DAILY' ? 'Please select a date.' : type === 'WEEKLY' ? 'Please select a month, year and week.' : 'Please select a month and year.' })
      return
    }
    setMsg(null); setLoading(true)
    try {
      const { start, end } = salaryRange
      const rangeDate = new Date(start + 'T00:00:00')
      const pMonth = rangeDate.getMonth() + 1
      const pYear  = rangeDate.getFullYear()

      const empRes = await authFetch(`/ems/employees/${empId}`)
      if (!empRes.ok) throw new Error('Failed to fetch employee')
      const empData = await empRes.json()
      const templateId = empData?.payroll_template_id
      if (!templateId) { setMsg({ type:'warning', text:'This employee has no payroll template assigned.' }); return }

      const empGenType = empData?.salary_generation_type ?? 'MANUAL'
      if (empGenType === 'AUTO') {
        setMsg({ type:'warning', text:`${empData.first_name} ${empData.last_name} is set to AUTO paysheet generation. Manual generation is disabled.` })
        setLoading(false); return
      }

      const tplRes  = await authFetch(`/ems/payroll-templates/${templateId}`)
      if (!tplRes.ok) throw new Error('Failed to fetch payroll template')
      const tplData = await tplRes.json()
      setPayrollType((tplData?.payroll_type ?? 'MONTHLY').toUpperCase())

      const otHourRate    = Number(tplData?.ot_hour_rate)         || 0
      const holidayOtRate = Number(tplData?.holiday_ot_hour_rate) || 0
      const noPayRate     = Number(tplData?.no_pay_deduction_rate)|| 0

      const detRes = await authFetch(`/ems/payroll-template/${templateId}`)
      if (!detRes.ok) throw new Error('Failed to fetch template details')
      const detData = await detRes.json()
      const rows = Array.isArray(detData) ? detData : (detData?.data ?? [])
      if (rows.length === 0) { setMsg({ type:'warning', text:'This payroll template has no earnings or deductions configured.' }); return }

      const getName  = (r) => r.earning_deduction_name ?? r.ed_master_name ?? r.name ?? '—'
      const buildRow = (r) => {
        const storedValue = Number(r.value ?? 0); const storedAmount = Number(r.amount ?? 0)
        const isPercent = storedValue > 0 && storedAmount === 0
        return { earning_deduction_id: r.earning_deduction_id ?? null, name: getName(r), amount: isPercent ? String(storedValue) : String(storedAmount), amountType: isPercent ? 'PERCENTAGE' : 'LKR', checked: true, isCustom: false }
      }
      setEarnings(rows.filter(r  => ['EARNING','EARNINGS'].includes((r.type ?? '').toUpperCase())).map(buildRow))
      setDeductions(rows.filter(r => ['DEDUCTION','DEDUCTIONS'].includes((r.type ?? '').toUpperCase())).map(buildRow))

      let attData = {}
      try {
        const attRes = await authFetch(`/ems/attendance-summary?employee_id=${empId}&start=${start}&end=${end}`)
        if (attRes.ok) attData = await attRes.json()
      } catch { /* graceful */ }

      const normalOtHours  = Number(attData.normal_overtime_minutes  || 0) / 60
      const holidayOtHours = Number(attData.holiday_overtime_minutes || 0) / 60
      const absentDays     = Number(attData.absent_days      || 0)
      const unpaidLeaveDays= Number(attData.unpaid_leave_days || 0)
      const lateCount      = Number(attData.late_count        || 0)
      const lateNoPayDays  = Math.floor(lateCount / 3)
      const totalNoPayDays = absentDays + unpaidLeaveDays + lateNoPayDays

     const noPayOnlyDays = absentDays + unpaidLeaveDays;
      setAutoCalc({
        normalOtHours,
        holidayOtHours,
        normalOtAmount:       parseFloat((normalOtHours * otHourRate).toFixed(2)),
        holidayOtAmount:      parseFloat((holidayOtHours * holidayOtRate).toFixed(2)),
        noPayAmount:          parseFloat((noPayOnlyDays * noPayRate).toFixed(2)),       // ← only absent+unpaid
        lateDeductionAmount:  parseFloat((lateNoPayDays * noPayRate).toFixed(2)),       // ← NEW
        absentDays,
        unpaidLeaveDays,
        lateNoPayDays,
        totalNoPayDays,
        otHourRate,
        holidayOtRate,
        noPayRate,
        lateCount,
        loaded: true,
      })
      setStep(2)
    } catch (err) {
      setMsg({ type:'danger', text: err.message ?? 'Failed to load template details.' })
    } finally { setLoading(false) }
  }

  const handleGenerate = async () => {
    setMsg(null); setBusy(true)
    try {
      const { start, end } = salaryRange
      const rangeDate = new Date(start + 'T00:00:00')
      const pMonth = rangeDate.getMonth() + 1
      const pYear  = rangeDate.getFullYear()

      const earningItems = earnings.filter(e => e.checked && e.name).map(e => {
        const lkr = resolveToLKR(e.amount, e.amountType, fixedEarningsBase)
        return lkr > 0 ? { earning_deduction_id: e.earning_deduction_id ?? null, name: e.name, type:'EARNINGS', amount: parseFloat(lkr.toFixed(2)) } : null
      }).filter(Boolean)

      const deductionItems = deductions.filter(d => d.checked && d.name).map(d => {
        const lkr = resolveToLKR(d.amount, d.amountType, grossEarnings)
        return lkr > 0 ? { earning_deduction_id: d.earning_deduction_id ?? null, name: d.name, type:'DEDUCTIONS', amount: parseFloat(lkr.toFixed(2)) } : null
      }).filter(Boolean)

      const calcEarnings   = earningItems.reduce((s,r)   => s + r.amount, 0)
      const calcDeductions = deductionItems.reduce((s,r) => s + r.amount, 0)

      const payload = {
        employee_id: Number(empId), payroll_month: pMonth, payroll_year: pYear,
        salary_range_start: start, salary_range_end: end,
        total_earnings: calcEarnings, total_deductions: calcDeductions,
        net_salary: calcEarnings - calcDeductions,
        line_items: [...earningItems, ...deductionItems],
      }

      const res = await authFetch('/ems/paysheet', { method:'POST', body: JSON.stringify(payload) })
      if (!res.ok) { const e = await res.json(); throw new Error(e?.message ?? 'Generation failed') }
      const result = await res.json()

      const extras = []
      if (result.normal_ot_amount       > 0) extras.push(`Normal OT +${currencySymbol} ${fmt(result.normal_ot_amount)}`)
      if (result.holiday_ot_amount      > 0) extras.push(`Holiday OT +${currencySymbol} ${fmt(result.holiday_ot_amount)}`)
      if (result.no_pay_amount          > 0) extras.push(`No-Pay −${currencySymbol} ${fmt(result.no_pay_amount)}`)
      if (result.late_deduction_amount  > 0) extras.push(`Late Deduction −${currencySymbol} ${fmt(result.late_deduction_amount)}`)

      setMsg({ type:'success', text:`Paysheet for ${periodLabel} generated! Net: ${currencySymbol} ${fmt(result.net_salary)}${extras.length ? ' · '+extras.join(' · ') : ''}` })
      setTimeout(() => { onHide(); onSuccess?.() }, 2400)
    } catch (e) {
      setMsg({ type:'danger', text: e?.message ?? 'Failed to generate paysheet.' })
    } finally { setBusy(false) }
  }

  const makeUpdater = (setter) => (idx, field, val) =>
    setter(prev => prev.map((item,i) => i === idx ? { ...item, [field]: val } : item))
  const updE = makeUpdater(setEarnings); const updD = makeUpdater(setDeductions)
  const addEarning    = () => setEarnings(p  => [...p, { earning_deduction_id:null, name:'', amount:'', amountType:'LKR', checked:true, isCustom:true }])
  const addDeduction  = () => setDeductions(p => [...p, { earning_deduction_id:null, name:'', amount:'', amountType:'LKR', checked:true, isCustom:true }])
  const removeEarning   = (idx) => setEarnings(p  => p.filter((_,i) => i !== idx))
  const removeDeduction = (idx) => setDeductions(p => p.filter((_,i) => i !== idx))

  return (
    <>
      <style>{`
        .gw-progress-wrap{display:flex;align-items:center;justify-content:center;padding-bottom:20px;border-bottom:1px solid #eee;gap:0;margin-bottom:24px}
        .gw-step-node{display:flex;flex-direction:column;align-items:center;gap:6px;flex-shrink:0}
        .gw-step-circle{width:38px;height:38px;border-radius:50%;border:2px solid #dee2e6;background:#fff;color:#adb5bd;font-weight:700;font-size:.9rem;display:flex;align-items:center;justify-content:center;transition:all .4s ease;z-index:1}
        .gw-step-node.active .gw-step-circle{border-color:#198754;background:#198754;color:#fff;box-shadow:0 0 0 4px rgba(25,135,84,.18)}
        .gw-step-node.completed .gw-step-circle{border-color:#198754;background:#d1e7dd;color:#198754}
        .gw-step-label{font-size:.72rem;font-weight:600;color:#adb5bd;text-transform:uppercase;letter-spacing:.5px;white-space:nowrap}
        .gw-step-node.active .gw-step-label,.gw-step-node.completed .gw-step-label{color:#198754}
        .gw-connector{flex:1;height:4px;background:#e9ecef;border-radius:2px;margin:0 8px;margin-bottom:22px;overflow:hidden;min-width:60px}
        .gw-connector-fill{height:100%;width:0%;background:linear-gradient(90deg,#198754,#20c997);border-radius:2px;transition:width .6s cubic-bezier(.4,0,.2,1)}
        .gw-connector-fill.filled{width:100%}
        .gw-section-divider{width:100%;text-align:center;border-bottom:1px solid #f0f0f0;line-height:.1em;margin:24px 0 18px}
        .gw-section-divider span{background:#fff;padding:0 10px;color:#adb5bd;font-size:.75rem;letter-spacing:1px;text-transform:uppercase}
        .gw-autocalc-panel{background:linear-gradient(135deg,#f0f4ff 0%,#edfaf3 100%);border:1.5px solid #c8d8f0;border-radius:10px;padding:14px 16px;margin-top:18px}
        .gw-autocalc-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#3d4f63;margin-bottom:10px;display:flex;align-items:center;gap:6px}
        .gw-ac-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
        .gw-ac-card{background:#fff;border-radius:8px;padding:10px 12px;border:1px solid #e0e7ef}
        .gw-ac-card .ac-label{font-size:9.5px;text-transform:uppercase;letter-spacing:.7px;color:#6c757d;font-weight:700;margin-bottom:3px}
        .gw-ac-card .ac-value{font-size:14px;font-weight:700;line-height:1.15}
        .gw-ac-card .ac-sub{font-size:10px;color:#adb5bd;margin-top:3px;line-height:1.3}
        .gw-ac-card.earn .ac-value{color:#1b6c3e}
        .gw-ac-card.dedu .ac-value{color:#9b2222}
        .gw-ac-card.zero .ac-value{color:#adb5bd}
        .gw-ac-note{font-size:10.5px;color:#6c757d;margin-top:10px;padding-top:8px;border-top:1px solid #e4eaf3;display:flex;align-items:flex-start;gap:5px;line-height:1.4}
        .gw-net-row{background:linear-gradient(90deg,#0b2447,#19376d);border-radius:8px;padding:12px 18px;display:flex;justify-content:space-between;align-items:center;margin-top:20px;color:#fff}
        .gw-net-row .nl{font-size:10px;text-transform:uppercase;letter-spacing:2px;opacity:.65;font-weight:600;display:flex;align-items:center;gap:6px}
        .gw-est-badge{font-size:9px;background:rgba(255,255,255,.18);border-radius:4px;padding:1px 7px;letter-spacing:.4px;font-weight:600}
        .gw-net-row .nv{font-size:20px;font-weight:700}
        .gw-net-row .nc{font-size:12px;opacity:.7;margin-right:3px}
        .gw-net-row .nw{font-size:11px;opacity:.5;margin-top:2px}
        .gw-fade{animation:gwFadeUp .35s ease-out}
        .gw-type-pill{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:20px;font-size:10.5px;font-weight:700;letter-spacing:.5px;text-transform:uppercase}
        .gw-type-pill.MONTHLY{background:#e9ecef;color:#495057}
        .gw-type-pill.WEEKLY{background:#fff3cd;color:#856404}
        .gw-type-pill.DAILY{background:#cff4fc;color:#055160}
        @keyframes gwFadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
      `}</style>
      <Modal show={show} onHide={onHide} size="xl" centered scrollable>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            Generate Paysheet
            {step === 2 && (
              <span className={`gw-type-pill ${(payrollType||'MONTHLY').toUpperCase()}`}>
                <Icon icon={payrollType==='DAILY' ? 'mdi:calendar-today' : payrollType==='WEEKLY' ? 'mdi:calendar-week' : 'mdi:calendar-month'} style={{ fontSize:13 }}/>
                {(payrollType||'MONTHLY').toUpperCase()}
              </span>
            )}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="px-2 pt-2">
            <div className="gw-progress-wrap">
              {[1,2].map((s) => {
                const labels = ['Employee & Period','Earnings & Deductions']
                const isCompleted = step > s; const isActive = step === s
                return (
                  <React.Fragment key={s}>
                    {s > 1 && <div className="gw-connector"><div className={`gw-connector-fill ${isCompleted?'filled':''}`}/></div>}
                    <div className={`gw-step-node ${isActive?'active':''} ${isCompleted?'completed':''}`}>
                      <div className="gw-step-circle">{isCompleted ? <Icon icon="solar:check-circle-bold" style={{fontSize:18}}/> : s}</div>
                      <span className="gw-step-label">{labels[s-1]}</span>
                    </div>
                  </React.Fragment>
                )
              })}
            </div>
            {msg && <Alert variant={msg.type} className="mb-3">{msg.text}</Alert>}

            {step === 1 && (
              <div className="gw-fade">
                <h6 className="gw-section-divider"><span>Select Employee</span></h6>
                <Row className="g-3 my-0">
                  <Col md={12}>
                    <FormLabel>Employee <span style={{ color:'#dc3545' }}>*</span></FormLabel>
                    <FormSelect value={empId} onChange={async e => {
                      const newEmpId = e.target.value
                      setEmpId(newEmpId)
                      setMsg(null)
                      setMonth('')
                      setSelectedDate('')
                      setSelectedWeek(null)
                      setPayrollType('MONTHLY') 

                      if (!newEmpId) return

                      try {
                        // Fetch employee to get template ID
                        const empRes = await authFetch(`/ems/employees/${newEmpId}`)
                        if (!empRes.ok) return
                        const empData = await empRes.json()
                        const templateId = empData?.payroll_template_id
                        if (!templateId) return

                        // Fetch template to get payroll_type
                        const tplRes = await authFetch(`/ems/payroll-templates/${templateId}`)
                        if (!tplRes.ok) return
                        const tplData = await tplRes.json()
                        const fetchedType = (tplData?.payroll_type ?? 'MONTHLY').toUpperCase()
                        setPayrollType(fetchedType)
                      } catch {
                      }
                    }}>
                      <option value="">— Select Employee —</option>
                      {employees.map(e => (
                        <option key={e.employee_id} value={e.employee_id}>
                          {e.first_name} {e.last_name} · #{e.employee_id}
                        </option>
                      ))}
                    </FormSelect>
                  </Col>
                  <Col md={6}>
                    <FormLabel>Employee ID</FormLabel>
                    <FormControl readOnly className="bg-light" placeholder="Auto-filled" value={selectedEmp ? `EMP-${String(selectedEmp.employee_id).padStart(4,'0')}` : ''}/>
                  </Col>
                  <Col md={6}>
                    <FormLabel>Department</FormLabel>
                    <FormControl readOnly className="bg-light" placeholder="Auto-filled" value={selectedEmp?.department_name ?? ''}/>
                  </Col>
                </Row>
                <PayrollPeriodSelector
                  payrollType={payrollType}
                  month={month}          setMonth={setMonth}
                  year={year}            setYear={setYear}
                  selectedDate={selectedDate} setSelectedDate={setSelectedDate}
                  selectedWeek={selectedWeek} setSelectedWeek={setSelectedWeek}
                  years={years}
                />
                {selectedEmp && (
                  <>
                    <h6 className="gw-section-divider"><span>Employee Details</span></h6>
                    <div className="border rounded p-3 bg-light">
                      <Row className="g-2">
                        {[['Name',`${selectedEmp.first_name} ${selectedEmp.last_name??''}`],['Designation',selectedEmp.designation_name??'—'],['Department',selectedEmp.department_name??'—'],['Template',selectedEmp.payroll_template_name??'Not assigned']].map(([label,value]) => (
                          <Col md={3} key={label}><small className="text-muted d-block" style={{fontSize:'0.7rem',textTransform:'uppercase',letterSpacing:'0.5px'}}>{label}</small><span style={{fontSize:'0.875rem',fontWeight:600}}>{value}</span></Col>
                        ))}
                      </Row>
                    </div>
                  </>
                )}
              </div>
            )}

            {step === 2 && (
              <div className="gw-fade">
                <div className="border rounded p-3 bg-light mb-2">
                  <Row className="g-2">
                    {[['Employee',`${selectedEmp?.first_name??''} ${selectedEmp?.last_name??''}`],['Employee ID',`EMP-${String(selectedEmp?.employee_id??0).padStart(4,'0')}`],['Pay Period',periodLabel],['Template',selectedEmp?.payroll_template_name??'—']].map(([label,value]) => (
                      <Col md={3} key={label}><small className="text-muted d-block" style={{fontSize:'0.7rem',textTransform:'uppercase',letterSpacing:'0.5px'}}>{label}</small><span style={{fontSize:'0.875rem',fontWeight:600}}>{value}</span></Col>
                    ))}
                  </Row>
                  {salaryRange && (
                    <div style={{ marginTop:8, fontSize:11, color:'#6c757d' }}>
                      Salary range: <strong>{salaryRange.start}</strong> → <strong>{salaryRange.end}</strong>
                    </div>
                  )}
                </div>
                <h6 className="gw-section-divider"><span>Earnings &amp; Deductions</span></h6>
                <Row className="g-3">
                  <LineItemTable title="Earnings" colorClass="success" headerClass="table-success" rows={earnings} onCheck={(i,v)=>updE(i,'checked',v)} onUpdate={updE} onAdd={addEarning} onRemove={removeEarning} addLabel="Add Earning" grossEarningsBase={fixedEarningsBase} currencySymbol={currencySymbol}/>
                  <LineItemTable title="Deductions" colorClass="danger" headerClass="table-danger" rows={deductions} onCheck={(i,v)=>updD(i,'checked',v)} onUpdate={updD} onAdd={addDeduction} onRemove={removeDeduction} addLabel="Add Deduction" grossEarningsBase={grossEarnings} currencySymbol={currencySymbol}/>
                </Row>
                <div className="gw-autocalc-panel">
                  <div className="gw-autocalc-title">
                    <Icon icon="mdi:cog-sync-outline" style={{fontSize:15}}/> Auto-Calculated by Server
                    <Badge bg={autoCalc.loaded?'success':'secondary'} style={{fontWeight:500,fontSize:'10px'}}>{autoCalc.loaded?'Estimated':'No attendance data'}</Badge>
                  </div>
                  <div className="gw-ac-grid">
                    <div className={`gw-ac-card ${autoCalc.normalOtAmount>0?'earn':'zero'}`}>
                      <div className="ac-label">Normal Overtime</div>
                      <div className="ac-value">{autoCalc.normalOtAmount>0?`+${currencySymbol} ${fmt(autoCalc.normalOtAmount)}`:'—'}</div>
                      <div className="ac-sub">{autoCalc.normalOtHours>0?`${autoCalc.normalOtHours.toFixed(2)} hrs × ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr`:`Rate: ${currencySymbol} ${fmt(autoCalc.otHourRate)}/hr · No OT`}</div>
                    </div>
                    <div className={`gw-ac-card ${autoCalc.holidayOtAmount>0?'earn':'zero'}`}>
                      <div className="ac-label">Holiday Overtime</div>
                      <div className="ac-value">{autoCalc.holidayOtAmount>0?`+${currencySymbol} ${fmt(autoCalc.holidayOtAmount)}`:'—'}</div>
                      <div className="ac-sub">{autoCalc.holidayOtHours>0?`${autoCalc.holidayOtHours.toFixed(2)} hrs × ${currencySymbol} ${fmt(autoCalc.holidayOtRate)}/hr`:`Rate: ${currencySymbol} ${fmt(autoCalc.holidayOtRate)}/hr · No holiday OT`}</div>
                    </div>
                    <div className={`gw-ac-card ${autoCalc.noPayAmount>0?'dedu':'zero'}`}>
                      <div className="ac-label">No-Pay Deduction</div>
                      <div className="ac-value">{autoCalc.noPayAmount>0?`−${currencySymbol} ${fmt(autoCalc.noPayAmount)}`:'—'}</div>
                      <div className="ac-sub">{autoCalc.noPayAmount>0?`${autoCalc.absentDays} absent + ${autoCalc.unpaidLeaveDays} unpaid × ${currencySymbol} ${fmt(autoCalc.noPayRate)}/day`:`Rate: ${currencySymbol} ${fmt(autoCalc.noPayRate)}/day · No absent/unpaid`}</div>
                    </div>
                    <div className={`gw-ac-card ${autoCalc.lateDeductionAmount>0?'dedu':'zero'}`}>
                      <div className="ac-label">Late Deduction</div>
                      <div className="ac-value">{autoCalc.lateDeductionAmount>0?`−${currencySymbol} ${fmt(autoCalc.lateDeductionAmount)}`:'—'}</div>
                      <div className="ac-sub">{autoCalc.lateCount>0?`${autoCalc.lateCount} late → ${autoCalc.lateNoPayDays} day(s) deducted`:`Every 3 lates = 1 day · No lates`}</div>
                    </div>
                  </div>
                <div className="gw-ac-note">
                      <Icon icon="mdi:information-outline" style={{fontSize:13,flexShrink:0,marginTop:1}}/>
                      Estimated from attendance data for <strong>{periodLabel}</strong>. Server recalculates on generation.
                    </div>
                  </div> {/* closes gw-autocalc-panel */}
               <div className="gw-net-row">
                  <div>
                    <div className="nl">Estimated Net Payable <span className="gw-est-badge">ESTIMATE</span></div>
                    <div className="nw">{estNetSalary>0?`${numberToWords(Math.floor(estNetSalary))} ${currencySymbol} Only`:`Zero ${currencySymbol} Only`}</div>
                  </div>
                  <div style={{textAlign:'right'}}>
                    <span className="nc">{currencySymbol}</span><span className="nv">{Number(estNetSalary).toLocaleString('en-LK',{minimumFractionDigits:2})}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Modal.Body>
        <Modal.Footer className="justify-content-between">
          <small className="text-muted">
            Currency: <strong>{currencySymbol}</strong>
            {step===2 && <>&nbsp;·&nbsp; Period: <strong>{periodLabel}</strong>&nbsp;·&nbsp; Type: <strong>{(payrollType||'MONTHLY').toUpperCase()}</strong></>}
          </small>
          <div className="d-flex gap-2">
            {step===1 ? (
              <>
                <Button variant="light" onClick={onHide}>Cancel</Button>
                <Button variant="primary" onClick={handleNext} disabled={loading||!empId||!isPeriodValid}>
                  {loading?<><Spinner size="sm" className="me-1"/>Loading…</>:<>Continue <Icon icon="solar:alt-arrow-right-linear"/></>}
                </Button>
              </>
            ) : (
              <>
                <Button variant="light" onClick={()=>{setStep(1);setMsg(null)}}><Icon icon="solar:alt-arrow-left-linear"/> Previous</Button>
                <Button variant="success" onClick={handleGenerate} disabled={busy}>
                  {busy?<><Spinner size="sm" className="me-1"/>Generating…</>:<><Icon icon="solar:check-read-linear" className="me-1"/>Generate &amp; Save</>}
                </Button>
              </>
            )}
          </div>
        </Modal.Footer>
      </Modal>
    </>
  )
}

// ─── PaysheetList (main page) ──────────────────────────────────────────────────
const PaysheetList = ({ companyName = 'OZONE DESK' }) => {
  const { currency } = useCurrencySymbol()
  const currencySymbol = currency ?? 'LKR'
  const fmt = makeFmt(currencySymbol)

  const cy    = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => cy - 2 + i)

  // ── Filter state ──────────────────────────────────────────────────────────
  const [filterKeyword, setFilterKeyword] = useState('')
  const [filterDateFrom, setFilterDateFrom] = useState('')
  const [filterDateTo,   setFilterDateTo]   = useState('')
  const [filterStatus,  setFilterStatus]  = useState('')
  const [searchKeyword, setSearchKeyword] = useState('')

  const [sheets,        setSheets]        = useState([])
  const [sheetsLoading, setSheetsLoading] = useState(false)
  const [fetchError,    setFetchError]    = useState(false)

  const { data: employees = [] } = useGetAllEmployeesListQuery()

  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages,  setTotalPages]  = useState(1)
  const PAGE_SIZE = 10 // adjust as needed

  // ── Employee options for react-select ─────────────────────────────────────
  const employeeOptions = employees
    .filter(e => {
      if (!searchKeyword || searchKeyword.length < 1) return true
      const kw = searchKeyword.toLowerCase()
      return (
        `${e.first_name} ${e.last_name}`.toLowerCase().includes(kw) ||
        String(e.employee_id).includes(kw)
      )
    })
    .map(e => ({
      label: `${e.first_name} ${e.last_name}`,
      value: String(e.employee_id),
    }))

  const token = () =>
    typeof window !== 'undefined' ? sessionStorage.getItem('access_token') ?? '' : ''

  // ── Core fetch — GET /ems/paysheet with query params ──────────────────────
const fetchSheets = async (overrides = {}) => {
  setSheetsLoading(true)
  setFetchError(false)
  try {
    const kw       = 'keyword'  in overrides ? overrides.keyword   : filterKeyword
    const dateFrom = 'dateFrom' in overrides ? overrides.dateFrom  : filterDateFrom
    const dateTo   = 'dateTo'   in overrides ? overrides.dateTo    : filterDateTo
    const status   = 'status'   in overrides ? overrides.status    : filterStatus
    const page     = 'page'     in overrides ? overrides.page      : currentPage

    const params = new URLSearchParams()
    if (kw)       params.append('keyword',   kw)
    if (dateFrom) params.append('date_from', dateFrom)
    if (dateTo)   params.append('date_to',   dateTo)
    if (status)   params.append('status',    status)
    params.append('page',     page)
    params.append('per_page', PAGE_SIZE)

    const url = `${process.env.NEXT_PUBLIC_BASE_URL}/ems/paysheet?${params.toString()}`
    const res = await fetch(url, {
      method: 'GET',
      headers: { Authorization: `Bearer ${token()}` },
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const data = await res.json()

    setSheets(Array.isArray(data?.data) ? data.data : [])
    setTotalPages(data?.totalPages ?? 1)
    setCurrentPage(page)

  } catch (err) {
    console.error('fetchSheets error:', err)
    setFetchError(true)
  } finally {
    setSheetsLoading(false)
  }
}
const handlePageChange = (page) => {
  if (page < 1 || page > totalPages) return
  fetchSheets({ page })
}
  useEffect(() => {
    fetchSheets({ keyword: '', month: '', year: '', status: '' })
  }, [])

  const handleReset = () => {
  setFilterKeyword('')
  setFilterDateFrom('')
  setFilterDateTo('')
  setFilterStatus('')
  setCurrentPage(1)
  fetchSheets({ keyword: '', dateFrom: '', dateTo: '', status: '', page: 1 })
}

  // ── Modals ────────────────────────────────────────────────────────────────
  const [modalOpen,       setModalOpen]       = useState(false)
  const [activeSheet,     setActiveSheet]     = useState(null)
  const [activeDetails,   setActiveDetails]   = useState([])
  const [detailsLoading,  setDetailsLoading]  = useState(false)

  const [payModalOpen,      setPayModalOpen]      = useState(false)
  const [paySheet,          setPaySheet]          = useState(null)
  const [payDetails,        setPayDetails]        = useState([])
  const [payDetailsLoading, setPayDetailsLoading] = useState(false)

  const [genOpen, setGenOpen] = useState(false)

  const authFetch = (url, opts = {}) =>
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${url}`, {
      ...opts,
      headers: {
        Authorization: `Bearer ${token()}`,
        'Content-Type': 'application/json',
        ...(opts.headers ?? {}),
      },
    })

  const fetchDetails = async (paysheetId) => {
    try {
      const res  = await authFetch(`/ems/paysheet-details/${paysheetId}`)
      const data = await res.json()
      return Array.isArray(data) ? data : (data?.data ?? [])
    } catch { return [] }
  }

  const openSlip = async (s) => {
    setActiveSheet(s); setActiveDetails([]); setModalOpen(true); setDetailsLoading(true)
    const details = await fetchDetails(s.paysheet_id)
    setActiveDetails(details); setDetailsLoading(false)
  }

  const openPay = async (s) => {
    setPaySheet(s); setPayDetails([]); setPayModalOpen(true); setPayDetailsLoading(true)
    const details = await fetchDetails(s.paysheet_id)
    setPayDetails(details); setPayDetailsLoading(false)
  }

  const activeEmpObj = employees.find(e => String(e.employee_id) === String(activeSheet?.employee_id))
  const payEmpObj    = employees.find(e => String(e.employee_id) === String(paySheet?.employee_id))

  // ── Styles ────────────────────────────────────────────────────────────────
  const selectStyles = {
    control: (base, state) => ({
      ...base,
      borderRadius: '999px',
      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
      boxShadow: state.isFocused
        ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)'
        : 'none',
      minHeight: '38px',
    }),
  }

  const roundedSelect = { borderRadius: '999px', borderColor: '#DEE2E6' }

  return (
    <>
      <style>{`
        .pay-btn-action{background:linear-gradient(135deg,#1b6c3e,#20c997);border:none;color:#fff;font-size:12px;font-weight:600;padding:0.3rem 0.85rem;border-radius:15px;display:inline-flex;align-items:center;gap:4px;cursor:pointer;transition:all .18s;letter-spacing:.2px}
        .pay-btn-action:hover:not(:disabled){background:linear-gradient(135deg,#155a33,#1aab83);transform:translateY(-1px);box-shadow:0 4px 12px rgba(32,201,151,.3)}
        .pay-btn-action:disabled{opacity:.55;cursor:default}
        .pay-btn-action.already-paid{background:linear-gradient(135deg,#6c757d,#495057)}
        .pay-btn-action.already-paid:hover{transform:none;box-shadow:none}
      `}</style>

      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center">
            <Col>
              <CardTitle as="h4" style={{ fontSize: 18 }} className="mb-0">
                <Icon icon="mdi:file-chart-outline" className="me-2 text-primary"/>
                Paysheets
              </CardTitle>
            </Col>
            <Col xs="auto">
              <Button variant="success" onClick={() => setGenOpen(true)}>
                <Icon icon="mdi:plus" className="me-1"/>Generate Paysheet
              </Button>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>

          {/* ── Filter bar ── */}
          <Form className="row g-2 mb-3">

          {/* Keyword */}
          <FormGroup className="col-md-3">
            <FormLabel>Keyword</FormLabel>
            <FormControl
              type="text"
              placeholder="Search by ID or Name"
              value={filterKeyword}
              onChange={e => setFilterKeyword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && fetchSheets({ page: 1 })}
            />
          </FormGroup>

          {/* Date range */}
          <FormGroup className="col-md-4">
            <div className="row g-1">
              <div className="col-6">
                <FormLabel>From Date</FormLabel>
                <FormControl
                  type="date"
                  value={filterDateFrom}
                  onChange={e => setFilterDateFrom(e.target.value)}

                />
              </div>
              <div className="col-6">
                <FormLabel>To Date</FormLabel>
                <FormControl
                  type="date"
                  value={filterDateTo}
                  onChange={e => setFilterDateTo(e.target.value)}

                />
              </div>
            </div>
          </FormGroup>

          {/* Status */}
          <FormGroup className="col-md-3">
            <FormLabel>Status</FormLabel>
            <FormSelect
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
            >
              <option value="">All Statuses</option>
              <option value="PAID">Paid</option>
              <option value="PENDING">Pending</option>
              <option value="DRAFT">Draft</option>
              <option value="GENERATED">Generated</option>
              <option value="APPROVED">Approved</option>
            </FormSelect>
          </FormGroup>

          {/* Search button */}
          <FormGroup className="col-md-2 d-flex align-items-end">
            <Button
              className="bg-primary border-primary flex-grow-1"
              onClick={() => fetchSheets({ page: 1 })}
              disabled={sheetsLoading}
            >
              <Icon icon="material-symbols:search-rounded" width="18" height="18" className="me-1" />
              Search
            </Button>
          </FormGroup>

        </Form>

          {/* ── Table ── */}
          {fetchError ? (
            <Alert variant="danger">Failed to load paysheets. Please try again.</Alert>
          ) : sheetsLoading ? (
            <div className="d-flex justify-content-center align-items-center py-5">
              <Spinner animation="border" variant="primary"/>
              <span className="ms-3 text-muted">Loading paysheets…</span>
            </div>
          ) : (
            <>
              <div className="d-flex justify-content-between align-items-center mb-2">
                <small className="text-muted">
                  Showing <strong>{sheets.length}</strong> paysheet{sheets.length !== 1 ? 's' : ''}
                </small>
              </div>
              <Table striped hover responsive>
                <thead>
                  <tr>
                    <th>Paysheet ID</th>
                    <th>Employee Name</th>
                    <th>Employee ID</th>
                    <th className="text-end">Pay Period</th>
                    <th className="text-end">Working Days</th>
                    <th className="text-end">Gross Earnings</th>
                    <th className="text-end">Deductions</th>
                    <th className="text-end">Net Salary ({currencySymbol})</th>
                    <th className="text-end">Status</th>
                    <th className="text-end" style={{ minWidth: 130 }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sheets.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="text-center py-5 text-muted">
                        <Icon icon="mdi:file-search-outline" width={32} className="mb-2 d-block mx-auto"/>
                        No paysheets found
                      </td>
                    </tr>
                  ) : sheets.map(s => {
                    const emp  = employees.find(e => String(e.employee_id) === String(s.employee_id))
                    const toTitleCase = (str) =>
                      str.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())

                    const rawName = s.employee_name
                      || s.employee_full_name
                      || (emp ? `${emp.first_name} ${emp.last_name}` : `#${s.employee_id}`)

                    const name = toTitleCase(rawName)
                    const isPaid = (s.payroll_status ?? '') === 'PAID'
                    return (
                      <tr key={s.paysheet_id}>
                        <td><span className="fw-semibold text-primary">#{s.paysheet_id}</span></td>
                        <td className="fw-semibold">{name}</td>
                        <td>
                          <Badge bg="light" text="dark" className="border">
                            EMP-{String(s.employee_id).padStart(4, '0')}
                          </Badge>
                        </td>
                        <td className="text-end">
                          {s.payroll_month && s.payroll_year
                            ? `${MONTHS[s.payroll_month - 1]} ${s.payroll_year}` : '—'}
                        </td>
                        <td className="text-end">{s.total_working_days ?? '—'}</td>
                        <td className="text-end text-success fw-semibold">
                          {Number(s.total_earnings || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="text-end text-danger">
                          {Number(s.total_deductions || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="text-end">
                          <span className="fw-bold" style={{ color: '#0b2447' }}>
                            {Number(s.net_salary || 0).toLocaleString('en-LK', { minimumFractionDigits: 2 })}
                          </span>
                        </td>
                        <td className="text-end">{statusBadge(s.payroll_status)}</td>
                        <td className="text-end">
                          <div className="d-flex gap-1 align-items-end justify-content-end">
                            <Button
                              size="sm" variant="primary"
                              style={{ borderRadius: 15, padding: '0.3rem 0.8rem' }}
                              onClick={() => openSlip(s)}
                            >
                              <Icon icon="mdi:eye" className="me-1"/>View
                            </Button>
                            <button
                              className={`pay-btn-action${isPaid ? ' already-paid' : ''}`}
                              onClick={() => !isPaid && openPay(s)}
                              title={isPaid ? 'Already Paid' : 'Process Payment'}
                            >
                              {isPaid
                                ? <><Icon icon="mdi:check-circle-outline" style={{ fontSize: 13 }}/> Paid</>
                                : <><Icon icon="mdi:cash-check" style={{ fontSize: 13 }}/> Pay</>}
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>
            </>
          )}

          {/* ================= PAGINATION ================= */}
{totalPages > 1 && (
  <div className="d-flex justify-content-end mt-3">
    <Pagination>
      <Pagination.Item disabled={currentPage === 1} onClick={() => handlePageChange(1)}>First</Pagination.Item>
      <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
      {(() => {
        let pages = []
        if (totalPages <= 5) {
          for (let i = 1; i <= totalPages; i++)
            pages.push(<Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>{i}</Pagination.Item>)
        } else {
          let start = Math.max(1, currentPage - 2)
          let end   = Math.min(totalPages, currentPage + 2)
          if (start === 1) end = 5
          if (end === totalPages) start = totalPages - 4
          for (let i = start; i <= end; i++)
            pages.push(<Pagination.Item key={i} active={i === currentPage} onClick={() => handlePageChange(i)}>{i}</Pagination.Item>)
        }
        return pages
      })()}
      <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
      <Pagination.Item disabled={currentPage === totalPages} onClick={() => handlePageChange(totalPages)}>Last</Pagination.Item>
    </Pagination>
  </div>
)}
        </CardBody>
      </Card>

      <PayslipModal
        show={modalOpen}
        onHide={() => setModalOpen(false)}
        paysheet={activeSheet}
        details={activeDetails}
        employee={activeEmpObj}
        detailsLoading={detailsLoading}
        companyName={companyName}
        currencySymbol={currencySymbol}
      />

      <PaymentModal
        show={payModalOpen}
        onHide={() => setPayModalOpen(false)}
        paysheet={paySheet}
        details={payDetails}
        employee={payEmpObj}
        detailsLoading={payDetailsLoading}
        companyName={companyName}
        onPaySuccess={() => {}}
        refetchSheets={() => fetchSheets({ keyword: '', month: '', year: '', status: '' })}
        currencySymbol={currencySymbol}
      />

      <GenerateWizardModal
        show={genOpen}
        onHide={() => setGenOpen(false)}
        employees={employees}
        onSuccess={() => fetchSheets({ keyword: '', month: '', year: '', status: '' })}
        currencySymbol={currencySymbol}
      />
    </>
  )
}

export default PaysheetList
