import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Pay sheet Template - Employee Management',
}


const Paysheet = dynamic(() => import('./Paysheet'), { ssr: false })


export default function AddEarningDeductionpage() {
  return <Paysheet />
}