import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Attendance - Employee Management',
}


const Attendance = dynamic(() => import('./Attendance'), { ssr: false })

export default function AddDesignationPage() {
  return <Attendance />
}