'use client'

import React, { useState, useMemo, useEffect, useRef } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  Button, Col, Form, FormControl, FormLabel,
  Row, Modal, Card, CardHeader, CardBody,
  CardTitle, Table,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import {
  useGetAttendanceQuery,
  useCreateAttendanceMutation,
  useGetShiftsQuery,
  useGetFilteredAllEmpolyeesMutation,
  useGetAllLeavesQuery,
  useGetHolidaysQuery,
} from '@/store/features/emsSlice'

const EMPLOYEES_PER_PAGE = 10

// ─── CSV Import Helper ────────────────────────────────────────────────────────

const KNOWN_STATUSES = new Set([
  'PRESENT','LATE','ABSENT','LEAVE','NO_PAY',
  'FIRST_HALF','SECOND_HALF','HOLIDAY','SHORT_LEAVE','DAY_OFF',
])

function parseImportCSV(text, employees) {
  let lines = text.trim().split('\n').filter(Boolean)
  if (lines.length < 2) throw new Error('CSV must have a header row and at least one data row.')

  let headerLineIndex = 0
for (let i = 0; i < lines.length; i++) {
  const cleaned = lines[i].replace(/"/g, '')
  if (cleaned.startsWith('Employee,') || cleaned.includes(',Employee,') || cleaned.trim().startsWith('Employee')) {
    headerLineIndex = i
    break
  }
}

const headers = lines[headerLineIndex].split(',').map(h => h.trim().replace(/^"|"$/g, ''))

// Only process data lines after the header, skip legend rows at bottom
lines = lines.slice(headerLineIndex + 1).filter(line => {
  const first = line.split(',')[0].replace(/"/g, '').trim()
  return (
    first !== '' &&
    first !== 'LEGEND:' &&
    first !== 'John Doe' &&
    !first.startsWith('P =') &&
    !first.startsWith('NP =') &&
    !first.startsWith('PRESENT') &&
    !first.startsWith('FIRST_HALF') &&
    !first.startsWith('Use -')
  )
})
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/

  // Date columns are everything between "Role" and "Present Days" / summary cols
  const summaryLabels = new Set(['Present','Absent','Leave','Holidays','Present Days'])
  const dateColumns   = headers.slice(2).filter(h => !summaryLabels.has(h))
  const validDates    = dateColumns.filter(h => dateRegex.test(h))

  if (validDates.length === 0) throw new Error('No valid date columns found (expected YYYY-MM-DD).')

  // Build employee name → id lookup
const empLookup = {}
employees.forEach(e => {
  const full = `${e.first_name || ''} ${e.last_name || ''}`
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
  empLookup[full] = e.employee_id

  // also index by first+last separately trimmed (handles double-spaces in source data)
  const alt = `${e.first_name?.trim() || ''} ${e.last_name?.trim() || ''}`
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim()
  if (alt !== full) empLookup[alt] = e.employee_id
})

  const rows    = []
  const errors  = []
  const skipped = []

  for (let i = 0; i < lines.length; i++) {
    // Handle quoted commas properly
    const cols = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''))

    const empName = cols[0]?.trim()
    if (!empName || empName === '-' || empName === 'John Doe') continue

    // Try to match employee by name
    const empId = empLookup[empName.toLowerCase().replace(/\s+/g, ' ').trim()]
    if (!empId) {
      skipped.push(`"${empName}" — not found in system, skipped.`)
      continue
    }

    const records = []
    validDates.forEach((date, idx) => {
      const colIdx = headers.indexOf(date)
      if (colIdx === -1) return
      const raw    = cols[colIdx]?.trim() || '-'
      const status = raw.toUpperCase()
      if (status === '-' || status === '') return
      if (!KNOWN_STATUSES.has(status)) {
        errors.push(`Row ${i + 1} (${empName}), ${date}: unknown status "${raw}" — skipped.`)
        return
      }
      records.push({ date, status })
    })

    if (records.length > 0) {
      rows.push({ employeeId: empId, employeeName: empName, records })
    }
  }

  return { rows, errors, skipped, dateColumns: validDates }
}

// ─── Import Modal Body ────────────────────────────────────────────────────────

const ImportCSVBody = ({ onClose, employees }) => {
  const fileRef = React.useRef(null)

  const [step, setStep]           = useState('upload')
  const [dragOver, setDragOver]   = useState(false)
  const [fileName, setFileName]   = useState('')
  const [parseError, setParseError] = useState('')
  const [warnings, setWarnings]   = useState([])
  const [skipped, setSkipped]     = useState([])
  const [preview, setPreview]     = useState(null)
  const [progress, setProgress]   = useState(0)
  const [result, setResult]       = useState(null)
  const [isImporting, setIsImporting] = useState(false)

  const processFile = (file) => {
    if (!file) return
    if (!file.name.endsWith('.csv')) { setParseError('Only .csv files are supported.'); return }
    setFileName(file.name)
    setParseError('')
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const parsed = parseImportCSV(e.target.result, employees)
        if (parsed.rows.length === 0) {
          setParseError('No matching employees found. Make sure employee names in the CSV match exactly.')
          return
        }
        setWarnings(parsed.errors)
        setSkipped(parsed.skipped)
        setPreview(parsed)
        setStep('preview')
      } catch (err) {
        setParseError(err.message)
      }
    }
    reader.readAsText(file)
  }

  const handleDrop = (e) => {
    e.preventDefault(); setDragOver(false)
    processFile(e.dataTransfer.files[0])
  }

  const totalRecords = preview?.rows.reduce((sum, r) => sum + r.records.length, 0) || 0

  const handleImport = async () => {
    if (!preview) return
    setIsImporting(true)
    setStep('importing')
    setProgress(0)

    let inserted = 0, skippedCount = 0, failed = 0
    const total  = preview.rows.length

    for (let i = 0; i < preview.rows.length; i++) {
      const row = preview.rows[i]
      try {
        const res  = await fetch('/api/ems/attendance/import-csv-row', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({
            employee_id: row.employeeId,
            records:     row.records,
          }),
        })
        const data = await res.json()
        inserted     += data.inserted || 0
        skippedCount += data.skipped  || 0
        if (!res.ok) failed++
      } catch { failed++ }

      setProgress(Math.round(((i + 1) / total) * 100))
    }

    setResult({ inserted, skipped: skippedCount, failed })
    setIsImporting(false)
    setStep('done')
  }

  // ── Upload step ──
  if (step === 'upload') return (
    <div>
      <p className="text-muted small mb-3">
        Upload the exported attendance CSV. Employee names must match exactly.
        Duplicate records (same employee + same date) will be skipped automatically.
      </p>

      {parseError && <div className="alert alert-danger py-2 small">{parseError}</div>}

      <div
        onDragOver={e => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileRef.current?.click()}
        style={{
          border:        `2px dashed ${dragOver ? '#0d6efd' : '#dee2e6'}`,
          borderRadius:  8,
          padding:       '40px 20px',
          textAlign:     'center',
          cursor:        'pointer',
          backgroundColor: dragOver ? '#f0f4ff' : '#fafafa',
          transition:    'all 0.2s',
        }}
      >
        <Icon icon="mdi:file-upload-outline" width={40} className="text-muted mb-2" />
        <p className="mb-1 fw-semibold">Drag & drop your CSV here</p>
        <p className="text-muted small">or click to browse</p>
        <input
          ref={fileRef}
          type="file"
          accept=".csv"
          style={{ display: 'none' }}
          onChange={e => processFile(e.target.files[0])}
        />
      </div>
    </div>
  )

  // ── Preview step ──
  if (step === 'preview') return (
    <div>
      <div className="d-flex align-items-center gap-2 mb-3">
        <Icon icon="mdi:file-check" width={20} className="text-success" />
        <span className="fw-semibold">{fileName}</span>
        <Button size="sm" variant="outline-secondary" className="ms-auto"
          onClick={() => { setStep('upload'); setPreview(null); setFileName('') }}>
          Change File
        </Button>
      </div>

      {/* Summary cards */}
      <div className="d-flex gap-3 mb-3">
        {[
          { label: 'Employees matched', value: preview.rows.length,  color: '#28a745' },
          { label: 'Records to import', value: totalRecords,         color: '#0d6efd' },
          { label: 'Employees skipped', value: skipped.length,       color: '#fd7e14' },
        ].map(({ label, value, color }) => (
          <div key={label} className="flex-fill text-center p-3 rounded"
            style={{ backgroundColor: '#f8f9fa', border: '1px solid #dee2e6' }}>
            <div className="fw-bold fs-4" style={{ color }}>{value}</div>
            <div className="text-muted small">{label}</div>
          </div>
        ))}
      </div>

      {/* Skipped employees warning */}
      {skipped.length > 0 && (
        <div className="alert alert-warning py-2 small mb-3">
          <strong>These employees were not found in the system:</strong>
          <ul className="mb-0 mt-1">
            {skipped.slice(0, 5).map((s, i) => <li key={i}>{s}</li>)}
            {skipped.length > 5 && <li>…and {skipped.length - 5} more</li>}
          </ul>
        </div>
      )}

      {/* Row preview table */}
      <div style={{ maxHeight: 260, overflowY: 'auto', fontSize: 13 }}>
        <Table bordered size="sm">
          <thead className="table-light">
            <tr>
              <th>Employee</th>
              <th className="text-center">Records</th>
              <th>Dates</th>
            </tr>
          </thead>
          <tbody>
            {preview.rows.map((row, i) => (
              <tr key={i}>
                <td>{row.employeeName}</td>
                <td className="text-center">{row.records.length}</td>
                <td className="text-muted small">
                  {row.records.slice(0, 3).map(r => `${r.date} (${r.status})`).join(', ')}
                  {row.records.length > 3 && ` +${row.records.length - 3} more`}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>

      <div className="d-flex justify-content-end gap-2 mt-3">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button variant="primary" onClick={handleImport}>
          <Icon icon="mdi:import" className="me-1" width={18} />
          Import {totalRecords} Records
        </Button>
      </div>
    </div>
  )

  // ── Importing step ──
  if (step === 'importing') return (
    <div className="text-center py-4">
      <Icon icon="mdi:loading" width={40} className="text-primary mb-3"
        style={{ animation: 'spin 1s linear infinite' }} />
      <p className="fw-semibold mb-2">Importing attendance records…</p>
      <div className="progress mb-2" style={{ height: 10 }}>
        <div className="progress-bar progress-bar-striped progress-bar-animated"
          style={{ width: `${progress}%` }} />
      </div>
      <p className="text-muted small">{progress}% complete</p>
      <style>{`@keyframes spin { from { transform: rotate(0deg) } to { transform: rotate(360deg) } }`}</style>
    </div>
  )

  // ── Done step ──
  if (step === 'done') return (
    <div className="text-center py-3">
      <Icon icon={result?.failed > 0 ? 'mdi:alert-circle' : 'mdi:check-circle'}
        width={52}
        style={{ color: result?.failed > 0 ? '#fd7e14' : '#28a745' }}
        className="mb-3" />
      <h5 className="fw-bold mb-3">Import Complete</h5>
      <div className="d-flex justify-content-center gap-4 mb-4">
        {[
          { label: 'Inserted',       value: result?.inserted,  color: '#28a745' },
          { label: 'Skipped (dup)',  value: result?.skipped,   color: '#6c757d' },
          { label: 'Failed',         value: result?.failed,    color: '#dc3545' },
        ].map(({ label, value, color }) => (
          <div key={label} className="text-center">
            <div className="fw-bold fs-3" style={{ color }}>{value ?? 0}</div>
            <div className="text-muted small">{label}</div>
          </div>
        ))}
      </div>
      <Button variant="primary" onClick={onClose}>Close & Refresh</Button>
    </div>
  )

  return null
}

const Attendance = () => {
  const [showSuccess, setShowSuccess]               = useState(false)
  const [showManualModal, setShowManualModal]         = useState(false)
  const [showDetailModal, setShowDetailModal]         = useState(false)
  const [selectedAttendance, setSelectedAttendance]   = useState(null)
  const [selectedShift, setSelectedShift]             = useState('')
  const [modalCheckInDate, setModalCheckInDate]   = useState(new Date().toISOString().split('T')[0])
  const [modalCheckOutDate, setModalCheckOutDate] = useState(new Date().toISOString().split('T')[0])
  const [year, setYear]     = useState(new Date().getFullYear())
  const [month, setMonth]   = useState(new Date().getMonth() + 1)
  const [page, setPage]     = useState(1)

 
  const [employeeSearch, setEmployeeSearch]     = useState('')
  const [showSuggestions, setShowSuggestions]   = useState(false)
  const searchRef                               = useRef(null)

  const [employees, setEmployees]                     = useState([])
  const [isLoadingEmployees, setIsLoadingEmployees]   = useState(true)
  const [showImportModal, setShowImportModal] = useState(false)

  const { data: shifts = [], isLoading: isLoadingShifts }       = useGetShiftsQuery()
  const { data: attendanceData = [], isLoading: isLoadingAttendance } = useGetAttendanceQuery()
  const [createManualAttendance, { isLoading: isCreating }]     = useCreateAttendanceMutation()
  const [fetchFilteredEmployees]                                 = useGetFilteredAllEmpolyeesMutation()
  const { data: holidaysData = [] } = useGetHolidaysQuery()
  
  const { data: allLeaves = [] } = useGetAllLeavesQuery()

  useEffect(() => {
    const load = async () => {
      try {
        setIsLoadingEmployees(true)
        const res = await fetchFilteredEmployees({
          page: 1,
          limit: 1000,
          keyword: '',
          status: '',
          date: '',
          todate: '',
        }).unwrap()
        setEmployees(res.employees || [])
      } catch (err) {
       
      } finally {
        setIsLoadingEmployees(false)
      }
    }
    load()
  }, [])

  
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowSuggestions(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm({
    resolver: yupResolver(
      yup.object().shape({
        employeeId:   yup.string().required(),
        name:         yup.string().required(),
        checkInDate:   yup.string().required(),
        checkOutDate:  yup.string().required(),
        checkInTime:  yup.string().required(),
        checkOutTime: yup.string().required(),
      })
    ),
  })

  
  const employeeSuggestions = useMemo(() => {
    if (employeeSearch.length < 2) return []
    const lower = employeeSearch.toLowerCase()
    return employees.filter((emp) => {
      const fullName = `${emp.first_name || ''} ${emp.last_name || ''}`.toLowerCase()
      return fullName.includes(lower) || String(emp.employee_id).includes(lower)
    }).slice(0, 10)
  }, [employeeSearch, employees])

  const handleSelectEmployee = (emp) => {
    const fullName = `${emp.first_name || ''} ${emp.last_name || ''}`.trim()
    setEmployeeSearch(fullName)
    setValue('employeeId', String(emp.employee_id))
    setValue('name', fullName)
    setShowSuggestions(false)
  }

  const handleOpenManualModal = () => {
  const today = new Date().toISOString().split('T')[0]
  setModalCheckInDate(today)
  setModalCheckOutDate(today)
  setShowSuggestions(false)
  reset()
  setValue('checkInDate', today)   // ← ADD
  setValue('checkOutDate', today)  // ← ADD
  setShowManualModal(true)
}

  const attendanceLookup = useMemo(() => {
  const map = {}
  attendanceData.forEach((att) => {
    const key = String(att.employee_id)
    if (!map[key]) map[key] = {}
    const dateKey = new Date(att.check_in_date).toISOString().split('T')[0]
    


    // ✅ Keep ALL fields — status is already resolved by transformResponse
    map[key][dateKey] = {
      status:               att.status,
      clock_in_time:        att.clock_in_time,
      clock_out_time:       att.clock_out_time,
      log_source:           att.log_source,
      attendance_note:      att.attendance_note,
      // leave fields
      leave_type_name:      att.leave_type_name      || null,
      leave_duration_type:  att.leave_duration_type  || null,
      paid_status:          att.paid_status           || null,
      reason:               att.reason               || null,
      // half-day flag
      halfday:              att.halfday               || false,
      // holiday fields
      holiday_name:         att.holiday_name          || null,
      holiday_type:         att.holiday_type          || null,
      occasion:             att.occasion              || null,
      // late fields  ← added `late` boolean from attendance_status
      late:                 att.late                  || false,
      shift_in_time:        att.shift_in_time         || null,
      grace_period_minutes: att.grace_period_minutes  || 0,
    }
  })
  return map
}, [attendanceData])

  const filteredLookup = useMemo(() => {
    const result = {}
    Object.entries(attendanceLookup).forEach(([empId, dates]) => {
      result[empId] = {}
      Object.entries(dates).forEach(([dateKey, entry]) => {
        const d = new Date(dateKey)
        if (d.getFullYear() === Number(year) && d.getMonth() + 1 === Number(month)) {
          result[empId][dateKey] = entry
        }
      })
    })
    return result
  }, [attendanceLookup, year, month])

  const leaveLookup = useMemo(() => {
  const map = {}
  allLeaves.forEach((leave) => {
    if (leave.status !== 'Approved') return

    const empId = String(leave.employee_id)
    if (!map[empId]) map[empId] = {}

    const start = new Date(leave.from_date)
    const end   = new Date(leave.to_date || leave.from_date)
    const cur   = new Date(start)

    while (cur <= end) {
      const key = cur.toISOString().split('T')[0]

      // ✅ Check BOTH field names — backend uses duration_type, some responses use duration
      const durationType = leave.duration_type || leave.duration || ''

      const leaveStatus =
        durationType === 'first_half'  || durationType === 'First Half'  ? 'FIRST_HALF'  :
        durationType === 'second_half' || durationType === 'Second Half' ? 'SECOND_HALF' :
        leave.paid_status === 'unpaid'                                   ? 'NO_PAY'      :
        'LEAVE'

      map[empId][key] = {
        status:          leaveStatus,
        leave_type_name: leave.leave_type_name || 'Leave',
        duration_type:   durationType,
        paid_status:     leave.paid_status || 'paid',
        reason:          leave.reason || null,
        halfday:         ['first_half','second_half','First Half','Second Half'].includes(durationType),
      }

      cur.setDate(cur.getDate() + 1)
    }
  })
  return map
}, [allLeaves])

  const holidayLookup = useMemo(() => {
  const map = {}
  holidaysData.forEach((holiday) => {
    const dateKey = holiday.holiday_date?.split('T')[0]
    if (dateKey) {
      map[dateKey] = {
        status:       'HOLIDAY',
        holiday_name: holiday.holiday_name,
        holiday_type: holiday.holiday_type,
        occasion:     holiday.occasion,
      }
    }
  })
  return map
}, [holidaysData])

 const attendanceMatrix = useMemo(() => {
  return employees.map((emp) => {
    const empId      = String(emp.employee_id)
    const attendance = filteredLookup[empId] || {}
    const leaves     = leaveLookup[empId]    || {}
    const merged     = {}

    const allKeys = new Set([
      ...Object.keys(attendance),
      ...Object.keys(leaves),
      ...Object.keys(holidayLookup),
    ])

    allKeys.forEach((dateKey) => {
      const d = new Date(dateKey)
      if (d.getFullYear() !== Number(year) || d.getMonth() + 1 !== Number(month)) return

      const attEntry     = attendance[dateKey]
      const leaveEntry   = leaves[dateKey]
      const holidayEntry = holidayLookup[dateKey]

      if (attEntry) {
        // ✅ Status already resolved correctly by transformResponse
        // But if backend missed the half-day split, cross-check with leaveLookup
        let resolvedEntry = { ...attEntry }

        // If attendance says PRESENT/LATE but leaveLookup says FIRST_HALF/SECOND_HALF
        // → trust the leave (half-day means partial presence)
        if (
          leaveEntry &&
          ['FIRST_HALF', 'SECOND_HALF'].includes(leaveEntry.status) &&
          ['PRESENT', 'LATE'].includes(attEntry.status)
        ) {
          resolvedEntry = {
            ...attEntry,
            ...leaveEntry,
            // keep clock times from attendance
            clock_in_time:  attEntry.clock_in_time,
            clock_out_time: attEntry.clock_out_time,
            log_source:     attEntry.log_source,
          }
        }

        // Holiday always wins over everything
        if (holidayEntry && attEntry.status !== 'HOLIDAY') {
          resolvedEntry = {
            ...attEntry,
            ...holidayEntry,
          }
        }

        merged[dateKey] = resolvedEntry

      } else if (leaveEntry) {
        merged[dateKey] = leaveEntry
      } else if (holidayEntry) {
        merged[dateKey] = holidayEntry
      }
    })

   const toTitleCase = (str) =>
    str.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())

  return {
    employeeId: emp.employee_id,
    name:       toTitleCase(`${emp.first_name || ''} ${emp.last_name || ''}`.trim()),
    role:       emp.designation_name || '-',
    attendance: merged,
  }
  })
}, [employees, filteredLookup, leaveLookup, holidayLookup, year, month])

  const totalPages    = Math.ceil(attendanceMatrix.length / EMPLOYEES_PER_PAGE)
  const paginatedRows = attendanceMatrix.slice((page - 1) * EMPLOYEES_PER_PAGE, page * EMPLOYEES_PER_PAGE)

  const handleYearChange  = (e) => { setYear(e.target.value);  setPage(1) }
  const handleMonthChange = (e) => { setMonth(e.target.value); setPage(1) }

  function getPageWindow(current, total, width = 5) {
    const w    = Math.max(1, width)
    const half = Math.floor(w / 2)
    let start  = Math.max(1, current - half)
    let end    = Math.min(total, start + w - 1)
    start      = Math.max(1, end - w + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const getDaysInMonth = (year, month) => {
    const date = new Date(year, month - 1, 1)
    const days = []
    while (date.getMonth() === month - 1) {
      days.push(new Date(date))
      date.setDate(date.getDate() + 1)
    }
    return days
  }
  const days = getDaysInMonth(year, month)

  const statusIcons = {
  PRESENT:     { icon: 'mdi:check-circle',         class: 'text-success'              },
  LATE:        { icon: 'mdi:clock-alert-outline',  class: '', color: '#fd7e14'        },
  ABSENT:      { icon: 'mdi:close-circle',         class: 'text-danger'               },
  LEAVE:       { icon: 'mdi:airplane',             class: 'text-primary'              },
  NO_PAY:      { icon: 'mdi:currency-usd-off',     class: 'text-danger'               },
  FIRST_HALF:  { icon: 'mdi:circle-half-full',     class: 'text-warning'              },
  SECOND_HALF: { icon: 'mdi:circle-half-full',     class: '', color: '#fd7e14'        },
  SHORT_LEAVE: { icon: 'mdi:clock-minus',          class: 'text-info'                 },
  DAY_OFF:     { icon: 'mdi:weather-sunny-off',    class: '', color: '#6f42c1'        },
  HOLIDAY:     { icon: 'mdi:star-circle',          class: '', color: '#e83e8c'        },
}

  const onSubmit = async (data) => {
    try {
      await createManualAttendance({
        employee_id:     data.employeeId,
        name:            data.name,
        check_in_date:  data.checkInDate,
        check_out_date: data.checkOutDate,   
        clock_in_time:   data.checkInTime,
        clock_out_time:  data.checkOutTime,
        log_source:      'HR_DASHBOARD',
        shift_id:        selectedShift,
        status:          'PRESENT',
      }).unwrap()
      setShowManualModal(false)
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 3000)
      reset()
      setEmployeeSearch('')
    } catch (error) {
   
    }
  }

     // Add this map near your exportToCSV function
const statusLabels = {
  PRESENT: 'P', LATE: 'L', ABSENT: 'A',
  LEAVE: 'Leave', NO_PAY: 'NP', FIRST_HALF: 'FH',
  SECOND_HALF: 'SH', HOLIDAY: 'Holiday', DAY_OFF: 'Off'
}
const downloadImportTemplate = () => {
  const today = new Date()
  const year  = today.getFullYear()
  const month = today.getMonth() + 1

  // Generate all days of current month as columns
  const templateDays = getDaysInMonth(year, month)
    .map(d => d.toISOString().split('T')[0])

  const header = ['Employee', 'Role', ...templateDays]
  const exampleRow = ['John Doe', 'Manager', ...templateDays.map(() => '')]

  const statusGuide = [
    [],
    ['LEGEND:'],
    ['PRESENT', 'LATE', 'ABSENT', 'LEAVE', 'NO_PAY'],
    ['FIRST_HALF', 'SECOND_HALF', 'SHORT_LEAVE', 'HOLIDAY', 'DAY_OFF'],
    [],
    ['Use - or leave blank for no entry'],
  ]

  const allRows  = [header, exampleRow, ...statusGuide]
  const csv      = allRows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
  const blob     = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url      = URL.createObjectURL(blob)
  const link     = document.createElement('a')
  link.setAttribute('href', url)
  link.setAttribute('download', `attendance_import_template_${year}-${String(month).padStart(2, '0')}.csv`)
  link.click()
}

  const exportToCSV = () => {
  if (!attendanceMatrix.length) return

  // ── Header row ──
  const header = [
  'Employee', 'Role',
  ...days.map(d => d.toISOString().split('T')[0]),  // keeps YYYY-MM-DD
  'Present', 'Absent', 'Leave', 'Holidays'
]

  // ── Status label map ──
  const label = {
    PRESENT: 'P', LATE: 'L✦', ABSENT: 'A',
    LEAVE: 'Lv', NO_PAY: 'NP', FIRST_HALF: 'FH',
    SECOND_HALF: 'SH', HOLIDAY: 'Hol', DAY_OFF: 'Off', SHORT_LEAVE: 'SL'
  }

  // ── Data rows ──
  const dataRows = attendanceMatrix.map((emp) => {
    const counts = { present: 0, absent: 0, leave: 0, holiday: 0 }
    const cells = days.map(d => {
      const status = emp.attendance[d.toISOString().split('T')[0]]?.status
      if (!status) return '-'
      if (['PRESENT','LATE'].includes(status))             counts.present++
      else if (status === 'ABSENT')                        counts.absent++
      else if (['LEAVE','NO_PAY','FIRST_HALF','SECOND_HALF','SHORT_LEAVE'].includes(status)) counts.leave++
      else if (status === 'HOLIDAY')                       counts.holiday++
      return label[status] || status
    })
    return [emp.name, emp.role, ...cells,
      counts.present, counts.absent, counts.leave, counts.holiday]
  })

  // ── Legend block at bottom ──
  const legend = [
    [], // blank row
    ['LEGEND:'],
    ['P = Present', 'L✦ = Late', 'A = Absent', 'Lv = Leave'],
    ['NP = No Pay', 'FH = First Half', 'SH = Second Half', 'Hol = Holiday'],
  ]

  // ── Month title row ──
  const title = [
    [`Attendance Report — ${new Date(year, month - 1).toLocaleString('default', { month: 'long' })} ${year}`]
  ]

  const allRows  = [...title, [], header, ...dataRows, ...legend]
  const csv      = allRows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
  const blob     = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url      = URL.createObjectURL(blob)
  const link     = document.createElement('a')
  link.setAttribute('href', url)
  link.setAttribute('download', `attendance_${year}-${String(month).padStart(2, '0')}.csv`)
  link.click()
}

  const isLoading = isLoadingEmployees || isLoadingAttendance

  return (
    <Card>
      <CardHeader className="bg-light py-3">
        <Row className="align-items-center">
          <Col>
            <CardTitle as="h4" style={{ fontSize: '18px' }}>Employee Attendance</CardTitle>
            <CardTitle as="h6" className="text-muted">
              Today: {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </CardTitle>
          </Col>

          <Col xs="auto" className="d-flex align-items-center gap-2">
            <Form.Select style={{ width: '110px' }} value={year} onChange={handleYearChange}>
              {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
            </Form.Select>

            <Form.Select style={{ width: '130px' }} value={month} onChange={handleMonthChange}>
              {Array.from({ length: 12 }).map((_, i) => (
                <option key={i} value={i + 1}>
                  {new Date(0, i).toLocaleString('default', { month: 'long' })}
                </option>
              ))}
            </Form.Select>

            <Button variant="success" className="d-flex align-items-center text-nowrap" onClick={handleOpenManualModal}>
              <Icon icon="mdi:plus-circle-outline" className="me-1" width={20} /> Manual Entry
            </Button>

            <Button variant="info" className="d-flex align-items-center text-nowrap text-white" onClick={exportToCSV}>
              <Icon icon="mdi:download" className="me-1" width={20} /> Export CSV
            </Button>

            <Button
            variant="outline-secondary"
            className="d-flex align-items-center text-nowrap"
            onClick={downloadImportTemplate}
            title="Download blank CSV template for import"
          >
            <Icon icon="mdi:file-download-outline" className="me-1" width={20} />
            Import Template
          </Button>

            <Button variant="secondary" className="d-flex align-items-center text-nowrap"
              onClick={() => setShowImportModal(true)}>
              <Icon icon="mdi:file-import" className="me-1" width={20} /> Import CSV
            </Button>
          </Col>
        </Row>
      </CardHeader>

      <CardBody>
        {showSuccess && (
          <div className="alert alert-success">Manual attendance entry added successfully ✅</div>
        )}

        <Row className="mb-2">
          <Col className="d-flex gap-3 flex-wrap">
            {Object.entries(statusIcons).map(([key, val]) => (
            <div key={key} className="d-flex align-items-center gap-1">
              <Icon icon={val.icon} className={val.class} style={{ color: val.color }} width={18} />
              <span style={{ fontSize: 10 }}>{key.replace('_', ' ')}</span>
            </div>
          ))}
          </Col>
        </Row>

        <Row className="mb-2">
          <Col>
            <span className="text-muted small">
              Showing{' '}
              {attendanceMatrix.length === 0 ? 0 : (page - 1) * EMPLOYEES_PER_PAGE + 1}–
              {Math.min(page * EMPLOYEES_PER_PAGE, attendanceMatrix.length)}{' '}
              of {attendanceMatrix.length} employees
            </span>
          </Col>
        </Row>

        {isLoading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" />
            <p className="mt-2 text-muted">Loading attendance...</p>
          </div>
        ) : (
          <>
            <div className="table-responsive">
              <Table bordered hover size="sm">
                <thead className="table-light">
                  <tr>
                    <th style={{ minWidth: 180 }}>Employee</th>
                    {days.map(d => {
                      const key       = d.toISOString().split('T')[0]
                      const isHoliday = !!holidayLookup[key]
                      return (
                        <th
                          key={d.toISOString()}
                          className="text-center"
                          style={{
                            minWidth: 36,
                            backgroundColor: isHoliday ? '#fce4ec' : undefined,
                          }}
                          title={isHoliday ? holidayLookup[key]?.holiday_name : undefined}
                        >
                          {d.getDate()}
                          <div style={{ fontSize: 10 }}>
                            {d.toLocaleDateString('en-US', { weekday: 'short' })}
                          </div>
                        </th>
                      )
                    })}
                    <th className="text-center">Total</th>
                  </tr>
                </thead>

                <tbody>
                  {paginatedRows.length === 0 ? (
                    <tr>
                      <td colSpan={days.length + 2} className="text-center text-muted py-4">
                        No employees found.
                      </td>
                    </tr>
                  ) : (
                    paginatedRows.map((emp) => {
                      const presentCount = Object.values(emp.attendance)
                        .filter(e => e?.status === 'PRESENT').length

                      return (
                        <tr key={emp.employeeId}>
                          <td>
                            <strong>{emp.name}</strong>
                            <div className="text-muted small">{emp.role}</div>
                          </td>

                          {days.map(d => {
                          const key       = d.toISOString().split('T')[0]
                          const entry     = emp.attendance[key]
                          const status    = entry?.status
                          const isHoliday = !!holidayLookup[key]

                          return (
                            <td
                              key={key}
                              className="text-center"
                              style={{
                                cursor: status ? 'pointer' : 'default',
                                backgroundColor: isHoliday ? '#fce4ec' : 'transparent',
                              }}
                              title={isHoliday && !status ? holidayLookup[key]?.holiday_name : undefined}
                            >
                              {status ? (
                                <Icon
                                  icon={statusIcons[status]?.icon}
                                  className={statusIcons[status]?.class}
                                  style={{ color: statusIcons[status]?.color }}
                                  width={18}
                                  onClick={() => {
                                    setSelectedAttendance({ employee: emp.name, date: key, ...entry })
                                    setShowDetailModal(true)
                                  }}
                                />
                              ) : (
                                <span className="text-muted" style={{ fontSize: 12 }}>—</span>
                              )}
                            </td>
                          )
                        })}

                          <td className="fw-semibold text-center">
                            {presentCount} / {days.length}
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </Table>
            </div>

            {totalPages > 1 && (
              <nav aria-label="Attendance pagination" className="mt-3">
                <ul className="pagination justify-content-end mb-0">
                  <li className={`page-item ${page === 1 ? 'disabled' : ''}`}>
                    <button className="page-link"
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}>
                      Previous
                    </button>
                  </li>

                  {getPageWindow(page, totalPages, 5).map((p) => (
                    <li key={p} className={`page-item ${p === page ? 'active' : ''}`}>
                      <button className="page-link" onClick={() => setPage(p)}>{p}</button>
                    </li>
                  ))}

                  <li className={`page-item ${page === totalPages ? 'disabled' : ''}`}>
                    <button className="page-link"
                      onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                      disabled={page === totalPages}>
                      Next
                    </button>
                  </li>
                </ul>
              </nav>
            )}
          </>
        )}
      </CardBody>

     
      <Modal show={showManualModal} onHide={() => setShowManualModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add Manual Entry</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Body>

            
            <FormLabel>Search Employee</FormLabel>
            <div ref={searchRef} style={{ position: 'relative' }}>
              <FormControl
                placeholder="Type at least 2 characters to search…"
                value={employeeSearch}
                onChange={(e) => {
                  setEmployeeSearch(e.target.value)
                  setShowSuggestions(e.target.value.length >= 2)
                }}
                onFocus={() => {
                  if (employeeSearch.length >= 2) setShowSuggestions(true)
                }}
                autoComplete="off"
              />

              {showSuggestions && (
                <ul
                  style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    zIndex: 1050,
                    backgroundColor: '#fff',
                    border: '1px solid #dee2e6',
                    borderRadius: '0 0 6px 6px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                    maxHeight: 220,
                    overflowY: 'auto',
                    margin: 0,
                    padding: 0,
                    listStyle: 'none',
                  }}
                >
                  {employeeSuggestions.length === 0 ? (
                    <li style={{ padding: '10px 14px', color: '#6c757d', fontSize: 13 }}>
                      No employees found
                    </li>
                  ) : (
                    employeeSuggestions.map((emp) => {
                      const fullName = `${emp.first_name || ''} ${emp.last_name || ''}`.trim()
                      return (
                        <li
                          key={emp.employee_id}
                          onMouseDown={() => handleSelectEmployee(emp)}
                          style={{
                            padding: '8px 14px',
                            cursor: 'pointer',
                            borderBottom: '1px solid #f0f0f0',
                            fontSize: 13,
                          }}
                          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f0f4ff'}
                          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#fff'}
                        >
                          <strong>{fullName}</strong>
                          <span className="text-muted ms-2" style={{ fontSize: 11 }}>
                            #{emp.employee_id} · {emp.designation_name || emp.job_specification || 'No role'}
                          </span>
                        </li>
                      )
                    })
                  )}
                </ul>
              )}
            </div>

           
            <FormControl type="hidden" {...register('employeeId')} />
            <FormControl type="hidden" {...register('name')} />

            
            {(errors.employeeId || errors.name) && (
              <div className="text-danger mt-1" style={{ fontSize: 12 }}>
                Please select an employee from the list.
              </div>
            )}

            <FormLabel className="mt-3">Shift</FormLabel>
            <Form.Select value={selectedShift} onChange={e => setSelectedShift(e.target.value)} disabled={isLoadingShifts}>
              <option value="">Select a shift</option>
              {shifts.map(s => (
                <option key={s.id || s._id} value={s.id || s._id}>
                  {s.shift_name || s.name}
                </option>
              ))}
            </Form.Select>

            <FormLabel className="mt-3">Check In Date</FormLabel>
            <FormControl
            type="date"
            {...register('checkInDate')}
            value={modalCheckInDate}
            onChange={e => {
              setModalCheckInDate(e.target.value)
              setValue('checkInDate', e.target.value)   // ← ADD THIS LINE
              if (e.target.value > modalCheckOutDate) {
                setModalCheckOutDate(e.target.value)
                setValue('checkOutDate', e.target.value)
              }
            }}
          />

            <FormLabel className="mt-2">Check Out Date</FormLabel>
            <FormControl
            type="date"
            {...register('checkOutDate')}
            value={modalCheckOutDate}
            min={modalCheckInDate}
            onChange={e => {
              setModalCheckOutDate(e.target.value)
              setValue('checkOutDate', e.target.value)  // ← ADD THIS LINE
            }}
          />

            <FormLabel className="mt-2">Check In Time</FormLabel>
            <FormControl type="time" {...register('checkInTime')} isInvalid={!!errors.checkInTime} />

            <FormLabel className="mt-2">Check Out Time</FormLabel>
            <FormControl type="time" {...register('checkOutTime')} isInvalid={!!errors.checkOutTime} />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowManualModal(false)}>Cancel</Button>
            <Button type="submit" disabled={isCreating}>
              {isCreating ? 'Saving…' : 'Save'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>

      
      <Modal show={showDetailModal} onHide={() => setShowDetailModal(false)} centered>
  <Modal.Header closeButton>
    <Modal.Title>Attendance Details</Modal.Title>
  </Modal.Header>
  <Modal.Body className="p-0">
    {selectedAttendance && (() => {
      const status   = selectedAttendance.status
      const iconMeta = statusIcons[status] || { icon: 'mdi:help-circle', class: 'text-muted' }

      const headerColors = {
        PRESENT:     '#28a745',
        LATE:        '#fd7e14',
        ABSENT:      '#dc3545',
        LEAVE:       '#007bff',
        NO_PAY:      '#dc3545',
        FIRST_HALF:  '#ffc107',
        SECOND_HALF: '#fd7e14',
        SHORT_LEAVE: '#17a2b8',
        DAY_OFF:     '#6f42c1',
        HOLIDAY:     '#e83e8c',
      }

      const fmt = (t) => {
        if (!t) return '-'
        return t.length <= 8
          ? t
          : new Date(`1970-01-01T${t}`).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }

      const toMins = (t) => {
        if (!t) return 0
        const [h, m] = String(t).split(':').map(Number)
        return h * 60 + m
      }

      const lateMinutes = status === 'LATE' && selectedAttendance.clock_in_time && selectedAttendance.shift_in_time
        ? toMins(selectedAttendance.clock_in_time)
          - toMins(selectedAttendance.shift_in_time)
          - (parseInt(selectedAttendance.grace_period_minutes) || 0)
        : 0

      const statusLabels = {
        PRESENT:     'Present',
        LATE:        'Late Arrival',
        ABSENT:      'Absent',
        LEAVE:       'On Leave',
        NO_PAY:      'No Pay Leave',
        FIRST_HALF:  'First Half Leave',
        SECOND_HALF: 'Second Half Leave',
        SHORT_LEAVE: 'Short Leave',
        DAY_OFF:     'Day Off',
        HOLIDAY:     'Public Holiday',
      }

      return (
        <Card className="w-100 overflow-hidden border-0 rounded-0" style={{ backgroundColor: '#f8f9fa' }}>
          <div
            className="text-white text-center py-4 position-relative"
            style={{ backgroundColor: headerColors[status] ?? '#5f83e7' }}
          >
            <span style={{
              backgroundColor: '#020c07cc', color: 'white', padding: '4px 10px',
              borderRadius: '12px', fontSize: '0.6rem', position: 'absolute', top: 10, left: 10,
            }}>
              {selectedAttendance.date}
            </span>
            <span style={{
              backgroundColor: '#020c07cc', color: 'white', padding: '4px 10px',
              borderRadius: '12px', fontSize: '0.6rem', position: 'absolute', top: 10, right: 10,
            }}>
              {statusLabels[status] ?? status}
            </span>

            <div
              className="mx-auto mb-2 d-flex align-items-center justify-content-center rounded-circle bg-white"
              style={{ width: 90, height: 90 }}
            >
              <Icon
                icon={iconMeta.icon}
                className={iconMeta.class}
                style={{ color: iconMeta.color }}
                width={52}
              />
            </div>
            <h5 className="mb-0 fw-bold">{selectedAttendance.employee}</h5>
          </div>

          <Card.Body className="px-4 py-3">
            <div className="d-flex flex-column gap-2">

              {/* ── Clock In ── */}
              <div className="d-flex align-items-center gap-2">
                <Icon icon="mdi:clock-in" width={18} className="text-success flex-shrink-0" />
                <span className="text-muted small">Clock In</span>
                <span className="fw-semibold small ms-auto">{fmt(selectedAttendance.clock_in_time)}</span>
              </div>

              {/* ── Late badge ── */}
              {status === 'LATE' && lateMinutes > 0 && (
                <>
                  <hr className="my-1" />
                  <div className="d-flex align-items-center gap-2">
                    <Icon icon="mdi:clock-alert-outline" width={18} style={{ color: '#fd7e14' }} className="flex-shrink-0" />
                    <span className="text-muted small">Late By</span>
                    <span className="fw-semibold small ms-auto" style={{ color: '#fd7e14' }}>
                      {lateMinutes} min{lateMinutes !== 1 ? 's' : ''}
                    </span>
                  </div>
                </>
              )}

              <hr className="my-1" />

              {/* ── Clock Out ── */}
              <div className="d-flex align-items-center gap-2">
                <Icon icon="mdi:clock-out" width={18} className="text-danger flex-shrink-0" />
                <span className="text-muted small">Clock Out</span>
                <span className="fw-semibold small ms-auto">{fmt(selectedAttendance.clock_out_time)}</span>
              </div>

              <hr className="my-1" />

              {/* ── Log Source ── */}
              <div className="d-flex align-items-center gap-2">
                <Icon icon="mdi:source-branch" width={18} className="text-muted flex-shrink-0" />
                <span className="text-muted small">Log Source</span>
                <span className="fw-semibold small ms-auto">{selectedAttendance.log_source || '-'}</span>
              </div>
{/* ── Leave Info ── */}
{['LEAVE', 'NO_PAY', 'FIRST_HALF', 'SECOND_HALF', 'SHORT_LEAVE'].includes(status) && (
  <>
    <hr className="my-1" />
    <div className="d-flex align-items-center gap-2">
      <Icon icon="mdi:airplane" width={18} className="text-primary flex-shrink-0" />
      <span className="text-muted small">Leave Type</span>
      <span className="fw-semibold small ms-auto">
        {selectedAttendance.leave_type_name || '-'}
      </span>
    </div>

    {/* ✅ NEW — show which half */}
    {['FIRST_HALF', 'SECOND_HALF'].includes(status) && (
      <>
        <hr className="my-1" />
        <div className="d-flex align-items-center gap-2">
          <Icon icon="mdi:circle-half-full" width={18} className="text-warning flex-shrink-0" />
          <span className="text-muted small">Half Day</span>
          <span className="fw-semibold small ms-auto">
            {status === 'FIRST_HALF' ? 'First Half (Morning)' : 'Second Half (Afternoon)'}
          </span>
        </div>
      </>
    )}

    <hr className="my-1" />
    <div className="d-flex align-items-center gap-2">
      <Icon icon="mdi:cash" width={18} className="text-muted flex-shrink-0" />
      <span className="text-muted small">Pay Status</span>
      <span
        className="fw-semibold small ms-auto"
        style={{ color: status === 'NO_PAY' || selectedAttendance.paid_status === 'unpaid' ? '#dc3545' : '#28a745' }}
      >
        {status === 'NO_PAY' || selectedAttendance.paid_status === 'unpaid' ? 'Unpaid' : 'Paid'}
      </span>
    </div>

    {selectedAttendance.reason && (
      <>
        <hr className="my-1" />
        <div className="d-flex align-items-center gap-2">
          <Icon icon="mdi:text" width={18} className="text-muted flex-shrink-0" />
          <span className="text-muted small">Reason</span>
          <span className="fw-semibold small ms-auto" style={{ maxWidth: 160, textAlign: 'right' }}>
            {selectedAttendance.reason}
          </span>
        </div>
      </>
    )}
  </>
)}
              {/* ── Holiday Info ── */}
              {status === 'HOLIDAY' && selectedAttendance.holiday_name && (
                <>
                  <hr className="my-1" />
                  <div className="d-flex align-items-center gap-2">
                    <Icon icon="mdi:star-circle" width={18} style={{ color: '#e83e8c' }} className="flex-shrink-0" />
                    <span className="text-muted small">Holiday</span>
                    <span className="fw-semibold small ms-auto">{selectedAttendance.holiday_name}</span>
                  </div>
                  {selectedAttendance.holiday_type && (
                    <>
                      <hr className="my-1" />
                      <div className="d-flex align-items-center gap-2">
                        <Icon icon="mdi:tag-outline" width={18} className="text-muted flex-shrink-0" />
                        <span className="text-muted small">Type</span>
                        <span className="fw-semibold small ms-auto">{selectedAttendance.holiday_type}</span>
                      </div>
                    </>
                  )}
                  {selectedAttendance.occasion && (
                    <>
                      <hr className="my-1" />
                      <div className="d-flex align-items-center gap-2">
                        <Icon icon="mdi:text" width={18} className="text-muted flex-shrink-0" />
                        <span className="text-muted small">Occasion</span>
                        <span className="fw-semibold small ms-auto">{selectedAttendance.occasion}</span>
                      </div>
                    </>
                  )}
                </>
              )}

              {/* ── Absent reason ── */}
              {status === 'ABSENT' && (
                <>
                  <hr className="my-1" />
                  <div className="d-flex align-items-center gap-2">
                    <Icon icon="mdi:close-circle" width={18} className="text-danger flex-shrink-0" />
                    <span className="text-muted small">Note</span>
                    <span className="fw-semibold small ms-auto">
                      {selectedAttendance.attendance_note || 'No note recorded'}
                    </span>
                  </div>
                </>
              )}

            </div>
          </Card.Body>
        </Card>
      )
    })()}
  </Modal.Body>
  <Modal.Footer>
    <Button variant="secondary" onClick={() => setShowDetailModal(false)}>Close</Button>
  </Modal.Footer>
</Modal>

 <Modal show={showImportModal} onHide={() => setShowImportModal(false)} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <Icon icon="mdi:file-import" className="me-2" width={22} />
            Import Attendance CSV
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ImportCSVBody
            onClose={() => setShowImportModal(false)}
            employees={employees}
          />
        </Modal.Body>
      </Modal>
    </Card>
  )
}

export default Attendance
