'use client'

import React, { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  Button, Col, Form, FormControl, FormLabel, FormSelect, Row,
  Modal, Card, CardHeader, CardBody, CardTitle, Table, Alert,Spinner 
} from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { Icon } from '@iconify/react/dist/iconify.js'
import {
  useGetDesignationsQuery,
  useCreateDesignationMutation,
  useUpdateDesignationMutation,
  useGetDepartmentsQuery,
  useCreateDepartmentMutation,
} from '@/store/features/emsSlice'


const baseFields = {
  designation_name: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'Designation can only contain letters')
    .required('Designation is required'),
  department_name: yup.string().required('Department is required'),
  status: yup.string().required('Status is required'),
  annual_leave: yup.number().typeError('Must be a number').min(0, 'Cannot be negative').required('Annual leave is required'),
  casual_leave:  yup.number().typeError('Must be a number').min(0, 'Cannot be negative').required('Casual leave is required'),
  sick_leave:    yup.number().typeError('Must be a number').min(0, 'Cannot be negative').required('Sick leave is required'),
  maternity_leave: yup.number().typeError('Must be a number').min(0, 'Cannot be negative').required('Maternity leave is required'),
  paternity_leave: yup.number().typeError('Must be a number').min(0, 'Cannot be negative').required('Paternity leave is required'),
}

const schema = yup.object(baseFields)

const EMPTY_FORM = {
  designation_name: '',
  department_name: '',
  status: '',
  annual_leave: '',
  casual_leave: '',
  sick_leave: '',
  maternity_leave: '',
  paternity_leave: '',
}


const AddDesignation = () => {

  const { data: apiResponse, isLoading, error, refetch } = useGetDesignationsQuery()
  const [createDesignation, { isLoading: isCreating }] = useCreateDesignationMutation()
  const [updateDesignation, { isLoading: isUpdating }] = useUpdateDesignationMutation()
  const { data: departmentsData, refetch: refetchDepartments } = useGetDepartmentsQuery()
  const [createDepartmentApi, { isLoading: isCreatingDept }] = useCreateDepartmentMutation()

  const designations = Array.isArray(apiResponse)   ? apiResponse   : []
  const departments  = Array.isArray(departmentsData) ? departmentsData : []

  const {
    register, handleSubmit, formState: { errors }, reset, setValue, watch,
  } = useForm({ resolver: yupResolver(schema), mode: 'onChange', defaultValues: EMPTY_FORM })

  const departmentValue = watch('department_name')

  useEffect(() => {
    if (departmentValue === 'add-new') {
      setShowDepartmentModal(true)
      setValue('department_name', '')
    }
  }, [departmentValue, setValue])

  const {
    register: regEdit,
    handleSubmit: handleEditSubmit,
    formState: { errors: editErrors },
    reset: resetEdit,
    setValue: setEditValue,
    watch: watchEdit,
  } = useForm({ resolver: yupResolver(schema), mode: 'onChange' })

  const editDeptValue = watchEdit('department_name')

  useEffect(() => {
    if (editDeptValue === 'add-new') {
      setShowDepartmentModal(true)
      setEditValue('department_name', '')
    }
  }, [editDeptValue, setEditValue])

  const [showEditModal,       setShowEditModal]       = useState(false)
  const [showViewModal,       setShowViewModal]       = useState(false)
  const [showDepartmentModal, setShowDepartmentModal] = useState(false)
  const [viewDesignation,     setViewDesignation]     = useState(null)
  const [editDesignation,     setEditDesignation]     = useState(null)
  const [newDepartmentName,   setNewDepartmentName]   = useState('')
  const [isAdding,            setIsAdding]            = useState(false)
  const [successMsg,          setSuccessMsg]          = useState('')

  const onSubmit = async (data) => {
    try {
      await createDesignation(data).unwrap()
      reset(EMPTY_FORM)
      refetch()
    } catch (err) {
      console.error(err)
      alert(err?.data?.message || 'Failed to save')
    }
  }

  const openEdit = (item) => {
    setEditDesignation(item)
    setSuccessMsg('')
    resetEdit({
      designation_name: item.designation_name,
      department_name:  item.department_name,
      status:           item.status,
      annual_leave:     item.annual_leave  ?? 0,
      casual_leave:     item.casual_leave  ?? 0,
      sick_leave:       item.sick_leave    ?? 0,
      maternity_leave:  item.maternity_leave ?? 0,  
      paternity_leave:  item.paternity_leave ?? 0, 
    })
    setShowEditModal(true)
  }

  const onEditSubmit = async (data) => {
    try {
      await updateDesignation({ id: editDesignation.designation_id, ...data }).unwrap()
      setSuccessMsg('Designation updated successfully!')
      refetch()
      setTimeout(() => {
        setShowEditModal(false)
        setSuccessMsg('')
      }, 1200)
    } catch (err) {
      console.error(err)
      alert(err?.data?.message || 'Failed to update')
    }
  }

  const handleSaveDepartment = async () => {
    if (!newDepartmentName.trim()) return
    setIsAdding(true)
    try {
      await createDepartmentApi({ department_name: newDepartmentName.trim(), status: 'Active' }).unwrap()
      await refetchDepartments()
      if (showEditModal) setEditValue('department_name', newDepartmentName.trim())
      else setValue('department_name', newDepartmentName.trim())
      setShowDepartmentModal(false)
      setNewDepartmentName('')
    } catch (err) {
      alert(err?.data?.message || 'Failed to create department')
    } finally {
      setIsAdding(false)
    }
  }

  
  return (
    <>
      <ComponentContainerCard title="Add New Designation">
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Row className="my-3 d-flex align-items-end gap-3">
            <Col md={3}>
              <FormLabel>Designation</FormLabel>
              <FormControl type="text" {...register('designation_name')}
                isInvalid={!!errors.designation_name} placeholder="Enter Designation" />
              {errors.designation_name && <p className="text-danger small mb-0">{errors.designation_name.message}</p>}
            </Col>

            <Col md={3}>
              <FormLabel>Department</FormLabel>
              <FormSelect {...register('department_name')} isInvalid={!!errors.department_name}>
                <option value="">Select Department</option>
                {departments.map((d, i) => <option key={i} value={d.department_name}>{d.department_name}</option>)}
                <option value="add-new" className="text-primary fw-bold">+ Add new</option>
              </FormSelect>
              {errors.department_name && <p className="text-danger small mb-0">{errors.department_name.message}</p>}
            </Col>

            <Col md={3}>
              <FormLabel>Status</FormLabel>
              <FormSelect {...register('status')} isInvalid={!!errors.status}>
                <option value="">Select Status</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </FormSelect>
              {errors.status && <p className="text-danger small mb-0">{errors.status.message}</p>}
            </Col>

            <Col md={2}>
              <Button className="btn bg-primary w-100" type="submit" disabled={isCreating}>
                {isCreating
                  ? <><Spinner animation="border" size="sm" className="me-1" /> Saving…</>
                  : 'Add Designation'}
              </Button>
            </Col>
          </Row>

          <Row>
            <Col md={2}>
              <FormLabel>Annual Leave</FormLabel>
              <FormControl type="number" min={0} {...register('annual_leave')}
                isInvalid={!!errors.annual_leave} placeholder="Days" />
              {errors.annual_leave && <p className="text-danger small mb-0">{errors.annual_leave.message}</p>}
            </Col>
            <Col md={2}>
              <FormLabel>Casual Leave</FormLabel>
              <FormControl type="number" min={0} {...register('casual_leave')}
                isInvalid={!!errors.casual_leave} placeholder="Days" />
              {errors.casual_leave && <p className="text-danger small mb-0">{errors.casual_leave.message}</p>}
            </Col>
            <Col md={2}>
              <FormLabel>Sick Leave</FormLabel>
              <FormControl type="number" min={0} {...register('sick_leave')}
                isInvalid={!!errors.sick_leave} placeholder="Days" />
              {errors.sick_leave && <p className="text-danger small mb-0">{errors.sick_leave.message}</p>}
            </Col>
            <Col md={2}>
              <FormLabel>Maternity Leave</FormLabel>
              <FormControl type="number" min={0} {...register('maternity_leave')}
                isInvalid={!!errors.maternity_leave} placeholder="Days" />
              {errors.maternity_leave && <p className="text-danger small mb-0">{errors.maternity_leave.message}</p>}
            </Col>
            <Col md={2}>
              <FormLabel>Paternity Leave</FormLabel>
              <FormControl type="number" min={0} {...register('paternity_leave')}
                isInvalid={!!errors.paternity_leave} placeholder="Days" />
              {errors.paternity_leave && <p className="text-danger small mb-0">{errors.paternity_leave.message}</p>}
            </Col>
          </Row>
        </Form>
      </ComponentContainerCard>

      <Card className="mt-4">
        <CardHeader className="py-3 bg-light">
          <Row>
            <Col><CardTitle>Designation List</CardTitle></Col>
          </Row>
        </CardHeader>
        <CardBody>
          <div className="table-responsive">
            <Table striped hover>
              <thead>
                <tr>
                  <th>Designation</th>
                  <th>Department</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan="4" className="text-center py-4">Loading designations...</td></tr>
                ) : error ? (
                  <tr><td colSpan="4" className="text-center text-danger py-4">{error?.data?.message || 'Unknown error'}</td></tr>
                ) : designations.length > 0 ? (
                  designations.map(item => (
                    <tr key={item.designation_id}>
                      <td style={{ textTransform: 'capitalize' }}>{item.designation_name || 'N/A'}</td>
                      <td style={{ textTransform: 'capitalize' }}>{item.department_name  || 'N/A'}</td>
                      <td>
                        <span className={`badge ${item.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                          {item.status || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex align-items-center gap-2">
                          {/* View */}
                          <Button size="sm" className="d-flex align-items-center"
                            onClick={() => { setViewDesignation(item); setShowViewModal(true) }}
                            style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#007bff', borderColor: '#007bff', color: '#fff' }}>
                            <Icon icon="mdi:eye" width={15} style={{ marginRight: 4 }} />View
                          </Button>
                          {/* Edit */}
                          <Button size="sm" className="d-flex align-items-center"
                            onClick={() => openEdit(item)}
                            style={{ padding: '0.3rem 0.6rem', fontSize: '0.65rem', height: 30, borderRadius: 15, backgroundColor: '#fd7e14', borderColor: '#fd7e14', color: '#fff' }}>
                            <Icon icon="mdi:pencil" width={15} style={{ marginRight: 4 }} />Edit
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr><td colSpan="4" className="text-center py-4">No designations found.</td></tr>
                )}
              </tbody>
            </Table>
          </div>
        </CardBody>
      </Card>

     
      <Modal show={showEditModal} onHide={() => { setShowEditModal(false); setSuccessMsg('') }} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Designation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {successMsg && <Alert variant="success">{successMsg}</Alert>}

          <Form id="edit-designation-form" onSubmit={handleEditSubmit(onEditSubmit)}>
            <Row className="g-3">
              <Col md={6}>
                <FormLabel>Designation <span className="text-danger">*</span></FormLabel>
                <FormControl type="text" placeholder="Enter Designation"
                  {...regEdit('designation_name')} isInvalid={!!editErrors.designation_name} />
                {editErrors.designation_name && <p className="text-danger small mb-0">{editErrors.designation_name.message}</p>}
              </Col>

              <Col md={6}>
                <FormLabel>Department <span className="text-danger">*</span></FormLabel>
                <FormSelect {...regEdit('department_name')} isInvalid={!!editErrors.department_name}>
                  <option value="">Select Department</option>
                  {departments.map((d, i) => <option key={i} value={d.department_name}>{d.department_name}</option>)}
                  <option value="add-new" className="text-primary fw-bold">+ Add new</option>
                </FormSelect>
                {editErrors.department_name && <p className="text-danger small mb-0">{editErrors.department_name.message}</p>}
              </Col>

              <Col md={6}>
                <FormLabel>Status <span className="text-danger">*</span></FormLabel>
                <FormSelect {...regEdit('status')} isInvalid={!!editErrors.status}>
                  <option value="">Select Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </FormSelect>
                {editErrors.status && <p className="text-danger small mb-0">{editErrors.status.message}</p>}
              </Col>

              <Col md={2}>
                <FormLabel>Annual Leave</FormLabel>
                <FormControl type="number" min={0} placeholder="Days"
                  {...regEdit('annual_leave')} isInvalid={!!editErrors.annual_leave} />
                {editErrors.annual_leave && <p className="text-danger small mb-0">{editErrors.annual_leave.message}</p>}
              </Col>

              <Col md={2}>
                <FormLabel>Casual Leave</FormLabel>
                <FormControl type="number" min={0} placeholder="Days"
                  {...regEdit('casual_leave')} isInvalid={!!editErrors.casual_leave} />
                {editErrors.casual_leave && <p className="text-danger small mb-0">{editErrors.casual_leave.message}</p>}
              </Col>

              <Col md={2}>
                <FormLabel>Sick Leave</FormLabel>
                <FormControl type="number" min={0} placeholder="Days"
                  {...regEdit('sick_leave')} isInvalid={!!editErrors.sick_leave} />
                {editErrors.sick_leave && <p className="text-danger small mb-0">{editErrors.sick_leave.message}</p>}
              </Col>

              <Col md={2}>
                <FormLabel>Maternity Leave</FormLabel>
                <FormControl type="number" min={0} placeholder="Days"
                  {...regEdit('maternity_leave')} isInvalid={!!editErrors.maternity_leave} />
                {editErrors.maternity_leave && <p className="text-danger small mb-0">{editErrors.maternity_leave.message}</p>}
              </Col>
              <Col md={2}>
                <FormLabel>Paternity Leave</FormLabel>
                <FormControl type="number" min={0} placeholder="Days"
                  {...regEdit('paternity_leave')} isInvalid={!!editErrors.paternity_leave} />
                {editErrors.paternity_leave && <p className="text-danger small mb-0">{editErrors.paternity_leave.message}</p>}
              </Col>
                          </Row>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" disabled={isUpdating} onClick={() => { setShowEditModal(false); setSuccessMsg('') }}>Close</Button>
          <Button type="submit" form="edit-designation-form" variant="warning" disabled={isUpdating}>
            {isUpdating
              ? <><Spinner animation="border" size="sm" className="me-1" /> Saving…</>
              : 'Update Designation'}
          </Button>
        </Modal.Footer>
      </Modal>

     
      <Modal show={showViewModal} onHide={() => setShowViewModal(false)} centered size="md">
        <Modal.Header closeButton>
          <Modal.Title>Designation Details</Modal.Title>
        </Modal.Header>
        <Modal.Body className="p-0">
          {viewDesignation ? (
            <Card className="w-100 overflow-hidden border-0 rounded-0" style={{ backgroundColor: '#f8f9fa' }}>
              <div className="text-white text-center py-4 position-relative"
                style={{ backgroundColor: viewDesignation.status === 'active' ? '#28a745' : '#6c757d' }}>
                <span style={{ backgroundColor: '#020c07cc', color: 'white', padding: '4px 10px', borderRadius: 12, fontSize: '0.6rem', position: 'absolute', top: 10, right: 10, textTransform: 'capitalize' }}>
                  {viewDesignation.status}
                </span>
                <div className="mx-auto mb-2 d-flex align-items-center justify-content-center rounded-circle bg-white" style={{ width: 90, height: 90 }}>
                  <Icon icon="mdi:briefcase-account" width={52}
                    style={{ color: viewDesignation.status === 'active' ? '#28a745' : '#6c757d' }} />
                </div>
                <h5 className="mb-0 fw-bold" style={{ textTransform: 'capitalize' }}>{viewDesignation.designation_name}</h5>
              </div>

              <Card.Body className="px-4 py-3">
                <div className="d-flex flex-column gap-2">
                  {[
                    { icon: 'mdi:briefcase-outline',  label: 'Designation', value: viewDesignation.designation_name },
                    { icon: 'mdi:domain',              label: 'Department',  value: viewDesignation.department_name || '-' },
                    { icon: 'mdi:calendar-check',      label: 'Annual Leave',  value: `${viewDesignation.annual_leave ?? 0} days` },
                    { icon: 'mdi:calendar-clock',      label: 'Casual Leave',  value: `${viewDesignation.casual_leave ?? 0} days` },
                    { icon: 'mdi:hospital-box',        label: 'Sick Leave',    value: `${viewDesignation.sick_leave    ?? 0} days` },
                    { icon: 'mdi:baby-carriage',   label: 'Maternity Leave', value: `${viewDesignation.maternity_leave ?? 0} days` },
                    { icon: 'mdi:human-male-boy',  label: 'Paternity Leave', value: `${viewDesignation.paternity_leave ?? 0} days` },
                  ].map(({ icon, label, value }, i, arr) => (
                    <React.Fragment key={label}>
                      <div className="d-flex align-items-center gap-2">
                        <Icon icon={icon} width={18} className="text-muted flex-shrink-0" />
                        <span className="text-muted small">{label}</span>
                        <span className="fw-semibold small ms-auto" style={{ textTransform: 'capitalize' }}>{value}</span>
                      </div>
                      {i < arr.length - 1 && <hr className="my-1" />}
                    </React.Fragment>
                  ))}

                  <hr className="my-1" />
                  <div className="d-flex align-items-center gap-2">
                    <Icon icon={viewDesignation.status === 'active' ? 'mdi:check-circle' : 'mdi:close-circle'}
                      width={18} className={viewDesignation.status === 'active' ? 'text-success flex-shrink-0' : 'text-secondary flex-shrink-0'} />
                    <span className="text-muted small">Status</span>
                    <span className="ms-auto">
                      <span className={`badge ${viewDesignation.status === 'active' ? 'bg-success' : 'bg-secondary'}`} style={{ fontSize: '0.7rem' }}>
                        {viewDesignation.status}
                      </span>
                    </span>
                  </div>
                </div>
              </Card.Body>
            </Card>
          ) : (
            <p className="p-3">Loading...</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowViewModal(false)}>Close</Button>
        </Modal.Footer>
      </Modal>

      
      <Modal show={showDepartmentModal} onHide={() => setShowDepartmentModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Department</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={(e) => { e.preventDefault(); handleSaveDepartment() }}>
            <Form.Group className="mb-3">
              <FormLabel>Department Name</FormLabel>
              <FormControl type="text" value={newDepartmentName}
                onChange={(e) => setNewDepartmentName(e.target.value)}
                placeholder="Enter Department" />
            </Form.Group>
            <Button className="btn bg-primary border-primary w-100" type="submit" disabled={isAdding}>
              <div className="d-flex align-items-center justify-content-center gap-2">
                <Icon icon="material-symbols:group-add-rounded" width="20" height="20" />
                <span>{isAdding ? 'Saving...' : 'Add Department'}</span>
              </div>
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </>
  )
}

export default AddDesignation
