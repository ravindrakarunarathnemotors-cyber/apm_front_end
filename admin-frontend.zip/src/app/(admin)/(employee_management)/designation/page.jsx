import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Designation - Employee Management',
}


const AddDesignation = dynamic(() => import('./designation'), { ssr: false })

export default function AddDesignationPage() {
  return <AddDesignation />
}