'use client'

import React, { useState, useRef,useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Button, Col, Form, FormControl, FormLabel, FormSelect, Row, ListGroup, InputGroup } from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { Icon } from '@iconify/react/dist/iconify.js'
import Swal from 'sweetalert2'
import {
  useCreateEmployeeMutation,
  useGetDesignationsQuery,
  useGetShiftsQuery,
  useGetPayrollTemplatesMutation,
  useGetDepartmentsQuery, 
  useGetOutletsQuery,
} from '@/store/features/emsSlice'
import { useAdminLog } from '@/hooks/useAdminLog'

const schema = yup.object().shape({

  firstName:    yup.string().matches(/^[A-Za-z\s]+$/, 'Letters only').required('First Name is required'),
  middleName:   yup.string().nullable(),
  lastName:     yup.string().matches(/^[A-Za-z\s]+$/, 'Letters only').required('Last Name is required'),
  dob:          yup.string().required('Date of Birth is required'),
  maritalStatus:yup.string().required('Marital Status is required'),
  gender:       yup.string().required('Gender is required'),
  nationality:  yup.string().nullable(),
  nicNo:        yup.string().required('NIC is required'),
  email:        yup.string().email('Invalid email').required('Email is required'),
  mobileNo:     yup.string().required('Mobile Number is required'),
  contactNo:    yup.string().required('Contact Number is required'),
  address1:     yup.string().required('Address Line 1 is required'),
  address2:     yup.string().nullable(),
  city:         yup.string().required('City is required'),
  country:      yup.string().required('Country is required'),
  
  emergencyContactName:     yup.string().required('Emergency contact name is required'),
  emergencyRelationship:    yup.string().required('Relationship is required'),
  emergencyContactMobile:   yup.string().required('Emergency contact mobile is required'),
  emergencyContactAddress:  yup.string().nullable(),


    
  employmentStatus: yup.string().required('Employment status is required'),
  designation:      yup.string().required('Designation is required'),
  branchId: yup
  .number()
  .typeError('Branch selection is required')
  .required('Branch selection is required'),
  startday:         yup.string().required('Start Day is required'),
  ped:  yup.string().when('employmentStatus', {
    is: (v) => v === 'Permanent' || v === 'Probation',
    then: (s) => s.required('Probation End Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  dop: yup.string().when('employmentStatus', {
    is: (v) => v === 'Permanent',
    then: (s) => s.required('Date of Permanency is required'),
    otherwise: (s) => s.nullable(),
  }),
  csd: yup.string().when('employmentStatus', {
    is: (v) => v === 'Contract',
    then: (s) => s.required('Contract Start Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  ced: yup.string().when('employmentStatus', {
    is: (v) => v === 'Contract',
    then: (s) => s.required('Contract End Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  jobSpecification: yup.string().nullable(),


  payrolltemplate: yup.string().required('Payroll Template is required'),
  salary:          yup.number().typeError('Must be a number').positive().required('Salary is required'),
  ssd:             yup.string().required('First Salary Date is required'),
  shift:           yup.string().required('Shift is required'),
  bankacNo:        yup.string().required('Bank Account No is required'),
  bankOwnerName:   yup.string().required('Account Holder Name is required'),
  bankName:        yup.string().required('Bank Name is required'),
  bankbranchname:  yup.string().required('Bank Branch is required'),
  bankCode:        yup.string().required('Bank Code is required'),
  acctype:         yup.string().required('Account Type is required'),
  department: yup.string().required('Department is required'),
})


const AddEmployeeWizard = () => {
  const [step, setStep] = useState(1)
  const [bankSlipFile, setBankSlipFile] = useState(null)
  const [isUploading, setIsUploading] = useState(false)

  const { data: designations = [], isLoading: loadingDesignations } = useGetDesignationsQuery()
  const [createEmployee, { isLoading }] = useCreateEmployeeMutation()
  const { data: shifts = [], isLoading: loadingShifts } = useGetShiftsQuery()
  const [fetchPayrollTemplates, { data: payrollTemplatesData, isLoading: loadingTemplates }] = useGetPayrollTemplatesMutation()
  const payrollTemplates = payrollTemplatesData?.payroll_templates ?? []
  const { data: departments = [] } = useGetDepartmentsQuery()
  const { data: outlets = [], isLoading: loadingOutlets } = useGetOutletsQuery()
  const { sendLog } = useAdminLog()


  const outletList = Array.isArray(outlets) ? outlets : outlets?.data ?? []

   const uploadEmsFile = async (file, fileType) => {
    const token = sessionStorage.getItem('access_token')
    const fileForm = new FormData()
    fileForm.append('file', file)
    fileForm.append('file_type', fileType)

    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/emsUpload/upload-ems`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: fileForm,
    })
    if (!res.ok) throw new Error('File upload failed')
    return await res.json()
  }

  useEffect(() => {
  fetchPayrollTemplates({})
  }, [])
  
  const dropdownRef = useRef(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
    trigger,
    setValue,
    reset,
    watch,
    setError,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
    defaultValues: {
      employmentStatus: '',
      jobSpecification: '',
    },
  })

  const employmentStatus  = watch('employmentStatus')
  const payrollTemplate   = watch('payrolltemplate')
  const salaryValue       = watch('salary')
  const startDay          = watch('startday') 

 
  const handleBranchSearch = (e) => {
    const val = e.target.value
    setQuery(val)
    if (val.length > 0) {
      setFilteredBranches(outlets.filter(b =>
        b.outlet_name.toLowerCase().includes(val.toLowerCase())
      ))
      setShowDropdown(true)
    } else {
      setShowDropdown(false)
    }
  }

  const handleSelectBranch = (selected) => {
  setQuery(selected.outlet_name)
  setSelectedBranch(selected.outlet_id)
  setValue('branchId', selected.outlet_id, { shouldValidate: true })
  setShowDropdown(false)
}

// ── Derive salary_start_day + first_salary_strategy from salary_start_date ──
const handleSalaryStartDateChange = (salaryStartDate) => {
  setValue('ssd', salaryStartDate, { shouldValidate: true })

  if (!salaryStartDate || !startDay) return

  const start  = new Date(salaryStartDate)
  const joined = new Date(startDay)

  // Extract the day number (e.g. 26) from the picked date
  const derivedStartDay = start.getDate()

  // If same month+year as joined_date → CURRENT_MONTH, else NEXT_MONTH
  const derivedStrategy =
    start.getMonth() === joined.getMonth() &&
    start.getFullYear() === joined.getFullYear()
      ? 'CURRENT_MONTH'
      : 'NEXT_MONTH'

console.log('Derived:', { derivedStartDay, derivedStrategy, salaryStartDate, startDay })

  setValue('salary_start_day',       derivedStartDay,   { shouldValidate: false })
  setValue('first_salary_strategy',  derivedStrategy,   { shouldValidate: false })
}

  const handlePayrollChange = (e) => {
  const templateId = e.target.value
  setValue('payrolltemplate', templateId, { shouldValidate: true })
  const selected = payrollTemplates.find(t => String(t.id) === String(templateId))
  if (selected) {
    setValue('salary', selected.earnings ?? '', { shouldValidate: true })
  } else {
    setValue('salary', '', { shouldValidate: false })
  }
}

 
  const stepFields = {
    1: ['firstName', 'middleName', 'lastName', 'dob', 'maritalStatus', 'gender',
        'nicNo', 'email', 'mobileNo', 'contactNo', 'address1', 'city', 'country','emergencyContactName', 'emergencyRelationship', 'emergencyContactMobile'],
    2: ['designation', 'department', 'branchId', 'employmentStatus', 'startday',
        ...(employmentStatus === 'Contract'  ? ['csd', 'ced'] : []),
        ...(employmentStatus === 'Permanent' ? ['dop', 'ped'] : []),
        ...(employmentStatus === 'Probation' ? ['ped'] : []),
    ],
  }


  const nextStep = async () => {
    const isValid = await trigger(stepFields[step] || [])
    if (isValid) setStep(prev => prev + 1)
  }
  const prevStep = () => setStep(prev => prev - 1)
 

  const onSubmit = async (formData) => {
  const employmentStatusMap = {
    'Permanent': 'PERMANENT',
    'Probation': 'PROBATION',
    'Contract':  'CONTRACT',
  }
  const genderMap = {
    'Male':   'MALE',
    'Female': 'FEMALE',
    'Other':  'OTHER',
  }
  const maritalStatusMap = {
    'Single':   'SINGLE',
    'Married':  'MARRIED',
    'Divorced': 'DIVORCED',
    'Widowed':  'WIDOWED',
  }
  const accountTypeMap = {
    'Savings': 'SAVINGS',
    'Current': 'CURRENT',
  }

  try {
   
    let bankPassbookUrl = null
    if (bankSlipFile) {
      setIsUploading(true)   
      const uploadRes = await uploadEmsFile(bankSlipFile, 'bank_passbook')
      bankPassbookUrl = uploadRes.url
      setIsUploading(false)
    }
   
    const payload = {
      first_name:          formData.firstName,
      middle_name:         formData.middleName  || null,
      last_name:           formData.lastName,
      nic:                 formData.nicNo,
      contact_no:          formData.contactNo,
      mobile_number:       formData.mobileNo,
      email:               formData.email,
      date_of_birth:       formData.dob,
      marital_status:      maritalStatusMap[formData.maritalStatus] || formData.maritalStatus,
      gender:              genderMap[formData.gender] || formData.gender,
      nationality:         formData.nationality,
      address:             formData.address2
                           ? `${formData.address1}, ${formData.address2}`
                           : formData.address1,
      city:                formData.city,
      country:             formData.country,
      bank_account_no:     formData.bankacNo,
      account_holder_name: formData.bankOwnerName,
      bank_name:           formData.bankName,
      bank_branch:         formData.bankbranchname,
      bank_code:           formData.bankCode,
      account_type:        accountTypeMap[formData.acctype] || formData.acctype,
      bank_passbook_url:   bankPassbookUrl,        // ← S3 URL or null if no file
      joined_date:         formData.startday,
      job_specification:   formData.jobSpecification,
      employment_status:   employmentStatusMap[formData.employmentStatus] || formData.employmentStatus,
      probation_end_date:  formData.ped  || null,
      date_of_permanency:  formData.dop  || null,
      contract_start_date: formData.employmentStatus === 'Contract' ? formData.csd : null,
      contract_end_date:   formData.employmentStatus === 'Contract' ? formData.ced : null,
      salary:              formData.salary,
      salary_start_date:        formData.ssd,
      salary_start_day:      formData.salary_start_day ? Number(formData.salary_start_day) : null,
      first_salary_strategy:    formData.first_salary_strategy   || 'CURRENT_MONTH',
      payroll_template_id: Number(formData.payrolltemplate),
      shift_id:            Number(formData.shift),
      designation_id:      Number(formData.designation),
      outlet_id:           parseInt(formData.branchId, 10),
      department_id:       Number(formData.department),
      emergency_contact_full_name:    formData.emergencyContactName,
      emergency_contact_relationship: formData.emergencyRelationship,
      emergency_contact_mobile_no:    formData.emergencyContactMobile,
      emergency_contact_address:      formData.emergencyContactAddress || null,
    }

    console.log('Payload salary fields:', {
      salary_start_date:     formData.ssd,
      salary_start_day:      formData.salary_start_day,
      first_salary_strategy: formData.first_salary_strategy,
    })
    
    const response = await createEmployee(payload).unwrap()
    console.log("SUCCESS RESPONSE:", response)

    await sendLog('Employees', `New employee onboarded: ${payload.first_name} ${payload.last_name} | NIC: ${payload.nic} | Department ID: ${payload.department_id} | Designation ID: ${payload.designation_id}`)
    
    Swal.fire({
      icon: 'success',
      title: 'Employee onboarded successfully',
      toast: true,
      timer: 2000,
      position: 'top-end',
      showConfirmButton: false,
    })

    reset()
    setStep(1)
    setBankSlipFile(null)

 } catch (error) {
    setIsUploading(false)

    const status = error?.status
    const data   = error?.data

    if (status === 409 && data?.code === 'DUPLICATE_ENTRY') {
      // Map backend field names → { formField, step }
      const fieldMap = {
        email:          { formField: 'email',    step: 1 },
        mobile_number:  { formField: 'mobileNo', step: 1 },
        nic:            { formField: 'nicNo',     step: 1 },
        contact_no:     { formField: 'contactNo', step: 1 },
        bank_account_no:{ formField: 'bankacNo',  step: 3 },
      }

      const matched = data.field ? fieldMap[data.field] : null

      if (matched) {
        // Set inline field error (shows red under the field)
        setError(matched.formField, {
          type: 'manual',
          message: data.message,
        })
        // Navigate to the step that has the duplicate field
        setStep(matched.step)
      }

      Swal.fire({
        icon: 'warning',
        title: 'Duplicate Entry',
        text: data.message || 'This information is already registered.',
        confirmButtonColor: '#198754',
      })

      return
    }

    // Generic fallback error
    Swal.fire({
      icon: 'error',
      title: 'Failed to onboard employee',
      text: data?.message || 'Something went wrong. Please try again.',
    })
}
}

  
  return (
    <Form onSubmit={handleSubmit(onSubmit)} className="pb-5">
    
      <ComponentContainerCard title="Employee Onboarding">
        <div className="wizard-progress-wrap my-3">
          {[1, 2, 3].map((s) => {
            const labels = ['Personal Details', 'Employment Details', 'Salary & Shift']
            const isCompleted = step > s
            const isActive = step === s
            return (
              <React.Fragment key={s}>
                {s > 1 && (
                  <div className="wizard-connector">
                    <div className={`wizard-connector-fill ${isCompleted ? 'filled' : ''}`} />
                  </div>
                )}
                <div className={`wizard-step-node ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`}>
                  <div className="wizard-step-circle">
                    {isCompleted
                      ? <Icon icon="solar:check-circle-bold" style={{ fontSize: 18 }} />
                      : s}
                  </div>
                  <span className="wizard-step-label">{labels[s - 1]}</span>
                </div>
              </React.Fragment>
            )
          })}
        </div>

        <div className="form-inner-container px-lg-4">
          {step === 1 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Personal Details</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>First Name *</FormLabel>
                  <FormControl {...register('firstName')} isInvalid={!!errors.firstName} placeholder="Enter First Name" />
                  <p className="text-danger small">{errors.firstName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Middle Name</FormLabel>
                  <FormControl {...register('middleName')} placeholder="Enter Middle Name" />
                </Col>
                <Col md={4}>
                  <FormLabel>Last Name *</FormLabel>
                  <FormControl {...register('lastName')} isInvalid={!!errors.lastName} placeholder="Enter Last Name" />
                  <p className="text-danger small">{errors.lastName?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Date of Birth *</FormLabel>
                  <FormControl type="date" {...register('dob')} isInvalid={!!errors.dob} />
                  <p className="text-danger small">{errors.dob?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Marital Status *</FormLabel>
                  <FormSelect {...register('maritalStatus')} isInvalid={!!errors.maritalStatus}>
                    <option value="">-- Select --</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.maritalStatus?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Gender *</FormLabel>
                  <FormSelect {...register('gender')} isInvalid={!!errors.gender}>
                    <option value="">-- Select --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.gender?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Nationality</FormLabel>
                  <FormControl {...register('nationality')} placeholder="Enter Nationality" />
                </Col>
              
                <Col md={4}>
                  <FormLabel>NIC Number / Passport Number *</FormLabel>
                  <FormControl {...register('nicNo')} isInvalid={!!errors.nicNo} placeholder="19XXXXXXXXX" />
                  <p className="text-danger small">{errors.nicNo?.message}</p>
                </Col>
              </Row>

              <h6 className="section-divider"><span>Contact Details</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Email *</FormLabel>
                  <FormControl type="email" {...register('email')} isInvalid={!!errors.email} placeholder="name@company.com" />
                  <p className="text-danger small">{errors.email?.message}</p>
                </Col>
                
                <Col md={4}>
                  <FormLabel>Mobile Number *</FormLabel>
                  <FormControl {...register('mobileNo')} isInvalid={!!errors.mobileNo} placeholder="07XXXXXXXX" />
                  <p className="text-danger small">{errors.mobileNo?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Contact Number *</FormLabel>
                  <FormControl {...register('contactNo')} isInvalid={!!errors.contactNo} placeholder="07XXXXXXXX" />
                  <p className="text-danger small">{errors.contactNo?.message}</p>
                </Col>
              </Row>

              
              <Row className="g-3 my-0">
                <Col md={6}>
                  <FormLabel>Address Line 1 *</FormLabel>
                  <FormControl {...register('address1')} isInvalid={!!errors.address1} placeholder="123 Main St" />
                  <p className="text-danger small">{errors.address1?.message}</p>
                </Col>
                <Col md={6}>
                  <FormLabel>Address Line 2</FormLabel>
                  <FormControl {...register('address2')} placeholder="Apartment, suite, unit, etc." />
                </Col>
                <Col md={3}>
                  <FormLabel>City *</FormLabel>
                  <FormControl {...register('city')} isInvalid={!!errors.city} placeholder="Colombo" />
                  <p className="text-danger small">{errors.city?.message}</p>
                </Col>
                <Col md={3}>
                  <FormLabel>Country *</FormLabel>
                  <FormSelect {...register('country')} isInvalid={!!errors.country}>
                    <option value="">-- Select --</option>
                    <option value="SL">Sri Lanka</option>
                    <option value="UK">United Kingdom</option>
                    <option value="US">United States</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.country?.message}</p>
                </Col>
              </Row>

              <h6 className="section-divider"><span>Emergency Contact</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Full Name *</FormLabel>
                  <FormControl
                    {...register('emergencyContactName')}
                    isInvalid={!!errors.emergencyContactName}
                    placeholder="Enter full name"
                  />
                  <p className="text-danger small">{errors.emergencyContactName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Relationship *</FormLabel>
                  <FormSelect {...register('emergencyRelationship')} isInvalid={!!errors.emergencyRelationship}>
                    <option value="">-- Select --</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Parent">Parent</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Child">Child</option>
                    <option value="Friend">Friend</option>
                    <option value="Other">Other</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.emergencyRelationship?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Mobile Number *</FormLabel>
                  <FormControl
                    {...register('emergencyContactMobile')}
                    isInvalid={!!errors.emergencyContactMobile}
                    placeholder="07XXXXXXXX"
                  />
                  <p className="text-danger small">{errors.emergencyContactMobile?.message}</p>
                </Col>
                <Col md={6}>
                  <FormLabel>Address</FormLabel>
                  <FormControl
                    {...register('emergencyContactAddress')}
                    placeholder="Emergency contact address (optional)"
                  />
                </Col>
              </Row>
            </div>
          )}

          {step === 2 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Job Assignment</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Employment Status *</FormLabel>
                  <FormSelect {...register('employmentStatus')} isInvalid={!!errors.employmentStatus}>
                    <option value="">-- Select --</option>
                    <option value="Permanent">Permanent</option>
                    <option value="Probation">Probation</option>
                    <option value="Contract">Contract</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.employmentStatus?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Designation *</FormLabel>
                  <FormSelect {...register('designation')} isInvalid={!!errors.designation}>
                    <option value="">-- Select --</option>
                    {designations.map((d) => (
                      <option key={d.designation_id} value={d.designation_id}>
                        {d.designation_name}
                      </option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{errors.designation?.message}</p>
                </Col>

                <Col md={4} className="position-relative" ref={dropdownRef}>
                  <FormLabel>Branch *</FormLabel>
                  <FormSelect
                    {...register('branchId')}
                    isInvalid={!!errors.branchId}
                    disabled={loadingOutlets}
                    onChange={(e) => setValue('branchId', e.target.value, { shouldValidate: true })}
                    
                  >
                    <option value="">
                      {loadingOutlets ? 'Loading...' : '-- Select Branch --'}
                    </option>
                    {outletList.map((o) => (
                      <option key={o.outlet_id} value={o.outlet_id}>
                        {o.outlet_name}
                      </option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{errors.branchId?.message}</p>
                  </Col>
                  <Col md={4}>
                  <FormLabel>Department *</FormLabel>
                  <FormSelect {...register('department')} isInvalid={!!errors.department}>
                    <option value="">-- Select --</option>
                    {departments.map((d) => (
                      <option key={d.department_id} value={d.department_id}>
                        {d.department_name}
                      </option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{errors.department?.message}</p>
              </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Start Day *</FormLabel>
                  <FormControl type="date" {...register('startday')} isInvalid={!!errors.startday} />
                  <p className="text-danger small">{errors.startday?.message}</p>
                </Col>

              
                {(employmentStatus === 'Permanent' || employmentStatus === 'Probation') && (
                  <Col md={4}>
                    <FormLabel>Probation End Date *</FormLabel>
                    <FormControl type="date" {...register('ped')} isInvalid={!!errors.ped} />
                    <p className="text-danger small">{errors.ped?.message}</p>
                  </Col>
                )}
                {employmentStatus === 'Permanent' && (
                  <Col md={4}>
                    <FormLabel>Date of Permanency *</FormLabel>
                    <FormControl type="date" {...register('dop')} isInvalid={!!errors.dop} />
                    <p className="text-danger small">{errors.dop?.message}</p>
                  </Col>
                )}

          
                {employmentStatus === 'Contract' && (
                  <>
                    <Col md={4}>
                      <FormLabel>Contract Start Date *</FormLabel>
                      <FormControl type="date" {...register('csd')} isInvalid={!!errors.csd} />
                      <p className="text-danger small">{errors.csd?.message}</p>
                    </Col>
                    <Col md={4}>
                      <FormLabel>Contract End Date *</FormLabel>
                      <FormControl type="date" {...register('ced')} isInvalid={!!errors.ced} />
                      <p className="text-danger small">{errors.ced?.message}</p>
                    </Col>
                  </>
                )}
              </Row>

       
              <h6 className="section-divider"><span>Job Description</span></h6>
              <Row className="g-3 my-0">
                <Col md={12}>
                  <FormLabel>Job Description / Specification</FormLabel>
                  <FormControl
                    as="textarea"
                    rows={8}
                    placeholder="Describe key responsibilities, required skills, KPIs, reporting structure…"
                    {...register('jobSpecification')}
                    style={{
                      resize: 'vertical',
                      fontFamily: 'inherit',
                      fontSize: '0.9rem',
                      lineHeight: '1.6',
                      padding: '12px',
                    }}
                  />
                </Col>
              </Row>
            </div>
          )}

          {step === 3 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Shift</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Shift *</FormLabel>
                  <FormSelect {...register('shift')} isInvalid={!!errors.shift}>
                    <option value="">-- Select --</option>
                    {shifts.map((d) => (
                      <option key={d.shift_id} value={d.shift_id}>{d.shift_name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{errors.shift?.message}</p>
                </Col>
              </Row>

              
              <h6 className="section-divider"><span>Payroll & Salary</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Payroll Template *</FormLabel>
                  <FormSelect
                    {...register('payrolltemplate')}
                    isInvalid={!!errors.payrolltemplate}
                    onChange={handlePayrollChange}
                  >
                    <option value="">-- Select --</option>
                    {payrollTemplates.map((t) => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{errors.payrolltemplate?.message}</p>
                </Col>

                <Col md={4}>
                  <FormLabel>Gross Salary (Auto-filled)</FormLabel>
                  <InputGroup>
                    <InputGroup.Text>LKR</InputGroup.Text>
                    <FormControl
                      type="number"
                      {...register('salary')}
                      isInvalid={!!errors.salary}
                      readOnly
                      className="bg-light"
                      placeholder="Select a payroll template"
                    />
                  </InputGroup>
                  <Form.Text className="text-muted">Salary is set automatically by the payroll template.</Form.Text>
                  <p className="text-danger small">{errors.salary?.message}</p>
                </Col>

                <Col md={4}>
                    <FormLabel>First Salary Date *</FormLabel>
                    <FormControl
                        type="date"
                        {...register('ssd', {
                          onChange: (e) => handleSalaryStartDateChange(e.target.value)
                        })}
                        isInvalid={!!errors.ssd}
                        min={startDay || ''}
                      />
                    <p className="text-danger small">{errors.ssd?.message}</p>
                    {/* Show derived values as read-only hints */}
                    {watch('ssd') && startDay && (
                      <div className="mt-1">
                        <small className="text-muted d-block">
                          📅 Payroll day: <strong>{watch('salary_start_day') || '-'}</strong> of each month
                        </small>
                        <small className="text-muted d-block">
                          📌 Strategy: <strong>
                            {watch('first_salary_strategy') === 'CURRENT_MONTH' ? 'Current Month' : 'Next Month'}
                          </strong>
                        </small>
                      </div>
                    )}
                  </Col>
                  {/* Hidden fields — values set programmatically via handleSalaryStartDateChange */}
                  <input type="hidden" {...register('salary_start_day')} />
                  <input type="hidden" {...register('first_salary_strategy')} />
              </Row>

         
              <h6 className="section-divider"><span>Bank Account Details</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Bank Account No *</FormLabel>
                  <FormControl {...register('bankacNo')} isInvalid={!!errors.bankacNo} placeholder="e.g. 0012345678" />
                  <p className="text-danger small">{errors.bankacNo?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Account Holder Name *</FormLabel>
                  <FormControl {...register('bankOwnerName')} isInvalid={!!errors.bankOwnerName} placeholder="Enter full name as on passbook" />
                  <p className="text-danger small">{errors.bankOwnerName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Account Type *</FormLabel>
                  <FormSelect {...register('acctype')} isInvalid={!!errors.acctype}>
                    <option value="">-- Select --</option>
                    <option value="Savings">Savings</option>
                    <option value="Current">Current</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.acctype?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Name *</FormLabel>
                  <FormControl {...register('bankName')} isInvalid={!!errors.bankName} placeholder="e.g. Commercial Bank" />
                  <p className="text-danger small">{errors.bankName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Branch *</FormLabel>
                  <FormSelect {...register('bankbranchname')} isInvalid={!!errors.bankbranchname}>
                    <option value="">-- Select --</option>
                    <option value="Colombo">Colombo</option>
                    <option value="Galle">Galle</option>
                    <option value="Kandy">Kandy</option>
                    <option value="Kurunegala">Kurunegala</option>
                    <option value="Jaffna">Jaffna</option>
                  </FormSelect>
                  <p className="text-danger small">{errors.bankbranchname?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Code *</FormLabel>
                  <FormControl {...register('bankCode')} isInvalid={!!errors.bankCode} placeholder="e.g. 7056" />
                  <p className="text-danger small">{errors.bankCode?.message}</p>
                </Col>
              </Row>

          
              <h6 className="section-divider"><span>Bank PassBook Attachment</span></h6>
              <Row className="g-4">
                <Col md={6}>
                  <FormLabel>Upload Bank Passbook Front Page</FormLabel>
                  <FormControl
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setBankSlipFile(e.target.files[0] || null)}
                  />
                  {bankSlipFile && (
                    <Form.Text className="text-success">
                      <Icon icon="solar:check-circle-linear" className="me-1" />
                      {bankSlipFile.name} selected
                    </Form.Text>
                  )}
                  <Form.Text className="d-block text-muted">
                    Accepted formats: JPG, PNG, PDF. Max 5 MB.
                  </Form.Text>
                </Col>
              </Row>
            </div>
          )}
        </div>

        <div className="d-flex justify-content-between mt-5 pt-4 border-top">
          <Button variant="light" onClick={prevStep} disabled={step === 1}>
            <Icon icon="solar:alt-arrow-left-linear" /> Previous
          </Button>
          <div className="d-flex gap-2">
            {step < 3 ? (
              <Button variant="primary" onClick={nextStep}>
                Continue <Icon icon="solar:alt-arrow-right-linear" />
              </Button>
            ) : (
              <Button variant="success" type="submit" disabled={isLoading || isUploading}>
              {isUploading ? 'Uploading file…' : isLoading ? 'Saving…' : <>Finalize &amp; Save <Icon icon="solar:check-read-linear" /></>}
            </Button>
            )}
          </div>
        </div>

      </ComponentContainerCard>

      <style jsx>{`
        .wizard-progress-wrap {
        display: flex;
        align-items: center;
        justify-content: center;
        padding-bottom: 24px;
        border-bottom: 1px solid #eee;
        gap: 0;
      }

      /* The numbered circle */
      .wizard-step-node {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        position: relative;
        flex-shrink: 0;
      }

      .wizard-step-circle {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 2px solid #dee2e6;
        background: #fff;
        color: #adb5bd;
        font-weight: 700;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.4s ease;
        z-index: 1;
      }

      .wizard-step-node.active .wizard-step-circle {
        border-color: #198754;
        background: #198754;
        color: #fff;
        box-shadow: 0 0 0 4px rgba(25, 135, 84, 0.18);
      }

      .wizard-step-node.completed .wizard-step-circle {
        border-color: #198754;
        background: #d1e7dd;
        color: #198754;
      }

      .wizard-step-label {
        font-size: 0.72rem;
        font-weight: 600;
        color: #adb5bd;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
        transition: color 0.3s;
      }

      .wizard-step-node.active .wizard-step-label,
      .wizard-step-node.completed .wizard-step-label {
        color: #198754;
      }

      /* The connecting bar between steps */
      .wizard-connector {
        flex: 1;
        height: 4px;
        background: #e9ecef;
        border-radius: 2px;
        margin: 0 8px;
        margin-bottom: 22px; /* aligns with circle center */
        overflow: hidden;
        min-width: 60px;
      }

      .wizard-connector-fill {
        height: 100%;
        width: 0%;
        background: linear-gradient(90deg, #198754, #20c997);
        border-radius: 2px;
        transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
      }

      .wizard-connector-fill.filled {
        width: 100%;
      }
        .section-divider {
          width: 100%;
          text-align: center;
          border-bottom: 1px solid #f0f0f0;
          line-height: 0.1em;
          margin: 30px 0 20px;
        }
        .section-divider span {
          background: #fff;
          padding: 0 10px;
          color: #adb5bd;
          font-size: 0.75rem;
          letter-spacing: 1px;
          text-transform: uppercase;
        }
        .fade-in-up {
          animation: fadeInUp 0.4s ease-out;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </Form>
  )
}

export default AddEmployeeWizard
