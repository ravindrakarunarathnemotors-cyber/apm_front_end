'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Button, Col, Form, FormControl, FormLabel, FormSelect, Row, ListGroup, InputGroup } from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { Icon } from '@iconify/react/dist/iconify.js'
import Swal from 'sweetalert2'
import {
  useCreateEmployeeMutation,
  useGetDesignationsQuery,
  useGetShiftsQuery,
  useGetPayrollTemplatesMutation,
  useGetDepartmentsQuery,
  useGetOutletsQuery,
  useGetRolesQuery,
} from '@/store/features/emsSlice'
import { useAdminLog } from '@/hooks/useAdminLog'
import UseLogout from '@/hooks/useLogout'
import useRefreshToken from '@/hooks/useRefreshToken'
import PayCycleGroupModal from '@/components/PayCycleGroupModal'

const schema = yup.object().shape({

  firstName: yup.string().matches(/^[A-Za-z\s]+$/, 'Letters only').required('First Name is required'),
  middleName: yup.string().nullable(),
  lastName: yup.string().matches(/^[A-Za-z\s]+$/, 'Letters only').required('Last Name is required'),
  dob: yup.string().required('Date of Birth is required'),
  maritalStatus: yup.string().required('Marital Status is required'),
  gender: yup.string().required('Gender is required'),
  nationality: yup.string().nullable(),
  nicNo: yup.string().required('NIC is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  mobileNo: yup.string().required('Mobile Number is required'),
  contactNo: yup.string().required('Contact Number is required'),
  address1: yup.string().required('Address Line 1 is required'),
  address2: yup.string().nullable(),
  city: yup.string().required('City is required'),
  country: yup.string().required('Country is required'),

  emergencyContactName: yup.string().required('Emergency contact name is required'),
  emergencyRelationship: yup.string().required('Relationship is required'),
  emergencyContactMobile: yup.string().required('Emergency contact mobile is required'),
  emergencyContactAddress: yup.string().nullable(),



  employmentStatus: yup.string().required('Employment status is required'),
  designation: yup.string().required('Designation is required'),
  branchId: yup
    .number()
    .typeError('Branch selection is required')
    .required('Branch selection is required'),
  startday: yup.string().required('Start Day is required'),
  ped: yup.string().when('employmentStatus', {
    is: (v) => v === 'Permanent' || v === 'Probation',
    then: (s) => s.required('Probation End Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  dop: yup.string().when('employmentStatus', {
    is: (v) => v === 'Permanent',
    then: (s) => s.required('Date of Permanency is required'),
    otherwise: (s) => s.nullable(),
  }),
  csd: yup.string().when('employmentStatus', {
    is: (v) => v === 'Contract',
    then: (s) => s.required('Contract Start Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  ced: yup.string().when('employmentStatus', {
    is: (v) => v === 'Contract',
    then: (s) => s.required('Contract End Date is required'),
    otherwise: (s) => s.nullable(),
  }),
  jobSpecification: yup.string().nullable(),


  payrolltemplate: yup.string().required('Payroll Template is required'),
  salary: yup.number().typeError('Must be a number').positive().required('Salary is required'),
  ssd: yup.string().required('First Salary Date is required'),
  shift: yup.string().required('Shift is required'),
  bankacNo: yup.string().required('Bank Account No is required'),
  bankOwnerName: yup.string().required('Account Holder Name is required'),
  bankName: yup.string().required('Bank Name is required'),
  bankbranchname: yup.string().required('Bank Branch is required'),
  bankCode: yup.string().required('Bank Code is required'),
  acctype: yup.string().required('Account Type is required'),
  department: yup.string().required('Department is required'),

  createUserAccount: yup.boolean().default(false),
  username: yup.string().when('createUserAccount', {
    is: true,
    then: (s) => s.required('Username is required').min(3, 'Min 3 characters'),
    otherwise: (s) => s.nullable(),
  }),
  userRole: yup.string().when('createUserAccount', {
    is: true,
    then: (s) => s.required('Role is required'),
    otherwise: (s) => s.nullable(),
  }),
  password: yup.string().when('createUserAccount', {
    is: true,
    then: (s) =>
      s
        .required('Password is required')
        .min(8, 'Minimum 8 characters')
        .matches(/[A-Z]/, 'Must contain at least one uppercase letter')
        .matches(/[0-9]/, 'Must contain at least one number'),
    otherwise: (s) => s.nullable(),
  }),
  confirmPassword: yup.string().when('createUserAccount', {
    is: true,
    then: (s) =>
      s
        .required('Please confirm password')
        .oneOf([yup.ref('password')], 'Passwords do not match'),
    otherwise: (s) => s.nullable(),
  }),
})

const ordinal = (n) => {
  if (!n) return '—'
  const s = ['th','st','nd','rd']
  const v = n % 100
  return n + (s[(v - 20) % 10] || s[v] || s[0])
}

const AddEmployeeWizard = () => {
  const [selectedCycleGroup,  setSelectedCycleGroup]  = useState(null)
  const [cycleGroupModalOpen, setCycleGroupModalOpen] = useState(false)
  const [step, setStep] = useState(1)
  const [bankSlipFile, setBankSlipFile] = useState(null)
  const [createUserAccount, setCreateUserAccount] = useState(false)
  const [usernameStatus, setUsernameStatus] = useState(null) // null | 'checking' | 'available' | 'taken'
  const usernameCheckRef = useRef(null)
  const [isUploading, setIsUploading] = useState(false)
  const [stepAttempted, setStepAttempted] = useState({ 1: false, 2: false, 3: false })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  const { data: designations = [], isLoading: loadingDesignations } = useGetDesignationsQuery()
  const [createEmployee, { isLoading }] = useCreateEmployeeMutation()
  const { data: shifts = [], isLoading: loadingShifts } = useGetShiftsQuery()
  const [fetchPayrollTemplates, { data: payrollTemplatesData, isLoading: loadingTemplates }] = useGetPayrollTemplatesMutation()
  const payrollTemplates = payrollTemplatesData?.payroll_templates ?? []
  const { data: departments = [] } = useGetDepartmentsQuery()
  const { data: outlets = [], isLoading: loadingOutlets } = useGetOutletsQuery()
  const { data: roles = [] } = useGetRolesQuery()
  const { sendLog } = useAdminLog()


  const outletList = Array.isArray(outlets) ? outlets : outlets?.data ?? []

  const uploadEmsFile = async (file, fileType) => {
    const fileForm = new FormData()
    fileForm.append('file', file)
    fileForm.append('file_type', fileType)

    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/emsUpload/upload-ems`, {
      method: 'POST',
      headers: {},
      credentials: 'include',
      body: fileForm,
    })
    if (res.status === 401 || res.status === 403) {
      try {
        await refresh()
        return uploadEmsFile(file, fileType)
      } catch (refreshError) {
        console.error('Error refreshing token:', refreshError)
        Logout()
      }
    }
    if (!res.ok) throw new Error('File upload failed')
    return await res.json()
  }

  useEffect(() => {
    fetchPayrollTemplates({})
  }, [])

  const dropdownRef = useRef(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
    trigger,
    setValue,
    reset,
    watch,
    setError,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onSubmit',
    reValidateMode: 'onChange',
    defaultValues: {
      nationality: 'Sri Lankan',
      employmentStatus: '',
      jobSpecification: '',
      payrolltemplate: '',
      salary: '',
      ssd: '',
      shift: '',
      bankacNo: '',
      bankOwnerName: '',
      bankName: '',
      bankbranchname: '',
      bankCode: '',
      acctype: '',
    },
  })

  const employmentStatus = watch('employmentStatus')
  const payrollTemplate = watch('payrolltemplate')
  const salaryValue = watch('salary')
  const startDay = watch('startday')


  const handleBranchSearch = (e) => {
    const val = e.target.value
    setQuery(val)
    if (val.length > 0) {
      setFilteredBranches(outlets.filter(b =>
        b.outlet_name.toLowerCase().includes(val.toLowerCase())
      ))
      setShowDropdown(true)
    } else {
      setShowDropdown(false)
    }
  }

  const handleSelectBranch = (selected) => {
    setQuery(selected.outlet_name)
    setSelectedBranch(selected.outlet_id)
    setValue('branchId', selected.outlet_id, { shouldValidate: true })
    setShowDropdown(false)
  }

  // ── Derive salary_start_day + first_salary_strategy from salary_start_date ──
  const handleSalaryStartDateChange = (salaryStartDate) => {
    setValue('ssd', salaryStartDate, { shouldValidate: true })

    if (!salaryStartDate || !startDay) return

    const start = new Date(salaryStartDate)
    const joined = new Date(startDay)
    const derivedStartDay = start.getDate()
    const derivedStrategy =
      start.getMonth() === joined.getMonth() &&
        start.getFullYear() === joined.getFullYear()
        ? 'CURRENT_MONTH'
        : 'NEXT_MONTH'

    setValue('salary_start_day', derivedStartDay, { shouldValidate: false })
    setValue('first_salary_strategy', derivedStrategy, { shouldValidate: false })
  }

  const handlePayrollChange = (e) => {
    const templateId = e.target.value
    setValue('payrolltemplate', templateId, { shouldValidate: true })
    const selected = payrollTemplates.find(t => String(t.id) === String(templateId))
    if (selected) {
      setValue('salary', selected.earnings ?? '', { shouldValidate: true })
    } else {
      setValue('salary', '', { shouldValidate: false })
    }
  }

  const handleUserAccountToggle = (enabled) => {
  setCreateUserAccount(enabled)
  setValue('createUserAccount', enabled)
  if (enabled) {
    const firstName = watch('firstName')
    if (firstName && !watch('username')) {
      const autoUsername = firstName.toLowerCase().replace(/\s+/g, '')
      setValue('username', autoUsername, { shouldValidate: false })
      
      // ✅ Auto-check the pre-filled username immediately
      setUsernameStatus('checking')
      fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/check-username?username=${encodeURIComponent(autoUsername)}`,
        { credentials: 'include' }
      )
        .then(res => res.json())
        .then(data => {
          setUsernameStatus(data.available ? 'available' : 'taken')
          if (!data.available) {
            setError('username', { type: 'manual', message: 'Username already taken' })
          }
        })
        .catch(() => setUsernameStatus(null))
    }
  } else {
    setValue('username', '')
    setValue('userRole', '')
    setValue('password', '')
    setValue('confirmPassword', '')
    setUsernameStatus(null)
    setShowPassword(false)
    setShowConfirmPassword(false)
  }
}

const handleUsernameChange = (e) => {
  // ✅ Strip spaces entirely — username cannot contain spaces
  const val = e.target.value.replace(/\s+/g, '')
  setValue('username', val, { shouldValidate: true })

  if (usernameCheckRef.current) clearTimeout(usernameCheckRef.current)

  if (val.trim().length < 3) {
    setUsernameStatus(null)
    return
  }

  setUsernameStatus('checking')

  usernameCheckRef.current = setTimeout(async () => {
    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/check-username?username=${encodeURIComponent(val.trim())}`,
        { credentials: 'include' }
      )
      const data = await res.json()
      if (data.available) {
        setUsernameStatus('available')
        // ✅ Clear the error when username becomes available
        setError('username', { type: 'manual', message: '' })
      } else {
        setUsernameStatus('taken')
        setError('username', { type: 'manual', message: 'Username already taken' })
      }
    } catch {
      setUsernameStatus(null)
    }
  }, 500)
}


  const stepFields = {
    1: ['firstName', 'middleName', 'lastName', 'dob', 'maritalStatus', 'gender',
      'nicNo', 'email', 'mobileNo', 'contactNo', 'address1', 'city', 'country', 'emergencyContactName', 'emergencyRelationship', 'emergencyContactMobile'],
    2: [
      'designation', 'department', 'branchId', 'employmentStatus', 'startday',
      ...(employmentStatus === 'Contract' ? ['csd', 'ced'] : []),
      ...(employmentStatus === 'Permanent' ? ['dop', 'ped'] : []),
      ...(employmentStatus === 'Probation' ? ['ped'] : []),
      ...(createUserAccount ? ['username', 'userRole', 'password', 'confirmPassword'] : []),
    ],
  }


  const checkDuplicateFields = async () => {
    const mobileNo = watch('mobileNo')
    const email = watch('email')
    const nicNo = watch('nicNo')
    const contactNo = watch('contactNo')

    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/ems/check-duplicate`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({
            mobile_number: mobileNo,
            email,
            nic: nicNo,
            contact_no: contactNo,
          }),
        }
      )
      if (res.status === 401 || res.status === 403) {
        try {
          await refresh()
          return checkDuplicateFields()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (res.status === 409) {
        const data = await res.json()
        const fieldMap = {
          email: 'email',
          mobile_number: 'mobileNo',
          nic: 'nicNo',
          contact_no: 'contactNo',
        }
        const formField = fieldMap[data.field]
        if (formField) {
          setError(formField, { type: 'manual', message: data.message })
        }
        return false
      }
      return true
    } catch (err) {
      console.error('Duplicate check failed:', err)
      return true
    }
  }

    const nextStep = async () => {
      setStepAttempted(prev => ({ ...prev, [step]: true })) 
      const isValid = await trigger(stepFields[step] || [])
      if (!isValid) return

      if (step === 1) {
          const noDuplicates = await checkDuplicateFields()
          if (!noDuplicates) return
      }

      if (step === 2 && createUserAccount) {
          if (usernameStatus === 'taken') {
              setError('username', { type: 'manual', message: 'Username already taken' })
              return
          }
          if (usernameStatus === 'checking') {

              Swal.fire({
                  icon: 'info',
                  title: 'Checking username...',
                  text: 'Please wait a moment and try again.',
                  timer: 1500,
                  showConfirmButton: false,
              })
              return
          }
          if (usernameStatus !== 'available') {
              setError('username', { type: 'manual', message: 'Please enter a valid username' })
              return
          }
      }

      setStep(prev => prev + 1)
  }
  const prevStep = () => setStep(prev => prev - 1)


  const onSubmit = async (formData) => {
    const employmentStatusMap = {
      'Permanent': 'PERMANENT',
      'Probation': 'PROBATION',
      'Contract': 'CONTRACT',
    }
    const genderMap = {
      'Male': 'MALE',
      'Female': 'FEMALE',
      'Other': 'OTHER',
    }
    const maritalStatusMap = {
      'Single': 'SINGLE',
      'Married': 'MARRIED',
      'Divorced': 'DIVORCED',
      'Widowed': 'WIDOWED',
    }
    const accountTypeMap = {
      'Savings': 'SAVINGS',
      'Current': 'CURRENT',
    }

    try {

      let bankPassbookUrl = null
      try {
        if (bankSlipFile) {
          setIsUploading(true)
          const uploadRes = await uploadEmsFile(bankSlipFile, 'bank_passbook')
          bankPassbookUrl = uploadRes.url
        }
      } catch (err) {
        console.error('Upload error:', err)
        Swal.fire({ icon: 'warning', title: 'File upload failed', text: 'The passbook file could not be uploaded, but you can continue and add it later.' })
      } finally {
        setIsUploading(false)
      }

      const payload = {
        first_name: formData.firstName,
        middle_name: formData.middleName || null,
        last_name: formData.lastName,
        nic: formData.nicNo,
        contact_no: formData.contactNo,
        mobile_number: formData.mobileNo,
        email: formData.email,
        date_of_birth: formData.dob,
        marital_status: maritalStatusMap[formData.maritalStatus] || formData.maritalStatus,
        gender: genderMap[formData.gender] || formData.gender,
        nationality: formData.nationality,
        address: formData.address2
          ? `${formData.address1}, ${formData.address2}`
          : formData.address1,
        city: formData.city,
        country: formData.country,
        bank_account_no: formData.bankacNo,
        account_holder_name: formData.bankOwnerName,
        bank_name: formData.bankName,
        bank_branch: formData.bankbranchname,
        bank_code: formData.bankCode,
        account_type: accountTypeMap[formData.acctype] || formData.acctype,
        bank_passbook_url: bankPassbookUrl,        // ← S3 URL or null if no file
        joined_date: formData.startday,
        job_specification: formData.jobSpecification,
        employment_status: employmentStatusMap[formData.employmentStatus] || formData.employmentStatus,
        probation_end_date: formData.ped || null,
        date_of_permanency: formData.dop || null,
        contract_start_date: formData.employmentStatus === 'Contract' ? formData.csd : null,
        contract_end_date: formData.employmentStatus === 'Contract' ? formData.ced : null,
        salary: formData.salary,
        salary_start_date: formData.ssd,
        salary_start_day: formData.salary_start_day ? Number(formData.salary_start_day) : null,
        first_salary_strategy: formData.first_salary_strategy || 'CURRENT_MONTH',
        payroll_template_id: Number(formData.payrolltemplate),
        shift_id: Number(formData.shift),
        designation_id: Number(formData.designation),
        outlet_id: parseInt(formData.branchId, 10),
        department_id: Number(formData.department),
        emergency_contact_full_name: formData.emergencyContactName,
        emergency_contact_relationship: formData.emergencyRelationship,
        emergency_contact_mobile_no: formData.emergencyContactMobile,
        emergency_contact_address: formData.emergencyContactAddress || null,
        create_user_account: createUserAccount === true,
        is_first_time: createUserAccount === true ? true : undefined,
        username: createUserAccount ? formData.username?.trim() : null,
        role_id: createUserAccount ? Number(formData.userRole) : null,
        password: createUserAccount ? formData.password : null,
        pay_cycle_group_id: selectedCycleGroup
        ? (Number(selectedCycleGroup.id) || Number(selectedCycleGroup.pay_cycle_group_id) || null)
        : null,
      }

      console.log('FINAL PAYLOAD USER ACCOUNT:', {
        create_user_account: payload.create_user_account,
        username: payload.username,
        role_id: payload.role_id,
        password: payload.password ? '[SET]' : '[MISSING]',
      })

console.log('[onSubmit] selectedCycleGroup:', selectedCycleGroup);
console.log('[onSubmit] pay_cycle_group_id in payload:', payload.pay_cycle_group_id);
      const response = await createEmployee(payload).unwrap()

      await sendLog('Employees', `New employee onboarded: ${payload.first_name} ${payload.last_name} | NIC: ${payload.nic} | Department ID: ${payload.department_id} | Designation ID: ${payload.designation_id}`)

      Swal.fire({
        icon: 'success',
        title: 'Employee onboarded successfully',
        toast: true,
        timer: 2000,
        position: 'top-end',
        showConfirmButton: false,
      })

      reset()
      setStep(1)
      setBankSlipFile(null)
      setStepAttempted({ 1: false, 2: false, 3: false })
      setCreateUserAccount(false)
      setUsernameStatus(null)
      setShowPassword(false)
      setShowConfirmPassword(false)

    } catch (error) {
      setIsUploading(false)

      const status = error?.status
      const data = error?.data

     if (status === 409 && data?.code === 'DUPLICATE_ENTRY') {
        const fieldMap = {
            email: { formField: 'email', step: 1 },
            mobile_number: { formField: 'mobileNo', step: 1 },
            nic: { formField: 'nicNo', step: 1 },
            contact_no: { formField: 'contactNo', step: 1 },
            bank_account_no: { formField: 'bankacNo', step: 3 },
            username: { formField: 'username', step: 2 },  
        }

        const matched = data.field ? fieldMap[data.field] : null

        if (matched) {
          // Set inline field error (shows red under the field)
          setError(matched.formField, {
            type: 'manual',
            message: data.message,
          })
          // Navigate to the step that has the duplicate field
          setStep(matched.step)
        }

        Swal.fire({
          icon: 'warning',
          title: 'Duplicate Entry',
          text: data.message || 'This information is already registered.',
          confirmButtonColor: '#198754',
        })

        return
      }

      // Generic fallback error
      Swal.fire({
        icon: 'error',
        title: 'Failed to onboard employee',
        text: data?.message || 'Something went wrong. Please try again.',
      })
    }
  }

// ✅ CORRECT: helper to guard both red border AND error message per step
  const err = (field, s) => stepAttempted[s] && !!errors[field]

  return (
    // ✅ CORRECT: plain handleSubmit, no setStepAttempted here
    <Form onSubmit={handleSubmit(onSubmit)}>
      <ComponentContainerCard title="Employee Onboarding">

        {/* ── Wizard Progress Bar ── */}
        <div className="wizard-progress-wrap my-3">
          {[1, 2, 3].map((s) => {
            const labels = ['Personal Details', 'Employment Details', 'Salary & Shift']
            const isCompleted = step > s
            const isActive = step === s
            return (
              <React.Fragment key={s}>
                {s > 1 && (
                  <div className="wizard-connector">
                    <div className={`wizard-connector-fill ${isCompleted ? 'filled' : ''}`} />
                  </div>
                )}
                <div className={`wizard-step-node ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`}>
                  <div className="wizard-step-circle">
                    {isCompleted ? <Icon icon="solar:check-circle-bold" style={{ fontSize: 18 }} /> : s}
                  </div>
                  <span className="wizard-step-label">{labels[s - 1]}</span>
                </div>
              </React.Fragment>
            )
          })}
        </div>

        <div className="form-inner-container px-lg-4">

          {/* ─────────── STEP 1 ─────────── */}
          {step === 1 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Personal Details</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>First Name *</FormLabel>
                  {/* ✅ err('firstName', 1) — guards both border and message */}
                  <FormControl {...register('firstName')} isInvalid={err('firstName', 1)} placeholder="Enter First Name" />
                  <p className="text-danger small">{stepAttempted[1] && errors.firstName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Middle Name</FormLabel>
                  <FormControl {...register('middleName')} placeholder="Enter Middle Name" />
                </Col>
                <Col md={4}>
                  <FormLabel>Last Name *</FormLabel>
                  <FormControl {...register('lastName')} isInvalid={err('lastName', 1)} placeholder="Enter Last Name" />
                  <p className="text-danger small">{stepAttempted[1] && errors.lastName?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Date of Birth *</FormLabel>
                  <FormControl type="date" {...register('dob')} isInvalid={err('dob', 1)} />
                  <p className="text-danger small">{stepAttempted[1] && errors.dob?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Marital Status *</FormLabel>
                  <FormSelect {...register('maritalStatus')} isInvalid={err('maritalStatus', 1)}>
                    <option value="">-- Select --</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[1] && errors.maritalStatus?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Gender *</FormLabel>
                  <FormSelect {...register('gender')} isInvalid={err('gender', 1)}>
                    <option value="">-- Select --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[1] && errors.gender?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Nationality</FormLabel>
                  <FormControl {...register('nationality')} placeholder="Enter Nationality" />
                </Col>
                <Col md={4}>
                  <FormLabel>NIC Number / Passport Number *</FormLabel>
                  <FormControl {...register('nicNo')} isInvalid={err('nicNo', 1)} placeholder="19XXXXXXXXX" />
                  <p className="text-danger small">{stepAttempted[1] && errors.nicNo?.message}</p>
                </Col>
              </Row>

              <h6 className="section-divider"><span>Contact Details</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Email *</FormLabel>
                  <FormControl type="email" {...register('email')} isInvalid={err('email', 1)} placeholder="name@company.com" />
                  <p className="text-danger small">{stepAttempted[1] && errors.email?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Mobile Number *</FormLabel>
                  <FormControl {...register('mobileNo')} isInvalid={err('mobileNo', 1)} placeholder="94XXXXXXXXX" />
                  <Form.Text className="text-muted d-block">
                    Mobile numbers must start with <strong>94</strong> (e.g. 94771234567)
                  </Form.Text>
                  <p className="text-danger small">{stepAttempted[1] && errors.mobileNo?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Contact Number *</FormLabel>
                  <FormControl {...register('contactNo')} isInvalid={err('contactNo', 1)} placeholder="94XXXXXXXXX" />
                  <Form.Text className="text-muted d-block">
                    Contact numbers must start with <strong>94</strong> (e.g. 94112345678)
                  </Form.Text>
                  <p className="text-danger small">{stepAttempted[1] && errors.contactNo?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={6}>
                  <FormLabel>Address Line 1 *</FormLabel>
                  <FormControl {...register('address1')} isInvalid={err('address1', 1)} placeholder="123 Main St" />
                  <p className="text-danger small">{stepAttempted[1] && errors.address1?.message}</p>
                </Col>
                <Col md={6}>
                  <FormLabel>Address Line 2</FormLabel>
                  <FormControl {...register('address2')} placeholder="Apartment, suite, unit, etc." />
                </Col>
                <Col md={3}>
                  <FormLabel>City *</FormLabel>
                  <FormControl {...register('city')} isInvalid={err('city', 1)} placeholder="Colombo" />
                  <p className="text-danger small">{stepAttempted[1] && errors.city?.message}</p>
                </Col>
                <Col md={3}>
                  <FormLabel>Country *</FormLabel>
                  <FormSelect {...register('country')} isInvalid={err('country', 1)}>
                    <option value="">-- Select --</option>
                    <option value="SL">Sri Lanka</option>
                    <option value="UK">United Kingdom</option>
                    <option value="US">United States</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[1] && errors.country?.message}</p>
                </Col>
              </Row>

              <h6 className="section-divider"><span>Emergency Contact</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Full Name *</FormLabel>
                  <FormControl {...register('emergencyContactName')} isInvalid={err('emergencyContactName', 1)} placeholder="Enter full name" />
                  <p className="text-danger small">{stepAttempted[1] && errors.emergencyContactName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Relationship *</FormLabel>
                  <FormSelect {...register('emergencyRelationship')} isInvalid={err('emergencyRelationship', 1)}>
                    <option value="">-- Select --</option>
                    <option value="Spouse">Spouse</option>
                    <option value="Parent">Parent</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Child">Child</option>
                    <option value="Friend">Friend</option>
                    <option value="Other">Other</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[1] && errors.emergencyRelationship?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Mobile Number *</FormLabel>
                  <FormControl {...register('emergencyContactMobile')} isInvalid={err('emergencyContactMobile', 1)} placeholder="94XXXXXXXXX" />
                  <p className="text-danger small">{stepAttempted[1] && errors.emergencyContactMobile?.message}</p>
                </Col>
                <Col md={6}>
                  <FormLabel>Address</FormLabel>
                  <FormControl {...register('emergencyContactAddress')} placeholder="Emergency contact address" />
                </Col>
              </Row>
            </div>
          )}

          {/* ─────────── STEP 2 ─────────── */}
          {step === 2 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Job Assignment</span></h6>
              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Employment Status *</FormLabel>
                  {/* ✅ err('field', 2) for all step 2 inputs */}
                  <FormSelect {...register('employmentStatus')} isInvalid={err('employmentStatus', 2)}>
                    <option value="">-- Select --</option>
                    <option value="Permanent">Permanent</option>
                    <option value="Probation">Probation</option>
                    <option value="Contract">Contract</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[2] && errors.employmentStatus?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Designation *</FormLabel>
                  <FormSelect {...register('designation')} isInvalid={err('designation', 2)}>
                    <option value="">-- Select --</option>
                    {designations.map((d) => (
                      <option key={d.designation_id} value={d.designation_id}>{d.designation_name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[2] && errors.designation?.message}</p>
                </Col>
                <Col md={4} className="position-relative" ref={dropdownRef}>
                  <FormLabel>Branch *</FormLabel>
                  <FormSelect
                    {...register('branchId')}
                    isInvalid={err('branchId', 2)}
                    disabled={loadingOutlets}
                    onChange={(e) => setValue('branchId', e.target.value, { shouldValidate: true })}
                  >
                    <option value="">{loadingOutlets ? 'Loading...' : '-- Select Branch --'}</option>
                    {outletList.map((o) => (
                      <option key={o.outlet_id} value={o.outlet_id}>{o.outlet_name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[2] && errors.branchId?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Department *</FormLabel>
                  <FormSelect {...register('department')} isInvalid={err('department', 2)}>
                    <option value="">-- Select --</option>
                    {departments.map((d) => (
                      <option key={d.department_id} value={d.department_id}>{d.department_name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[2] && errors.department?.message}</p>
                </Col>
              </Row>

              <Row className="g-3 my-0">
                <Col md={4}>
                  <FormLabel>Start Day *</FormLabel>
                  <FormControl type="date" {...register('startday')} isInvalid={err('startday', 2)} />
                  <p className="text-danger small">{stepAttempted[2] && errors.startday?.message}</p>
                </Col>
                {(employmentStatus === 'Permanent' || employmentStatus === 'Probation') && (
                  <Col md={4}>
                    <FormLabel>Probation End Date *</FormLabel>
                    <FormControl type="date" {...register('ped')} isInvalid={err('ped', 2)} />
                    <p className="text-danger small">{stepAttempted[2] && errors.ped?.message}</p>
                  </Col>
                )}
                {employmentStatus === 'Permanent' && (
                  <Col md={4}>
                    <FormLabel>Date of Permanency *</FormLabel>
                    <FormControl type="date" {...register('dop')} isInvalid={err('dop', 2)} />
                    <p className="text-danger small">{stepAttempted[2] && errors.dop?.message}</p>
                  </Col>
                )}
                {employmentStatus === 'Contract' && (
                  <>
                    <Col md={4}>
                      <FormLabel>Contract Start Date *</FormLabel>
                      <FormControl type="date" {...register('csd')} isInvalid={err('csd', 2)} />
                      <p className="text-danger small">{stepAttempted[2] && errors.csd?.message}</p>
                    </Col>
                    <Col md={4}>
                      <FormLabel>Contract End Date *</FormLabel>
                      <FormControl type="date" {...register('ced')} isInvalid={err('ced', 2)} />
                      <p className="text-danger small">{stepAttempted[2] && errors.ced?.message}</p>
                    </Col>
                  </>
                )}
              </Row>

              <h6 className="section-divider"><span>Job Description</span></h6>
              <Row className="g-3 my-0">
                <Col md={12}>
                  <FormLabel>Job Description / Specification</FormLabel>
                  <FormControl
                    as="textarea"
                    rows={8}
                    placeholder="Describe key responsibilities, required skills, KPIs, reporting structure…"
                    {...register('jobSpecification')}
                    style={{ resize: 'vertical', fontFamily: 'inherit', fontSize: '0.9rem', lineHeight: '1.6', padding: '12px' }}
                  />
                </Col>
              </Row>

              <h6 className="section-divider"><span>User Account</span></h6>
              <Row className="g-3 my-0">
                <Col md={12}>
                  <div className="d-flex align-items-center gap-3 p-3 rounded"
                    style={{ background: '#f8f9fa', border: '1px solid #e9ecef' }}>
                    <Form.Check
                      type="switch"
                      id="create-user-account-switch"
                      checked={createUserAccount}
                      onChange={(e) => handleUserAccountToggle(e.target.checked)}
                      label=""
                    />
                    <div>
                      <div className="fw-semibold" style={{ fontSize: '0.9rem' }}>
                        Create User Account
                      </div>
                      <div className="text-muted" style={{ fontSize: '0.78rem' }}>
                        Enable to give this employee login access to the system
                      </div>
                    </div>
                  </div>
                </Col>

                {createUserAccount && (
                  <>
                    <Col md={4} className="mt-3">
                      <FormLabel>Username *</FormLabel>
                      <InputGroup>
                        <FormControl
                          {...register('username')}
                          isInvalid={err('username', 2)}
                          isValid={usernameStatus === 'available'}
                          placeholder="e.g. john.doe"
                          onChange={handleUsernameChange}
                          onKeyDown={(e) => { if (e.key === ' ') e.preventDefault() }}
                        />
                        <InputGroup.Text style={{ minWidth: 36 }}>
                          {usernameStatus === 'checking' && (
                            <span className="spinner-border spinner-border-sm text-secondary" />
                          )}
                          {usernameStatus === 'available' && (
                            <Icon icon="solar:check-circle-bold" style={{ color: '#198754', fontSize: 18 }} />
                          )}
                          {usernameStatus === 'taken' && (
                            <Icon icon="solar:close-circle-bold" style={{ color: '#dc3545', fontSize: 18 }} />
                          )}
                        </InputGroup.Text>
                      </InputGroup>
                      {usernameStatus === 'available' && (
                        <Form.Text className="text-success">Username is available</Form.Text>
                      )}
                      <p className="text-danger small">{stepAttempted[2] && errors.username?.message}</p>
                    </Col>

                    <Col md={4} className="mt-3">
                      <FormLabel>Role *</FormLabel>
                      <FormSelect
                        {...register('userRole')}
                        isInvalid={err('userRole', 2)}
                      >
                        <option value="">-- Select Role --</option>
                        {roles.map((r) => (
                          <option key={r.role_id} value={r.role_id}>
                            {r.role_name}
                          </option>
                        ))}
                      </FormSelect>
                      <p className="text-danger small">{stepAttempted[2] && errors.userRole?.message}</p>
                    </Col>

                    <Col md={4} className="mt-3">
                      <FormLabel>Password *</FormLabel>
                      <InputGroup>
                        <FormControl
                          type={showPassword ? 'text' : 'password'}
                          {...register('password')}
                          isInvalid={err('password', 2)}
                          placeholder="Min 8 chars, 1 uppercase, 1 number"
                          autoComplete="new-password"
                        />
                        <InputGroup.Text
                          style={{ cursor: 'pointer' }}
                          onClick={() => setShowPassword(v => !v)}
                        >
                          <Icon icon={showPassword ? 'solar:eye-closed-linear' : 'solar:eye-linear'} />
                        </InputGroup.Text>
                      </InputGroup>
                      <p className="text-danger small">{stepAttempted[2] && errors.password?.message}</p>
                    </Col>

                    <Col md={4} className="mt-3">
                      <FormLabel>Confirm Password *</FormLabel>
                      <InputGroup>
                        <FormControl
                          type={showConfirmPassword ? 'text' : 'password'}
                          {...register('confirmPassword')}
                          isInvalid={err('confirmPassword', 2)}
                          placeholder="Re-enter password"
                          autoComplete="new-password"
                        />
                        <InputGroup.Text
                          style={{ cursor: 'pointer' }}
                          onClick={() => setShowConfirmPassword(v => !v)}
                        >
                          <Icon icon={showConfirmPassword ? 'solar:eye-closed-linear' : 'solar:eye-linear'} />
                        </InputGroup.Text>
                      </InputGroup>
                      <p className="text-danger small">{stepAttempted[2] && errors.confirmPassword?.message}</p>
                    </Col>
                  </>
                )}
              </Row>
            </div>
          )}

          {/* ─────────── STEP 3 ─────────── */}
          {step === 3 && (
            <div className="fade-in-up">
              <h6 className="section-divider"><span>Shift</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Shift *</FormLabel>
                  {/* ✅ stepAttempted[3] guards everything in step 3 */}
                  <FormSelect {...register('shift')} isInvalid={err('shift', 3)}>
                    <option value="">-- Select --</option>
                    {shifts.map((d) => (
                      <option key={d.shift_id} value={d.shift_id}>{d.shift_name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[3] && errors.shift?.message}</p>
                </Col>
              </Row>
              <h6 className="section-divider"><span>Pay Cycle Group</span></h6>
              <Row className="g-4 mb-2">
                <Col md={8}>
                  <FormLabel>
                    Salary Cycle Group{' '}
                    <span style={{ fontWeight: 400, color: '#9ca3af', fontSize: '0.78rem' }}>optional</span>
                  </FormLabel>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'stretch' }}>
                    <div style={{
                      flex: 1, padding: '9px 14px', borderRadius: 10,
                      border: '1px solid #e5e7eb', background: '#f9fafb',
                      fontSize: '0.82rem', color: selectedCycleGroup ? '#111827' : '#9ca3af',
                      minHeight: 42, display: 'flex', alignItems: 'center',
                    }}>
                      {selectedCycleGroup ? (
                        <div>
                          <span style={{ fontWeight: 600 }}>{selectedCycleGroup.name}</span>
                          <span style={{ marginLeft: 8, fontSize: '0.72rem', color: '#6b7280' }}>
                            {selectedCycleGroup.cutoff_type === 'last_day'
                              ? '· closes last day of month'
                              : `· closes on the ${ordinal(selectedCycleGroup.cutoff_day)}`}
                          </span>
                        </div>
                      ) : 'No cycle group selected'}
                    </div>
                    <Button
                      type="button"
                      variant="outline-primary"
                      onClick={() => setCycleGroupModalOpen(true)}
                      style={{ borderRadius: 8, whiteSpace: 'nowrap', fontSize: '0.8rem' }}
                    >
                      {selectedCycleGroup ? 'Change' : 'Select Group'}
                    </Button>
                    {selectedCycleGroup && (
                      <Button
                        type="button"
                        variant="outline-secondary"
                        size="sm"
                        onClick={() => {
                          setSelectedCycleGroup(null)
                          setValue('ssd', '', { shouldValidate: false })
                        }}
                        style={{ borderRadius: 8 }}
                      >
                        <Icon icon="mdi:close" />
                      </Button>
                    )}
                  </div>
                  {selectedCycleGroup && (
                    <Form.Text className="text-success">
                      <Icon icon="mdi:check-circle-outline" width={11} className="me-1" />
                      Pay-run on day {selectedCycleGroup.payrun_day}
                      {selectedCycleGroup.payrun_month_offset === 1 ? ' of the following month' : ' of the same month'}.
                      First salary date is auto-filled below.
                    </Form.Text>
                  )}
                </Col>
              </Row>
              <h6 className="section-divider"><span>Payroll & Salary</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Payroll Template *</FormLabel>
                  <FormSelect {...register('payrolltemplate')} isInvalid={err('payrolltemplate', 3)} onChange={handlePayrollChange}>
                    <option value="">-- Select --</option>
                    {payrollTemplates.map((t) => (
                      <option key={t.id} value={t.id}>{t.name}</option>
                    ))}
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[3] && errors.payrolltemplate?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Gross Salary (Auto-filled)</FormLabel>
                  <InputGroup>
                    <InputGroup.Text>LKR</InputGroup.Text>
                    <FormControl
                      type="number"
                      {...register('salary')}
                      isInvalid={err('salary', 3)}
                      readOnly
                      className="bg-light"
                      placeholder="Select a payroll template"
                    />
                  </InputGroup>
                  <Form.Text className="text-muted">Salary is set automatically by the payroll template.</Form.Text>
                  <p className="text-danger small">{stepAttempted[3] && errors.salary?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>First Salary Date *</FormLabel>
                  <FormControl
                    type="date"
                    {...register('ssd', {
                      onChange: (e) => {
                        if (!selectedCycleGroup) handleSalaryStartDateChange(e.target.value)
                      },
                    })}
                    isInvalid={err('ssd', 3)}
                    readOnly={!!selectedCycleGroup}
                    className={selectedCycleGroup ? 'bg-light' : ''}
                    min={new Date().toISOString().split('T')[0]}
                  />
                  {selectedCycleGroup && (
                    <Form.Text className="text-muted" style={{ fontSize: '0.7rem' }}>
                      <Icon icon="mdi:lock-outline" width={11} className="me-1" />
                      Locked by pay cycle group — remove the group to edit manually
                    </Form.Text>
                  )}
                  <p className="text-danger small">{stepAttempted[3] && errors.ssd?.message}</p>
                  {watch('ssd') && startDay && (
                    <div className="mt-1">
                      <small className="text-muted d-block">
                        📅 Payroll day: <strong>{watch('salary_start_day') || '-'}</strong> of each month
                      </small>
                      <small className="text-muted d-block">
                        📌 Strategy: <strong>{watch('first_salary_strategy') === 'CURRENT_MONTH' ? 'Current Month' : 'Next Month'}</strong>
                      </small>
                    </div>
                  )}
                </Col>
                <input type="hidden" {...register('salary_start_day')} />
                <input type="hidden" {...register('first_salary_strategy')} />
              </Row>

              <h6 className="section-divider"><span>Bank Account Details</span></h6>
              <Row className="g-4">
                <Col md={4}>
                  <FormLabel>Bank Account No *</FormLabel>
                  <FormControl {...register('bankacNo')} isInvalid={err('bankacNo', 3)} placeholder="e.g. 0012345678" />
                  {/* ✅ FIXED: was stepAttempted[4], now stepAttempted[3] */}
                  <p className="text-danger small">{stepAttempted[3] && errors.bankacNo?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Account Holder Name *</FormLabel>
                  <FormControl {...register('bankOwnerName')} isInvalid={err('bankOwnerName', 3)} placeholder="Enter full name as on passbook" />
                  <p className="text-danger small">{stepAttempted[3] && errors.bankOwnerName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Account Type *</FormLabel>
                  <FormSelect {...register('acctype')} isInvalid={err('acctype', 3)}>
                    <option value="">-- Select --</option>
                    <option value="Savings">Savings</option>
                    <option value="Current">Current</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[3] && errors.acctype?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Name *</FormLabel>
                  <FormControl {...register('bankName')} isInvalid={err('bankName', 3)} placeholder="e.g. Commercial Bank" />
                  <p className="text-danger small">{stepAttempted[3] && errors.bankName?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Branch *</FormLabel>
                  <FormSelect {...register('bankbranchname')} isInvalid={err('bankbranchname', 3)}>
                    <option value="">-- Select --</option>
                    <option value="Colombo">Colombo</option>
                    <option value="Galle">Galle</option>
                    <option value="Kandy">Kandy</option>
                    <option value="Kurunegala">Kurunegala</option>
                    <option value="Jaffna">Jaffna</option>
                  </FormSelect>
                  <p className="text-danger small">{stepAttempted[3] && errors.bankbranchname?.message}</p>
                </Col>
                <Col md={4}>
                  <FormLabel>Bank Code *</FormLabel>
                  <FormControl {...register('bankCode')} isInvalid={err('bankCode', 3)} placeholder="e.g. 7056" />
                  <p className="text-danger small">{stepAttempted[3] && errors.bankCode?.message}</p>
                </Col>
              </Row>

              <h6 className="section-divider"><span>Bank PassBook Attachment</span></h6>
              <Row className="g-4">
                <Col md={6}>
                  <FormLabel>Upload Bank Passbook Front Page</FormLabel>
                  <FormControl
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setBankSlipFile(e.target.files[0] || null)}
                  />
                  {bankSlipFile && (
                    <Form.Text className="text-success">
                      <Icon icon="solar:check-circle-linear" className="me-1" />
                      {bankSlipFile.name} selected
                    </Form.Text>
                  )}
                  <Form.Text className="d-block text-muted">
                    Accepted formats: JPG, PNG, PDF. Max 5 MB.
                  </Form.Text>
                </Col>
              </Row>
            </div>
          )}
        </div>

        <div className="d-flex justify-content-between mt-5 pt-4 border-top">
          <Button variant="light" onClick={prevStep} disabled={step === 1}>
            <Icon icon="solar:alt-arrow-left-linear" /> Previous
          </Button>
          <div className="d-flex gap-2">
            {step < 3 ? (
              <Button variant="primary" onClick={nextStep}>
                Continue <Icon icon="solar:alt-arrow-right-linear" />
              </Button>
            ) : (
              // ✅ CORRECT: setStepAttempted on the button onClick, NOT on the Form onSubmit
              <Button
                variant="success"
                type="submit"
                disabled={isLoading || isUploading}
                onClick={() => setStepAttempted(prev => ({ ...prev, 3: true }))}
              >
                {isUploading ? 'Uploading file…' : isLoading ? 'Saving…' : <>Finalize &amp; Save <Icon icon="solar:check-read-linear" /></>}
              </Button>
            )}
          </div>
        </div>

      </ComponentContainerCard>

      <style jsx>{`
        .wizard-progress-wrap {
        display: flex;
        align-items: center;
        justify-content: center;
        padding-bottom: 24px;
        border-bottom: 1px solid #eee;
        gap: 0;
      }

      /* The numbered circle */
      .wizard-step-node {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        position: relative;
        flex-shrink: 0;
      }

      .wizard-step-circle {
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 2px solid #dee2e6;
        background: #fff;
        color: #adb5bd;
        font-weight: 700;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.4s ease;
        z-index: 1;
      }

      .wizard-step-node.active .wizard-step-circle {
        border-color: #198754;
        background: #198754;
        color: #fff;
        box-shadow: 0 0 0 4px rgba(25, 135, 84, 0.18);
      }

      .wizard-step-node.completed .wizard-step-circle {
        border-color: #198754;
        background: #d1e7dd;
        color: #198754;
      }

      .wizard-step-label {
        font-size: 0.72rem;
        font-weight: 600;
        color: #adb5bd;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
        transition: color 0.3s;
      }

      .wizard-step-node.active .wizard-step-label,
      .wizard-step-node.completed .wizard-step-label {
        color: #198754;
      }

      /* The connecting bar between steps */
      .wizard-connector {
        flex: 1;
        height: 4px;
        background: #e9ecef;
        border-radius: 2px;
        margin: 0 8px;
        margin-bottom: 22px; /* aligns with circle center */
        overflow: hidden;
        min-width: 60px;
      }

      .wizard-connector-fill {
        height: 100%;
        width: 0%;
        background: linear-gradient(90deg, #198754, #20c997);
        border-radius: 2px;
        transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1);
      }

      .wizard-connector-fill.filled {
        width: 100%;
      }
        .section-divider {
          width: 100%;
          text-align: center;
          border-bottom: 1px solid #f0f0f0;
          line-height: 0.1em;
          margin: 30px 0 20px;
        }
        .section-divider span {
          background: #fff;
          padding: 0 10px;
          color: #adb5bd;
          font-size: 0.75rem;
          letter-spacing: 1px;
          text-transform: uppercase;
        }
        .fade-in-up {
          animation: fadeInUp 0.4s ease-out;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      <PayCycleGroupModal
        show={cycleGroupModalOpen}
        onHide={() => setCycleGroupModalOpen(false)}
        onSelect={(group) => {
            console.log('[PayCycleGroupModal onSelect] group received:', group);
          setSelectedCycleGroup(group)
          setCycleGroupModalOpen(false)

          // Auto-compute next pay date from this group
          const today  = new Date()
          const pmo    = parseInt(group.payrun_month_offset, 10) ?? 1
          const rawM   = today.getMonth() + pmo
          const pY     = today.getFullYear() + (rawM > 11 ? 1 : 0)
          const normM  = rawM % 12
          const pMax   = new Date(pY, normM + 1, 0).getDate()
          const prd    = Math.min(parseInt(group.payrun_day, 10), pMax)
          const payISO = `${pY}-${String(normM + 1).padStart(2,'0')}-${String(prd).padStart(2,'0')}`

          setValue('ssd', payISO, { shouldValidate: true })
        }}
      />
    </Form>
  )
}

export default AddEmployeeWizard
