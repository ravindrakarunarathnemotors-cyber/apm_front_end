import dynamic from 'next/dynamic'

export const metadata = {
  title: 'AddEmployee - Employee Management',
}


const AddEmployee = dynamic(() => import('./AddEmployee'), { ssr: false })

export default function AddEmployeePage() {
  return <AddEmployee />
}