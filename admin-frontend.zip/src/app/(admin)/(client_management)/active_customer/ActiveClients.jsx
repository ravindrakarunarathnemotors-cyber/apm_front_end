'use client'

import React, { useState, useEffect, useRef } from 'react'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  Button,
  Table,
  Badge,
  Spinner,
} from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { debounce } from 'lodash'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import ViewModal from '../modals/viewModal'
import EditModal from '../modals/editModal'
import ActiveModal from '../modals/activeModal'
import Pagination from '@/components/Pagination'
import {
  useGetActiveclientsMutation,
  useGetCustonameQuery,
  useUpdateClientStatusMutation,
} from '@/store/features/apiSlice'

function ActiveClients() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [editOrder, setEditOrder] = useState(null)
  const [showEditModal, setShowEditModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [fetchPendingOrders, { isLoading, error }] = useGetActiveclientsMutation()
  const [pendingorders, setPendingOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [loading, setLoading] = useState(false)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showStatusModal, setShowStatusModal] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [isActivating, setIsActivating] = useState(true)

  const printSectionRef = useRef()

  const { data: RecipientResults } = useGetCustonameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })
  console.log('firstRecipient', RecipientResults)
  const [updateClientStatus] = useUpdateClientStatusMutation()

  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.first_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handleView = (order) => {
    setViewOrder(order)
    setShowViewModal(true)
  }

  const handleCloseViewModal = () => {
    setShowViewModal(false)
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  const handleEdit = (order) => {
    setEditOrder(order)
    setShowEditModal(true)
  }

  const handleCloseEditModal = () => {
    setShowEditModal(false)
  }

  const handleToggleStatus = (customer) => {
    setSelectedCustomer(customer)
    setIsActivating(customer.status !== 'active')
    setShowStatusModal(true)
  }

  const handleConfirmStatusChange = async () => {
    if (!selectedCustomer) return
    const newStatus = isActivating ? 'active' : 'inactive'

    try {
      const res = await updateClientStatus({
        customer_id: selectedCustomer.customer_id,
        status: newStatus,
      }).unwrap()

      if (res.success) {
        Swal.fire('Success', `Status updated to ${newStatus}`, 'success')

        const updated = pendingorders.map((c) => (c.customer_id === selectedCustomer.customer_id ? { ...c, status: newStatus } : c))
        setPendingOrders(updated)
      } else {
        Swal.fire('Error', res.message || 'Update failed', 'error')
      }
    } catch (err) {
      console.error(err)
      Swal.fire('Error', 'API request failed', 'error')
    } finally {
      setShowStatusModal(false)
    }
  }

  const fetchOrders = async (page, customLimit = limit) => {
    setLoading(true)
    try {
      const res = await fetchPendingOrders({
        page,
        limit: customLimit,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        keyword: filters.keyword,
        // payment_status: paymentStatus,
        // paymentMethod: paymentMethod,
        date: date,
      }).unwrap()

      setPendingOrders(res.pendingorders || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
      setTotalEntries(res.total || 0)
    } catch (err) {
      console.error('Failed to fetch orders:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchOrders(1, limit)
  }, [])

  const handleLimitChange = (e) => {
    const newLimit = Number(e.target.value)

    setLimit(newLimit)
    setCurrentPage(1)

    fetchOrders(1, newLimit)
  }

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }



  const capitalizeFirst = (text = '') => (text ? text.charAt(0).toUpperCase() + text.slice(1) : '-')

  useEffect(() => {
    fetchOrders(currentPage)
  }, [currentPage])

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Active Customers
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Date</FormLabel>
                <Form.Control type="date" placeholder="Recipient Name" value={date} onChange={(e) => setDate(e.target.value)} />
              </FormGroup>
              <FormGroup className="col-md-5">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile And Email"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchOrders(1)}>
                  Search
                </Button>

              </FormGroup>
            </Form>

            <div ref={printSectionRef}>
              <div className="table-responsive">
                <Table striped className="table mb-0">

                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Name</th>
                      <th>Contact</th>
                      <th>City</th>
                      <th>Email</th>
                      <th>Status</th>
                      <th className="text-center no-print">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={8} className="text-center py-4">
                          <Spinner animation="border" size="sm" role="status" className="me-2" />
                          Loading...
                        </td>
                      </tr>
                    ) : pendingorders.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="text-center">
                          No active clients
                        </td>
                      </tr>
                    ) : (
                      pendingorders.map((order) => (
                        <tr key={order.customer_id}>
                          <td>{order.customer_id}</td>
                          <td>{new Date(order.created_at).toLocaleDateString()}</td>
                          <td>{capitalizeFirst(order.first_name)}</td>
                          <td>{order.contact_number_1 || '-'} </td>
                          <td>{capitalizeFirst(order.city)}</td>
                          <td>{order.email || '-'}</td>
                          <td>{order.status.charAt(0).toUpperCase() + order.status.slice(1)}</td>
                          <td className="text-end no-print">
                            <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#5f5f5f',
                                  borderColor: '#5f5f5f',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => handleView(order)}>
                                <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>View</span>
                              </Button>

                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#fd7e14',
                                  borderColor: '#fd7e14',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => handleEdit(order)}>
                                <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Edit</span>
                              </Button>

                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  color: '#fff',
                                  backgroundColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                  borderColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                  flex: 1,
                                }}
                                onClick={() => handleToggleStatus(order)}
                                title={order.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                                <IconifyIcon
                                  icon={order.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                  style={{ fontSize: '20px', marginRight: '4px' }}
                                />
                                <span>{order.status === 'active' ? 'Active' : 'Inactive'}</span>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>
                </div>
              </div>

              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalEntries={totalEntries}
                limit={limit}
                onPageChange={handlePageChange}
                onLimitChange={(newLimit) => {
                  setLimit(newLimit)
                  setCurrentPage(1)
                  fetchOrders(1, newLimit)
                }}
                showingFrom={
                  pendingorders.length === 0
                    ? 0
                    : (currentPage - 1) * limit + 1
                }
                showingTo={
                  pendingorders.length === 0
                    ? 0
                    : (currentPage - 1) * limit + pendingorders.length
                }
              />
          </CardBody>
        </Card>
      </Col>
      <ViewModal showViewModal={showViewModal} handleCloseViewModal={handleCloseViewModal} viewOrder={viewOrder} />
      <EditModal showEditModal={showEditModal} handleCloseEditModal={handleCloseEditModal} editOrder={editOrder} />
      <ActiveModal
        show={showStatusModal}
        onClose={() => setShowStatusModal(false)}
        onConfirm={handleConfirmStatusChange}
        isActivating={isActivating}
      />
    </Row>
  )
}

export default ActiveClients
