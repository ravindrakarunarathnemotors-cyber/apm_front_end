import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Active Customers - Customer Management',
}


const ActiveClients = dynamic(() => import('./ActiveClients'), { ssr: false })

export default function ActiveClientsPage() {
  return <ActiveClients />
}