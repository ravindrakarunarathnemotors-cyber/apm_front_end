import dynamic from 'next/dynamic'

export const metadata = {
  title: 'approve reviews',
}

const ApproveReviews = dynamic(() => import('./ApproveReviews'), { ssr: false })

export default function AddProductPage() {
  return <ApproveReviews />
}