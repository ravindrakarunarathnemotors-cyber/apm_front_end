'use client'

import { useEffect, useMemo, useState } from 'react'
import { Card, Table, Pagination, Badge, Form, Spinner, Button } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'

import { useGetAllProductReviewsQuery, useUpdateReviewStatusMutation } from '@/store/features/apiSlice'

const ProductReviews = ({ pageSize = 25 }) => {
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [searchBy, setSearchBy] = useState('name') // new: 'name' or 'id'
  const [reviews, setReviews] = useState([])

  const { data: reviewsResp, isLoading, isFetching } = useGetAllProductReviewsQuery()
  const [updateReviewStatus] = useUpdateReviewStatusMutation()

  // map API → UI
  useEffect(() => {
    if (!reviewsResp) return
    const list = reviewsResp.reviews || []
    const mapped = list.map((r) => ({
      id: r.review_id,
      prod_id: r.product_id,
      name: r.customer_name,
      type: r.type === 1 ? 'Guest' : r.type === 2 ? 'Client' : 'Other',
      stars: parseFloat(r.review ?? 0),
      comment: r.comment || '',
      visible: r.status === 'active', // true = Approved, false = Rejected
    }))
    setReviews(mapped)
    setPage(1)
  }, [reviewsResp])

  // filtered list based on search & searchBy
  const filtered = useMemo(() => {
    const qRaw = (search || '').trim()
    const q = qRaw.toLowerCase()

    if (!qRaw) return reviews

    return reviews.filter((r) => {
      if (searchBy === 'id') {
        // Review ID (numeric or partial)
        return String(r.id).includes(qRaw)
      }
      if (searchBy === 'prod_id') {
        // Product ID (numeric or partial)
        return String(r.prod_id).includes(qRaw)
      }
      if (searchBy === 'name') {
        // Customer name
        return (r.name || '').toLowerCase().includes(q)
      }
      return true
    })
  }, [reviews, search, searchBy])

  // pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  useEffect(() => {
    if (page > totalPages) setPage(totalPages)
  }, [totalPages, page])

  const pageData = useMemo(() => {
    const start = (page - 1) * pageSize
    return filtered.slice(start, start + pageSize)
  }, [filtered, page, pageSize])

  // stars component
  const StarRating = ({ value }) => {
    const v = Number(value) || 0
    return (
      <>
        {Array.from({ length: Math.floor(v) }).map((_, i) => (
          <Icon key={`full-${i}`} icon="mdi:star" color="#ffc107" width={18} height={18} />
        ))}
        {v % 1 >= 0.5 && <Icon icon="mdi:star-half-full" color="#ffc107" width={18} height={18} />}
        {Array.from({ length: 5 - Math.ceil(v) }).map((_, i) => (
          <Icon key={`empty-${i}`} icon="mdi:star-outline" color="#ffc107" width={18} height={18} />
        ))}
        <span className="ms-1 text-muted small">({v.toFixed(1)})</span>
      </>
    )
  }

  // toggle status (API call + UI update)
  const handleToggle = async (r) => {
    const newStatus = r.visible ? 'inactive' : 'active'
    try {
      // Optimistic UI update
      setReviews((prev) => prev.map((x) => (x.id === r.id ? { ...x, visible: !x.visible } : x)))

      await updateReviewStatus({ review_id: r.id, status: newStatus }).unwrap()
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: `Review ${newStatus === 'active' ? 'Approved' : 'Rejected'} successfully`,
        timer: 1500,
        showConfirmButton: false,
      })
    } catch (err) {
      console.error('Update review status failed:', err)
      // revert UI on failure
      setReviews((prev) => prev.map((x) => (x.id === r.id ? { ...x, visible: r.visible } : x)))
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to update review status',
      })
    }
  }

  return (
    <Card className="shadow-sm">
      <Card.Header className="py-3 bg-light d-flex justify-content-between align-items-center">
        <Card.Title className="fw-bold mb-0">Approve Reviews</Card.Title>
        <div className="d-flex align-items-center" style={{ gap: 12 }}>
          <Form.Select value={searchBy} onChange={(e) => setSearchBy(e.target.value)} style={{ width: 160 }}>
            <option value="id">Review ID</option>
            <option value="prod_id">Product ID</option>
            <option value="name">Name</option>
          </Form.Select>

          <input
            type="text"
            className="form-control"
            placeholder={searchBy === 'id' ? 'Search by Review ID...' : searchBy === 'prod_id' ? 'Search by Product ID...' : 'Search by Name...'}
            style={{ width: 320, maxWidth: '80vw' }}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value)
              setPage(1)
            }}
          />

          <Button variant="primary" className="btn bg-primary border border-primary px-3">
            <Icon icon="mdi:magnify" width={18} className="me-1" />
            Search
          </Button>
        </div>
      </Card.Header>

      <Card.Body className="position-relative">
        {(isLoading || isFetching) && (
          <div
            className="position-absolute w-100 h-100 d-flex align-items-center justify-content-center"
            style={{ inset: 0, background: 'rgba(255,255,255,.6)', zIndex: 1, borderRadius: '.25rem' }}>
            <Spinner animation="border" role="status" />
          </div>
        )}

        <Table size="sm" striped  hover className="mb-2">
          <thead className="table-dark text-center" style={{height:'40px'}}>
            <tr>
              <th>Review ID</th>
              <th>Product ID</th>
              <th className='text-start ps-2'>Name</th>
              <th>Type</th>
              <th>Review</th>
              <th className='text-start ps-2'>Comment</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody className="text-center">
            {pageData.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-muted py-3">
                  No Product Reviews Found..
                </td>
              </tr>
            ) : (
              pageData.map((r) => (
                <tr key={r.id} style={{ height: '25px' }}>
                  <td>{r.id}</td>
                  <td>{r.prod_id}</td>
                  <td className='text-start ps-2'>{r.name}</td>
                  <td>{r.type}</td>
                  <td>
                    <StarRating value={r.stars} />
                  </td>
                  <td className='text-start ps-2'>{r.comment}</td>
                  <td className="p-1">
                     
                      <Badge bg={r.visible ? 'success' : 'danger'}>
                        {r.visible ? 'Approved' : 'Rejected'}
                      </Badge>
                  </td>
                  <td className="p-1">
                      <Form.Check type="switch" id={`visible-switch-${r.id}`} checked={r.visible} onChange={() => handleToggle(r)}  />

                  </td>
                </tr>
              ))
            )}
          </tbody>
        </Table>

        {totalPages > 1 && (
          <div className="d-flex justify-content-end">
            <Pagination>
              {Array.from({ length: totalPages }).map((_, i) => (
                <Pagination.Item key={i} active={i + 1 === page} onClick={() => setPage(i + 1)}>
                  {i + 1}
                </Pagination.Item>
              ))}
            </Pagination>
          </div>
        )}
      </Card.Body>
    </Card>
  )
}

export default ProductReviews
