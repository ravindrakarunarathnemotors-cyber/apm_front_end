'use client'

import React, { useState, useRef } from 'react'
import Swal from 'sweetalert2'
import { checkNumberFormat } from '@/utils/checkNumber'
import useLogout from '@/hooks/useLogout'
import axios from 'axios'
import { useRefreshTokenMutation, useGetAllCountriesQuery } from '@/store/features/apiSlice'
import { Button, ProgressBar, Card, CardHeader, CardBody, Row, Col, CardTitle } from 'react-bootstrap'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import AVATAR_PLACEHOLDER from '@/assets/avatar_placeholder.jpg'

const CreateCustomer = () => {
  const [customerInfo, setCustomerInfo] = useState({
    first_name: '',
    last_name: '',
    contact_number_1: '',
    contact_number_2: '',
    address: '',
    apartment: '',
    city: '',
    postal_code: '',
    email: '',
    company_name: '',
    avatar: AVATAR_PLACEHOLDER,
    country_name: '',
  })

  const [errors, setErrors] = useState({
    contact_number_1: '',
    contact_number_2: '',
    email: '',
  })

  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const fileRef = useRef(null)

  let token = ''
  if (typeof window !== 'undefined') {
    token = sessionStorage.getItem('access_token') || ''
  }

  const [refreshtoken] = useRefreshTokenMutation()
  const { data: countriesData, isLoading, isError } = useGetAllCountriesQuery()

  const { Logout } = useLogout()

  // const handleChange = (e) => {
  //   const { name, value } = e.target
  //   setCustomerInfo((prev) => ({ ...prev, [name]: value }))
  // }

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
  const digitsOnly = (val) => (val || '').replace(/\D/g, '')

  const handleChange = (e) => {
    const { name, value } = e.target


     if (name === 'country') {
   
   const selected = countriesData?.result?.find(
     (c) => String(c.id) === String(value)
   )
   setCustomerInfo((prev) => ({
     ...prev,
     country: value,                      
     country_name: selected?.country_name || '',
   }))
   return
 }

    if (name === 'contact_number_1' || name === 'contact_number_2') {
      const onlyDigits = digitsOnly(value)
      setCustomerInfo((prev) => ({ ...prev, [name]: onlyDigits }))
      setErrors((prev) => ({ ...prev, [name]: '' }))
      return
    }

    if (name === 'email') {
      setCustomerInfo((prev) => ({ ...prev, email: value.trim() }))
      setErrors((prev) => ({ ...prev, email: '' }))
      return
    }

    setCustomerInfo((prev) => ({ ...prev, [name]: value }))
  }

  const pickImage = () => fileRef.current?.click()

  const onImageSelected = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    const previewURL = URL.createObjectURL(file)
    setCustomerInfo((p) => ({ ...p, avatar: previewURL }))

    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'temp-brand')

    try {
      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (pe) => {
          if (!pe.total) return
          setUploadProgress(Math.round((pe.loaded * 100) / pe.total))
        },
      })

      const uploadedUrl = res?.data?.media?.[0]?.media_url
      if (!uploadedUrl) throw new Error('Upload failed')

      setCustomerInfo((p) => ({ ...p, avatar: uploadedUrl }))
    } catch (err) {
      console.error(err)
      Swal.fire({ icon: 'error', title: 'Upload Failed', text: err?.message || 'Image upload failed' })
      setCustomerInfo((p) => ({ ...p, avatar: AVATAR_PLACEHOLDER }))
    } finally {
      setUploading(false)
      setUploadProgress(0)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const removeAvatar = () => {
    setCustomerInfo((p) => ({ ...p, avatar: AVATAR_PLACEHOLDER }))
    if (fileRef.current) fileRef.current.value = ''
  }

  const validate = () => {
    const newErr = { contact_number_1: '', contact_number_2: '', email: '' }
    let ok = true

    if (!/^94\d{9}$/.test(customerInfo.contact_number_1 || '')) {
      newErr.contact_number_1 = 'Mobile must be 94XXXXXXXXX (11 digits)'
      ok = false
    }

    if (customerInfo.contact_number_2) {
      if (!/^94\d{9}$/.test(customerInfo.contact_number_2)) {
        newErr.contact_number_2 = 'Phone must be 94XXXXXXXXX (11 digits)'
        ok = false
      }
    }

    if (customerInfo.email && !isValidEmail(customerInfo.email)) {
      newErr.email = 'Enter a valid email address'
      ok = false
    }

    if (!customerInfo.contact_number_1 && !customerInfo.email) {
      if (!newErr.contact_number_1) newErr.contact_number_1 = 'Provide mobile (94XXXXXXXXX) or email'
      if (!newErr.email) newErr.email = 'Provide email or mobile'
      ok = false
    }

    setErrors(newErr)
    return ok
  }

  const handleSubmit = async (isRetry = false) => {
    if (customerInfo.first_name === '' || customerInfo.address === '' || customerInfo.city === '' || customerInfo.last_name === '') {
      Swal.fire({ title: 'Error', text: 'Please fill all the required fields', icon: 'error', confirmButtonText: 'OK' })
      return
    }

    if (!customerInfo.contact_number_1 && !customerInfo.email) {
      Swal.fire({ title: 'Error', text: 'Please fill at least one contact number or email', icon: 'error', confirmButtonText: 'OK' })
      return
    }
    if (!validate()) {
      Swal.fire({ title: 'Error', text: 'Please fix validation errors', icon: 'error', confirmButtonText: 'OK' })
      return
    }

    try {
      const payload = {
        first_name: customerInfo.first_name,
        last_name: customerInfo.last_name,
        contact_number_1: customerInfo.contact_number_1,
        contact_number_2: customerInfo.contact_number_2 || null,
        address: customerInfo.address,
        apartment: customerInfo.apartment,
        city: customerInfo.city,
        postal_code: customerInfo.postal_code,
        email: customerInfo.email,
        company_name: customerInfo.company_name,
        picture: customerInfo.avatar,
        country: customerInfo.country || '',
      }

      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/order/createCustomer`, payload, {
        headers: { Authorization: `Bearer ${token}` },
      })

      if (response.status === 201) {
        Swal.fire({ title: 'Success', text: 'Customer added successfully', icon: 'success', confirmButtonText: 'OK' })
        setCustomerInfo({
          first_name: '',
          last_name: '',
          contact_number_1: '',
          contact_number_2: '',
          address: '',
          apartment: '',
          city: '',
          postal_code: '',
          email: '',
          company_name: '',
          avatar: AVATAR_PLACEHOLDER,
          country_name: '',
        })
      }
    } catch (error) {
      if ((error.response?.status === 401 || error.response?.status === 403) && !isRetry) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const r = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', r.access_token)
            token = r.access_token
            return handleSubmit(true)
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        Swal.fire({
          title: 'Error',
          text: error?.response?.data?.message || 'Something went wrong',
          icon: 'error',
          confirmButtonText: 'OK',
        })
      }
    }
  }

  return (
    <div className="container">
      <Row className="justify-content-center">
        <Col>
          <Card>
            <CardHeader className="py-3 bg-light">
              <CardTitle as="h4" className="mb-0">
                Add Customers
              </CardTitle>
            </CardHeader>
            <CardBody>
              <div className="d-flex align-items-center mb-3">
                <div className="position-relative me-3">
                  <div
                    style={{
                      width: 96,
                      height: 96,
                      borderRadius: '50%',
                      overflow: 'hidden',
                      border: '1px solid #e3e3e3',
                      background: '#f7f7f7',
                    }}>
                    <img
                      src={customerInfo.avatar}
                      alt="avatar"
                      width={96}
                      height={96}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                    />
                  </div>

                  <Link
                    href=""
                    className="thumb-md justify-content-center d-flex align-items-center bg-primary text-white rounded-circle position-absolute"
                    style={{ right: -6, bottom: -6, width: 36, height: 36 }}
                    onClick={(e) => {
                      e.preventDefault()
                      pickImage()
                    }}>
                    <IconifyIcon icon="bi:camera" width={15} height={15} />
                  </Link>

                  <input ref={fileRef} type="file" accept="image/*" onChange={onImageSelected} style={{ display: 'none' }} />
                </div>
              </div>

              {uploading && (
                <div className="mb-3">
                  <ProgressBar now={uploadProgress} animated label={`${uploadProgress}%`} />
                </div>
              )}

              <div>
                <div className="row">
                  <div className="col-md-6 mb-2">
                    <label className="form-label">First Name</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="First name"
                      name="first_name"
                      value={customerInfo.first_name}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="col-md-6 mb-2">
                    <label className="form-label">Last name</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Last name"
                      name="last_name"
                      value={customerInfo.last_name}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6 mb-2">
                    <label className="form-label">Mobile Number</label>
                    <input
                      type="tel"
                      className={`form-control ${errors.contact_number_1 ? 'is-invalid' : ''}`}
                      placeholder="94XXXXXXXXX"
                      name="contact_number_1"
                      value={customerInfo.contact_number_1}
                      onChange={handleChange}
                      maxLength={11}
                    />
                    {errors.contact_number_1 && <div className="invalid-feedback">{errors.contact_number_1}</div>}
                  </div>

                  <div className="col-md-6 mb-2">
                    <label className="form-label">Phone Number (Optional)</label>
                    <input
                      type="tel"
                      className={`form-control ${errors.contact_number_2 ? 'is-invalid' : ''}`}
                      placeholder="94XXXXXXXXX"
                      name="contact_number_2"
                      value={customerInfo.contact_number_2}
                      onChange={handleChange}
                      maxLength={11}
                    />
                    {errors.contact_number_2 && <div className="invalid-feedback">{errors.contact_number_2}</div>}
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6 mb-2">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                      placeholder="name@example.com"
                      name="email"
                      value={customerInfo.email}
                      onChange={handleChange}
                    />
                    {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                  </div>
                  <div className="col-md-6 mb-2">
                    <label className="form-label">Company Name</label>
                    <input
                      type="tel"
                      className="form-control"
                      placeholder="Company Name"
                      name="company_name"
                      value={customerInfo.company_name}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="mb-2">
                  <label className="form-label">Address Line 1</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="No.120/A"
                    name="address"
                    value={customerInfo.address}
                    onChange={handleChange}
                  />
                </div>

                <div className="mb-2">
                  <label className="form-label">Address Line 2</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="1st lane, Araliya Garden"
                    name="apartment"
                    value={customerInfo.apartment}
                    onChange={handleChange}
                  />
                </div>

                <div className="row">
                  

                  <div className="col-md-4 mb-2">
                    <label className="form-label">City</label>
                    <input type="text" className="form-control" placeholder="City" name="city" value={customerInfo.city} onChange={handleChange} />
                  </div>

                  <div className="col-md-4 mb-2">
                    <label className="form-label">Postal code (Optional)</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Postal code"
                      name="postal_code"
                      value={customerInfo.postal_code}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="col-12 col-md-4 mb-2 select-dropdown">
                    <label className="form-label">Country/Region</label>
                    <select
                      name="country"
                      className="form-control"
                      value={customerInfo.country}
                      onChange={(e) => {
                        handleChange(e)
                        e.target.size = 1
                        e.target.blur()
                      }}
                      onFocus={(e) => (e.target.size = 10)}
                      onBlur={(e) => (e.target.size = 1)}
                      style={{ overflowY: 'auto', maxHeight: '250px' }}>
                      <option value="">Select Country</option>
                      {isLoading && <option>Loading countries...</option>}
                      {isError && <option className="text-danger">Failed to load</option>}
                      {countriesData?.result?.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.country_name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="d-flex justify-content-end gap-2">
                  <Button
                    variant="secondary"
                    onClick={() =>
                      setCustomerInfo({
                        first_name: '',
                        last_name: '',
                        contact_number_1: '',
                        contact_number_2: '',
                        address: '',
                        apartment: '',
                        city: '',
                        postal_code: '',
                        email: '',
                        company_name: '',
                        avatar: AVATAR_PLACEHOLDER,
                      })
                    }>
                    Clear
                  </Button>
                  <Button className="btn bg-primary border border-primary px-4" variant="primary" onClick={() => handleSubmit()}>
                    Save
                  </Button>
                </div>
              </div>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  )
}

export default CreateCustomer
