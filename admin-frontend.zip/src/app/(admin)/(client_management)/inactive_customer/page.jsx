'use client'

import React, { useState, useEffect, useRef } from 'react'
import {
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Button,
  Table,
  Pagination,
  Badge,
  Spinner,
} from 'react-bootstrap'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { debounce } from 'lodash'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'
import ViewModal from '../modals/viewModal'
import EditModal from '../modals/editModal'
import ActiveModal from '../modals/activeModal'
import {
  useGetInactiveclientsMutation,
  useGetCustonameQuery,
  useCancelOrderMutation,
  useUpdateClientStatusMutation,
} from '@/store/features/apiSlice'

function InactiveClients() {
  const [filters, setFilters] = useState({
    order_number: '',
    recipient_name: '',
    mobile: '',
    date: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [orderId, setOrderId] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [mobileNo, setMobileNo] = useState('')
  const [date, setDate] = useState('')
  const [viewOrder, setViewOrder] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [editOrder, setEditOrder] = useState(null)
  const [showEditModal, setShowEditModal] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('')
  const [fetchPendingOrders, { isLoading, error }] = useGetInactiveclientsMutation()
  const [pendingorders, setPendingOrders] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const logsPerPage = 25
  const [loading, setLoading] = useState(false)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showStatusModal, setShowStatusModal] = useState(false)
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [isActivating, setIsActivating] = useState(true)

  const printSectionRef = useRef()

  const { data: RecipientResults } = useGetCustonameQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })

  const [updateClientStatus] = useUpdateClientStatusMutation()

  const [cancelOrder] = useCancelOrderMutation()
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.first_name}`,
    })) || []

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const handleView = (order) => {
    setViewOrder(order)
    setShowViewModal(true)
  }

  // const handlePageChange = (page) => {
  //   if (page < 1 || page > totalPages) return
  //   setCurrentPage(page)
  // }
  const handleCloseViewModal = () => {
    setShowViewModal(false)
  }

  const handleEdit = (order) => {
    setEditOrder(order)
    setShowEditModal(true)
  }

  const handleCloseEditModal = () => {
    setShowEditModal(false)
  }

  const handleToggleStatus = (customer) => {
    setSelectedCustomer(customer)
    setIsActivating(customer.status !== 'active')
    setShowStatusModal(true)
  }

  const handleConfirmStatusChange = async () => {
    if (!selectedCustomer) return
    const newStatus = isActivating ? 'active' : 'inactive'

    try {
      const res = await updateClientStatus({
        customer_id: selectedCustomer.customer_id,
        status: newStatus,
      }).unwrap()

      if (res.success) {
        Swal.fire('Success', `Status updated to ${newStatus}`, 'success')

        const updated = pendingorders.map((c) => (c.customer_id === selectedCustomer.customer_id ? { ...c, status: newStatus } : c))
        setPendingOrders(updated)
      } else {
        Swal.fire('Error', res.message || 'Update failed', 'error')
      }
    } catch (err) {
      console.error(err)
      Swal.fire('Error', 'API request failed', 'error')
    } finally {
      setShowStatusModal(false)
    }
  }

  const Logout = () => {
    sessionStorage.clear()
    localStorage.clear()
    window.location.href = '/auth/login'
  }

  const fetchOrders = async (page) => {
    setLoading(true)
    try {
      const token = sessionStorage.getItem('access_token')

      const res = await fetchPendingOrders({
        page,
        limit: logsPerPage,
        order_id: orderId,
        recipient_name: recipientName,
        mobile: mobileNo,
        keyword: filters.keyword,
        payment_status: paymentStatus,
        paymentMethod: paymentMethod,
        date: date,
      }).unwrap()

      setPendingOrders(res.pendingorders || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
    } catch (err) {
      if (err.status === 401 || err.status === 403) {
        const refreshToken = localStorage.getItem('refresh_token')
        if (refreshToken) {
          try {
            const refreshed = await refreshtoken(refreshToken).unwrap()
            sessionStorage.setItem('access_token', refreshed.access_token)
            return fetchOrders(page)
          } catch (refreshErr) {
            console.error('Refresh failed:', refreshErr)
            Logout()
          }
        } else {
          Logout()
        }
      } else {
        console.error('Failed to fetch orders:', err)
      }
    } finally {
      setLoading(false)
    }
  }
  useEffect(() => {
    fetchOrders(1)
  }, [])

  const capitalizeFirst = (text = '') => (text ? text.charAt(0).toUpperCase() + text.slice(1) : '-')
  useEffect(() => {
    fetchOrders(currentPage)
  }, [currentPage])

  const handlePageChange = (page) => {
  if (page < 1 || page > totalPages) return
  setCurrentPage(page)
}

  const handleCancel = async (orderId) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Do you really want to cancel order ${orderId}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, cancel it!',
      cancelButtonText: 'No, keep it',
    })

    if (result.isConfirmed) {
      const user_id = sessionStorage.getItem('user_id')

      if (!user_id) {
        Swal.fire('Error', 'User not logged in. Please refresh or log in again.', 'error')
        return
      }

      try {
        const res = await cancelOrder({
          order_id: orderId,
          status: 'cancelled',
          user_id,
        }).unwrap()

        Swal.fire('Cancelled', res.message, 'success')
        fetchOrders(currentPage)
      } catch (err) {
        console.error('Cancel error:', err)
        Swal.fire('Error', 'Failed to cancel the order.', 'error')
      }
    }
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Inactive Clients
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Date</FormLabel>
                <Form.Control type="date" placeholder="Recipient Name" value={date} onChange={(e) => setDate(e.target.value)} />
              </FormGroup>
              <FormGroup className="col-md-5">
                <FormLabel>Keyword</FormLabel>
                <Select
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name, Mobile, And Email"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchOrders(1)}>
                  Search
                </Button>
              </FormGroup>
            </Form>

            <div ref={printSectionRef}>
              <Table striped className="table mb-0">
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>City</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th className="text-center no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={8} className="text-center py-4">
                        <Spinner animation="border" size="sm" role="status" className="me-2" />
                        Loading...
                      </td>
                    </tr>
                  ) : pendingorders.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center">
                        No inactive clients
                      </td>
                    </tr>
                  ) : (
                    pendingorders.map((order) => (
                      <tr key={order.customer_id}>
                        <td>{order.customer_id}</td>
                        <td>{new Date(order.created_at).toLocaleDateString()}</td>
                        <td>{capitalizeFirst(order.first_name)}</td>
                        <td>{order.contact_number_1 || '-'} </td>
                        <td>{capitalizeFirst(order.city)}</td>
                        <td>{order.email || '-'}</td>
                        <td>{order.status.charAt(0).toUpperCase() + order.status.slice(1)}</td>
                        <td className="text-end no-print">
                          <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                            <Button
                              className="d-flex align-items-center justify-content-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#5f5f5f',
                                borderColor: '#5f5f5f',
                                color: '#fff',
                                flex: 1,
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>View</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center justify-content-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#fd7e14',
                                borderColor: '#fd7e14',
                                color: '#fff',
                                flex: 1,
                              }}
                              onClick={() => handleEdit(order)}>
                              <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Edit</span>
                            </Button>

                            <Button
                              className="d-flex align-items-center justify-content-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                color: '#fff',
                                backgroundColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                borderColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                flex: 1,
                              }}
                              onClick={() => handleToggleStatus(order)}
                              title={order.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                              <IconifyIcon
                                icon={order.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                style={{ fontSize: '20px', marginRight: '4px' }}
                              />
                              <span>{order.status === 'active' ? 'Active' : 'Inactive'}</span>
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </Table>
            </div>
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  {/* FIRST */}
                  <Pagination.Item
                    disabled={currentPage === 1}
                    onClick={() => handlePageChange(1)}
                  >
                    First
                  </Pagination.Item>

                  {/* PREVIOUS */}
                  <Pagination.Prev
                    disabled={currentPage === 1}
                    onClick={() => handlePageChange(currentPage - 1)}
                  />

                  {/* PAGE NUMBERS */}
                  {(() => {
                    let pages = []

                    if (totalPages <= 5) {
                      for (let i = 1; i <= totalPages; i++) {
                        pages.push(
                          <Pagination.Item
                            key={i}
                            active={i === currentPage}
                            onClick={() => handlePageChange(i)}
                          >
                            {i}
                          </Pagination.Item>
                        )
                      }
                    } else {
                      let start = currentPage - 2
                      let end = currentPage + 2

                      if (start < 1) {
                        start = 1
                        end = 5
                      }

                      if (end > totalPages) {
                        end = totalPages
                        start = totalPages - 4
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item
                            key={i}
                            active={i === currentPage}
                            onClick={() => handlePageChange(i)}
                          >
                            {i}
                          </Pagination.Item>
                        )
                      }
                    }

                    return pages
                  })()}

                  {/* NEXT */}
                  <Pagination.Next
                    disabled={currentPage === totalPages}
                    onClick={() => handlePageChange(currentPage + 1)}
                  />

                  {/* LAST */}
                  <Pagination.Item
                    disabled={currentPage === totalPages}
                    onClick={() => handlePageChange(totalPages)}
                  >
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>
      <ViewModal showViewModal={showViewModal} handleCloseViewModal={handleCloseViewModal} viewOrder={viewOrder} />
      <EditModal showEditModal={showEditModal} handleCloseEditModal={handleCloseEditModal} editOrder={editOrder} />
      <ActiveModal
        show={showStatusModal}
        onClose={() => setShowStatusModal(false)}
        onConfirm={handleConfirmStatusChange}
        isActivating={isActivating}
      />
    </Row>
  )
}

export default InactiveClients
