'use client'
import React, { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Button, Form } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import InvoiceModal from '../invoiceModal'

const Invoices = ({ customer }) => {
  const { invoices = [] } = customer || {}

  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState(null)

  // Filters
  const [tempFilterInvoiceId, setTempFilterInvoiceId] = useState('')
  const [tempDate, setTempDate] = useState('')
  const [filterInvoiceId, setFilterInvoiceId] = useState('')
  const [date, setDate] = useState('')

  // Pagination
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10
  const maxVisible = 3

  // View invoice
  const handleView = (invoice) => {
    setSelectedOrder(invoice)
    setShowViewModal(true)
  }

  // Search
  const handleSearch = () => {
    setFilterInvoiceId(tempFilterInvoiceId)
    setDate(tempDate)
    setCurrentPage(1)
  }

  // Clear filters
  const handleClear = () => {
    setTempFilterInvoiceId('')
    setTempDate('')
    setFilterInvoiceId('')
    setDate('')
    setCurrentPage(1)
  }

  // Filter invoices
  const filteredInvoices = useMemo(() => {
    return invoices.filter((invoice) => {
      const matchId = filterInvoiceId
        ? invoice.id.toString().includes(filterInvoiceId)
        : true

      const matchDate = date
        ? new Date(invoice.created_at).toISOString().split('T')[0] === date
        : true

      return matchId && matchDate
    })
  }, [invoices, filterInvoiceId, date])

  const totalPages = Math.max(1, Math.ceil(filteredInvoices.length / itemsPerPage))

  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages)
  }, [totalPages, currentPage])

  const paginatedInvoices = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage
    return filteredInvoices.slice(start, start + itemsPerPage)
  }, [filteredInvoices, currentPage])

  // Pagination window
  const getPageWindow = () => {
    if (totalPages <= maxVisible)
      return Array.from({ length: totalPages }, (_, i) => i + 1)

    let start = currentPage - Math.floor(maxVisible / 2)
    start = Math.max(1, start)

    if (start + maxVisible - 1 > totalPages)
      start = totalPages - maxVisible + 1

    return Array.from({ length: maxVisible }, (_, i) => start + i)
  }

  return (
    <>
      <Card>
        <CardHeader>
          {/* <Row className="align-items-center">
            <Col className="d-flex justify-content-start">
              <CardTitle as="h4">Invoices</CardTitle>
            </Col>

            <Col className="d-flex justify-content-end">
            </Col>
          </Row> */}
              <Row className="mb-1 align-items-end">
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Invoice ID</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Invoice ID"
                      value={tempFilterInvoiceId}
                      onChange={(e) => setTempFilterInvoiceId(e.target.value)}
                    />
                  </Form.Group>
                </Col>

                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Date</Form.Label>
                    <Form.Control
                      type="date"
                      value={tempDate}
                      onChange={(e) => setTempDate(e.target.value)}
                    />
                  </Form.Group>
                </Col>

                <Col md={4} className="d-flex gap-2">
                  <Button variant="primary" className="flex-grow-1" onClick={handleSearch}>
                    Search
                  </Button>
                  <Button variant="secondary" onClick={handleClear}>
                    Clear
                  </Button>
                </Col>
              </Row>
        </CardHeader>

        <CardBody className="pt-0">
          <div className="table-responsive">
            <table className="table mb-0">
              <thead className="table-light">
                <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Order Status</th>
                  <th>Recipient</th>
                  <th>Payment</th>
                  <th>Total ({customer?.currency})</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {paginatedInvoices.length > 0 ? (
                  paginatedInvoices.map((invoice, idx) => (
                    <tr key={`${invoice.id}-${idx}`}>
                      <td className="py-1">{invoice.id}</td>

                      <td className="py-1">
                        {new Date(invoice.created_at).toLocaleDateString()}
                      </td>

                      <td className="py-1">
                        {invoice.order_status?.charAt(0).toUpperCase() +
                          invoice.order_status?.slice(1)}
                      </td>

                      <td className="py-1">{invoice.customer_name}</td>

                      <td
                      className="py-1"
                        style={{
                          color:
                            invoice.payment_status === 'paid'
                              ? 'green'
                              : 'red',
                        }}
                      >
                        {invoice.payment_status
                          ? invoice.payment_status.charAt(0).toUpperCase() +
                            invoice.payment_status.slice(1)
                          : '-'}
                      </td>

                      <td className="py-1">{Number(invoice.total_value).toFixed(2)}</td>

                      <td className="text-end no-print py-1">
                        <Button
                          className="d-flex align-items-center"
                          style={{
                            minWidth: 'auto',
                            padding: '0.5rem',
                            fontSize: '1rem',
                            height: '30px',
                            borderRadius: '15px',
                            backgroundColor: '#007bff',
                            borderColor: '#007bff',
                            color: '#fff',
                          }}
                          onClick={() => handleView(invoice)}
                        >
                          <Icon
                            icon="mdi:eye"
                            width={15}
                            height={20}
                            style={{ marginRight: '4px' }}
                          />
                          <span style={{ fontSize: '0.65rem' }}>View</span>
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="text-center text-muted py-3">
                      No invoices available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {filteredInvoices.length > itemsPerPage && (
            <nav aria-label="Page navigation" className="mt-3">
              <ul className="pagination justify-content-end mb-0">
                <li
                  className={`page-item ${
                    currentPage === 1 ? 'disabled' : ''
                  }`}
                >
                  <button
                    className="page-link"
                    onClick={() =>
                      setCurrentPage((p) => Math.max(1, p - 1))
                    }
                  >
                    Previous
                  </button>
                </li>

                {getPageWindow().map((page) => (
                  <li
                    key={page}
                    className={`page-item ${
                      page === currentPage ? 'active' : ''
                    }`}
                  >
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </button>
                  </li>
                ))}

                <li
                  className={`page-item ${
                    currentPage === totalPages ? 'disabled' : ''
                  }`}
                >
                  <button
                    className="page-link"
                    onClick={() =>
                      setCurrentPage((p) =>
                        Math.min(totalPages, p + 1)
                      )
                    }
                  >
                    Next
                  </button>
                </li>
              </ul>
            </nav>
          )}
        </CardBody>
      </Card>

      {/* Invoice Modal */}
      {showViewModal && (
        <InvoiceModal
          show={showViewModal}
          onClose={() => {
            setShowViewModal(false)
            setSelectedOrder(null)
          }}
          order={selectedOrder}
        />
      )}
    </>
  )
}

export default Invoices