'use client'
import React, { useState } from 'react'
import { Card, CardBody, Col, Row } from 'react-bootstrap'
import Image from 'next/image'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Link from 'next/link'
import EditModal from '../editModal'
import avatarPlaceholder from '@/assets/avatar_placeholder.jpg'

const CustomerCard = ({ customer = {} }) => {
  const {
    customer_id = '',
    first_name = '',
    last_name = '',
    email = '',
    contact_number_1 = '',
    contact_number_2 = '',
    city = '',
    picture = '',
    avatar = avatarPlaceholder,
    status = 'active',
    loyalty_point = '',
  } = customer

  const name = `${first_name} ${last_name}`.trim()
  const isActive = status?.toLowerCase() === 'active'
  const [showEditModal, setShowEditModal] = useState(false)

  const handleOpenEditModal = () => setShowEditModal(true)
  const handleCloseEditModal = () => setShowEditModal(false)

  const handleSave = (updatedData) => {
    console.log('Saved data:', updatedData)
    // Optionally update parent state via props callback
  }

  return (
    <>
      <Card style={{ height: '100%' }}>
        <CardBody>
          <Row
            style={{
              alignItems: 'center',
              flexDirection: 'column',
              textAlign: 'center',
              gap: '1rem',
            }}
            className="flex-md-row text-md-start">
            <Col md style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-start' }}>
              <div style={{ position: 'relative', display: 'flex', alignItems: 'start', gap: '1rem' }}>
                <Image
                  src={picture || avatarPlaceholder}
                  alt="avatar"
                  className="shadow-sm border"
                  style={{ borderRadius: '50%', objectFit: 'cover' }}
                  width={80}
                  height={80}
                />
                <div className="d-flex flex-column justify-content-start gap-2" style={{}}>
                  <div style={{ textAlign: 'left' }}>
                    <h5 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 'bold' }}>
                      #{customer_id || '-'} - {name ? name.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase()) : ''}
                    </h5>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'start', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <span
                      style={{
                        backgroundColor: isActive ? '#28a745' : '#dc3545',
                        color: '#fff',
                        display: 'inline-flex',
                        alignItems: 'center',
                        padding: '0.25rem 0.75rem',
                        fontSize: '0.75rem',
                        borderRadius: '50px',
                      }}>
                      <IconifyIcon
                        icon={isActive ? 'mdi:check-circle-outline' : 'mdi:alert-circle-outline'}
                        style={{ fontSize: '0.85rem', marginRight: '0.25rem' }}
                      />
                      {isActive ? 'Active' : 'Inactive'}
                    </span>

                    <span
                      style={{
                        backgroundColor: '#ffc107',
                        color: '#000',
                        display: 'inline-flex',
                        alignItems: 'center',
                        padding: '0.25rem 0.75rem',
                        fontSize: '0.75rem',
                        borderRadius: '50px',
                      }}
                      onClick={handleOpenEditModal}>
                      <IconifyIcon icon="mdi:pencil-outline" style={{ fontSize: '0.85rem', marginRight: '0.25rem' }} />
                      Edit
                    </span>
                  </div>
                </div>
              </div>
            </Col>

            {/* <Col md="auto" style={{ textAlign: 'center' }}>
              <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                <span
                  style={{
                    backgroundColor: isActive ? '#28a745' : '#dc3545',
                    color: '#fff',
                    display: 'inline-flex',
                    alignItems: 'center',
                    padding: '0.25rem 0.75rem',
                    fontSize: '0.75rem',
                    borderRadius: '50px',
                  }}>
                  <IconifyIcon
                    icon={isActive ? 'mdi:check-circle-outline' : 'mdi:alert-circle-outline'}
                    style={{ fontSize: '0.85rem', marginRight: '0.25rem' }}
                  />
                  {isActive ? 'Active' : 'Inactive'}
                </span>

                <span
                  style={{
                    backgroundColor: '#ffc107',
                    color: '#000',
                    display: 'inline-flex',
                    alignItems: 'center',
                    padding: '0.25rem 0.75rem',
                    fontSize: '0.75rem',
                    borderRadius: '50px',
                  }}
                  onClick={handleOpenEditModal}>
                  <IconifyIcon icon="mdi:pencil-outline" style={{ fontSize: '0.85rem', marginRight: '0.25rem' }} />
                  Edit
                </span>
              </div>
            </Col> */}
          </Row>

          <div style={{ marginTop: '1rem', borderTop: '1px solid #e9ecef', paddingTop: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <div className="d-flex gap-1 align-items-start">
              <IconifyIcon icon="tabler:building-community" style={{ fontSize: '1rem', color: '#6c757d' }} />
              <div className="d-flex gap-1">
                City :<span style={{ fontWeight: 600, marginRight: 4, wordBreak: 'break-word' }}>{city || '-'}</span>
              </div>
            </div>
            <div className="d-flex gap-1 align-items-start">
              <IconifyIcon icon="iconoir-mail-out" style={{ fontSize: '1rem', color: '#6c757d' }} />
              <div className="d-flex gap-1">

                <span style={{ fontWeight: 600, marginRight: 4, wordBreak: 'break-word' }}>{email}</span>
              </div>
            </div>
            <div className="d-flex gap-1 align-items-center">
              <IconifyIcon icon="iconoir-phone" style={{ fontSize: '1rem', color: '#6c757d' }} />
              <div className="d-flex gap-1">

                <span style={{ fontWeight: 600, marginRight: 4 }}>
                  {contact_number_1
                    ? contact_number_2
                      ? `${contact_number_1} / ${contact_number_2}`
                      : contact_number_1
                    : '-'}
                </span>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>
      {showEditModal && (
        <EditModal showEditModal={showEditModal} handleCloseEditModal={handleCloseEditModal} editOrder={customer} onSave={handleSave} />
      )}
    </>
  )
}

export default CustomerCard
