'use client'
import React, { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, Table } from 'react-bootstrap'
import { useGetCustomerPointsQuery } from '@/store/features/apiSlice'

const LoyaltyPointsTable = ({ customer_id, loyalty_point }) => {
  const { data, isLoading, isError } = useGetCustomerPointsQuery(customer_id)

  const [currentPage, setCurrentPage] = useState(1)

  const itemsPerPage = 15
  const maxVisible = 3

  const logs = data || []

  const totalPages = Math.ceil(logs.length / itemsPerPage)

  // Fix page if page exceeds total pages
  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages || 1)
    }
  }, [totalPages, currentPage])

  // Paginated data
  const paginatedLogs = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage
    return logs.slice(start, start + itemsPerPage)
  }, [logs, currentPage])

  // Page window
  const getPageWindow = () => {
    if (totalPages <= maxVisible) {
      return Array.from({ length: totalPages }, (_, i) => i + 1)
    }

    let start = currentPage - Math.floor(maxVisible / 2)

    start = Math.max(1, start)

    if (start + maxVisible - 1 > totalPages) {
      start = totalPages - maxVisible + 1
    }

    return Array.from({ length: maxVisible }, (_, i) => start + i)
  }

  return (
    <Card>
      <CardBody>
        <h4 className="text-warning fw-bold">Loyalty Points : {loyalty_point}</h4>

        <hr />

        {isLoading && <p>Loading points logs...</p>}

        {isError && <p>Error fetching points logs.</p>}

        {!isLoading && !isError && paginatedLogs.length > 0 && (
          <>
            <Table striped bordered hover size="md" style={{ width: 'auto' }}>
              <thead>
                <tr>
                  <th className="text-center">ID</th>
                  <th className="text-start">Date</th>
                  <th className="text-end">Prev Amount</th>
                  <th className="text-end">Adjusted Amount</th>
                  <th className="text-end">New Amount</th>
                </tr>
              </thead>

              <tbody>
                {paginatedLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="text-center">{log.id}</td>

                    <td>{new Date(log.date).toLocaleString()}</td>

                    <td className="text-end">{log.prev_amount}</td>

                    <td className="text-end">{log.adjust_amount}</td>

                    <td className="text-end">{log.new_amount}</td>
                  </tr>
                ))}
              </tbody>
            </Table>

            {logs.length > itemsPerPage && (
              <nav aria-label="Page navigation" className="mt-3">
                <ul className="pagination justify-content-start mb-0">
                  {/* Previous */}

                  <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                    <button className="page-link" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>
                      Previous
                    </button>
                  </li>

                  {/* Page numbers */}

                  {getPageWindow().map((page) => (
                    <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                      <button className="page-link" onClick={() => setCurrentPage(page)}>
                        {page}
                      </button>
                    </li>
                  ))}

                  {/* Next */}

                  <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                    <button
                      className="page-link"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}>
                      Next
                    </button>
                  </li>
                </ul>
              </nav>
            )}
          </>
        )}

        {!isLoading && !isError && logs.length === 0 && <p>No points logs found.</p>}
      </CardBody>
    </Card>
  )
}

export default LoyaltyPointsTable
