'use client'
import React, { useState } from 'react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { Card, CardBody, Col, Row } from 'react-bootstrap'

const StatCard = ({ title, value, unit, icon, variant, onClick }) => {
  return (
    <Card className="shadow-none border mb-3 mb-lg-0" onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default' }}>
      <CardBody className="p-2">
        <div className="d-flex align-items-center justify-content-between border-bottom pb-1">
          <p className="text-dark mb-0 fw-semibold fs-13">{title}</p>
          <div className="d-flex align-items-center bg-light rounded p-1">
            <IconifyIcon icon={icon} className={`fs-20 align-self-center text-${variant}`} />
          </div>
        </div>
        <div className="flex-grow-1 text-truncate">
          <h3 className="mt-1 mb-0 fs-18 fw-bold">
            {value} <span className="fs-11 text-muted fw-normal">{unit}</span>
          </h3>
        </div>
      </CardBody>
    </Card>
  )
}

const Stats = ({ customer, onLoyaltyClick, onOrdersClick }) => {
  const {
    customer_id = '',
    order_count = 0,
    returned_count = 0,
    completed_count = 0,
    pending_count = 0,
    paid_total = 0,
    unpaid_total = 0,
    cancelled_count = 0,
    loyalty_point = 0,
    first_name = '',
    last_name = '',
    currency = '',
  } = customer || {}

  const name = `${first_name} ${last_name}`.trim()

  const statData = [
    {
      title: 'Orders',
      value: order_count,
      unit: '',
      icon: 'mdi:package-variant-closed',
      variant: 'primary',
      onClick: onOrdersClick,
    },
    {
      title: 'Returned',
      value: returned_count,
      unit: '',
      icon: 'mdi:archive-refresh-outline',
      variant: 'success',
    },
    {
      title: 'Pending',
      value: pending_count,
      unit: '',
      icon: 'mdi:clock-outline',
      variant: 'success',
    },
    {
      title: 'Completed',
      value: completed_count,
      unit: '',
      icon: 'mdi:check-circle-outline',
      variant: 'success',
    },
    {
      title: 'Points',
      value: loyalty_point,
      unit: '',
      icon: 'mdi:star-outline',
      variant: 'success',
      onClick: onLoyaltyClick,
    },
    {
      title: 'Cancelled',
      value: cancelled_count,
      unit: '',
      icon: 'mdi:cancel',
      variant: 'success',
    },
    {
      title: `Paid`,
      value: `${Number(paid_total).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      unit: ` ${currency}`,
      icon: 'mdi:cash-check',
      variant: 'warning',
    },
    {
      title: `Unpaid`,
      value: `${Number(unpaid_total).toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      unit: ` ${currency}`,
      icon: 'mdi:cash-remove',
      variant: 'danger',
    },
  ]

  return (
    <Card>
      <CardBody>
        <Row className="g-2">
          {statData.map((stat, idx) => (
            <Col xs={12} sm={6} md={3} key={idx}>
              <StatCard {...stat} />
            </Col>
          ))}
        </Row>
      </CardBody>
    </Card>
  )
}

export default Stats
