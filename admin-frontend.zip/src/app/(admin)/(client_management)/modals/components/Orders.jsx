'use client'
import React, { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Button, Form, Tabs, Tab } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import View from '../../../(order_management)/pending_orders/components/view'
import Invoices from './invoices'

const Orders = ({ customer }) => {
  const { orders = [] } = customer || {}
  const [activeTab, setActiveTab] = useState('orders')
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedOrderId, setSelectedOrderId] = useState(null)

  // Filters
  const [tempFilterOrderId, setTempFilterOrderId] = useState('')
  const [tempDate, setTempDate] = useState('')
  const [filterOrderId, setFilterOrderId] = useState('')
  const [date, setDate] = useState('')

  // Pagination
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10
  const maxVisible = 3

  const handleView = (order) => {
    setSelectedOrderId(order.order_id)
    setShowViewModal(true)
  }

  const handleSearch = () => {
    setFilterOrderId(tempFilterOrderId)
    setDate(tempDate)
    setCurrentPage(1)
  }

  const handleClear = () => {
    setTempFilterOrderId('')
    setTempDate('')
    setFilterOrderId('')
    setDate('')
    setCurrentPage(1)
  }

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchId = filterOrderId ? order.order_id.toString().includes(filterOrderId) : true
      const matchDate = date ? new Date(order.created_at).toISOString().split('T')[0] === date : true
      return matchId && matchDate
    })
  }, [orders, filterOrderId, date])

  const totalPages = Math.max(1, Math.ceil(filteredOrders.length / itemsPerPage))

  // Keep page in bounds
  useEffect(() => {
    if (currentPage > totalPages) setCurrentPage(totalPages)
  }, [totalPages, currentPage])

  const paginatedOrders = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage
    return filteredOrders.slice(start, start + itemsPerPage)
  }, [filteredOrders, currentPage])

  // ---- Windowed page numbers (max 3 visible) ----
  const getPageWindow = () => {
    if (totalPages <= maxVisible) {
      return Array.from({ length: totalPages }, (_, i) => i + 1)
    }
    // Try to keep current centered when possible
    let start = currentPage - Math.floor(maxVisible / 2)
    start = Math.max(1, start)
    if (start + maxVisible - 1 > totalPages) {
      start = totalPages - maxVisible + 1
    }
    return Array.from({ length: maxVisible }, (_, i) => start + i)
  }

  return (
    <>
      <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k)} className="mb-1">
        <Tab eventKey="orders" title="Orders">
          <Card>
            <CardHeader>
              {/* <Row className="align-items-center">
            <Col className="d-flex justify-content-start">
              <CardTitle as="h4">Orders</CardTitle>
            </Col>
            <Col className="d-flex justify-content-end">
            </Col>
          </Row> */}
              <Row className="mb-1 align-items-end">
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Order ID</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Order ID"
                      value={tempFilterOrderId}
                      onChange={(e) => setTempFilterOrderId(e.target.value)}
                    />
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>Date</Form.Label>
                    <Form.Control type="date" value={tempDate} onChange={(e) => setTempDate(e.target.value)} />
                  </Form.Group>
                </Col>
                <Col md={4} className="d-flex gap-2">
                  <Button variant="primary" className='flex-grow-1' onClick={handleSearch}>
                    Search
                  </Button>
                  <Button variant="secondary" onClick={handleClear}>
                    Clear
                  </Button>
                </Col>
              </Row>
            </CardHeader>

            <CardBody className="pt-0">
              <div className="table-responsive">
                <table className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Order Status</th>
                      <th>Recipient</th>
                      <th>Address</th>
                      <th>Payment</th>
                      <th>Total ({customer?.currency})</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedOrders.length > 0 ? (
                      paginatedOrders.map((order, idx) => (
                        <tr key={`${order.order_id}-${idx}`}>
                          <td className="py-1">{order.order_id}</td>
                          <td className="py-1">{new Date(order.created_at).toLocaleDateString()}</td>
                          <td className="py-1">{order.order_status.charAt(0).toUpperCase() + order.order_status.slice(1)}</td>
                          <td className="py-1">
                            {order.recipient_name
                              .split(' ')
                              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                              .join(' ')}
                          </td>

                          <td className="py-1">{order.recipient_address}</td>
                          <td className="py-1" style={{ color: order.payment_status === 'paid' ? 'green' : 'red' }}>
                            {order.payment_status ? order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1) : '-'}
                          </td>
                          <td className="py-1">{Number(order.total_value).toFixed(2)}</td>
                          <td className="text-end no-print py-1">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.5rem',
                                fontSize: '1rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#007bff',
                                borderColor: '#007bff',
                                color: '#fff',
                              }}
                              onClick={() => handleView(order)}>
                              <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span style={{ fontSize: '0.65rem' }}>View</span>
                            </Button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="9" className="text-center text-muted py-3">
                          No orders available
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Bootstrap-like pagination with max 3 numbers */}
              {filteredOrders.length > itemsPerPage && (
                <nav aria-label="Page navigation" className="mt-3">
                  <ul className="pagination justify-content-end mb-0">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                      <button className="page-link" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>
                        Previous
                      </button>
                    </li>

                    {getPageWindow().map((page) => (
                      <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(page)}>
                          {page}
                        </button>
                      </li>
                    ))}

                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                      <button
                        className="page-link"
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}>
                        Next
                      </button>
                    </li>
                  </ul>
                </nav>
              )}
            </CardBody>
          </Card>
        </Tab>

        <Tab eventKey="invoices" title="Invoices">
          <Invoices customer={customer} />
        </Tab>
      </Tabs>

      {showViewModal && selectedOrderId && <View show={showViewModal} onClose={() => setShowViewModal(false)} order_id={selectedOrderId} />}
    </>
  )
}

export default Orders
