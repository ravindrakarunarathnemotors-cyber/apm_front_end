'use client'

import React from 'react'
import { Modal, Button } from 'react-bootstrap'
import { useUpdateClientStatusMutation } from '@/store/features/apiSlice'

const ActiveModal = ({ show, onClose, onConfirm, isActivating }) => {
  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Confirm Status Change</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        Are you sure you want to {isActivating ? 'activate' : 'deactivate'} this customer?
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          No
        </Button>
        <Button variant="primary" onClick={onConfirm}>
          Yes
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default ActiveModal
