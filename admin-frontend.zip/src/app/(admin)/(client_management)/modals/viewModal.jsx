'use client'
import React, { useState } from 'react'
import { Modal, Button, Row, Col } from 'react-bootstrap'

import CustomerCard from './components/CustomerCard'
import Stats from './components/Stats'
import Orders from './components/Orders'
import LoyaltyPointsTable from './components/LoyaltyPointsModal'

const ViewModal = ({ showViewModal, handleCloseViewModal, viewOrder }) => {
  console.log('viewOrder',viewOrder)
  const [activeSection, setActiveSection] = useState('orders')
  if (!viewOrder) return null
  const handleShowLoyalty = () => {
    setActiveSection('loyalty')
  }

  const handleShowOrders = () => {
    setActiveSection('orders')
  }

  return (
    <Modal show={showViewModal} onHide={handleCloseViewModal} fullscreen scrollable style={{ paddingLeft: '100px', paddingRight: '5px' }}>
      <Modal.Header closeButton>
        <Modal.Title>Customer / Order Details</Modal.Title>
      </Modal.Header>

      <Modal.Body className="bg-light">
        <Row className="mb-1 align-items-stretch">
          <Col md={12} lg={4}>
            <div className="h-100 d-flex flex-column">
              <CustomerCard customer={viewOrder} />
            </div>
          </Col>
          <Col md={12} lg={8}>
            <Stats customer={viewOrder} onLoyaltyClick={handleShowLoyalty} onOrdersClick={handleShowOrders} />
          </Col>
        </Row>

        {activeSection === 'orders' && (
          <Row>
            <Col lg={12}>
              <Orders customer={viewOrder} />
            </Col>
          </Row>
        )}
        {activeSection === 'loyalty' && (
          <Row>
            <Col lg={12}>
              <LoyaltyPointsTable customer_id={viewOrder.customer_id} loyalty_point={viewOrder.loyalty_point} />
            </Col>
          </Row>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseViewModal}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default ViewModal
