'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Card, CardBody, Row, Col, Form, Button } from 'react-bootstrap'
import Image from 'next/image'
import Link from 'next/link'
import Swal from 'sweetalert2'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useUpdateClientDetailsMutation } from '@/store/features/apiSlice'
import axios from 'axios'
import avatarPlaceholder from '@/assets/avatar_placeholder.jpg'

const EditModal = ({ showEditModal, handleCloseEditModal, editOrder, onSave }) => {
  const [formData, setFormData] = useState({
    customer_id: '',
    first_name: '',
    last_name: '',
    email: '',
    contact_number_1: '',
    contact_number_2: '',
    company_name: '',
    city: '',
    address: '',
    avatar: avatarPlaceholder,
    status: 'active',
    country: '',
    postal_code: '',
  })
  const [errors, setErrors] = useState({})
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadingField, setUploadingField] = useState(null)
  const [imageUploading, setImageUploading] = useState(false)

  const [updateClientDetails, { isLoading, isSuccess, isError }] = useUpdateClientDetailsMutation()

  useEffect(() => {
    if (editOrder) {
      setFormData({
        customer_id: editOrder.customer_id || '',
        first_name: editOrder.first_name || '',
        last_name: editOrder.last_name || '',
        email: editOrder.email || '',
        contact_number_1: editOrder.contact_number_1 || '',
        contact_number_2: editOrder.contact_number_2 || '-',
        company_name: editOrder.company_name || '-',
        city: editOrder.city || '',
        address: editOrder.address || '',
        avatar: editOrder.picture || avatarPlaceholder,
        status: editOrder.status || 'active',
        country: editOrder.country || '',
        postal_code: editOrder.postal_code || '',
      })
    }
  }, [editOrder])

  if (!editOrder) return null
  const sanitizeDigits = (val) => val.replace(/\D/g, '')

  // const handleChange = (e) => {
  //   const { name, value } = e.target
  //   setFormData((prev) => ({
  //     ...prev,
  //     [name]: value,
  //   }))
  // }

   const handleChange = (e) => {
    const { name, value } = e.target

    if (name === 'contact_number_1' || name === 'contact_number_2') {
      const onlyDigits = sanitizeDigits(value)
      setFormData((prev) => ({ ...prev, [name]: onlyDigits }))
      setErrors((prev) => ({ ...prev, [name]: undefined }))
      return
    }

    setFormData((prev) => ({ ...prev, [name]: value }))
    setErrors((prev) => ({ ...prev, [name]: undefined }))
  }

  const validateForm = () => {
    const newErrors = {}

    // Mobile (required): must start with 94 and be 11 digits
    if (!/^94\d{9}$/.test(formData.contact_number_1 || '')) {
      newErrors.contact_number_1 = 'Enter a valid mobile number (94XXXXXXXXX)'
    }

    if (formData.contact_number_2) {
    if (!/^94\d{9}$/.test(formData.contact_number_2)) {
      newErrors.contact_number_2 = 'Phone must be 94XXXXXXXXX (11 digits)'
    }
  }
    

     if (!formData.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    newErrors.email = 'Enter a valid email address'
  }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleImageUpload = async (file) => {
    if (!file) return

    setImageUploading(true)

    const previewURL = URL.createObjectURL(file)
    setFormData((prev) => ({
      ...prev,
      avatar: previewURL,
    }))

    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'temp-brand')

    try {
      setUploadingField('avatar')
      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          setUploadProgress(percent)
        },
      })

      const uploaded = res.data.media?.[0]
      if (!uploaded) throw new Error('Upload failed or no media returned.')

      setFormData((prev) => ({
        ...prev,
        avatar: uploaded.media_url,
      }))
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Upload Failed',
        text: err?.response?.data?.error || err.message || 'Image upload failed',
      })
    } finally {
      setUploadProgress(0)
      setUploadingField(null)
      setImageUploading(false)
    }
  }

  // const handleSave = async () => {
  //   try {
  //     const result = await updateClientDetails(formData).unwrap()

  //     console.log('Updated customer:', result.data)

  //     if (result.success) {
  //       await Swal.fire({
  //         icon: 'success',
  //         title: 'Success',
  //         text: 'Customer updated successfully',
  //         confirmButtonColor: '#3085d6',
  //       })
  //     } else {
  //       await Swal.fire({
  //         icon: 'error',
  //         title: 'Error',
  //         text: 'Update failed',
  //         confirmButtonColor: '#d33',
  //       })
  //     }
  //   } catch (err) {
  //     console.error('Update error:', err)
  //     await Swal.fire({
  //       icon: 'error',
  //       title: 'Error',
  //       text: 'Something went wrong while updating',
  //       confirmButtonColor: '#d33',
  //     })
  //   }

  //   handleCloseEditModal()
  // }

  const handleSave = async () => {
    if (!validateForm()) return

    try {
      const result = await updateClientDetails(formData).unwrap()
      if (result?.success) {
        await Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Customer updated successfully',
          confirmButtonColor: '#3085d6',
        })
        onSave?.(result?.data)
      } else {
        await Swal.fire({
          icon: 'error',
          title: 'Error',
          text: result?.message || 'Update failed',
          confirmButtonColor: '#d33',
        })
      }
    } catch (err) {
      console.error('Update error:', err)
      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Something went wrong while updating',
        confirmButtonColor: '#d33',
      })
    }

    handleCloseEditModal()
  }

  const fullName = `${formData.first_name} ${formData.last_name}`.trim()
  const isActive = formData.status?.toLowerCase() === 'active'

  return (
    <Modal show={showEditModal} onHide={handleCloseEditModal} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>Edit Customer</Modal.Title>
      </Modal.Header>
      <Modal.Body
        style={{
          border: '1px solid #ccc',
          borderRadius: '6px',
          padding: '20px',
          backgroundColor: '#fff',
          margin: '20px',
        }}>
        <Card>
          <CardBody>
            <Row className="mb-3 text-center">
              <Col>
                <div className="d-flex align-items-center flex-row flex-wrap">
                  <div className="position-relative me-3">
                    {!imageUploading ? (
                      <Image src={formData.avatar || avatarPlaceholder} alt="avatar" width={100} height={100} className="rounded-circle" />
                    ) : (
                      <div
                        className="placeholder-avatar"
                        style={{ width: '100px', height: '100px', backgroundColor: '#f0f0f0', borderRadius: '50%' }}
                      />
                    )}
                    <Link
                      href=""
                      className="thumb-md justify-content-center d-flex align-items-center bg-primary text-white rounded-circle position-absolute end-0 bottom-0 border border-3 border-card-bg"
                      onClick={(e) => {
                        e.preventDefault()
                        document.getElementById('fileInput').click()
                      }}>
                      <IconifyIcon icon="fa-solid:camera" className="fas fa-camera" />
                    </Link>
                    <input
                      id="fileInput"
                      type="file"
                      accept="image/*"
                      style={{ display: 'none' }}
                      onChange={(e) => handleImageUpload(e.target.files[0])}
                    />
                  </div>
                  <div>
                    <h5 className="fw-semibold fs-22 mb-1">{fullName}</h5>
                    <p className="mb-0 text-muted fw-medium">
                      <span
                        className={`badge bg-${isActive ? 'success' : 'danger'} text-white`}
                        style={{ borderRadius: '12px', fontSize: '0.75rem', padding: '0.4rem 0.8rem' }}>
                        {isActive ? 'Active' : 'Inactive'}
                      </span>
                    </p>
                  </div>
                </div>
              </Col>
            </Row>

            <Form>
              <Row style={{ marginBottom: '6px' }}>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>First Name</Form.Label>
                    <Form.Control
                      type="text"
                      name="first_name"
                      value={formData.first_name}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control
                      type="text"
                      name="last_name"
                      value={formData.last_name}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Row style={{ marginBottom: '6px' }}>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      isInvalid={!!errors.email}
                      placeholder="example@email.com"
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.email}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Company Name</Form.Label>
                    <Form.Control
                      type="text"
                      name="company_name"
                      value={formData.company_name}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Row style={{ marginBottom: '6px' }}>
                {/* <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Mobile Number</Form.Label>
                    <Form.Control
                      type="text"
                      name="contact_number_1"
                      value={formData.contact_number_1}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col> */}
                 <Col md={6}>
                  <Form.Group>
                    <Form.Label>Mobile Number</Form.Label>
                    <Form.Control
                      type="text"
                      inputMode="numeric"
                      maxLength={11}
                      name="contact_number_1"
                      value={formData.contact_number_1}
                      onChange={handleChange}
                      isInvalid={!!errors.contact_number_1}
                      placeholder="94XXXXXXXXX"
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.contact_number_1}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Phone Number</Form.Label>
                    <Form.Control
                      type="text"
                      inputMode="numeric"
                      maxLength={11}
                      name="contact_number_2"
                      value={formData.contact_number_2}
                      isInvalid={!!errors.contact_number_2}
                      placeholder="94XXXXXXXXX"
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.contact_number_2}
                    </Form.Control.Feedback>

                  </Form.Group>
                </Col>
              </Row>
              <Row style={{ marginBottom: '6px' }}>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Country</Form.Label>
                    <Form.Control
                      type="text"
                      name="country"
                      value={formData.country}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>City</Form.Label>
                    <Form.Control
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Row style={{ marginBottom: '6px' }}>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Postal Code</Form.Label>
                    <Form.Control
                      type="text"
                      name="postal_code"
                      value={formData.postal_code}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group style={{ marginBottom: '6px' }}>
                    <Form.Label>Address</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      name="address"
                      placeholder="Enter address"
                      value={formData.address}
                      onChange={handleChange}
                      style={{ padding: '4px 8px', fontSize: '0.85rem' }}
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Row>
                <Col className="d-flex justify-content-end" style={{ gap: '8px', marginTop: '10px' }}>
                  <Button variant="secondary" onClick={handleCloseEditModal}>
                    Close
                  </Button>
                  <Button variant="primary" onClick={handleSave}>
                    Save Changes
                  </Button>
                </Col>
              </Row>
            </Form>
          </CardBody>
        </Card>
      </Modal.Body>
    </Modal>
  )
}

export default EditModal
