import React from 'react'
import BulkPrintFixed from '../bulk_print/Bulk_PrintFixed'

function page() {
  return (
    <>
    <BulkPrintFixed/>
     
    </>
  )
}

export default page