'use client'

import React, { useRef, useState, useEffect } from 'react'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Button, Table, Pagination } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import axios from 'axios'
import Labels4x4 from '../../../(admin)/label_print_module/labels4x4'
import LabelsA4 from '../../../(admin)/label_print_module/labelsA4'

const getAccessToken = () => {
  if (typeof window === 'undefined') return null
  const vals = [
    sessionStorage.getItem('accessToken'),
    localStorage.getItem('accessToken'),
    sessionStorage.getItem('access_token'),
    localStorage.getItem('access_token'),
  ]
  return vals.find((v) => v && v !== 'null' && v !== 'undefined') || null
}

const authHeaders = () => {
  const token = getAccessToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function BulkOrderPrint() {
  const printA4Ref = useRef(null)
  const printRef4x4 = useRef(null)

  const [bulkHistory, setBulkHistory] = useState([])
  const [newBulk, setNewBulk] = useState(null)
  const [labelData, setLabelData] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [totalItems, setTotalItems] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [bulkOrdersPage, setBulkOrdersPage] = useState(1)
  const [printing, setPrinting] = useState(false)
  const ordersPerPage = 25

  // Fetch bulk history
  useEffect(() => {
    const fetchBulkHistory = async () => {
      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL
        const res = await axios.get(`${baseUrl}/delivery-management/bulk-generated-history?page=${currentPage}`, { headers: authHeaders() })
        setBulkHistory(res.data.data || [])
        setTotalPages(res.data.totalPages || 1)
        setTotalItems(res.data.totalItems || 0)
      } catch (err) {
        console.error('Error fetching bulk history:', err)
      }
    }

    const fetchLatestBulk = async () => {
      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL
        const res = await axios.get(`${baseUrl}/delivery-management/latest-bulk-print`, { headers: authHeaders() })
        if (res.data?.success && Array.isArray(res.data.orders)) {
          setNewBulk({
            bulk_id: res.data.bulk_id,
            first_name: res.data.first_name || 'Client',
            last_name: res.data.last_name || '',
            generated_at: res.data.generated_at || new Date().toISOString(),
            order_count: res.data.order_count,
            orders: res.data.orders.map((order) => ({
              order_id: order.id,
              delivery_partner_name: order.courier_partner || 'N/A',
              customer_name: order.client,
              order_status: order.status,
              tracking_id: order.tracking || 'N/A',
              created_at: order.created_at || null,
            })),
          })
          setBulkOrdersPage(1)
        }
      } catch (err) {
        console.error('Error fetching latest bulk:', err)
      }
    }

    fetchBulkHistory()
    fetchLatestBulk()
  }, [currentPage])

  // Generate new bulk
  const handleGenerate = async () => {
    try {
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL
      const res = await axios.post(`${baseUrl}/delivery-management/generate-bulk-print`, {}, { headers: authHeaders() })
      if (res.data.success && res.data.bulk_id && Array.isArray(res.data.orders)) {
        const generated = {
          bulk_id: res.data.bulk_id,
          first_name: 'Client',
          last_name: '',
          generated_at: new Date().toISOString(),
          order_count: res.data.order_count,
          orders: res.data.orders.map((order) => ({
            order_id: order.id,
            delivery_partner_name: order.courier_partner || 'N/A',
            customer_name: order.client,
            order_status: order.status,
            tracking_id: order.tracking || 'N/A',
            created_at: order.created_at || null,
          })),
        }
        setNewBulk(generated)
        localStorage.setItem('newBulk', JSON.stringify(generated))
        setBulkOrdersPage(1)
        Swal.fire('Generated', res.data.message || 'Bulk delivery labels created.', 'success')
      } else {
        Swal.fire('No Orders', res.data.message || 'No eligible orders to generate.', 'info')
      }
    } catch (err) {
      console.error(err)
      Swal.fire('Error', 'Failed to generate bulk delivery labels.', 'error')
    }
  }

  // Print logic
  const handlePrint = async (bulk_id, type = 'A4') => {
    if (!bulk_id || printing) return
    setPrinting(true)
    try {
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL
      const res = await fetch(`${baseUrl}/delivery-management/bulk-labels-by-id`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ bulk_id }),
      })
      const data = await res.json()
      const orders = data?.orders || []
      if (!orders.length) {
        Swal.fire('No Orders', 'No orders available to print.', 'info')
        setPrinting(false)
        return
      }
      setLabelData(orders)

      setTimeout(() => {
        const ref = type === 'A4' ? printA4Ref : printRef4x4
        const cloned = ref.current.cloneNode(true)

        // Convert canvas to image
        cloned.querySelectorAll('canvas').forEach((canvas) => {
          const img = document.createElement('img')
          img.src = canvas.toDataURL('image/png')
          img.style.display = 'block'
          img.style.margin = '0 auto'
          canvas.replaceWith(img)
        })

        const printWindow = window.open('', '_blank', 'width=800,height=600')
        printWindow.document.write(`
        <html>
          <head>
            <title>Print Labels</title>
            <style>
              /* General reset so images don't stretch */
              img { 
                max-width: 100%;
                height: auto !important;       /* preserve aspect ratio */
              }

              /* Common logo selectors — any that match will be constrained */
              img.logo,
              img.brand-logo,
              img.partner-logo,
              img[data-role="logo"],
              img[data-type="logo"] {
                width: auto !important;
                height: auto !important;
                max-width: 140px !important;   /* <-- adjust as you like */
                max-height: 48px !important;   /* <-- adjust as you like */
                object-fit: contain !important;
                display: inline-block;
                vertical-align: middle;
              }

              /* If your label markup wraps the logo, this prevents parent from stretching it */
              .logo-wrap, .brand-logo-wrap, .partner-logo-wrap {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                max-height: 48px;
                max-width: 140px;
                overflow: hidden;
              }

              @media print {
                body { margin:0; padding:0; box-sizing:border-box; }
                .label-page { page-break-after: always; }
                canvas { display:none !important; }
                img { display:block !important; } /* show the barcode images we injected */
              }
            </style>
          </head>
          <body>${cloned.innerHTML}</body>
        </html>
      `)

        printWindow.document.close()
        printWindow.onload = () => {
          printWindow.focus()
          printWindow.print()
          printWindow.close()
          setPrinting(false)
        }
      }, 300)
    } catch (err) {
      console.error(err)
      Swal.fire('Error', 'Failed to print labels.', 'error')
      setPrinting(false)
    }
  }

  const paginatedOrders = newBulk ? newBulk.orders.slice((bulkOrdersPage - 1) * ordersPerPage, bulkOrdersPage * ordersPerPage) : []
  const getNewBulkPageRange = () => (newBulk ? Array.from({ length: Math.ceil(newBulk.orders.length / ordersPerPage) }, (_, i) => i + 1) : [])
  const getPaginationRange = () => Array.from({ length: totalPages }, (_, i) => i + 1)

  return (
    <Row>
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <div className="d-flex justify-content-between align-items-center">
              <CardTitle as="h4" className="mb-0">
                Bulk Delivery Labels Generator
              </CardTitle>
              <Button variant="primary" onClick={handleGenerate}>
                <div className=" gap-1 px-2" style={{ display: 'flex', alignItems: 'center' }}>
                  <Icon icon="mingcute:file-new-fill" width="18" height="18" style={{ color: '#fff' }} />
                  Generate
                </div>
              </Button>
            </div>
          </CardHeader>

          <CardBody>
            {/* NEWLY GENERATED BULK */}
            {newBulk ? (
              <div className="mb-2">
                <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-0">
                  <h5 className="mb-0">Most Recent Bulk Generation #{newBulk.bulk_id}</h5>

                  <div className="d-flex flex-row gap-2">
                    <Button
                      size="sm"
                      style={{ backgroundColor: '#515151', borderColor: '#515151', color: '#fff' }}
                      onClick={() => handlePrint(newBulk.bulk_id, '4x4')}>
                      <Icon icon="mdi:printer" width="16" className="me-1" />
                      Print 4x4
                    </Button>

                    <Button
                      size="sm"
                      style={{ backgroundColor: '#515151', borderColor: '#515151', color: '#fff' }}
                      onClick={() => handlePrint(newBulk.bulk_id, 'A4')}>
                      <Icon icon="mdi:printer" width="16" className="me-1" />
                      Print A4
                    </Button>
                  </div>
                </div>
                <p className="fs-6 fw-semibold text-dark mb-0">
                  <strong>Generated by:</strong> {newBulk.first_name} {newBulk.last_name} &nbsp;|&nbsp;
                  <strong>At:</strong> {new Date(newBulk.generated_at).toLocaleString()} &nbsp;|&nbsp;
                  <strong>Orders:</strong> {newBulk.order_count}
                </p>
                <hr />

                <Table striped size="sm" className="mt-2" style={{ fontSize: '0.75rem' }}>
                  <thead className="table-light">
                    <tr>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Order ID</th>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Created At</th>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Delivery Partner</th>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Customer</th>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Status</th>
                      <th style={{ fontWeight: 'bold', padding: '6px 8px', verticalAlign: 'middle' }}>Tracking</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedOrders.map((order) => (
                      <tr key={order.order_id}>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle' }}>{order.order_id}</td>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle' }}>
                          {order.created_at ? new Date(order.created_at).toLocaleString() : 'N/A'}
                        </td>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle' }}>{order.delivery_partner_name}</td>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle', textTransform: 'capitalize' }}>{order.customer_name}</td>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle', textTransform: 'capitalize' }}>{order.order_status}</td>
                        <td style={{ padding: '4px 8px', verticalAlign: 'middle' }}>{order.tracking_id}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>

                {/* Pagination for newBulk orders */}
                {/* Pagination for newBulk orders */}
                {newBulk.orders.length > 0 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {(() => {
                        const total = Math.ceil(newBulk.orders.length / ordersPerPage)
                        const safeCurrent = Math.min(Math.max(bulkOrdersPage, 1), total)
                        const pages = []

                        let start = safeCurrent - 2
                        let end = safeCurrent + 2

                        if (total <= 5) {
                          start = 1
                          end = total
                        } else {
                          if (start < 1) {
                            start = 1
                            end = 5
                          }
                          if (end > total) {
                            end = total
                            start = total - 4
                          }
                        }

                        for (let i = start; i <= end; i++) {
                          pages.push(
                            <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setBulkOrdersPage(i)}>
                              {i}
                            </Pagination.Item>,
                          )
                        }

                        return (
                          <>
                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => setBulkOrdersPage(1)}>
                              First
                            </Pagination.Item>

                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => setBulkOrdersPage(safeCurrent - 1)}>
                              {'<'}
                            </Pagination.Item>

                            {pages}

                            <Pagination.Item disabled={safeCurrent === total} onClick={() => setBulkOrdersPage(safeCurrent + 1)}>
                              {'>'}
                            </Pagination.Item>

                            <Pagination.Item disabled={safeCurrent === total} onClick={() => setBulkOrdersPage(total)}>
                              Last
                            </Pagination.Item>
                          </>
                        )
                      })()}
                    </Pagination>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-4 text-muted">
                <p className="mb-0">No newly generated bulk found.</p>
                <small>
                  Click <strong>Generate</strong> to create a new one.
                </small>
              </div>
            )}

            {/* Bulk History */}
            <h5 className="mb-0">📦 Bulk Label Generated History</h5>
            <hr />
            {bulkHistory.length > 0 ? (
              <>
                <Table striped>
                  <thead className="table-light">
                    <tr>
                      <th>Bulk ID</th>
                      <th>Generated At</th>
                      <th>Generated By</th>
                      <th>Order Count</th>
                      <th>Print Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bulkHistory.map((bulk) => (
                      <tr key={bulk.bulk_id}>
                        <td>{bulk.bulk_id}</td>
                        <td>{new Date(bulk.generated_at).toLocaleString()}</td>
                        <td>
                          {bulk.first_name} {bulk.last_name}
                        </td>
                        <td>{bulk.order_count}</td>
                        <td>
                          <div className="d-flex flex-row gap-2">
                            <Button
                              size="sm"
                              style={{ backgroundColor: '#515151', borderColor: '#515151', color: '#fff' }}
                              onClick={() => handlePrint(bulk.bulk_id, '4x4')}>
                              <Icon icon="mdi:printer" width="16" className="me-1" /> Print 4x4
                            </Button>
                            <Button
                              size="sm"
                              style={{ backgroundColor: '#515151', borderColor: '#515151', color: '#fff' }}
                              onClick={() => handlePrint(bulk.bulk_id, 'A4')}>
                              <Icon icon="mdi:printer" width="16" className="me-1" /> Print A4
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>

                {/* Bulk History Pagination */}
                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    {(() => {
                      const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                      const pages = []

                      let start = safeCurrent - 2
                      let end = safeCurrent + 2

                      if (totalPages <= 5) {
                        start = 1
                        end = totalPages
                      } else {
                        if (start < 1) {
                          start = 1
                          end = 5
                        }
                        if (end > totalPages) {
                          end = totalPages
                          start = totalPages - 4
                        }
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setCurrentPage(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }

                      return (
                        <>
                          {/* FIRST */}
                          <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(1)}>
                            First
                          </Pagination.Item>

                          {/* PREV (<) */}
                          <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(safeCurrent - 1)}>
                            {'<'}
                          </Pagination.Item>

                          {pages}

                          {/* NEXT (>) */}
                          <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(safeCurrent + 1)}>
                            {'>'}
                          </Pagination.Item>

                          {/* LAST */}
                          <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(totalPages)}>
                            Last
                          </Pagination.Item>
                        </>
                      )
                    })()}
                  </Pagination>
                </div>
              </>
            ) : (
              <div className="text-center py-4 text-muted">
                <p className="mb-0">No bulk label history found.</p>
              </div>
            )}

            {/* Hidden print refs */}
            <div style={{ display: 'none' }}>
              <div ref={printA4Ref}>
                <LabelsA4 labelData={labelData} />
              </div>
              <div ref={printRef4x4}>
                <Labels4x4 labelData={labelData} />
              </div>
            </div>
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default BulkOrderPrint
