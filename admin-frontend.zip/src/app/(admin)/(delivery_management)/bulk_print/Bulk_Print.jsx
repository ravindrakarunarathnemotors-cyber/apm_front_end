// 'use client'

// import React, { useState, useRef, useEffect } from 'react'
// import { Row, Col, Card, CardHeader, CardBody, CardTitle, Form, FormGroup, FormLabel, FormControl, Button, Collapse, Badge } from 'react-bootstrap'
// import { Icon } from '@iconify/react'
// // import ShippingLabel from '../../(order_management)/pending_orders/components/ShippingLabel'
// import noImage from '@/assets/no-image.png' // adjust alias or path as needed

// const BulkWaybillGenerator = () => {
//   const [fromDate, setFromDate] = useState('')
//   const [fromTime, setFromTime] = useState('')
//   const [toDate, setToDate] = useState('')
//   const [toTime, setToTime] = useState('')
//   const [generated, setGenerated] = useState(false)
//   const [orderIds, setOrderIds] = useState([])
//   const [collapseOpen, setCollapseOpen] = useState(false)
//   const [labelData, setLabelData] = useState([])
//   const [printing, setPrinting] = useState(false)
//   const printRef = useRef()

//   const handleGenerate = async () => {
//     if (!fromDate || !toDate) return

//     const fromTimestamp = `${fromDate} ${fromTime || '00:00:00'}`
//     const toTimestamp = `${toDate} ${toTime || '23:59:59'}`

//     try {
//       const response = await fetch('http://localhost:5008/delivery-management/orderdetails-bulkprint', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({
//           from_time: fromTimestamp,
//           to_time: toTimestamp,
//           page: 1,
//           limit: 100,
//         }),
//       })

//       const data = await response.json()

//       if (data.success && Array.isArray(data.orders)) {
//         setOrderIds(data.orders.map((order) => order.order_details.order_id))
//         setLabelData(data.orders)
//         setGenerated(true)
//         setCollapseOpen(false)
//       } else {
//         setOrderIds([])
//         setGenerated(false)
//         alert('No orders found')
//       }
//     } catch (error) {
//       console.error('Error fetching labels:', error)
//       alert('Failed to fetch order labels')
//     }
//   }

//   const handleClear = () => {
//     setFromDate('')
//     setFromTime('')
//     setToDate('')
//     setToTime('')
//   }

//   const handlePrint = () => {
//     if (!printRef.current || printing) return
//     setPrinting(true)

//     // Clone the label container
//     const cloned = printRef.current.cloneNode(true)

//     // Convert canvas barcodes to images
//     const canvases = cloned.querySelectorAll('canvas')
//     canvases.forEach((canvas) => {
//       const img = document.createElement('img')
//       img.src = canvas.toDataURL('image/png')
//       img.style.maxWidth = '160px'
//       img.style.display = 'block'
//       canvas.replaceWith(img)
//     })

//     // Open new print window
//     const printWindow = window.open('', '_blank', 'width=800,height=600')
//     if (!printWindow) {
//       setPrinting(false)
//       return
//     }

//     const doc = printWindow.document

//     // Write entire HTML before closing
//     const labelHTML = (() => {
//       const labels = Array.from(cloned.children)
//       const pages = []

//       for (let i = 0; i < labels.length; i += 6) {
//         const pageLabels = labels
//           .slice(i, i + 6)
//           .map((el) => el.outerHTML)
//           .join('')
//         pages.push(`<div class="label-page">${pageLabels}</div>`)
//       }

//       return pages.join('')
//     })()

//     doc.write(`
// <html>
//   <head>
//     <title>Print Labels</title>
//     <style>
//       @media print {
//         body {
//           margin: 0;
//           padding: 0;
//           box-sizing: border-box;
//         }
//         .label-page {
//           display: grid;
//           grid-template-columns: repeat(2, 1fr);
//           grid-template-rows: repeat(3, 1fr);
//           gap: 8mm;
//           width: 210mm;
//           height: 297mm;
//           padding: 10mm;
//           box-sizing: border-box;
//           page-break-after: always;
//         }
//         .shipping-label-print {
//           position: relative;
//           width: 387px;
//           background: white;
//             padding: 0 10px 6px;

//           box-sizing: border-box;
//           page-break-inside: avoid;
//           border: 1px solid #333;
//           display: flex;
//           flex-direction: column;
//           justify-content: flex-start;
//           justify-content: space-between;
//           height: 85mm;
//         }
//         h5, p, li, address {
//           margin-top: 0 !important;
//           margin-bottom: 0.25rem !important;
//         }
//         canvas {
//           display: none !important;
//         }
//         canvas + .generated-barcode {
//           display: block;
//         }
//         img {
//           max-width: 100%;
//         }
//         .modal-backdrop {
//           display: none !important;
//         }
//       }
//     </style>
//   </head>
//   <body>
//     ${labelHTML}
//   </body>
// </html>
// `)

//     doc.close()

//     // Wait until styles/images are loaded before printing
//     printWindow.onload = () => {
//       printWindow.focus()
//       printWindow.print()
//       printWindow.close()
//       setPrinting(false)
//     }
//   }

//   useEffect(() => {
//     if (generated && labelData.length > 0) {
//       console.log('Labels ready to print:', labelData.length)
//     }
//   }, [generated, labelData])

//   useEffect(() => {
//     if (labelData.length > 0) {
//       labelData.forEach((order, index) => {
//         const trackingId = order?.order_details?.tracking_id || null

//         const canvas = document.getElementById(`barcode-canvas-${index}`)

//         if (canvas && trackingId) {
//           JsBarcode(canvas, trackingId.toString(), {
//             format: 'CODE128',
//             lineColor: '#000',
//             width: 2,
//             height: 40,
//             fontSize: 12,
//             displayValue: true,
//             margin: 0,
//           })

//           // ✅ Convert canvas to image for print compatibility
//           const img = document.createElement('img')
//           img.src = canvas.toDataURL('image/png')
//           img.style.maxWidth = '160px'
//           img.style.display = 'block'
//           img.className = 'generated-barcode'

//           // ✅ Insert the image after the canvas (once)
//           if (!canvas.nextSibling?.classList?.contains('generated-barcode')) {
//             canvas.parentNode.insertBefore(img, canvas.nextSibling)
//           }
//         }
//       })
//     }
//   }, [labelData])

//   return (
//     <Row className="justify-content-center">
//       <Col>
//         <Card>
//           <CardHeader className="py-2" style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
//             <CardTitle as="h4" className="mb-0">
//               Bulk Waybill Generator
//             </CardTitle>
//           </CardHeader>

//           <CardBody>
//             <Form className="row g-2 align-items-end">
//               <FormGroup className="col-md-2">
//                 <FormLabel>From Date</FormLabel>
//                 <FormControl type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
//               </FormGroup>
//               <FormGroup className="col-md-2">
//                 <FormLabel>From Time</FormLabel>
//                 <FormControl type="time" value={fromTime} onChange={(e) => setFromTime(e.target.value)} />
//               </FormGroup>
//               <FormGroup className="col-md-2">
//                 <FormLabel>To Date</FormLabel>
//                 <FormControl type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
//               </FormGroup>
//               <FormGroup className="col-md-2">
//                 <FormLabel>To Time</FormLabel>
//                 <FormControl type="time" value={toTime} onChange={(e) => setToTime(e.target.value)} />
//               </FormGroup>

//               <FormGroup className="col-md-4 d-flex justify-content-end gap-2">
//                 <Button variant="success" onClick={handleGenerate}>
//                   Generate
//                 </Button>
//                 <Button variant="outline-secondary" onClick={handleClear}>
//                   Clear
//                 </Button>
//               </FormGroup>
//             </Form>
//           </CardBody>
//         </Card>

//         {!generated && orderIds.length === 0 && (
//           <Card className="mt-3 text-center">
//             <CardBody>
//               <Icon icon="ph:funnel-light" width={28} className="text-muted mb-2" />
//               <h5 className="text-muted">Apply filters to see results</h5>
//             </CardBody>
//           </Card>
//         )}

//         {generated && (
//           <Card className="mt-3">
//             <CardHeader className="py-2" style={{ backgroundColor: '#5ec224ff' }}>
//               <CardTitle as="h5" className="mb-0">
//                 {orderIds.length} Orders Found
//               </CardTitle>
//             </CardHeader>

//             <CardBody>
//               <h6 className="fw-bold text-dark">Order IDs</h6>
//               <div className="text-dark fs-6 mb-2">
//                 From: {fromDate} {fromTime} → To: {toDate} {toTime}
//               </div>
//               <hr className="my-2" />
//               <div className="d-flex flex-wrap gap-2 mt-3 mb-2">
//                 {(collapseOpen ? orderIds : orderIds.slice(0, 10)).map((id) => (
//                   <Badge key={id} bg="secondary" pill>
//                     {id}
//                   </Badge>
//                 ))}
//               </div>
//               {orderIds.length > 10 && (
//                 <div className="mb-3">
//                   <Button variant="outline-primary" size="sm" onClick={() => setCollapseOpen(!collapseOpen)}>
//                     {collapseOpen ? 'Collapse Order IDs' : 'Show All Order IDs'}
//                   </Button>
//                 </div>
//               )}

//               <div className="d-flex justify-content-end">
//                 <Button
//                   style={{
//                     backgroundColor: '#6f42c1',
//                     borderColor: '#6f42c1',
//                     borderRadius: '15px',
//                     fontSize: '0.875rem',
//                     padding: '6px 14px',
//                     color: 'white',
//                   }}
//                   onClick={handlePrint}>
//                   <Icon icon="mdi:printer" className="me-1" width={18} />
//                   Print Labels
//                 </Button>
//               </div>
//               {/* Hidden print-only container */}
//               <div className="hidden-print-labels" style={{ display: 'none' }}>
//                 <div ref={printRef} className="shipping-label-grid">
//                   {labelData.map((order, index) => {
//                     const trackingId = order?.order_details?.tracking_id
//                     const barcodeId = `barcode-canvas-${index}`

//                     return (
//              <div className="shipping-label-print" key={index}>
//   {/* Waybill + Barcode */}
//   <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 2 }}>
//     <div style={{ flexGrow: 1 }}>
//       {trackingId ? (
//         <canvas id={barcodeId} width={160} height={40} style={{ display: 'block', marginBottom: 2 }} />
//       ) : (
//         <div style={{ fontSize: 12, fontStyle: 'italic', color: 'gray' }}>No Tracking ID Found</div>
//       )}
//     </div>
//     <div style={{ fontSize: 12, whiteSpace: 'nowrap', marginLeft: 10 }}>
//       {order?.order_details?.waybill ? (
//         <>
//           <strong>Waybill ID:</strong> {order?.order_details?.waybill}
//         </>
//       ) : (
//         <span style={{ fontStyle: 'italic', color: 'gray' }}>No Waybill ID Found</span>
//       )}
//     </div>
//   </div>

//   <hr style={{ margin: '4px 0' }} />

//   {/* Recipient Address */}
//   <div style={{ fontSize: 12 }}>
//     <strong>Recipient</strong><br />
//     {order?.recipient_address?.name || 'N/A'}<br />
//     {order?.recipient_address?.address || 'N/A'}<br />
//     {order?.recipient_address?.city || ''}<br />
//     {order?.recipient_address?.country || ''}<br />
//     Contact: {order?.recipient_contact_info?.contact || 'N/A'}
//   </div>

//   {/* COD if applicable */}
//   {String(order?.order_details?.cod).toLowerCase() === 'true' && (
//     <div style={{ fontSize: 12, textAlign: 'right', marginTop: 4 }}>
//       <strong>COD:</strong> {Number(order?.order_details?.total_value || 0).toFixed(2)}
//     </div>
//   )}

//   <hr style={{ margin: '4px 0' }} />

//   {/* From */}
//   <div style={{ fontSize: 12 }}>
//     <strong>From</strong><br />
//     {order?.customer_address?.name || 'N/A'}
//   </div>

//   {/* Partner Logo and Hotline */}
//   <div
//     style={{
//       marginTop: 'auto',
//       display: 'flex',
//       flexDirection: 'column',
//       alignItems: 'center',
//       justifyContent: 'flex-end',
//       minHeight: 60,
//     }}>
//     {typeof order?.order_details?.delivery_partner_logo === 'string' &&
//       order?.order_details?.delivery_partner_logo.trim() !== '' && (
//         <img
//           src={order?.order_details?.delivery_partner_logo}
//           alt="Partner Logo"
//           style={{ width: '120px', height: '40px', objectFit: 'contain', marginBottom: 2 }}
//           onError={(e) => {
//             e.target.onerror = null
//             e.target.remove()
//           }}
//         />
//       )}
//     <div style={{ fontSize: 11 }}>
//       <strong>Hotline:</strong> {order?.order_details?.delivery_partner_contact || 'N/A'}
//     </div>
//   </div>
// </div>

//                     )
//                   })}
//                 </div>
//               </div>
//             </CardBody>
//           </Card>
//         )}
//       </Col>

//       {/* Print Styles */}
//       {/* <style jsx global>{`
//   @media print {
//   body * {
//     visibility: hidden !important;
//   }

//   .shipping-label-grid,
//   .shipping-label-grid * {
//     visibility: visible !important;
//   }

//   .shipping-label-grid {
//     display: grid;
//     grid-template-columns: repeat(2, 1fr);
//     grid-auto-rows: auto;
//     gap: 12px;
//     padding: 16px;
//     width: 100%;
//     box-sizing: border-box;
//   }

//   .shipping-label-print {
//     background: white;
//     border: 1px solid #ccc;
//     padding: 10px;
//     font-size: 12px;
//     page-break-inside: avoid;
//   }

//   .modal-backdrop {
//     display: none !important;
//   }

//     canvas + .generated-barcode {
//     display: block;
//   }

//   canvas {
//     display: none !important;
//   }
// }

// `}</style> */}
//     </Row>
//   )
// }

// export default BulkWaybillGenerator
