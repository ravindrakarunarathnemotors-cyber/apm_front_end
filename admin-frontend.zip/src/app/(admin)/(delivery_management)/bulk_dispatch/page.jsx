import React from 'react'
import BulkDispatch from './BulkDispatch'

function page() {
  return (
    <>
    <BulkDispatch/>
     
    </>
  )
}

export default page