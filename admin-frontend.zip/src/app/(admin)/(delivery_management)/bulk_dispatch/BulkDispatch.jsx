'use client'

import React, { useState, useEffect } from 'react'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Button, Table, Form, Pagination } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import { useRouter } from 'next/navigation'
import UseLogout from '@/hooks/useLogout'
import useRefreshToken from '@/hooks/useRefreshToken'

const BulkDispatchList = () => {
  const [selectedPartner, setSelectedPartner] = useState('')
  const [selectedPartnerName, setSelectedPartnerName] = useState('')
  const [partners, setPartners] = useState([])
  const [orders, setOrders] = useState([])
  const [showTable, setShowTable] = useState(false)
  const [checkboxes, setCheckboxes] = useState({})
  const [currentPage, setCurrentPage] = useState(1)
  const ordersPerPage = 25
  const [isLoadingOrders, setIsLoadingOrders] = useState(false)

  const router = useRouter()
  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  useEffect(() => {
    const fetchPartners = async () => {
      try {

        const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/delivery-management-sub/active-delivery-partners`, {
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        })

        if (res.status === 401 || res.status === 403) {
          try {
            await refresh()
            return fetchPartners()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        }

        const data = await res.json()
        setPartners(Array.isArray(data) ? data : [])
      } catch (err) {
        console.error('Failed to fetch partners', err)
      }
    }

    fetchPartners()
  }, [])

  const paginatedOrders = orders.slice((currentPage - 1) * ordersPerPage, currentPage * ordersPerPage)

  const handleGoClick = async () => {
    const partner = partners.find((p) => Number(p.partner_id) === Number(selectedPartner))

    if (partner) {
      setSelectedPartnerName(partner.name)
      setIsLoadingOrders(true) // start loading

      try {

        const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/delivery-management-sub/partner-order-details`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ partner_id: Number(selectedPartner) }),
        })

        if (res.status === 401 || res.status === 403) {
          try {
            await refresh()
            return handleGoClick()
          } catch (refreshError) {
            console.error('Error refreshing token:', refreshError)
            Logout()
          }
        }

        const data = await res.json()
        console.log('Fetched orders data:', data)

        const ordersArray = data.orders || (Array.isArray(data) ? data : [])
        setOrders(ordersArray)

        const defaultChecks = {}
        ordersArray.forEach((o) => {
          defaultChecks[o.order_id] = true
        })
        setCheckboxes(defaultChecks)
      } catch (err) {
        console.error('Failed to fetch orders', err)
      } finally {
        setShowTable(true)
        setIsLoadingOrders(false) // stop loading
      }
    }
  }

  const handleCheckboxChange = (id) => {
    setCheckboxes((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  const handleMarkAsDispatched = async () => {
    const selected = orders.filter((o) => checkboxes[o.order_id])
    if (!selected.length) return Swal.fire('Warning', 'No orders selected.', 'warning')

    Swal.fire({
      title: 'Are you sure?',
      html: `<strong>${selected.length}</strong> orders will be marked as dispatched.`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, dispatch',
    }).then(async (result) => {
      if (result.isConfirmed) {
        const payload = {
          partner_id: Number(selectedPartner),
          order_ids: selected.map((o) => o.order_id),
        }

        try {
          

          const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/delivery-management-sub/generate-bulk-dispatch`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify(payload),
          })

          if (res.status === 401 || res.status === 403) {
            try {
              await refresh()
              return handleMarkAsDispatched()
            } catch (refreshError) {
              console.error('Error refreshing token:', refreshError)
              Logout()
            }
          }

          const data = await res.json()

          if (res.ok && data.success) {
            Swal.fire('Dispatched!', `${data.order_count} orders marked as dispatched.`, 'success').then(() => {
              router.push('/dispatch_list') // redirect
            })

            setShowTable(false)
            setOrders([])
            setCheckboxes({})
          } else {
            Swal.fire('Error', data.message || 'Failed to dispatch orders.', 'error')
          }
        } catch (err) {
          console.error('Error dispatching orders:', err)
          Swal.fire('Error', 'Something went wrong while dispatching.', 'error')
        }
      }
    })
  }

  const currentDate = new Date()
  const formattedDate = showTable
    ? `${currentDate.toLocaleDateString('en-CA')} ${currentDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    : ''

  const getPaginationRange = () => Array.from({ length: Math.ceil(orders.length / ordersPerPage) }, (_, i) => i + 1)

  return (
    <Row>
      <Col>
        <Card>
          {/* <CardHeader style={{ backgroundColor: '#e5e8ed' }}>
            <div className="d-flex justify-content-between align-items-center">
              <CardTitle className="mb-0">{selectedPartnerName ? `Dispatch to – ${selectedPartnerName}` : 'Dispatch to Courier'}</CardTitle>

              <div className="text-muted small">{formattedDate}</div>
            </div>
          </CardHeader> */}
          <CardHeader
            className="py-3 bg-light">
            <div className="d-flex justify-content-between align-items-center">
              <CardTitle as="h4" className="mb-0">
                {selectedPartnerName ? `Dispatch to – ${selectedPartnerName}` : 'Dispatch to Courier'}
              </CardTitle>

              <div className="small" style={{ color: 'inherit' }}>
                {formattedDate}
              </div>
            </div>
          </CardHeader>

          <CardBody>
            <div className="d-flex gap-2 mb-3">
              <Form.Select style={{ width: '250px' }} value={selectedPartner} onChange={(e) => setSelectedPartner(Number(e.target.value))}>
                <option value="">Select Delivery Partner</option>
                {partners.map((p) => (
                  <option key={p.partner_id} value={p.partner_id}>
                    {p.name}
                  </option>
                ))}
              </Form.Select>

              <Button variant="primary" onClick={handleGoClick} disabled={isLoadingOrders}>
                <Icon icon="mdi:send" className="me-1" width="16" /> {isLoadingOrders ? 'Loading...' : 'Go'}
              </Button>
            </div>

            <hr></hr>

            <Table striped size="sm" className="mt-2" style={{ fontSize: '0.875rem' }}>
              <thead className="table-light ">
                <tr>
                  <th style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>
                    Order ID
                  </th>
                  <th style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>
                    Order Date
                  </th>
                  <th style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>City</th>
                  <th className='text-center' style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>COD</th>
                  <th style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>
                    Client
                  </th>
                  <th style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>
                    Tracking
                  </th>
                  <th className='text-center' style={{ fontSize: '0.75rem', fontWeight: 'bold', paddingTop: '6px', paddingBottom: '6px', verticalAlign: 'middle' }}>
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {!showTable ? (
                  <tr>
                    <td colSpan="7" className="text-center text-muted py-4">
                      Select a Delivery Partner
                    </td>
                  </tr>
                ) : isLoadingOrders ? (
                  <tr>
                    <td colSpan="7" className="text-center text-muted py-4">
                      Loading orders...
                    </td>
                  </tr>
                ) : orders.length === 0 ? (
                  <tr>
                    <td colSpan="7" className="text-center text-danger fw-semibold py-4">
                      No orders found for {selectedPartnerName}
                    </td>
                  </tr>
                ) : (
                  paginatedOrders.map((order) => (
                    <tr key={order.order_id} >
                      <td>{order.order_id ?? 'N/A'}</td>
                      <td>{order.created_at ? new Date(order.created_at).toLocaleDateString() : 'N/A'}</td>
                      <td style={{ textTransform: 'capitalize' }}>{order.recipient_city || 'N/A'}</td>
                      <td className='text-end pe-3'>{order.cod ? `${Number(order.total_value).toFixed(2)} (${order.currency})` : 'N/A'}</td>

                      <td>{`${order.customer_first_name || ''} ${order.customer_last_name || ''}`.trim() || 'N/A'}</td>

                      <td>{order.tracking_id || 'N/A'}</td>

                      <td className='text-center'>
                        <Form.Check
                          type="checkbox"
                          checked={checkboxes[order.order_id] || false}
                          onChange={() => handleCheckboxChange(order.order_id)}
                          className="d-inline-block"
                        />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </Table>

            {showTable && (
              <>
                <div className="d-flex justify-content-end">
                  <Pagination>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)} />
                    {getPaginationRange().map((page) => (
                      <Pagination.Item key={page} active={page === currentPage} onClick={() => setCurrentPage(page)}>
                        {page}
                      </Pagination.Item>
                    ))}
                    <Pagination.Next disabled={currentPage === getPaginationRange().length} onClick={() => setCurrentPage(currentPage + 1)} />
                  </Pagination>
                </div>

                <div className="text-end">
                  <Button variant="dark" className="mt-3" onClick={handleMarkAsDispatched} disabled={orders.length === 0}>
                    <Icon icon="material-symbols:check-circle-outline" className="me-1" width="18" />
                    Dispatch to Courier
                  </Button>
                </div>
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default BulkDispatchList
