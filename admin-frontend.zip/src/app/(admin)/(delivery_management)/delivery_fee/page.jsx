'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Button, Table, Pagination, Form } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import AddDeliveryFee from './modal/AddDeliveryFee'
import {
  useGetDeliveryFeeMutation,
  useUpdateDeliveryFeeMutation,
  useUpdateDeliveryFeeStatusMutation,
} from '@/store/features/apiSlice'

function DeliveryFee() {
  const [fetchFilteredOrders, { isLoading, error }] = useGetDeliveryFeeMutation()
  const [updateDeliveryFee] = useUpdateDeliveryFeeMutation()
  const [updateDeliveryFeeStatus] = useUpdateDeliveryFeeStatusMutation()
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [fees, setFees] = useState([])
  const logsPerPage = 25
  const [showAddModal, setShowAddModal] = useState(false)
  const [loading, setLoading] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [editDraft, setEditDraft] = useState({ firstKg: '', addKg: '' })
  const [sellInternational, setSellInternational] = useState(false)
  const printSectionRef = useRef()
  const router = useRouter()
  const [currency, setCurrency] = useState('');

  const formatMoney = (n) => (n == null || Number.isNaN(Number(n)) ? '-' : Number(n).toFixed(2))

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredOrders({
        page,
        limit: logsPerPage,
      }).unwrap()

      const normalized = (res.fees || []).map((o) => ({
        ...o,

        fee: o.fee ?? o.price_first_kg ?? null,
        additional_fee: o.additional_fee ?? o.price_additional_kg ?? null,
        status: o.status ?? 'active',
      }))

      setFees(normalized)
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
      setSellInternational(res.sell_international)
      setCurrency(res.fees?.[0]?.currency || '');
    } catch (err) {
     
      console.error('Failed to fetch fees:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  useEffect(() => {
    if (currentPage) fetchLogs(currentPage)
  }, [currentPage])

  const startEdit = (row) => {
    setEditingId(row.id)
    setEditDraft({
      firstKg: String(row.fee ?? ''),
      addKg: String(row.additional_fee ?? ''),
    })
  }

  const cancelEdit = () => {
    setEditingId(null)
    setEditDraft({ firstKg: '', addKg: '' })
  }

  const handleDraftChange = (field, value) => {
    const cleaned = value.replace(/[^\d.]/g, '')
    setEditDraft((prev) => ({ ...prev, [field]: cleaned }))
  }

  const saveEdit = async (row) => {
    const first = parseFloat(editDraft.firstKg)
    const add = parseFloat(editDraft.addKg)

    if (Number.isNaN(first) || Number.isNaN(add)) {
      Swal.fire('Invalid values', 'Please enter valid numbers for both prices.', 'warning')
      return
    }

    const payload = {
      id: row.id,
      fee: first,
      additional_fee: add,
    }

    try {
      await updateDeliveryFee(payload).unwrap()

      setFees((prev) => prev.map((o) => (o.id === row.id ? { ...o, fee: first, additional_fee: add } : o)))

      Swal.fire({
        title: 'Updated Successfully',
        icon: 'success',
      })

      cancelEdit()
    } catch (e) {
      console.error(e)
      Swal.fire('Error', 'Failed to update delivery fee.', 'error')
    }
  }

  const handleToggleStatus = async (row) => {
    const newStatus = row.status === 'active' ? 'inactive' : 'active'

    const result = await Swal.fire({
      title: 'Confirm Status Change',
      text: `Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this customer?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true,
    })

    if (!result.isConfirmed) {
      return
    }

    try {
      await updateDeliveryFeeStatus({ id: row.id, status: newStatus }).unwrap()

      setFees((prev) => prev.map((o) => (o.id === row.id ? { ...o, status: newStatus } : o)))

      Swal.fire({
        icon: 'success',
        title: `Status changed to ${newStatus}`,
      })
    } catch (error) {
      console.error('Failed to toggle status:', error)
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to update status.',
      })
    }
  }

  const getPaginationRange = () => {
    const range = []
    for (let i = 1; i <= totalPages; i++) range.push(i)
    return range
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader
            className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Delivery Fee
            </CardTitle>
            {sellInternational && (
              <button className="btn btn-sm btn-primary" onClick={() => setShowAddModal(true)}>
                + Add
              </button>
            )}
          </CardHeader>

          <CardBody>
            {isLoading || loading ? (
              <p>Loading fees...</p>
            ) : error ? (
              <p>Error Loading fees.</p>
            ) : (
              <>
                <div ref={printSectionRef}>
                  <Table striped className="table mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Country</th>
                        <th className="text-end pe-3">Price of First Kg ({currency})</th>
                        <th className="text-end pe-3">Additional Kg ({currency})</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>

                    <tbody>
                      {fees.length === 0 ? (
                        <tr>
                          <td colSpan="6" className="text-center">
                            No Fees found.
                          </td>
                        </tr>
                      ) : (
                        fees.map((order) => {
                          const isEditing = editingId === order.id

                          return (
                            <tr key={order.id}>
                              <td>{order.id}</td>
                              <td>{order.country_name || '-'}</td>

                              <td className="text-end pe-3" style={{ minWidth: 100 }}>
                                {isEditing ? (
                                  <Form.Control
                                    size="sm"
                                    type="text"
                                    value={editDraft?.firstKg ?? ''}
                                    onChange={(e) => handleDraftChange('firstKg', e.target.value)}
                                    inputMode="decimal"
                                  />
                                ) : (
                                  formatMoney(order.fee)
                                )}
                              </td>

                              <td className="text-end pe-3" style={{ minWidth: 160 }}>
                                {isEditing ? (
                                  <Form.Control
                                    size="sm"
                                    type="text"
                                    value={editDraft?.addKg ?? ''}
                                    onChange={(e) => handleDraftChange('addKg', e.target.value)}
                                    inputMode="decimal"
                                  />
                                ) : (
                                  formatMoney(order.additional_fee)
                                )}
                              </td>

                              <td>{order.status === 'active' ? 'Active' : 'Inactive'}</td>

                              <td>
                                <div className="d-flex align-items-center gap-2">
                                  {!isEditing ? (
                                    <Button
                                      className="d-flex align-items-center"
                                      style={{
                                        minWidth: 'auto',
                                        padding: '0.3rem 0.6rem',
                                        fontSize: '0.65rem',
                                        height: '30px',
                                        borderRadius: '15px',
                                        backgroundColor: '#fd7e14',
                                        borderColor: '#fd7e14',
                                        color: '#fff',
                                      }}
                                      onClick={() => startEdit(order)}>
                                      <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: 4 }} />
                                      <span>Edit</span>
                                    </Button>
                                  ) : (
                                    <>
                                      <Button
                                        className="d-flex align-items-center"
                                        style={{
                                          minWidth: 'auto',
                                          padding: '0.3rem 0.6rem',
                                          fontSize: '0.65rem',
                                          height: '30px',
                                          borderRadius: '15px',
                                        }}
                                        onClick={() => saveEdit(order)}>
                                        <Icon icon="mdi:content-save-check" width={16} style={{ marginRight: 4 }} />
                                        <span>Update</span>
                                      </Button>

                                      <Button variant="link" className="p-0 text-muted" onClick={cancelEdit} title="Cancel">
                                        Cancel
                                      </Button>
                                    </>
                                  )}

                                  <Button
                                    className="d-flex align-items-center justify-content-center"
                                    style={{
                                      minWidth: 'auto',
                                      padding: '0.3rem 0.6rem',
                                      fontSize: '0.65rem',
                                      height: '30px',
                                      borderRadius: '15px',
                                      color: '#fff',
                                      backgroundColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                      borderColor: order.status === 'active' ? '#28a745' : '#dc3545',
                                    }}
                                    title={order.status === 'active' ? 'Set Inactive' : 'Set Active'}
                                    onClick={() => handleToggleStatus(order)}>
                                    <IconifyIcon
                                      icon={order.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                      style={{ fontSize: 20, marginRight: 4 }}
                                    />
                                    <span>{order.status === 'active' ? 'Active' : 'Inactive'}</span>
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          )
                        })
                      )}
                    </tbody>
                  </Table>
                </div>
                <AddDeliveryFee
                  show={showAddModal}
                  onClose={() => setShowAddModal(false)}
                  onAdd={(newFee) => {
                    setFees((prev) => [
                      ...prev,
                      {
                        id: Date.now(),
                        country_name: newFee.country_name,
                        fee: newFee.fee,
                        additional_fee: newFee.additional_fee,
                        status: 'active',
                      },
                    ])
                  }}
                />
                {/* <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} />
                    {getPaginationRange().map((page) => (
                      <Pagination.Item key={page} active={page === currentPage} onClick={() => setCurrentPage(page)}>
                        {page}
                      </Pagination.Item>
                    ))}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} />
                  </Pagination>
                </div> */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {/* FIRST */}
                      <Pagination.Item
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(1)}
                      >
                        First
                      </Pagination.Item>

                      {/* PREVIOUS */}
                      <Pagination.Prev
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      />

                      {/* PAGE NUMBERS (MAX 5, CENTERED) */}
                      {(() => {
                        let pages = []

                        if (totalPages <= 5) {
                          for (let i = 1; i <= totalPages; i++) {
                            pages.push(
                              <Pagination.Item
                                key={i}
                                active={i === currentPage}
                                onClick={() => setCurrentPage(i)}
                              >
                                {i}
                              </Pagination.Item>
                            )
                          }
                        } else {
                          let start = currentPage - 2
                          let end = currentPage + 2

                          if (start < 1) {
                            start = 1
                            end = 5
                          }

                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }

                          for (let i = start; i <= end; i++) {
                            pages.push(
                              <Pagination.Item
                                key={i}
                                active={i === currentPage}
                                onClick={() => setCurrentPage(i)}
                              >
                                {i}
                              </Pagination.Item>
                            )
                          }
                        }

                        return pages
                      })()}

                      {/* NEXT */}
                      <Pagination.Next
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      />

                      {/* LAST */}
                      <Pagination.Item
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(totalPages)}
                      >
                        Last
                      </Pagination.Item>
                    </Pagination>
                  </div>
                )}
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default DeliveryFee
