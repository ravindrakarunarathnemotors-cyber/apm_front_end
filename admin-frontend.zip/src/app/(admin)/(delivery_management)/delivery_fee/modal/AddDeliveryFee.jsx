'use client'

import React, { useState, useCallback } from 'react'
import { Modal, Button, Form } from 'react-bootstrap'
import Swal from 'sweetalert2'
import Select from 'react-select'
import { debounce } from 'lodash'
import { useGetCountryQuery,useAddDeliveryFeeMutation } from '@/store/features/apiSlice' 

const AddDeliveryFee = ({ show, onClose, onAdd }) => {
  const [form, setForm] = useState({
    country: '',
    fee: '',
    additional_fee: '',
  })

   const [searchCountry, setSearchCountry] = useState('')
  const [selectedCountry, setSelectedCountry] = useState(null)

  const { data: countryResults } = useGetCountryQuery(searchCountry, {
    skip: searchCountry.length < 2,
  })
 const [addDeliveryFee, { isLoading, error }] = useAddDeliveryFeeMutation()

  const debouncedSearchCountry = useCallback(
    debounce((inputValue) => {
      setSearchCountry(inputValue)
    }, 300),
    []
  )

  const countryOptions =
    countryResults?.map((country) => ({
      value: country.id,
      label: country.country_name,
    })) || []

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async () => {
    const { country, fee, additional_fee } = form
    

    const payload = {
      country_name: selectedCountry.value,   
      fee: fee,
      additional_fee: additional_fee,
    }

    console.log('Submitting payload:', payload)

    try {
    const response = await addDeliveryFee(payload).unwrap()
    console.log('Added successfully:', response)
    Swal.fire('Success', 'Delivery fee added!', 'success')
    onClose()
  } catch (err) {
    console.error('Error:', err)
    if (err?.status === 409) {
      Swal.fire('Duplicate', 'Delivery fee already exists for this country.', 'warning')
    } else {
      Swal.fire('Error', 'Failed to add delivery fee.', 'error')
    }
  }
}

  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Add Delivery Fee</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Country</Form.Label>
            <Select
              options={countryOptions}
              onInputChange={debouncedSearchCountry}
              onChange={setSelectedCountry}
              placeholder="Search country..."
              isClearable
              isSearchable
              value={selectedCountry}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Price of First Kg (Rs.)</Form.Label>
            <Form.Control
              type="number"
              name="fee"
              value={form.fee}
              onChange={handleChange}
              placeholder="Enter first kg price"
            />
          </Form.Group>

          <Form.Group>
            <Form.Label>Additional Kg (Rs.)</Form.Label>
            <Form.Control
              type="number"
              name="additional_fee"
              value={form.additional_fee}
              onChange={handleChange}
              placeholder="Enter additional kg price"
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancel
        </Button>
        <Button variant="primary" onClick={handleSubmit}>
          Add
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default AddDeliveryFee
