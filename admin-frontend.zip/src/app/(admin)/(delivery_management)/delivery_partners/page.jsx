import React from 'react'
import DeliveryOrders from '../delivery_partners/DeliveryPartners'

function page() {
  return (
    <>
    <DeliveryOrders/>
     
    </>
  )
}

export default page