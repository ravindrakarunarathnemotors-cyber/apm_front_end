'use client'

import React, { useEffect, useRef, useState } from 'react'
import { Modal, Button, Form, Row, Col } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import axios from 'axios'
import Swal from 'sweetalert2'

const DEFAULT_LOGO =
  'https://d8y1.c2.e2-9.dev/tekorasuit/Product_Media/2026-03-20/15-19-40-unnamed.jpg'

const EditDeliveryPartnerModal = ({
  show,
  onClose,
  partner,
  onSave,
}) => {
  const [formData, setFormData] = useState({
    partner_id: '',
    name: '',
    title: '',
    description: '',
    tracking_url: '',
    logo: '',
    api_status: '',
    status: '',
    type: '',
    contact_number: '',
  })

  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const fileRef = useRef(null)

  // ✅ Load selected partner data
  useEffect(() => {
    if (partner) {
      setFormData({
        partner_id: partner.partner_id || '',
        name: partner.name || '',
        title: partner.title || '',
        description: partner.description || '',
        tracking_url: partner.tracking_url || '',
        logo: partner.logo || '',
        api_status: partner.api_status || '',
        status: partner.status || '',
        type: partner.type || '',
        contact_number: partner.contact_number || '',
      })
    }
  }, [partner])

  // ✅ Handle input change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  // ✅ Open file picker
  const pickImage = () => fileRef.current?.click()

  // ✅ Upload image
  const handleImageChange = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    // preview
    const previewURL = URL.createObjectURL(file)

    setFormData((prev) => ({
      ...prev,
      logo: previewURL,
    }))

    const uploadData = new FormData()

    uploadData.append('files', file)
    uploadData.append('product_id', 'partner-logo')

    try {
      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`,
        uploadData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          onUploadProgress: (pe) => {
            if (!pe.total) return

            setUploadProgress(
              Math.round((pe.loaded * 100) / pe.total)
            )
          },
        }
      )

      const uploadedUrl = res?.data?.media?.[0]?.media_url

      if (!uploadedUrl) {
        throw new Error('Upload failed')
      }

      setFormData((prev) => ({
        ...prev,
        logo: uploadedUrl,
      }))
    } catch (err) {
      console.error(err)

      Swal.fire('Error', 'Image upload failed', 'error')

      setFormData((prev) => ({
        ...prev,
        logo: DEFAULT_LOGO,
      }))
    } finally {
      setUploading(false)
      setUploadProgress(0)

      if (fileRef.current) {
        fileRef.current.value = ''
      }
    }
  }

  // ✅ Submit update
  const handleSubmit = () => {
    onSave(formData)
  }

  return (
    <Modal
      show={show}
      onHide={onClose}
      centered
      backdrop="static"
      size="lg"
    >
      {/* HEADER */}
      <Modal.Header closeButton className="bg-dark text-white">
        <Modal.Title className="d-flex align-items-center gap-2">
          <Icon icon="mdi:pencil-outline" width={22} />
          Edit Delivery Partner
        </Modal.Title>
      </Modal.Header>

      {/* BODY */}
      <Modal.Body>
        <Form>

          {/* ✅ LOGO UPLOAD */}
          <div className="text-center mb-4">
            <div
              style={{
                width: 120,
                height: 120,
                margin: '0 auto',
                position: 'relative',
              }}
            >
              {/* IMAGE */}
              {formData.logo ? (
                <img
                  src={formData.logo}
                  alt="Logo"
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    borderRadius: 8,
                  }}
                />
              ) : (
                <div
                  style={{
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: '#f1f1f1',
                    borderRadius: 8,
                    color: '#888',
                    fontSize: 12,
                  }}
                >
                  No Image
                </div>
              )}

              {/* CAMERA BUTTON */}
              <button
                type="button"
                onClick={pickImage}
                className="btn btn-primary rounded-circle"
                style={{
                  position: 'absolute',
                  bottom: 0,
                  right: 0,
                  width: 32,
                  height: 32,
                  padding: 0,
                }}
              >
                <Icon icon="mdi:camera" width={16} />
              </button>

              {/* FILE INPUT */}
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                hidden
              />
            </div>

            {/* UPLOAD PROGRESS */}
            {uploading && (
              <div className="small mt-2">
                Uploading... {uploadProgress}%
              </div>
            )}
          </div>

          {/* FORM FIELDS */}
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Partner Name</Form.Label>

                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Title</Form.Label>

                <Form.Control
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                />
              </Form.Group>
            </Col>
          </Row>

          <Form.Group className="mb-3">
            <Form.Label>Description</Form.Label>

            <Form.Control
              as="textarea"
              rows={3}
              name="description"
              value={formData.description}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Tracking URL</Form.Label>

            <Form.Control
              type="text"
              name="tracking_url"
              value={formData.tracking_url}
              onChange={handleChange}
            />
          </Form.Group>

          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Status</Form.Label>

                <Form.Select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </Form.Select>
              </Form.Group>
            </Col>

             <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Contact Number	</Form.Label>

                <Form.Control
                  type="text"
                  name="contact_number"
                  value={formData.contact_number}
                  onChange={handleChange}
                />
              </Form.Group>
            </Col>
          </Row>

        </Form>
      </Modal.Body>

      {/* FOOTER */}
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Cancel
        </Button>

        <Button variant="primary" onClick={handleSubmit}>
          Update Partner
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default EditDeliveryPartnerModal