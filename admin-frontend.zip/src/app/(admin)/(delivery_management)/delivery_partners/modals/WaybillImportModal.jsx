'use client';
import { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import Papa from "papaparse";
import Swal from 'sweetalert2';
import { useAddedWaybillsMutation } from '@/store/features/apiSlice';

const WaybillImportModal = ({ show, onClose, partner }) => {
  const [file, setFile] = useState(null);
  const [rows, setRows] = useState([]);
  const [addWaybill] = useAddedWaybillsMutation();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile?.type === 'text/csv') {
      setFile(selectedFile);
      Papa.parse(selectedFile, {
        header: true,
        skipEmptyLines: true,
        complete: (result) => {
          setRows(result.data);
        }
      });
    } else {
      Swal.fire('Invalid File', 'Please upload a valid CSV file.', 'error');
    }
  };

 const handleUpload = async () => {
 
  try {
    const payload = {
      rows: rows.map((r) => ({
        d_partner_id: partner.partner_id,
        waybill: r.Waybill, 
        status: 'unuse', 
      })),
     
    };

    await addWaybill(payload).unwrap();
    Swal.fire('Success', 'Waybills uploaded successfully.', 'success');
    onClose(); 
  } catch (err) {
    console.error(err);
    Swal.fire('Error', 'Upload failed.', 'error');
  }
};

  

  return (
    <Modal show={show} onHide={onClose} size="md" backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>Import Waybills - {partner?.name}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Group>
          <Form.Label>Upload CSV File</Form.Label>
          <Form.Control type="file" accept=".csv" onChange={handleFileChange} />
        </Form.Group>
        {rows.length > 0 && (
          <div className="mt-3 text-success">{rows.length} rows ready for upload.</div>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button variant="primary" onClick={handleUpload} disabled={rows.length === 0}>Upload</Button>
      </Modal.Footer>
    </Modal>
  );
};

export default WaybillImportModal;
