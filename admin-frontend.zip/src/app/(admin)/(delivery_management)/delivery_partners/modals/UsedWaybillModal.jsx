'use client'
import React, { useState, useMemo, useEffect } from 'react'
import { Modal, Button, Table, Pagination, Spinner } from 'react-bootstrap'
import { useGetUsewaybillsListMutation } from '@/store/features/apiSlice'

const UsedWaybillModal = ({ show, onClose, partner }) => {
  const [fetchFilteredWaybills, { isLoading }] = useGetUsewaybillsListMutation()
  const [usewaybills, setWaybills] = useState([])
  const [totalPages, setTotalPages] = useState(1)
  const [currentPage, setCurrentPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const logsPerPage = 25
  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredWaybills({
        page,
        limit: logsPerPage,
        d_partner_id: partner?.partner_id,
      }).unwrap()

      setWaybills(res.usewaybills || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch waybills:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (show && partner?.partner_id) {
      fetchLogs(currentPage)
    }
  }, [show, currentPage, partner?.partner_id])

  useEffect(() => {
    if (show) {
      setCurrentPage(1)
    }
  }, [show, partner])

  const getPaginationRange = () => {
    const delta = 2
    const range = []

    for (let i = Math.max(1, currentPage - delta); i <= Math.min(totalPages, currentPage + delta); i++) {
      range.push(i)
    }

    return range
  }

  return (
    <Modal show={show} onHide={onClose} className="sm">
      <Modal.Header
        closeButton
        closeVariant="white"
        className="d-flex align-items-center justify-content-between"
        style={{ backgroundColor: '#6610f2' }}>
        <Modal.Title className="text-white">Used Waybills - {partner?.name}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {isLoading ? (
          <div className="text-center py-5">
            <Spinner animation="border" variant="primary" />
          </div>
        ) : (
          <>
            <Table striped bordered hover responsive className="mt-4">
              <thead className="table-light">
                <tr>
                  <th>Upload Date</th>
                  <th>Order Date</th>
                  <th>Import By</th>
                  <th>Order Id</th>
                  <th>Waybill</th>
                </tr>
              </thead>
              <tbody>
                {usewaybills.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="text-center">
                      No Used waybills found.
                    </td>
                  </tr>
                ) : (
                  usewaybills.map((wb) => (
                    <tr key={wb.id}>
                      <td>{new Date(wb.upload_date).toLocaleDateString()}</td>
                      <td>-</td>
                      <td>{wb.import_by}</td>
                      <td>{wb.order_id|| '-'}</td>
                      <td>{wb.waybill}</td>
                     
                      
                    </tr>
                  ))
                )}
              </tbody>
            </Table>
            <div className="d-flex justify-content-end mt-3">
              <Pagination>
                <Pagination.Prev disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)} />
                {getPaginationRange().map((page) => (
                  <Pagination.Item key={page} active={page === currentPage} onClick={() => setCurrentPage(page)}>
                    {page}
                  </Pagination.Item>
                ))}
                <Pagination.Next disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage + 1)} />
              </Pagination>
            </div>
          </>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default UsedWaybillModal;




