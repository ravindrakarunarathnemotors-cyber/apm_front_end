'use client'
import { useState } from 'react'
import { Card, CardBody, Col, Row, Spinner, Button, CardHeader, CardTitle } from 'react-bootstrap'
import Image from 'next/image'
import Link from 'next/link'
import { Icon } from '@iconify/react'
import { useGetDeliveryPartnersQuery, useAddedWaybillsMutation, useUpdatePartnerStatusMutation, useAddDeliveryPartnerMutation, useUpdateDeliveryPartnerMutation } from '@/store/features/apiSlice'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import ApiConfigModal from './modals/ApiConfigModal'
import UnusedWaybillModal from './modals/UnusedWaybillModal'
import UsedWaybillModal from './modals/UsedWaybillModal'
import WaybillImportModal from './modals/WaybillImportModal'
import AddDeliveryPartnerModal from './modals/AddDeliveryPartnerModal'
import EditDeliveryPartnerModal from './modals/EditDeliveryPartnerModal'
import Swal from 'sweetalert2'

const DeliveryOrders = () => {
  // const { data, isLoading, isError } = useGetDeliveryPartnersQuery()
  const { data, isLoading, isError, refetch } = useGetDeliveryPartnersQuery()

  const [updatePartnerStatus] = useUpdatePartnerStatusMutation()
  const [addDeliveryPartner] = useAddDeliveryPartnerMutation();
  const [updateDeliveryPartner] = useUpdateDeliveryPartnerMutation()
  const [addWaybill] = useAddedWaybillsMutation()
  const [showModal, setShowModal] = useState(false)
  const [selectedPartner, setSelectedPartner] = useState(null)
  const [showUnusedModal, setShowUnusedModal] = useState(false)
  const [selectedUnusedPartner, setSelectedUnusedPartner] = useState(null)
  const [showUsedModal, setShowUsedModal] = useState(false)
  const [selectedUsedPartner, setSelectedUsedPartner] = useState(null)
  const [showWaybillModal, setShowWaybillModal] = useState(false)
  const [selectedImportPartner, setSelectedImportPartner] = useState(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [Logs, setLogs] = useState([])
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedEditPartner, setSelectedEditPartner] = useState(null)

  const handleOpenUsedModal = (partner) => {
    setSelectedUsedPartner(partner)
    setShowUsedModal(true)
  }

  const handleCloseUsedModal = () => {
    setSelectedUsedPartner(null)
    setShowUsedModal(false)
  }

  const handleOpenUnusedModal = (partner) => {
    setSelectedUnusedPartner(partner)
    setShowUnusedModal(true)
  }

  const handleCloseUnusedModal = () => {
    setSelectedUnusedPartner(null)
    setShowUnusedModal(false)
  }
  const handleOpenModal = (partner) => {
    setSelectedPartner(partner)
    setShowModal(true)
  }

  const handleCloseModal = () => {
    setSelectedPartner(null)
    setShowModal(false)
  }

  const handleUpdatePartner = async (updatedData) => {
    try {
      const response = await updateDeliveryPartner(updatedData).unwrap()

      Swal.fire('Success', 'Delivery Partner Updated!', 'success')

      setShowEditModal(false)
      refetch()
    } catch (err) {
      console.error(err)

      Swal.fire('Error', 'Failed to update partner.', 'error')
    }
  }

  const handleSaveApiConfig = () => {
    Swal.fire('Success', 'Saved API Config!', 'success')
    setShowModal(false)
  }
  const handleOpenAddModal = () => setShowAddModal(true)
  const handleCloseAddModal = () => setShowAddModal(false)
  
  const handleEditPartner = (partner) => {
  setSelectedEditPartner(partner)
  setShowEditModal(true)
}

const handleCloseEditModal = () => {
  setSelectedEditPartner(null)
  setShowEditModal(false)
}

  const handleSavePartner = async (data) => {
    console.log('Sending to backend:', data); // log first

    try {
      const response = await addDeliveryPartner(data).unwrap();
      console.log('Backend response:', response);

      Swal.fire('Success', 'Delivery Partner Added!', 'success');
      setShowAddModal(false);
      refetch();
    } catch (err) {
      console.error('Error adding partner:', err);
      Swal.fire('Error', 'Failed to add partner.', 'error');
    }
  };


  const handleImportWaybill = async (partner) => {
    const result = await Swal.fire({
      title: 'Are you sure?',
      text: `This will generate new waybills for ${partner.name}.`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, Generate',
      cancelButtonText: 'No, Cancel',
      confirmButtonColor: '#007bff',
      cancelButtonColor: '#6c757d',
    })

    if (result.isConfirmed) {
      try {
        

        const payload = {
          delivery_partner_id: partner.partner_id,
          status: 'unuse',
        }

        const response = await addWaybill(payload).unwrap()

        console.log('Waybills generated:', response)
        Swal.fire('Success', 'Waybills have been generated!', 'success')
      } catch (error) {
        console.error('Waybill import failed:', error)
        Swal.fire('Error', 'Failed to generate waybills.', 'error')
      }
    }
  }

  const deliveryPartners = data?.data || []

  const handleToggleStatus = async (partner_id, currentStatus) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active'
    try {
      const response = await updatePartnerStatus({ partner_id, status: newStatus }).unwrap()
      console.log('Update success:', response)
      Swal.fire('Success', `Partner status updated to ${newStatus}`, 'success')
      refetch()
    } catch (err) {
      console.error('Failed to update status:', err)
      Swal.fire('Error', 'Failed to update partner status.', 'error')
    }
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          {/* <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Delivery Partners
            </CardTitle>
            
          </CardHeader> */}
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">

              <Col>
                <CardTitle as="h4" className="mb-0">
                  Delivery Partners
                </CardTitle>
              </Col>

              <Col xs="auto">
                <Button
                  className="bg-primary border border-primary"
                  onClick={handleOpenAddModal}
                >
                  <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                  Add Delivery Partner
                </Button>

              </Col>

            </Row>
          </CardHeader>
          <CardBody>
            {isLoading ? (
              <div className="text-center py-4">
                <Spinner animation="border" variant="primary" />
              </div>
            ) : isError ? (
              <div className="alert alert-danger text-center">Failed to load delivery partners.</div>
            ) : deliveryPartners.length === 0 ? (
              <div
                style={{
                  backgroundColor: '#f8d7da',
                  color: '#842029',
                  padding: '10px',
                  border: '1px solid #f5c2c7',
                  borderRadius: '5px',
                  textAlign: 'center',
                  fontSize: '14px',
                  margin: '10px 0',
                }}
              >
                No Delivery Partners...
              </div>
            ) : (
              <Row>
                {deliveryPartners
                  .filter((partner) => !(partner.partner_id === 1 && partner.used_count === '0' && partner.unused_count === '0'))
                  .map((partner, index) => (
                    <Col md={6} lg={6} key={index}>
                      <Card className="mb-4">
                        <CardBody className="pt-2 pb-3 px-3">
                          <div className="text-center border-dashed-bottom pb-3">
                            <div className="d-flex justify-content-between align-items-center mt-2">
                              <div className="d-flex justify-content-between align-items-center mt-2">
                                <div>
                                  <div className="d-flex align-items-center flex-wrap" style={{ gap: '6px' }}>
                                    <span className="text-dark">
                                      <h5 className="fw-bold fs-20 mb-2">{partner.name}</h5>
                                    </span>
                                  </div>
                                  <div className="d-flex align-items-center flex-wrap" style={{ gap: '6px' }}>
                                    <span className="badge rounded-pill bg-transparent border border-primary text-primary">
                                      Partner Status: {partner.status.charAt(0).toUpperCase() + partner.status.slice(1)}
                                    </span>
                                    <span
                                      className={`badge rounded-pill bg-transparent border ${partner.api_status === 'enable' ? 'border-success text-dark' : 'border-danger text-danger'
                                        }`}>
                                      API Status: {partner.api_status === 'enable' ? 'Active' : 'Inactive'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <Image src={partner.logo} alt="Plugin Logo" width={120} height={80} style={{ objectFit: 'contain', borderRadius: '8px' }} />
                            </div>
                            <p className="text-dark fs-13 fw-semibold mt-2">
                              <span className="text-muted">{partner.title}</span>
                            </p>

                            <p className="text-muted mt-3 mb-0">
                              <span className="text-muted">{partner.description}</span>
                            </p>

                            <div className="d-flex justify-content-around mt-3 gap-3 flex-wrap">
                              <div className="text-center bg-light p-3 rounded shadow-sm" style={{ flex: '1', minWidth: '120px' }}>
                                <Icon icon="material-symbols:mark-email-unread-outline" width={36} className="mb-2 text-secondary" />
                                <div className="fw-bold">Unused Waybill</div>
                                <div className="fw-bold">{partner.unused_count}</div>
                              </div>
                              <div className="text-center bg-light p-3 rounded shadow-sm" style={{ flex: '1', minWidth: '120px' }}>
                                <Icon icon="material-symbols:schedule-outline" width={36} className="mb-2 text-primary" />
                                <div className="fw-bold">Last Used Waybill</div>
                                <div className="fw-bold">0</div>
                              </div>
                              <div className="text-center bg-light p-3 rounded shadow-sm" style={{ flex: '1', minWidth: '120px' }}>
                                <Icon icon="material-symbols:mark-email-read-outline" width={36} className="mb-2 text-success" />
                                <div className="fw-bold">Used Waybill</div>
                                <div className="fw-bold">{partner.used_count}</div>
                              </div>
                            </div>
                          </div>
                          <div className="d-flex justify-content-between align-items-center mb-2">
                            <div className="d-flex flex-nowrap gap-2 mb-2">
                              <Button
                                className="d-flex align-items-center mt-3 ms-2"
                                style={{
                                  height: '36px',
                                  borderRadius: '20px',
                                  backgroundColor: '#007bff',
                                  borderColor: '#007bff',
                                  color: '#fff',
                                  padding: '0 12px',
                                  fontSize: '0.75rem',
                                }}
                                onClick={() => {
                                  setSelectedImportPartner(partner)
                                  setShowWaybillModal(true)
                                }}>
                                <Icon icon="mdi:import" width={18} height={18} style={{ marginRight: '6px' }} />
                                Import Waybill
                              </Button>
                              <Button
                                className="d-flex align-items-center mt-3"
                                style={{
                                  height: '36px',
                                  borderRadius: '20px',
                                  backgroundColor: '#6610f2',
                                  borderColor: '#6610f2',
                                  color: '#fff',
                                  padding: '0 12px',
                                  fontSize: '0.75rem',
                                }}
                                onClick={() => handleOpenUnusedModal(partner)}>
                                <Icon icon="mdi:file-eye-outline" width={18} height={18} style={{ marginRight: '6px' }} />
                                Unused Waybill
                              </Button>

                              <Button
                                className="d-flex align-items-center mt-3"
                                style={{
                                  height: '36px',
                                  borderRadius: '20px',
                                  backgroundColor: '#198754',
                                  borderColor: '#198754',
                                  color: '#fff',
                                  padding: '0 12px',
                                  fontSize: '0.75rem',
                                }}
                                onClick={() => handleOpenUsedModal(partner)}>
                                <Icon icon="mdi:check-decagram" width={18} height={18} style={{ marginRight: '6px' }} />
                                Used Waybill
                              </Button>

                              {partner.tracking_url && partner.tracking_url.startsWith('http') && (
                                <Button
                                  className="d-flex align-items-center mt-3"
                                  style={{
                                    height: '36px',
                                    borderRadius: '20px',
                                    backgroundColor: '#fd7e14',
                                    borderColor: '#fd7e14',
                                    color: '#fff',
                                    padding: '0 12px',
                                    fontSize: '0.75rem',
                                  }}
                                  onClick={() => window.open(partner.tracking_url, '_blank')}>
                                  <Icon icon="mdi:map-marker-path" width={18} height={18} style={{ marginRight: '6px' }} />
                                  Tracking
                                </Button>
                              )}
                            </div>
                          </div>
                          <div className="d-flex justify-content-between align-items-center mb-2">
                            <span
                              role="button"
                              className="d-flex align-items-center"
                              title="API Config"
                              style={{ cursor: 'pointer' }}
                              onClick={() => handleOpenModal(partner)}>
                              <IconifyIcon icon="mdi:cog-outline" style={{ fontSize: '28px' }} className="text-primary" />
                              <span className="ms-1 fw-semibold">API Config</span>
                            </span>
                            <span
                              role="button"
                              className="d-flex align-items-center"
                              title={partner.status === 'active' ? 'Active' : 'Inactive'}
                              onClick={() => handleToggleStatus(partner.partner_id, partner.status)}>
                              <IconifyIcon
                                icon={partner.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                style={{ fontSize: '50px' }}
                                className={partner.status === 'active' ? 'text-success' : 'text-danger'}
                              />
                              <span className="ms-1 fw-semibold">{partner.status.charAt(0).toUpperCase() + partner.status.slice(1)}</span>
                            </span>
                            {partner.type === 'Bulk' && (
                              <span
                                role="button"
                                className="d-flex align-items-center px-3 py-1 rounded-pill"
                                title="Edit Partner"
                                onClick={() => handleEditPartner(partner)}
                                style={{
                                  cursor: 'pointer',
                                  background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                                  color: '#fff',
                                  transition: '0.3s ease',
                                  boxShadow: '0 4px 12px rgba(99,102,241,0.25)'
                                }}
                                onMouseEnter={(e) => {
                                  e.currentTarget.style.transform = 'translateY(-2px)';
                                }}
                                onMouseLeave={(e) => {
                                  e.currentTarget.style.transform = 'translateY(0)';
                                }}
                              >
                                <IconifyIcon
                                  icon="mdi:pencil-outline"
                                  style={{ fontSize: '20px' }}
                                />

                                <span
                                  className="ms-1"
                                  style={{ fontSize: '12px', fontWeight: '200' }}
                                >
                                  Edit
                                </span>
                              </span>
                            )}
                          </div>
                          <ApiConfigModal show={showModal} onHide={handleCloseModal} partner={selectedPartner} onSave={handleSaveApiConfig} />
                          <UnusedWaybillModal show={showUnusedModal} onClose={handleCloseUnusedModal} partner={selectedUnusedPartner} />
                          <UsedWaybillModal show={showUsedModal} onClose={handleCloseUsedModal} partner={selectedUsedPartner} />
                          <WaybillImportModal show={showWaybillModal} onClose={() => setShowWaybillModal(false)} partner={selectedImportPartner} />
                          <AddDeliveryPartnerModal
                            show={showAddModal}
                            onClose={handleCloseAddModal}
                            onSave={handleSavePartner}
                          />
                          <EditDeliveryPartnerModal
                            show={showEditModal}
                            onClose={handleCloseEditModal}
                            partner={selectedEditPartner}
                            onSave={handleUpdatePartner}
                          />
                        </CardBody>
                      </Card>
                    </Col>
                  ))}
              </Row>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default DeliveryOrders
