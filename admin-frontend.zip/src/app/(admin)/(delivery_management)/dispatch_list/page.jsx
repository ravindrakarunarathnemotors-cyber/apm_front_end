import React from 'react'
import DispatchList from '../dispatch_list/DispatchList'

function page() {
  return (
    <>
    <DispatchList/>
     
    </>
  )
}

export default page