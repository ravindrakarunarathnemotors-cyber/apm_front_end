'use client'

import React, { useEffect, useState } from 'react'
import axios from 'axios'

const BulkDispatchPrint = ({ bulkId, orderCount, partnerName, onPrintComplete }) => {
  const [orders, setOrders] = useState([])
  const [brandLogo, setBrandLogo] = useState('')
  const [partnerLogo, setPartnerLogo] = useState('')

  console.log('partner name is', partnerName)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL
        const token = sessionStorage.getItem('access_token')

        const res = await axios.post(
          `${baseUrl}/delivery-management-sub/orders-by-bulk`,
          { bulk_id: bulkId },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )

        if (res.data.success) {
          setOrders(res.data.orders || [])
          setBrandLogo(res.data.brand_logo || '')
          if (res.data.orders.length > 0 && res.data.orders[0].partner_logo) {
            setPartnerLogo(res.data.orders[0].partner_logo)
          }
        }
      } catch (err) {
        console.error('Error fetching bulk dispatch orders:', err)
      }
    }

    fetchData()
  }, [bulkId])

  useEffect(() => {
    if (orders.length > 0) {
      const timer = setTimeout(() => {
        triggerPrintWindow()
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [orders])

  const now = new Date()
  const date = now.toLocaleDateString('en-CA')
  const time = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })

  const ordersPerPage = 105
  const pages = []
  for (let i = 0; i < orders.length; i += ordersPerPage) {
    const slice = orders.slice(i, i + ordersPerPage)
    while (slice.length < ordersPerPage) slice.push({ order_id: '', tracking_id: '' })
    pages.push(slice)
  }

  const getColumns = (data) => {
    const rowsPerColumn = Math.ceil(data.length / 4)
    return Array.from({ length: 4 }, (_, colIndex) => data.slice(colIndex * rowsPerColumn, (colIndex + 1) * rowsPerColumn))
  }

  const triggerPrintWindow = () => {
    const printWindow = window.open('', '_blank', 'width=800,height=1000')
    if (!printWindow) return

    const htmlContent = `
    <html>
      <head>
        <title>Bulk Dispatched List</title>
        <style>
        /* Page Setup */
        @page {
          size: A4 portrait;
          margin: 0;
        }

        /* Global Body */
        body {
          font-family: 'Segoe UI', sans-serif;
          margin: 0;
          padding: 0;
          color: #000;
        }

        /* Printable Page Container */
        .print-sheet {
          width: 210mm;
          height: 297mm;
        padding: 5mm 25mm 20mm 25mm;  /* ⬅️ reduce top padding from 10mm to 5mm */
          box-sizing: border-box;
          position: relative;
          break-after: page;
        }

        /* Header Row */
        .header {
          display: flex;
          justify-content: center;
          align-items: flex-start;
            margin-top: 10;     /* ⬅️ add this */

          margin-bottom: 2px;
          position: relative;
        }

        /* Title and Order Count */
      .dispatch-info {
        text-align: center;
        flex: none;
        margin-top: 0;   /* bring title & partner name higher */
      }


        .dispatch-info h2 {
          margin-bottom: 4px;
        }

        .dispatch-info p {
          margin: 0;
        }

        /* Date & Time Block - Aligned with brand logo */
        .timestamp-top {
          position: absolute;
          top: 10mm;
          right: 25mm;             /* ✅ aligned with right page padding */
          font-size: 12px;
          text-align: right;
          line-height: 1.4;
        }

        /* Columns Container */
        .table-layout {
          display: flex;
          justify-content: space-between;
          margin-top: 10px;
        }

        /* Each Column */
        .column {
          width: 23%;
        }

        /* Row & Header Styles */
        .table-header,
        .table-row {
          display: flex;
          justify-content: space-between;
          font-size: 12px;
          padding: 4px 0;
          border-bottom: 1px solid #ddd;
        }

        .table-header {
          font-weight: bold;
          border-bottom: 2px solid #000;
          margin-bottom: 4px;
        }

        /* Footer Signature Area */
        .footer {
          position: absolute;
          bottom: 30mm;
          left: 25mm;
          right: 25mm;
          display: flex;
          justify-content: space-between;
          font-size: 12px;
        }

        /* Brand Logo Top-Left - aligned with table left edge */
        .brand-logo {
          position: absolute;
          top: 14mm;
          left: 25mm;              /* ✅ aligned with left page padding */
          height: 40px;
        }

/* Partner Logo Right-Aligned, Slightly Higher */
.partner-logo {
  position: absolute;
  bottom: 18mm; /* ⬅️ raised from 10mm to 45mm */
  right: 25mm;  /* align with right page padding */
  height: 25px; /* smaller size */
}


      </style>


      </head>
      <body>
        ${pages
          .map((ordersChunk) => {
            const columns = getColumns(ordersChunk)
            const orderText = `${orderCount}`

            return `
            <div class="print-sheet">
              <img src="${brandLogo}" class="brand-logo" />
          <div class="timestamp-top">
            <div>${date}</div>
            <div>${time}</div>
            <div>Bulk ID: ${bulkId}</div>
            <div>Order Count: ${orderText}</div>
          </div>

              <div class="header">
                <div class="dispatch-info">
                  <h2>Bulk Dispatched List</h2>
                  <p style="margin-top: 4px;">${partnerName}</p>
                </div>
              </div>
              <hr />
              <div class="table-layout">
                ${columns
                  .map(
                    (col) => `
                  <div class="column">
                    <div class="table-header">
                      <div>Order ID</div>
                      <div>Tracking ID</div>
                    </div>
                    ${col
                      .map(
                        (row) => `
                      <div class="table-row">
                        <div>${row.order_id}</div>
                        <div>${row.tracking_id}</div>
                      </div>`,
                      )
                      .join('')}
                  </div>`,
                  )
                  .join('')}
              </div>
              <div class="footer">
                <div>
                  <strong>Handover By</strong><br />
                  <div style="height: 10px;"></div>
                  ______________________<br />
                  Generated Person
                </div>
                <div style="text-align:right">
                  <strong>Received By</strong><br />
                  <div style="height: 10px;"></div>
                  ______________________<br />
                  Simple Express
                </div>
              </div>
              ${partnerLogo ? `<img src="${partnerLogo}" class="partner-logo" />` : ''}
            </div>`
          })
          .join('')}
      </body>
    </html>`

    printWindow.document.write(htmlContent)
    printWindow.document.close()

    printWindow.onload = () => {
      printWindow.focus()
      printWindow.print()
      printWindow.close()
      onPrintComplete?.()
    }
  }

  return null
}

export default BulkDispatchPrint
