'use client'

import React, { useState, useEffect, useRef } from 'react'
import { Card, Button, Spinner } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import { useReactToPrint } from 'react-to-print'
import PrintGRN from '../grn_list/PrintGRN'

import { useApprovedPOListQuery, usePurchaseOrderDetailsQuery, useGrnReceivedSummaryQuery, useCreateGRNMutation } from '@/store/features/apiSlice'

function NewGRN() {
  const [step, setStep] = useState(1)
  const [selectedPOId, setSelectedPOId] = useState('')
  const [receivedItems, setReceivedItems] = useState([])
  const [remark, setRemark] = useState('')

  const [searchTerm, setSearchTerm] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [showDropdown, setShowDropdown] = useState(false)

  const [createGRN, { isLoading: isSaving }] = useCreateGRNMutation()
  const [printGRNId, setPrintGRNId] = useState(null)
  const printRef = useRef(null)

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: `GRN_${printGRNId}`,
    removeAfterPrint: true,
    onAfterPrint: () => setPrintGRNId(null),
  })

  useEffect(() => {
    // Reset page to fresh state
    setStep(1)
    setSelectedPOId('')
    setReceivedItems([])
    setRemark('')
    setSearchTerm('')
    setDebouncedSearch('')
  }, [])

  /* ================= 300ms DEBOUNCE ================= */
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm)
    }, 300)

    return () => clearTimeout(timer)
  }, [searchTerm])

  /* ================= BACKEND SEARCH ================= */
  const {
    data: approvedPOs = [],
    isLoading: poLoading,
    refetch: refetchApprovedPOs,
  } = useApprovedPOListQuery(debouncedSearch, {
    skip: debouncedSearch.trim().length < 1,
    refetchOnMountOrArgChange: true,
    refetchOnFocus: true,
  })
  /* ================= FETCH PO DETAILS (UNCHANGED) ================= */
  const {
    data: poDetails,
    isLoading: detailsLoading,
    refetch: refetchPODetails,
  } = usePurchaseOrderDetailsQuery(selectedPOId, {
    skip: !selectedPOId,
    refetchOnMountOrArgChange: true,
  })

  const header = poDetails?.header
  const items = poDetails?.items || []
  const currency = poDetails?.currency || '-'
  /* ================= FETCH RECEIVED SUMMARY ================= */
  const { data: receivedSummary = [], refetch: refetchSummary } = useGrnReceivedSummaryQuery(selectedPOId, {
    skip: !selectedPOId,
    refetchOnMountOrArgChange: true,
  })

  /* ================= INIT RECEIVED ITEMS ================= */
  useEffect(() => {
    if (!items.length) return

    const mapped = items.map((item) => {
      const summary = receivedSummary.find((s) => s.po_item_id === item.po_item_id)

      return {
        ...item,
        already_received: summary?.total_received_qty || 0,
        remaining_qty: summary?.remaining_qty || item.req_qty,
        received_qty: 0,
      }
    })

    setReceivedItems(mapped)
  }, [items, receivedSummary])

  /* ================= UPDATE RECEIVED QTY ================= */
  const updateReceivedQty = (index, qty) => {
    const clone = [...receivedItems]
    clone[index].received_qty = Number(qty)
    setReceivedItems(clone)
  }

  /* ================= TOTALS ================= */
  const totalReceivedQty = receivedItems.reduce((s, i) => s + Number(i.received_qty || 0), 0)

  const totalAmount = receivedItems.reduce((sum, i) => {
    const qty = Number(i.received_qty || 0)
    const unitCost = Number(i.unit_cost || 0)
    const per = Number(i.amount_per_unit || 0)

    const rowTotal = qty * unitCost
    return sum + rowTotal
  }, 0)

  /* ================= SAVE GRN ================= */ const handleSaveGRN = async () => {
    try {
      const filteredItems = receivedItems.filter((item) => Number(item.received_qty) > 0)

      if (!filteredItems.length) {
        Swal.fire({
          icon: 'warning',
          title: 'No Quantities Entered',
          text: 'Please enter at least one received quantity',
        })
        return
      }

      /* ================= CONFIRMATION SUMMARY ================= */
      const confirm = await Swal.fire({
        title: 'Confirm GRN Creation',
        html: `
        <div style="text-align:left">
          <p><strong>PO ID:</strong> ${selectedPOId}</p>
          <p><strong>Supplier:</strong> ${header?.business_name}</p>
        
          <p><strong>Total Received Qty:</strong> ${totalReceivedQty}</p>
          <p><strong>Total Amount:</strong> ${totalAmount.toFixed(2)}</p>
        </div>
      `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, Create GRN',
        cancelButtonText: 'Cancel',
      })

      if (!confirm.isConfirmed) return

      /* ================= PAYLOAD ================= */
      const payload = {
        po_id: selectedPOId,
        supplier_id: header?.supplier_id,
        remark,
        received_by: 1,
        items: filteredItems.map((item) => {
          const qty = Number(item.received_qty || 0)
          const unitCost = Number(item.unit_cost || 0)
          const per = Number(item.amount_per_unit || 0)

          const calculatedLineTotal = qty * unitCost
          return {
            po_item_id: item.po_item_id,
            product_id: item.product_id,
            variant_id: item.variant_id || null,
            batch_number: item.batch_number || null,

            ordered_qty: Number(item.req_qty),
            received_qty: qty,
            unit_cost: unitCost,

            // ✅ NEW FIELDS
            measurement_unit: item.measurement_unit ?? null,
            amount_per_unit: per || null,
            line_total: Number(calculatedLineTotal.toFixed(2)),
          }
        }),
      }

      const response = await createGRN(payload).unwrap()

      /* ================= SUCCESS MESSAGE ================= */
      const result = await Swal.fire({
        icon: 'success',
        title: 'GRN Created Successfully',
        html: `
    <div style="text-align:left">
      <p><strong>GRN ID:</strong> ${response.grn_id}</p>
      <p><strong>PO ID:</strong> ${selectedPOId}</p>
      <p><strong>Total Qty:</strong> ${totalReceivedQty}</p>
      <p><strong>Total Amount:</strong> ${totalAmount.toFixed(2)}</p>
    </div>
  `,
        showCancelButton: true,
        confirmButtonText: 'Print GRN',
        cancelButtonText: 'Close',
      })

      if (result.isConfirmed) {
        setPrintGRNId(response.grn_id)
      }

      /* ================= RESET ================= */
      setStep(1)
      setSelectedPOId('')
      setReceivedItems([])
      setRemark('')
      setSearchTerm('')
      setDebouncedSearch('')
    } catch (err) {
      console.error('GRN Save Error:', err)

      Swal.fire({
        icon: 'error',
        title: 'Error Creating GRN',
        text: err?.data?.message || 'Something went wrong',
      })
    }
  }

  const formatQtyWithUnit = (qty, unit) => {
    const formattedQty = Number(qty || 0).toLocaleString()

    // Hide unit if it's pcs
    if (!unit || unit.toLowerCase() === 'pcs') {
      return formattedQty
    }

    return `${formattedQty} ${unit}`
  }

  return (
    <div className="container-fluid p-4">
      <Card className="shadow border-0">
        <Card.Header className="bg-dark text-white d-flex align-items-center gap-2">
          {step === 2 && (
            <Button size="sm" variant="outline-light" onClick={() => setStep(1)}>
              <Icon icon="mdi:arrow-left" />
            </Button>
          )}
          <h5 className="mb-0">New Goods Received Note (GRN)</h5>
        </Card.Header>

        <Card.Body>
          {/* ================= STEP 1 ================= */}
          {step === 1 && (
            <>
              <div className="row g-3">
                <div className="col-md-6 position-relative">
                  <label className="form-label fw-semibold">Select Approved Purchase Order</label>

                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search PO ID or Supplier..."
                    value={searchTerm}
                    onFocus={() => setShowDropdown(true)}
                    onChange={(e) => {
                      setSearchTerm(e.target.value)
                      setShowDropdown(true)
                    }}
                  />

                  {showDropdown && debouncedSearch && (
                    <div className="list-group position-absolute w-100 shadow" style={{ zIndex: 1000, maxHeight: 250, overflowY: 'auto' }}>
                      {poLoading && <div className="list-group-item text-muted">Searching...</div>}

                      {!poLoading && approvedPOs.length === 0 && <div className="list-group-item text-muted">No Purchase Orders Found</div>}

                      {approvedPOs.map((po) => (
                        <button
                          type="button"
                          key={po.po_id}
                          className="list-group-item list-group-item-action"
                          onClick={() => {
                            setSelectedPOId(po.po_id)
                            setSearchTerm(`PO #${po.po_id} - ${po.business_name}`)
                            setShowDropdown(false)
                          }}>
                          <strong>PO #{po.po_id}</strong> - {po.business_name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {selectedPOId && (
                <div className="mt-4">
                  {detailsLoading ? (
                    <Spinner />
                  ) : (
                    header && (
                      <div className="border rounded p-4 bg-light">
                        <h6>Supplier: {header.business_name}</h6>
                        <div>Total PO Qty: {header.po_qty}</div>
                      </div>
                    )
                  )}

                  <div className="text-end mt-3">
                    <Button variant="primary" disabled={!header} onClick={() => setStep(2)}>
                      Go → Add GRN Items
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* ================= STEP 2 (UNCHANGED) ================= */}
          {step === 2 && (
            <>
              <h5 className="mb-3">GRN Items for PO #{selectedPOId}</h5>

              <div className="table-responsive">
                <table className="table table-bordered align-middle">
                  <thead className="table-dark">
                    <tr>
                      <th>#</th>
                      <th>Product</th>
                      <th>Ordered</th>
                      <th>Previously Received</th>
                      <th>Remaining</th>
                      <th>Received</th>
                      <th>Unit Cost ({currency})</th>
                    </tr>
                  </thead>
                  <tbody>
                    {receivedItems.map((item, index) => (
                      <tr key={item.po_item_id}>
                        <td>{index + 1}</td>
                        <td>
                          <div className="fw-semibold">{item.product_title}</div>

                          {item.variant_id && (
                            <div className="text-muted small">
                              #{item.variant_id} {item.variant_value || ''}
                            </div>
                          )}
                        </td>
                        <td>{formatQtyWithUnit(item.req_qty)}</td>
                        <td>{formatQtyWithUnit(item.already_received)}</td>
                        <td>{formatQtyWithUnit(item.remaining_qty)}</td>
                        <td>
                          <input
                            type="number"
                            max={item.remaining_qty}
                            min={0}
                            className="form-control"
                            value={item.received_qty}
                            onChange={(e) => updateReceivedQty(index, e.target.value)}
                          />
                        </td>
                        <td>
                          {Number(item.unit_cost).toFixed(2)}
                          {item.amount_per_unit && item.measurement_value && item.measurement_value.toLowerCase() !== 'pcs'
                            ? ` Per ${Number(item.amount_per_unit)} ${item.measurement_value}`
                            : ''}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* TOTALS SECTION */}
              <div className="mt-4 d-flex justify-content-end">
                <div style={{ minWidth: 300 }}>
                  {/* <div className="d-flex justify-content-between border-top pt-2">
      <strong>Total Items:</strong>
      <span>{receivedItems.length}</span>
    </div> */}

                  <div className="d-flex justify-content-between border-top pt-2">
                    <strong>Total Qty:</strong>
                    <span>{Number(totalReceivedQty).toLocaleString()}</span>
                  </div>

                  <div className="d-flex justify-content-between border-top pt-2">
                    <strong>Grand Total:</strong>
                    <strong>
                      {currency} {totalAmount.toFixed(2)}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <label className="form-label">GRN Remark</label>
                <textarea rows={3} className="form-control" value={remark} onChange={(e) => setRemark(e.target.value)} />
              </div>

              <div className="mt-4 text-end">
                <Button variant="success" onClick={handleSaveGRN} disabled={isSaving}>
                  {isSaving ? 'Saving...' : 'Save GRN'}
                </Button>
              </div>
            </>
          )}
        </Card.Body>
      </Card>
      {printGRNId && (
        <div style={{ display: 'none' }}>
          <PrintGRN ref={printRef} grnId={printGRNId} onReady={handlePrint} />
        </div>
      )}
    </div>
  )
}

export default NewGRN
