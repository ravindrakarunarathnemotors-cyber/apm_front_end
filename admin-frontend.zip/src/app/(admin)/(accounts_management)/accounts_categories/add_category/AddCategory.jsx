'use client'

import React, { useState } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Form, Button, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'

// ✅ RTK Hook Import
import { useAddAccountCategoryMutation } from '@/store/features/apiSlice'

//  import CategoryList
import CategoryList from '../category_list/CategoryList'

function AddCategory() {
  const [formData, setFormData] = useState({
    name: '',
    note: '',
  })

  const [errors, setErrors] = useState({})
  const [isSaving, setIsSaving] = useState(false)

  // ✅ RTK Mutation Hook
  const [addAccountCategory] = useAddAccountCategoryMutation()

  const handleChange = (e) => {
    const { name, value } = e.target

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    setErrors((prev) => ({
      ...prev,
      [name]: '',
    }))
  }

  const validate = () => {
    let newErrors = {}

    if (!formData.name.trim()) newErrors.name = 'Category name is required'

    setErrors(newErrors)

    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validate()) return

    const confirm = await Swal.fire({
      title: 'Account Category Summary',
      html: `
        <div style="text-align:left">
          <p><strong>Name:</strong><br>${formData.name}</p>
          <p><strong>Note:</strong><br>${formData.note || '-'}</p>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Confirm & Save',
      confirmButtonColor: '#0d6efd',
    })

    if (!confirm.isConfirmed) return

    try {
      setIsSaving(true)

      // ✅ REAL API CALL
      const response = await addAccountCategory({
        name: formData.name.trim(),
        note: formData.note?.trim() || null,
      }).unwrap()

      await Swal.fire({
        icon: 'success',
        title: 'Account Category Added Successfully!',
      })

      // Reset form
      setFormData({
        name: '',
        note: '',
      })

      setErrors({})
    } catch (error) {
      console.error('Save Error:', error)

      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error?.data?.message || 'Failed to save category. Please try again.',
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleReset = () => {
    setFormData({
      name: '',
      note: '',
    })

    setErrors({})
  }

  return (
    <>
      {/* Form Card */}
      <Card className="shadow-sm mb-4">
        <CardHeader className="py-3 bg-light">
          <CardTitle className="mb-0">Add New Account Category</CardTitle>
        </CardHeader>

        <CardBody>
          <Form onSubmit={handleSubmit}>
            <Row className="mb-3">
              <Col md={6}>
                <Form.Label>Category Name *</Form.Label>

                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  isInvalid={!!errors.name}
                  placeholder="Enter category name"
                />

                <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
              </Col>
            </Row>

            <Row className="mb-3">
              <Col md={6}>
                <Form.Label>
                  Note <span className="text-muted">(Optional)</span>
                </Form.Label>

                <Form.Control as="textarea" rows={2} name="note" value={formData.note} onChange={handleChange} placeholder="Enter note" />
              </Col>
            </Row>

            <div className="d-flex justify-content-end gap-2">
              <Button variant="secondary" type="button" onClick={handleReset} disabled={isSaving}>
                Reset
              </Button>

              <Button variant="primary" type="submit" disabled={isSaving}>
                {isSaving ? 'Saving...' : 'Save Category'}
              </Button>
            </div>
          </Form>
        </CardBody>
      </Card>

      {/* ✅ Category List rendered here */}
      <CategoryList />
    </>
  )
}

export default AddCategory
