'use client'

import React, { useState } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Form, Row, Col, Table, Button, Spinner, Modal } from 'react-bootstrap'
import Swal from 'sweetalert2'
import Select from 'react-select'
import { Icon } from '@iconify/react'
import PaginationComponent from '@/components/Pagination'

// ✅ RTK Hooks
import { useGetAccountCategoriesQuery, useUpdateAccountCategoryStatusMutation, useUpdateAccountCategoryMutation } from '@/store/features/apiSlice'

const statusOptions = [
  { value: '', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
]

function CategoryList() {
  const [filters, setFilters] = useState({
    name: '',
    status: '',
    fromDate: '',
    toDate: '',
  })

  const [currentPage, setCurrentPage] = useState(1)
  const [isSearched, setIsSearched] = useState(false)
  const [searchParams, setSearchParams] = useState({})

  // ✅ Edit Modal States
  const [showEditModal, setShowEditModal] = useState(false)
  const [editData, setEditData] = useState({
    category_id: null,
    name: '',
    note: '',
    status: 'active',
  })

  const pageSize = 25

  const { data, isLoading, isFetching } = useGetAccountCategoriesQuery({
    page: currentPage,
    limit: pageSize,
    ...searchParams,
  })

  const [updateAccountCategoryStatus] = useUpdateAccountCategoryStatusMutation()

  const [updateAccountCategory, { isLoading: isUpdating }] = useUpdateAccountCategoryMutation()

  const categories = data?.data || []
  const totalPages = data?.pagination?.totalPages || 1


  const totalEntries = data?.pagination?.totalRecords || 0

  const limit = data?.pagination?.limit || pageSize

  const isFilterApplied = Boolean(filters.name || filters.status || filters.fromDate || filters.toDate)

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({ ...prev, [field]: value }))
  }

  const handleSearch = () => {
    if (!isFilterApplied) return

    setSearchParams({
      name: filters.name || undefined,
      status: filters.status || undefined,
      from_date: filters.fromDate || undefined,
      to_date: filters.toDate || undefined,
    })

    setCurrentPage(1)
    setIsSearched(true)
  }

  const resetFilters = () => {
    setFilters({
      name: '',
      status: '',
      fromDate: '',
      toDate: '',
    })
    setSearchParams({})
    setCurrentPage(1)
    setIsSearched(false)
  }

  // ================= STATUS TOGGLE =================
  const handleStatusToggle = async (cat) => {
    const newStatus = cat.status === 'active' ? 'inactive' : 'active'

    const result = await Swal.fire({
      title: 'Confirm Status Change',
      html: `
        <div style="text-align:left">
          <p><strong>Category:</strong><br>${cat.name}</p>
          <p><strong>New Status:</strong> ${newStatus === 'active' ? 'Active' : 'Inactive'}</p>
        </div>
      `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Update',
      confirmButtonColor: newStatus === 'active' ? '#198754' : '#dc3545',
    })

    if (!result.isConfirmed) return

    try {
      await updateAccountCategoryStatus({
        category_id: cat.category_id,
        status: newStatus,
      }).unwrap()

      Swal.fire({
        icon: 'success',
        title: 'Status Updated',
        timer: 1500,
        showConfirmButton: false,
      })
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error?.data?.message || 'Failed to update status',
      })
    }
  }

  // ================= EDIT =================
  const handleEdit = (cat) => {
    setEditData({
      category_id: cat.category_id,
      name: cat.name,
      note: cat.note || '',
      status: cat.status,
    })
    setShowEditModal(true)
  }

  const handleUpdateCategory = async () => {
    if (!editData.name.trim()) {
      Swal.fire({
        icon: 'warning',
        title: 'Validation Error',
        text: 'Category name is required',
      })
      return
    }

    const confirm = await Swal.fire({
      title: 'Confirm Update',
      html: `
        <div style="text-align:left">
          <p><strong>Name:</strong><br>${editData.name}</p>
          <p><strong>Note:</strong><br>${editData.note || '-'}</p>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Update',
      confirmButtonColor: '#0d6efd',
    })

    if (!confirm.isConfirmed) return

    try {
      await updateAccountCategory({
        category_id: editData.category_id,
        name: editData.name.trim(),
        note: editData.note || null,
        status: editData.status,
      }).unwrap()

      setShowEditModal(false)

      Swal.fire({
        icon: 'success',
        title: 'Category Updated Successfully',
        timer: 1500,
        showConfirmButton: false,
      })
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error?.data?.message || 'Failed to update category',
      })
    }
  }

  return (
    <>
      <Card className="shadow-sm mb-4">
        <CardHeader className="py-3 bg-light">
          <CardTitle className="mb-0">Account Category List</CardTitle>
        </CardHeader>

        <CardBody>
          {/* Filters (UNCHANGED) */}
          <Form className="mb-4">
            <Row className="align-items-end g-3">
              <Col md={3}>
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  value={filters.name}
                  placeholder="Search by name"
                  onChange={(e) => handleFilterChange('name', e.target.value)}
                />
              </Col>

              <Col md={2}>
                <Form.Label>Status</Form.Label>
                <Select
                  options={statusOptions}
                  value={statusOptions.find((o) => o.value === filters.status)}
                  onChange={(option) => handleFilterChange('status', option?.value || '')}
                />
              </Col>

              <Col md={2}>
                <Form.Label>From Date</Form.Label>
                <Form.Control type="date" value={filters.fromDate} onChange={(e) => handleFilterChange('fromDate', e.target.value)} />
              </Col>

              <Col md={2}>
                <Form.Label>To Date</Form.Label>
                <Form.Control type="date" value={filters.toDate} onChange={(e) => handleFilterChange('toDate', e.target.value)} />
              </Col>

              <Col md={3}>
                {!isSearched ? (
                  <Button variant="primary" className="w-100" disabled={!isFilterApplied} onClick={handleSearch}>
                    <Icon icon="mdi:magnify" className="me-2" />
                    Search
                  </Button>
                ) : (
                  <Button variant="secondary" className="w-100" onClick={resetFilters}>
                    <Icon icon="mdi:refresh" className="me-2" />
                    Reset Filters
                  </Button>
                )}
              </Col>
            </Row>
          </Form>

          {/* Table (UNCHANGED except edit works now) */}
          <Table striped bordered hover responsive className="text-center align-middle">
            <thead className="table-light">
              <tr>
                <th>ID</th>
                <th>Created Date</th>
                <th>Created By</th>
                <th>Name</th>
                <th>Note</th>
                <th style={{ width: '200px' }}>Action</th>
              </tr>
            </thead>

            <tbody>
              {isLoading || isFetching ? (
                <tr>
                  <td colSpan="6">
                    <Spinner animation="border" size="sm" /> Loading...
                  </td>
                </tr>
              ) : categories.length > 0 ? (
                categories.map((cat) => (
                  <tr key={cat.category_id}>
                    <td>{cat.category_id}</td>
                    <td>{cat.created_at?.split('T')[0]}</td>
                    <td>
                      #{cat.category_id} {cat.first_name}
                    </td>
                    <td>
                      {cat.name}
                      {cat.is_default && <span className="badge bg-primary ms-2">Default</span>}
                    </td>
                    <td>{cat.note}</td>
                    <td>
                      <div className="d-flex justify-content-center align-items-center gap-3">
                        <Form.Check
                          type="switch"
                          checked={cat.status === 'active'}
                          disabled={cat.is_default}
                          onChange={() => handleStatusToggle(cat)}
                          label={
                            <span className={cat.status === 'active' ? 'text-success fw-semibold' : 'text-muted fw-semibold'}>
                              {cat.status === 'active' ? 'Active' : 'Inactive'}
                            </span>
                          }
                        />
                        <Button size="sm" variant="info" onClick={() => handleEdit(cat)} disabled={cat.is_default}>
                          <Icon icon="mdi:pencil" className="me-1" />
                          Edit
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="text-muted">
                    No categories found
                  </td>
                </tr>
              )}
            </tbody>
          </Table>
          {totalPages > 0 && (
            <PaginationComponent
              currentPage={currentPage}
              totalPages={totalPages}
              totalEntries={totalEntries}
              limit={limit}
              onPageChange={(page) => {
                setCurrentPage(page)
              }}
              onLimitChange={(val) => {
                setCurrentPage(1)
              }}
              showingFrom={
                categories.length === 0
                  ? 0
                  : (currentPage - 1) * limit + 1
              }
              showingTo={
                categories.length === 0
                  ? 0
                  : (currentPage - 1) * limit + categories.length
              }
            />
          )}
        </CardBody>
      </Card>

      {/* ================= EDIT MODAL ================= */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Account Category</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Category Name *</Form.Label>
              <Form.Control
                type="text"
                value={editData.name}
                onChange={(e) =>
                  setEditData((prev) => ({
                    ...prev,
                    name: e.target.value,
                  }))
                }
              />
            </Form.Group>

            <Form.Group>
              <Form.Label>Note</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={editData.note}
                onChange={(e) =>
                  setEditData((prev) => ({
                    ...prev,
                    note: e.target.value,
                  }))
                }
              />
            </Form.Group>
          </Form>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleUpdateCategory} disabled={isUpdating}>
            {isUpdating ? 'Updating...' : 'Update Category'}
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default CategoryList
