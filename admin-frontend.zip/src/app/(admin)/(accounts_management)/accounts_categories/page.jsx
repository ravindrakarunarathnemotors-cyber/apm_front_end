import AddCategory from './add_category/AddCategory'

export const metadata = {
  title: 'Categories',
}

export default function Page() {
  return <AddCategory />
}
