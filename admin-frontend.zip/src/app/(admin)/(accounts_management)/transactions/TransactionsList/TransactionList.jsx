'use client'

import React, { useState, useMemo } from 'react'
import Swal from 'sweetalert2'
import { Icon } from '@iconify/react'
import { Card, CardBody, CardHeader, CardTitle, Form, Button, Row, Col, Table, Modal, Spinner } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import {
  useGetTransactionsQuery,
  useGetActiveAccountsQuery,
  useGetActiveAccountCategoriesQuery,
  useUpdateTransactionPaymentStatusMutation,
} from '@/store/features/apiSlice'

function TransactionList() {
  // ================= STATUS BADGE =================
  const getStatusBadge = (status) => {
    if (!status) return 'bg-secondary'

    const s = status.toLowerCase()

    if (s === 'active') return 'bg-success'
    if (s === 'inactive') return 'bg-secondary'

    if (s === 'approved') return 'bg-success'
    if (s === 'pending') return 'bg-warning text-dark'
    if (s === 'rejected') return 'bg-danger'

    return 'bg-secondary'
  }

  // ================= FILTER OPTIONS =================
  const transactionTypeOptions = [
    { value: '', label: 'All Types' },
    { value: 'income', label: 'Income' },
    { value: 'expense', label: 'Expense' },
    { value: 'transfer', label: 'Transfer' },
  ]

  const paymentStatusOptions = [
    { value: '', label: 'All Status' },
    { value: 'pending', label: 'Pending' },
    { value: 'approved', label: 'Approved' },
    { value: 'rejected', label: 'Rejected' },
  ]

  // ================= FETCH DATA =================
  const { data: accountsData, isLoading: accountsLoading } = useGetActiveAccountsQuery()
  const { data: categoriesData, isLoading: categoriesLoading } = useGetActiveAccountCategoriesQuery()

  const [updatePaymentStatus, { isLoading: isUpdatingStatus }] = useUpdateTransactionPaymentStatusMutation()

  // ================= DROPDOWN OPTIONS =================
  const accountOptions = useMemo(() => {
    const dynamic =
      accountsData?.data?.map((acc) => ({
        value: acc.id,
        label: acc.name,
      })) || []
    return [{ value: '', label: 'All Accounts' }, ...dynamic]
  }, [accountsData])

  const categoryOptions = useMemo(() => {
    const dynamic =
      categoriesData?.data?.map((cat) => ({
        value: cat.category_id,
        label: cat.name,
      })) || []
    return [{ value: '', label: 'All Categories' }, ...dynamic]
  }, [categoriesData])

  // ================= FILTER STATE =================
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [typeFilter, setTypeFilter] = useState(transactionTypeOptions[0])
  const [categoryFilter, setCategoryFilter] = useState(categoryOptions[0])
  const [accountFilter, setAccountFilter] = useState(accountOptions[0])
  const [statusFilter, setStatusFilter] = useState(paymentStatusOptions[0])
  const [currentPage, setCurrentPage] = useState(1)

  const [limit, setLimit] = useState(25)

  const [appliedFilters, setAppliedFilters] = useState({
    page: 1,
    limit: 25,
  })

  const [showModal, setShowModal] = useState(false)
  const [selectedTx, setSelectedTx] = useState(null)

  // ================= FETCH TRANSACTIONS =================
  const { data, isLoading, isFetching, isError } = useGetTransactionsQuery(appliedFilters)
  const transactions = data?.data || []
  const totalPages = data?.total_pages || 1
  const totalEntries = data?.total_records || 0
  const currency = data?.currency || ''
  // ================= SEARCH =================
  const handleSearch = () => {
  setCurrentPage(1)

  setAppliedFilters({
    page: 1,
    limit,
    from: fromDate || undefined,
    to: toDate || undefined,
    transaction_type: typeFilter?.value || undefined,
    category_id: categoryFilter?.value || undefined,
    account_id: accountFilter?.value || undefined,
    payment_status: statusFilter?.value || undefined,
  })
}

  // ================= STATUS UPDATE =================



  const handleChangeStatus = async (transaction_id, payment_status, transaction_type) => {
    const confirm = await Swal.fire({
      title: `Confirm ${payment_status.toUpperCase()}?`,
      text: `Are you sure you want to ${payment_status} this transaction?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
    })

    if (!confirm.isConfirmed) return

    try {
      await updatePaymentStatus({
        transaction_id,
        payment_status,
        transaction_type,
      }).unwrap()
      Swal.fire('Success', `Transaction ${payment_status} successfully`, 'success')
    } catch {
      Swal.fire('Error', 'Failed to update payment status', 'error')
    }
  }

  // ================= PAGINATION =================


  const handlePageChange = (page) => {
    setCurrentPage(page)

    setAppliedFilters((prev) => ({
      ...prev,
      page,
    }))
  }

  const formatDate = (date) => {
    if (!date) return ''
    return new Date(date).toISOString().split('T')[0]
  }

  const handleView = (tx) => {
    setSelectedTx(tx)
    setShowModal(true)
  }

  return (
    <>
      <Card className="shadow-sm">
        <CardHeader className="py-3 bg-light">
          <CardTitle className="mb-0">Transaction List</CardTitle>
        </CardHeader>

        <CardBody>
          {/* ================= FILTER SECTION ================= */}
          <Row className="mb-3 align-items-end">
            <Col md={2}>
              <Form.Label>From</Form.Label>
              <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
            </Col>

            <Col md={2}>
              <Form.Label>To</Form.Label>
              <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
            </Col>

            <Col md={2}>
              <Form.Label>Type</Form.Label>
              <Select options={transactionTypeOptions} value={typeFilter} onChange={setTypeFilter} />
            </Col>

            <Col md={2}>
              <Form.Label>Category</Form.Label>
              {categoriesLoading ? <Spinner size="sm" /> : <Select options={categoryOptions} value={categoryFilter} onChange={setCategoryFilter} />}
            </Col>

            <Col md={2}>
              <Form.Label>Account</Form.Label>
              {accountsLoading ? <Spinner size="sm" /> : <Select options={accountOptions} value={accountFilter} onChange={setAccountFilter} />}
            </Col>

            {/* SEARCH BUTTON - SAME ROW */}
            <Col md={2} className="d-flex">
              <Button className="w-100" onClick={handleSearch}>
                Search
              </Button>
            </Col>
          </Row>
          {/* ================= TABLE ================= */}
          <Table bordered hover responsive className="text-center align-middle">
            <thead className="table-light">
              <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Type</th>
                <th>Category</th>
                <th>Account</th>
                <th>Payer/Payee</th>
                <th>Note/Reference</th>

                {/* <th>Fee</th> */}
                <th>Status</th>
                <th>By</th>
                <th className="text-end">Amount {currency ? `(${currency})` : ''}</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {isLoading || isFetching ? (
                <tr>
                  <td colSpan="12" className="text-center">
                    <Spinner animation="border" size="sm" /> Loading...
                  </td>
                </tr>
              ) : isError ? (
                <tr>
                  <td colSpan="12" className="text-danger text-center">
                    Error fetching transactions
                  </td>
                </tr>
              ) : transactions.length > 0 ? (
                transactions.map((tx) => (
                  <tr key={tx.transaction_id}>
                    <td>{tx.transaction_id}</td>
                    <td>{formatDate(tx.transaction_date)}</td>
                    <td>{tx.transaction_type}</td>
                    <td>{tx.category_name || '-'}</td>
                    <td>{tx.account_name}</td>
                    <td>{tx.payer_payee || 'N/A'}</td>
                    <td className="text-start">
                      <div className="d-flex align-items-center justify-content-between">
                        <span>{tx.note || '-'}</span>

                        {tx.file_url && (
                          <Icon
                            icon="mdi:download"
                            width="18"
                            title="Download Attachment"
                            style={{
                              cursor: 'pointer',
                              color: '#0d6efd',
                            }}
                            onClick={async () => {
                              try {
                                const response = await fetch(tx.file_url)
                                const blob = await response.blob()

                                const url = window.URL.createObjectURL(blob)

                                const link = document.createElement('a')
                                link.href = url
                                link.download = tx.file_url.split('/').pop() || 'attachment'
                                document.body.appendChild(link)

                                link.click()

                                link.remove()
                                window.URL.revokeObjectURL(url)
                              } catch (error) {
                                Swal.fire('Download Failed', 'Unable to download file', 'error')
                              }
                            }}
                          />
                        )}
                      </div>
                    </td>
                    {/* <td className="text-end">{tx.transaction_fee}</td> */}

                    {/* STATUS BADGE */}
                    <td>
                      <span className={`badge ${getStatusBadge(tx.status)}`}>{(tx.status || '').toUpperCase()}</span>
                    </td>

                    <td>
                      #{tx.by} {tx.first_name}
                    </td>
                    <td className="text-end">{tx.amount}</td>

                    {/* ACTION BUTTONS */}
                    <td>
                      <div className="d-flex justify-content-center gap-2">
                        <button
                          className="btn btn-sm btn-outline-primary d-flex align-items-center justify-content-center"
                          style={{ width: '85px' }}
                          onClick={() => handleView(tx)}>
                          <Icon icon="mdi:eye-outline" width="14" className="me-1" />
                          View
                        </button>

                        <button
                          className={`btn btn-sm d-flex align-items-center justify-content-center ${tx.payment_status === 'rejected' ? 'btn-secondary' : 'btn-outline-danger'
                            }`}
                          style={{ width: '85px' }}
                          disabled={tx.payment_status === 'rejected' || isUpdatingStatus}
                          onClick={() => handleChangeStatus(tx.transaction_id, 'rejected', tx.transaction_type)}>
                          <Icon icon="mdi:close-circle-outline" width="14" className="me-1" />
                          {tx.payment_status === 'rejected' ? 'Rejected' : 'Reject'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="12" className="text-center">
                    No transactions found
                  </td>
                </tr>
              )}
            </tbody>
          </Table>

          {totalPages > 1 && (
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalEntries={totalEntries}
              limit={limit}
              onPageChange={handlePageChange}
              onLimitChange={(val) => {
                const newLimit = Number(val)

                setLimit(newLimit)
                setCurrentPage(1)

                setAppliedFilters((prev) => ({
                  ...prev,
                  page: 1,
                  limit: newLimit,
                }))
              }}
              showingFrom={
                transactions.length === 0
                  ? 0
                  : (currentPage - 1) * limit + 1
              }
              showingTo={
                transactions.length === 0
                  ? 0
                  : (currentPage - 1) * limit + transactions.length
              }
            />
          )}
        </CardBody>
      </Card>
      {/* ================= VIEW MODAL ================= */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered size="lg">
        {/* ===== HEADER ===== */}
        <Modal.Header closeButton className="border-0 pb-0">
          <Modal.Title className="fw-bold d-flex align-items-center gap-2">
            <Icon icon="mdi:receipt-text-outline" className="text-primary" />
            Transaction Details
          </Modal.Title>
        </Modal.Header>

        {/* ===== BODY ===== */}
        <Modal.Body className="pt-3">
          {selectedTx && (
            <div className="rounded-4 border shadow-sm p-4 bg-white">
              {/* ===== TOP ROW ===== */}
              <div className="d-flex justify-content-between align-items-start mb-4">
                <div>
                  <div className="text-muted small">Transaction ID</div>
                  <div className="fw-bold fs-5">#{selectedTx.transaction_id}</div>
                </div>

                <div className="text-end">
                  <div
                    className={`badge px-3 py-2 ${selectedTx.payment_status === 'approved'
                        ? 'bg-success-subtle text-success'
                        : selectedTx.payment_status === 'pending'
                          ? 'bg-warning-subtle text-warning'
                          : 'bg-danger-subtle text-danger'
                      }`}
                    style={{ fontWeight: 500 }}>
                    {selectedTx.payment_status?.toUpperCase()}
                  </div>
                </div>
              </div>

              {/* ===== AMOUNT HIGHLIGHT CARD ===== */}
              <div className="bg-light rounded-4 p-3 mb-4 border">
                <div className="text-muted small">Amount</div>
                <div className="fw-bold fs-3 text-primary">{selectedTx.amount}</div>
              </div>

              {/* ===== DETAILS GRID ===== */}
              <Row className="g-4">
                <Col md={6}>
                  <div className="text-muted small">Date</div>
                  <div className="fw-medium">{formatDate(selectedTx.transaction_date)}</div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Type</div>
                  <div className="fw-medium text-capitalize">{selectedTx.transaction_type}</div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Category</div>
                  <div className="fw-medium">{selectedTx.category_name || '-'}</div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Account</div>
                  <div className="fw-medium">{selectedTx.account_name || '-'}</div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Payer / Payee</div>
                  <div className="fw-medium">{selectedTx.payer_payee || 'N/A'}</div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Created By</div>
                  <div className="fw-medium">
                    #{selectedTx.by} {selectedTx.first_name || ''}
                  </div>
                </Col>

                <Col md={6}>
                  <div className="text-muted small">Transaction Fee</div>
                  <div className="fw-medium">{selectedTx.transaction_fee || 0}</div>
                </Col>

                <Col md={12}>
                  <div className="text-muted small">Note / Reference</div>
                  <div className="fw-medium">{selectedTx.note || '-'}</div>
                </Col>
              </Row>
            </div>
          )}
        </Modal.Body>

        {/* ===== FOOTER ===== */}
        <Modal.Footer className="border-0 pt-0">
          <Button variant="primary" className="px-4 rounded-3" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default TransactionList
