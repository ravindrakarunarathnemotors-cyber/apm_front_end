'use client'

import React, { useState, useMemo, useEffect, useRef } from 'react'

import { Card, CardBody, CardHeader, CardTitle, Form, Button, Row, Col, Spinner, ProgressBar } from 'react-bootstrap'
import Select from 'react-select'
import Swal from 'sweetalert2'
import TransactionList from '../TransactionsList/TransactionList'
import {
  useCreateTransactionMutation,
  useGetActiveAccountsQuery,
  useGetActiveAccountCategoriesQuery,
  useFetchPayerPayeesQuery,
  useGetActiveOutletsQuery,
} from '@/store/features/apiSlice'
import axios from 'axios'

function NewTransaction() {
  const [createTransaction, { isLoading }] = useCreateTransactionMutation()
  const { data: accountsData, isLoading: accountsLoading } = useGetActiveAccountsQuery()
  const { data: categoriesData, isLoading: categoriesLoading } = useGetActiveAccountCategoriesQuery()
  const { data: payerPayeesData, isLoading: payerPayeesLoading } = useFetchPayerPayeesQuery()
  const { data: outletsData, isLoading: outletsLoading } = useGetActiveOutletsQuery()
  const [outlet, setOutlet] = useState(null)

  const categoryOptions = useMemo(() => {
    if (!categoriesData?.data) return []

    return categoriesData.data.map((cat) => ({
      value: cat.category_id,
      label: cat.name,
      is_default: cat.is_default,
    }))
  }, [categoriesData])

  const formatCategoryLabel = (option) => (
    <div className="d-flex align-items-center justify-content-between">
      <span>{option.label}</span>

      {option.is_default && (
        <span
          style={{
            background: '#198754',
            color: '#fff',
            fontSize: '10px',
            padding: '2px 6px',
            borderRadius: '6px',
            marginLeft: '8px',
          }}>
          Default
        </span>
      )}
    </div>
  )

  const formatAccountLabel = (option) => (
    <div className="d-flex align-items-center justify-content-between">
      <span>{option.label}</span>

      <span
        style={{
          background: '#0d6efd',
          color: '#fff',
          fontSize: '10px',
          padding: '2px 6px',
          borderRadius: '6px',
          marginLeft: '8px',
        }}>
        {option.outlet_name} #{option.outlet_id}
      </span>
    </div>
  )
  const transactionTypeOptions = [
    { value: 'income', label: 'Income' },
    { value: 'expense', label: 'Expense' },
    { value: 'transfer', label: 'Transfer' },
  ]

  const [transactionType, setTransactionType] = useState(null)
  const [category, setCategory] = useState(null)
  const [account, setAccount] = useState(null)
  const [fromAccount, setFromAccount] = useState(null)
  const [toAccount, setToAccount] = useState(null)
  const [date, setDate] = useState('')
  const [party, setParty] = useState(null)
  const [amount, setAmount] = useState('')
  const [transactionFee, setTransactionFee] = useState('')
  const [description, setDescription] = useState('')
  const [accountError, setAccountError] = useState('')
  const [feeDeductFrom, setFeeDeductFrom] = useState(null)
  const [file, setFile] = useState(null)
  const [fileUrl, setFileUrl] = useState('')
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [fileError, setFileError] = useState('')
  const fileInputRef = useRef(null)
  const isTransfer = transactionType?.value === 'transfer'

  const filteredAccountOptions = useMemo(() => {
    if (!accountsData?.data) return []

    let filtered = accountsData.data

    // filter only for non-transfer transactions
    if (!isTransfer && outlet?.value) {
      filtered = filtered.filter((acc) => acc.outlet_id === outlet.value)
    }
    return filtered.map((acc) => ({
      value: acc.id,
      label: acc.name,
      outlet_name: acc.outlet_name,
      outlet_id: acc.outlet_id,
    }))
  }, [accountsData, outlet, isTransfer])

  const today = new Date().toISOString().split('T')[0]

  const payerPayeeOptionsBase = useMemo(() => {
    if (!payerPayeesData?.payer_payees) return []

    return payerPayeesData.payer_payees.map((p) => ({
      value: p.id,
      label: p.name,
      type: p.type,
    }))
  }, [payerPayeesData])

  const payerPayeeOptions = useMemo(() => {
    if (!transactionType) return payerPayeeOptionsBase

    if (transactionType.value === 'income') {
      return payerPayeeOptionsBase.filter((p) => p.type === 'payer' || p.type === 'payer/payee')
    }

    if (transactionType.value === 'expense') {
      return payerPayeeOptionsBase.filter((p) => p.type === 'payee' || p.type === 'payer/payee')
    }

    return payerPayeeOptionsBase
  }, [payerPayeeOptionsBase, transactionType])

  useEffect(() => {
    if (isTransfer && fromAccount) {
      setFeeDeductFrom(fromAccount)
    }
  }, [fromAccount, isTransfer])

  const handleToggleFeeAccount = () => {
    if (!fromAccount || !toAccount) return
    setFeeDeductFrom((prev) => (prev?.value === fromAccount.value ? toAccount : fromAccount))
  }

  useEffect(() => {
    if (isTransfer && fromAccount && toAccount && fromAccount.value === toAccount.value) {
      setAccountError('From Account and To Account cannot be the same')
    } else {
      setAccountError('')
    }
  }, [fromAccount, toAccount, isTransfer])

  useEffect(() => {
    setParty(null)
  }, [transactionType])

  useEffect(() => {
    setAccount(null)
    setFromAccount(null)
    setToAccount(null)
  }, [outlet])
  const partyLabel = useMemo(() => {
    if (!transactionType) return 'Payer/Payee'
    if (transactionType.value === 'income') return 'Payer'
    if (transactionType.value === 'expense') return 'Payee'
    return ''
  }, [transactionType])

  const baseFieldsCompleted = isTransfer
    ? transactionType && category && fromAccount && toAccount && date && !accountError
    : transactionType && category && account && date && party

  const amountEntered = amount && Number(amount) > 0
  const noteEntered = description && description.trim().length > 0
  const isFormValid = baseFieldsCompleted && amountEntered && noteEntered
  const handleFileChange = async (e) => {
    const selectedFile = e.target.files[0]
    if (!selectedFile) return

    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf', 'application/zip']

    const maxSize = 10 * 1024 * 1024

    if (!allowedTypes.includes(selectedFile.type)) {
      setFileError('Only JPG, PNG, PDF or ZIP allowed')
      return
    }

    if (selectedFile.size > maxSize) {
      setFileError('File must be less than 10MB')
      return
    }

    try {
      setUploading(true)
      setUploadProgress(0)
      setFileError('')

      const formData = new FormData()
      formData.append('files', selectedFile)
      formData.append('transaction_id', 'TEMP')

      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/acc-transaction-routes/upload-transaction-files`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          setUploadProgress(percent)
        },
      })

      const returnedUrl = response?.data?.data?.[0]?.url

      if (!returnedUrl) throw new Error('Upload failed')

      setFileUrl(returnedUrl)
      setFile(selectedFile)
    } catch (error) {
      setFile(null)
      setFileUrl(null)

      Swal.fire('Upload Failed', error?.response?.data?.message || 'File upload failed', 'error')
    } finally {
      setUploading(false)
    }
  }

  // Dummy outlets (temporary)
  const outletOptions = useMemo(() => {
    if (!outletsData?.outlets) return []

    return outletsData.outlets.map((o) => ({
      value: o.outlet_id,
      label: o.name,
    }))
  }, [outletsData])

  // Selected outlet

  // Show dropdown only if more than one outlet
  const showOutletDropdown = outletOptions.length > 0
  useEffect(() => {
    if (outletOptions.length === 1) {
      setOutlet(outletOptions[0])
    }
  }, [outletOptions])
  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!isFormValid) return

    const deductFee = Number(transactionFee) > 0

    const confirm = await Swal.fire({
      title: 'Transaction Summary',
      html: `
        <div style="text-align:left">
          <p><strong>Type:</strong> ${transactionType.label}</p>
          <p><strong>Category:</strong> ${category.label}</p>
          <p><strong>Date:</strong> ${date}</p>
          ${
            isTransfer
              ? `
                <p><strong>From:</strong> ${fromAccount.label}</p>
                <p><strong>To:</strong> ${toAccount.label}</p>
              `
              : `
                <p><strong>Account:</strong> ${account.label}</p>
                <p><strong>${partyLabel}:</strong> ${party.label}</p>
              `
          }
          <p><strong>Amount:</strong> ${amount}</p>
          <p><strong>Fee:</strong> ${transactionFee || 0}</p>
          <p><strong>Deduct Transaction Fee From:</strong> ${isTransfer ? feeDeductFrom?.label : account?.label}</p>
        </div>
      `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Confirm & Submit',
    })

    if (!confirm.isConfirmed) return

    // const handleFileChange = async (e) => {
    //   const selectedFile = e.target.files[0]
    //   if (!selectedFile) return

    //   const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf', 'application/zip']

    //   const maxSize = 10 * 1024 * 1024

    //   if (!allowedTypes.includes(selectedFile.type)) {
    //     setFileError('Only JPG, PNG, PDF or ZIP allowed')
    //     return
    //   }

    //   if (selectedFile.size > maxSize) {
    //     setFileError('File must be less than 10MB')
    //     return
    //   }

    //   try {
    //     setUploading(true)
    //     setUploadProgress(0)
    //     setFileError('')

    //     const formData = new FormData()
    //     formData.append('files', selectedFile)
    //     formData.append('transaction_id', 'TEMP')

    //     const response = await axios.post('/acc-transaction-routes/upload-transaction-files', formData, {
    //       headers: {
    //         'Content-Type': 'multipart/form-data',
    //       },
    //       onUploadProgress: (progressEvent) => {
    //         const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total)
    //         setUploadProgress(percent)
    //       },
    //     })

    //     const returnedUrl = response?.data?.data?.[0]?.url

    //     if (!returnedUrl) throw new Error('Upload failed')

    //     setFileUrl(returnedUrl)
    //     setFile(selectedFile)
    //   } catch (error) {
    //     setFile(null)
    //     setFileUrl(null)

    //     Swal.fire('Upload Failed', error?.response?.data?.message || 'File upload failed', 'error')
    //   } finally {
    //     setUploading(false)
    //   }
    // }
    try {
      await createTransaction({
        transaction_type: transactionType.value,
        category_id: category.value,
        account_id: isTransfer ? fromAccount.value : account.value,
        to_account_id: isTransfer ? toAccount.value : null,
        deduct_fee: deductFee,
        deduct_fee_account_id: isTransfer ? feeDeductFrom?.value : account.value,
        transaction_date: date,
        payer_payee: isTransfer ? 'TRANSFER' : party.label,
        payer_payee_id: isTransfer ? 0 : party.value,
        amount: Number(amount),
        transaction_fee: Number(transactionFee) || 0,
        note: description,
        file_url: fileUrl || null,
        outlet_id: isTransfer ? fromAccount?.outlet_id || toAccount?.outlet_id || 1 : outlet?.value,
        status: 'active',
      }).unwrap()

      await Swal.fire({
        icon: 'success',
        title: 'Transaction Added Successfully!',
      })

      setFile(null)
      setFileUrl(null)
      setUploadProgress(0)

      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }

      // Reset
      setTransactionType(null)
      setCategory(null)
      setAccount(null)
      setFromAccount(null)
      setToAccount(null)
      setFeeDeductFrom(null)
      setDate('')
      setParty(null)
      setOutlet(null)
      setAmount('')
      setTransactionFee('')
      setDescription('')
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: error?.data?.message || 'Something went wrong',
      })
    }
  }

  return (
    <>
      <Card className="shadow-sm mb-4">
        <CardHeader className="py-3 bg-light">
          <CardTitle className="mb-0">Add New Transaction</CardTitle>
        </CardHeader>

        <CardBody>
          <Form onSubmit={handleSubmit}>
            {isTransfer ? (
              <>
                {/* Row 1 */}
                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Label>Transaction Type *</Form.Label>
                    <Select options={transactionTypeOptions} value={transactionType} onChange={setTransactionType} />
                  </Col>

                  <Col md={4}>
                    <Form.Label>Category *</Form.Label>

                    {categoriesLoading ? (
                      <Spinner size="sm" />
                    ) : (
                      <Select
                        options={categoryOptions}
                        value={category}
                        onChange={setCategory}
                        placeholder="Select category"
                        isClearable
                        formatOptionLabel={formatCategoryLabel}
                      />
                    )}
                  </Col>

                  <Col md={4}>
                    <Form.Label>Date *</Form.Label>
                    <Form.Control type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} />
                  </Col>
                </Row>

                {/* Row 2 */}

                <Row className="mb-3">
                  {/* {showOutletDropdown && (
    <Col md={3}>
      <Form.Label>Outlet *</Form.Label>
      {outletsLoading ? (
        <Spinner size="sm" />
      ) : (
        <Select options={outletOptions} value={outlet} onChange={setOutlet} placeholder="Select outlet" />
      )}
    </Col>
  )} */}

                  <Col md={4}>
                    <Form.Label>From Account *</Form.Label>
                    <Select
                      options={filteredAccountOptions}
                      value={fromAccount}
                      onChange={setFromAccount}
                      formatOptionLabel={formatAccountLabel}
                      isDisabled={accountsLoading}
                      placeholder="Select account"
                      className={accountError ? 'is-invalid' : ''}
                    />

                    {accountError && <div className="text-danger small mt-1">{accountError}</div>}
                  </Col>

                  <Col md={4}>
                    <Form.Label>To Account *</Form.Label>

                    <Select
                      options={filteredAccountOptions}
                      value={toAccount}
                      onChange={setToAccount}
                      formatOptionLabel={formatAccountLabel}
                      isDisabled={accountsLoading}
                      placeholder="Select account"
                      className={accountError ? 'is-invalid' : ''}
                    />
                    {accountError && <div className="text-danger small mt-1">{accountError}</div>}
                  </Col>

                  <Col md={4}>
                    <Form.Label>Amount *</Form.Label>
                    <Form.Control type="number" min="0" step="0.01" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
                  </Col>
                </Row>

                {/* Row 3 */}
                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Label>
                      Transaction Fee <span className="text-muted">(Optional)</span>
                    </Form.Label>
                    <Form.Control type="number" min="0" value={transactionFee} onChange={(e) => setTransactionFee(e.target.value)} />
                  </Col>

                  <Col md={4}>
                    <Form.Label>Deduct Fee From</Form.Label>
                    <div className="d-flex align-items-center gap-3">
                      <Form.Check
                        type="switch"
                        checked={feeDeductFrom?.value === toAccount?.value}
                        onChange={handleToggleFeeAccount}
                        disabled={!fromAccount || !toAccount}
                      />
                      <span className="fw-semibold">{feeDeductFrom?.label || fromAccount?.label}</span>
                    </div>
                  </Col>

                  <Col md={4}>
                    <Form.Label>
                      Attachment <span className="text-muted">(Optional)</span>
                    </Form.Label>
                    <Form.Control ref={fileInputRef} type="file" accept=".jpg,.jpeg,.png,.pdf,.zip" onChange={handleFileChange} />

                    {uploading && <ProgressBar now={uploadProgress} className="mt-2" />}

                    {fileError && <div className="text-danger mt-1">{fileError}</div>}
                  </Col>

                  <Col md={4}>
                    <Form.Label>Note / Reference *</Form.Label>
                    <Form.Control as="textarea" rows={1} maxLength={250} value={description} onChange={(e) => setDescription(e.target.value)} />
                  </Col>
                </Row>
              </>
            ) : (
              <>
                {/* Normal UI remains unchanged */}
                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Label>Transaction Type *</Form.Label>
                    <Select options={transactionTypeOptions} value={transactionType} onChange={setTransactionType} />
                  </Col>

                  <Col md={4}>
                    <Form.Label>Category *</Form.Label>
                    {categoriesLoading ? (
                      <Spinner size="sm" />
                    ) : (
                      <Select
                        options={categoryOptions}
                        value={category}
                        onChange={setCategory}
                        placeholder="Select category"
                        isClearable
                        formatOptionLabel={formatCategoryLabel}
                      />
                    )}
                  </Col>

                  {showOutletDropdown && (
                    <Col md={4}>
                      <Form.Label>Outlet *</Form.Label>
                      {outletsLoading ? (
                        <Spinner size="sm" />
                      ) : (
                        <Select options={outletOptions} value={outlet} onChange={setOutlet} placeholder="Select outlet" />
                      )}
                    </Col>
                  )}
                </Row>

                <Row className="mb-3">
                  <Col md={3}>
                    <Form.Label>Account *</Form.Label>
                    {accountsLoading ? (
                      <Spinner size="sm" />
                    ) : (
                      <Select
                        options={filteredAccountOptions}
                        value={account}
                        onChange={setAccount}
                        formatOptionLabel={formatAccountLabel}
                        isDisabled={!outlet}
                        placeholder={!outlet ? 'Select outlet first' : 'Select account'}
                      />
                    )}
                  </Col>

                  <Col md={3}>
                    <Form.Label>Date *</Form.Label>
                    <Form.Control type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} />
                  </Col>

                  <Col md={3}>
                    <Form.Label>{partyLabel} *</Form.Label>
                    {payerPayeesLoading ? <Spinner size="sm" /> : <Select options={payerPayeeOptions} value={party} onChange={setParty} />}
                  </Col>

                  <Col md={3}>
                    <Form.Label>Amount *</Form.Label>
                    <Form.Control type="number" min="0" step="0.01" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
                  </Col>
                </Row>
                <Row className="mb-3">
                  <Col md={4}>
                    <Form.Label>
                      Transaction Fee <span className="text-muted">(Optional)</span>
                    </Form.Label>
                    <Form.Control
                      type="number"
                      min="0"
                      step="0.01"
                      inputMode="decimal"
                      value={transactionFee}
                      onChange={(e) => setTransactionFee(e.target.value)}
                    />
                  </Col>

                  <Col md={4}>
                    <Form.Label>Note / Reference *</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={1}
                      maxLength={250}
                      required
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </Col>
                  <Col md={4}>
                    <Form.Label>
                      Attachment <span className="text-muted">(Optional)</span>
                    </Form.Label>
                    <Form.Control ref={fileInputRef} type="file" accept=".jpg,.jpeg,.png,.pdf,.zip" onChange={handleFileChange} />

                    {uploading && <ProgressBar now={uploadProgress} className="mt-2" />}

                    {fileError && <div className="text-danger mt-1">{fileError}</div>}
                  </Col>
                </Row>
              </>
            )}

            <div className="text-end">
              <Button type="submit" disabled={!isFormValid || isLoading}>
                {isLoading ? 'Submitting...' : 'Submit Transaction'}
              </Button>
            </div>
          </Form>
        </CardBody>
      </Card>

      <TransactionList />
    </>
  )
}

export default NewTransaction
