import NewTransaction from './AddNewTransaction/NewTransaction'

export const metadata = {
  title: 'Add New Transaction',
}

export default function Page() {
  return <NewTransaction />
}