'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import AddAccount from './AddAccount'
import EditAccount from './EditAccount'
import { useGetAllAccountsMutation, useToggleAccountStatusMutation, useGetAccountNamesQuery } from '@/store/features/apiSlice'
import AdjustBalance from '../account_adjustments/AdjustBalance'
import AccountStatement from '../account_statement/AccountStatement'

function Accounts() {
  const [filters, setFilters] = useState({ keyword: '' })
  const [paymentStatus, setPaymentStatus] = useState('active')
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [searchRecipient, setSearchRecipient] = useState('')
  const [showAddModal, setShowAddModal] = useState(false)
  const [recipientName, setRecipientName] = useState('')
  const [showEditModal, setShowEditModal] = useState(false)
  const [selectedSupplier, setSelectedSupplier] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedRawMaterial, setSelectedRawMaterial] = useState(null)
  const [showStatementModal, setShowStatementModal] = useState(false)
  const [selectedAccountId, setSelectedAccountId] = useState(null)
  const [currency, setCurrency] = useState('')
  const [showAdjustmentModal, setShowAdjustmentModal] = useState(false)
  const [selectedAdjustmentAccount, setSelectedAdjustmentAccount] = useState(null)
  const logsPerPage = 10
  const [fetchFilteredProducts, { isLoading }] = useGetAllAccountsMutation()
  const [toggleRawMaterialStatus] = useToggleAccountStatusMutation()

  const { data: RecipientResults } = useGetAccountNamesQuery(searchRecipient, {
    skip: searchRecipient.length < 2,
  })
  const orderOptions =
    RecipientResults?.map((order) => ({
      label: `${order.name}`,
    })) || []

  function getPageWindow(current, total, width = 5) {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const debouncedSearchRecipient = debounce((value) => {
    setSearchRecipient(value)
  }, 300)

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredProducts({
        page,
        limit: logsPerPage,
        keyword: filters.keyword,
        status: paymentStatus,
        todate: todate,
        date: date,
      }).unwrap()

      setLogs(res.accounts || [])
      setCurrency(res.currency || '')
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch products:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const getCurrencySymbol = (code) => {
    try {
      return (
        new Intl.NumberFormat('en', {
          style: 'currency',
          currency: code,
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        })
          .formatToParts(0)
          .find((part) => part.type === 'currency')?.value || code
      )
    } catch {
      return code
    }
  }

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const handleToggleStatus = async (id) => {
    const material = logs.find((m) => m.id === id)
    if (!material) return

    const newStatus = material.status === 'active' ? 'inactive' : 'active'

    const result = await Swal.fire({
      title: `Confirm Status Change`,
      html: `
      Are you sure you want to 
      <strong>${newStatus}</strong> 
      the account name <strong>${material.name}</strong>?
      <br/><br/>
    `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus}`,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      await toggleRawMaterialStatus({
        id,
        status: newStatus,
      }).unwrap()

      Swal.fire('Success', 'Status updated successfully!', 'success')

      // Update UI instantly
      setLogs((prevLogs) => prevLogs.map((m) => (m.id === id ? { ...m, status: newStatus } : m)))
    } catch (error) {
      console.error('Failed to update status:', error)
      Swal.fire('Error', 'Failed to update status.', 'error')
    }
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Accounts
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Button type="button" className="btn bg-primary border border-primary" onClick={() => setShowAddModal(true)}>
                  <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                  Add Accounts
                </Button>
              </Col>
            </Row>
          </CardHeader>
          <CardBody>
            <Form className="row g-3 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Keyword</FormLabel>
                <Select
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  options={orderOptions}
                  onInputChange={(value, { action }) => {
                    if (action === 'input-change') {
                      // Typing
                      debouncedSearchRecipient(value)
                      setSearchRecipient(value)
                      setRecipientName(value)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: value,
                      }))
                    }
                  }}
                  onChange={(option) => {
                    if (option) {
                      const name = option.label?.split('(')[0].trim()
                      setRecipientName(name)
                      setSearchRecipient(name)
                      setFilters((prev) => ({
                        ...prev,
                        keyword: name,
                      }))
                    } else {
                      setRecipientName('')
                      setSearchRecipient('')
                      setFilters((prev) => ({
                        ...prev,
                        keyword: '',
                      }))
                    }
                  }}
                  placeholder="ID, Name"
                  isClearable
                  isSearchable
                  value={recipientName ? { label: recipientName, value: recipientName } : null}
                  components={{
                    DropdownIndicator: null,
                  }}
                />
              </FormGroup>
              <FormGroup className="col-md-3">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>From Date</FormLabel>
                    <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                  </div>

                  <div className="col-6">
                    <FormLabel>To Date</FormLabel>
                    <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-3">
                <FormLabel>Status</FormLabel>
                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                  <option value="">All</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </Form.Select>
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading raw materials...</p>
            ) : (
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Created At</th>
                      <th>Account Name </th>
                      <th>Outlet</th>
                      <th>Type</th>
                      <th>Description</th>
                      <th>Status</th>
                      {/* <th className="text-end">On Hold {currency && `(${currency})`}</th> */}
                      <th className="text-end">Balance {currency && `(${currency})`}</th>
                      <th className="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan="6" className="text-center">
                          No raw materials found.
                        </td>
                      </tr>
                    ) : (
                      logs.map((item) => (
                        <tr key={item.id}>
                          <td>{item.id}</td>
                          <td>{item.date && !isNaN(new Date(item.date)) ? new Date(item.date).toLocaleDateString() : 'Invalid Date'}</td>
                          <td>{item.name}</td>

                          <td>
                            {item.outlet_name ? (
                              <span className="badge bg-secondary">{item.outlet_name}</span>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </td>

                          <td>{item.type}</td>
                          <td>{item.description?.trim() ? item.description : 'N/A'}</td>
                          <td>
                            <span className={`badge ${item.status === 'active' ? 'bg-success' : 'bg-danger'}`}>
                              {item.status ? item.status.charAt(0).toUpperCase() + item.status.slice(1) : ''}
                            </span>
                          </td>
                          {/* <td className="text-end">
                            {item.hold_balance !== null && item.hold_balance !== undefined
                              ? `${item.currency_symbol || ''} ${Number(item.hold_balance).toLocaleString(undefined, {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                                })}`
                              : 'N/A'}
                          </td> */}

                          <td className="text-end">
                            {item.balance !== null && item.balance !== undefined
                              ? `${item.currency_symbol || ''} ${Number(item.balance).toLocaleString(undefined, {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                                })}`
                              : `${item.currency_symbol || ''} 0.00`}
                          </td>

                          <td className="text-end">
                            <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                              {/* Statement */}
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#0d6efd',
                                  borderColor: '#0d6efd',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => {
                                  setSelectedAccountId(item.id)
                                  setShowStatementModal(true)
                                }}>
                                <IconifyIcon icon="mdi:file-document-outline" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Statement</span>
                              </Button>

                              {/* Adjustment */}
                              <Button
                                className="d-flex align-items-center justify-content-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: '#6f42c1',
                                  borderColor: '#6f42c1',
                                  color: '#fff',
                                  flex: 1,
                                }}
                                onClick={() => {
                                  setSelectedAdjustmentAccount(item)
                                  setShowAdjustmentModal(true)
                                }}>
                                <IconifyIcon icon="mdi:scale-balance" width={15} height={20} style={{ marginRight: '4px' }} />
                                <span>Adjustment</span>
                              </Button>

                              {/* Edit */}
                              <span title={item.is_default ? 'Default accounts cannot be edited' : 'Edit account'} style={{ flex: 1 }}>
                                <Button
                                  disabled={item.is_default}
                                  className="d-flex align-items-center justify-content-center w-100"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    backgroundColor: '#fd7e14',
                                    borderColor: '#fd7e14',
                                    color: '#fff',
                                    opacity: item.is_default ? 0.6 : 1,
                                    cursor: item.is_default ? 'not-allowed' : 'pointer',
                                  }}
                                  onClick={() => {
                                    if (item.is_default) return
                                    setSelectedRawMaterial(item)
                                    setShowEditModal(true)
                                  }}>
                                  <IconifyIcon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                  <span>Edit</span>
                                </Button>
                              </span>

                              {/* Status Toggle */}
                              <span
                                title={
                                  item.is_default
                                    ? 'Default accounts cannot change status'
                                    : item.status === 'active'
                                      ? 'Set account inactive'
                                      : 'Set account active'
                                }
                                style={{ flex: 1 }}>
                                <Button
                                  disabled={item.is_default}
                                  className="d-flex align-items-center justify-content-center w-100"
                                  style={{
                                    minWidth: 'auto',
                                    padding: '0.3rem 0.6rem',
                                    fontSize: '0.65rem',
                                    height: '30px',
                                    borderRadius: '15px',
                                    color: '#fff',
                                    backgroundColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                    borderColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                    opacity: item.is_default ? 0.6 : 1,
                                    cursor: item.is_default ? 'not-allowed' : 'pointer',
                                  }}
                                  onClick={() => {
                                    if (item.is_default) return
                                    handleToggleStatus(item.id)
                                  }}>
                                  <IconifyIcon
                                    icon={item.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                    style={{ fontSize: '20px', marginRight: '4px' }}
                                  />
                                  <span>{item.status === 'active' ? 'Active' : 'Inactive'}</span>
                                </Button>
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>
                {/* ================= PAGINATION ================= */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {(() => {
                        const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                        const pages = []

                        let start = safeCurrent - 2
                        let end = safeCurrent + 2

                        if (totalPages <= 5) {
                          start = 1
                          end = totalPages
                        } else {
                          if (start < 1) {
                            start = 1
                            end = 5
                          }
                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }
                        }

                        for (let i = start; i <= end; i++) {
                          pages.push(
                            <Pagination.Item key={i} active={i === safeCurrent} onClick={() => handlePageChange(i)}>
                              {i}
                            </Pagination.Item>,
                          )
                        }

                        return (
                          <>
                            {/* FIRST */}
                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(1)}>
                              First
                            </Pagination.Item>

                            {/* PREV */}
                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(safeCurrent - 1)}>
                              {'<'}
                            </Pagination.Item>

                            {pages}

                            {/* NEXT */}
                            <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(safeCurrent + 1)}>
                              {'>'}
                            </Pagination.Item>

                            {/* LAST */}
                            <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(totalPages)}>
                              Last
                            </Pagination.Item>
                          </>
                        )
                      })()}
                    </Pagination>
                  </div>
                )}
              </>
            )}
          </CardBody>

          <EditAccount
            show={showEditModal}
            onHide={() => setShowEditModal(false)}
            rawMaterialData={selectedRawMaterial}
            onSuccess={() => fetchLogs(currentPage)}
          />

          <AddAccount show={showAddModal} onHide={() => setShowAddModal(false)} onSuccess={() => fetchLogs(1)} />

          <AccountStatement show={showStatementModal} onHide={() => setShowStatementModal(false)} accountId={selectedAccountId} />
          <AdjustBalance
            show={showAdjustmentModal}
            onHide={() => setShowAdjustmentModal(false)}
            accountData={selectedAdjustmentAccount}
            currency={currency}
            onSuccess={() => fetchLogs(currentPage)}
          />
        </Card>
      </Col>
    </Row>
  )
}

export default Accounts
