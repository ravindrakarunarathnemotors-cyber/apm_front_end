import Accounts from './Accounts'

export const metadata = {
  title: 'Accounts',
}

export default function Page() {
  return <Accounts />
}