'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Button, Form, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useCreateAccountMutation, useGetActiveOutletsQuery } from '@/store/features/apiSlice'

function AddAccount({ show, onHide, onSuccess }) {
    const [createAccount] = useCreateAccountMutation()

    const { data } = useGetActiveOutletsQuery()

    const outlets = data?.outlets || []

    const [formData, setFormData] = useState({
        name: '',
        type: '',
        description: '',
        balance: '',
        outlet_id: '',
        bank_account: false,
        status: 'active',
    })

    useEffect(() => {
        if (!show) {
            setFormData({
                name: '',
                type: '',
                description: '',
                balance: '',
                outlet_id: '',
                bank_account: false,
                status: 'active',
            })
        }
    }, [show])

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target
        setFormData((prev) => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }))
    }

    const handleSubmit = async () => {


    if (!formData.outlet_id) {
        Swal.fire('Validation Error', 'Please select an outlet.', 'warning')
        return
    }
    
        try {
            await createAccount(formData).unwrap()

            Swal.fire('Success', 'Account created successfully!', 'success')

            onHide()
            onSuccess()
        } catch (error) {
            console.error(error)
            Swal.fire('Error', 'Failed to create account.', 'error')
        }
    }

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>Add Account</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <Form>
                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Account Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Type</Form.Label>
                                <Form.Select
                                    name="type"
                                    value={formData.type}
                                    onChange={handleChange}
                                >
                                    <option value="">Select Type</option>
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </Form.Select>
                            </Form.Group>
                        </Col>
                    </Row>

                    <Form.Group className="mb-3">
                        <Form.Label>Initial Balance</Form.Label>
                        <Form.Control
                            type="number"
                            name="balance"
                            value={formData.balance}
                            onChange={handleChange}
                        />
                    </Form.Group>

                    <Form.Group className="mb-3">
                        <Form.Label>Description</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={3}
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                        />
                    </Form.Group>

                    <Form.Group className="mb-3">
                        <Form.Label>Status</Form.Label>
                        <Form.Select
                            name="status"
                            value={formData.status}
                            onChange={handleChange}
                        >
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </Form.Select>
                    </Form.Group>
                    <Row>

                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Outlet</Form.Label>
                                <Form.Select
                                    name="outlet_id"
                                    value={formData.outlet_id}
                                    onChange={handleChange}
                                    required
                                >
                                    <option value="">Select Outlet</option>

                                    {outlets.map((outlet) => (
                                        <option
                                            key={outlet.outlet_id}
                                            value={outlet.outlet_id}
                                        >
                                            {outlet.name}
                                        </option>
                                    ))}

                                </Form.Select>
                            </Form.Group>
                        </Col>


                        <Col md={6} className="d-flex align-items-center">

                            <Form.Group className="mb-3">
                                <Form.Check
                                    type="switch"
                                    id="bank_account_switch"
                                    label="Bank Account"
                                    name="bank_account"
                                    checked={formData.bank_account}
                                    onChange={handleChange}
                                />
                            </Form.Group>

                        </Col>

                    </Row>
                </Form>
            </Modal.Body>

            <Modal.Footer>
                <Button variant="secondary" onClick={onHide}>
                    Cancel
                </Button>
                <Button variant="primary" onClick={handleSubmit}>
                    Save Account
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default AddAccount