'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Button, Form, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useUpdateAccountMutation, useGetActiveOutletsQuery } from '@/store/features/apiSlice'

function EditAccount({ show, onHide, rawMaterialData, onSuccess }) {
    const [updateAccount] = useUpdateAccountMutation()
    const { data } = useGetActiveOutletsQuery()

    const outlets = data?.outlets || []

    const [formData, setFormData] = useState({
        id: '',
        name: '',
        type: '',
        description: '',
        outlet_id: '',
        bank_account: false,
        status: '',
    })

    useEffect(() => {
        if (rawMaterialData) {
            setFormData({
                id: rawMaterialData.id,
                name: rawMaterialData.name || '',
                type: rawMaterialData.type || '',
                description: rawMaterialData.description || '',
                outlet_id: rawMaterialData.outlet_id || '',
                bank_account: rawMaterialData.bank_account || false,
                status: rawMaterialData.status || 'active',
            })
        }
    }, [rawMaterialData])

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target
        setFormData((prev) => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }))
    }

    const handleSubmit = async () => {
        try {
            await updateAccount({
                id: formData.id,
                name: formData.name,
                type: formData.type,
                description: formData.description,
                outlet_id: formData.outlet_id,
                bank_account: formData.bank_account,
                status: formData.status,
                // 👇 balance NOT sent intentionally
            }).unwrap()

            Swal.fire('Success', 'Account updated successfully!', 'success')

            onHide()
            onSuccess()
        } catch (error) {
            console.error(error)
            Swal.fire('Error', 'Failed to update account.', 'error')
        }
    }

    return (
        <Modal show={show} onHide={onHide} centered>
            <Modal.Header closeButton>
                <Modal.Title>Edit Account</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <Form>
                    <Row>
                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Account Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Type</Form.Label>
                                <Form.Select
                                    name="type"
                                    value={formData.type || ""}
                                    onChange={handleChange}
                                >
                                    <option value="">Select Type</option>
                                    <option value="online">Online</option>
                                    <option value="offline">Offline</option>
                                </Form.Select>
                            </Form.Group>
                        </Col>
                    </Row>

                    <Form.Group className="mb-3">
                        <Form.Label>Description</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={3}
                            name="description"
                            value={formData.description}
                            onChange={handleChange}
                        />
                    </Form.Group>

                    <Form.Group className="mb-3">
                        <Form.Label>Status</Form.Label>
                        <Form.Select
                            name="status"
                            value={formData.status}
                            onChange={handleChange}
                        >
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </Form.Select>
                    </Form.Group>

                    <Row>

                        <Col md={6}>
                            <Form.Group className="mb-3">
                                <Form.Label>Outlet</Form.Label>
                                <Form.Select
                                    name="outlet_id"
                                    value={formData.outlet_id}
                                    onChange={handleChange}
                                >
                                    <option value="">Select Outlet</option>

                                    {outlets.map((outlet) => (
                                        <option
                                            key={outlet.outlet_id}
                                            value={outlet.outlet_id}
                                        >
                                            {outlet.name}
                                        </option>
                                    ))}

                                </Form.Select>
                            </Form.Group>
                        </Col>

                        <Col md={6} className="d-flex align-items-center">
                            <Form.Group className="mb-3">
                                <Form.Check
                                    type="switch"
                                    id="bank_account_switch"
                                    label="Bank Account"
                                    name="bank_account"
                                    checked={formData.bank_account}
                                    onChange={handleChange}
                                />
                            </Form.Group>
                        </Col>

                    </Row>
                </Form>
            </Modal.Body>

            <Modal.Footer>
                <Button variant="secondary" onClick={onHide}>
                    Cancel
                </Button>
                <Button variant="primary" onClick={handleSubmit}>
                    Update Account
                </Button>
            </Modal.Footer>
        </Modal>
    )
}

export default EditAccount