'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Button, Form, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useCreatePayerpayeeMutation } from '@/store/features/apiSlice'

function AddPayerPayee({ show, onHide, onSuccess }) {
  const [createPayerpayee] = useCreatePayerpayeeMutation()

  const [formData, setFormData] = useState({
    name: '',
    type: '',
    status: 'active',
  })

  useEffect(() => {
    if (!show) {
      setFormData({
        name: '',
        type: '',
        status: 'active',
      })
    }
  }, [show])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async () => {
    if (!formData.name || !formData.type) {
      Swal.fire('Error', 'Please fill all required fields', 'error')
      return
    }

    try {
      await createPayerpayee(formData).unwrap()

      Swal.fire('Success', 'Payer Payee created successfully!', 'success')

      onHide()
      onSuccess()
    } catch (error) {
      console.error(error)
      Swal.fire('Error', 'Failed to create Payer Payee.', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Add Payer Payee</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Type</Form.Label>
                <Form.Select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                >
                  <option value="">Select Type</option>
                  <option value="payer">Payer</option>
                  <option value="payee">Payee</option>
                  <option value="payer/payee">Payer/Payee</option>
                </Form.Select>
              </Form.Group>
            </Col>
          </Row>

          <Form.Group className="mb-3">
            <Form.Label>Status</Form.Label>
            <Form.Select
              name="status"
              value={formData.status}
              onChange={handleChange}
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </Form.Select>
          </Form.Group>
        </Form>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button variant="primary" onClick={handleSubmit}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default AddPayerPayee
