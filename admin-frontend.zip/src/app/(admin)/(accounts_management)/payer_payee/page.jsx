import PayerPayeeList from './PayerPayeeList/PayerPayeeList'

export const metadata = {
  title: 'PayerPayeeList',
}

export default function Page() {
  return <PayerPayeeList />
}
