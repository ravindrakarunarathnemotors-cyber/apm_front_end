'use client'

import React, { useState, useEffect } from 'react'
import { Modal, Button, Form, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useUpdatePayerpayeeMutation } from '@/store/features/apiSlice'

function EditPayerPayee({ show, onHide, payerpayeeData, onSuccess }) {
    console.log("payerpayeeData",payerpayeeData)
  const [updatePayerpayee] = useUpdatePayerpayeeMutation()

  const [formData, setFormData] = useState({
    name: '',
    type: '',
    status: 'active',
  })

  useEffect(() => {
    if (payerpayeeData) {
      setFormData({
        name: payerpayeeData.name || '',
        type: payerpayeeData.type || '',
        status: payerpayeeData.status || 'active',
      })
    }
  }, [payerpayeeData])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async () => {
    try {
      await updatePayerpayee({
        id: payerpayeeData.id,
        ...formData,
      }).unwrap()

      Swal.fire('Success', 'Updated successfully!', 'success')

      onHide()
      onSuccess()
    } catch (error) {
      console.error(error)
      Swal.fire('Error', 'Failed to update.', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Payer Payee</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                />
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>Type</Form.Label>
                <Form.Select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                >
                  <option value="payer">Payer</option>
                  <option value="payee">Payee</option>
                  <option value="payer/payee">Payer/Payee</option>
                </Form.Select>
              </Form.Group>
            </Col>
          </Row>

          <Form.Group className="mb-3">
            <Form.Label>Status</Form.Label>
            <Form.Select
              name="status"
              value={formData.status}
              onChange={handleChange}
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </Form.Select>
          </Form.Group>
        </Form>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button variant="primary" onClick={handleSubmit}>
          Update
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default EditPayerPayee