'use client'

import React, { useMemo, useState, useEffect } from 'react'
import { Modal, Button, Table, Row, Col, Form, Spinner } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useFetchAccountStatementMutation } from '@/store/features/apiSlice'

function AccountStatement({ show, onHide, accountId }) {
  /* ================= FETCH HOOK ================= */
  const [fetchAccountStatement, { data, isLoading }] = useFetchAccountStatementMutation()

  /* ================= ACCOUNT DATA (UNCHANGED) ================= */
  // const accountData = {
  //   id: accountId || 1001,
  //   date: new Date(),
  //   by: 1,
  //   name: 'Main Cash Account',
  //   type: 'Asset',
  //   p_method_id: 2,
  //   description: 'Primary operational cash account',
  //   status: 'active',
  //   balance: 87500,
  // }

  /* ================= DATE FILTER ================= */
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')

  /* ================= PAGINATION STATE ================= */
  const [currentPage, setCurrentPage] = useState(1)
  const recordsPerPage = 25

  /* ================= FETCH DATA ================= */

  /* ================= MONEY FORMATTER ================= */
  const formatMoney = (value) => {
    return Number(value || 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }
  useEffect(() => {
    if (!accountId) return

    fetchAccountStatement({
      account_id: accountId,
      page: currentPage,
      limit: recordsPerPage,
      from_date: fromDate || undefined,
      to_date: toDate || undefined,
    })
  }, [accountId, currentPage, fromDate, toDate, fetchAccountStatement])
  /* ================= MAP API RESPONSE ================= */
  const currency = data?.currency || ''

  const accountData = data?.account || {}
  const transactions = useMemo(() => {
    if (!data?.transactions) return []

    return data.transactions.map((t) => ({
      id: Number(t.acc_statement_id),
      date: t.created_at,
      reference: t.reference || '-',
      by: t.by || '-',
      status: t.status,
      debit: Number(t.debit),
      credit: Number(t.credit),
      balance: Number(t.balance), // ✅ use balance from API
    }))
  }, [data])
  /* ================= RUNNING BALANCE ================= */
  // const calculatedTransactions = useMemo(() => {
  //   let runningBalance = 0

  //   return transactions.map((t) => {
  //     runningBalance = runningBalance + t.credit - t.debit
  //     return { ...t, balance: runningBalance }
  //   })
  // }, [transactions])

  /* ================= TOTALS ================= */
  const totals = useMemo(() => {
    const totalDebit = transactions.reduce((sum, t) => sum + t.debit, 0)
    const totalCredit = transactions.reduce((sum, t) => sum + t.credit, 0)

    const closingBalance = transactions.length ? transactions[0].balance : 0

    return {
      totalDebit,
      totalCredit,
      closingBalance,
    }
  }, [transactions])

  const totalPages = data?.totalPages || 1
  if (!show) return null
  return (
    <Modal show={show} onHide={onHide} fullscreen backdrop="static" keyboard={false}>
      {/* ================= HEADER ================= */}
      <Modal.Header
        className="
    border-0
    px-3
    py-2
    bg-dark
    bg-gradient
    text-white
    shadow-sm
  ">
        <div className="d-flex justify-content-between align-items-center w-100">
          {/* LEFT */}
          <div className="d-flex align-items-center gap-2">
            <div
              className="
          rounded-3
          bg-light
          bg-opacity-10
          border
          border-light
          border-opacity-10
          d-flex
          align-items-center
          justify-content-center
        "
              style={{ width: '38px', height: '38px' }}>
              <Icon icon="mdi:bank-outline" className="fs-5 text-white" />
            </div>

            <div>
              <Modal.Title className="fw-bold mb-0 fs-6">Account Statement</Modal.Title>

              <div className="small text-light text-opacity-50 lh-1">Financial overview</div>
            </div>
          </div>

          {/* RIGHT */}
          <Button
            onClick={onHide}
            className="
        rounded-circle
        border-0
        bg-light
        bg-opacity-10
        text-white
        d-flex
        align-items-center
        justify-content-center
        p-0
      "
            style={{
              width: '32px',
              height: '32px',
            }}>
            <Icon icon="mdi:close" className="fs-6" />
          </Button>
        </div>
      </Modal.Header>

      {/* ================= BODY ================= */}
      <Modal.Body className="bg-light p-4">
        {/* ================= ACCOUNT DETAILS CARD (UNCHANGED) ================= */}
        <div
          className="
    bg-white
    rounded-4
    shadow-sm
    border
    mb-4
    overflow-hidden
  ">
          {/* HEADER */}
          <div className="px-3 py-2 d-flex justify-content-between align-items-center border-bottom bg-light">
            <div className="d-flex align-items-center gap-2">
              <div className="bg-primary bg-opacity-10 rounded-3 p-2 d-flex align-items-center justify-content-center">
                <Icon icon="mdi:bank" className="text-primary fs-5" />
              </div>

              <div>
                <div className="fw-bold text-dark fs-4 lh-1">{accountData.name || 'Account'}</div>

                <div className="small text-muted fs-6">Account ID: #{accountData.id}</div>
              </div>
            </div>

            <span
              className={`badge rounded-pill px-3 py-2 ${
                accountData.status === 'active'
                  ? 'bg-success-subtle text-success border border-success-subtle'
                  : 'bg-secondary-subtle text-secondary border border-secondary-subtle'
              }`}>
              {accountData.status?.toUpperCase() || 'UNKNOWN'}
            </span>
          </div>

          {/* TILES */}
          <Row className="g-2 p-2 flex-nowrap overflow-auto align-items-stretch">
            {[
              { label: 'Created Date', value: accountData.date ? new Date(accountData.date).toLocaleDateString() : '-' },
              { label: 'Account Type', value: accountData.type || '-' },
              { label: 'Payment Method', value: accountData.p_method_id || '-' },
              { label: 'Description', value: accountData.description || '-' },
              { label: 'Created By', value: `#${accountData.by ?? '-'}` },
            ].map((item, i) => (
              <Col xs="auto" key={i}>
                <div
                  className="
            px-3 py-2
            bg-white
            border
            rounded-4
            shadow-sm
            h-100
            d-flex
            flex-column
            justify-content-center
            position-relative
            overflow-hidden
            text-dark
            tile-card
          "
                  style={{
                    minWidth: '170px',
                    cursor: 'pointer',
                  }}>
                  <div className="small text-uppercase text-muted fw-semibold mb-1">{item.label}</div>

                  <div className="fw-semibold text-truncate">{item.value}</div>

                  {/* soft hover overlay */}
                  <div className="position-absolute top-0 start-0 w-100 h-100 bg-primary opacity-0 hover-opacity-10 transition-all" />
                </div>
              </Col>
            ))}

            {/* BALANCE TILE */}
            <Col xs="auto" className="ms-auto">
              <div
                className="
          px-3 py-2
          rounded-4
          text-white
          bg-primary
          bg-gradient
          shadow-sm
          border
          h-100
          d-flex
          align-items-center
          justify-content-between
          gap-3
          position-relative
          overflow-hidden
          tile-card
        "
                style={{
                  minWidth: '190px',
                  cursor: 'pointer',
                }}>
                <div>
                  <div className="small text-uppercase fw-semibold opacity-75">Current Balance</div>

                  <div className="fw-bold fs-5 lh-1">
                    {currency} {Number(accountData.balance || 0).toLocaleString()}
                  </div>
                </div>

                <div
                  className="bg-white bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center"
                  style={{ width: 34, height: 34 }}>
                  <Icon icon="mdi:wallet-outline" className="text-white fs-6" />
                </div>
              </div>
            </Col>
          </Row>
        </div>

        {/* ================= FILTER + TABLE ================= */}
        <div className="bg-white rounded-4 shadow-sm border overflow-hidden">
          {/* HEADER (compact + high contrast) */}
          <div className="bg-white border-bottom px-3 py-2">
            <Row className="align-items-center">
              {/* LEFT TITLE */}
              <Col>
                <div className="fw-bold fs-5 text-dark lh-1">Account Statement Report</div>
                <div className="small fw-semibold text-dark">Filter and review account transactions</div>
              </Col>

              {/* RIGHT FILTERS (compact height) */}
              <Col md="auto">
                <div className="d-flex align-items-center gap-2">
                  {/* FROM */}
                  <div className="d-flex align-items-center gap-2 bg-white border rounded-3 px-2 py-1 shadow-sm">
                    <span className="small fw-bold text-dark">From</span>

                    <Form.Control
                      type="date"
                      value={fromDate}
                      onChange={(e) => {
                        setCurrentPage(1)
                        setFromDate(e.target.value)
                      }}
                      className="border-0 shadow-none bg-white text-dark"
                      style={{ width: '140px' }}
                    />
                  </div>

                  {/* TO */}
                  <div className="d-flex align-items-center gap-2 bg-white border rounded-3 px-2 py-1 shadow-sm">
                    <span className="small fw-bold text-dark">To</span>

                    <Form.Control
                      type="date"
                      value={toDate}
                      onChange={(e) => {
                        setCurrentPage(1)
                        setToDate(e.target.value)
                      }}
                      className="border-0 shadow-none bg-white text-dark"
                      style={{ width: '140px' }}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </div>

          {/* CONTENT AREA */}
          <div className="p-3 bg-white">
            {isLoading ? (
              <div className="text-center py-5">
                <Spinner />
              </div>
            ) : transactions.length === 0 ? (
              <div className="text-center py-5 text-dark fw-semibold">
                <Icon icon="mdi:file-document-outline" width={40} />
                <div className="mt-2">No Transactions Found</div>
              </div>
            ) : (
              <>
                <div className="table-responsive">
                  <Table className="align-middle mb-0 bg-white rounded-3 overflow-hidden shadow-sm" hover>
                    {/* TABLE HEADER (DARK BLUE) */}
                    <thead style={{ backgroundColor: '#0b2d4d' }}>
                      <tr>
                        <th className="fw-bold text-white fs-6">#</th>
                        <th className="text-center fw-bold text-white fs-6">Date</th>
                        <th className="fw-bold text-white fs-6">Note / Reference</th>
                        <th className="text-center fw-bold text-white fs-6">By</th>
                        <th className="text-center fw-bold text-white fs-6">Status</th>
                        <th className="text-end fw-bold text-white fs-6">Debit ({currency})</th>
                        <th className="text-end fw-bold text-white fs-6">Credit ({currency})</th>
                        <th className="text-end fw-bold text-white fs-6">Balance ({currency})</th>
                      </tr>
                    </thead>

                    {/* TABLE BODY */}
                    <tbody>
                      {transactions.map((t) => (
                        <tr key={t.id} className="border-bottom">
                          <td className="fw-semibold text-dark">{t.id}</td>

                          <td className="text-center text-dark">{new Date(t.date).toLocaleString()}</td>

                          <td className="text-dark">{t.reference || '-'}</td>

                          <td className="text-center text-dark">{t.by}</td>

                          <td className="text-center">
                            <span
                              className={`badge rounded-pill px-3 py-1 ${
                                t.status === 'Adjusted'
                                  ? 'bg-danger-subtle text-danger'
                                  : t.status === 'Active'
                                    ? 'bg-success-subtle text-success'
                                    : 'bg-secondary-subtle text-dark'
                              }`}>
                              {t.status}
                            </span>
                          </td>

                          <td className="text-end text-danger fw-semibold">{t.debit > 0 ? formatMoney(t.debit) : '-'}</td>

                          <td className="text-end text-success fw-semibold">{t.credit > 0 ? formatMoney(t.credit) : '-'}</td>

                          <td className="text-end fw-bold text-dark">{formatMoney(t.balance)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>

                {/* PAGINATION */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Button size="sm" variant="outline-dark" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                      Previous
                    </Button>

                    <span className="mx-3 align-self-center text-dark fw-semibold">
                      Page {currentPage} of {totalPages}
                    </span>

                    <Button size="sm" variant="outline-dark" disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage + 1)}>
                      Next
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer
        className="justify-content-end"
        style={{
          backgroundColor: '#d7dbe2',
          borderTop: '1px solid #d9dfe9',
          padding: '0.75rem 1rem',
          borderBottomLeftRadius: '0.5rem',
          borderBottomRightRadius: '0.5rem',
        }}>
        <Button
          variant="light"
          onClick={onHide}
          style={{
            border: '1px solid #7487a3',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}>
          <Icon icon="mdi:close" />
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default AccountStatement
