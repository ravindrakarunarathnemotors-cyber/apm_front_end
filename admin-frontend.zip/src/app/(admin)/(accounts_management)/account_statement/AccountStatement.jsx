'use client'

import React, { useMemo, useState, useEffect } from 'react'
import { Modal, Button, Table, Row, Col, Form, Spinner } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useFetchAccountStatementMutation } from '@/store/features/apiSlice'

function AccountStatement({ show, onHide, accountId }) {
  /* ================= FETCH HOOK ================= */
  const [fetchAccountStatement, { data, isLoading }] = useFetchAccountStatementMutation()

  /* ================= ACCOUNT DATA (UNCHANGED) ================= */
  // const accountData = {
  //   id: accountId || 1001,
  //   date: new Date(),
  //   by: 1,
  //   name: 'Main Cash Account',
  //   type: 'Asset',
  //   p_method_id: 2,
  //   description: 'Primary operational cash account',
  //   status: 'active',
  //   balance: 87500,
  // }

  /* ================= DATE FILTER ================= */
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')

  /* ================= PAGINATION STATE ================= */
  const [currentPage, setCurrentPage] = useState(1)
  const recordsPerPage = 25

  /* ================= FETCH DATA ================= */

  /* ================= MONEY FORMATTER ================= */
  const formatMoney = (value) => {
    return Number(value || 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }
  useEffect(() => {
    if (!accountId) return

    fetchAccountStatement({
      account_id: accountId,
      page: currentPage,
      limit: recordsPerPage,
      from_date: fromDate || undefined,
      to_date: toDate || undefined,
    })
  }, [accountId, currentPage, fromDate, toDate, fetchAccountStatement])
  /* ================= MAP API RESPONSE ================= */
  const currency = data?.currency || ''

  const accountData = data?.account || {}
  const transactions = useMemo(() => {
    if (!data?.transactions) return []

    return data.transactions.map((t) => ({
      id: Number(t.acc_statement_id),
      date: t.created_at,
      reference: t.reference || '-',
      by: t.by || '-',
      status: t.status,
      debit: Number(t.debit),
      credit: Number(t.credit),
      balance: Number(t.balance), // ✅ use balance from API
    }))
  }, [data])
  /* ================= RUNNING BALANCE ================= */
  // const calculatedTransactions = useMemo(() => {
  //   let runningBalance = 0

  //   return transactions.map((t) => {
  //     runningBalance = runningBalance + t.credit - t.debit
  //     return { ...t, balance: runningBalance }
  //   })
  // }, [transactions])

  /* ================= TOTALS ================= */
  const totals = useMemo(() => {
    const totalDebit = transactions.reduce((sum, t) => sum + t.debit, 0)
    const totalCredit = transactions.reduce((sum, t) => sum + t.credit, 0)

    const closingBalance = transactions.length ? transactions[0].balance : 0

    return {
      totalDebit,
      totalCredit,
      closingBalance,
    }
  }, [transactions])

  const totalPages = data?.totalPages || 1
  if (!show) return null
  return (
    <Modal show={show} onHide={onHide} fullscreen backdrop="static" keyboard={false}>
      {/* ================= HEADER ================= */}
      <Modal.Header className="bg-primary text-white">
        <div className="d-flex justify-content-between align-items-center w-100">
          <Modal.Title>
            <Icon icon="mdi:bank-outline" className="me-2" />
            Account Statement
          </Modal.Title>

          <Button variant="outline-light" onClick={onHide}>
            <Icon icon="mdi:close" />
          </Button>
        </div>
      </Modal.Header>

      {/* ================= BODY ================= */}
      <Modal.Body className="bg-light p-4">
        {/* ================= ACCOUNT DETAILS CARD (UNCHANGED) ================= */}
        <div className="bg-white p-4 rounded-4 shadow-sm mb-4 border">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <h5 className="fw-bold mb-1">
                <Icon icon="mdi:bank" className="me-2 text-primary" />
                {accountData.name || 'Account'}
              </h5>
              <div className="text-muted small">Account ID: #{accountData.id}</div>
            </div>

            <div className={`badge px-3 py-2 fs-6 ${accountData.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
              {accountData.status?.toUpperCase() || 'UNKNOWN'}
            </div>
          </div>

          <Row className="g-3 flex-nowrap overflow-auto align-items-stretch">
            <Col xs="auto">
              <div className="p-3 bg-light rounded-3 border h-100" style={{ minWidth: '190px' }}>
                <div className="text-muted small">Created Date</div>
                <div className="fw-semibold">{accountData.date ? new Date(accountData.date).toLocaleDateString() : '-'}</div>
              </div>
            </Col>

            <Col xs="auto">
              <div className="p-3 bg-light rounded-3 border h-100" style={{ minWidth: '190px' }}>
                <div className="text-muted small">Account Type</div>
                <div className="fw-semibold">{accountData.type || '-'}</div>
              </div>
            </Col>

            <Col xs="auto">
              <div className="p-3 bg-light rounded-3 border h-100" style={{ minWidth: '190px' }}>
                <div className="text-muted small">Payment Method ID</div>
                <div className="fw-semibold">{accountData.p_method_id || '-'}</div>
              </div>
            </Col>

            <Col xs="auto">
              <div className="p-3 bg-light rounded-3 border h-100" style={{ minWidth: '190px' }}>
                <div className="text-muted small">Description</div>
                <div>{accountData.description || '-'}</div>
              </div>
            </Col>

            <Col xs="auto">
              <div className="p-3 bg-light rounded-3 border h-100" style={{ minWidth: '190px' }}>
                <div className="text-muted small">Created By (User ID)</div>
                <div className="fw-semibold"> #{accountData.by ?? '-'}</div>
              </div>
            </Col>

            <Col xs="auto" className="ms-auto">
              <div className="p-3 bg-primary text-white rounded-3 h-100" style={{ minWidth: '190px' }}>
                <div className="small">Current Balance</div>
                <div className="fw-bold fs-5">
                  {currency} {Number(accountData.balance || 0).toLocaleString()}
                </div>
              </div>
            </Col>
          </Row>
        </div>

        {/* ================= FILTER + TABLE ================= */}
        <div className="bg-white p-4 rounded shadow-sm">
          <Row className="mb-3">
            <Col md={3}>
              <Form.Group>
                <Form.Label>From Date</Form.Label>
                <Form.Control
                  type="date"
                  value={fromDate}
                  onChange={(e) => {
                    setCurrentPage(1)
                    setFromDate(e.target.value)
                  }}
                />
              </Form.Group>
            </Col>

            <Col md={3}>
              <Form.Group>
                <Form.Label>To Date</Form.Label>
                <Form.Control
                  type="date"
                  value={toDate}
                  onChange={(e) => {
                    setCurrentPage(1)
                    setToDate(e.target.value)
                  }}
                />
              </Form.Group>
            </Col>
          </Row>

          {isLoading ? (
            <div className="text-center py-5">
              <Spinner />
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-5 text-muted">
              <Icon icon="mdi:file-document-outline" width={40} />
              <div className="mt-3 fw-semibold">No Transactions Made Yet</div>
            </div>
          ) : (
            <>
              <div className="table-responsive">
                <Table bordered hover className="align-middle">
                  <thead className="table-dark">
                    <tr>
                      <th>#</th>
                      <th className="text-center">Date</th>
                      <th>Note/Reference</th>
                      <th className="text-center">By</th>
                      <th className="text-center">Status</th>
                      <th className="text-end">Debit ({currency})</th>
                      <th className="text-end">Credit ({currency})</th>
                      <th className="text-end">Balance ({currency})</th>
                    </tr>
                  </thead>

                  <tbody>
                    {transactions.map((t, index) => {
                      const referenceText = t.reference || '-'

                      return (
                        <tr key={t.id}>
                          <td>{t.id}</td>

                          <td className="text-center">{new Date(t.date).toLocaleString()}</td>

                          <td>{referenceText}</td>

                          <td className="text-center">{t.by}</td>

                          <td className="text-center">
                            <span
                              className={`badge text-capitalize ${
                                t.status === 'Adjusted' ? 'bg-danger' : t.status === 'Active' ? 'bg-success' : 'bg-secondary'
                              }`}>
                              {t.status}
                            </span>
                          </td>

                          <td className="text-end text-danger fw-semibold">{t.debit > 0 ? formatMoney(t.debit) : '-'}</td>
                          <td className="text-end text-success fw-semibold">{t.credit > 0 ? formatMoney(t.credit) : '-'}</td>
                          <td className="text-end fw-bold">{formatMoney(t.balance)}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </Table>
              </div>

              {totalPages > 1 && (
                <div className="d-flex justify-content-end mt-3">
                  <Button size="sm" variant="outline-secondary" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                    Previous
                  </Button>

                  <span className="mx-3 align-self-center">
                    Page {currentPage} of {totalPages}
                  </span>

                  <Button size="sm" variant="outline-secondary" disabled={currentPage === totalPages} onClick={() => setCurrentPage(currentPage + 1)}>
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </Modal.Body>

      <Modal.Footer className="justify-content-end">
        <Button variant="secondary" onClick={onHide}>
          <Icon icon="mdi:close" className="me-1" />
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default AccountStatement
