'use client'

import React, { useEffect, useState } from 'react'
import { Modal, Button, Form, Row, Col, Badge } from 'react-bootstrap'
import Swal from 'sweetalert2'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useAdjustAccountBalanceMutation } from '@/store/features/apiSlice'

function AdjustBalance({ show, onHide, accountData, currency, onSuccess }) {
  const [currentBalance, setCurrentBalance] = useState(0)
  const [newBalance, setNewBalance] = useState('')
  const [reason, setReason] = useState('')

  const [adjustAccountBalance, { isLoading }] = useAdjustAccountBalanceMutation()

  const currencySymbol = currency || accountData?.currency_symbol || ''

  const formatAmount = (value) => {
    return Number(value || 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  }

  const normalizeInput = (value) => {
    if (value === '') return ''
    return Number(value).toFixed(2)
  }

  useEffect(() => {
    if (accountData) {
      setCurrentBalance(Number(accountData.balance) || 0)
      setNewBalance('')
      setReason('')
    }
  }, [accountData])

  const handleSubmit = async () => {
    if (newBalance === '') {
      Swal.fire('Error', 'Please enter the new balance.', 'error')
      return
    }

    if (!reason.trim()) {
      Swal.fire('Error', 'Please enter a reason.', 'error')
      return
    }

    const normalizedBalance = Number(newBalance).toFixed(2)

    const result = await Swal.fire({
      title: 'Confirm Balance Update',
      html: `
        <div style="text-align:left">
        <b>Account ID:</b> ${accountData.id}<br/>
        <b>Account Name:</b> ${accountData.name}<br/>
        <b>Status:</b> ${accountData.status}<br/><br/>

        <b>Current Balance:</b> ${currencySymbol} ${formatAmount(currentBalance)}<br/>
        <b>New Balance:</b> ${currencySymbol} ${formatAmount(normalizedBalance)}<br/><br/>

        <b>Reason:</b><br/>
        ${reason}
        </div>
      `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Update Balance',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      await adjustAccountBalance({
        account_id: accountData.id,
        new_balance: Number(normalizedBalance),
        reason: reason,
      }).unwrap()

      Swal.fire('Success', 'Account balance updated successfully.', 'success')

      if (onSuccess) onSuccess()

      onHide()
    } catch (error) {
      console.error(error)
      Swal.fire('Error', 'Failed to update balance.', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} centered size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          <IconifyIcon icon="mdi:scale-balance" className="me-2" />
          Account Balance Adjustment
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {!accountData ? (
          <p>No account selected</p>
        ) : (
          <>
            {/* Account Details */}
            <div className="border rounded p-3 mb-4 bg-light">
              <Row className="align-items-center">
                <Col md={3}>
                  <strong>ID</strong>
                  <div>{accountData.id}</div>
                </Col>

                <Col md={3}>
                  <strong>Account Name</strong>
                  <div>{accountData.name}</div>
                </Col>

                <Col md={3}>
                  <strong>Status</strong>
                  <div>
                    <Badge bg={accountData.status === 'active' ? 'success' : 'danger'}>
                      {accountData.status?.charAt(0).toUpperCase() + accountData.status?.slice(1)}
                    </Badge>
                  </div>
                </Col>

                <Col md={3}>
                  <strong>Current Balance</strong>
                  <div className="fw-bold">
                    {currencySymbol} {formatAmount(currentBalance)}
                  </div>
                </Col>
              </Row>
            </div>

            {/* New Balance + Reason Row */}
            <Row>
              <Col md={4}>
                <Form.Group>
                  <Form.Label>New Balance ({currencySymbol})</Form.Label>

                  <Form.Control
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={newBalance}
                    onChange={(e) => setNewBalance(e.target.value)}
                    onBlur={(e) => setNewBalance(normalizeInput(e.target.value))}
                  />
                </Form.Group>
              </Col>

              <Col md={8}>
                <Form.Group>
                  <Form.Label>Reason</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={2}
                    maxLength={250}
                    placeholder="Reason for balance correction"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                  <small className="text-muted">{reason.length}/250 characters</small>
                </Form.Group>
              </Col>
            </Row>
          </>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>

        <Button
          disabled={isLoading}
          className="bg-primary border border-primary"
          onClick={handleSubmit}
        >
          <IconifyIcon icon="mdi:check" className="me-1" />
          {isLoading ? 'Updating...' : 'Update Balance'}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default AdjustBalance