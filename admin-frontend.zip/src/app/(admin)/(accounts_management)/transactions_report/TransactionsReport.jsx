'use client'

import React, { useState, useMemo } from 'react'
import { Icon } from '@iconify/react'
import { Card, CardBody, CardHeader, CardTitle, Form, Button, Row, Col, Table, Pagination, Spinner } from 'react-bootstrap'
import Select, { components } from 'react-select'
import {
  useGetTransactionsAdvancedQuery,
  useGetActiveAccountsQuery,
  useGetActiveAccountCategoriesQuery,
  useFetchPayerPayeesQuery,
  useGetApprovedTransactionsSummaryQuery,
} from '@/store/features/apiSlice'

/* ===================== CHECKBOX OPTION ===================== */

const Option = (props) => (
  <components.Option {...props}>
    <input type="checkbox" checked={props.isSelected} onChange={() => null} className="me-2" />
    {props.label}
  </components.Option>
)

/* ===================== COMPACT MULTI VALUE ===================== */

const MultiValueContainer = ({ selectProps, data }) => {
  const selected = selectProps.value || []
  if (selected.length > 1) {
    return null
  }
  return <components.MultiValueContainer {...{ selectProps, data }} />
}

const ValueContainer = ({ children, ...props }) => {
  const { getValue } = props
  const selected = getValue()

  if (selected.length > 1) {
    return <components.ValueContainer {...props}>{selected.length} selected</components.ValueContainer>
  }

  return <components.ValueContainer {...props}>{children}</components.ValueContainer>
}

/* ================================================================ */

function TransactionsReport() {
  const getStatusBadge = (status) => {
    if (!status) return 'bg-secondary'
    if (status === 'approved') return 'bg-success'
    if (status === 'pending') return 'bg-warning text-dark'
    return 'bg-danger'
  }

  const formatStatus = (status) => {
    if (!status) return 'N/A'
    return status.charAt(0).toUpperCase() + status.slice(1)
  }

  const getTxIcon = (type) => {
    if (type === 'income') return 'mdi:arrow-down-bold-circle'
    if (type === 'expense') return 'mdi:arrow-up-bold-circle'
    if (type === 'transfer') return 'mdi:swap-horizontal-bold'
    return 'mdi:circle-outline'
  }

  const transactionTypeOptions = [
    { value: 'income', label: 'Income' },
    { value: 'expense', label: 'Expense' },
    { value: 'transfer', label: 'Transfer' },
  ]

  const { data: accountsData, isLoading: accountsLoading } = useGetActiveAccountsQuery()
  const { data: categoriesData, isLoading: categoriesLoading } = useGetActiveAccountCategoriesQuery()
  const { data: payerPayeesData } = useFetchPayerPayeesQuery()

  const accountOptions = useMemo(() => accountsData?.data?.map((acc) => ({ value: acc.id, label: acc.name })) || [], [accountsData])

  const categoryOptions = useMemo(() => categoriesData?.data?.map((cat) => ({ value: cat.category_id, label: cat.name })) || [], [categoriesData])

  const payerPayeeOptions = useMemo(() => payerPayeesData?.payer_payees?.map((p) => ({ value: p.id, label: p.name })) || [], [payerPayeesData])

  /* ===================== FILTER STATES ===================== */

  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [typeFilter, setTypeFilter] = useState([])
  const [categoryFilter, setCategoryFilter] = useState([])
  const [accountFilter, setAccountFilter] = useState([])
  const [payerFilter, setPayerFilter] = useState([])

  const [currentPage, setCurrentPage] = useState(1)

  const [appliedFilters, setAppliedFilters] = useState({ page: 1 })

  /* ===================== QUERY ===================== */

  const { data, isLoading, isFetching, isError } = useGetTransactionsAdvancedQuery(appliedFilters)

  const { data: summaryData, isLoading: summaryLoading } = useGetApprovedTransactionsSummaryQuery()

  const transactions = data?.data || []
  const totalPages = data?.total_pages || 1
  const currency = data?.currency || ''
  const totalIncome = summaryData?.total_income || 0
  const totalExpense = summaryData?.total_expense || 0
  /* ===================== SEARCH ===================== */

  const handleSearch = () => {
    setCurrentPage(1)

    setAppliedFilters({
      page: 1,
      from: fromDate || undefined,
      to: toDate || undefined,
      transaction_type: typeFilter.map((t) => t.value).join(',') || undefined,
      category_id: categoryFilter.map((c) => c.value).join(',') || undefined,
      account_id: accountFilter.map((a) => a.value).join(',') || undefined,
      payer_payee_id: payerFilter.map((p) => p.value).join(',') || undefined,
    })
  }

  const handlePageChange = (page) => {
    setCurrentPage(page)
    setAppliedFilters((prev) => ({ ...prev, page }))
  }

  const formatDate = (date) => {
    if (!date) return ''
    return new Date(date).toISOString().split('T')[0]
  }

  const handlePrint = () => window.print()

  const printedTime = new Date().toLocaleString()

  /* ===================== FILTER SUMMARY ===================== */

  const filterSummary = [
    fromDate && `From: ${fromDate}`,
    toDate && `To: ${toDate}`,
    typeFilter.length && `Type: ${typeFilter.map((x) => x.label).join(', ')}`,
    categoryFilter.length && `Category: ${categoryFilter.map((x) => x.label).join(', ')}`,
    accountFilter.length && `Account: ${accountFilter.map((x) => x.label).join(', ')}`,
    payerFilter.length && `Payer/Payee: ${payerFilter.map((x) => x.label).join(', ')}`,
  ]
    .filter(Boolean)
    .join(' | ')

  return (
    <Card className="shadow-sm">
      <style>
        {`

/* Screen vs Print toggle */

.screen-type{
  display:inline;
}

.print-type{
  display:none;
}

/* ================= PRINT STYLE ================= */

@media print {

  html, body{
    background:#fff !important;
    color:#000 !important;
    font-family: Arial, Helvetica, sans-serif;
    font-size:10px;
  }

  @page{
    size:A4 portrait;
    margin:6mm;
  }

  .no-print{
    display:none !important;
  }

  .card{
    border:none !important;
    box-shadow:none !important;
    background:#fff !important;
  }

  .card-body{
    padding:0 !important;
  }

  /* ===== HEADER ===== */

 .print-header{
  text-align:center;
  margin-bottom:12px;   /* space before table */
}

.print-header h3{
  margin-bottom:6px;
}

.print-filters{
  margin-bottom:6px;
}

.print-header hr{
  margin:8px 0 12px 0;
  border-top:1px solid #000;
}
  .print-header h3{
    margin:0;
    font-size:15px;
    font-weight:700;
  }

  .print-filters{
    font-size:9px;
    color:#444;
    margin-top:2px;
  }

  .print-header hr{
    margin:4px 0;
    border-top:1px solid #000;
  }
/* ===== TABLE ===== */

table{
  width:100% !important;
  border-collapse:collapse !important;
  font-size:9.3px;
  table-layout:auto !important;
}

thead{
  display:table-header-group;
}

table th{
  border:0.6px solid #555;
  padding:3px 5px;
  background:#f6f6f6 !important;
  font-weight:600;
  white-space:nowrap;
}

table td{
  border:0.6px solid #666;
  padding:3px 5px;
  line-height:1.2;
  white-space:nowrap;
}

table tbody tr:nth-child(even){
  background:#fafafa;
}
  /* ===== TRANSACTION ICONS ===== */

  .screen-type{
    display:none !important;
  }

  .print-type{
    display:inline !important;
  }

  .tx-icon{
    font-size:14px;
    vertical-align:middle;
  }

  .tx-income .tx-icon{
    color:#198754;
  }

  .tx-expense .tx-icon{
    color:#dc3545;
  }

  .tx-transfer .tx-icon{
    color:#0d6efd;
  }

  /* ===== HIDE BOOTSTRAP BADGES ===== */

  .badge{
    display:none !important;
  }

/* ===== TOTALS ===== */

.d-flex.justify-content-end.mb-3{
  margin-top:6px;
  font-size:9.6px;
}

/* outer totals container */
.d-flex.justify-content-end.mb-3 > div{
  border:0.6px solid #666 !important;
  background:#fff !important;
  padding:2px 8px !important;
  gap:14px !important;
  border-radius:2px;
  align-items:center;
}

/* each total block */
.d-flex.justify-content-end.mb-3 > div > div{
  border:none !important;
  background:none !important;
  color:#000 !important;
  padding:0 !important;
  min-width:auto !important;
  font-size:9.6px !important;
  font-weight:600;
  display:flex;
  gap:6px;
  align-items:center;
}

/* label */
.d-flex.justify-content-end.mb-3 > div > div div:first-child{
  font-size:9px !important;
  font-weight:500;
  opacity:0.8;
}

/* amount */
.d-flex.justify-content-end.mb-3 > div > div div:last-child{
  font-size:10px !important;
  font-weight:700 !important;
}
  /* ===== FOOTER ===== */

  .print-footer{
    position:fixed;
    bottom:4mm;
    left:0;
    right:0;
    text-align:center;
    font-size:9px;
    color:#555;
  }

  /* ===== TRANSACTION KEY MAP ===== */

.transaction-key{
  margin-top:6px;
  font-size:9px;
  display:flex;
  gap:12px;
  justify-content:flex-start;
}

}

`}
      </style>

      <CardHeader className="py-3 bg-light d-flex justify-content-between align-items-center no-print">
        <CardTitle className="mb-0">Transactions Report</CardTitle>

        <Button style={{ backgroundColor: '#6f42c1', borderColor: '#6f42c1' }} onClick={handlePrint}>
          <Icon icon="mdi:printer-outline" className="me-1" />
          Print
        </Button>
      </CardHeader>

      <CardBody>
        {/* ===================== PRINT HEADER ===================== */}

        <div className="print-header d-none d-print-block">
          <h3>Transactions Report</h3>

          {filterSummary && <div className="print-filters">Filters: {filterSummary}</div>}

          <hr />
        </div>

        {/* ===================== FILTERS ===================== */}

        <Row className="mb-3 align-items-end no-print">
          <Col md={2}>
            <Form.Label>From</Form.Label>
            <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
          </Col>

          <Col md={2}>
            <Form.Label>To</Form.Label>
            <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
          </Col>

          <Col md={2}>
            <Form.Label>Type</Form.Label>
            <Select
              options={transactionTypeOptions}
              value={typeFilter}
              onChange={setTypeFilter}
              isMulti
              closeMenuOnSelect={false}
              components={{ Option, MultiValueContainer, ValueContainer }}
            />
          </Col>

          <Col md={2}>
            <Form.Label>Category</Form.Label>
            {categoriesLoading ? (
              <Spinner size="sm" />
            ) : (
              <Select
                options={categoryOptions}
                value={categoryFilter}
                onChange={setCategoryFilter}
                isMulti
                closeMenuOnSelect={false}
                components={{ Option, MultiValueContainer, ValueContainer }}
              />
            )}
          </Col>

          <Col md={2}>
            <Form.Label>Account</Form.Label>
            {accountsLoading ? (
              <Spinner size="sm" />
            ) : (
              <Select
                options={accountOptions}
                value={accountFilter}
                onChange={setAccountFilter}
                isMulti
                closeMenuOnSelect={false}
                components={{ Option, MultiValueContainer, ValueContainer }}
              />
            )}
          </Col>

          <Col md={2} className="d-flex">
            <Button className="w-100" onClick={handleSearch}>
              Search
            </Button>
          </Col>
        </Row>

        {/* ===================== TABLE ===================== */}

        <Table bordered hover responsive className="text-center align-middle">
          <thead className="table-light">
            <tr>
              <th>ID</th>
              <th>Date</th>
              <th>Type</th>
              <th>Category</th>
              <th>Account</th>
              <th>Payer/Payee</th>
              <th>Note</th>
              <th>Status</th>
              <th>By</th>
              <th className="text-end">Amount {currency ? `(${currency})` : ''}</th>
            </tr>
          </thead>

          <tbody>
            {isLoading || isFetching ? (
              <tr>
                <td colSpan="10" className="text-center">
                  <Spinner animation="border" size="sm" /> Loading...
                </td>
              </tr>
            ) : isError ? (
              <tr>
                <td colSpan="10" className="text-danger text-center">
                  Error fetching transactions
                </td>
              </tr>
            ) : transactions.length > 0 ? (
              transactions.map((tx) => (
                <tr key={tx.transaction_id}>
                  <td>{tx.transaction_id}</td>

                  <td>{formatDate(tx.transaction_date)}</td>

                  <td>
                    {/* Screen view → Capitalized text */}
                    <span className="screen-type">
                      {tx.transaction_type ? tx.transaction_type.charAt(0).toUpperCase() + tx.transaction_type.slice(1) : ''}
                    </span>

                    {/* Print view → Icon */}
                    <span className={`print-type tx-${tx.transaction_type}`}>
                      <Icon icon={getTxIcon(tx.transaction_type)} className="tx-icon" />
                    </span>
                  </td>
                  <td>{tx.category_name || '-'}</td>

                  <td>{tx.account_name}</td>

                  <td>{tx.payer_payee || 'N/A'}</td>

                  <td className="text-start">{tx.note || '-'}</td>

                  <td>
                    <span className={`badge ${getStatusBadge(tx.payment_status)}`}>{formatStatus(tx.payment_status)}</span>

                    <span className="d-none d-print-inline">{formatStatus(tx.payment_status)}</span>
                  </td>

                  <td>
                    #{tx.by} {tx.first_name}
                  </td>

                  <td className="text-end">{tx.amount}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="10" className="text-center">
                  No transactions found
                </td>
              </tr>
            )}
          </tbody>
        </Table>

        {/* ===================== TOTALS ===================== */}

        <div className="d-flex justify-content-end mb-3">
          {summaryLoading ? (
            <Spinner size="sm" />
          ) : (
            <div
              className="d-flex gap-3 px-3 py-2"
              style={{
                border: '2px solid #dee2e6',
                borderRadius: '8px',
                background: '#f8f9fa',
              }}>
              <div
                className="px-3 py-2 fw-semibold"
                style={{
                  border: '1px solid #28a745',
                  borderRadius: '6px',
                  background: '#eaf7ee',
                  color: '#198754',
                  minWidth: '170px',
                }}>
                <div style={{ fontSize: '12px', opacity: 0.8 }}>Total Income</div>
                <div style={{ fontSize: '16px', fontWeight: '700' }}>
                  {currency} {totalIncome}
                </div>
              </div>

              <div
                className="px-3 py-2 fw-semibold"
                style={{
                  border: '1px solid #dc3545',
                  borderRadius: '6px',
                  background: '#fdeaea',
                  color: '#dc3545',
                  minWidth: '170px',
                }}>
                <div style={{ fontSize: '12px', opacity: 0.8 }}>Total Expense</div>
                <div style={{ fontSize: '16px', fontWeight: '700' }}>
                  {currency} {totalExpense}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ===================== TRANSACTION ICON KEY (PRINT ONLY) ===================== */}

        <div className="transaction-key d-none d-print-flex">
          <div className="d-flex align-items-center gap-2">
            <Icon icon="mdi:arrow-down-bold-circle" style={{ color: '#198754', fontSize: '18px' }} />
            <span>Income</span>
          </div>

          <div className="d-flex align-items-center gap-2">
            <Icon icon="mdi:arrow-up-bold-circle" style={{ color: '#dc3545', fontSize: '18px' }} />
            <span>Expense</span>
          </div>

          <div className="d-flex align-items-center gap-2">
            <Icon icon="mdi:swap-horizontal-bold" style={{ color: '#0d6efd', fontSize: '18px' }} />
            <span>Transfer</span>
          </div>
        </div>
        <div className="d-flex justify-content-end no-print">
          <Pagination>
            {(() => {
              const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
              const pages = []

              let start = safeCurrent - 2
              let end = safeCurrent + 2

              if (totalPages <= 5) {
                start = 1
                end = totalPages
              } else {
                if (start < 1) {
                  start = 1
                  end = 5
                }
                if (end > totalPages) {
                  end = totalPages
                  start = totalPages - 4
                }
              }

              for (let i = start; i <= end; i++) {
                pages.push(
                  <Pagination.Item key={i} active={i === safeCurrent} onClick={() => handlePageChange(i)}>
                    {i}
                  </Pagination.Item>,
                )
              }

              return (
                <>
                  {/* FIRST */}
                  <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(1)}>
                    First
                  </Pagination.Item>

                  {/* PREV */}
                  <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(safeCurrent - 1)}>
                    {'<'}
                  </Pagination.Item>

                  {pages}

                  {/* NEXT */}
                  <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(safeCurrent + 1)}>
                    {'>'}
                  </Pagination.Item>

                  {/* LAST */}
                  <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(totalPages)}>
                    Last
                  </Pagination.Item>
                </>
              )
            })()}
          </Pagination>
        </div>

        {/* ===================== PRINT FOOTER ===================== */}

        <div className="print-footer d-none d-print-block">
          <hr />

          <div>Printed on: {printedTime}</div>
        </div>
      </CardBody>
    </Card>
  )
}

export default TransactionsReport
