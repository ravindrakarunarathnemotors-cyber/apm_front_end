import TransactionReport from './TransactionsReport'

export const metadata = {
  title: 'Transactions Report',
}

export default function Page() {
  return <TransactionReport />
}