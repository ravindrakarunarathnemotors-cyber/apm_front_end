import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Reorder Level',
}

const Reorder = dynamic(() => import('./Reorder'), { ssr: false })

export default function ReorderPage() {
  return <Reorder />
}