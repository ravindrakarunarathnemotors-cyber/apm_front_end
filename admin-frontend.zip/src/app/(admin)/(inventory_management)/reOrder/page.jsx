'use client'

import React, { useState, useEffect } from 'react'
import { Card, CardBody, CardHeader, CardTitle, Col, Row, Table, Form, FormGroup, FormLabel, Button, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import AsyncSelect from 'react-select/async'
import { debounce } from 'lodash'
import { useSearchProductVariantsQuery, useSearchReorderLevelQuery } from '@/store/features/apiSlice'
import { skipToken } from '@reduxjs/toolkit/query'

function Reorder() {
  const [expandedRows, setExpandedRows] = useState({})
  const [reorderlevel, setReorderlevel] = useState('')
  const [collection, setCollection] = useState('')
  const [reorderdate, setReorderdate] = useState('')
  const [brandId, setBrandId] = useState('')
  const [selectedReorders, setSelectedReorders] = useState(null)
  const [logs, setLogs] = useState([])
  const [currentMeasurementLabel, setCurrentMeasurementLabel] = useState('')
  const [searchTerm, setSearchTerm] = useState('')

  // const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const logsPerPage = 15
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [submittedSearch, setSubmittedSearch] = useState(null)

  const { data: reorderData, isFetching: isFetchingReorders } = useSearchReorderLevelQuery(
    submittedSearch
      ? {
          query: submittedSearch.query,
          reorderlevel: submittedSearch.reorderlevel,
          fromDate: submittedSearch.fromDate,
          toDate: submittedSearch.toDate,
          page: submittedSearch.page,
          limit: logsPerPage,
        }
      : skipToken,
  )

  const { data: productResults, isLoading: isProductLoading } = useSearchProductVariantsQuery(
    searchTerm && searchTerm.length >= 2 ? { query: searchTerm } : skipToken,
  )

  const debouncedSearchProduct = React.useMemo(
    () =>
      debounce((value) => {
        const v = typeof value === 'string' ? value.trim() : ''
        setSearchTerm(v)
      }, 300),
    [],
  )

  useEffect(() => {
    return () => debouncedSearchProduct.cancel()
  }, [debouncedSearchProduct])

  const reorderlevelOptions = [
    { value: 'reached', label: 'Reached' },
    { value: 'near to reach', label: 'Near to Reach' },
  ]

  const loadProductOptions = async (inputValue) => {
    setSearchTerm(inputValue)
    if (!productResults?.results) return []
    return productResults.results.map((item) => ({
      value: item.product_id,
      label: `${item.title} (${item.product_id})`,
      name: item.title,
    }))
  }
  const updateSearch = (page = 1) => {
    setCurrentPage(page)
    setSubmittedSearch({
      query:
        selectedReorders?.type === 'product'
          ? String(selectedReorders.value)
          : selectedReorders?.type === 'variant'
            ? String(selectedReorders.value)
            : '',
      reorderlevel,
      fromDate,
      toDate,
      page,
    })
  }
  // eslint-disable-next-line react-hooks/exhaustive-deps

  useEffect(() => {
    updateSearch(1)
  }, [])

  useEffect(() => {
    if (reorderData) {
      const formattedLogs = reorderData.results.map((item) => ({
        id: item.variant_id,
        title: `${item.product_title} - ${item.variant_value}`,
        reorderDays: item.reorder_level_reached_days ?? '-',
        stock: item.current_stock ?? '-',
        reorderLevel: item.reorder_level ?? '-',
        measurement: item.measurement_value ?? '', // bind measurement value with variant
        stockStatus: item.stock_status ?? '',
      }))
      setLogs(formattedLogs)

      // 👇 Add this to update the header unit
      if (reorderData.results.length > 0) {
        setCurrentMeasurementLabel(reorderData.results[0].measurement_value || '')
      } else {
        setCurrentMeasurementLabel('')
      }

      setTotalPages(reorderData.totalPages || 1)
    }
  }, [reorderData])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    updateSearch(pageNumber)
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  const toggleRow = (id) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <CardTitle as="h4" className="mb-0">
              Re -Order Level
            </CardTitle>
          </CardHeader>

          <CardBody>
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-3">
                <FormLabel>Product (ID, Name, Variant)</FormLabel>
                <Select
                  options={
                    productResults?.results?.flatMap((product) => {
                      const baseOption = {
                        value: product.product_id,
                        label: `🛒 ${product.title} (${product.product_id})`,
                        type: 'product',
                      }

                      const variantOptions = (product.variants || []).map((variant) => ({
                        value: variant.variant_id,
                        label: `🔹 ${product.title} - ${variant.variant_value} (${variant.variant_id}${variant.sku ? ` | SKU: ${variant.sku}` : ''}${variant.barcode ? ` | Barcode: ${variant.barcode}` : ''})`,
                        product_id: product.product_id,
                        variant_value: variant.variant_value,
                        sku: variant.sku,
                        barcode: variant.barcode,
                        type: 'variant',
                      }))

                      return [baseOption, ...variantOptions]
                    }) || []
                  }
                  onInputChange={(value, { action }) => {
                    if (action !== 'input-change') return
                    debouncedSearchProduct(value)
                  }}
                  onChange={(option) => {
                    setSelectedReorders(option)

                    if (!option) {
                      setBrandId('')
                      setCollection('')
                      return
                    }

                    setBrandId(option.product_id || option.value || '')
                    setCollection(option.label || '')
                  }}
                  isClearable
                  isLoading={isProductLoading}
                  value={selectedReorders}
                  placeholder="Search product..."
                  filterOption={null}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Re-Order Level</FormLabel>
                <Select
                  options={reorderlevelOptions}
                  isClearable //it show an "x" to clear
                  value={reorderlevelOptions.find((option) => option.value === reorderlevel) || null}
                  onChange={(selectedOption) => {
                    console.log('Reorder Level changed:', selectedOption?.value)
                    setReorderlevel(selectedOption?.value || '')
                  }}
                  placeholder="Select Re-Order Level"
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>

              <FormGroup className="col-md-2">
                <Form.Label>From Date</Form.Label>
                <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2">
                <Form.Label>To Date</Form.Label>
                <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-3 d-flex align-items-end gap-2">
                <Button variant="primary" className="btn bg-primary border-1 border-primary flex-grow-1 " onClick={() => updateSearch(1)}>
                  Search
                </Button>
              </FormGroup>
            </Form>

            {isFetchingReorders ? (
              <p>Loading Re-Order...</p>
            ) : (
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Product/Variant</th>
                      {/* <th>Measurement Unit</th> */}
                      {/* <th>Re-order level reached days</th> */}
                      <th>Stock Status</th>
                      <th className="text-end pe-2">Re-Order Level</th>
                      <th className="text-end pe-2">Current Stock</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan="6" className="text-center">
                          No results found.
                        </td>
                      </tr>
                    ) : (
                      logs.map((log) => (
                        <tr key={log.id}>
                          <td>{log.id}</td>
                          <td>{log.title}</td>
                          {/* <td>{log.reorderDays}</td> */}
                          <td>
                            {log.stockStatus === 'out_of_stock' && <span className="badge bg-danger">Out of Stock</span>}
                            {log.stockStatus === 'reorder_level_reached' && <span className="badge bg-warning text-dark">Reorder Reached</span>}
                            {log.stockStatus === 'low_stock' && <span className="badge bg-info text-dark">Low Stock</span>}
                            {log.stockStatus === 'in_stock' && <span className="badge bg-primary">In Stock</span>}
                          </td>
                          <td className="text-end pe-2">{log.reorderLevel}</td>
                          <td className="text-end pe-2">
                            {log.stock}
                            {log.measurement && (
                              <span style={{ fontWeight: 'normal', color: 'inherit', fontSize: 'inherit' }}> ({log.measurement})</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </Table>

                <div className="d-flex justify-content-end mt-3">
                  {/* ================= PAGINATION ================= */}
                  {totalPages > 1 && (
                    <div className="d-flex justify-content-end mt-3">
                      <Pagination>
                        {(() => {
                          const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                          const pages = []

                          let start = safeCurrent - 2
                          let end = safeCurrent + 2

                          if (totalPages <= 5) {
                            start = 1
                            end = totalPages
                          } else {
                            if (start < 1) {
                              start = 1
                              end = 5
                            }
                            if (end > totalPages) {
                              end = totalPages
                              start = totalPages - 4
                            }
                          }

                          for (let i = start; i <= end; i++) {
                            pages.push(
                              <Pagination.Item key={i} active={i === safeCurrent} onClick={() => handlePageChange(i)}>
                                {i}
                              </Pagination.Item>,
                            )
                          }

                          return (
                            <>
                              {/* FIRST */}
                              <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(1)}>
                                First
                              </Pagination.Item>

                              {/* PREV (<) */}
                              <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(safeCurrent - 1)}>
                                {'<'}
                              </Pagination.Item>

                              {pages}

                              {/* NEXT (>) */}
                              <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(safeCurrent + 1)}>
                                {'>'}
                              </Pagination.Item>

                              {/* LAST */}
                              <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(totalPages)}>
                                Last
                              </Pagination.Item>
                            </>
                          )
                        })()}
                      </Pagination>
                    </div>
                  )}
                </div>
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default Reorder
