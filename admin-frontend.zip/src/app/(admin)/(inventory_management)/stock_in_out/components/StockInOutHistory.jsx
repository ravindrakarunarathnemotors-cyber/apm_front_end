import { Card, CardHeader, CardBody, CardTitle, Table, Spinner, Button, Form, FormGroup, FormLabel } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Pagination from '@/components/Pagination'
import { useEffect, useState } from 'react'
import { useGetStockSheetHistoryMutation, useUpdateStockRemarkMutation } from '@/store/features/apiSlice'
import ViewSheetDetails from './ViewSheetDetails'
// import { Modal } from "react-bootstrap";

const StockInOutHistory = () => {
  const [getStockSheetHistory, { data, isLoading, isError }] = useGetStockSheetHistoryMutation()

  const [updateStockRemark, { isLoading: isUpdatingRemark }] = useUpdateStockRemarkMutation()

  // Filter states
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [sheetId, setSheetId] = useState('')
  const [stockType, setStockType] = useState('')
  const [outlet, setOutlet] = useState('')
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const [selectedSheet, setSelectedSheet] = useState(null)
  const [modalShow, setModalShow] = useState(false)
  const [editRemark, setEditRemark] = useState('')
  const [remarkModalShow, setRemarkModalShow] = useState(false)
  const [editingSheetId, setEditingSheetId] = useState(null)

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)

  const handleViewClick = (row) => {
    setSelectedSheet({
      sheetId: row.sheet_id,
      stockType: row.stock_type,
      outlet: row.outlet_name,
      remark: row.remark,
      createdBy: row.created_by,
      createdAt: row.created_at,
    })
    setModalShow(true)
  }

  const handleSaveRemark = async () => {
    try {
      await updateStockRemark({
        sheet_id: editingSheetId,
        remark: editRemark,
      })

      setRemarkModalShow(false)
      fetchData(currentPage) // refresh table
    } catch (error) {
      console.error('Failed to update remark', error)
    }
  }

  const handleRemarkClick = (row) => {
    setEditingSheetId(row.sheet_id)
    setEditRemark(row.remark || '')
    setRemarkModalShow(true)
  }
  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchData(page)
  }

  const handleLimitChange = (e) => {
    const newLimit = Number(e.target.value)

    setLimit(newLimit)
    setCurrentPage(1)

    fetchData(1, newLimit)
  }

  // Fetch data function
  const fetchData = async (page = 1, customLimit = limit) => {
    try {
      setCurrentPage(page)

      const res = await getStockSheetHistory({
        page,
        limit: customLimit,
        sheet_id: sheetId || undefined,
        stock_type: stockType || undefined,
        date: date || undefined,
        todate: todate || undefined,
      }).unwrap()

      setTotalEntries(res.total || 0)
    } catch (error) {
      console.error(error)
    }
  }

  // Fetch data initially
  useEffect(() => {
    fetchData()
  }, [])

  // Helper to calculate pagination window
  const getPageWindow = (current, total, size) => {
    const half = Math.floor(size / 2)
    let start = Math.max(1, current - half)
    let end = Math.min(total, start + size - 1)
    start = Math.max(1, end - size + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const totalPages = data?.totalPages || 1

  return (
    <Card className="mt-4">
      <CardHeader className="py-3 bg-light">
        <CardTitle as="h4" className="mb-0">
          Stock In/Out History
        </CardTitle>
      </CardHeader>

      <CardBody>
        {/* Filters */}
        <Form className="row g-1 mb-2">
          {/* Sheet ID */}
          <FormGroup className="col-md-2">
            <Form.Label>Sheet ID</Form.Label>
            <Form.Control type="text" placeholder="Enter Sheet ID" value={sheetId} onChange={(e) => setSheetId(e.target.value)} />
          </FormGroup>

          {/* Stock Type */}
          <FormGroup className="col-md-2">
            <Form.Label>Stock Type</Form.Label>
            <Form.Select value={stockType} onChange={(e) => setStockType(e.target.value)}>
              <option value="">All</option>
              <option value="stock in">Stock In</option>
              <option value="stock out">Stock Out</option>
            </Form.Select>
          </FormGroup>

          {/* From Date */}
          <FormGroup className="col-md-3">
            <Form.Label>From Date</Form.Label>
            <Form.Control type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </FormGroup>

          {/* To Date */}
          <FormGroup className="col-md-3">
            <Form.Label>To Date</Form.Label>
            <Form.Control type="date" value={todate} onChange={(e) => setToDate(e.target.value)} />
          </FormGroup>

          {/* Search Button */}
          <FormGroup className="col-md-2 d-flex align-items-end gap-1">
            {/* <Button
                            variant="primary"
                            className="w-100"
                            onClick={() => fetchData(1)}
                        >
                            Search
                        </Button> */}
            <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchData(1)}>
              Search
            </Button>
          </FormGroup>
        </Form>

        {isLoading && <Spinner animation="border" />}
        {isError && <p className="text-danger">Failed to load data</p>}

        {data?.data?.length > 0 && (
          <>
            <div className="table-responsive">
              <Table striped className="table mb-0">
                <thead className="table-light text-center">
                  <tr>
                    <th>Sheet ID</th>
                    <th>Date</th>
                    <th>User</th>
                    <th>Stock Type</th>
                    <th>Outlet</th>
                    <th>Remark</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.data.map((row) => (
                    <tr key={row.sheet_id}>
                      <td className="text-center">{row.sheet_id}</td>
                      <td className="text-center">{new Date(row.created_at).toLocaleDateString()}</td>
                      <td className="text-center">{row.created_by}</td>
                      <td className="text-center">{row.stock_type?.charAt(0).toUpperCase() + row.stock_type?.slice(1)}</td>
                      <td className="text-center">{row.outlet_name || '-'}</td>

                      <td>{row.remark?.charAt(0).toUpperCase() + row.remark?.slice(1)}</td>

                      <td>
                        <div className="d-flex justify-content-center">
                          <Button
                            className="d-flex align-items-center"
                            style={{
                              minWidth: 'auto',
                              padding: '0.3rem 0.6rem',
                              fontSize: '0.65rem',
                              height: '30px',
                              borderRadius: '15px',
                              backgroundColor: '#007bff',
                              borderColor: '#007bff',
                              color: '#fff',
                            }}
                            onClick={() => handleViewClick(row)}>
                            <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                            <span>View</span>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
              </div>

              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalEntries={totalEntries}
                limit={limit}
                onPageChange={handlePageChange}
                onLimitChange={(val) => {
                  handleLimitChange({ target: { value: val } })
                }}
                showingFrom={
                  data?.data?.length === 0
                    ? 0
                    : (currentPage - 1) * limit + 1
                }
                showingTo={
                  (currentPage - 1) * limit + (data?.data?.length || 0)
                }
              />
            </>
        )}

            {!isLoading && data?.data?.length === 0 && <p className="text-muted text-center">No stock history found</p>}

            <ViewSheetDetails
              sheetId={selectedSheet?.sheetId}
              stockType={selectedSheet?.stockType}
              outlet={selectedSheet?.outlet}
              remark={selectedSheet?.remark}
              createdBy={selectedSheet?.createdBy}
              createdAt={selectedSheet?.createdAt}
              show={modalShow}
              onHide={() => setModalShow(false)}
            />

            {/* <Modal
                    show={remarkModalShow}
                    onHide={() => setRemarkModalShow(false)}
                    centered
                >
                    <Modal.Header closeButton>
                        <Modal.Title>Edit Remark #{sheetId}</Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                        <Form>
                            <Form.Group>
                                <Form.Label>Remark</Form.Label>
                                <Form.Control
                                    as="textarea"
                                    rows={3}
                                    value={editRemark}
                                    onChange={(e) => setEditRemark(e.target.value)}
                                />
                            </Form.Group>
                        </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="secondary" onClick={() => setRemarkModalShow(false)}>
                            Cancel
                        </Button>

                        <Button
                            variant="primary"
                            onClick={() => handleSaveRemark()}
                        >
                            Save
                        </Button>
                    </Modal.Footer>
                </Modal> */}
          </CardBody>
    </Card>
  )
}

export default StockInOutHistory
