import { Card, CardHeader, CardBody, CardTitle, Table, Spinner, Button, Form, FormGroup, FormLabel } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import { useEffect, useState } from 'react'
import { useGetStockSheetHistoryMutation, useUpdateStockRemarkMutation } from '@/store/features/apiSlice'
import ViewSheetDetails from './ViewSheetDetails'
import Pagination from '@/components/Pagination'
// import { Modal } from "react-bootstrap";

const StockInOutHistory = () => {
  const [getStockSheetHistory, { data, isLoading, isError }] = useGetStockSheetHistoryMutation()

  const [updateStockRemark, { isLoading: isUpdatingRemark }] = useUpdateStockRemarkMutation()

  // Filter states
  const [date, setDate] = useState('')
  const [todate, setToDate] = useState('')
  const [sheetId, setSheetId] = useState('')
  const [stockType, setStockType] = useState('')
  const [outlet, setOutlet] = useState('')

  const [selectedSheet, setSelectedSheet] = useState(null)
  const [modalShow, setModalShow] = useState(false)
  const [editRemark, setEditRemark] = useState('')
  const [remarkModalShow, setRemarkModalShow] = useState(false)
  const [editingSheetId, setEditingSheetId] = useState(null)
  const [limit, setLimit] = useState(25)
  const [totalEntries, setTotalEntries] = useState(0)
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)

  const handleViewClick = (row) => {
    setSelectedSheet({
      sheetId: row.sheet_id,
      stockType: row.stock_type,
      outlet: row.outlet_name,
      remark: row.remark,
      createdBy: row.created_by,
      createdAt: row.created_at,
      wastageDetails: row.wastage_details || [],
      wastageNo: row.wastage_no || null,
      wastageId: row.wastage_id || null,
    })
    setModalShow(true)
  }

  const handleSaveRemark = async () => {
    try {
      await updateStockRemark({
        sheet_id: editingSheetId,
        remark: editRemark,
      })

      setRemarkModalShow(false)
      fetchData(currentPage) // refresh table
    } catch (error) {
      console.error('Failed to update remark', error)
    }
  }

  const handleRemarkClick = (row) => {
    setEditingSheetId(row.sheet_id)
    setEditRemark(row.remark || '')
    setRemarkModalShow(true)
  }

  const handleLimitChange = (e) => {
    const newLimit = Number(e.target.value)

    setLimit(newLimit)
    setCurrentPage(1)

    fetchData(1, newLimit)
  }

  const handlePageChange = (page) => {
    if (page < 1 || page > totalPages) return
    fetchData(page)
  }

  // Fetch data function
  // const fetchData = (page = 1) => {
  //   setCurrentPage(page)
  //   getStockSheetHistory({
  //     page,
  //     limit: 25,
  //     sheet_id: sheetId || undefined,
  //     stock_type: stockType || undefined,
  //     date: date || undefined,
  //     todate: todate || undefined,
  //   })
  // }

  const fetchData = async (page = 1, customLimit = limit) => {
    try {
      setCurrentPage(page)

      const res = await getStockSheetHistory({
        page,
        limit: customLimit,
        sheet_id: sheetId || undefined,
        stock_type: stockType || undefined,
        date: date || undefined,
        todate: todate || undefined,
      }).unwrap()

      setTotalEntries(res.total || 0)
    } catch (error) {
      console.error(error)
    }
  }

  // Fetch data initially
  useEffect(() => {
    fetchData()
  }, [])

  // Helper to calculate pagination window
  const getPageWindow = (current, total, size) => {
    const half = Math.floor(size / 2)
    let start = Math.max(1, current - half)
    let end = Math.min(total, start + size - 1)
    start = Math.max(1, end - size + 1)
    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const totalPages = data?.totalPages || 1

  const formatStockType = (type) => {
    const normalized = String(type || '').toLowerCase()

    if (normalized === 'stock in' || normalized === 'in') return 'Stock In'
    if (normalized === 'stock out' || normalized === 'out') return 'Stock Out'

    if (normalized === 'wastage' || normalized === 'stock wastage' || normalized === 'stock-wastage') {
      return 'Stock Wastage'
    }

    return type ? type.charAt(0).toUpperCase() + type.slice(1) : '-'
  }

  const getStockTypeBadgeClass = (type) => {
    const normalized = String(type || '').toLowerCase()

    if (normalized === 'stock in' || normalized === 'in') return 'bg-success'
    if (normalized === 'stock out' || normalized === 'out') return 'bg-danger'

    if (normalized === 'wastage' || normalized === 'stock wastage' || normalized === 'stock-wastage') {
      return 'bg-warning text-dark'
    }

    return 'bg-secondary'
  }

  return (
    <Card className="mt-4">
      <CardHeader className="py-3 bg-light">
        <CardTitle as="h4" className="mb-0">
          Stock In/Out History
        </CardTitle>
      </CardHeader>

      <CardBody>
        {/* Filters */}
        <div className="po-filter-bar mb-3">
          <div className="row g-2 align-items-end">
            {/* Sheet ID */}
            <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
              <div className="po-filter-label">Sheet ID</div>

              <Form.Control
                type="text"
                placeholder="Enter Sheet ID"
                value={sheetId}
                onChange={(e) => setSheetId(e.target.value)}
                className="form-control form-control-sm"
                style={{
                  height: '36px',
                  fontSize: '13px',
                  borderRadius: '8px',
                }}
              />
            </div>

            {/* Stock Type */}
            <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
              <div className="po-filter-label">Stock Type</div>

              <Form.Select
                value={stockType}
                onChange={(e) => setStockType(e.target.value)}
                className="form-select form-select-sm"
                style={{
                  height: '36px',
                  fontSize: '13px',
                  borderRadius: '8px',
                }}>
                <option value="">All</option>
                <option value="stock in">Stock In</option>
                <option value="stock out">Stock Out</option>
                <option value="stock wastage">Stock Wastage</option>
              </Form.Select>
            </div>

            {/* From Date */}
            <div className="col-6 col-sm-3 col-lg-3 col-xl-3">
              <div className="po-filter-label">From Date</div>

              <Form.Control
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="form-control form-control-sm"
                style={{
                  height: '36px',
                  fontSize: '13px',
                  borderRadius: '8px',
                }}
              />
            </div>

            {/* To Date */}
            <div className="col-6 col-sm-3 col-lg-3 col-xl-3">
              <div className="po-filter-label">To Date</div>

              <Form.Control
                type="date"
                value={todate}
                onChange={(e) => setToDate(e.target.value)}
                className="form-control form-control-sm"
                style={{
                  height: '36px',
                  fontSize: '13px',
                  borderRadius: '8px',
                }}
              />
            </div>

            {/* Search Button */}
            <div className="col-12 col-sm-4 col-lg-2 col-xl-2">
              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-dark btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-2"
                  onClick={() => fetchData(1)}>
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>

        {isLoading && <Spinner animation="border" />}
        {isError && <p className="text-danger">Failed to load data</p>}

        {data?.data?.length > 0 && (
          <>
            <div className="table-responsive">
              <Table striped className="table mb-0">
                <thead className="table-light text-center">
                  <tr>
                    <th>Sheet ID</th>
                    <th>Date</th>
                    <th>User</th>
                    <th>Stock Type</th>
                    <th>Outlet</th>
                    <th>Remark</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.data.map((row) => (
                    <tr key={row.sheet_id}>
                      <td className="text-center">{row.sheet_id}</td>
                      <td className="text-center">
                        {new Date(row.created_at).toLocaleString([], {
                          year: 'numeric',
                          month: '2-digit',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                          hour12: true,
                        })}
                      </td>
                      <td className="text-center">{row.created_by}</td>
                      <td className="text-center">
                        <span
                          className={`badge rounded-pill px-2 py-1 ${getStockTypeBadgeClass(row.stock_type)}`}
                          style={{
                            fontSize: '0.62rem',
                            fontWeight: 600,
                            minWidth: '64px',
                            lineHeight: '1',
                          }}>
                          {row.stock_method === 'CSV Upload' ? `${formatStockType(row.stock_type)} - CSV` : formatStockType(row.stock_type)}
                        </span>
                      </td>
                      <td className="text-center">{row.outlet_name || '-'}</td>

                      <td>{row.remark?.charAt(0).toUpperCase() + row.remark?.slice(1)}</td>

                      <td>
                        <div className="d-flex justify-content-center">
                          <Button
                            className="d-flex align-items-center"
                            style={{
                              minWidth: 'auto',
                              padding: '0.3rem 0.6rem',
                              fontSize: '0.65rem',
                              height: '30px',
                              borderRadius: '15px',
                              backgroundColor: '#007bff',
                              borderColor: '#007bff',
                              color: '#fff',
                            }}
                            onClick={() => handleViewClick(row)}>
                            <Icon icon="mdi:eye" width={15} height={20} style={{ marginRight: '4px' }} />
                            <span>View</span>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalEntries={totalEntries}
              limit={limit}
              onPageChange={handlePageChange}
              onLimitChange={(val) => {
                handleLimitChange({ target: { value: val } })
              }}
              showingFrom={data?.data?.length === 0 ? 0 : (currentPage - 1) * limit + 1}
              showingTo={(currentPage - 1) * limit + (data?.data?.length || 0)}
            />
          </>
        )}

        {!isLoading && data?.data?.length === 0 && <p className="text-muted text-center">No stock history found</p>}

        <ViewSheetDetails
          sheetId={selectedSheet?.sheetId}
          stockType={selectedSheet?.stockType}
          outlet={selectedSheet?.outlet}
          remark={selectedSheet?.remark}
          createdBy={selectedSheet?.createdBy}
          createdAt={selectedSheet?.createdAt}
          wastageDetails={selectedSheet?.wastageDetails}
          wastageNo={selectedSheet?.wastageNo}
          wastageId={selectedSheet?.wastageId}
          show={modalShow}
          onHide={() => setModalShow(false)}
        />

        {/* <Modal
                    show={remarkModalShow}
                    onHide={() => setRemarkModalShow(false)}
                    centered
                >
                    <Modal.Header closeButton>
                        <Modal.Title>Edit Remark #{sheetId}</Modal.Title>
                    </Modal.Header>

                    <Modal.Body>
                        <Form>
                            <Form.Group>
                                <Form.Label>Remark</Form.Label>
                                <Form.Control
                                    as="textarea"
                                    rows={3}
                                    value={editRemark}
                                    onChange={(e) => setEditRemark(e.target.value)}
                                />
                            </Form.Group>
                        </Form>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="secondary" onClick={() => setRemarkModalShow(false)}>
                            Cancel
                        </Button>

                        <Button
                            variant="primary"
                            onClick={() => handleSaveRemark()}
                        >
                            Save
                        </Button>
                    </Modal.Footer>
                </Modal> */}
      </CardBody>
    </Card>
  )
}

export default StockInOutHistory
