'use client'

import React, { useCallback, useMemo, useRef, useState } from 'react'
import { Alert, Badge, Button, Card, Col, Form, Pagination, Row, Spinner, Table } from 'react-bootstrap'
import Select from 'react-select'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import axios from 'axios'
import { useFetchInventorySubOutletsQuery } from '@/store/features/apiSlice'

const REQUIRED_COLUMNS = [
  {
    name: 'variant_id',
    required: true,
    description: 'The product variant ID that will be updated.',
    example: '503778',
  },
  {
    name: 'stock_quantity',
    required: true,
    description: 'The quantity to add or remove from stock.',
    example: '10',
  },
  {
    name: 'batch_number',
    required: false,
    description: 'The existing batch number assigned to this variant.',
    example: 'BATCH-001',
  },
  {
    name: 'continue_selling',
    required: false,
    description: 'Use true or false to allow selling when out of stock.',
    example: 'TRUE',
  },
  {
    name: 'reorder_level',
    required: false,
    description: 'The minimum stock level before reorder notification.',
    example: '5',
  },
]

const ALLOWED_FILE_TYPES = ['text/csv', 'application/vnd.ms-excel', 'text/plain']

const MAX_FILE_SIZE = 5 * 1024 * 1024
const FAILED_ROWS_PER_PAGE = 10

const CSVStockUpdate = ({ isModal = false, onClose, onUploadSuccess }) => {
  const fileInputRef = useRef(null)

  const [stockType, setStockType] = useState(null)
  const [selectedOutlet, setSelectedOutlet] = useState(null)
  const [selectedFile, setSelectedFile] = useState(null)
  const [isDragging, setIsDragging] = useState(false)

  const [isUploading, setIsUploading] = useState(false)

  const [uploadMessage, setUploadMessage] = useState('')

  const [uploadResult, setUploadResult] = useState(null)

  const [failedPage, setFailedPage] = useState(1)

  const { data: outletOptions = [], isLoading: outletsLoading } = useFetchInventorySubOutletsQuery()

  const requiredFieldsSelected = Boolean(stockType) && Boolean(selectedOutlet) && Boolean(selectedFile)

  const uploadDisabled = !requiredFieldsSelected || isUploading

  const failedRows = uploadResult?.failed_rows || []

  const totalFailedPages = Math.max(1, Math.ceil(failedRows.length / FAILED_ROWS_PER_PAGE))

  const paginatedFailedRows = useMemo(() => {
    const startIndex = (failedPage - 1) * FAILED_ROWS_PER_PAGE

    return failedRows.slice(startIndex, startIndex + FAILED_ROWS_PER_PAGE)
  }, [failedRows, failedPage])

  const resetUploadState = () => {
    setSelectedFile(null)
    setUploadResult(null)
    setFailedPage(1)

    setUploadMessage('')

    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const validateFile = useCallback(async (file) => {
    if (!file) {
      return false
    }

    const extension = file.name.split('.').pop()?.toLowerCase()

    if (extension !== 'csv') {
      await Swal.fire({
        icon: 'warning',
        title: 'Invalid File Type',
        text: 'Please select a valid CSV file.',
        confirmButtonColor: '#0d6efd',
      })

      return false
    }

    if (file.type && !ALLOWED_FILE_TYPES.includes(file.type) && extension !== 'csv') {
      await Swal.fire({
        icon: 'warning',
        title: 'Unsupported File',
        text: 'Only CSV files are supported.',
        confirmButtonColor: '#0d6efd',
      })

      return false
    }

    if (file.size > MAX_FILE_SIZE) {
      await Swal.fire({
        icon: 'warning',
        title: 'File Too Large',
        text: 'The maximum allowed CSV file size is 5 MB.',
        confirmButtonColor: '#0d6efd',
      })

      return false
    }

    if (file.size === 0) {
      await Swal.fire({
        icon: 'warning',
        title: 'Empty File',
        text: 'The selected CSV file is empty.',
        confirmButtonColor: '#0d6efd',
      })

      return false
    }

    return true
  }, [])

  const handleFileSelection = useCallback(
    async (file) => {
      const isValid = await validateFile(file)

      if (!isValid) {
        return
      }

      setSelectedFile(file)
      setUploadResult(null)
      setFailedPage(1)

      setUploadMessage('')
    },
    [validateFile],
  )

  const handleInputChange = async (event) => {
    const file = event.target.files?.[0]

    await handleFileSelection(file)
  }

  const handleDragEnter = (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (!isUploading) {
      setIsDragging(true)
    }
  }

  const handleDragOver = (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (!isUploading) {
      setIsDragging(true)
    }
  }

  const handleDragLeave = (event) => {
    event.preventDefault()
    event.stopPropagation()

    if (!event.currentTarget.contains(event.relatedTarget)) {
      setIsDragging(false)
    }
  }

  const handleDrop = async (event) => {
    event.preventDefault()
    event.stopPropagation()

    setIsDragging(false)

    if (isUploading) {
      return
    }

    const file = event.dataTransfer.files?.[0]

    await handleFileSelection(file)
  }

  const handleRemoveFile = () => {
    if (isUploading) {
      return
    }

    resetUploadState()
  }

  const downloadCSVFile = ({ rows, filename }) => {
    if (!Array.isArray(rows) || rows.length === 0) {
      Swal.fire({
        icon: 'info',
        title: 'No Failed Rows',
        text: 'There are no rejected rows available to download.',
        confirmButtonColor: '#0d6efd',
      })

      return
    }

    const headers = [
      'row_number',
      'variant_id',
      'batch_number',
      'continue_selling',
      'stock_quantity',
      'reorder_level',
      'error_type',
      'category',
      'reason',
    ]

    const csvLines = [headers.join(','), ...rows.map((row) => headers.map((header) => escapeCSVValue(row?.[header])).join(','))]

    const csvContent = `\uFEFF${csvLines.join('\n')}`

    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;',
    })

    const url = URL.createObjectURL(blob)

    const anchor = document.createElement('a')

    anchor.href = url
    anchor.download = filename

    document.body.appendChild(anchor)
    anchor.click()
    document.body.removeChild(anchor)

    URL.revokeObjectURL(url)
  }

  const handleSampleDownload = () => {
    const sampleCSV = [
      'variant_id,batch_number,continue_selling,stock_quantity,reorder_level',
      '503778,BATCH-001,TRUE,10,5',
      '504422,BATCH-002,FALSE,7,3',
      '504423,,TRUE,15,10',
    ].join('\n')

    const blob = new Blob([`\uFEFF${sampleCSV}`], {
      type: 'text/csv;charset=utf-8;',
    })

    const url = URL.createObjectURL(blob)

    const anchor = document.createElement('a')

    anchor.href = url
    anchor.download = 'stock_update_sample.csv'

    document.body.appendChild(anchor)
    anchor.click()
    document.body.removeChild(anchor)

    URL.revokeObjectURL(url)
  }

  const handleFailedRowsDownload = (rows = failedRows) => {
    const stockTypeName = stockType?.value === 'out' ? 'stock_out' : 'stock_in'

    const outletName = uploadResult?.outlet_name || selectedOutlet?.label || 'outlet'

    const safeOutletName = String(outletName)
      .trim()
      .replace(/[^a-zA-Z0-9_-]+/g, '_')

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')

    downloadCSVFile({
      rows,

      filename: `failed_${stockTypeName}_` + `${safeOutletName}_` + `${timestamp}.csv`,
    })
  }

  const uploadCSVFile = async ({ file, stockTypeValue, outletId }) => {
    const formData = new FormData()

    formData.append('file', file)
    formData.append('stock_type', stockTypeValue)
    formData.append('outlet_id', String(outletId))

    const baseURL = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:5008'

    const response = await axios.post(`${baseURL}/inventory-sub/csv-stock-update`, formData, {
      withCredentials: true,
    })

    return response.data
  }
  const getFailureTypeDetails = (row) => {
    if (row?.category === 'PRODUCT_OR_VARIANT_NOT_EXISTING') {
      return {
        label: 'Variant Error',
        variant: 'warning',
        icon: 'mdi:identifier-off',
      }
    }

    if (row?.category === 'BATCH_VALIDATION_FAILED') {
      return {
        label: 'Batch Error',
        variant: 'info',
        icon: 'mdi:package-variant-closed-remove',
      }
    }

    return {
      label: 'Update Failed',
      variant: 'danger',
      icon: 'mdi:alert-circle-outline',
    }
  }

  const escapeHTML = (value) =>
    String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;')

  const escapeCSVValue = (value) => {
    if (value === undefined || value === null) {
      return ''
    }

    const text = String(value).replace(/"/g, '""')

    return /[",\n\r]/.test(text) ? `"${text}"` : text
  }

  const downloadFailedRowsCSV = (rows, resultData) => {
    if (!Array.isArray(rows) || rows.length === 0) {
      return
    }

    const columns = [
      'row_number',
      'variant_id',
      'batch_number',
      'continue_selling',
      'stock_quantity',
      'reorder_level',
      'error_type',
      'category',
      'reason',
    ]

    const csvContent = [columns.join(','), ...rows.map((row) => columns.map((column) => escapeCSVValue(row?.[column])).join(','))].join('\n')

    const blob = new Blob([`\uFEFF${csvContent}`], {
      type: 'text/csv;charset=utf-8;',
    })

    const url = URL.createObjectURL(blob)

    const anchor = document.createElement('a')

    const outletName = String(resultData?.outlet_name || 'outlet')
      .trim()
      .replace(/[^a-zA-Z0-9_-]+/g, '_')

    const stockTypeName = resultData?.stock_type === 'stock out' ? 'stock_out' : 'stock_in'

    anchor.href = url
    anchor.download = `failed_${stockTypeName}_` + `${outletName}.csv`

    document.body.appendChild(anchor)
    anchor.click()
    document.body.removeChild(anchor)

    URL.revokeObjectURL(url)
  }

  const getSwalFailureLabel = (row) => {
    if (row?.category === 'BATCH_VALIDATION_FAILED') {
      return {
        label: 'Batch Error',
        background: '#e7f1ff',
        color: '#084298',
      }
    }

    if (row?.category === 'PRODUCT_OR_VARIANT_NOT_EXISTING') {
      return {
        label: 'Variant Error',
        background: '#fff3cd',
        color: '#664d03',
      }
    }

    return {
      label: 'Update Failed',
      background: '#f8d7da',
      color: '#842029',
    }
  }

  const showRejectedRowsSwal = async (normalizedResult) => {
    const rejectedRows = normalizedResult.failed_rows || []

    const rowsPerPage = 10
    const totalPages = Math.max(1, Math.ceil(rejectedRows.length / rowsPerPage))

    let currentPage = 1

    const buildRowsHTML = () => {
      const startIndex = (currentPage - 1) * rowsPerPage

      const currentRows = rejectedRows.slice(startIndex, startIndex + rowsPerPage)

      return currentRows
        .map((row) => {
          const errorDetails = getSwalFailureLabel(row)

          return `
          <tr>
            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              text-align:center;
              font-weight:600;
              white-space:nowrap;
            ">
              ${escapeHTML(row.row_number || '-')}
            </td>

            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              text-align:center;
              white-space:nowrap;
            ">
              <code>
                ${escapeHTML(row.variant_id || '-')}
              </code>
            </td>

            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              text-align:center;
              white-space:nowrap;
            ">
              ${escapeHTML(row.batch_number || 'No batch')}
            </td>

            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              text-align:center;
              white-space:nowrap;
            ">
              ${escapeHTML(row.stock_quantity || '-')}
            </td>

            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              white-space:nowrap;
            ">
              <span style="
                display:inline-block;
                padding:4px 8px;
                border-radius:999px;
                font-size:11px;
                font-weight:700;
                background:
                  ${errorDetails.background};
                color:
                  ${errorDetails.color};
              ">
                ${errorDetails.label}
              </span>

              ${
                row.error_type
                  ? `
                    <div style="
                      color:#6c757d;
                      font-size:11px;
                      margin-top:4px;
                    ">
                      ${escapeHTML(row.error_type)}
                    </div>
                  `
                  : ''
              }
            </td>

            <td style="
              padding:9px;
              border-bottom:1px solid #e9ecef;
              min-width:280px;
              color:#842029;
              font-size:12px;
              line-height:1.45;
            ">
              ${escapeHTML(row.reason || 'Unable to process this row.')}
            </td>
          </tr>
        `
        })
        .join('')
    }

    const buildPaginationHTML = () => {
      const startRecord = rejectedRows.length === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1

      const endRecord = Math.min(currentPage * rowsPerPage, rejectedRows.length)

      return `
      <div style="
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:12px;
        margin-top:14px;
        flex-wrap:wrap;
      ">
        <div style="
          color:#6c757d;
          font-size:12px;
        ">
          Showing
          ${startRecord}
          –
          ${endRecord}
          of
          ${rejectedRows.length}
          rejected rows
        </div>

        <div style="
          display:flex;
          align-items:center;
          gap:7px;
        ">
          <button
            type="button"
            id="csv-failed-prev"
            ${currentPage === 1 ? 'disabled' : ''}
            style="
              border:1px solid #ced4da;
              border-radius:6px;
              background:#fff;
              padding:6px 11px;
              cursor:
                ${currentPage === 1 ? 'not-allowed' : 'pointer'};
              opacity:
                ${currentPage === 1 ? '0.5' : '1'};
            "
          >
            Previous
          </button>

          <span style="
            font-size:12px;
            font-weight:600;
            min-width:80px;
            text-align:center;
          ">
            Page ${currentPage}
            of ${totalPages}
          </span>

          <button
            type="button"
            id="csv-failed-next"
            ${currentPage === totalPages ? 'disabled' : ''}
            style="
              border:1px solid #ced4da;
              border-radius:6px;
              background:#fff;
              padding:6px 11px;
              cursor:
                ${currentPage === totalPages ? 'not-allowed' : 'pointer'};
              opacity:
                ${currentPage === totalPages ? '0.5' : '1'};
            "
          >
            Next
          </button>
        </div>
      </div>
    `
    }

    const buildContentHTML = () => `
    <div style="
      text-align:left;
      font-size:13px;
    ">
      <div style="
        display:grid;
        grid-template-columns:
          repeat(4,minmax(0,1fr));
        gap:9px;
        margin-bottom:14px;
      ">
        <div style="
          border:1px solid #dee2e6;
          border-radius:9px;
          padding:10px;
          background:#f8f9fa;
        ">
          <div style="
            color:#6c757d;
            font-size:11px;
          ">
            Total Rows
          </div>

          <div style="
            font-size:21px;
            font-weight:700;
          ">
            ${normalizedResult.total_rows}
          </div>
        </div>

        <div style="
          border:1px solid #badbcc;
          border-radius:9px;
          padding:10px;
          background:#f0fff4;
        ">
          <div style="
            color:#198754;
            font-size:11px;
          ">
            Successful
          </div>

          <div style="
            font-size:21px;
            font-weight:700;
            color:#198754;
          ">
            ${normalizedResult.successful_rows}
          </div>
        </div>

        <div style="
          border:1px solid #b6d4fe;
          border-radius:9px;
          padding:10px;
          background:#eef6ff;
        ">
          <div style="
            color:#084298;
            font-size:11px;
          ">
            Batch Errors
          </div>

          <div style="
            font-size:21px;
            font-weight:700;
            color:#084298;
          ">
            ${normalizedResult.batch_failed_rows_count}
          </div>
        </div>

        <div style="
          border:1px solid #f5c2c7;
          border-radius:9px;
          padding:10px;
          background:#fff5f5;
        ">
          <div style="
            color:#842029;
            font-size:11px;
          ">
            Rejected
          </div>

          <div style="
            font-size:21px;
            font-weight:700;
            color:#842029;
          ">
            ${normalizedResult.rejected_rows_count}
          </div>
        </div>
      </div>

      <div style="
        overflow:auto;
        max-height:430px;
        border:1px solid #dee2e6;
        border-radius:10px;
      ">
        <table style="
          width:100%;
          border-collapse:collapse;
          background:#fff;
        ">
          <thead style="
            position:sticky;
            top:0;
            background:#f8f9fa;
            z-index:1;
          ">
            <tr>
              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                white-space:nowrap;
              ">
                Row
              </th>

              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                white-space:nowrap;
              ">
                Variant ID
              </th>

              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                white-space:nowrap;
              ">
                Batch
              </th>

              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                white-space:nowrap;
              ">
                Qty
              </th>

              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                white-space:nowrap;
              ">
                Error
              </th>

              <th style="
                padding:9px;
                border-bottom:1px solid #dee2e6;
                min-width:280px;
              ">
                Reason
              </th>
            </tr>
          </thead>

          <tbody id="csv-failed-table-body">
            ${buildRowsHTML()}
          </tbody>
        </table>
      </div>

      <div id="csv-failed-pagination">
        ${buildPaginationHTML()}
      </div>
    </div>
  `

    const refreshSwalPage = () => {
      const tableBody = document.getElementById('csv-failed-table-body')

      const pagination = document.getElementById('csv-failed-pagination')

      if (tableBody) {
        tableBody.innerHTML = buildRowsHTML()
      }

      if (pagination) {
        pagination.innerHTML = buildPaginationHTML()

        bindPaginationEvents()
      }
    }

    const bindPaginationEvents = () => {
      const previousButton = document.getElementById('csv-failed-prev')

      const nextButton = document.getElementById('csv-failed-next')

      previousButton?.addEventListener('click', () => {
        if (currentPage > 1) {
          currentPage -= 1
          refreshSwalPage()
        }
      })

      nextButton?.addEventListener('click', () => {
        if (currentPage < totalPages) {
          currentPage += 1
          refreshSwalPage()
        }
      })
    }

    const swalResult = await Swal.fire({
      icon: 'warning',

      title: 'Upload Completed with Errors',

      width: 1050,

      html: buildContentHTML(),

      showCancelButton: true,

      showDenyButton: true,

      confirmButtonText: 'Close',

      denyButtonText: 'Download Failed Rows CSV',

      cancelButtonText: 'Keep Modal Open',

      confirmButtonColor: '#6c757d',

      denyButtonColor: '#dc3545',

      cancelButtonColor: '#0d6efd',

      didOpen: () => {
        bindPaginationEvents()
      },
    })

    if (swalResult.isDenied) {
      downloadFailedRowsCSV(rejectedRows, normalizedResult)

      await showRejectedRowsSwal(normalizedResult)
    }

    return swalResult
  }

  const handleUpload = async () => {
    if (uploadDisabled) {
      return
    }

    const confirmation = await Swal.fire({
      icon: 'warning',

      title: 'Confirm CSV Stock Update',

      html: `
          <div style="
            font-size:14px;
            color:#555;
            text-align:left;
          ">
            <p>
              You are about to process stock updates using:
            </p>

            <div style="
              border:1px solid #e5e7eb;
              border-radius:10px;
              padding:14px;
              background:#f8f9fa;
              margin-bottom:14px;
            ">
              <div style="margin-bottom:6px;">
                <b>Stock Type:</b>
                ${stockType?.label || '-'}
              </div>

              <div style="margin-bottom:6px;">
                <b>Outlet:</b>
                ${selectedOutlet?.label || '-'}
              </div>

              <div>
                <b>File:</b>
                ${selectedFile?.name || '-'}
              </div>
            </div>

            <div style="
              color:#dc3545;
              background:#fff5f5;
              border:1px solid #f5c2c7;
              border-radius:8px;
              padding:10px;
            ">
              <b>Important:</b>
              Do not close this modal,
              refresh the page, or navigate
              away until the upload is fully
              completed.
            </div>
          </div>
        `,

      showCancelButton: true,

      confirmButtonText: 'Yes, Upload CSV',

      cancelButtonText: 'Cancel',

      confirmButtonColor: '#198754',

      cancelButtonColor: '#6c757d',

      backdrop: 'rgba(0,0,0,0.45)',
    })

    if (!confirmation.isConfirmed) {
      return
    }

    setIsUploading(true)
    setUploadResult(null)
    setFailedPage(1)
    setUploadMessage('Uploading and processing stock records...')
    try {
      const result = await uploadCSVFile({
        file: selectedFile,
        stockTypeValue: stockType.value,
        outletId: selectedOutlet.value,
      })

      setUploadMessage('Stock update completed.')
      const backendFailedRows = Array.isArray(result?.failed_rows) ? result.failed_rows : []

      const notExistingRows = Array.isArray(result?.not_existing_rows) ? result.not_existing_rows : []

      const combinedRejectedRows = [...notExistingRows, ...backendFailedRows]

      const normalizedResult = {
        success: result?.success !== false,

        message: result?.message || 'The CSV stock update has been processed.',

        stock_type: result?.stock_type || '',

        stock_sheet_remark: result?.stock_sheet_remark || '',

        outlet_id: result?.outlet_id ?? null,

        outlet_name: result?.outlet_name || '',

        total_rows: Number(result?.total_rows ?? 0) || 0,

        successful_rows: Number(result?.successful_rows ?? 0) || 0,

        not_existing_rows_count: Number(result?.not_existing_rows_count ?? notExistingRows.length) || 0,

        batch_failed_rows_count:
          Number(result?.batch_failed_rows_count ?? backendFailedRows.filter((row) => row?.category === 'BATCH_VALIDATION_FAILED').length) || 0,

        stock_failed_rows_count:
          Number(result?.stock_failed_rows_count ?? backendFailedRows.filter((row) => row?.category !== 'BATCH_VALIDATION_FAILED').length) || 0,

        backend_failed_rows_count: Number(result?.failed_rows_count ?? backendFailedRows.length) || 0,

        rejected_rows_count: Number(result?.rejected_rows_count ?? combinedRejectedRows.length) || 0,

        stock_sheet_updated: result?.stock_sheet_updated ?? false,

        stock_sheet_count: Number(result?.stock_sheet_count ?? 0) || 0,

        stock_sheet_headers: Array.isArray(result?.stock_sheet_headers) ? result.stock_sheet_headers : [],

        not_existing_rows: notExistingRows,

        backend_failed_rows: backendFailedRows,

        failed_rows: combinedRejectedRows,

        failed_rows_count: combinedRejectedRows.length,

        results: Array.isArray(result?.results) ? result.results : [],
      }

      setUploadResult(normalizedResult)

      if (normalizedResult.rejected_rows_count === 0) {
        await Swal.fire({
          icon: 'success',

          title: 'Upload Completed',

          html: `
            <div style="
              text-align:left;
              font-size:14px;
            ">
              <div style="
                padding:12px;
                border-radius:10px;
                background:#f0fff4;
                border:1px solid #badbcc;
              ">
                <div style="
                  font-weight:700;
                  color:#146c43;
                  margin-bottom:6px;
                ">
                  All stock rows were updated successfully.
                </div>

                <div>
                  <b>Total rows:</b>
                  ${normalizedResult.total_rows}
                </div>

                <div>
                  <b>Successful rows:</b>
                  ${normalizedResult.successful_rows}
                </div>

                <div>
                  <b>Stock sheets created:</b>
                  ${normalizedResult.stock_sheet_count}
                </div>
              </div>
            </div>
          `,

          confirmButtonColor: '#198754',
        })
      } else {
        const warningResult = await Swal.fire({
          icon: 'warning',

          title: 'Upload Completed with Errors',

          width: 680,

          html: `
              <div style="
                text-align:left;
                font-size:14px;
              ">
                <div style="
                  display:grid;
                  grid-template-columns:
                    repeat(2, minmax(0, 1fr));
                  gap:10px;
                  margin-bottom:14px;
                ">
                  <div style="
                    border:1px solid #dee2e6;
                    border-radius:10px;
                    padding:12px;
                    background:#f8f9fa;
                  ">
                    <div style="
                      color:#6c757d;
                      font-size:12px;
                    ">
                      Total Rows
                    </div>

                    <div style="
                      font-size:24px;
                      font-weight:700;
                    ">
                      ${normalizedResult.total_rows}
                    </div>
                  </div>

                  <div style="
                    border:1px solid #badbcc;
                    border-radius:10px;
                    padding:12px;
                    background:#f0fff4;
                  ">
                    <div style="
                      color:#198754;
                      font-size:12px;
                    ">
                      Successful
                    </div>

                    <div style="
                      font-size:24px;
                      font-weight:700;
                      color:#198754;
                    ">
                      ${normalizedResult.successful_rows}
                    </div>
                  </div>

                  <div style="
                    border:1px solid #ffe69c;
                    border-radius:10px;
                    padding:12px;
                    background:#fff8e1;
                  ">
                    <div style="
                      color:#997404;
                      font-size:12px;
                    ">
                      Variant Errors
                    </div>

                    <div style="
                      font-size:24px;
                      font-weight:700;
                      color:#997404;
                    ">
                      ${normalizedResult.not_existing_rows_count}
                    </div>
                  </div>

                  <div style="
                    border:1px solid #b6d4fe;
                    border-radius:10px;
                    padding:12px;
                    background:#eef6ff;
                  ">
                    <div style="
                      color:#084298;
                      font-size:12px;
                    ">
                      Batch Errors
                    </div>

                    <div style="
                      font-size:24px;
                      font-weight:700;
                      color:#084298;
                    ">
                      ${normalizedResult.batch_failed_rows_count}
                    </div>
                  </div>
                </div>

                <div style="
                  border:1px solid #f5c2c7;
                  background:#fff5f5;
                  color:#842029;
                  padding:12px;
                  border-radius:10px;
                ">
                  <b>
                    ${normalizedResult.rejected_rows_count}
                    row(s) were rejected.
                  </b>

                  <div style="margin-top:5px;">
                    Review the rejected rows in
                    the modal or download them
                    as a CSV file.
                  </div>
                </div>
              </div>
            `,

          showDenyButton: true,

          confirmButtonText: 'Review in Modal',

          denyButtonText: 'Download Failed CSV',

          confirmButtonColor: '#0d6efd',

          denyButtonColor: '#dc3545',
        })

        if (warningResult.isDenied) {
          handleFailedRowsDownload(normalizedResult.failed_rows)
        }
      }

      if (typeof onUploadSuccess === 'function') {
        onUploadSuccess(normalizedResult)
      }
    } catch (error) {
      setUploadMessage('')

      const errorMessage =
        error?.response?.data?.message || error?.response?.data?.error || error?.message || 'An unexpected error occurred while uploading the CSV.'

      await Swal.fire({
        icon: 'error',

        title: 'CSV Upload Failed',

        text: errorMessage,

        confirmButtonColor: '#dc3545',
      })
    } finally {
      setIsUploading(false)
    }
  }

  const handleClose = async () => {
    if (isUploading) {
      await Swal.fire({
        icon: 'warning',

        title: 'Upload in Progress',

        text: 'Please wait until the stock update is fully completed before closing this modal.',

        confirmButtonColor: '#0d6efd',
      })

      return
    }

    if (typeof onClose === 'function') {
      onClose()
    }
  }

  const renderPaginationItems = () => {
    if (totalFailedPages <= 1) {
      return null
    }

    const pages = []

    const startPage = Math.max(1, failedPage - 2)

    const endPage = Math.min(totalFailedPages, failedPage + 2)

    for (let page = startPage; page <= endPage; page += 1) {
      pages.push(
        <Pagination.Item key={page} active={page === failedPage} onClick={() => setFailedPage(page)}>
          {page}
        </Pagination.Item>,
      )
    }

    return (
      <Pagination size="sm" className="mb-0 flex-wrap">
        <Pagination.First disabled={failedPage === 1} onClick={() => setFailedPage(1)} />

        <Pagination.Prev disabled={failedPage === 1} onClick={() => setFailedPage((page) => Math.max(1, page - 1))} />

        {startPage > 1 && <Pagination.Ellipsis disabled />}

        {pages}

        {endPage < totalFailedPages && <Pagination.Ellipsis disabled />}

        <Pagination.Next disabled={failedPage === totalFailedPages} onClick={() => setFailedPage((page) => Math.min(totalFailedPages, page + 1))} />

        <Pagination.Last disabled={failedPage === totalFailedPages} onClick={() => setFailedPage(totalFailedPages)} />
      </Pagination>
    )
  }

  return (
    <div className="csv-stock-update">
      {isUploading && (
        <Alert variant="warning" className="d-flex align-items-start gap-3 mb-4">
          <Icon icon="mdi:alert-circle-outline" width={24} className="flex-shrink-0 mt-1" />

          <div>
            <div className="fw-semibold">Stock update is currently processing</div>

            <div className="small mt-1">Do not close this modal, refresh the page, or navigate away until the process is completed.</div>
          </div>
        </Alert>
      )}

      <Card className="border-0 shadow-sm mb-4">
        <Card.Body className="p-4">
          <div className="d-flex align-items-start justify-content-between gap-3 flex-wrap mb-4">
            <div className="d-flex align-items-center gap-2">
              <span
                className="d-inline-flex align-items-center justify-content-center rounded-circle"
                style={{
                  width: 38,
                  height: 38,
                  backgroundColor: 'rgba(13,110,253,0.1)',
                  color: '#0d6efd',
                }}>
                <Icon icon="mdi:tune-variant" width={21} />
              </span>

              <div>
                <h5 className="mb-1">Stock Update Settings</h5>

                <p className="text-muted small mb-0">Select the stock type and outlet before uploading your CSV file.</p>
              </div>
            </div>

            <Badge bg="light" text="dark" className="border px-3 py-2">
              Fields marked * are required
            </Badge>
          </div>

          <Row className="g-3">
            <Col xs={12} md={6}>
              <Form.Label className="fw-semibold small">
                Stock Type <span className="text-danger">*</span>
              </Form.Label>

              <Select
                options={[
                  {
                    label: 'Stock In',
                    value: 'in',
                  },
                  {
                    label: 'Stock Out',
                    value: 'out',
                  },
                ]}
                value={stockType}
                onChange={(option) => {
                  setStockType(option)
                  setUploadResult(null)
                }}
                isClearable
                isDisabled={isUploading}
                placeholder="Select Stock In or Stock Out"
              />
            </Col>

            <Col xs={12} md={6}>
              <Form.Label className="fw-semibold small">
                Outlet <span className="text-danger">*</span>
              </Form.Label>

              <Select
                options={outletOptions}
                value={selectedOutlet}
                onChange={(option) => {
                  setSelectedOutlet(option)
                  setUploadResult(null)
                }}
                isClearable
                isLoading={outletsLoading}
                isDisabled={isUploading}
                placeholder="Select outlet"
              />
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card className="border-0 shadow-sm mb-4">
        <Card.Body className="p-4">
          <div className="mb-3">
            <h5 className="mb-1">Upload CSV File</h5>

            <p className="text-muted small mb-0">Drag and drop the CSV file below or select it manually.</p>
          </div>

          <div
            role="button"
            tabIndex={0}
            onClick={() => {
              if (!isUploading) {
                fileInputRef.current?.click()
              }
            }}
            onKeyDown={(event) => {
              if (!isUploading && (event.key === 'Enter' || event.key === ' ')) {
                fileInputRef.current?.click()
              }
            }}
            onDragEnter={handleDragEnter}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className="d-flex flex-column align-items-center justify-content-center text-center p-4"
            style={{
              minHeight: 220,

              border: `2px dashed ${isDragging ? '#0d6efd' : '#cfd4da'}`,

              borderRadius: 14,

              backgroundColor: isDragging ? 'rgba(13,110,253,0.06)' : selectedFile ? 'rgba(25,135,84,0.04)' : '#fafbfc',

              cursor: isUploading ? 'not-allowed' : 'pointer',

              opacity: isUploading ? 0.75 : 1,
            }}>
            <Form.Control
              ref={fileInputRef}
              type="file"
              accept=".csv,text/csv"
              className="d-none"
              onChange={handleInputChange}
              disabled={isUploading}
            />

            {selectedFile ? (
              <>
                <Icon icon="mdi:file-check-outline" width={50} className="text-success mb-3" />

                <h6 className="mb-1">{selectedFile.name}</h6>

                <div className="text-muted small mb-3">{(selectedFile.size / 1024).toFixed(2)} KB</div>

                {!isUploading && (
                  <div className="d-flex gap-2">
                    <Button
                      type="button"
                      variant="outline-primary"
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation()

                        fileInputRef.current?.click()
                      }}>
                      Replace File
                    </Button>

                    <Button
                      type="button"
                      variant="outline-danger"
                      size="sm"
                      onClick={(event) => {
                        event.stopPropagation()

                        handleRemoveFile()
                      }}>
                      Remove
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <>
                <Icon icon="mdi:cloud-upload-outline" width={55} className="text-primary mb-3" />

                <h6 className="mb-1">Drop your CSV file here</h6>

                <p className="text-muted small mb-3">or click to browse from your computer</p>

                <Badge bg="light" text="dark" className="border px-3 py-2">
                  CSV only · Maximum 5 MB
                </Badge>
              </>
            )}
          </div>

          {isUploading && (
            <div
              className="mt-4 p-4 text-center"
              style={{
                borderRadius: 14,
                border: '1px solid rgba(13,110,253,0.2)',
                background: 'linear-gradient(135deg, rgba(13,110,253,0.05), rgba(111,66,193,0.05))',
              }}>
              <div
                className="d-inline-flex align-items-center justify-content-center mb-3"
                style={{
                  width: 58,
                  height: 58,
                  borderRadius: '50%',
                  backgroundColor: 'rgba(13,110,253,0.1)',
                }}>
                <Spinner
                  animation="border"
                  variant="primary"
                  style={{
                    width: 30,
                    height: 30,
                  }}
                />
              </div>

              <div className="fw-semibold">{uploadMessage}</div>

              <div className="text-muted small mt-2">
                Please keep this window open while the CSV rows are validated and stock records are updated.
              </div>

              <div className="d-flex justify-content-center gap-2 mt-3">
                <span className="spinner-grow spinner-grow-sm text-primary" role="status" />

                <span
                  className="spinner-grow spinner-grow-sm text-primary"
                  role="status"
                  style={{
                    animationDelay: '0.15s',
                  }}
                />

                <span
                  className="spinner-grow spinner-grow-sm text-primary"
                  role="status"
                  style={{
                    animationDelay: '0.3s',
                  }}
                />
              </div>
            </div>
          )}
        </Card.Body>
      </Card>

      <Card className="border-0 shadow-sm mb-4">
        <Card.Body className="p-4">
          <div className="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
            <div>
              <h5 className="mb-1">Required CSV Format</h5>

              <p className="text-muted small mb-0">Use the exact column names shown below.</p>
            </div>

            <Button type="button" variant="outline-primary" size="sm" onClick={handleSampleDownload} disabled={isUploading}>
              <Icon icon="mdi:download" className="me-1" />
              Download Sample CSV
            </Button>
          </div>

          <div className="table-responsive">
            <Table bordered hover size="sm" className="align-middle mb-0">
              <thead className="table-light">
                <tr>
                  <th>Column</th>
                  <th>Required</th>
                  <th>Description</th>
                  <th>Example</th>
                </tr>
              </thead>

              <tbody>
                {[...REQUIRED_COLUMNS]
                  .sort((a, b) => Number(b.required) - Number(a.required))
                  .map((column) => (
                    <tr key={column.name}>
                      <td>
                        <code>
                          {column.name}

                          {column.required && <span className="text-danger">*</span>}
                        </code>
                      </td>

                      <td>{column.required ? <Badge bg="danger">Required</Badge> : <Badge bg="secondary">Optional</Badge>}</td>

                      <td>{column.description}</td>

                      <td>
                        <code>{column.example}</code>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </Table>
          </div>
        </Card.Body>
      </Card>

      {uploadResult && (
        <Card className="border-0 shadow-sm mb-4">
          <Card.Body className="p-4">
            <div className="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-4">
              <div>
                <div className="d-flex align-items-center gap-2 mb-1">
                  <span
                    className="d-inline-flex align-items-center justify-content-center rounded-circle"
                    style={{
                      width: 38,
                      height: 38,

                      backgroundColor: uploadResult.rejected_rows_count > 0 ? 'rgba(255,193,7,0.12)' : 'rgba(25,135,84,0.1)',

                      color: uploadResult.rejected_rows_count > 0 ? '#997404' : '#198754',
                    }}>
                    <Icon icon={uploadResult.rejected_rows_count > 0 ? 'mdi:alert-circle-outline' : 'mdi:check-circle-outline'} width={22} />
                  </span>

                  <div>
                    <h5 className="mb-0">Upload Result</h5>

                    <div className="text-muted small">{uploadResult.message}</div>
                  </div>
                </div>
              </div>

              <Badge
                bg={uploadResult.rejected_rows_count > 0 ? 'warning' : 'success'}
                text={uploadResult.rejected_rows_count > 0 ? 'dark' : undefined}
                className="px-3 py-2">
                {uploadResult.rejected_rows_count > 0 ? 'Completed with errors' : 'Completed successfully'}
              </Badge>
            </div>

            <Row className="g-3 mb-4">
              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: '#f8f9fa',
                    border: '1px solid #dee2e6',
                  }}>
                  <small className="text-muted">Total Rows</small>

                  <div className="fs-4 fw-bold">{uploadResult.total_rows}</div>
                </div>
              </Col>

              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: 'rgba(25,135,84,0.07)',
                    border: '1px solid rgba(25,135,84,0.2)',
                  }}>
                  <small className="text-success">Successful</small>

                  <div className="fs-4 fw-bold text-success">{uploadResult.successful_rows}</div>
                </div>
              </Col>

              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: 'rgba(255,193,7,0.08)',
                    border: '1px solid rgba(255,193,7,0.25)',
                  }}>
                  <small
                    style={{
                      color: '#997404',
                    }}>
                    Variant Errors
                  </small>

                  <div
                    className="fs-4 fw-bold"
                    style={{
                      color: '#997404',
                    }}>
                    {uploadResult.not_existing_rows_count}
                  </div>
                </div>
              </Col>

              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: 'rgba(13,110,253,0.07)',
                    border: '1px solid rgba(13,110,253,0.2)',
                  }}>
                  <small className="text-primary">Batch Errors</small>

                  <div className="fs-4 fw-bold text-primary">{uploadResult.batch_failed_rows_count}</div>
                </div>
              </Col>

              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: 'rgba(220,53,69,0.07)',
                    border: '1px solid rgba(220,53,69,0.2)',
                  }}>
                  <small className="text-danger">Update Failed</small>

                  <div className="fs-4 fw-bold text-danger">{uploadResult.stock_failed_rows_count}</div>
                </div>
              </Col>

              <Col xs={6} lg={2}>
                <div
                  className="p-3 h-100"
                  style={{
                    borderRadius: 12,
                    backgroundColor: 'rgba(111,66,193,0.07)',
                    border: '1px solid rgba(111,66,193,0.2)',
                  }}>
                  <small
                    style={{
                      color: '#6f42c1',
                    }}>
                    Stock Sheets
                  </small>

                  <div
                    className="fs-4 fw-bold"
                    style={{
                      color: '#6f42c1',
                    }}>
                    {uploadResult.stock_sheet_count}
                  </div>
                </div>
              </Col>
            </Row>

            {failedRows.length > 0 && (
              <>
                <Alert variant="warning" className="d-flex align-items-start justify-content-between gap-3 flex-wrap">
                  <div className="d-flex align-items-start gap-2">
                    <Icon icon="mdi:alert-outline" width={22} className="flex-shrink-0 mt-1" />

                    <div>
                      <div className="fw-semibold">Rejected rows need correction</div>

                      <div className="small mt-1">Correct the failed values and upload only those rows again.</div>
                    </div>
                  </div>

                  <Button
                    type="button"
                    variant="danger"
                    size="sm"
                    className="d-flex align-items-center gap-2"
                    onClick={() => handleFailedRowsDownload()}>
                    <Icon icon="mdi:file-download-outline" width={18} />
                    Download Failed Rows CSV
                  </Button>
                </Alert>

                <div className="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3">
                  <div>
                    <h6 className="mb-1 text-danger">Rejected CSV Rows</h6>

                    <div className="text-muted small">
                      Showing {(failedPage - 1) * FAILED_ROWS_PER_PAGE + 1}
                      {' – '}
                      {Math.min(failedPage * FAILED_ROWS_PER_PAGE, failedRows.length)} of {failedRows.length}
                    </div>
                  </div>

                  <Badge bg="danger" className="px-3 py-2">
                    {failedRows.length} rejected row(s)
                  </Badge>
                </div>

                <div className="table-responsive">
                  <Table bordered hover size="sm" className="align-middle mb-0">
                    <thead className="table-light">
                      <tr>
                        <th
                          style={{
                            minWidth: 85,
                          }}>
                          CSV Row
                        </th>

                        <th
                          style={{
                            minWidth: 115,
                          }}>
                          Variant ID
                        </th>

                        <th
                          style={{
                            minWidth: 140,
                          }}>
                          Batch Number
                        </th>

                        <th
                          style={{
                            minWidth: 100,
                          }}>
                          Quantity
                        </th>

                        <th
                          style={{
                            minWidth: 130,
                          }}>
                          Continue Selling
                        </th>

                        <th
                          style={{
                            minWidth: 115,
                          }}>
                          Reorder Level
                        </th>

                        <th
                          style={{
                            minWidth: 145,
                          }}>
                          Error Type
                        </th>

                        <th
                          style={{
                            minWidth: 320,
                          }}>
                          Failure Reason
                        </th>
                      </tr>
                    </thead>

                    <tbody>
                      {paginatedFailedRows.map((row, index) => {
                        const errorDetails = getFailureTypeDetails(row)

                        return (
                          <tr key={`${row.row_number || index}-${row.variant_id || 'variant'}-${row.batch_number || 'batch'}`}>
                            <td className="text-center fw-semibold">{row.row_number ?? (failedPage - 1) * FAILED_ROWS_PER_PAGE + index + 1}</td>

                            <td className="text-center">
                              <code>{row.variant_id || '-'}</code>
                            </td>

                            <td className="text-center">
                              {row.batch_number ? (
                                <Badge bg="light" text="dark" className="border">
                                  {row.batch_number}
                                </Badge>
                              ) : (
                                <span className="text-muted">No batch</span>
                              )}
                            </td>

                            <td className="text-center fw-semibold">{row.stock_quantity ?? '-'}</td>

                            <td className="text-center">{row.continue_selling || '-'}</td>

                            <td className="text-center">{row.reorder_level ?? '-'}</td>

                            <td>
                              <Badge
                                bg={errorDetails.variant}
                                text={errorDetails.variant === 'warning' || errorDetails.variant === 'info' ? 'dark' : undefined}
                                className="d-inline-flex align-items-center gap-1">
                                <Icon icon={errorDetails.icon} width={15} />

                                {errorDetails.label}
                              </Badge>

                              {row.error_type && (
                                <div className="text-muted mt-1">
                                  <small>{row.error_type}</small>
                                </div>
                              )}
                            </td>

                            <td>
                              <div className="d-flex align-items-start gap-2">
                                <Icon icon="mdi:alert-circle-outline" className="text-danger flex-shrink-0 mt-1" />

                                <span className="small text-danger">{row.reason || row.error || row.message || 'Unable to process this row.'}</span>
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </Table>
                </div>

                <div className="d-flex align-items-center justify-content-between gap-3 flex-wrap mt-3">
                  <div className="text-muted small">
                    Page {failedPage} of {totalFailedPages}
                  </div>

                  {renderPaginationItems()}
                </div>
              </>
            )}
          </Card.Body>
        </Card>
      )}

      <div className="d-flex justify-content-between pt-2">
        <Button variant="outline-secondary" onClick={handleClose} disabled={isUploading}>
          Close
        </Button>

        {requiredFieldsSelected && (
          <Button variant={stockType?.value === 'out' ? 'danger' : 'success'} onClick={handleUpload} disabled={isUploading}>
            {isUploading ? (
              <>
                <Spinner size="sm" className="me-2" />
                Updating Stock...
              </>
            ) : stockType?.value === 'out' ? (
              <>
                <Icon icon="mdi:package-variant-minus" className="me-2" />
                Update Stock Out
              </>
            ) : (
              <>
                <Icon icon="mdi:package-variant-plus" className="me-2" />
                Update Stock In
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}

export default CSVStockUpdate
