import { Modal, Table, Spinner, Card, Button } from "react-bootstrap";
import { useEffect } from "react";
import { useGetStockSheetDetailsMutation } from "@/store/features/apiSlice";

const ViewSheetDetails = ({
  sheetId,
  stockType,
  remark,
  createdBy,
  createdAt,
  show,
  onHide,
  outlet,
}) => {
  const [getStockSheetDetails, { data, isLoading, isError }] =
    useGetStockSheetDetailsMutation();

  useEffect(() => {
    if (show && sheetId) {
      getStockSheetDetails({ sheet_id: sheetId });
    }
  }, [show, sheetId, getStockSheetDetails]);


  const stockTypeBadge = (type) => {
    const colorMap = {
      'stock in': '#198754',   // green
      'stock out': '#dc3545',  // red
    }

    const backgroundColor = colorMap[type?.toLowerCase()] || '#adb5bd'

    return (
      <span
        style={{
          backgroundColor,
          color: 'white',
          padding: '4px 10px',
          borderRadius: '12px',
          textTransform: 'capitalize',
          fontSize: '0.65rem',
          display: 'inline-block',
          minWidth: '80px',
          textAlign: 'center',
        }}
      >
        {type}
      </span>
    )
  }


  return (
    <Modal show={show} onHide={onHide} size="xl" centered>


      <Modal.Header closeButton className="no-print">
        <Modal.Title>Sheet ID: #{sheetId}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        {/* =========================
            PRINT AREA
        ========================= */}
        <div className="print-area">
          {/* Summary Card */}
          <Card
            className="mb-3"
            style={{
              border: "1px solid gray", // full border
              borderRadius: "8px",      // optional rounded corners
            }}
          >
            <Card.Body className="bg-light">
              <p className="mb-1">
                <strong>Responsible User:</strong> {createdBy}
              </p>


              <p className="mb-1">
                <strong>Stock Type:</strong>{" "}
                <span className="stock-type-screen">
                  {stockTypeBadge(stockType)}
                </span>

                <span
                  className="stock-type-print"
                  style={{ display: 'none' }}
                >
                  {stockType
                    ? stockType.charAt(0).toUpperCase() + stockType.slice(1)
                    : ''}
                </span>
              </p>

              {outlet && (
                <p className="mb-1">
                  <strong>Outlet:</strong> {outlet}
                </p>
              )}



              <p className="mb-1">
                <strong>Date:</strong>{" "}
                {new Date(createdAt).toLocaleDateString()}
              </p>
              <p className="mb-1">
                <strong>Remark:</strong>{" "}
                {remark?.charAt(0).toUpperCase() + remark?.slice(1)}
              </p>
            </Card.Body>
          </Card>

          {/* Loading */}
          {isLoading && (
            <div className="text-center my-3">
              <Spinner animation="border" />
            </div>
          )}

          {/* Error */}
          {isError && (
            <p className="text-danger text-center">
              Failed to load details
            </p>
          )}

          {/* Table */}
          {!isLoading && data?.data?.length > 0 && (
            <Table
              bordered
              size="sm"
              responsive
              className="project-invoice"
            >
              <thead className="table-light">
                <tr>
                  <th>Product Details</th>
                  <th>Variant Details</th>
                  <th>SKU</th>
                  <th>Batch No</th>
                  <th>Barcode</th>
                  <th>Changed Qty</th>
                  <th>Previous Qty</th>
                  <th>Current Qty</th>



                </tr>
              </thead>
              <tbody>
                {data.data.map((d) => (
                  <tr key={d.sheet_details_id}>

                    <td style={{ width: 410, textAlign: d.product_id || d.product_title ? 'left' : 'center' }}>
                      {(d.product_id ?? '-') + ' - ' + (d.product_title ?? '-')}
                    </td>

                    <td style={{ textAlign: d.variant_id || d.variant_value ? 'left' : 'center' }}>
                      {(d.variant_id ?? '-') + ' - ' + (d.variant_value ?? '-')}
                    </td>

                    <td style={{ textAlign: d.sku ? 'left' : 'center' }}>
                      {d.sku ?? '-'}
                    </td>

                    <td style={{ textAlign: d.batch_number ? 'left' : 'center' }}>
                      {d.batch_number ?? '-'}
                    </td>

                    <td style={{ textAlign: d.barcode ? 'left' : 'center' }}>
                      {d.barcode ?? '-'}
                    </td>

                    <td style={{ textAlign: d.changed_qty !== null && d.changed_qty !== undefined ? 'left' : 'center' }}>
                      {d.changed_qty ?? '-'}
                    </td>

                    <td style={{ textAlign: d.previous_stock !== null && d.previous_stock !== undefined ? 'left' : 'center' }}>
                      {d.previous_stock ?? '-'}
                    </td>

                    <td style={{ textAlign: d.current_stock !== null && d.current_stock !== undefined ? 'left' : 'center' }}>
                      {d.current_stock ?? '-'}
                    </td>




                  </tr>
                ))}
              </tbody>
            </Table>
          )}

          {!isLoading && (!data?.data || data.data.length === 0) && (
            <p className="text-center text-muted">No records found</p>
          )}
        </div>

        {/* =========================
            PRINT STYLES
        ========================= */}
        <style jsx global>{`
          /* =========================
             SCREEN ONLY
          ========================= */
          .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
          }

          /* =========================
             PRINT SETUP
          ========================= */
          @media print {
            @page {
              size: A4;
              margin: 0;
            }

            html,
            body {
              width: 210mm;
              height: 297mm;
              margin: 0 !important;
              padding: 0 !important;
              background: #fff !important;
              overflow: hidden !important;
            }

            /* Hide everything except modal */
            body > *:not(.modal) {
              display: none !important;
            }

            /* Modal becomes document */
            .modal {
              position: fixed !important;
              inset: 0 !important;
              display: block !important;
              background: #fff !important;
              margin: 0 !important;
              padding: 0 !important;
            }

            .modal-dialog,
            .modal-content {
              width: 100% !important;
              height: 100% !important;
              max-width: 100% !important;
              margin: 0 !important;
              padding: 0 !important;
              border: none !important;
              border-radius: 0 !important;
              box-shadow: none !important;
            }

            /* Remove modal chrome */
            .modal-header,
            .modal-footer {
              display: none !important;
            }

            /* Printable area */
            .print-area {
              width: 100% !important;
              height: 100% !important;
              margin: 0 !important;
              padding: 16px !important;
              background: #fff !important;
            }

            /* Remove UI effects */
            .card,
            .shadow,
            .shadow-sm,
            .rounded,
            .border {
              border-radius: 0 !important;
              box-shadow: none !important;
            }

            .card {
              border: none !important;
            }

            .card-body {
              padding: 0 !important;
            }

            /* Table safety */
            table {
              width: 100% !important;
              page-break-inside: auto;
            }

            tr {
              page-break-inside: avoid;
            }

            thead {
              display: table-header-group;
            }

            /* No-print utility */
            .no-print {
              display: none !important;
            }

            button,
            input,
            select {
              display: none !important;
            }

            .modal-backdrop {
              display: none !important;
            }
            .stock-type-print {
  display: none;
}

@media print {
 

  .stock-type-screen {
    display: none !important;
  }

  .stock-type-print {
    display: inline !important;
  }
}
          }
        `}</style>
      </Modal.Body>

      <Modal.Footer className="no-print">
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
        <Button variant="primary" onClick={() => window.print()}>
          Print
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ViewSheetDetails;
