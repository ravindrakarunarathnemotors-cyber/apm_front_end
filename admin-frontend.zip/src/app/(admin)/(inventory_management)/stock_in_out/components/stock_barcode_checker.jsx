'use client'

import { useEffect, useRef, useState } from 'react'
import { Form, InputGroup, Spinner } from 'react-bootstrap'
import { useCheckProductBarcodeMutation } from '@/store/features/apiSlice'

/**
 * StockBarcodeChecker
 * ------------------------------------------------------
 * - Stock In / Out barcode checker
 * - Debounced uniqueness validation
 * - Spinner appears INSIDE input (right side)
 * - No background / no separated addon
 * - Skips validation for prefilled DB barcode
 * - Uses SAME RTK mutation
 */
export default function StockBarcodeChecker({ value = '', onChange, maxLength = 30, debounceMs = 500 }) {
  const [barcode, setBarcode] = useState(value)
  const [error, setError] = useState('')
  const [isValid, setIsValid] = useState(false)
  const [isChecking, setIsChecking] = useState(false)

  const [checkBarcode] = useCheckProductBarcodeMutation()

  const debounceTimerRef = useRef(null)
  const lastCheckedRef = useRef('')
  const initialBarcodeRef = useRef('')
  const isUserEditingRef = useRef(false)

  /* ------------------------------------------------------
   Sync with parent value
   ------------------------------------------------------ */
  useEffect(() => {
    if (isUserEditingRef.current) {
      isUserEditingRef.current = false
      return
    }

    const next = value || ''
    setBarcode(next)

    // capture initial DB barcode ONCE
    if (!initialBarcodeRef.current && next) {
      const trimmed = next.trim()
      initialBarcodeRef.current = trimmed
      lastCheckedRef.current = trimmed
    }

    if (!next) {
      initialBarcodeRef.current = ''
      lastCheckedRef.current = ''
      setError('')
      setIsValid(false)
      setIsChecking(false)
    }
  }, [value])

  /* ------------------------------------------------------
   Debounced validation
   ------------------------------------------------------ */
  useEffect(() => {
    const val = barcode.trim()

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
    }

    setIsValid(false)
    setIsChecking(false)

    if (!val) {
      setError('')
      lastCheckedRef.current = ''
      return
    }

    // skip original DB value
  if (val === initialBarcodeRef.current) {
  setError('')
  setIsValid(true)
  onChange?.(val, true)
  return
}


    if (val === lastCheckedRef.current) return

    debounceTimerRef.current = setTimeout(async () => {
      try {
        setIsChecking(true)
        lastCheckedRef.current = val

        const res = await checkBarcode(val).unwrap()

   if (res?.exists) {
  setError('Barcode already exists')
  setIsValid(false)
  onChange?.(val, false)
} else {
  setError('')
  setIsValid(true)
  onChange?.(val, true)
}

      } catch {
  setError('Barcode validation failed')
  setIsValid(false)
  onChange?.(val, false)
}
 finally {
        setIsChecking(false)
      }
    }, debounceMs)

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current)
      }
    }
  }, [barcode, debounceMs, checkBarcode])

  /* ------------------------------------------------------
   Handle input
   ------------------------------------------------------ */
  const handleChange = (e) => {
    const val = e.target.value
    if (val.length > maxLength) return

    isUserEditingRef.current = true
    setBarcode(val)
    setError('')
    setIsValid(false)
    setIsChecking(false)

   onChange?.(val, false) // pessimistic until validated

  }

  /* ------------------------------------------------------
   Render
   ------------------------------------------------------ */
  return (
    <div style={{ position: 'relative' }}>
      <Form.Control
        size="sm"
        type="text"
        className="text-center pe-4" // padding for spinner
        placeholder="Enter Barcode"
        value={barcode}
        maxLength={maxLength}
        onChange={handleChange}
        isInvalid={!!error}
        isValid={isValid}
      />

      {/* 🔄 Inline spinner (NO background, NO border) */}
      {isChecking && (
        <Spinner
          animation="border"
          size="sm"
          style={{
            position: 'absolute',
            right: 8,
            top: '50%',
            transform: 'translateY(-50%)',
            pointerEvents: 'none',
          }}
        />
      )}

      {error && <Form.Text className="text-danger d-block text-center">{error}</Form.Text>}

      {/* ✅ Valid check icon tweak */}
      <style jsx global>{`
        .form-control.is-valid {
          background-size: 0.75rem 0.75rem;
          background-position: right 0.45rem center;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23198754' d='M6.564.75L3.59 4.63 1.564 2.75.75 3.564l2.5 2.5.686.686.686-.686 3.5-3.5z'/%3E%3C/svg%3E");
        }
      `}</style>
    </div>
  )
}
