import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Stock In/Out',
}

const StockInOut = dynamic(() => import('./StockInOut'), { ssr: false })

export default function StockInOutPage() {
  return <StockInOut />
}