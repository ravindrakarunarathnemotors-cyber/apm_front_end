'use client'

import { useState } from 'react'
import { Form, Button, Card, CardHeader, CardBody, CardTitle, Col, Modal, Row, Spinner, Toast, Table, ToastContainer } from 'react-bootstrap'
import Select from 'react-select'
import AsyncSelect from 'react-select/async'

// 🧪 Mock product + variant data
const mockProducts = [
  { product_id: 'p1', name: 'Red T-Shirt', current_stock: 12 },
  { product_id: 'p2', name: 'Blue Jeans', current_stock: 7 },
  { product_id: 'p3', name: 'Sneakers', current_stock: 20 },
  { product_id: 'p4', name: 'Hoodie', current_stock: 5 },
  { product_id: 'p5', name: 'Long Sleeve', current_stock: 8 },
]

const mockVariants = {
  p1: [
    { variant_id: 'v1', name: 'Red T-Shirt - Small', sku: 'SKU-R-S', stock: 4 },
    { variant_id: 'v2', name: 'Red T-Shirt - Medium', sku: 'SKU-R-M', stock: 8 },
  ],
  p2: [
    { variant_id: 'v3', name: 'Blue Jeans - 32', sku: 'SKU-BJ-32', stock: 4 },
    { variant_id: 'v4', name: 'Blue Jeans - 34', sku: 'SKU-BJ-34', stock: 3 },
  ],
  p3: [
    { variant_id: 'v5', name: 'Sneakers - 8', sku: 'SKU-S-8', stock: 10 },
    { variant_id: 'v6', name: 'Sneakers - 9', sku: 'SKU-S-9', stock: 10 },
  ],
  p4: [
    { variant_id: 'v7', name: 'Hoodie - M', sku: 'SKU-H-M', stock: 3 },
    { variant_id: 'v8', name: 'Hoodie - L', sku: 'SKU-H-L', stock: 2 },
  ],
}

// 🔁 Mock mutation
const useStockUpdateMutation = () => {
  const [isLoading, setIsLoading] = useState(false)
  const mutate = async (payload) => {
    setIsLoading(true)
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        setIsLoading(false)
        if (Math.random() > 0.2) {
          resolve({ message: 'Stock updated!', payload })
        } else {
          reject(new Error('Server error!'))
        }
      }, 1000)
    })
  }
  return [mutate, { isLoading }]
}

const StockInOut = () => {
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [quantity, setQuantity] = useState('')
  const [stockType, setStockType] = useState('in')
  const [variants, setVariants] = useState([])
  const [variantEdits, setVariantEdits] = useState({})
  const [showConfirmModal, setShowConfirmModal] = useState(false)

  const [toast, setToast] = useState({ show: false, message: '', variant: 'success' })
  const [recentUpdates, setRecentUpdates] = useState([])

  const [updateStock, { isLoading }] = useStockUpdateMutation()

  const handleVariantChange = (variant_id, field, value) => {
    setVariantEdits((prev) => ({
      ...prev,
      [variant_id]: { ...prev[variant_id], [field]: value },
    }))
  }

  // 🔍 Handle all searches
  const handleProductSearch = async (inputValue) => {
    const input = inputValue.toLowerCase()
    return mockProducts
      .filter(
        (p) =>
          p.name.toLowerCase().includes(input) ||
          p.product_id.toLowerCase().includes(input) ||
          (mockVariants[p.product_id] || []).some((v) => v.variant_id.toLowerCase().includes(input) || v.name.toLowerCase().includes(input)),
      )
      .map((p) => ({
        value: p.product_id,
        label: `${p.name} (Stock: ${p.current_stock})`,
        name: p.name,
      }))
  }

  const handleProductChange = (selected) => {
    setSelectedProduct(selected)
    setQuantity('')
    setVariants([])
  }

  const isFormValid = selectedProduct && stockType

  const handleVariantSave = async () => {
    try {
      const updatedVariants = []

      await Promise.all(
        Object.entries(variantEdits).map(async ([variant_id, data]) => {
          const payload = {
            variant_id,
            sku: data.sku ?? '',
            barcode: data.barcode ?? '',
            quantity: data.quantity ? (stockType === 'in' ? data.quantity : -Math.abs(data.quantity)) : 0,
          }

          await updateStock(payload)

          // Get variant name from current variant list
          const variantName = variants.find((v) => v.variant_id === variant_id)?.name || variant_id

          updatedVariants.push({
            variant_id,
            name: variantName,
            quantity: payload.quantity,
            sku: payload.sku,
            barcode: payload.barcode,
            continue_selling: payload.continue_selling,
            reorder_level: payload.reorder_level,
          })
        }),
      )

      const newEntry = {
        id: Date.now(),
        product: `${selectedProduct.label} (${stockType === 'in' ? 'Stock In' : 'Stock Out'})`,
        branch: '-', // Replace with actual branch if needed
        type: stockType,
        variants: updatedVariants,
      }

      setRecentUpdates((prev) => [newEntry, ...prev.slice(0, 4)]) // Max 5 groups
      setToast({ show: true, message: '✅ Variant stock updated!', variant: 'success' })
      setVariantEdits({})
      setVariants([])
    } catch (err) {
      setToast({ show: true, message: '❌ Failed to update variant stock', variant: 'danger' })
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!isFormValid) return

    // Optionally still update stock log for main product (or disable this if only variants matter)
    const payload = {
      product_id: selectedProduct.value,
      quantity: 0,
      type: stockType,
    }

    try {
      const response = await updateStock(payload)
      setToast({ show: true, message: '✅ Variants loaded & stock log updated!', variant: 'success' })
      setRecentUpdates((prev) => [
        {
          id: Date.now(),
          product: selectedProduct.label,
          quantity: '-',
          type: stockType,
        },
        ...prev.slice(0, 9),
      ])
      setSelectedProduct(null)
      setVariants([])
      setVariantEdits({})
    } catch (error) {
      setToast({ show: true, message: '❌ Update failed. ' + error.message, variant: 'danger' })
    }
  }

  const handleSearch = () => {
    // ⏬ Load variants here now
    const newVariants = mockVariants[selectedProduct.value] || []
    setVariants(newVariants)

    // setVariants(mockVariants[selected.value] || [])
  }

  return (
    <>
      <Form onSubmit={handleSubmit}>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Stock In/Out
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>
          <CardBody>
            <Row className="mb-3">
              <Col md={6}>
                <Form.Label>Search Product (ID, Name, Variant)</Form.Label>
                <AsyncSelect
                  cacheOptions
                  loadOptions={handleProductSearch}
                  onChange={handleProductChange}
                  value={selectedProduct}
                  placeholder="Search by product ID, name, variant ID/name..."
                />
              </Col>

              <Col md={4}>
                <Form.Label>Stock Type</Form.Label>
                <Select
                  options={[
                    { label: 'Stock In', value: 'in' },
                    { label: 'Stock Out', value: 'out' },
                  ]}
                  placeholder="Select Stock Type"
                  value={stockType ? { label: stockType === 'in' ? 'Stock In' : 'Stock Out', value: stockType } : null}
                  onChange={(selected) => setStockType(selected?.value || '')}
                  isClearable
                />
              </Col>
              <Col md={2} className="align-self-end">
                <div className="d-flex justify-content-end  align-items-end">
                  <Button onClick={handleSearch} disabled={!selectedProduct || !stockType || isLoading}>
                    {isLoading ? <Spinner size="sm" animation="border" /> : 'Search'}
                  </Button>
                </div>
              </Col>
            </Row>

            {variants.length > 0 && (
              <Row className="mt-4">
                <Col>
                  <Table size="sm" responsive>
                    <thead>
                      <tr>
                        <th>Variant ID</th>
                        <th>Name</th>
                        <th style={{ width: '120px' }}>SKU</th>
                        <th style={{ width: '120px' }}>Barcode</th>
                        <th style={{ width: '120px' }}>Continue Selling</th>
                        <th style={{ width: '100px' }}>Stock</th>
                        <th style={{ width: '150px' }}>Reorder Level</th>
                        <th style={{ width: '150px' }}>Quantity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {variants.map((v) => {
                        const edit = variantEdits[v.variant_id] || {}
                        return (
                          <tr key={v.variant_id}>
                            <td>{v.variant_id}</td>
                            <td>{v.name}</td>

                            <td>
                              {v.sku ? (
                                <span>{v.sku}</span>
                              ) : (
                                <Form.Control
                                  size="sm"
                                  placeholder="SKU"
                                  value={edit.sku ?? ''}
                                  onChange={(e) => handleVariantChange(v.variant_id, 'sku', e.target.value)}
                                />
                              )}
                            </td>

                            <td>
                              {v.barcode ? (
                                <span>{v.barcode}</span>
                              ) : (
                                <Form.Control
                                  size="sm"
                                  placeholder="Barcode"
                                  value={edit.barcode ?? ''}
                                  onChange={(e) => handleVariantChange(v.variant_id, 'barcode', e.target.value)}
                                />
                              )}
                            </td>

                            <td className="text-center">
                              <Form.Check
                                type="checkbox"
                                checked={edit.continue_selling ?? true}
                                onChange={(e) => handleVariantChange(v.variant_id, 'continue_selling', e.target.checked)}
                              />
                            </td>

                            <td>
                              <Form.Control size="sm" value={v.stock} readOnly disabled style={{ border: 'none' }} />
                            </td>
                            <td>
                              <Form.Control
                                size="sm"
                                type="number"
                                placeholder="Reorder Level"
                                value={edit.reorder_level ?? ''}
                                onChange={(e) => handleVariantChange(v.variant_id, 'reorder_level', parseInt(e.target.value) || '')}
                              />
                            </td>

                            <td>
                              <Form.Control
                                size="sm"
                                type="number"
                                placeholder="Qty"
                                value={edit.quantity ?? ''}
                                onChange={(e) => handleVariantChange(v.variant_id, 'quantity', parseInt(e.target.value) || '')}
                              />
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </Table>

                  {Object.keys(variantEdits).length > 0 && (
                    <div className="d-flex justify-content-between align-items-center">
                      <span className="text-muted">
                        Total Quantity: {Object.values(variantEdits).reduce((acc, cur) => acc + (parseInt(cur.quantity) || 0), 0)}
                      </span>
                      <Button onClick={() => setShowConfirmModal(true)}>
                        {isLoading ? (
                          <>
                            <Spinner size="sm" animation="border" className="me-2" />
                            Updating...
                          </>
                        ) : (
                          'Update Variant Stock'
                        )}
                      </Button>
                    </div>
                  )}
                </Col>
              </Row>
            )}
          </CardBody>
        </Card>
      </Form>

      {/* Toasts */}
      <ToastContainer position="top-end" className="p-3">
        <Toast show={toast.show} bg={toast.variant} onClose={() => setToast({ ...toast, show: false })} delay={3000} autohide>
          <Toast.Body className="text-white">{toast.message}</Toast.Body>
        </Toast>
      </ToastContainer>

      <Modal show={showConfirmModal} onHide={() => setShowConfirmModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Update</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to update <strong>{Object.keys(variantEdits).length}</strong> edited variant(s)?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowConfirmModal(false)}>
            Cancel
          </Button>
          <Button
            onClick={async () => {
              setShowConfirmModal(false)
              await handleVariantSave()
            }}>
            Yes, Update
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Table of recent updates */}
      <hr className="my-4" />
      <h5>Recent Stock Updates</h5>
      <Table striped bordered hover responsive size="sm">
        <thead>
          <tr style={{ height: '50px', borderRadius: '0px', textAlign: 'center' }}>
            <th>ID</th>
            <th>Product / Variant</th>
            <th>Type</th>
            <th>Quantity</th>
            <th>SKU</th>
            <th>Barcode</th>
            <th>Continue Selling</th>
            <th>Reorder Level</th>
          </tr>
        </thead>
        <tbody>
          {recentUpdates.map((group, idx) => (
            <>
              {group.variants.map((v) => (
                <tr key={v.variant_id}>
                  <td style={{ paddingLeft: '10px' }}>{v.variant_id}</td>
                  <td style={{ paddingLeft: '10px' }}>{v.name}</td>
                  <td style={{ textAlign: 'center', paddingRight: '10px' }}>{group.type.toUpperCase()}</td>
                  <td style={{ textAlign: 'end', paddingRight: '10px' }}>{v.quantity}</td>
                  <td>{v.sku || '-'}</td>
                  <td>{v.barcode || '-'}</td>
                  <td style={{ textAlign: 'center' }}>{v.continue_selling === false ? '❌' : '✅'}</td>
                  <td style={{ textAlign: 'center' }}>{v.reorder_level ?? '-'}</td>
                </tr>
              ))}
            </>
          ))}
          {recentUpdates.length === 0 && (
            <tr>
              <td colSpan="5" className="text-center">
                No updates yet.
              </td>
            </tr>
          )}
        </tbody>
      </Table>
    </>
  )
}

export default StockInOut
