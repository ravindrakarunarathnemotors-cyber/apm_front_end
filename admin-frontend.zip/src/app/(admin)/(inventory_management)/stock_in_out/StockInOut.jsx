'use client'
import { useState, useEffect, useCallback } from 'react'
import {
  Form,
  Button,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Col,
  Row,
  Spinner,
  Toast,
  Table,
  ToastContainer,
  InputGroup,
  Modal,
} from 'react-bootstrap'
import Select from 'react-select'
import AsyncSelect from 'react-select/async'
import debounce from 'lodash/debounce'
// import { useRouter } from 'next/navigation'
import BatchManagement from '../batch_management/BatchManagement'
import {
  useLazySearchProductVariantsQuery,
  useUpdateStockInOutMutation,
  useFetchInventorySubOutletsQuery,
  useLazySearchInventoryProductsQuery,
  useLazyGetVariantBatchStockQuery,
} from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import StockInOutHistory from './components/StockInOutHistory'
import StockBarcodeChecker from './components/stock_barcode_checker'
import CSVStockUpdate from './components/CSVStockUpdate'

const highlightMatch = (text, input) => {
  if (!input) return text
  const regex = new RegExp(`(${input})`, 'gi')
  return text.replace(regex, '<strong>$1</strong>')
}

const resolveVariantDisplayName = ({ variant_value, variant_type, productTitle, fallback = '—' }) => {
  const isDefault = String(variant_value || '').toLowerCase() === 'default' || String(variant_type || '').toLowerCase() === 'default'

  return isDefault ? productTitle : variant_value || fallback
}

const StockInOut = () => {
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [stockType, setStockType] = useState('in')
  const [variants, setVariants] = useState([])
  const [historyRefreshKey, setHistoryRefreshKey] = useState(0)
  const [variantEdits, setVariantEdits] = useState({})
  const [refreshing, setRefreshing] = useState(false)
  const [toast, setToast] = useState({ show: false, message: '', variant: 'success' })
  const [recentUpdates, setRecentUpdates] = useState([])
  const [fetchVariants, { data, isFetching }] = useLazySearchProductVariantsQuery()
  const [options, setOptions] = useState([])
  const [dirtyVariants, setDirtyVariants] = useState(new Set())
  const [updateStockInOut] = useUpdateStockInOutMutation()
  const [batchLoadingMap, setBatchLoadingMap] = useState({})
  const [didSearch, setDidSearch] = useState(false)
  const hasEdits = dirtyVariants.size > 0
  const [headerProduct, setHeaderProduct] = useState(null)
  const [searchPayload, setSearchPayload] = useState(null)
  const [showBatchModal, setShowBatchModal] = useState(false)
  const [showCSVUploadModal, setShowCSVUploadModal] = useState(false)
  const [batchModalVariant, setBatchModalVariant] = useState(null)
  const [selectedOutlet, setSelectedOutlet] = useState(null)
  const [fetchVariantBatchStock] = useLazyGetVariantBatchStockQuery()

  const [fieldConfig, setFieldConfig] = useState({
    sku: true,
    barcode: true,
    batch_no: true,
  })

  const { data: outletOptions = [], isLoading: outletsLoading } = useFetchInventorySubOutletsQuery()
  // const router = useRouter()

  const [searchProducts] = useLazySearchInventoryProductsQuery()
  const debouncedFetcher = useCallback(
    debounce(async (inputValue, resolve) => {
      if (inputValue.length < 2) return resolve([])

      try {
        const res = await searchProducts({ query: inputValue }).unwrap()

        // Show each product only once in the search list
        const uniqueProducts = Array.from(new Map(res.results.map((p) => [p.product_id, p])).values())

        const mapped = uniqueProducts.map((p) => ({
          value: p.product_id,
          label: p.title,
          name: p.title,

          // keep the first variant id if present
          variant_id: p.variant_id || null,

          searchValue: String(p.product_id),
        }))

        resolve(mapped)
      } catch (err) {
        console.error('Failed to fetch products:', err)
        resolve([])
      }
    }, 300),
    [searchProducts],
  )

  const showBatchAddDeniedModal = async () => {
    await Swal.fire({
      icon: 'warning',
      title: 'Batch Adding Privilege Denied',
      text: 'You do not have permission to add new batches. Please contact your administrator.',
      confirmButtonText: 'OK',
      confirmButtonColor: '#0d6efd',
      backdrop: 'rgba(0,0,0,0.35)',
    })
  }

  const openBatchModal = async (variant) => {
    if (!fieldConfig.batch_no) {
      await showBatchAddDeniedModal()
      return
    }

    setBatchModalVariant({
      product_id: selectedProduct?.value || headerProduct?.product_id || variant.product_id,
      product_title: selectedProduct?.label || headerProduct?.title || headerProduct?.product_title || 'Selected Product',
      image: variant.image || variant.product_image || '/package.png',
      variant_id: variant.variant_id,
      variant_value: resolveVariantDisplayName({
        variant_value: variant.variant_value,
        variant_type: variant.variant_type,
        productTitle: selectedProduct?.label || headerProduct?.title || headerProduct?.product_title,
      }),
      variant_type: variant.variant_type,
    })

    setShowBatchModal(true)
  }

  const refetchCurrentStock = async () => {
    if (!searchPayload || !selectedOutlet) return

    try {
      const res = await fetchVariants({
        query: searchPayload.query,
        outlet_id: selectedOutlet.value,
      }).unwrap()

      const product = res.results?.find((p) => String(p.product_id) === String(searchPayload.query))
      if (!product) return

      setVariants((prev) =>
        prev.map((old) => {
          const fresh = product.variants.find((v) => v.variant_id === old.variant_id)

          return fresh
            ? {
                ...old,
                stock: fresh.current_stock ?? 0,
                measurement_value: fresh.measurement_value ?? old.measurement_value,
                batch_numbers: fresh.batch_numbers || old.batch_numbers || [],
              }
            : old
        }),
      )
    } catch (err) {
      console.error('❌ Failed to refetch stock:', err)
    }
  }

  const handleVariantSave = async () => {
    /* ======================================================
   VALIDATION: invalid barcode
====================================================== */

    for (const variant_id of dirtyVariants) {
      const edit = variantEdits[variant_id]
      if (!edit) continue

      if (edit.barcode && edit.barcode_valid === false) {
        await Swal.fire({
          icon: 'error',
          title: 'Invalid Barcode',
          html: `
        <div style="font-size:14px; color:#555;">
          One or more variants have an <b>invalid barcode</b>.<br/>
          Please fix the barcode before submitting.
        </div>
      `,
          confirmButtonText: 'OK',
          confirmButtonColor: '#dc3545',
          backdrop: 'rgba(0,0,0,0.35)',
        })
        return
      }
    }

    /* ======================================================
     VALIDATION: changes without quantity
  ====================================================== */

    for (const variant_id of dirtyVariants) {
      const edit = variantEdits[variant_id]
      if (!edit) continue

      const qty = Number(edit.quantity)
      const hasValidQty = Number.isFinite(qty) && qty !== 0

      const changedMeta =
        stockType === 'wastage'
          ? edit.batch_number?.trim() || edit.note?.trim()
          : (fieldConfig.sku && edit.sku?.trim()) ||
            (fieldConfig.batch_no && edit.batch_number?.trim()) ||
            (fieldConfig.barcode && edit.barcode?.trim()) ||
            (edit.reorder_level !== '' && edit.reorder_level != null)

      if (changedMeta && !hasValidQty) {
        await Swal.fire({
          icon: 'warning',
          title: 'Quantity Required',
          html: `
          <div style="font-size:14px; color:#555;">
            You changed variant details but did not enter a <b>quantity</b>.<br/>
            Please enter a quantity to update stock.
          </div>
        `,
          confirmButtonText: 'OK',
          confirmButtonColor: '#0d6efd',
          backdrop: 'rgba(0,0,0,0.35)',
        })
        return
      }
    }

    /* ======================================================
   CONFIRM VARIANT COUNT (MUST COME FIRST)
====================================================== */

    if (stockType === 'wastage') {
      for (const variant_id of dirtyVariants) {
        const edit = variantEdits[variant_id]
        if (!edit) continue

        const qty = Math.abs(Number(edit.quantity))

        if (!Number.isFinite(qty) || qty <= 0) {
          await Swal.fire({
            icon: 'warning',
            title: 'Wastage Quantity Required',
            text: 'Please enter a valid wastage quantity.',
            confirmButtonColor: '#0d6efd',
          })
          return
        }

        if (fieldConfig.batch_no && !edit.batch_number?.trim()) {
          await Swal.fire({
            icon: 'warning',
            title: 'Batch Required',
            text: 'Please select a batch number for stock wastage.',
            confirmButtonColor: '#0d6efd',
          })
          return
        }

        if (!edit.note?.trim()) {
          await Swal.fire({
            icon: 'warning',
            title: 'Note Required',
            text: 'Please enter a note for stock wastage.',
            confirmButtonColor: '#0d6efd',
          })
          return
        }
      }
    }

    const variantCount = dirtyVariants.size

    const confirm = await Swal.fire({
      icon: 'question',
      title: stockType === 'wastage' ? 'Confirm Stock Wastage' : 'Confirm Stock Update',
      html: `
<div style="font-size:14px; color:#555;">
  You are about to ${stockType === 'wastage' ? 'record stock wastage' : 'update stock'} for<br/>
  <b style="font-size:18px;">${variantCount}</b> variant${variantCount > 1 ? 's' : ''}.
</div>
`,
      showCancelButton: true,
      confirmButtonText: 'Yes, Update',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#198754',
      cancelButtonColor: '#dc3545',
      backdrop: 'rgba(0,0,0,0.35)',
    })

    if (!confirm.isConfirmed) {
      return
    }

    const outlet_id = selectedOutlet?.value

    /* ======================================================
   BUILD BULK PAYLOAD & SUBMIT
====================================================== */
    setRefreshing(true)

    try {
      const itemsPayload = []

      for (const variant_id of dirtyVariants) {
        const data = variantEdits[variant_id]
        const variant = variants.find((v) => v.variant_id === variant_id)
        if (!data || !variant) continue

        const qty = Number(data.quantity)
        const hasQty = Number.isFinite(qty) && qty !== 0

        const payload =
          stockType === 'wastage'
            ? {
                variant_id,
                outlet_id,
                batch_number: data.batch_number || null,
                adjust_quantity: Math.abs(qty),
                note: data.note || null,
              }
            : {
                variant_id,
                outlet_id,
                continue_selling_oos: data.continue_selling ?? true,
                sku: data.sku || null,
                batch_number: data.batch_number || null,
                barcode: data.barcode || null,
                reorder_level: Number.isFinite(Number(data.reorder_level)) ? Number(data.reorder_level) : null,
              }

        // only attach quantity if present
        if (hasQty && stockType !== 'wastage') {
          payload.adjust_quantity = stockType === 'in' ? Math.abs(qty) : -Math.abs(qty)
        }

        itemsPayload.push(payload)
      }

      if (itemsPayload.length === 0) {
        setToast({
          show: true,
          message: 'No valid stock changes to submit',
          variant: 'warning',
        })
        return
      }

      const response = await updateStockInOut({
        session_user_id: sessionStorage.getItem('user_id'),
        outlet_id,
        stock_type: stockType === 'wastage' ? 'wastage' : undefined,
        items: itemsPayload,
      }).unwrap()

      /* ======================================================
   UPDATE RECENT UPDATES FROM BACKEND RESPONSE
====================================================== */
      const now = new Date().toISOString()
      setRecentUpdates((prev) => [
        {
          type: stockType,
          timestamp: now,
          productName: selectedProduct?.name || '',
          variants: response.results.map((r) => {
            const edit = variantEdits[r.variant_id] || {}
            const variant = variants.find((v) => v.variant_id === r.variant_id)

            return {
              variant_id: r.variant_id,
              name: resolveVariantDisplayName({
                variant_value: variant?.variant_value,
                variant_type: variant?.variant_type,
                productTitle: selectedProduct?.name,
              }),

              quantity: r.adjust_quantity,
              sku: edit.sku || '',
              batch_number: edit.batch_number || '',
              barcode: edit.barcode || '',
              continue_selling: edit.continue_selling ?? true,
              reorder_level: edit.reorder_level ?? '-',
              note: edit.note || '',
            }
          }),
        },
        ...prev.slice(0, 9),
      ])

      setToast({
        show: true,
        message: stockType === 'wastage' ? 'Stock wastage saved successfully!' : 'Stock updated successfully!',
        variant: 'success',
      })

      setHistoryRefreshKey((prev) => prev + 1)

      setVariants((prev) =>
        prev.map((v) => {
          const edit = variantEdits[v.variant_id]
          if (!edit || !edit.quantity) return v

          return {
            ...v,
            stock: v.stock + (stockType === 'in' ? Math.abs(Number(edit.quantity)) : -Math.abs(Number(edit.quantity))),
          }
        }),
      )

      // 🔄 instantly refetch latest stock
      await refetchCurrentStock()

      // 🧹 clear dirty state
      setDirtyVariants(new Set())

      setVariantEdits((prev) => {
        const cleared = { ...prev }

        for (const variant_id of dirtyVariants) {
          cleared[variant_id] = {
            ...cleared[variant_id],
            quantity: '',
            note: '',
            batch_number: '',
          }
        }

        return cleared
      })
    } catch (err) {
      console.error('❌Stock update failed:', err)
      setToast({
        show: true,
        message: err?.data?.error || '❌ Failed to update stock',
        variant: 'danger',
      })
    } finally {
      setRefreshing(false)
    }
  }

  const loadOptions = (inputValue) =>
    new Promise((resolve) => {
      debouncedFetcher(inputValue, resolve)
    })

  const handleProductChange = (selected) => {
    setSelectedProduct(selected)
    if (selected) {
      setHeaderProduct(selected)

      // ✅ store STRING only
      setSearchPayload({
        query: selected.searchValue,
      })
    }

    setDidSearch(false)
    setVariants([])
    setVariantEdits({})
    setDirtyVariants(new Set())
  }

  const handleVariantChange = (variant_id, field, value, extra = {}) => {
    setVariantEdits((prev) => ({
      ...prev,
      [variant_id]: {
        ...prev[variant_id],
        [field]: value,
        ...extra, //  allow barcode_valid
      },
    }))

    setDirtyVariants((prev) => new Set(prev).add(variant_id))
  }
  const handleSearch = async () => {
    if (!searchPayload || !selectedOutlet) return

    setDidSearch(true)

    try {
      const res = await fetchVariants({
        query: searchPayload.query,

        outlet_id: selectedOutlet.value,
      }).unwrap()

      if (res.field_config) {
        setFieldConfig(res.field_config)
      }

      const product = res.results?.find((p) => String(p.product_id) === String(searchPayload.query))
      if (!product) {
        setVariants([])
        return
      }

      const newVariants = product.variants.map((v) => ({
        ...v,
        name: resolveVariantDisplayName({
          variant_value: v.variant_value,
          variant_type: v.variant_type,
          productTitle: product.title,
        }),
        stock: v.current_stock ?? 0,
        measurement_value: v.measurement_value ?? '',
      }))

      const edits = {}

      newVariants.forEach((v) => {
        edits[v.variant_id] = {
          sku: v.sku ?? '',
          batch_number: '', // ALWAYS EMPTY ON LOAD
          barcode: v.barcode ?? '',
          continue_selling: v.continue_selling ?? true,
          reorder_level: v.reorder_level ?? '',
          quantity: '',
          note: '',
        }
      })

      setVariants(newVariants)
      setVariantEdits(edits)
    } catch (err) {
      console.error('Failed to fetch variants:', err)
      setVariants([])
    }
  }

  // Reset edits when stock type changes — restore from original fetched variants
  useEffect(() => {
    if (didSearch && selectedProduct) {
      handleSearch()
    }
  }, [stockType])

  /* ======================================================
   RESET FORM (with unsaved changes protection)
====================================================== */
  const handleResetOnlyForm = async () => {
    if (dirtyVariants.size > 0) {
      const res = await Swal.fire({
        icon: 'warning',
        title: 'Discard changes?',
        text: 'This will clear all unsaved changes for variants.',
        showCancelButton: true,
        confirmButtonText: 'Yes, reset form',
        confirmButtonColor: '#dc3545',
      })

      if (!res.isConfirmed) return
    }

    // 🔁 Restore variantEdits from original variants
    const resetEdits = {}

    variants.forEach((v) => {
      resetEdits[v.variant_id] = {
        sku: v.sku ?? '',
        batch_number: v.batch_number ?? '',
        barcode: v.barcode ?? '',
        continue_selling: v.continue_selling ?? true,
        reorder_level: v.reorder_level ?? '',
        quantity: '',
        note: '',
      }
    })

    setVariantEdits(resetEdits)
    setDirtyVariants(new Set())
  }

  const handleResetFilters = async () => {
    if (dirtyVariants.size > 0) {
      const res = await Swal.fire({
        icon: 'warning',
        title: 'Discard all changes?',
        text: 'This will reset product, outlet, and all unsaved changes.',
        showCancelButton: true,
        confirmButtonText: 'Yes, reset filters',
        confirmButtonColor: '#dc3545',
      })

      if (!res.isConfirmed) return
    }

    setSelectedProduct(null)
    setHeaderProduct(null)
    setSelectedOutlet(null)
    setStockType('')
    setDidSearch(false)

    setVariants([])
    setVariantEdits({})
    setDirtyVariants(new Set())
  }

  return (
    <>
      <Card>
        {/* <CardHeader className="py-2 bg-primary text-white">
          <Row className="align-items-center justify-content-between">
            <Col>
              <CardTitle as="h4" className="mb-0">
                Stock In/Out
              </CardTitle>
            </Col>
          </Row>
        </CardHeader> */}
        <CardHeader className="py-3 bg-light">
          <div className="d-flex align-items-center justify-content-between w-100">
            <CardTitle as="h4" className="mb-0">
              Stock In/Out
            </CardTitle>

            <Button
              type="button"
              variant="success"
              size="sm"
              className="d-flex align-items-center justify-content-center gap-2 px-3"
              onClick={() => setShowCSVUploadModal(true)}
              style={{
                minHeight: '36px',
                borderRadius: '8px',
                whiteSpace: 'nowrap',
              }}>
              <Icon icon="mdi:file-upload-outline" width={18} />
              Upload CSV
            </Button>
          </div>
        </CardHeader>
        <CardBody>
          <div className="po-filter-bar mb-3">
            <div className="row g-2 align-items-end">
              {/* Product Search */}
              <div className="col-12 col-lg-5">
                <div className="po-filter-label">Search Product (ID, Name, Variant, SKU, Barcode)</div>

                <AsyncSelect
                  cacheOptions
                  defaultOptions
                  loadOptions={loadOptions}
                  onChange={handleProductChange}
                  value={selectedProduct}
                  isClearable
                  isDisabled={didSearch}
                  placeholder="Search by ID, Name, SKU, Barcode"
                  filterOption={null}
                  getOptionLabel={(e) => e.label}
                  getOptionValue={(e) => e.value}
                  formatOptionLabel={(option, { inputValue }) => (
                    <div className="d-flex align-items-center gap-1" style={{ fontSize: '0.75rem' }}>
                      <span
                        style={{
                          color: '#6c757d',
                          fontWeight: 400,
                          minWidth: '60px',
                        }}>
                        #{option.variant_id || option.value}
                      </span>

                      <div
                        dangerouslySetInnerHTML={{
                          __html: highlightMatch(option.label, inputValue),
                        }}
                      />
                    </div>
                  )}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      minHeight: '36px',
                      height: '36px',
                      fontSize: '13px',
                      borderRadius: '8px',
                      borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                      boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                      background: '#fff',
                      transition: 'all 0.15s ease',
                    }),
                    valueContainer: (base) => ({
                      ...base,
                      paddingLeft: '12px',
                    }),
                    indicatorsContainer: (base) => ({
                      ...base,
                      paddingRight: '10px',
                    }),
                    placeholder: (base) => ({
                      ...base,
                      color: '#6c757d',
                    }),
                    menu: (base) => ({
                      ...base,
                      zIndex: 9999,
                    }),
                  }}
                />
              </div>

              {/* Stock Type */}
              <div className="col-6 col-lg-2">
                <div className="po-filter-label">Stock Type</div>

                <Select
                  options={[
                    { label: 'Stock In', value: 'in' },
                    { label: 'Stock Out', value: 'out' },
                    { label: 'Stock Wastage', value: 'wastage' },
                  ]}
                  placeholder="Select Stock Type"
                  value={
                    stockType
                      ? {
                          label: stockType === 'in' ? 'Stock In' : stockType === 'out' ? 'Stock Out' : stockType === 'wastage' ? 'Stock Wastage' : '',
                          value: stockType,
                        }
                      : null
                  }
                  onChange={(s) => setStockType(s?.value || '')}
                  isClearable
                  isDisabled={didSearch}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      minHeight: '36px',
                      height: '36px',
                      fontSize: '13px',
                      borderRadius: '8px',
                      borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                      boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                      opacity: state.isDisabled ? 0.6 : 1,
                    }),
                    valueContainer: (base) => ({
                      ...base,
                      padding: '0 6px',
                    }),
                    menu: (base) => ({
                      ...base,
                      zIndex: 9999,
                    }),
                  }}
                />
              </div>

              {/* Outlet */}
              <div className="col-6 col-lg-3">
                <div className="po-filter-label">Outlet</div>

                <Select
                  options={outletOptions}
                  value={selectedOutlet}
                  onChange={setSelectedOutlet}
                  isClearable
                  isDisabled={didSearch}
                  isLoading={outletsLoading}
                  placeholder="Select Outlet"
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      minHeight: '36px',
                      height: '36px',
                      fontSize: '13px',
                      borderRadius: '8px',
                      borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                      boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                    }),
                    valueContainer: (base) => ({
                      ...base,
                      padding: '0 6px',
                    }),
                    menu: (base) => ({
                      ...base,
                      zIndex: 9999,
                    }),
                  }}
                />
              </div>

              {/* Button */}
              {/* Action Buttons */}
              <div className="col-12 col-lg-2">
                <div className="d-flex align-items-end gap-2 h-100">
                  <button
                    type="button"
                    className={`btn btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-1 ${
                      didSearch ? 'btn-outline-secondary' : 'btn-dark'
                    }`}
                    onClick={didSearch ? handleResetFilters : handleSearch}
                    disabled={isFetching || (!didSearch && (!selectedProduct || !stockType || !selectedOutlet))}
                    style={{
                      minHeight: '36px',
                      whiteSpace: 'nowrap',
                    }}>
                    <Icon icon={didSearch ? 'mdi:refresh' : 'fa6-solid:magnifying-glass'} />

                    {isFetching ? 'Loading...' : didSearch ? 'Reset' : 'Search and Set'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Outlet Selection */}
          {/* <Row className="mb-3">
  <Col md={6}>
    <Form.Label>Outlet</Form.Label>
    <Select
      options={outletOptions}
      value={selectedOutlet}
      onChange={setSelectedOutlet}
      isClearable
      isLoading={outletsLoading}
      placeholder="Select Outlet"
      styles={{
        control: (base, state) => ({
          ...base,
          minHeight: '38px',
          borderRadius: '999px',
          borderColor: state.isFocused
            ? 'var(--bs-primary)'
            : '#DEE2E6',
          boxShadow: state.isFocused
            ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)'
            : 'none',
        }),
      }}
    />
  </Col>
</Row> */}

          <div className="mt-4 mb-2">
            {isFetching && (
              <div className="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
                <Spinner animation="border" role="status" className="mb-2" />
                <span>Loading product and variants...</span>
              </div>
            )}

            {didSearch && selectedProduct && (
              <>
                <div className="d-flex align-items-center justify-content-between">
                  {/* Left: Product info */}
                  <div className="d-flex align-items-center gap-2 flex-wrap">
                    <strong>Product:</strong>
                    <span>{selectedProduct.name}</span>

                    {Array.isArray(variants) && variants.some((v) => (v?.variant_value || '').toLowerCase() === 'default') && (
                      <span className="ms-2 text-warning fw-semibold">Default | No Variants Added</span>
                    )}
                  </div>
                </div>

                <hr className="my-1" />
              </>
            )}
          </div>

          {!isFetching && variants.length > 0 && (
            <>
              {(() => {
                const isWastage = stockType === 'wastage'

                return (
                  <Row className="mt-4">
                    <Col>
                      <Table responsive striped hover size="sm" className="align-middle" style={{ tableLayout: 'auto', width: '100%' }}>
                        <thead className="table-light text-center">
                          <tr>
                            <th style={{ width: 110 }}>Variant ID</th>

                            <th className="text-start" style={{ minWidth: 240 }}>
                              Name
                            </th>

                            <th style={{ width: 130 }}>Current Stock</th>

                            {!isWastage && fieldConfig.sku && <th style={{ width: 140 }}>SKU</th>}

                            <th style={{ width: 150 }}>Batch No</th>
                            {!isWastage && fieldConfig.barcode && <th style={{ width: 140 }}>Barcode</th>}

                            {!isWastage && <th style={{ width: 150 }}>Reorder Level</th>}

                            {!isWastage && <th style={{ width: 140 }}>Continue Selling</th>}

                            <th style={{ width: 150 }}>Quantity</th>

                            {isWastage && (
                              <th style={{ width: 220 }}>
                                Note <span className="text-danger">*</span>
                              </th>
                            )}
                          </tr>
                        </thead>

                        <tbody>
                          {variants.map((v) => {
                            const edit = variantEdits[v.variant_id] || {}
                            const isDefault = (v?.variant_value || '').toLowerCase() === 'default'

                            return (
                              <tr
                                key={`${v.variant_id}-${v.stock}`}
                                style={{
                                  opacity: batchLoadingMap[v.variant_id] ? 0.5 : 1,
                                  filter: batchLoadingMap[v.variant_id] ? 'blur(1px)' : 'none',
                                  transition: 'opacity 0.15s ease, filter 0.15s ease',
                                }}>
                                {/* Variant ID */}
                                <td className="text-center ">{v.variant_id}</td>
                                <td className="text-start" style={{ minWidth: 240, maxWidth: 420 }}>
                                  <div
                                    style={{
                                      width: '100%',
                                      maxWidth: '100%',
                                      whiteSpace: 'nowrap',
                                      overflowX: 'auto',
                                      overflowY: 'hidden',
                                      scrollbarWidth: 'thin',
                                      display: 'block',
                                    }}
                                    title={v.name}>
                                    {v.name}
                                  </div>
                                </td>
                                {/* Current Stock */}
                                <td className="text-center">
                                  <span className="badge bg-light text-dark border d-inline-flex align-items-center gap-1">
                                    {batchLoadingMap[v.variant_id] ? (
                                      <>
                                        <Spinner animation="border" size="sm" />
                                        <span>Loading</span>
                                      </>
                                    ) : (
                                      <>
                                        {v.stock ?? 0}
                                        {v.measurement_value ? ` (${v.measurement_value})` : ''}
                                      </>
                                    )}
                                  </span>
                                </td>

                                {!isWastage && fieldConfig.sku && (
                                  <td className="text-center">
                                    <Form.Control
                                      size="sm"
                                      className="text-center"
                                      placeholder={v.sku == null ? 'Not Set' : 'SKU'}
                                      value={edit.sku ?? ''}
                                      onChange={(e) => handleVariantChange(v.variant_id, 'sku', e.target.value)}
                                    />
                                  </td>
                                )}

                                <td className="text-start">
                                  {Array.isArray(v.batch_numbers) && v.batch_numbers.length > 0 ? (
                                    <Form.Select
                                      size="sm"
                                      value={edit.batch_number ?? ''}
                                      className={edit.batch_number === '__add_batch__' ? 'text-center' : ''}
                                      onChange={async (e) => {
                                        const value = e.target.value

                                        if (value === '__add_batch__') {
                                          handleVariantChange(v.variant_id, 'batch_number', '')

                                          if (!fieldConfig.batch_no) {
                                            await showBatchAddDeniedModal()
                                            return
                                          }

                                          openBatchModal(v)
                                          return
                                        }

                                        // update selected batch in edits
                                        handleVariantChange(v.variant_id, 'batch_number', value)

                                        // mark this row as loading
                                        setBatchLoadingMap((prev) => ({
                                          ...prev,
                                          [v.variant_id]: true,
                                        }))

                                        try {
                                          // fetch stock for selected batch + outlet + variant
                                          const res = await fetchVariantBatchStock({
                                            variant_id: v.variant_id,
                                            outlet_id: selectedOutlet.value,
                                            batch_number: value,
                                          }).unwrap()

                                          // apply stock to UI
                                          setVariants((prev) =>
                                            prev.map((item) =>
                                              item.variant_id === v.variant_id ? { ...item, stock: res.current_stock ?? 0 } : item,
                                            ),
                                          )
                                        } catch (err) {
                                          console.error('Failed to fetch batch stock:', err)

                                          setVariants((prev) => prev.map((item) => (item.variant_id === v.variant_id ? { ...item, stock: 0 } : item)))
                                        } finally {
                                          setBatchLoadingMap((prev) => ({
                                            ...prev,
                                            [v.variant_id]: false,
                                          }))
                                        }
                                      }}>
                                      <option value="">Select batch</option>

                                      {v.batch_numbers.map((bn) => (
                                        <option key={bn} value={bn}>
                                          {bn}
                                        </option>
                                      ))}

                                      <option
                                        value="__add_batch__"
                                        style={{
                                          textAlign: 'center',
                                          fontWeight: 500,
                                          backgroundColor: '#f8f9fa',
                                        }}>
                                        {fieldConfig.batch_no ? '＋ Add batch' : '＋ Add batch (Denied)'}
                                      </option>
                                    </Form.Select>
                                  ) : (
                                    <div
                                      onClick={() => openBatchModal(v)}
                                      style={{
                                        textAlign: 'center',
                                        padding: '6px 8px',
                                        fontSize: '0.85rem',
                                        fontWeight: 500,
                                        color: '#191b1f',
                                        cursor: 'pointer',
                                        borderRadius: '6px',
                                        transition: 'background-color 0.15s ease',
                                      }}
                                      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#f1f3f5')}
                                      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}>
                                      {fieldConfig.batch_no ? '＋ Add batch' : '＋ Add batch (Denied)'}
                                    </div>
                                  )}
                                </td>

                                {!isWastage && fieldConfig.barcode && (
                                  <td className="text-center" style={{ minWidth: 160 }}>
                                    {v.barcode ? (
                                      <span className="badge bg-light text-dark border px-2 py-1">{v.barcode}</span>
                                    ) : (
                                      <StockBarcodeChecker
                                        value={edit.barcode ?? ''}
                                        onChange={(val, isValid) =>
                                          handleVariantChange(v.variant_id, 'barcode', val, {
                                            barcode_valid: isValid,
                                          })
                                        }
                                      />
                                    )}
                                  </td>
                                )}

                                {/* Reorder Level */}
                                {!isWastage && (
                                  <td className="text-center">
                                    <Form.Control
                                      size="sm"
                                      type="number"
                                      inputMode="numeric"
                                      className="text-center"
                                      placeholder={v.reorder_level == null ? 'Not Set' : 'Reorder Level'}
                                      value={edit.reorder_level ?? ''}
                                      onChange={(e) =>
                                        handleVariantChange(
                                          v.variant_id,
                                          'reorder_level',
                                          Number.isNaN(parseInt(e.target.value, 10)) ? '' : parseInt(e.target.value, 10),
                                        )
                                      }
                                    />
                                  </td>
                                )}

                                {/* Continue Selling (original checkbox) */}
                                {!isWastage && (
                                  <td className="text-center">
                                    <Form.Check id={`continue_${v.variant_id}`} type="checkbox">
                                      <Form.Check.Input
                                        type="checkbox"
                                        checked={edit.continue_selling ?? true}
                                        onChange={(e) => handleVariantChange(v.variant_id, 'continue_selling', e.target.checked)}
                                        style={{ borderColor: '#3f3f3fce', borderWidth: '1px' }}
                                      />
                                    </Form.Check>
                                  </td>
                                )}

                                {/* Quantity */}
                                <td className="text-center">
                                  <InputGroup size="sm" className="justify-content-center" style={{ display: 'flex', flexWrap: 'nowrap' }}>
                                    <Form.Control
                                      size="sm"
                                      type="number"
                                      inputMode="numeric"
                                      className="text-center"
                                      placeholder="Qty"
                                      style={{ flex: 1 }} // <-- always full width
                                      value={edit.quantity ?? ''}
                                      onChange={(e) => {
                                        let value = parseInt(e.target.value, 10) || ''
                                        if ((stockType === 'out' || stockType === 'wastage') && typeof value === 'number' && value > 0) {
                                          value = -Math.abs(value)
                                        } else if (stockType === 'in' && typeof value === 'number' && value < 0) {
                                          value = Math.abs(value)
                                        }
                                        handleVariantChange(v.variant_id, 'quantity', value)
                                      }}
                                    />

                                    {/* Show badge only if measurement unit exists */}
                                    {v.measurement_value && (
                                      <InputGroup.Text
                                        style={{
                                          flex: '0 0 auto',
                                          minWidth: 32,
                                          padding: '0 4px',
                                          fontSize: '0.75rem',
                                          lineHeight: '1rem',
                                          backgroundColor: '#f8f9fa',
                                          borderLeft: '1px solid rgba(0,0,0,0.075)',
                                        }}>
                                        {v.measurement_value}
                                      </InputGroup.Text>
                                    )}
                                  </InputGroup>
                                </td>
                                {isWastage && (
                                  <td className="text-center">
                                    <Form.Control
                                      size="sm"
                                      as="textarea"
                                      rows={1}
                                      placeholder="Note"
                                      value={edit.note ?? ''}
                                      onChange={(e) => handleVariantChange(v.variant_id, 'note', e.target.value)}
                                      style={{
                                        minWidth: 200,
                                        resize: 'vertical',
                                        fontSize: '0.78rem',
                                      }}
                                    />
                                  </td>
                                )}
                              </tr>
                            )
                          })}
                        </tbody>
                      </Table>

                      {refreshing && (
                        <div className="d-flex justify-content-center align-items-center my-3">
                          <Spinner animation="border" role="status" size="sm" className="me-2" />
                          <span>Refreshing updated data...</span>
                        </div>
                      )}

                      {hasEdits && (
                        <div className="d-flex justify-content-between align-items-center mt-2">
                          {/* LEFT: Reset Form */}
                          <Button variant="outline-danger" size="sm" onClick={handleResetOnlyForm} disabled={refreshing}>
                            <Icon icon="mdi:refresh" className="me-1" />
                            Reset Form
                          </Button>

                          {/* RIGHT: Update Stock */}
                          <Button variant="success" onClick={handleVariantSave} disabled={refreshing}>
                            {refreshing ? (
                              <>
                                <Spinner animation="border" size="sm" className="me-2" />
                                Updating...
                              </>
                            ) : stockType === 'wastage' ? (
                              'Save Stock Wastage'
                            ) : (
                              'Update Variant Stock'
                            )}
                          </Button>
                        </div>
                      )}
                    </Col>
                  </Row>
                )
              })()}
            </>
          )}

          {didSearch && selectedProduct && variants.length === 0 && !isFetching && (
            <div className="text-center text-muted py-5">No available/active product or variants found.</div>
          )}
        </CardBody>
      </Card>

      {/* Toasts */}
      <ToastContainer position="top-end" className="p-3">
        <Toast show={toast.show} bg={toast.variant} onClose={() => setToast({ ...toast, show: false })} delay={3000} autohide>
          <Toast.Body className="text-white">{toast.message}</Toast.Body>
        </Toast>
      </ToastContainer>

      {/* Table of recent updates (placeholder display only) */}
      {/* Show Recent Stock Updates only after at least one save */}
      {recentUpdates.length > 0 && (
        <>
          <hr className="my-4" />
          <Card className="mt-4">
            <CardHeader className="py-3 bg-light">
              <div className="d-flex align-items-center justify-content-between">
                <CardTitle as="h4" className="mb-0">
                  Stock In/Out
                </CardTitle>
              </div>
            </CardHeader>

            <CardBody>
              {/* Product title + ID above the table */}
              {headerProduct && (
                <>
                  <div className="d-flex flex-wrap align-items-center gap-2 mb-2">
                    <span className="fw-semibold" style={{ color: '#DC7104' }}>
                      {headerProduct.name}
                    </span>
                    {headerProduct.value && (
                      <span
                        className="badge"
                        style={{
                          border: '1px solid #DC7104',
                          color: '#DC7104',
                          backgroundColor: 'rgba(220,113,4,0.12)',
                        }}>
                        Prod.ID: {headerProduct.value}
                      </span>
                    )}
                  </div>
                  <hr className="mt-0 mb-2" />
                </>
              )}

              <Table responsive striped hover size="sm" className="align-middle">
                <thead className="table-light text-center">
                  <tr>
                    <th style={{ width: 110 }}>Variant ID</th>
                    <th style={{ width: 180 }}>Date</th>
                    <th style={{ width: 160 }}>Continue Selling</th>
                    <th className="text-start">Variant</th>

                    {fieldConfig.sku && <th style={{ width: 140 }}>SKU</th>}
                    {fieldConfig.batch_no && <th style={{ width: 140 }}>Batch No</th>}
                    {fieldConfig.barcode && <th style={{ width: 140 }}>Barcode</th>}

                    <th style={{ width: 150 }}>Reorder Level</th>
                    <th style={{ width: 140 }}>Type</th>
                    <th style={{ width: 120 }}>Quantity</th>
                  </tr>
                </thead>
                <tbody>
                  {recentUpdates.length > 0 ? (
                    recentUpdates.map((group) =>
                      group.variants.map((v) => {
                        const key = `${group.timestamp}-${v.variant_id}`
                        const isDefault = (v?.name || '').toLowerCase() === 'default'
                        const typeLower = (group.type || '').toLowerCase()

                        return (
                          <tr key={key}>
                            {/* Variant ID */}
                            <td className="text-center">{v.variant_id}</td>

                            {/* Date */}
                            <td className="text-center">{group.timestamp ? new Date(group.timestamp).toLocaleString() : '-'}</td>

                            {/* Continue Selling (icon) */}
                            <td className="text-center">
                              {v.continue_selling === false ? (
                                <Icon icon="mdi:close-circle" className="text-danger" width={18} height={18} title="Not allowed" />
                              ) : (
                                <Icon icon="mdi:check-circle" className="text-success" width={18} height={18} title="Allowed" />
                              )}
                            </td>

                            {/* Variant (left aligned) */}
                            <td className="text-start">
                              <div
                                style={{
                                  maxWidth: '220px', //  column width limit
                                  whiteSpace: 'nowrap', //  single line only
                                  overflowX: 'auto', // horizontal scroll if long
                                  overflowY: 'hidden',
                                  scrollbarWidth: 'thin', // Firefox thin scrollbar
                                }}
                                title={resolveVariantDisplayName({
                                  variant_value: v.name,
                                  variant_type: v.variant_type,
                                  productTitle: headerProduct?.name,
                                })}>
                                {resolveVariantDisplayName({
                                  variant_value: v.name,
                                  variant_type: v.variant_type,
                                  productTitle: headerProduct?.name,
                                })}
                              </div>
                            </td>

                            {fieldConfig.sku && <td className="text-center">{v.sku || '-'}</td>}

                            {fieldConfig.batch_no && <td className="text-center">{v.batch_number || '-'}</td>}

                            {fieldConfig.barcode && <td className="text-center">{v.barcode || '-'}</td>}

                            {/* Reorder Level */}
                            <td className="text-center">{v.reorder_level ?? '-'}</td>

                            {/* Type (Stock In / Stock Out) */}
                            <td className="text-center">{typeLower === 'in' ? 'Stock In' : typeLower === 'out' ? 'Stock Out' : '-'}</td>

                            {/* Quantity */}
                            <td className="text-center">{v.quantity}</td>
                          </tr>
                        )
                      }),
                    )
                  ) : (
                    <tr>
                      <td colSpan={9} className="text-center text-muted">
                        No recent updates
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </>
      )}

      {/* CSV Stock Upload Modal */}
      <Modal show={showCSVUploadModal} onHide={() => setShowCSVUploadModal(false)} size="xl" centered backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title className="d-flex align-items-center gap-2">
            <Icon icon="mdi:file-delimited-outline" width={22} />
            Upload Stock CSV
          </Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <CSVStockUpdate
            isModal={true}
            onClose={() => setShowCSVUploadModal(false)}
            onUploadSuccess={() => {
              setShowCSVUploadModal(false)
              setHistoryRefreshKey((prev) => prev + 1)

              if (didSearch) {
                handleSearch()
              }
            }}
          />
        </Modal.Body>
      </Modal>

      {/* Batch Modal */}
      <Modal show={showBatchModal} onHide={() => setShowBatchModal(false)} size="xl" centered backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Add Batch</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {batchModalVariant && (
            <BatchManagement
              isModal={true}
              initialVariant={batchModalVariant}
              lockVariantSearch={true}
              onClose={() => setShowBatchModal(false)}
              onBatchCreated={async ({ variant_id, batch_number }) => {
                setShowBatchModal(false)

                setVariants((prev) =>
                  prev.map((item) =>
                    item.variant_id === variant_id
                      ? {
                          ...item,
                          batch_numbers: Array.from(new Set([...(item.batch_numbers || []), batch_number])),
                        }
                      : item,
                  ),
                )

                handleVariantChange(variant_id, 'batch_number', batch_number)

                await refetchCurrentStock()
              }}
            />
          )}
        </Modal.Body>
      </Modal>

      <Modal show={showBatchModal} onHide={() => setShowBatchModal(false)} size="xl" centered backdrop="static" keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>Add Batch</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {batchModalVariant && (
            <BatchManagement
              isModal={true}
              initialVariant={batchModalVariant}
              lockVariantSearch={true}
              onClose={() => setShowBatchModal(false)}
              onBatchCreated={async ({ variant_id, batch_number }) => {
                setShowBatchModal(false)

                setVariants((prev) =>
                  prev.map((item) =>
                    item.variant_id === variant_id
                      ? {
                          ...item,
                          batch_numbers: Array.from(new Set([...(item.batch_numbers || []), batch_number])),
                        }
                      : item,
                  ),
                )

                handleVariantChange(variant_id, 'batch_number', batch_number)

                await refetchCurrentStock()
              }}
            />
          )}
        </Modal.Body>
      </Modal>

      {/* <StockInOutHistory /> */}

      <StockInOutHistory key={historyRefreshKey} />
    </>
  )
}

export default StockInOut
