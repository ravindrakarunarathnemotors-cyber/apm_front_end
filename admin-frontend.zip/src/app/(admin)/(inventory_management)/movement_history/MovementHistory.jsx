'use client'

import React, { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Row, Table } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetFilteredInventoryeListMutation, useSearchProductVariantsQuery } from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'
import Pagination from '@/components/Pagination'


function MovementHistory() {
  const [productName, setProductName] = useState('')
  const [sortOrder, setSortOrder] = useState('desc')
  const [variantId, setVariantId] = useState('')
  const [variantName, setVariantName] = useState('')
  const [productId, setProductId] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [limit, setLimit] = useState(10)
  const [totalEntries, setTotalEntries] = useState(0)
  const printRef = useRef()
  // NEW: single stock type value: 'stock-in' | 'stock-out' | null
  const [stockType, setStockType] = useState(null)

  const shouldSearch = searchProduct && searchProduct.trim().length >= 2

  const { data: productResults } = useSearchProductVariantsQuery(shouldSearch ? { query: searchProduct.trim() } : undefined)

  const debouncedSearchProduct = React.useMemo(
    () =>
      debounce((value) => {
        setSearchProduct(value)
      }, 300),
    [],
  )

  useEffect(() => {
    return () => debouncedSearchProduct.cancel()
  }, [debouncedSearchProduct])

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredInventoryeListMutation()

  const fetchLogs = React.useCallback(
    async (page = 1, customLimit = limit) => {
      setLoading(true)

      try {
        const res = await fetchFilteredProducts({
          page,
          limit: customLimit,
          ToDate: toDate,
          product_id: productId,
          inventory_name: productName,
          variant_id: variantId ? Number(variantId) : null,
          variant_name: variantName,
          inventory_name: productName,
          created_at: productDate,
          // merchant_id: '20001',
          ...(stockType ? { stockType } : {}),
        }).unwrap()

        setLogs(res.products || [])
        setTotalPages(res.totalPages || 1)
        setCurrentPage(page)
        setTotalEntries(res.total || 0)
      } catch (err) {
        console.error('Failed to fetch products:', err)
      } finally {
        setLoading(false)
      }
    },
    [toDate, productId, productName, variantId, variantName, productDate, stockType, fetchFilteredProducts, limit],
  )

  // eslint-disable-next-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handleLimitChange = (e) => {
    const newLimit = Number(e.target.value)

    setLimit(newLimit)
    setCurrentPage(1)

    fetchLogs(1, newLimit)
  }

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber, limit)
  }

  const sortedLogs = [...logs].sort((a, b) => {
    return sortOrder === 'asc' ? a.inventory_id - b.inventory_id : b.inventory_id - a.inventory_id
  })
  const normalizedProducts = sortedLogs.map((p) => ({
    inventory_id: p.inventory_id,
    variant_id: p.variant_id,
    action: p.system_module,
    created_at: p.last_updated,
    previous_quantity: p.previous_quantity,
    adjust_quantity: p.adjust_quantity,
    new_quantity: p.new_quantity,
    measurement_value: p.measurement_value,
    comment: p.comment,
  }))

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Inventory Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h2>Inventory Movement Report</h2>
        ${printContents}
      </body>
    </html>
  `)
    newWindow.document.close()
    newWindow.print()
  }

  // NEW: stock type options (single-select)
  const stockTypeOptions = [
    { value: 'stock-in', label: 'Stock In' },
    { value: 'stock-out', label: 'Stock Out' },
  ]

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Movement History
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <div className="po-filter-bar mb-3">
              <div className="row g-2 align-items-end">

                {/* Product / Variant Search */}
                <div className="col-12 col-lg-4">
                  <div className="po-filter-label">Product / Variant Search</div>

                  <Select
                    filterOption={() => true}
                    options={
                      productResults?.results?.flatMap((product) => {
                        const baseOption = {
                          value: product.product_id,
                          label: `🛒 ${product.title} (${product.product_id})`,
                          type: 'product',
                        }

                        const variantOptions = (product.variants || []).map((variant) => {
                          const displayLabel = `🔹 ${product.title} - ${variant.variant_value} (${variant.variant_id})`
                          const skuLabel = variant.sku ? ` | SKU: ${variant.sku}` : ''
                          const barcodeLabel = variant.barcode ? ` | Barcode: ${variant.barcode}` : ''

                          return {
                            value: variant.variant_id,
                            label: `${displayLabel}${skuLabel}${barcodeLabel}`,
                            product_id: product.product_id,
                            variant_value: variant.variant_value,
                            type: 'variant',
                            sku: variant.sku,
                            barcode: variant.barcode,
                          }
                        })

                        return [baseOption, ...variantOptions]
                      }) || []
                    }
                    onInputChange={(value) => debouncedSearchProduct(value)}
                    onChange={(option) => {
                      setSelectedProduct(option)

                      if (!option) {
                        setProductId('')
                        setProductName('')
                        setVariantId('')
                        setVariantName('')
                        return
                      }

                      if (option.type === 'product') {
                        setProductId(option.value)
                        setProductName(option.label.split('(')[0].replace('🛒', '').trim())
                        setVariantId('')
                        setVariantName('')
                      } else if (option.type === 'variant') {
                        setProductId(option.product_id)
                        setProductName(option.label.split('-')[0].replace('🔹', '').trim())
                        setVariantId(option.value)
                        setVariantName(option.variant_value)
                      }
                    }}
                    placeholder="Product or Variant..."
                    isClearable
                    isSearchable
                    value={selectedProduct}
                    styles={{
                      control: (base, state) => ({
                        ...base,
                        minHeight: '36px',
                        height: '36px',
                        fontSize: '13px',
                        borderRadius: '8px',
                        borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                        boxShadow: state.isFocused
                          ? '0 0 0 3px rgba(13,110,253,.1)'
                          : 'none',
                        background: '#fff',
                      }),
                      valueContainer: (b) => ({
                        ...b,
                        padding: '0 10px',
                      }),
                      indicatorsContainer: (b) => ({
                        ...b,
                        height: '36px',
                      }),
                      menu: (b) => ({
                        ...b,
                        zIndex: 9999,
                      }),
                      menuPortal: (b) => ({
                        ...b,
                        zIndex: 9999,
                      }),
                    }}
                    menuPortal={typeof document !== 'undefined' ? document.body : null}
                    menuPosition="fixed"
                  />
                </div>

                {/* To Date */}
                <div className="col-6 col-lg-2">
                  <div className="po-filter-label">To Date</div>

                  <Form.Control
                    type="date"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    className="form-control form-control-sm"
                    style={{
                      height: '36px',
                      fontSize: '13px',
                      borderRadius: '8px',
                    }}
                  />
                </div>

                {/* From Date */}
                <div className="col-6 col-lg-2">
                  <div className="po-filter-label">From Date</div>

                  <Form.Control
                    type="date"
                    value={productDate}
                    onChange={(e) => setProductDate(e.target.value)}
                    className="form-control form-control-sm"
                    style={{
                      height: '36px',
                      fontSize: '13px',
                      borderRadius: '8px',
                    }}
                  />
                </div>

                {/* Stock Type */}
                <div className="col-6 col-lg-2">
                  <div className="po-filter-label">Stock Type</div>

                  <Select
                    options={stockTypeOptions}
                    isClearable
                    placeholder="All"
                    value={stockTypeOptions.find((o) => o.value === stockType) || null}
                    onChange={(opt) => setStockType(opt?.value ?? null)}
                    styles={{
                      control: (base, state) => ({
                        ...base,
                        minHeight: '36px',
                        height: '36px',
                        fontSize: '13px',
                        borderRadius: '8px',
                        borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                        boxShadow: state.isFocused
                          ? '0 0 0 3px rgba(13,110,253,.1)'
                          : 'none',
                        background: '#fff',
                      }),
                      valueContainer: (b) => ({
                        ...b,
                        padding: '0 6px',
                      }),
                      menu: (b) => ({
                        ...b,
                        zIndex: 9999,
                      }),
                    }}
                  />
                </div>

                {/* Buttons */}
                <div className="col-12 col-lg-2">
                  <div className="d-flex gap-2">

                    <button
                      type="button"
                      className="btn btn-dark btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-2"
                      onClick={() => fetchLogs(1)}
                    >
                      Search
                    </button>

                    <button
                      type="button"
                      className="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center px-2"
                      style={{ minWidth: 36 }}
                      onClick={handlePrint}
                      title="Print"
                    >
                      Print
                    </button>

                  </div>
                </div>

              </div>
            </div>

            {isLoading || loading ? (
              <p>Loading Inventory...</p>
            ) : (
              <>
                <div ref={printRef}>
                  <div className="table-responsive">
                    <Table striped className="table mb-0">
                      <thead className="table-light">
                        <tr>
                          <th>Inventory ID</th>
                          <th>Variant ID</th> {/* NEW COLUMN */}
                          <th>Created At</th>
                          <th>Type</th>
                          <th>Comment</th>
                          <th className="text-end pe-2">Previous Quantity</th>
                          <th className="text-end pe-2">Adjusted Quantity</th>
                          <th className="text-end pe-2">New Quantity</th>
                        </tr>
                      </thead>
                      <tbody>
                        {normalizedProducts.length === 0 ? (
                          <tr>
                            <td colSpan="8" className="text-center">
                              No Inventory found.
                            </td>
                          </tr>
                        ) : (
                          normalizedProducts.map((product) => (
                            <tr key={product.inventory_id}>
                              <td>{product.inventory_id}</td>
                              <td>{product.variant_id ?? '-'}</td> {/*  NEW CELL */}
                              <td>{new Date(product.created_at).toLocaleDateString()}</td>
                              {/* <td>{product.action}</td> */}
                              <td>
                                {product.action === 'stock in' ? (
                                  <span className="d-inline-flex align-items-center gap-1" style={{ color: '#0d6efd' }}>
                                    <Icon icon="tabler:package-import" width={18} height={18} inline />
                                    <span>Stock In</span>
                                  </span>
                                ) : product.action === 'stock out' ? (
                                  <span className="d-inline-flex align-items-center gap-1" style={{ color: '#dc3545' }}>
                                    <Icon icon="tabler:package-export" width={18} height={18} inline />
                                    <span>Stock Out</span>
                                  </span>
                                ) : (
                                  product.action
                                )}
                              </td>
                              <td>{product.comment?.replace(/^{|}$/g, '')}</td>
                              <td className="text-end pe-2">{product.previous_quantity}</td>
                              <td className="text-end pe-2">{product.adjust_quantity}</td>
                              <td className="text-end pe-2">
                                {product.new_quantity}
                                {product.measurement_value ? ` (${product.measurement_value})` : ''}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </Table>
                  </div>
                </div>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalEntries={totalEntries}
                  limit={limit}
                  onPageChange={handlePageChange}
                  onLimitChange={(val) => {
                    setLimit(val)
                    setCurrentPage(1)

                    handleLimitChange({
                      target: { value: val }
                    })
                  }}
                  showingFrom={
                    logs.length === 0
                      ? 0
                      : (currentPage - 1) * limit + 1
                  }
                  showingTo={
                    (currentPage - 1) * limit + logs.length
                  }
                />
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default MovementHistory
