'use client'

import React, { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetFilteredInventoryeListMutation, useSearchProductVariantsQuery } from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'

function MovementHistory() {
  const [productName, setProductName] = useState('')
  const [sortOrder, setSortOrder] = useState('desc')
  const [variantId, setVariantId] = useState('')
  const [variantName, setVariantName] = useState('')
  const [productId, setProductId] = useState('')
  const [searchProduct, setSearchProduct] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [productDate, setProductDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const logsPerPage = 10
  const printRef = useRef()
  // NEW: single stock type value: 'stock-in' | 'stock-out' | null
  const [stockType, setStockType] = useState(null)

  const shouldSearch = searchProduct && searchProduct.trim().length >= 2

  const { data: productResults } = useSearchProductVariantsQuery(shouldSearch ? { query: searchProduct.trim() } : undefined)

  const debouncedSearchProduct = React.useMemo(
    () =>
      debounce((value) => {
        setSearchProduct(value)
      }, 300),
    [],
  )

  useEffect(() => {
    return () => debouncedSearchProduct.cancel()
  }, [debouncedSearchProduct])

  const [fetchFilteredProducts, { isLoading }] = useGetFilteredInventoryeListMutation()

  const fetchLogs = React.useCallback(
    async (page) => {
      setLoading(true)
      try {
        const res = await fetchFilteredProducts({
          page,
          limit: logsPerPage,
          ToDate: toDate,
          product_id: productId,
          inventory_name: productName,
          variant_id: variantId ? Number(variantId) : null,
          variant_name: variantName,
          inventory_name: productName,
          created_at: productDate,
          // merchant_id: '20001',
          ...(stockType ? { stockType } : {}),
        }).unwrap()

        setLogs(res.products || [])
        setTotalPages(res.totalPages || 1)
        setCurrentPage(page)
      } catch (err) {
        console.error('Failed to fetch products:', err)
      } finally {
        setLoading(false)
      }
    },
    [toDate, productId, productName, variantId, variantName, productDate, stockType, fetchFilteredProducts],
  )

  // eslint-disable-next-line react-hooks/exhaustive-deps

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const getPageWindow = (current, total, width = 5) => {
    const w = Math.max(1, width)
    const half = Math.floor(w / 2)

    let start = Math.max(1, current - half)
    let end = Math.min(total, start + w - 1)
    start = Math.max(1, end - w + 1)

    return Array.from({ length: end - start + 1 }, (_, i) => start + i)
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }
  const sortedLogs = [...logs].sort((a, b) => {
    return sortOrder === 'asc' ? a.inventory_id - b.inventory_id : b.inventory_id - a.inventory_id
  })
  const normalizedProducts = sortedLogs.map((p) => ({
    inventory_id: p.inventory_id,
    variant_id: p.variant_id,
    action: p.system_module,
    created_at: p.last_updated,
    previous_quantity: p.previous_quantity,
    adjust_quantity: p.adjust_quantity,
    new_quantity: p.new_quantity,
    measurement_value: p.measurement_value,
    comment: p.comment,
  }))

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Inventory Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h2>Inventory Movement Report</h2>
        ${printContents}
      </body>
    </html>
  `)
    newWindow.document.close()
    newWindow.print()
  }

  // NEW: stock type options (single-select)
  const stockTypeOptions = [
    { value: 'stock-in', label: 'Stock In' },
    { value: 'stock-out', label: 'Stock Out' },
  ]

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0">
                  Movement History
                </CardTitle>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            <Form className="row g-2 mb-3">
              <FormGroup className="col-md-4">
                <FormLabel>Product / Variant Search</FormLabel>
                <Select
                  filterOption={() => true}
                  options={
                    productResults?.results?.flatMap((product) => {
                      const baseOption = {
                        value: product.product_id,
                        label: `🛒 ${product.title} (${product.product_id})`,
                        type: 'product',
                      }

                      const variantOptions = (product.variants || []).map((variant) => {
                        const displayLabel = `🔹 ${product.title} - ${variant.variant_value} (${variant.variant_id})`
                        const skuLabel = variant.sku ? ` | SKU: ${variant.sku}` : ''
                        const barcodeLabel = variant.barcode ? ` | Barcode: ${variant.barcode}` : ''

                        return {
                          value: variant.variant_id,
                          label: `${displayLabel}${skuLabel}${barcodeLabel}`,
                          product_id: product.product_id,
                          variant_value: variant.variant_value,
                          type: 'variant',
                          sku: variant.sku,
                          barcode: variant.barcode,
                        }
                      })

                      return [baseOption, ...variantOptions]
                    }) || []
                  }
                  onInputChange={(value) => debouncedSearchProduct(value)}
                  onChange={(option) => {
                    setSelectedProduct(option)

                    if (!option) {
                      setProductId('')
                      setProductName('')
                      setVariantId('')
                      setVariantName('')
                      return
                    }

                    if (option.type === 'product') {
                      setProductId(option.value)
                      setProductName(option.label.split('(')[0].replace('🛒', '').trim())
                      setVariantId('')
                      setVariantName('')
                    } else if (option.type === 'variant') {
                      setProductId(option.product_id)
                      setProductName(option.label.split('-')[0].replace('🔹', '').trim())
                      setVariantId(option.value)
                      setVariantName(option.variant_value)
                    }
                  }}
                  placeholder="Product or Variant..."
                  isClearable
                  isSearchable
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                  value={selectedProduct}
                />
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>To Date</FormLabel>
                <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
              </FormGroup>
              <FormGroup className="col-md-2">
                <FormLabel>From Date</FormLabel>
                <Form.Control type="date" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
              </FormGroup>

              <FormGroup className="col-md-2">
                <FormLabel>Stock Type</FormLabel>
                <Select
                  options={stockTypeOptions}
                  isClearable
                  placeholder="All"
                  value={stockTypeOptions.find((o) => o.value === stockType) || null}
                  onChange={(opt) => setStockType(opt?.value ?? null)}
                  styles={{
                    control: (base, state) => ({
                      ...base,
                      borderRadius: '999px',
                      borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6', // same as Bootstrap input
                      boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                    }),
                  }}
                />
              </FormGroup>

              <FormGroup className="col-md-1 d-flex align-items-end gap-2">
                {/* <Button
                  variant="outline-secondary"
                  onClick={() => setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'))}
                  title={`Sort ${sortOrder === 'asc' ? 'Descending' : 'Ascending'}`}>
                  {sortOrder === 'asc' ? '⬆️' : '⬇️'}
                </Button> */}

                <Button variant="primary" className="btn bg-primary border-1 border-primary flex-grow-1 " onClick={() => fetchLogs(1)}>
                  Search
                </Button>

                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  style={{
                    backgroundColor: '#6f42c1',
                    borderColor: '#6f42c1',
                  }}>
                  Print
                </Button>
              </FormGroup>
            </Form>

            {isLoading || loading ? (
              <p>Loading Inventory...</p>
            ) : (
              <>
                <div ref={printRef}>
                  <Table striped className="table mb-0">
                    <thead className="table-light">
                      <tr>
                        <th>Inventory ID</th>
                        <th>Variant ID</th> {/* NEW COLUMN */}
                        <th>Created At</th>
                        <th>Type</th>
                        <th>Comment</th>
                        <th className="text-end pe-2">Previous Quantity</th>
                        <th className="text-end pe-2">Adjusted Quantity</th>
                        <th className="text-end pe-2">New Quantity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {normalizedProducts.length === 0 ? (
                        <tr>
                          <td colSpan="8" className="text-center">
                            No Inventory found.
                          </td>
                        </tr>
                      ) : (
                        normalizedProducts.map((product) => (
                          <tr key={product.inventory_id}>
                            <td>{product.inventory_id}</td>
                            <td>{product.variant_id ?? '-'}</td> {/*  NEW CELL */}
                            <td>{new Date(product.created_at).toLocaleDateString()}</td>
                            {/* <td>{product.action}</td> */}
                            <td>
                              {product.action === 'stock in' ? (
                                <span className="d-inline-flex align-items-center gap-1" style={{ color: '#0d6efd' }}>
                                  <Icon icon="tabler:package-import" width={18} height={18} inline />
                                  <span>Stock In</span>
                                </span>
                              ) : product.action === 'stock out' ? (
                                <span className="d-inline-flex align-items-center gap-1" style={{ color: '#dc3545' }}>
                                  <Icon icon="tabler:package-export" width={18} height={18} inline />
                                  <span>Stock Out</span>
                                </span>
                              ) : (
                                product.action
                              )}
                            </td>
                            <td>{product.comment?.replace(/^{|}$/g, '')}</td>
                            <td className="text-end pe-2">{product.previous_quantity}</td>
                            <td className="text-end pe-2">{product.adjust_quantity}</td>
                            <td className="text-end pe-2">
                              {product.new_quantity}
                              {product.measurement_value ? ` (${product.measurement_value})` : ''}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
                    {getPaginationRange().map((pageNum) => (
                      <Pagination.Item key={pageNum} active={pageNum === currentPage} onClick={() => handlePageChange(pageNum)}>
                        {pageNum}
                      </Pagination.Item>
                    ))}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                  </Pagination>
                </div> */}
                {/* ================= PAGINATION ================= */}
                {totalPages > 1 && (
                  <div className="d-flex justify-content-end mt-3">
                    <Pagination>
                      {(() => {
                        const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                        const pages = []

                        let start = safeCurrent - 2
                        let end = safeCurrent + 2

                        if (totalPages <= 5) {
                          start = 1
                          end = totalPages
                        } else {
                          if (start < 1) {
                            start = 1
                            end = 5
                          }
                          if (end > totalPages) {
                            end = totalPages
                            start = totalPages - 4
                          }
                        }

                        for (let i = start; i <= end; i++) {
                          pages.push(
                            <Pagination.Item key={i} active={i === safeCurrent} onClick={() => handlePageChange(i)}>
                              {i}
                            </Pagination.Item>,
                          )
                        }

                        return (
                          <>
                            {/* FIRST */}
                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(1)}>
                              First
                            </Pagination.Item>

                            {/* PREV (<) */}
                            <Pagination.Item disabled={safeCurrent === 1} onClick={() => handlePageChange(safeCurrent - 1)}>
                              {'<'}
                            </Pagination.Item>

                            {pages}

                            {/* NEXT (>) */}
                            <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(safeCurrent + 1)}>
                              {'>'}
                            </Pagination.Item>

                            {/* LAST */}
                            <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => handlePageChange(totalPages)}>
                              Last
                            </Pagination.Item>
                          </>
                        )
                      })()}
                    </Pagination>
                  </div>
                )}
              </>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}

export default MovementHistory
