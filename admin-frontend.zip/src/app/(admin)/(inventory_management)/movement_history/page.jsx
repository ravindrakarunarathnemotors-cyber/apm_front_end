import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Movement History',
}

const MovementHistory = dynamic(() => import('./MovementHistory'), { ssr: false })

export default function MovementHistoryPage() {
  return <MovementHistory />
}