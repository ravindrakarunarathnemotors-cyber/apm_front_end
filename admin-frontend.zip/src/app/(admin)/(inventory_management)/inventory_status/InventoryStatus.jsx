'use client'
import React, { useState, useEffect, useRef } from 'react'
import {
  Table,
  Form,
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Button,
  Badge,
  Spinner,
  ListGroup,
  Pagination,
  Modal,
  ProgressBar,
} from 'react-bootstrap'
import { useGetOutletsQuery, useGetProductSearchGlobalQuery, useGetProductsByOutletQuery } from '@/store/features/apiSlice'

function InventoryStatus() {
  const [selectedOutletId, setSelectedOutletId] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [searchedOutletId, setSearchedOutletId] = useState(null)
  const [showBatchModal, setShowBatchModal] = useState(false)
  const [selectedBatchVariant, setSelectedBatchVariant] = useState(null)
  // --- NEW: search input + debounce + suggestion pick ---
  const [searchInput, setSearchInput] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [selectedProductId, setSelectedProductId] = useState(null)
  const inputRef = useRef(null)
  // NEW: control whether suggestions are visible
  const [showSuggestions, setShowSuggestions] = useState(false)
  // ref for the search input / suggestion container area (used to detect outside clicks)
  const searchContainerRef = useRef(null)

  // --- NEW: CSV export progress state ---
  const [csvDownloading, setCsvDownloading] = useState(false)
  const [csvProgress, setCsvProgress] = useState(0)

  useEffect(() => {
    const t = setTimeout(() => {
      const trimmed = searchInput.trim()
      setDebouncedSearch(trimmed)

      // show suggestions when we have >=2 chars and user hasn't chosen a product
      if (trimmed.length >= 2 && !selectedProductId) {
        setShowSuggestions(true)
      } else {
        setShowSuggestions(false)
      }
    }, 400)
    return () => clearTimeout(t)
  }, [searchInput, selectedProductId])

  useEffect(() => {
    function handleDocClick(e) {
      // nothing to do if suggestions already hidden
      if (!showSuggestions) return

      // if click is inside the search container, keep open
      if (searchContainerRef.current && searchContainerRef.current.contains(e.target)) {
        return
      }

      // otherwise hide suggestions
      setShowSuggestions(false)
    }

    document.addEventListener('mousedown', handleDocClick)
    return () => document.removeEventListener('mousedown', handleDocClick)
  }, [showSuggestions])

  // suggestions (min 2 chars)
  const { data: productSuggestions = [], isFetching: isSearchingSuggestions } = useGetProductSearchGlobalQuery(debouncedSearch, {
    skip: debouncedSearch.length < 2,
  })

  // we’ll store what was searched (product_id or q) at click time
  const [searchedTerm, setSearchedTerm] = useState(null)

  // --- Outlets (unchanged) ---
  const { data: outletData, isLoading: outletLoading } = useGetOutletsQuery()
  const outletOptions = outletData?.outlets || []

  // --- RTK Query for products (same pattern as original, just richer arg) ---
  const outletParam = searchedOutletId === 'all' ? 0 : Number(searchedOutletId)

  const arg =
    searchedTerm == null
      ? undefined
      : /^\d+$/.test(searchedTerm)
        ? { outlet_id: outletParam, product_id: Number(searchedTerm) }
        : { outlet_id: outletParam, q: searchedTerm }

  const { data: productData, isFetching: isProductsLoading } = useGetProductsByOutletQuery(arg, {
    skip: searchedOutletId === null || searchedTerm == null,
    refetchOnMountOrArgChange: true,
  })

  const handleOpenBatchModal = (variant) => {
    if (!variant?.batches || variant.batches.length === 0) return
    setSelectedBatchVariant(variant)
    setShowBatchModal(true)
  }

  const handleCloseBatchModal = () => {
    setShowBatchModal(false)
    setSelectedBatchVariant(null)
  }

  const formatDate = (value) => {
    if (!value) return 'N/A'
    return new Date(value).toLocaleDateString()
  }

  const allProducts = productData?.results || []

  // --- expand/collapse (unchanged) ---
  const [expandedProducts, setExpandedProducts] = useState({})
  useEffect(() => {
    if (allProducts.length > 0) {
      setExpandedProducts((prev) => {
        const updated = {}
        allProducts.forEach((product) => {
          updated[product.product_id] = prev[product.product_id] ?? true
        })
        return updated
      })
    }
  }, [allProducts])

  const getStatusBadge = (stockStatus) => {
    switch (stockStatus) {
      case 'out of stock':
        return (
          <span className="inv-badge inv-badge-danger">
            <span className="inv-dot" /> Out of Stock
          </span>
        )
      case 'reorder_level_reached':
        return (
          <span className="inv-badge inv-badge-warning">
            <span className="inv-dot" /> Reorder Level Reached
          </span>
        )
      case 'low_stock':
        return (
          <span className="inv-badge inv-badge-info">
            <span className="inv-dot" /> Low Stock
          </span>
        )
      case 'in stock':
      default:
        return (
          <span className="inv-badge inv-badge-success">
            <span className="inv-dot" /> In Stock
          </span>
        )
    }
  }

  // NEW: plain-text status label (used for print + CSV, no JSX)
  const getStatusText = (stockStatus) => {
    switch (stockStatus) {
      case 'out of stock':
        return 'Out of Stock'
      case 'reorder_level_reached':
        return 'Reorder Level Reached'
      case 'low_stock':
        return 'Low Stock'
      case 'in stock':
      default:
        return 'In Stock'
    }
  }

  // --- pagination (same as your original: 5 per page) ---
  const itemsPerPage = 5
  const totalPages = Math.ceil(allProducts.length / itemsPerPage) || 1
  const paginatedProducts = allProducts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const printRef = useRef()

  // --- NEW: applied filters (branch name + search term), shown on screen + print ---
  const appliedBranchName =
    searchedOutletId === null
      ? null
      : searchedOutletId === 'all'
        ? 'All Branches'
        : outletOptions.find((o) => String(o.outlet_id) === String(searchedOutletId))?.name || `Branch #${searchedOutletId}`

  const hasAppliedFilters = searchedOutletId !== null

  // NEW: escape helper for safe HTML injection into the print window
  const escapeHtml = (value) => {
    const str = String(value ?? '')
    return str.replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch])
  }

  // --- Print: professional, minimal, purple-accented, ALL records (no pagination), applied filters on top, clean page breaks ---
  const handlePrint = () => {
    if (allProducts.length === 0) return

    let bodyRows = ''
    allProducts.forEach((product) => {
      const uniqueVariants = [...new Map(product.variants.map((v) => [v.variant_id, v])).values()]

      bodyRows += `
        <tr class="p-group-row">
          <td colspan="9">
            <span class="p-group-title">${escapeHtml(product.title)}</span>
            <span class="p-group-count">${uniqueVariants.length} variant${uniqueVariants.length !== 1 ? 's' : ''}</span>
          </td>
        </tr>
      `

      uniqueVariants.forEach((variant) => {
        bodyRows += `
          <tr class="p-variant-row">
            <td class="p-center">${escapeHtml(variant.variant_id)}</td>
            <td>${escapeHtml(product.title)}</td>
            <td class="p-center">${escapeHtml(variant.variant_value)}</td>
            <td class="p-center">${escapeHtml(product.category_name || 'N/A')}</td>
            <td class="p-center">${escapeHtml(variant.outlet_name)}</td>
            <td class="p-center"><span class="p-status p-status-${escapeHtml(variant.stock_status || 'default').replace(/\s+/g, '-')}">${escapeHtml(getStatusText(variant.stock_status))}</span></td>
            <td class="p-center">${escapeHtml(variant.stock_in)}</td>
            <td class="p-center">${escapeHtml(variant.stock_out)}</td>
            <td class="p-center">${escapeHtml(variant.current_stock)}${variant.measurement_value ? ' (' + escapeHtml(variant.measurement_value) + ')' : ''}</td>
          </tr>
        `
      })
    })

    const totalVariantCount = allProducts.reduce((sum, p) => sum + [...new Map(p.variants.map((v) => [v.variant_id, v])).values()].length, 0)

    const filtersHtml = hasAppliedFilters
      ? `
        <div class="p-filters">
          <div class="p-filter-chip"><span class="p-filter-label">Branch</span><span class="p-filter-value">${escapeHtml(appliedBranchName)}</span></div>
          <div class="p-filter-chip"><span class="p-filter-label">Search</span><span class="p-filter-value">${searchedTerm ? escapeHtml(searchedTerm) : 'None'}</span></div>
        </div>
      `
      : ''

    const printWindow = window.open('', '', 'width=1000,height=700')
    printWindow.document.write(`
      <html>
        <head>
          <title>Inventory Status Report</title>
          <meta charset="utf-8" />
          <style>
            * { box-sizing: border-box; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
              color: #1f2233;
              margin: 0;
              padding: 32px 36px;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .p-header {
              display: flex;
              justify-content: space-between;
              align-items: flex-end;
              border-bottom: 2px solid #6d28d9;
              padding-bottom: 14px;
              margin-bottom: 16px;
            }
            .p-header h1 {
              font-size: 20px;
              font-weight: 700;
              letter-spacing: -0.01em;
              color: #1b0a35;
              margin: 0;
            }
            .p-header .p-sub {
              font-size: 11px;
              color: #6b7280;
              margin-top: 4px;
            }
            .p-meta {
              text-align: right;
              font-size: 11px;
              color: #6b7280;
            }
            .p-filters {
              display: flex;
              gap: 10px;
              margin-bottom: 18px;
              flex-wrap: wrap;
            }
            .p-filter-chip {
              display: flex;
              align-items: center;
              gap: 6px;
              background: #f5f3ff;
              border: 1px solid #ddd6fe;
              border-radius: 999px;
              padding: 5px 12px;
              font-size: 11.5px;
            }
            .p-filter-label {
              text-transform: uppercase;
              letter-spacing: 0.04em;
              font-weight: 700;
              color: #1a0d2e;
              font-size: 10px;
            }
            .p-filter-value {
              color: #110820;
              font-weight: 500;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              font-size: 11.5px;
            }
            thead { display: table-header-group; }
            tr { page-break-inside: avoid; }
            th {
              text-align: center;
              background: #271344;
              color: #fff;
              font-size: 10px;
              text-transform: uppercase;
              letter-spacing: 0.04em;
              font-weight: 600;
              padding: 9px 8px;
            }
            td {
              padding: 7px 8px;
              border-bottom: 1px solid #ece9f7;
            }
            .p-center { text-align: center; }
            .p-group-row td {
              background: #f5f3ff;
              border-bottom: 1px solid #ddd6fe;
              border-top: 1px solid #ddd6fe;
              padding: 8px 8px;
              page-break-after: avoid;
            }
            .p-group-title {
              font-weight: 700;
              color: #4c1d95;
              font-size: 12px;
            }
            .p-group-count {
              margin-left: 8px;
              font-size: 10px;
              color: #7c6ea8;
              font-weight: 500;
            }
            .p-status {
              display: inline-block;
              padding: 2px 9px;
              border-radius: 999px;
              font-size: 10px;
              font-weight: 600;
            }
            .p-status-out-of-stock { background: #fee2e2; color: #b42318; }
            .p-status-reorder_level_reached { background: #fef3c7; color: #92620a; }
            .p-status-low_stock { background: #dbeafe; color: #175cd3; }
            .p-status-in-stock { background: #d1fae5; color: #05713f; }
            .p-footer {
              margin-top: 16px;
              padding-top: 10px;
              border-top: 1px solid #ece9f7;
              font-size: 10px;
              color: #9ca3af;
              display: flex;
              justify-content: space-between;
            }
            @page { margin: 16mm 14mm; }
            @media print {
              .p-group-row { break-inside: avoid; }
              .p-variant-row { break-inside: avoid; }
            }
          </style>
        </head>
        <body>
          <div class="p-header">
            <div>
              <h1>Inventory Status Report</h1>
              <div class="p-sub">${totalVariantCount} variant${totalVariantCount !== 1 ? 's' : ''} across ${allProducts.length} product${allProducts.length !== 1 ? 's' : ''}</div>
            </div>
            <div class="p-meta">Generated ${escapeHtml(new Date().toLocaleString())}</div>
          </div>

          ${filtersHtml}

          <table>
            <thead>
              <tr>
                <th>Variant ID</th>
                <th>Product</th>
                <th>Variant</th>
                <th>Category</th>
                <th>Outlet</th>
                <th>Status</th>
                <th>Stock In</th>
                <th>Stock Out</th>
                <th>Current Stock</th>
              </tr>
            </thead>
            <tbody>
              ${bodyRows}
            </tbody>
          </table>

          <div class="p-footer">
            <span>Inventory Status Report</span>
            <span>Page auto-generated — confidential</span>
          </div>
        </body>
      </html>
    `)
    printWindow.document.close()
    printWindow.focus()
    // give the new window a beat to lay out before invoking print
    setTimeout(() => {
      printWindow.print()
    }, 200)
  }

  // --- CSV export: all records (no pagination), chunked with a progress bar since it can take time on large datasets ---
  const escapeCsvField = (value) => {
    const str = String(value ?? '')
    if (/[",\n]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`
    }
    return str
  }

  const handleDownloadCSV = async () => {
    if (allProducts.length === 0 || csvDownloading) return

    setCsvDownloading(true)
    setCsvProgress(0)

    // flatten all products/variants into flat rows first
    const rows = []
    allProducts.forEach((product) => {
      const uniqueVariants = [...new Map(product.variants.map((v) => [v.variant_id, v])).values()]
      uniqueVariants.forEach((variant) => {
        rows.push({
          productVariant: `${product.title} - ${variant.variant_value}`,
          variantId: variant.variant_id,
          status: getStatusText(variant.stock_status),
          stockIn: variant.stock_in,
          stockOut: variant.stock_out,
          currentStock: variant.measurement_value ? `${variant.current_stock} (${variant.measurement_value})` : variant.current_stock,
        })
      })
    })

    const header = ['Product/Variant', 'Variant ID', 'Status', 'Total Stock In', 'Total Stock Out', 'Current Stock']
    let csvContent = header.map(escapeCsvField).join(',') + '\r\n'

    const totalRows = rows.length
    const chunkSize = 500

    if (totalRows === 0) {
      setCsvDownloading(false)
      setCsvProgress(0)
      return
    }

    for (let i = 0; i < totalRows; i += chunkSize) {
      const chunk = rows.slice(i, i + chunkSize)
      csvContent +=
        chunk
          .map((r) => [r.productVariant, r.variantId, r.status, r.stockIn, r.stockOut, r.currentStock].map(escapeCsvField).join(','))
          .join('\r\n') + '\r\n'

      const progress = Math.min(100, Math.round(((i + chunk.length) / totalRows) * 100))
      setCsvProgress(progress)

      // yield back to the browser so the progress bar can actually paint
      await new Promise((resolve) => setTimeout(resolve, 0))
    }

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `inventory-status-${new Date().toISOString().slice(0, 10)}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    setCsvProgress(100)
    setTimeout(() => {
      setCsvDownloading(false)
      setCsvProgress(0)
    }, 450)
  }

  const handlePickSuggestion = (s) => {
    setSelectedProductId(s.product_id)
    setSearchInput(s.title)
    setShowSuggestions(false) // hide suggestions after pick
    inputRef.current?.focus()
  }

  const handleClearSearch = () => {
    setSearchInput('')
    setDebouncedSearch('')
    setSelectedProductId(null)
    inputRef.current?.focus()
  }
  const onSearchChange = (val) => {
    setSearchInput(val)
    setSelectedProductId(null)
  }

  // Click Search → follow original flow: set searched state; hook fetches
  const handleSearchClick = () => {
    const outletToSearch = selectedOutletId
    const term = selectedProductId != null ? String(selectedProductId) : debouncedSearch

    setSearchedOutletId(outletToSearch)
    setSearchedTerm(term || '') // empty means “no filter”
    setCurrentPage(1)
    setShowSuggestions(false) // hide suggestions when user triggers search
  }

  return (
    <div className="mt-2">
   
      <Card className="inv-card border-0">
        <CardHeader className="py-3 inv-card-header">
          <div className="d-flex justify-content-between align-items-center">
            <CardTitle as="h4" className="mb-0 inv-card-title">
              Inventory Status
            </CardTitle>

            <button type="button" className="inv-print-btn" onClick={handlePrint} disabled={allProducts.length === 0} title="Print inventory report">
              <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round">
                <polyline points="6 9 6 2 18 2 18 9" />
                <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" />
                <rect x="6" y="14" width="12" height="8" />
              </svg>
              Print
            </button>
          </div>
        </CardHeader>

        <CardBody>
          <div ref={printRef}>
            <div className="po-filter-bar mb-3">
              <div className="row g-2 align-items-end">
                {/* Search Product */}
                <div className="col-12 col-lg-6" style={{ position: 'relative' }}>
                  <div ref={searchContainerRef}>
                    <div className="po-filter-label">Search Product</div>

                    <div className="inv-product-search-wrap">
                      <input
                        ref={inputRef}
                        className="form-control form-control-sm w-100 inv-input"
                        placeholder="Type product name..."
                        value={searchInput}
                        onChange={(e) => onSearchChange(e.target.value)}
                        onFocus={() => {
                          if (debouncedSearch.length >= 2 && !selectedProductId) {
                            setShowSuggestions(true)
                          }
                        }}
                      />

                      {searchInput && (
                        <button type="button" className="inv-clear-btn" onClick={handleClearSearch} aria-label="Clear product search" title="Clear">
                          ×
                        </button>
                      )}
                    </div>

                    {/* suggestions */}
                    {showSuggestions && searchInput && debouncedSearch.length >= 2 && !selectedProductId && (
                      <div className="inv-suggestions">
                        <div className="inv-suggestions-meta">
                          <span>{isSearchingSuggestions ? 'Searching…' : 'Top matches'}</span>
                          {isSearchingSuggestions && <Spinner size="sm" />}
                        </div>

                        <ListGroup variant="flush">
                          {(productSuggestions || []).length > 0 ? (
                            productSuggestions.map((s) => (
                              <ListGroup.Item action key={s.product_id} onClick={() => handlePickSuggestion(s)} className="inv-suggestion-item">
                                <div className="d-flex justify-content-between align-items-center">
                                  <span className="inv-suggestion-title">{s.title}</span>
                                  <span className="inv-suggestion-id">#{s.product_id}</span>
                                </div>
                              </ListGroup.Item>
                            ))
                          ) : (
                            <ListGroup.Item disabled className="text-muted small">
                              No matches
                            </ListGroup.Item>
                          )}
                        </ListGroup>
                      </div>
                    )}
                  </div>
                </div>

                {/* Branch */}
                <div className="col-6 col-lg-3">
                  <div className="po-filter-label">Select Branch</div>

                  <select
                    className="form-select form-select-sm w-100 inv-input"
                    value={selectedOutletId}
                    onChange={(e) => setSelectedOutletId(e.target.value)}
                    disabled={outletLoading}>
                    <option value="all">All Branches</option>
                    {outletOptions.map((outlet) => (
                      <option key={outlet.outlet_id} value={outlet.outlet_id}>
                        {outlet.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Search + Download buttons */}
                <div className="col-6 col-lg-3">
                  <div className="d-flex align-items-end h-100 gap-2">
                    <button
                      type="button"
                      className="inv-search-btn flex-grow-1"
                      onClick={handleSearchClick}
                      disabled={!selectedOutletId || isProductsLoading}>
                      {isProductsLoading ? (
                        <span className="inv-search-loading-content">
                          <span className="inv-search-spinner" />
                          Searching
                        </span>
                      ) : (
                        'Search'
                      )}
                    </button>

                    <button
                      type="button"
                      className="inv-download-btn"
                      onClick={handleDownloadCSV}
                      disabled={allProducts.length === 0 || csvDownloading}
                      title="Download CSV">
                      <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                        <polyline points="7 10 12 15 17 10" />
                        <line x1="12" y1="15" x2="12" y2="3" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Applied filters summary */}
            {hasAppliedFilters && (
              <div className="inv-applied-filters mb-3">
                <span className="inv-applied-label">Applied filters:</span>
                <span className="inv-filter-chip">
                  Branch: <strong>{appliedBranchName}</strong>
                </span>
                <span className="inv-filter-chip">
                  Search: <strong>{searchedTerm ? searchedTerm : 'None'}</strong>
                </span>
              </div>
            )}

            <div className="inv-table-shell">
              <Table hover responsive className="inv-table mb-0">
                <thead>
                  <tr>
                    <th className="text-center">Product/Variant ID</th>
                    <th className="text-center">Product</th>
                    <th className="text-center">Product Variant</th>
                    <th className="text-center">Category</th>
                    <th className="text-center">Outlet</th>
                    <th className="text-center">Status</th>
                    <th className="text-center">Total Stock In</th>
                    <th className="text-center">Total Stock Out</th>
                    <th className="text-center">Current Stock</th>
                  </tr>
                </thead>

                <tbody>
                  {isProductsLoading ? (
                    <tr>
                      <td colSpan="9" className="inv-table-loading-cell">
                        <div className="inv-table-loading">
                          <div className="inv-table-spinner">
                            <span />
                            <span />
                            <span />
                          </div>

                          <div className="inv-table-loading-title">Loading inventory</div>

                          <div className="inv-table-loading-text">Please wait while the latest stock details are retrieved.</div>
                        </div>
                      </td>
                    </tr>
                  ) : allProducts.length > 0 ? (
                    paginatedProducts.map((product) => {
                      const isExpanded = expandedProducts[product.product_id]
                      const uniqueVariants = [...new Map(product.variants.map((v) => [v.variant_id, v])).values()]

                      return (
                        <React.Fragment key={product.product_id}>
                          <tr
                            className="inv-group-row"
                            onClick={() =>
                              setExpandedProducts((prev) => ({
                                ...prev,
                                [product.product_id]: !prev[product.product_id],
                              }))
                            }>
                            <td colSpan="9">
                              <div className="d-flex align-items-center">
                                <span className={`inv-chevron ${isExpanded ? 'is-open' : ''}`}>
                                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M3 2L8 6L3 10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                                  </svg>
                                </span>
                                <span className="inv-group-title">{product.title}</span>
                                <span className="inv-count-badge">
                                  {uniqueVariants.length} variant{uniqueVariants.length !== 1 ? 's' : ''}
                                </span>
                              </div>
                            </td>
                          </tr>

                          {isExpanded &&
                            uniqueVariants.map((variant, idx) => (
                              <tr
                                key={variant.variant_id}
                                className={`inv-variant-row ${
                                  variant.stock_status === 'out of stock'
                                    ? 'inv-row-danger'
                                    : variant.stock_status === 'reorder_level_reached'
                                      ? 'inv-row-warning'
                                      : variant.stock_status === 'low_stock'
                                        ? 'inv-row-info'
                                        : variant.stock_status === 'in stock'
                                          ? 'inv-row-success'
                                          : ''
                                }`}
                                style={{ animationDelay: `${Math.min(idx, 8) * 35}ms` }}>
                                <td className="text-center">{variant.variant_id}</td>
                                <td>
                                  <div className="d-flex justify-content-center">
                                    <img
                                      src={product.media_url ? product.media_url : '/package.png'}
                                      alt={product.title}
                                      onError={(e) => {
                                        if (e.target.src !== window.location.origin + '/package.png') {
                                          e.target.onerror = null
                                          e.target.src = '/package.png'
                                          e.target.style.width = '40px'
                                          e.target.style.height = '40px'
                                        }
                                      }}
                                      className="inv-thumb"
                                    />
                                  </div>
                                </td>
                                <td className="text-center">
                                  <div className="d-flex justify-content-center align-items-center gap-2">
                                    <span>{variant.variant_value}</span>

                                    {Array.isArray(variant.batches) && variant.batches.length > 0 && (
                                      <button
                                        type="button"
                                        className="inv-batch-btn"
                                        title={`View ${variant.batches.length} batch detail${variant.batches.length !== 1 ? 's' : ''}`}
                                        aria-label={`View batch details for ${variant.variant_value}`}
                                        onClick={(e) => {
                                          e.stopPropagation()
                                          handleOpenBatchModal(variant)
                                        }}>
                                        <svg
                                          width="16"
                                          height="16"
                                          viewBox="0 0 24 24"
                                          fill="none"
                                          stroke="currentColor"
                                          strokeWidth="1.9"
                                          strokeLinecap="round"
                                          strokeLinejoin="round"
                                          aria-hidden="true">
                                          <path d="M6.75 3.75h7.5l3 3v13.5H6.75z" />
                                          <path d="M14.25 3.75v3h3" />
                                          <path d="M9.5 11h5" />
                                          <path d="M9.5 14.25h5" />
                                          <path d="M9.5 17.5h3.25" />
                                        </svg>

                                        <span className="inv-batch-count">{variant.batches.length}</span>
                                      </button>
                                    )}
                                  </div>
                                </td>
                                <td className="text-center">{product.category_name || 'N/A'}</td>
                                <td className="text-center">{variant.outlet_name}</td>
                                <td className="text-center">{getStatusBadge(variant.stock_status)}</td>
                                <td className="text-center">{variant.stock_in}</td>
                                <td className="text-center">{variant.stock_out}</td>
                                <td className="text-center">
                                  <span className="inv-stock-value">{variant.current_stock}</span>
                                  {variant.measurement_value && <span className="inv-stock-unit"> ({variant.measurement_value})</span>}
                                </td>
                              </tr>
                            ))}
                        </React.Fragment>
                      )
                    })
                  ) : (
                    <tr>
                      <td colSpan="9" className="text-center text-muted py-4">
                        {searchedOutletId === null ? 'Choose a branch and click Search.' : 'No results found for this outlet / search.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </div>
          </div>
        </CardBody>

        {/* ================= PAGINATION ================= */}
        {totalPages > 1 && (
          <div className="d-flex justify-content-end mt-1 mb-2 me-2">
            <Pagination className="inv-pagination">
              {(() => {
                const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                const pages = []

                let start = safeCurrent - 2
                let end = safeCurrent + 2

                if (totalPages <= 5) {
                  start = 1
                  end = totalPages
                } else {
                  if (start < 1) {
                    start = 1
                    end = 5
                  }
                  if (end > totalPages) {
                    end = totalPages
                    start = totalPages - 4
                  }
                }

                for (let i = start; i <= end; i++) {
                  pages.push(
                    <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setCurrentPage(i)}>
                      {i}
                    </Pagination.Item>,
                  )
                }

                return (
                  <>
                    {/* FIRST */}
                    <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(1)}>
                      First
                    </Pagination.Item>

                    {/* PREV (<) */}
                    <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(safeCurrent - 1)}>
                      {'<'}
                    </Pagination.Item>

                    {pages}

                    {/* NEXT (>) */}
                    <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(safeCurrent + 1)}>
                      {'>'}
                    </Pagination.Item>

                    {/* LAST */}
                    <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(totalPages)}>
                      Last
                    </Pagination.Item>
                  </>
                )
              })()}
            </Pagination>
          </div>
        )}

        <Modal show={showBatchModal} onHide={handleCloseBatchModal} centered size="lg" className="inv-modal">
          <Modal.Header closeButton className="inv-modal-header">
            <Modal.Title>Batch Details</Modal.Title>
          </Modal.Header>

          <Modal.Body>
            {selectedBatchVariant && (
              <>
                <div className="inv-modal-meta mb-3">
                  <div>
                    <span className="inv-modal-meta-label">Variant Value</span>
                    <span className="inv-modal-meta-value">{selectedBatchVariant.variant_value || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="inv-modal-meta-label">Variant ID</span>
                    <span className="inv-modal-meta-value">{selectedBatchVariant.variant_id}</span>
                  </div>
                </div>

                <Table hover responsive size="sm" className="inv-batch-table">
                  <thead>
                    <tr>
                      <th>Batch No</th>
                      <th>Cost Price</th>
                      <th>Selling Price</th>
                      <th>Manufacture Date</th>
                      <th>Expiry Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {selectedBatchVariant.batches.map((batch) => (
                      <tr key={batch.batch_management_id || batch.batch_number}>
                        <td>{batch.batch_number || 'N/A'}</td>
                        <td>{batch.cost_price ?? 0}</td>
                        <td>{batch.selling_price ?? 0}</td>
                        <td>{formatDate(batch.manufacture_date)}</td>
                        <td>{formatDate(batch.expiry_date)}</td>
                        <td>{batch.status || 'N/A'}</td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              </>
            )}
          </Modal.Body>

          <Modal.Footer className="inv-modal-footer">
            <Button variant="light" size="sm" onClick={handleCloseBatchModal} className="inv-close-btn">
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        {/* ================= CSV DOWNLOAD PROGRESS MODAL ================= */}
        <Modal show={csvDownloading} centered backdrop="static" keyboard={false} className="inv-csv-modal" size="sm">
          <Modal.Body className="inv-csv-modal-body">
            <div className="inv-csv-icon">
              <svg
                width="22"
                height="22"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            </div>
            <div className="inv-csv-title">Preparing your CSV…</div>
            <div className="inv-csv-sub">Exporting all records, this may take a moment for large datasets.</div>
            <ProgressBar now={csvProgress} label={`${csvProgress}%`} className="inv-csv-progress" />
          </Modal.Body>
        </Modal>
      </Card>

      <style jsx>{`
        .inv-status-wrapper {
          --inv-primary: #0b2e6f;
          --inv-primary-soft: #eef2fb;
          --inv-border: #e7e9ee;
          --inv-muted: #6b7280;
          --inv-purple: #6d28d9;
          --inv-purple-dark: #4c1d95;
          --inv-purple-soft: #f5f3ff;
          --inv-purple-border: #ddd6fe;
        }

        .inv-card {
          border-radius: 14px;
          box-shadow:
            0 1px 2px rgba(16, 24, 40, 0.04),
            0 4px 16px rgba(16, 24, 40, 0.06);
          overflow: hidden;
        }

        .inv-card-header {
          background: #fff;
          border-bottom: 1px solid var(--inv-border);
        }

        .inv-card-title {
          font-weight: 600;
          letter-spacing: -0.01em;
          color: #111827;
        }

        .inv-print-btn {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          height: 34px;
          padding: 0 16px;
          border: none;
          border-radius: 8px;
          background: linear-gradient(135deg, #7c3aed, #5b21b6);
          color: #fff;
          font-size: 13px;
          font-weight: 500;
          box-shadow: 0 2px 6px rgba(109, 40, 217, 0.25);
          transition:
            filter 0.15s ease,
            transform 0.1s ease,
            box-shadow 0.15s ease;
        }
        .inv-print-btn:hover:not(:disabled) {
          filter: brightness(1.06);
          box-shadow: 0 4px 10px rgba(109, 40, 217, 0.32);
        }
        .inv-print-btn:active:not(:disabled) {
          transform: scale(0.97);
        }
        .inv-print-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
          box-shadow: none;
        }

        .inv-input {
          height: 36px;
          border-radius: 8px;
          border-color: var(--inv-border);
          font-size: 13px;
          transition:
            border-color 0.15s ease,
            box-shadow 0.15s ease;
        }
        .inv-input:focus {
          border-color: #86b7fe;
          box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }

        .inv-product-search-wrap {
          position: relative;
        }

        .inv-product-search-wrap .inv-input {
          padding-right: 34px;
        }

        .inv-clear-btn {
          position: absolute;
          top: 50%;
          right: 10px;
          z-index: 2;
          border: none;
          background: transparent;
          padding: 0;
          color: #6b7280;
          font-size: 19px;
          line-height: 1;
          transform: translateY(-50%);
          cursor: pointer;
        }

        .inv-clear-btn:hover {
          color: #111827;
        }

        .inv-search-btn {
          height: 36px;
          border: none;
          border-radius: 8px;
          background: #111827;
          color: #fff;
          font-size: 13px;
          font-weight: 500;
          transition:
            background 0.15s ease,
            transform 0.1s ease;
        }
        .inv-search-btn:hover:not(:disabled) {
          background: #000;
        }
        .inv-search-btn:active:not(:disabled) {
          transform: scale(0.98);
        }
        .inv-search-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .inv-search-loading-content {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 7px;
        }

        .inv-search-spinner {
          width: 13px;
          height: 13px;
          border: 2px solid rgba(255, 255, 255, 0.38);
          border-top-color: #ffffff;
          border-radius: 50%;
          animation: invSearchSpin 0.7s linear infinite;
        }

        .inv-table-loading-cell {
          height: 260px;
          padding: 0 !important;
          background: #ffffff !important;
          border-bottom: none !important;
        }

        .inv-table-loading {
          min-height: 260px;
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 30px;
          text-align: center;
        }

        .inv-table-spinner {
          height: 30px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
          margin-bottom: 13px;
        }

        .inv-table-spinner span {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: var(--inv-primary);
          animation: invLoadingPulse 1s ease-in-out infinite;
        }

        .inv-table-spinner span:nth-child(2) {
          animation-delay: 0.14s;
        }

        .inv-table-spinner span:nth-child(3) {
          animation-delay: 0.28s;
        }

        .inv-table-loading-title {
          color: #1f2937;
          font-size: 13.5px;
          font-weight: 600;
          line-height: 1.4;
        }

        .inv-table-loading-text {
          max-width: 320px;
          margin-top: 4px;
          color: var(--inv-muted);
          font-size: 11.5px;
          line-height: 1.5;
        }

        @keyframes invSearchSpin {
          to {
            transform: rotate(360deg);
          }
        }

        @keyframes invLoadingPulse {
          0%,
          60%,
          100% {
            opacity: 0.35;
            transform: translateY(0);
          }

          30% {
            opacity: 1;
            transform: translateY(-5px);
          }
        }

        .inv-download-btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 36px;
          height: 36px;
          flex-shrink: 0;
          border-radius: 8px;
          border: 1px solid var(--inv-purple-border);
          background: var(--inv-purple-soft);
          color: var(--inv-purple);
          transition:
            background 0.15s ease,
            transform 0.1s ease,
            border-color 0.15s ease;
        }
        .inv-download-btn:hover:not(:disabled) {
          background: var(--inv-purple-border);
          border-color: var(--inv-purple);
        }
        .inv-download-btn:active:not(:disabled) {
          transform: scale(0.95);
        }
        .inv-download-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }

        .inv-applied-filters {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
        }
        .inv-applied-label {
          font-size: 11.5px;
          font-weight: 600;
          color: var(--inv-muted);
          text-transform: uppercase;
          letter-spacing: 0.03em;
          margin-right: 2px;
        }
        .inv-filter-chip {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 12px;
          color: var(--inv-purple-dark);
          background: var(--inv-purple-soft);
          border: 1px solid var(--inv-purple-border);
          border-radius: 999px;
          padding: 4px 12px;
        }
        .inv-filter-chip strong {
          font-weight: 600;
        }

        .inv-suggestions {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          z-index: 1000;
          background: #fff;
          border: 1px solid var(--inv-border);
          border-radius: 0 0 10px 10px;
          max-height: 260px;
          overflow-y: auto;
          box-shadow: 0 10px 24px rgba(16, 24, 40, 0.12);
          animation: invFadeDown 0.16s ease both;
        }

        .inv-suggestions-meta {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 12px;
          font-size: 11.5px;
          color: var(--inv-muted);
          border-bottom: 1px solid #f1f2f5;
        }

        .inv-suggestion-item {
          border: none !important;
          padding: 8px 12px;
          transition: background 0.12s ease;
        }
        .inv-suggestion-item:hover {
          background: var(--inv-primary-soft);
        }
        .inv-suggestion-title {
          font-size: 13px;
          color: #1f2937;
        }
        .inv-suggestion-id {
          font-size: 12px;
          color: var(--inv-muted);
        }

        .inv-table-shell {
          border: 1px solid var(--inv-border);
          border-radius: 12px;
          overflow: hidden;
        }

        .inv-table {
          font-size: 13.5px;
        }
        .inv-table :global(thead) {
          background: #f7f8fa;
        }
        .inv-table :global(th) {
          position: sticky;
          top: 0;
          font-size: 11.5px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: #4b5563;
          border-bottom: 1px solid var(--inv-border);
          padding: 12px 10px;
          white-space: nowrap;
        }
        .inv-table :global(td) {
          padding: 10px 10px;
          vertical-align: middle;
          border-color: #f0f1f4;
          color: #1f2937;
        }
        .inv-table :global(tbody tr:last-child td) {
          border-bottom: none;
        }

        .inv-group-row {
          cursor: pointer;
          background: #fafbfc;
          transition: background 0.15s ease;
        }
        .inv-group-row:hover :global(td) {
          background: var(--inv-primary-soft) !important;
        }
        .inv-group-row :global(td) {
          padding: 11px 12px;
          border-bottom: 1px solid var(--inv-border);
        }

        .inv-chevron {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          margin-right: 10px;
          color: var(--inv-primary);
          transition: transform 0.22s ease;
          flex-shrink: 0;
        }
        .inv-chevron.is-open {
          transform: rotate(90deg);
        }

        .inv-group-title {
          font-weight: 600;
          color: var(--inv-primary);
          font-size: 13.5px;
        }

        .inv-count-badge {
          margin-left: 10px;
          font-size: 11px;
          font-weight: 500;
          color: var(--inv-muted);
          background: #eef0f3;
          border-radius: 999px;
          padding: 2px 9px;
        }

        .inv-variant-row {
          animation: invRowIn 0.26s ease both;
        }
        .inv-variant-row td {
          background: #fff;
        }
        .inv-variant-row:hover td {
          background: #f9fafb;
        }

        .inv-row-danger td {
          background: #fef2f2 !important;
        }
        .inv-row-warning td {
          background: #fffbeb !important;
        }
        .inv-row-info td {
          background: #eff8ff !important;
        }
        .inv-row-success td {
          background: #f2fbf5 !important;
        }

        .inv-thumb {
          width: 44px;
          height: 44px;
          object-fit: cover;
          border-radius: 8px;
          border: 1px solid var(--inv-border);
          box-shadow: 0 1px 2px rgba(16, 24, 40, 0.06);
        }

        .inv-batch-btn {
          position: relative;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
          flex-shrink: 0;
          padding: 0;
          border: 1px solid #bfdbfe;
          border-radius: 9px;
          background: linear-gradient(145deg, #eff6ff 0%, #dbeafe 100%);
          color: #2563eb;
          cursor: pointer;
          box-shadow:
            0 1px 2px rgba(37, 99, 235, 0.12),
            0 3px 8px rgba(37, 99, 235, 0.1);
          transition:
            color 0.15s ease,
            background 0.15s ease,
            border-color 0.15s ease,
            box-shadow 0.15s ease,
            transform 0.12s ease;
        }

        .inv-batch-btn:hover {
          color: #ffffff;
          background: linear-gradient(145deg, #3b82f6 0%, #2563eb 100%);
          border-color: #2563eb;
          box-shadow:
            0 2px 4px rgba(37, 99, 235, 0.2),
            0 6px 14px rgba(37, 99, 235, 0.24);
          transform: translateY(-1px);
        }

        .inv-batch-btn:active {
          transform: translateY(0) scale(0.96);
          box-shadow: 0 2px 5px rgba(37, 99, 235, 0.18);
        }

        .inv-batch-btn:focus-visible {
          outline: none;
          box-shadow:
            0 0 0 3px rgba(59, 130, 246, 0.2),
            0 4px 12px rgba(37, 99, 235, 0.2);
        }

        .inv-batch-btn svg {
          display: block;
        }

        .inv-batch-count {
          position: absolute;
          top: -6px;
          right: -6px;
          min-width: 17px;
          height: 17px;
          padding: 0 4px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #ffffff;
          border-radius: 999px;
          background: #1d4ed8;
          color: #ffffff;
          font-size: 9px;
          font-weight: 700;
          line-height: 1;
          box-shadow: 0 1px 4px rgba(29, 78, 216, 0.3);
        }

        .inv-batch-btn:hover .inv-batch-count {
          background: #1e3a8a;
        }

        .inv-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11.5px;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: 999px;
          white-space: nowrap;
        }
        .inv-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: currentColor;
          flex-shrink: 0;
        }
        .inv-badge-danger {
          background: #fee2e2;
          color: #b42318;
        }
        .inv-badge-warning {
          background: #fef3c7;
          color: #92620a;
        }
        .inv-badge-info {
          background: #dbeafe;
          color: #175cd3;
        }
        .inv-badge-success {
          background: #d1fae5;
          color: #05713f;
        }

        .inv-stock-value {
          font-weight: 600;
        }
        .inv-stock-unit {
          color: var(--inv-muted);
          font-size: 12px;
        }

        .inv-pagination :global(.page-link) {
          border-radius: 8px;
          margin: 0 2px;
          border: 1px solid var(--inv-border);
          color: #374151;
          font-size: 13px;
          transition: all 0.12s ease;
        }
        .inv-pagination :global(.page-item.active .page-link) {
          background: #111827;
          border-color: #111827;
        }
        .inv-pagination :global(.page-link:hover) {
          background: var(--inv-primary-soft);
        }

        .inv-modal-header {
          border-bottom: 1px solid var(--inv-border);
        }
        .inv-modal-footer {
          border-top: 1px solid var(--inv-border);
        }
        .inv-close-btn {
          border-radius: 8px;
          font-size: 13px;
        }

        .inv-modal-meta {
          display: flex;
          gap: 24px;
          padding: 10px 14px;
          background: #f7f8fa;
          border-radius: 10px;
        }
        .inv-modal-meta-label {
          display: block;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          color: var(--inv-muted);
        }
        .inv-modal-meta-value {
          display: block;
          font-size: 14px;
          font-weight: 600;
          color: #111827;
        }

        .inv-batch-table :global(thead) {
          background: #f7f8fa;
        }
        .inv-batch-table :global(th) {
          font-size: 11.5px;
          text-transform: uppercase;
          letter-spacing: 0.03em;
          color: #4b5563;
          font-weight: 600;
        }

        .inv-csv-modal-body {
          text-align: center;
          padding: 28px 24px;
        }
        .inv-csv-icon {
          width: 48px;
          height: 48px;
          margin: 0 auto 12px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--inv-purple-soft);
          color: var(--inv-purple);
        }
        .inv-csv-title {
          font-size: 15px;
          font-weight: 600;
          color: #111827;
          margin-bottom: 4px;
        }
        .inv-csv-sub {
          font-size: 12.5px;
          color: var(--inv-muted);
          margin-bottom: 16px;
        }
        .inv-csv-progress :global(.progress-bar) {
          background-color: var(--inv-purple);
        }
        .inv-csv-progress {
          height: 10px;
          border-radius: 999px;
          font-size: 9px;
        }

        @keyframes invRowIn {
          from {
            opacity: 0;
            transform: translateY(-4px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes invFadeDown {
          from {
            opacity: 0;
            transform: translateY(-4px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @media (prefers-reduced-motion: reduce) {
          .inv-variant-row,
          .inv-suggestions,
          .inv-chevron {
            animation: none !important;
            transition: none !important;
          }
        }
      `}</style>
    </div>
  )
}

export default InventoryStatus
