'use client'
import React, { useState, useEffect, useRef } from 'react'
import { Table, Form, Row, Col, Card, CardHeader, CardBody, CardTitle, Button, Badge, Spinner, ListGroup, Pagination } from 'react-bootstrap'
import { useGetOutletsQuery, useGetProductSearchGlobalQuery, useGetProductsByOutletQuery } from '@/store/features/apiSlice'

function InventoryStatus() {
  const [selectedOutletId, setSelectedOutletId] = useState('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [searchedOutletId, setSearchedOutletId] = useState(null)

  // --- NEW: search input + debounce + suggestion pick ---
  const [searchInput, setSearchInput] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [selectedProductId, setSelectedProductId] = useState(null)
  const inputRef = useRef(null)
  // NEW: control whether suggestions are visible
  const [showSuggestions, setShowSuggestions] = useState(false)
  // ref for the search input / suggestion container area (used to detect outside clicks)
  const searchContainerRef = useRef(null)

  useEffect(() => {
    const t = setTimeout(() => {
      const trimmed = searchInput.trim()
      setDebouncedSearch(trimmed)

      // show suggestions when we have >=2 chars and user hasn't chosen a product
      if (trimmed.length >= 2 && !selectedProductId) {
        setShowSuggestions(true)
      } else {
        setShowSuggestions(false)
      }
    }, 400)
    return () => clearTimeout(t)
  }, [searchInput, selectedProductId])

  useEffect(() => {
    function handleDocClick(e) {
      // nothing to do if suggestions already hidden
      if (!showSuggestions) return

      // if click is inside the search container, keep open
      if (searchContainerRef.current && searchContainerRef.current.contains(e.target)) {
        return
      }

      // otherwise hide suggestions
      setShowSuggestions(false)
    }

    document.addEventListener('mousedown', handleDocClick)
    return () => document.removeEventListener('mousedown', handleDocClick)
  }, [showSuggestions])

  // suggestions (min 2 chars)
  const { data: productSuggestions = [], isFetching: isSearchingSuggestions } = useGetProductSearchGlobalQuery(debouncedSearch, {
    skip: debouncedSearch.length < 2,
  })

  // we’ll store what was searched (product_id or q) at click time
  const [searchedTerm, setSearchedTerm] = useState(null)

  // --- Outlets (unchanged) ---
  const { data: outletData, isLoading: outletLoading } = useGetOutletsQuery()
  const outletOptions = outletData?.outlets || []

  // --- RTK Query for products (same pattern as original, just richer arg) ---
  const outletParam = searchedOutletId === 'all' ? 0 : Number(searchedOutletId)

  const arg =
    searchedTerm == null
      ? undefined
      : /^\d+$/.test(searchedTerm)
        ? { outlet_id: outletParam, product_id: Number(searchedTerm) }
        : { outlet_id: outletParam, q: searchedTerm }

  const { data: productData } = useGetProductsByOutletQuery(arg, {
    skip: searchedOutletId === null || searchedTerm == null,
    refetchOnMountOrArgChange: true,
  })

  const allProducts = productData?.results || []

  // --- expand/collapse (unchanged) ---
  const [expandedProducts, setExpandedProducts] = useState({})
  useEffect(() => {
    if (allProducts.length > 0) {
      setExpandedProducts((prev) => {
        const updated = {}
        allProducts.forEach((product) => {
          updated[product.product_id] = prev[product.product_id] ?? true
        })
        return updated
      })
    }
  }, [allProducts])

  const getStatusBadge = (stockStatus) => {
    switch (stockStatus) {
      case 'out of stock':
        return <Badge bg="danger">Out of Stock</Badge>
      case 'reorder_level_reached':
        return <Badge bg="warning">Reorder Level Reached</Badge>
      case 'low_stock':
        return <Badge bg="info">Low Stock</Badge>
      case 'in stock':
      default:
        return <Badge bg="success">In Stock</Badge>
    }
  }

  // --- pagination (same as your original: 5 per page) ---
  const itemsPerPage = 5
  const totalPages = Math.ceil(allProducts.length / itemsPerPage) || 1
  const paginatedProducts = allProducts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  // --- Print (unchanged) ---
  const printRef = useRef()
  const handlePrint = () => {
    const printContents = printRef.current.innerHTML
    const newWindow = window.open('', '', 'width=900,height=650')
    newWindow.document.write(`
    <html>
      <head>
        <title>Inventory Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
          .no-print { display: none !important; }
        </style>
      </head>
      <body>
        <h2>Inventory Status Report</h2>
        ${printContents}
      </body>
    </html>
  `)
    newWindow.document.close()
    newWindow.print()
  }

  const handlePickSuggestion = (s) => {
    setSelectedProductId(s.product_id)
    setSearchInput(s.title)
    setShowSuggestions(false) // hide suggestions after pick
    inputRef.current?.focus()
  }

  const handleClearSearch = () => {
    setSearchInput('')
    setDebouncedSearch('')
    setSelectedProductId(null)
    inputRef.current?.focus()
  }
  const onSearchChange = (val) => {
    setSearchInput(val)
    setSelectedProductId(null)
  }

  // Click Search → follow original flow: set searched state; hook fetches
  const handleSearchClick = () => {
    const outletToSearch = selectedOutletId
    const term = selectedProductId != null ? String(selectedProductId) : debouncedSearch

    setSearchedOutletId(outletToSearch)
    setSearchedTerm(term || '') // empty means “no filter”
    setCurrentPage(1)
    setShowSuggestions(false) // hide suggestions when user triggers search
  }

  return (
    <div className="container mt-4">
      <Card>
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center justify-content-between">
            <Col>
              <CardTitle as="h4" className="mb-0">
                Inventory Status
              </CardTitle>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          <div ref={printRef}>
            <Form>
              <Row className="mb-3 align-items-end">
                {/* NEW: Search field first */}
                <Col md={5} style={{ position: 'relative' }}>
                  <div ref={searchContainerRef}>
                    <div className="d-flex justify-content-between align-items-center">
                      <Form.Label className="mb-1">Search Product</Form.Label>
                      <Button variant="link" className="p-0 mb-1" onClick={handleClearSearch} style={{ textDecoration: 'underline' }}>
                        Clear
                      </Button>
                    </div>
                    <Form.Control
                      ref={inputRef}
                      placeholder="Type product name..."
                      value={searchInput}
                      onChange={(e) => onSearchChange(e.target.value)}
                      onFocus={() => {
                        if (debouncedSearch.length >= 2 && !selectedProductId) {
                          setShowSuggestions(true)
                        }
                      }}
                    />

                    {/* suggestions */}
                    {showSuggestions && searchInput && debouncedSearch.length >= 2 && !selectedProductId && (
                      <div
                        style={{
                          position: 'absolute',
                          top: '100%',
                          left: 0,
                          right: 0,
                          zIndex: 1000,
                          background: '#fff',
                          border: '1px solid #ddd',
                          borderTop: 'none',
                          maxHeight: 260,
                          overflowY: 'auto',
                          boxShadow: '0 4px 10px rgba(0,0,0,0.08)',
                        }}>
                        <div className="p-2 d-flex justify-content-between align-items-center">
                          <span style={{ fontSize: 12, color: '#6c757d' }}>{isSearchingSuggestions ? 'Searching…' : 'Top matches'}</span>
                          {isSearchingSuggestions && <Spinner size="sm" />}
                        </div>
                        <ListGroup variant="flush">
                          {(productSuggestions || []).length > 0 ? (
                            productSuggestions.map((s) => (
                              <ListGroup.Item action key={s.product_id} onClick={() => handlePickSuggestion(s)}>
                                <div className="d-flex justify-content-between">
                                  <span>{s.title}</span>
                                  <span style={{ color: '#6c757d' }}>#{s.product_id}</span>
                                </div>
                              </ListGroup.Item>
                            ))
                          ) : (
                            <ListGroup.Item disabled>No matches</ListGroup.Item>
                          )}
                        </ListGroup>
                      </div>
                    )}
                  </div>
                </Col>

                {/* original branch select + buttons */}
                <Col md={4}>
                  <Form.Label>Select Branch</Form.Label>
                  <Form.Select value={selectedOutletId} onChange={(e) => setSelectedOutletId(e.target.value)} disabled={outletLoading}>
                    <option value="all">All Branches</option>
                    {outletOptions.map((outlet) => (
                      <option key={outlet.outlet_id} value={outlet.outlet_id}>
                        {outlet.name}
                      </option>
                    ))}
                  </Form.Select>
                </Col>

                <Col md={3} className="d-flex align-items-end">
                  <div className="no-print d-flex align-items-end">
                    <Button
                      type="button"
                      className="btn bg-primary border border-primary me-2"
                      onClick={handleSearchClick}
                      disabled={!selectedOutletId}>
                      Search
                    </Button>

                    {/* <Button variant="secondary" onClick={handlePrint} style={{ backgroundColor: '#6f42c1', borderColor: '#6f42c1' }}>
                      Print
                    </Button> */}
                  </div>
                </Col>
              </Row>
            </Form>

            <h5>Stock Summary</h5>
            <hr className="my-3" />

            <Table bordered hover responsive>
              <thead style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
                <tr>
                  <th className="text-center">Product/Variant ID</th>
                  <th className="text-center">Product</th>
                  <th className="text-center">Product Variant</th>
                  <th className="text-center">Category</th>
                  <th className="text-center">Outlet</th>
                  <th className="text-center">Status</th>
                  <th className="text-center">Total Stock In</th>
                  <th className="text-center">Total Stock Out</th>
                  <th className="text-center">Current Stock</th>
                </tr>
              </thead>

              <tbody>
                {allProducts.length > 0 ? (
                  paginatedProducts.map((product) => {
                    const isExpanded = expandedProducts[product.product_id]
                    return (
                      <React.Fragment key={product.product_id}>
                        <tr
                          style={{ backgroundColor: '#f8f9fa', cursor: 'pointer' }}
                          onClick={() =>
                            setExpandedProducts((prev) => ({
                              ...prev,
                              [product.product_id]: !prev[product.product_id],
                            }))
                          }>
                          <td colSpan="9" className="fw-bold text-primary">
                            <span style={{ marginRight: '10px' }}>{isExpanded ? '▼' : '►'}</span>
                            {product.title}
                          </td>
                        </tr>

                        {isExpanded &&
                          [...new Map(product.variants.map((v) => [v.variant_id, v])).values()].map((variant) => (
                            <tr
                              key={variant.variant_id}
                              className={
                                variant.stock_status === 'out of stock'
                                  ? 'table-danger'
                                  : variant.stock_status === 'reorder_level_reached'
                                    ? 'table-warning'
                                    : variant.stock_status === 'low_stock'
                                      ? 'table-info'
                                      : variant.stock_status === 'in stock'
                                        ? 'table-success'
                                        : ''
                              }>
                              <td>{variant.variant_id}</td>
                              <td>
                                <center>
                                  <img
                                    src={product.media_url ? product.media_url : '/package.png'}
                                    alt={product.title}
                                    onError={(e) => {
                                      if (e.target.src !== window.location.origin + '/package.png') {
                                        e.target.onerror = null
                                        e.target.src = '/package.png'
                                        e.target.style.width = '40px'
                                        e.target.style.height = '40px'
                                      }
                                    }}
                                    style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '4px' }}
                                  />
                                </center>
                              </td>
                              <td className="text-center">{variant.variant_value}</td>
                              <td className="text-center">{product.category_name || 'N/A'}</td>
                              <td className="text-center">{variant.outlet_name}</td>
                              <td className="text-center">{getStatusBadge(variant.stock_status)}</td>
                              <td className="text-center">{variant.stock_in}</td>
                              <td className="text-center">{variant.stock_out}</td>
                              <td>
                                {variant.current_stock}
                                {variant.measurement_value && (
                                  <span style={{ fontWeight: 'normal', color: 'inherit', fontSize: 'inherit' }}> ({variant.measurement_value})</span>
                                )}
                              </td>
                            </tr>
                          ))}
                      </React.Fragment>
                    )
                  })
                ) : (
                  <tr>
                    <td colSpan="9" className="text-center text-muted">
                      {searchedOutletId === null ? 'Choose a branch and click Search.' : 'No results found for this outlet / search.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </div>
        </CardBody>

        {/* ================= PAGINATION ================= */}
        {totalPages > 1 && (
          <div className="d-flex justify-content-end mt-1">
            <Pagination>
              {(() => {
                const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                const pages = []

                let start = safeCurrent - 2
                let end = safeCurrent + 2

                if (totalPages <= 5) {
                  start = 1
                  end = totalPages
                } else {
                  if (start < 1) {
                    start = 1
                    end = 5
                  }
                  if (end > totalPages) {
                    end = totalPages
                    start = totalPages - 4
                  }
                }

                for (let i = start; i <= end; i++) {
                  pages.push(
                    <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setCurrentPage(i)}>
                      {i}
                    </Pagination.Item>,
                  )
                }

                return (
                  <>
                    {/* FIRST */}
                    <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(1)}>
                      First
                    </Pagination.Item>

                    {/* PREV (<) */}
                    <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(safeCurrent - 1)}>
                      {'<'}
                    </Pagination.Item>

                    {pages}

                    {/* NEXT (>) */}
                    <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(safeCurrent + 1)}>
                      {'>'}
                    </Pagination.Item>

                    {/* LAST */}
                    <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(totalPages)}>
                      Last
                    </Pagination.Item>
                  </>
                )
              })()}
            </Pagination>
          </div>
        )}
      </Card>
    </div>
  )
}

export default InventoryStatus
