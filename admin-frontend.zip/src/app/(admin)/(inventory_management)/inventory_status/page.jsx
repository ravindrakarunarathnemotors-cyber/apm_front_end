import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Inventory Status',
}

const InventoryStatus = dynamic(() => import('./InventoryStatus'), { ssr: false })

export default function InventoryStatusPage() {
  return <InventoryStatus />
}