'use client'
import { useState, useMemo } from 'react'
import { Table, Button, Form, Toast, ToastContainer, Pagination, Row, Col, InputGroup } from 'react-bootstrap'
// import { useGetNewProductsQuery, useUpdateVariantMutation } from '@/store/features/apiSlice'

const sampleProducts = [
  {
    product_id: 101,
    title: 'Black T-Shirt',
    created_at: '2025-06-20',
    variants: [
      { variant_id: 50001, variant_value: 'S', sku: '', barcode: '', reorder_level: 5 },
      { variant_id: 50002, variant_value: 'M', sku: '', barcode: '', reorder_level: 10 }
    ]
  },
  {
    product_id: 102,
    title: 'Blue Jeans',
    created_at: '2025-06-21',
    variants: [
      { variant_id: 50003, variant_value: '32', sku: 'BJ-32', barcode: '789123', reorder_level: 8 },
      { variant_id: 50004, variant_value: '34', sku: 'BJ-34', barcode: '789124', reorder_level: 6 }
    ]
  },
  {
    product_id: 103,
    title: 'Red Cap',
    created_at: '2025-06-22',
    variants: []
  },
  {
    product_id: 104,
    title: 'Green Hoodie',
    created_at: '2025-06-23',
    variants: [
      { variant_id: 50005, variant_value: 'L', sku: '', barcode: '', reorder_level: 7 }
    ]
  },
  {
    product_id: 105,
    title: 'White Sneakers',
    created_at: '2025-06-24',
    variants: [
      { variant_id: 50006, variant_value: '9', sku: '', barcode: '', reorder_level: 4 }
    ]
  },
  {
    product_id: 106,
    title: 'Gray Shorts',
    created_at: '2025-06-25',
    variants: [
      { variant_id: 50007, variant_value: 'XL', sku: '', barcode: '', reorder_level: 6 }
    ]
  }
]

const NewOnboardingTable = () => {
  // const { data: products, isLoading } = useGetNewProductsQuery()
  const products = sampleProducts
  const isLoading = false

  const [editingId, setEditingId] = useState(null)
  const [formState, setFormState] = useState({})
  // const [updateVariant] = useUpdateVariantMutation()

  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [toastMsg, setToastMsg] = useState('')
  const [showToast, setShowToast] = useState(false)

  const itemsPerPage = 5

  const filtered = useMemo(() => {
    return products.filter(p =>
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.product_id.toString().includes(searchTerm)
    )
  }, [searchTerm, products])

  const paginated = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage
    return filtered.slice(start, start + itemsPerPage)
  }, [currentPage, filtered])

  const totalPages = Math.ceil(filtered.length / itemsPerPage)

  const handleEdit = (variantId, existingData) => {
    setEditingId(variantId)
    setFormState(existingData)
  }

  const handleChange = (field, value) => {
    setFormState(prev => ({ ...prev, [field]: value }))
  }

  const handleSave = async (variantId) => {
    // await updateVariant({ variant_id: variantId, ...formState })
    console.log('Saving variant:', variantId, formState)
    setEditingId(null)
    setToastMsg(`✅ Variant ${variantId} updated successfully`)
    setShowToast(true)
  }

  if (isLoading) return <p>Loading...</p>

  return (
    <>
      <Row className="mb-3">
        <Col md={4}>
          <InputGroup>
            <InputGroup.Text>🔍</InputGroup.Text>
            <Form.Control
              type="text"
              placeholder="Search by Product ID or Name"
              onChange={(e) => {
                setSearchTerm(e.target.value)
                setCurrentPage(1)
              }}
            />
          </InputGroup>
        </Col>
      </Row>

      <div className="table-responsive">
        <Table bordered hover>
          <thead className="table-light">
            <tr>
              <th>Product ID</th>
              <th>Product Name</th>
              <th>Variant</th>
              <th>SKU</th>
              <th>Barcode</th>
              <th>Reorder Level</th>
              <th>Added Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {paginated.map(product => (
              product.variants.length > 0 ? (
                product.variants.map(variant => (
                  <tr key={variant.variant_id}>
                    <td>{product.product_id}</td>
                    <td>{product.title}</td>
                    <td>{variant.variant_value || '-'}</td>
                    <td>
                      <Form.Control
                        size="sm"
                        disabled={editingId !== variant.variant_id}
                        value={editingId === variant.variant_id ? formState.sku : variant.sku || ''}
                        onChange={e => handleChange('sku', e.target.value)}
                      />
                    </td>
                    <td>
                      <Form.Control
                        size="sm"
                        disabled={editingId !== variant.variant_id}
                        value={editingId === variant.variant_id ? formState.barcode : variant.barcode || ''}
                        onChange={e => handleChange('barcode', e.target.value)}
                      />
                    </td>
                    <td>
                      <Form.Control
                        type="number"
                        size="sm"
                        disabled={editingId !== variant.variant_id}
                        value={editingId === variant.variant_id ? formState.reorder_level : variant.reorder_level || ''}
                        onChange={e => handleChange('reorder_level', e.target.value)}
                      />
                    </td>
                    <td>{new Date(product.created_at).toISOString().split('T')[0]}</td>
                    <td>
                      {editingId === variant.variant_id ? (
                        <Button size="sm" onClick={() => handleSave(variant.variant_id)}>Update</Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline-primary"
                          onClick={() =>
                            handleEdit(variant.variant_id, {
                              sku: variant.sku || '',
                              barcode: variant.barcode || '',
                              reorder_level: variant.reorder_level || '',
                            })
                          }
                        >
                          ✏️ Edit
                        </Button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr key={product.product_id}>
                  <td>{product.product_id}</td>
                  <td>{product.title}</td>
                  <td>–</td>
                  <td colSpan={3}>No variants available</td>
                  <td>{new Date(product.created_at).toISOString().split('T')[0]}</td>
                  <td>–</td>
                </tr>
              )
            ))}
          </tbody>
        </Table>

        <Pagination>
          {[...Array(totalPages)].map((_, idx) => (
            <Pagination.Item
              key={idx + 1}
              active={currentPage === idx + 1}
              onClick={() => setCurrentPage(idx + 1)}
            >
              {idx + 1}
            </Pagination.Item>
          ))}
        </Pagination>
      </div>

      <ToastContainer position="top-end" className="p-3">
        <Toast
          bg="success"
          onClose={() => setShowToast(false)}
          show={showToast}
          delay={2000}
          autohide
        >
          <Toast.Body className="text-white">{toastMsg}</Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  )
}

export default NewOnboardingTable
