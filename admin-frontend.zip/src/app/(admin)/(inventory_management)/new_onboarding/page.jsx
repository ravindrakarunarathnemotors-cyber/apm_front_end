import dynamic from 'next/dynamic'

export const metadata = {
  title: 'New Onboarding',
}

const NewOnboarding = dynamic(() => import('./NewOnboardingTable'), { ssr: false })

export default function NewOnboardingPage() {
  return <NewOnboarding />
}