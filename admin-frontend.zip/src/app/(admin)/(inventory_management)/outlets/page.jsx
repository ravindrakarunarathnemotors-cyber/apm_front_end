import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Outlet',
}

const AddOutlet = dynamic(() => import('./components/AddOutlet'), { ssr: false })
const Outlet = dynamic(() => import('./Outlet'), { ssr: false })

export default function OutletPage() {
  return (
    <div className="container mt-4">
      <AddOutlet />
      <Outlet />
    </div>
  )
}