'use client'

import { Card, Col, Row, Spinner, Alert, Form, CardHeader, CardBody } from 'react-bootstrap'
import { useGetOutletsQuery, useToggleOutletStatusMutation, useUpdateOutletMutation } from '@/store/features/apiSlice'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import { useState } from 'react'

const Field = ({ label, children }) => (
  <Form.Group className="mb-2">
    <Form.Label className="edit-field-label">{label}</Form.Label>
    {children}
  </Form.Group>
)

const Outlet = () => {
  const { data, isLoading, isError, refetch } = useGetOutletsQuery()
  const [toggleOutletStatus, { isLoading: isToggling }] = useToggleOutletStatusMutation()
  const [updateOutlet, { isLoading: isUpdating }] = useUpdateOutletMutation()

  const outlets = data?.outlets || []
  const activeOutlets = outlets.filter((o) => o.is_active)
  const inactiveOutlets = outlets.filter((o) => !o.is_active)

  const [editingId, setEditingId] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    email: '',
    hotline: '',
    tel_number: '',
    geocode: '',
    opening_hours_from: '',
    opening_hours_to: '',
  })

  const startEdit = (outlet) => {
    setEditingId(outlet.outlet_id)
    setFormData({
      name: outlet.name ?? '',
      address: outlet.address ?? '',
      email: outlet.email ?? '',
      hotline: outlet.hotline ?? '',
      tel_number: outlet.tel_number ?? '',
      geocode: outlet.geocode ?? '',
      opening_hours_from: outlet.opening_hours_from ?? '',
      opening_hours_to: outlet.opening_hours_to ?? '',
    })
  }

  const cancelEdit = () => setEditingId(null)
  const onChange = (field, value) => setFormData((prev) => ({ ...prev, [field]: value }))

  const handleToggleStatus = async (outlet) => {
    const newStatus = !outlet.is_active
    const confirmResult = await Swal.fire({
      title: `${newStatus ? 'Activate' : 'Deactivate'} Outlet?`,
      text: `"${outlet.name}" will be ${newStatus ? 'activated' : 'deactivated'}.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: newStatus ? '#16a34a' : '#dc2626',
      cancelButtonColor: '#6c757d',
      confirmButtonText: `Yes, ${newStatus ? 'activate' : 'deactivate'}`,
      reverseButtons: true,
    })
    if (!confirmResult.isConfirmed) return
    try {
      const response = await toggleOutletStatus({ outlet_id: outlet.outlet_id, is_active: newStatus, user_id: 1 }).unwrap()
      await refetch()
      Swal.fire({
        title: 'Updated',
        text: response.message || 'Status updated.',
        icon: 'success',
        timer: 2000,
        timerProgressBar: true,
        showConfirmButton: false,
      })
    } catch (err) {
      Swal.fire({ title: 'Error', text: err?.data?.error || 'Failed to update status.', icon: 'error', confirmButtonColor: '#dc3545' })
    }
  }

  const handleUpdate = async (outlet) => {
    const result = await Swal.fire({
      title: '<span style="font-size:1.05rem;font-weight:700">Save Changes?</span>',
      html: `
        <div style="text-align:left;font-size:0.875rem;line-height:2">
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="color:#6c757d;width:38%;padding:3px 0">Outlet Name</td><td style="font-weight:600;color:#212529">${formData.name}</td></tr>
            <tr><td style="color:#6c757d;padding:3px 0">Address</td><td style="color:#212529">${formData.address || '—'}</td></tr>
            <tr><td style="color:#6c757d;padding:3px 0">Email</td><td style="color:#212529">${formData.email || '—'}</td></tr>
            <tr><td style="color:#6c757d;padding:3px 0">Hotline</td><td style="color:#212529">${formData.hotline || '—'}</td></tr>
            <tr><td style="color:#6c757d;padding:3px 0">Opening Hours</td><td style="color:#212529">${formData.opening_hours_from} — ${formData.opening_hours_to}</td></tr>
          </table>
        </div>`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Save Changes',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#0d6efd',
      cancelButtonColor: '#6c757d',
      reverseButtons: true,
    })
    if (!result.isConfirmed) return
    try {
      await updateOutlet({ outlet_id: outlet.outlet_id, ...formData, user_id: 1 }).unwrap()
      await refetch()
      Swal.fire({
        title: 'Updated!',
        text: 'Outlet updated successfully.',
        icon: 'success',
        timer: 1800,
        timerProgressBar: true,
        showConfirmButton: false,
      })
      setEditingId(null)
    } catch (err) {
      Swal.fire({ title: 'Error', text: err?.data?.error || 'Failed to update outlet.', icon: 'error', confirmButtonColor: '#dc3545' })
    }
  }

  const renderCard = (outlet) => {
    const isEditing = editingId === outlet.outlet_id
    return (
      <Col key={outlet.outlet_id}>
        <Card className="h-100 border-0 outlet-card" style={{ borderRadius: 10 }}>
          {/* ── CARD TOP BAR ── */}
          <div className={`outlet-topbar ${outlet.is_active ? 'topbar-active' : 'topbar-inactive'}`}>
            <div className="d-flex align-items-center gap-2">
              <IconifyIcon icon="mdi:store" style={{ fontSize: 15 }} />
              <span className="outlet-topbar-name">
                {isEditing ? (
                  <Form.Control
                    size="sm"
                    value={formData.name}
                    onChange={(e) => onChange('name', e.target.value)}
                    className="outlet-name-input"
                    placeholder="Outlet name"
                  />
                ) : (
                  outlet.name
                )}
              </span>
              <span className="outlet-id-chip">#{outlet.outlet_id}</span>
            </div>

            <div className="d-flex align-items-center gap-1">
              {isEditing ? (
                <>
                  <button className="tbar-btn tbar-save" disabled={isUpdating} onClick={() => handleUpdate(outlet)}>
                    <IconifyIcon icon="mdi:content-save-outline" />
                    {isUpdating ? 'Saving...' : 'Save'}
                  </button>
                  <button className="tbar-btn tbar-cancel" disabled={isUpdating} onClick={cancelEdit}>
                    <IconifyIcon icon="mdi:close" />
                    Cancel
                  </button>
                </>
              ) : (
                <>
                  <button className="tbar-btn tbar-edit" onClick={() => startEdit(outlet)}>
                    <IconifyIcon icon="mdi:pencil-outline" />
                    Edit
                  </button>
                  <button
                    className={`tbar-btn ${outlet.is_active ? 'tbar-deactivate' : 'tbar-activate'}`}
                    disabled={isToggling}
                    onClick={() => handleToggleStatus(outlet)}>
                    <IconifyIcon icon={outlet.is_active ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'} />
                    {outlet.is_active ? 'Active' : 'Inactive'}
                  </button>
                </>
              )}
            </div>
          </div>

          <CardBody className="p-0">
            {isEditing ? (
              /* ── EDIT MODE ── */
              <div className="p-3">
                <Field label="Address">
                  <Form.Control
                    as="textarea"
                    rows={2}
                    value={formData.address}
                    onChange={(e) => onChange('address', e.target.value)}
                    className="outlet-input"
                  />
                </Field>
                <Row className="g-2">
                  <Col md={6}>
                    <Field label="Email">
                      <Form.Control
                        type="email"
                        value={formData.email}
                        onChange={(e) => onChange('email', e.target.value)}
                        className="outlet-input"
                      />
                    </Field>
                  </Col>
                  <Col md={6}>
                    <Field label="Hotline">
                      <Form.Control value={formData.hotline} onChange={(e) => onChange('hotline', e.target.value)} className="outlet-input" />
                    </Field>
                  </Col>
                </Row>
                <Row className="g-2">
                  <Col md={6}>
                    <Field label="Telephone">
                      <Form.Control value={formData.tel_number} onChange={(e) => onChange('tel_number', e.target.value)} className="outlet-input" />
                    </Field>
                  </Col>
                  <Col md={6}>
                    <Field label="Geocode">
                      <Form.Control value={formData.geocode} onChange={(e) => onChange('geocode', e.target.value)} className="outlet-input" />
                    </Field>
                  </Col>
                </Row>
                <Row className="g-2">
                  <Col md={6}>
                    <Field label="Open From">
                      <Form.Control
                        type="time"
                        value={formData.opening_hours_from}
                        onChange={(e) => onChange('opening_hours_from', e.target.value)}
                        className="outlet-input"
                      />
                    </Field>
                  </Col>
                  <Col md={6}>
                    <Field label="Open To">
                      <Form.Control
                        type="time"
                        value={formData.opening_hours_to}
                        onChange={(e) => onChange('opening_hours_to', e.target.value)}
                        className="outlet-input"
                      />
                    </Field>
                  </Col>
                </Row>
              </div>
            ) : (
              /* ── VIEW MODE ── */
              <div className="outlet-details">
                <div className="detail-block detail-full">
                  <div className="detail-icon-wrap">
                    <IconifyIcon icon="mdi:map-marker-outline" />
                  </div>
                  <div>
                    <div className="detail-label">Address</div>
                    <div className="detail-value">{outlet.address || '—'}</div>
                  </div>
                </div>

                <div className="detail-divider" />

                <div className="detail-grid">
                  <div className="detail-block">
                    <div className="detail-icon-wrap">
                      <IconifyIcon icon="mdi:email-outline" />
                    </div>
                    <div>
                      <div className="detail-label">Email</div>
                      <div className="detail-value">{outlet.email || '—'}</div>
                    </div>
                  </div>
                  <div className="detail-block">
                    <div className="detail-icon-wrap">
                      <IconifyIcon icon="mdi:phone-outline" />
                    </div>
                    <div>
                      <div className="detail-label">Hotline</div>
                      <div className="detail-value">{outlet.hotline || '—'}</div>
                    </div>
                  </div>
                  <div className="detail-block">
                    <div className="detail-icon-wrap">
                      <IconifyIcon icon="mdi:phone-classic" />
                    </div>
                    <div>
                      <div className="detail-label">Telephone</div>
                      <div className="detail-value">{outlet.tel_number || '—'}</div>
                    </div>
                  </div>
                  <div className="detail-block">
                    <div className="detail-icon-wrap">
                      <IconifyIcon icon="mdi:map-outline" />
                    </div>
                    <div>
                      <div className="detail-label">Geocode</div>
                      <div className="detail-value">{outlet.geocode || '—'}</div>
                    </div>
                  </div>
                </div>

                <div className="detail-divider" />

                <div className="detail-block detail-full" style={{ paddingBottom: 12 }}>
                  <div className="detail-icon-wrap">
                    <IconifyIcon icon="mdi:clock-outline" />
                  </div>
                  <div className="d-flex align-items-center gap-3">
                    <div>
                      <div className="detail-label">Opens</div>
                      <div className="detail-value hours-value">{outlet.opening_hours_from || '—'}</div>
                    </div>
                    <IconifyIcon icon="mdi:arrow-right" style={{ color: '#9ca3af', fontSize: 14, marginTop: 10 }} />
                    <div>
                      <div className="detail-label">Closes</div>
                      <div className="detail-value hours-value">{outlet.opening_hours_to || '—'}</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ── FOOTER ── */}
            <div className="outlet-footer">
              <span>
                <IconifyIcon icon="mdi:calendar-plus-outline" className="me-1" />
                Created {new Date(outlet.created_at).toLocaleDateString()}
              </span>
              <span>
                <IconifyIcon icon="mdi:calendar-edit" className="me-1" />
                Updated {new Date(outlet.updated_at).toLocaleDateString()}
              </span>
            </div>
          </CardBody>
        </Card>
      </Col>
    )
  }

  if (isLoading)
    return (
      <div className="d-flex justify-content-center align-items-center py-5 gap-2">
        <Spinner animation="border" variant="primary" size="sm" />
        <span className="text-muted" style={{ fontSize: '0.85rem' }}>
          Loading outlets...
        </span>
      </div>
    )

  if (isError)
    return (
      <Alert variant="danger" className="mt-4">
        Failed to load outlets.
      </Alert>
    )

  if (outlets.length === 0)
    return (
      <Alert variant="info" className="mt-4">
        No outlets found.
      </Alert>
    )

  return (
    <>
      <Card className="border-0 shadow-sm mt-4" style={{ borderRadius: 12 }}>
        <CardHeader
          className="d-flex align-items-center justify-content-between px-4 py-3"
          style={{ background: '#f8f9fa', borderRadius: '12px 12px 0 0', borderBottom: '1px solid #e9ecef' }}>
          <div className="d-flex align-items-center gap-2">
            <IconifyIcon icon="mdi:store-outline" style={{ fontSize: 20, color: '#0d6efd' }} />
            <h5 className="mb-0 fw-semibold" style={{ fontSize: '0.95rem' }}>
              Outlet List
            </h5>
          </div>
          <span className="text-muted" style={{ fontSize: '0.78rem' }}>
            {outlets.length} outlet{outlets.length !== 1 ? 's' : ''}
          </span>
        </CardHeader>

        <CardBody className="px-4 py-4">
          {/* ── ACTIVE OUTLETS ── */}
          {activeOutlets.length > 0 && (
            <>
              <div className="section-divider mb-4">
                <div className="section-divider-line" />
                <div className="section-divider-pill" style={{ color: '#023075', borderColor: '#c7d7f0', background: '#eef2fb' }}>
                  <span className="section-divider-dot" style={{ background: '#023075' }} />
                  Active
                  <span className="section-divider-count" style={{ color: '#023075', background: '#dce7f7' }}>
                    {activeOutlets.length}
                  </span>
                </div>
                <div className="section-divider-line" />
              </div>
              <Row xs={1} md={2} className="g-4">
                {activeOutlets.map((outlet) => renderCard(outlet))}
              </Row>
            </>
          )}

          {/* ── SECTION DIVIDER ── */}
          {activeOutlets.length > 0 && inactiveOutlets.length > 0 && (
            <div className="section-divider my-4">
              <div className="section-divider-line" />
              <div className="section-divider-pill" style={{ color: '#023075', borderColor: '#c7d7f0', background: '#eef2fb' }}>
                <span className="section-divider-dot" style={{ background: '#023075' }} />
                Inactive
                <span className="section-divider-count" style={{ color: '#023075', background: '#dce7f7' }}>
                  {inactiveOutlets.length}
                </span>
              </div>
              <div className="section-divider-line" />
            </div>
          )}

          {/* ── INACTIVE OUTLETS ── */}
          {/* ── INACTIVE OUTLETS ── */}
          {inactiveOutlets.length > 0 && (
            <>
              {activeOutlets.length === 0 && (
                <div className="section-divider mb-4">
                  <div className="section-divider-line" />
                  <div className="section-divider-pill" style={{ color: '#023075', borderColor: '#c7d7f0', background: '#eef2fb' }}>
                    <span className="section-divider-dot" style={{ background: '#023075' }} />
                    Inactive
                    <span className="section-divider-count" style={{ color: '#023075', background: '#dce7f7' }}>
                      {inactiveOutlets.length}
                    </span>
                  </div>
                  <div className="section-divider-line" />
                </div>
              )}
              <Row xs={1} md={2} className="g-4">
                {inactiveOutlets.map((outlet) => (
                  <Col key={outlet.outlet_id} className="inactive-col">
                    <Card className="h-100 border-0 outlet-card" style={{ borderRadius: 10 }}>
                      {/* ── CARD TOP BAR ── */}
                      <div className="outlet-topbar topbar-inactive">
                        <div className="d-flex align-items-center gap-2">
                          <IconifyIcon icon="mdi:store" style={{ fontSize: 15 }} />
                          <span className="outlet-topbar-name">
                            {editingId === outlet.outlet_id ? (
                              <Form.Control
                                size="sm"
                                value={formData.name}
                                onChange={(e) => onChange('name', e.target.value)}
                                className="outlet-name-input"
                                placeholder="Outlet name"
                              />
                            ) : (
                              outlet.name
                            )}
                          </span>
                          <span className="outlet-id-chip">#{outlet.outlet_id}</span>
                        </div>

                        <div className="d-flex align-items-center gap-1">
                          {editingId === outlet.outlet_id ? (
                            <>
                              <button className="tbar-btn tbar-save" disabled={isUpdating} onClick={() => handleUpdate(outlet)}>
                                <IconifyIcon icon="mdi:content-save-outline" />
                                {isUpdating ? 'Saving...' : 'Save'}
                              </button>
                              <button className="tbar-btn tbar-cancel" disabled={isUpdating} onClick={cancelEdit}>
                                <IconifyIcon icon="mdi:close" />
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button className="tbar-btn tbar-edit" onClick={() => startEdit(outlet)}>
                                <IconifyIcon icon="mdi:pencil-outline" />
                                Edit
                              </button>
                              <button className="tbar-btn tbar-activate" disabled={isToggling} onClick={() => handleToggleStatus(outlet)}>
                                <IconifyIcon icon="mdi:toggle-switch-off" />
                                Inactive
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      <CardBody className="p-0">
                        {editingId === outlet.outlet_id ? (
                          /* ── EDIT MODE ── */
                          <div className="p-3">
                            <Field label="Address">
                              <Form.Control
                                as="textarea"
                                rows={2}
                                value={formData.address}
                                onChange={(e) => onChange('address', e.target.value)}
                                className="outlet-input"
                              />
                            </Field>
                            <Row className="g-2">
                              <Col md={6}>
                                <Field label="Email">
                                  <Form.Control
                                    type="email"
                                    value={formData.email}
                                    onChange={(e) => onChange('email', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                              <Col md={6}>
                                <Field label="Hotline">
                                  <Form.Control
                                    value={formData.hotline}
                                    onChange={(e) => onChange('hotline', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                            </Row>
                            <Row className="g-2">
                              <Col md={6}>
                                <Field label="Telephone">
                                  <Form.Control
                                    value={formData.tel_number}
                                    onChange={(e) => onChange('tel_number', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                              <Col md={6}>
                                <Field label="Geocode">
                                  <Form.Control
                                    value={formData.geocode}
                                    onChange={(e) => onChange('geocode', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                            </Row>
                            <Row className="g-2">
                              <Col md={6}>
                                <Field label="Open From">
                                  <Form.Control
                                    type="time"
                                    value={formData.opening_hours_from}
                                    onChange={(e) => onChange('opening_hours_from', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                              <Col md={6}>
                                <Field label="Open To">
                                  <Form.Control
                                    type="time"
                                    value={formData.opening_hours_to}
                                    onChange={(e) => onChange('opening_hours_to', e.target.value)}
                                    className="outlet-input"
                                  />
                                </Field>
                              </Col>
                            </Row>
                          </div>
                        ) : (
                          /* ── VIEW MODE ── */
                          <div className="outlet-details">
                            <div className="detail-block detail-full">
                              <div className="detail-icon-wrap inactive-icon">
                                <IconifyIcon icon="mdi:map-marker-outline" />
                              </div>
                              <div>
                                <div className="detail-label">Address</div>
                                <div className="detail-value">{outlet.address || '—'}</div>
                              </div>
                            </div>

                            <div className="detail-divider" />

                            <div className="detail-grid">
                              <div className="detail-block">
                                <div className="detail-icon-wrap inactive-icon">
                                  <IconifyIcon icon="mdi:email-outline" />
                                </div>
                                <div>
                                  <div className="detail-label">Email</div>
                                  <div className="detail-value">{outlet.email || '—'}</div>
                                </div>
                              </div>
                              <div className="detail-block">
                                <div className="detail-icon-wrap inactive-icon">
                                  <IconifyIcon icon="mdi:phone-outline" />
                                </div>
                                <div>
                                  <div className="detail-label">Hotline</div>
                                  <div className="detail-value">{outlet.hotline || '—'}</div>
                                </div>
                              </div>
                              <div className="detail-block">
                                <div className="detail-icon-wrap inactive-icon">
                                  <IconifyIcon icon="mdi:phone-classic" />
                                </div>
                                <div>
                                  <div className="detail-label">Telephone</div>
                                  <div className="detail-value">{outlet.tel_number || '—'}</div>
                                </div>
                              </div>
                              <div className="detail-block">
                                <div className="detail-icon-wrap inactive-icon">
                                  <IconifyIcon icon="mdi:map-outline" />
                                </div>
                                <div>
                                  <div className="detail-label">Geocode</div>
                                  <div className="detail-value">{outlet.geocode || '—'}</div>
                                </div>
                              </div>
                            </div>

                            <div className="detail-divider" />

                            <div className="detail-block detail-full" style={{ paddingBottom: 12 }}>
                              <div className="detail-icon-wrap inactive-icon">
                                <IconifyIcon icon="mdi:clock-outline" />
                              </div>
                              <div className="d-flex align-items-center gap-3">
                                <div>
                                  <div className="detail-label">Opens</div>
                                  <div className="detail-value hours-value inactive-hours">{outlet.opening_hours_from || '—'}</div>
                                </div>
                                <IconifyIcon icon="mdi:arrow-right" style={{ color: '#9ca3af', fontSize: 14, marginTop: 10 }} />
                                <div>
                                  <div className="detail-label">Closes</div>
                                  <div className="detail-value hours-value inactive-hours">{outlet.opening_hours_to || '—'}</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* ── FOOTER ── */}
                        <div className="outlet-footer">
                          <span>
                            <IconifyIcon icon="mdi:calendar-plus-outline" className="me-1" />
                            Created {new Date(outlet.created_at).toLocaleDateString()}
                          </span>
                          <span>
                            <IconifyIcon icon="mdi:calendar-edit" className="me-1" />
                            Updated {new Date(outlet.updated_at).toLocaleDateString()}
                          </span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                ))}
              </Row>
            </>
          )}
        </CardBody>
      </Card>

      <style jsx global>{`
        .outlet-card {
          box-shadow: 0 2px 12px rgba(0, 0, 0, 0.07) !important;
          transition:
            box-shadow 0.18s ease,
            transform 0.18s ease;
          overflow: hidden;
        }
        .outlet-card:hover {
          box-shadow: 0 6px 24px rgba(0, 0, 0, 0.11) !important;
          transform: translateY(-2px);
        }

        /* INACTIVE COL FADE */
        .inactive-col {
          opacity: 0.72;
          transition: opacity 0.2s ease;
        }
        .inactive-col:hover {
          opacity: 1;
        }

        /* TOP BAR */
        .outlet-topbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
          gap: 8px;
        }
        .topbar-active {
          background: #023075;
          color: #fff;
        }
        .topbar-inactive {
          background: #464849;
          color: #fff;
        }

        .outlet-topbar-name {
          font-weight: 700;
          font-size: 0.88rem;
          letter-spacing: 0.01em;
        }
        .outlet-id-chip {
          font-size: 0.65rem;
          background: rgba(255, 255, 255, 0.22);
          border-radius: 999px;
          padding: 1px 7px;
          font-weight: 600;
        }
        .outlet-name-input {
          font-size: 0.82rem;
          font-weight: 700;
          border-radius: 6px;
          border: 1.5px solid rgba(255, 255, 255, 0.5);
          background: rgba(255, 255, 255, 0.15);
          color: #fff;
          max-width: 180px;
          padding: 2px 8px;
        }
        .outlet-name-input::placeholder {
          color: rgba(255, 255, 255, 0.6);
        }
        .outlet-name-input:focus {
          outline: none;
          box-shadow: none;
          border-color: #fff;
          background: rgba(255, 255, 255, 0.25);
        }

        /* TOP BAR BUTTONS */
        .tbar-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 3px 10px;
          font-size: 0.68rem;
          font-weight: 700;
          border-radius: 999px;
          border: 1.5px solid transparent;
          cursor: pointer;
          transition: opacity 0.15s;
          white-space: nowrap;
        }
        .tbar-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .tbar-btn:hover:not(:disabled) {
          opacity: 0.82;
        }
        .tbar-edit {
          background: rgba(255, 255, 255, 0.2);
          color: #fff;
          border-color: rgba(255, 255, 255, 0.4);
        }
        .tbar-save {
          background: #fff;
          color: #0d6efd;
        }
        .tbar-cancel {
          background: rgba(255, 255, 255, 0.15);
          color: #fff;
          border-color: rgba(255, 255, 255, 0.3);
        }
        .tbar-activate {
          background: #dcfce7;
          color: #16a34a;
        }
        .tbar-deactivate {
          background: rgba(255, 255, 255, 0.18);
          color: #fff;
          border-color: rgba(255, 255, 255, 0.35);
        }

        /* DETAILS */
        .outlet-details {
          padding: 14px 16px 0;
        }
        .detail-block {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          padding: 6px 0;
        }
        .detail-full {
          width: 100%;
        }
        .detail-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 2px 16px;
          padding: 4px 0;
        }
        .detail-icon-wrap {
          width: 28px;
          height: 28px;
          border-radius: 7px;
          background: #eff6ff;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          font-size: 14px;
          color: #023075;
          margin-top: 2px;
        }
        .inactive-icon {
          background: #f3f4f6;
          color: #9ca3af;
        }
        .detail-label {
          font-size: 0.68rem;
          font-weight: 600;
          color: #9ca3af;
          text-transform: uppercase;
          letter-spacing: 0.04em;
          line-height: 1.2;
        }
        .detail-value {
          font-size: 0.82rem;
          color: #1f2937;
          font-weight: 500;
          line-height: 1.4;
          margin-top: 1px;
          word-break: break-word;
        }
        .hours-value {
          font-size: 0.9rem;
          font-weight: 700;
          color: #023075;
        }
        .inactive-hours {
          color: #9ca3af !important;
        }
        .detail-divider {
          height: 1px;
          background: #f3f4f6;
          margin: 6px 0;
        }

        /* EDIT INPUTS */
        .edit-field-label {
          font-size: 0.75rem;
          font-weight: 600;
          color: #6c757d;
          margin-bottom: 3px;
        }
        .outlet-input {
          font-size: 0.82rem;
          border-radius: 7px;
          border: 1px solid #dee2e6;
        }
        .outlet-input:focus {
          border-color: #0d6efd;
          box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }

        /* FOOTER */
        .outlet-footer {
          display: flex;
          justify-content: space-between;
          font-size: 0.68rem;
          color: #9ca3af;
          border-top: 1px solid #f3f4f6;
          padding: 8px 16px;
          margin-top: 10px;
        }

        /* SECTION DIVIDER */
        .section-divider {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .section-divider-line {
          flex: 1;
          height: 1px;
          background: linear-gradient(to right, transparent, #d1d5db, transparent);
        }
        .section-divider-pill {
          display: flex;
          align-items: center;
          gap: 6px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          border-radius: 999px;
          padding: 4px 14px;
          font-size: 0.72rem;
          font-weight: 700;
          color: #6c757d;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          white-space: nowrap;
          user-select: none;
        }
        .section-divider-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #9ca3af;
          flex-shrink: 0;
        }
        .section-divider-count {
          font-size: 0.65rem;
          font-weight: 600;
          color: #9ca3af;
          background: #f3f4f6;
          border-radius: 999px;
          padding: 1px 7px;
          margin-left: 2px;
        }
      `}</style>
    </>
  )
}

export default Outlet
