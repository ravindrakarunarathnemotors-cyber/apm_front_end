'use client'

import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import { Form, Button, Row, Col, Card, CardHeader, CardBody } from 'react-bootstrap'
import { useAddOutletMutation } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import IconifyIcon from '@/components/wrappers/IconifyIcon'

const schema = yup.object().shape({
  name: yup.string().required('Outlet name is required'),
  address: yup.string().required('Address is required'),
  opening_hours_from: yup.string().required('Opening time is required'),
  opening_hours_to: yup.string().required('Closing time is required'),
  email: yup.string().email('Invalid email format').nullable().notRequired(),
  hotline: yup.string().nullable().notRequired(),
  geocode: yup.string().nullable().notRequired(),
  tel_number: yup.string().nullable().notRequired(),
  is_active: yup.boolean(),
})

const Field = ({ label, error, children, required }) => (
  <Form.Group className="mb-3">
    <Form.Label className="fw-semibold text-secondary" style={{ fontSize: '0.82rem' }}>
      {label} {required && <span className="text-danger">*</span>}
    </Form.Label>
    {children}
    {error && (
      <div className="text-danger mt-1" style={{ fontSize: '0.75rem' }}>
        {error}
      </div>
    )}
  </Form.Group>
)

const AddOutlet = () => {
  const [addOutlet, { isLoading, isSuccess, resetMutation }] = useAddOutletMutation()

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      name: '',
      address: '',
      geocode: '',
      hotline: '',
      email: '',
      opening_hours_from: '',
      opening_hours_to: '',
      tel_number: '',
      is_active: true,
    },
  })

  useEffect(() => {
    if (isSuccess) {
      const timer = setTimeout(() => {
        reset()
        resetMutation?.()
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [isSuccess, reset, resetMutation])

  const onSubmit = async (data) => {
    const result = await Swal.fire({
      title: '<span style="font-size:1.1rem;font-weight:700">Confirm Outlet Creation</span>',
      html: `
        <div style="text-align:left;font-size:0.875rem;line-height:2">
          <table style="width:100%;border-collapse:collapse">
            <tr>
              <td style="color:#6c757d;width:38%;padding:3px 0">Outlet Name</td>
              <td style="font-weight:600;color:#212529">${data.name}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Address</td>
              <td style="color:#212529">${data.address || '—'}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Email</td>
              <td style="color:#212529">${data.email || '—'}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Hotline</td>
              <td style="color:#212529">${data.hotline || '—'}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Telephone</td>
              <td style="color:#212529">${data.tel_number || '—'}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Opening Hours</td>
              <td style="color:#212529">${data.opening_hours_from} — ${data.opening_hours_to}</td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Status</td>
              <td>
                <span style="
                  background:${data.is_active ? '#d1fae5' : '#fee2e2'};
                  color:${data.is_active ? '#065f46' : '#991b1b'};
                  padding:2px 10px;
                  border-radius:999px;
                  font-size:0.72rem;
                  font-weight:600;
                  text-transform:uppercase;
                  letter-spacing:0.04em
                ">${data.is_active ? 'Active' : 'Inactive'}</span>
              </td>
            </tr>
            <tr>
              <td style="color:#6c757d;padding:3px 0">Cash Account</td>
              <td style="color:#212529;font-weight:600">${data.name} Cash <span style="font-size:0.72rem;color:#6c757d">(auto-created)</span></td>
            </tr>
          </table>
        </div>
      `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Create Outlet',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#0d6efd',
      cancelButtonColor: '#6c757d',
      reverseButtons: true,
      customClass: { popup: 'swal-outlet-popup' },
    })

    if (!result.isConfirmed) return

    try {
      await addOutlet(data).unwrap()
      Swal.fire({
        title: 'Outlet Created!',
        html: `<span style="font-size:0.9rem">
          <b>${data.name}</b> has been created successfully.<br/>
          <span style="color:#6c757d;font-size:0.82rem">A default cash account "<b>${data.name} Cash</b>" has also been set up.</span>
        </span>`,
        icon: 'success',
        confirmButtonColor: '#0d6efd',
        timer: 3000,
        timerProgressBar: true,
      })
    } catch (err) {
      console.error(err)
      if (err.status === 460) {
        Swal.fire({
          icon: "warning",
          iconColor: "#f59e0b", // Modern amber/warning color
          title: '<span style="font-family: sans-serif; font-weight: 600; color: #1f2937;">Outlet Limit Reached</span>',
          html: `
                <div style="text-align: center; color: #4b5563; font-family: sans-serif; font-size: 15px; line-height: 1.6; padding: 0 10px;">
                  <p style="margin: 0;">You have reached the maximum number of outlets allowed for your current plan.</p>
                  <p style="margin: 12px 0 0 0; font-weight: 600; color: #111827;">
                    Please contact your administrator to upgrade your subscription.
                  </p>
                </div>
              `,
          confirmButtonText: "Got it",
          confirmButtonColor: "#1f2937", // Pure inline background color
          background: "#ffffff",
          // This inline style rounds the default button beautifully
          didOpen: () => {
            const confirmButton = Swal.getConfirmButton();
            if (confirmButton) {
              confirmButton.style.borderRadius = "8px";
              confirmButton.style.padding = "10px 24px";
              confirmButton.style.fontSize = "14px";
              confirmButton.style.fontFamily = "sans-serif";
            }
          }
        });
        return;
      }
      Swal.fire({
        title: 'Failed',
        text: err?.data?.error || 'Something went wrong. Please try again.',
        icon: 'error',
        confirmButtonColor: '#dc3545',
      })
    }
  }

  return (
    <>
      <Card className="border-0 shadow-sm mt-4" style={{ borderRadius: 12 }}>
        <CardHeader
          className="d-flex align-items-center gap-2 px-4 py-3"
          style={{ background: '#f8f9fa', borderRadius: '12px 12px 0 0', borderBottom: '1px solid #e9ecef' }}>
          <IconifyIcon icon="mdi:store-plus-outline" style={{ fontSize: 20, color: '#0d6efd' }} />
          <h5 className="mb-0 fw-semibold" style={{ fontSize: '0.95rem' }}>
            Add New Outlet
          </h5>
        </CardHeader>

        <CardBody className="px-4 py-4">
          <Form onSubmit={handleSubmit(onSubmit)} noValidate>
            {/* SECTION: Basic Info */}
            <div className="section-label mb-3">Basic Information</div>

            <Row>
              <Col md={6}>
                <Field label="Outlet Name" error={errors.name?.message} required>
                  <Form.Control type="text" placeholder="e.g. Main Branch" {...register('name')} isInvalid={!!errors.name} className="form-input" />
                </Field>
              </Col>
              <Col md={4} className="d-flex align-items-center pt-3">
                <Form.Check
                  type="switch"
                  id="is_active_switch"
                  label={<span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Active</span>}
                  {...register('is_active')}
                  className="mt-2"
                />
              </Col>
            </Row>

            <Row>
              <Col md={8}>
                <Field label="Address" error={errors.address?.message} required>
                  <Form.Control
                    as="textarea"
                    rows={2}
                    placeholder="Enter full outlet address"
                    {...register('address')}
                    isInvalid={!!errors.address}
                    className="form-input"
                  />
                </Field>
              </Col>
            </Row>

            {/* SECTION: Contact */}
            <div className="section-label mb-3 mt-2">Contact Details</div>

            <Row>
              <Col md={4}>
                <Field label="Email" error={errors.email?.message}>
                  <Form.Control
                    type="email"
                    placeholder="outlet@example.com"
                    {...register('email')}
                    isInvalid={!!errors.email}
                    className="form-input"
                  />
                </Field>
              </Col>
              <Col md={4}>
                <Field label="Hotline" error={errors.hotline?.message}>
                  <Form.Control type="text" placeholder="+94 11 000 0000" {...register('hotline')} className="form-input" />
                </Field>
              </Col>
              <Col md={4}>
                <Field label="Telephone" error={errors.tel_number?.message}>
                  <Form.Control type="text" placeholder="+94 77 000 0000" {...register('tel_number')} className="form-input" />
                </Field>
              </Col>
            </Row>

            {/* SECTION: Hours & Location */}
            <div className="section-label mb-3 mt-2">Hours & Location</div>

            <Row>
              <Col md={3}>
                <Field label="Opening From" error={errors.opening_hours_from?.message} required>
                  <Form.Control type="time" {...register('opening_hours_from')} isInvalid={!!errors.opening_hours_from} className="form-input" />
                </Field>
              </Col>
              <Col md={3}>
                <Field label="Opening To" error={errors.opening_hours_to?.message} required>
                  <Form.Control type="time" {...register('opening_hours_to')} isInvalid={!!errors.opening_hours_to} className="form-input" />
                </Field>
              </Col>
              <Col md={6}>
                <Field label="Geocode" error={errors.geocode?.message}>
                  <Form.Control type="text" placeholder="e.g. 6.9271,79.8612" {...register('geocode')} className="form-input" />
                </Field>
              </Col>
            </Row>

            {/* FOOTER */}
            <div className="d-flex justify-content-between align-items-center pt-3 mt-2" style={{ borderTop: '1px solid #e9ecef' }}>
              <span style={{ fontSize: '0.78rem', color: '#6c757d' }}>
                <IconifyIcon icon="mdi:information-outline" className="me-1" />A default cash account will be auto-created for this outlet.
              </span>

              <Button
                type="submit"
                variant="primary"
                disabled={isLoading}
                className="px-5"
                style={{ borderRadius: 999, fontWeight: 600, fontSize: '0.88rem' }}>
                {isLoading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" />
                    Creating...
                  </>
                ) : (
                  <>
                    <IconifyIcon icon="mdi:store-check-outline" className="me-2" />
                    Create Outlet
                  </>
                )}
              </Button>
            </div>
          </Form>
        </CardBody>
      </Card>

      <style jsx global>{`
        .section-label {
          font-size: 0.72rem;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: #0d6efd;
          border-bottom: 1px solid #e9ecef;
          padding-bottom: 6px;
        }

        .form-input {
          font-size: 0.85rem;
          border-radius: 8px;
          border: 1px solid #dee2e6;
          transition:
            border-color 0.15s ease,
            box-shadow 0.15s ease;
        }

        .form-input:focus {
          border-color: #0d6efd;
          box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }

        .swal-outlet-popup {
          border-radius: 12px !important;
          padding: 24px !important;
        }
      `}</style>
    </>
  )
}

export default AddOutlet
