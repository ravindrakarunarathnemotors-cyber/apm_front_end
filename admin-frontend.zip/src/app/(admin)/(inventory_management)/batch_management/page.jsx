import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Batch Management',
}

const BatchManagement = dynamic(() => import('./BatchManagement'), { ssr: false })

export default function BatchManagementPage() {
  return <BatchManagement />
}
