'use client'

import { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, CardHeader, Row, Col, Form, Button, Spinner, InputGroup, Modal } from 'react-bootstrap'
import Select from 'react-select'
import BatchList from './BatchList'
import Swal from 'sweetalert2'
import {
  useValidateBatchNumberMutation,
  useBatchProductSearchQuery,
  useCreateBatchManagementMutation,
  useGetDiscountCurrencyQuery,
  useGetSystemGlobalSettingsQuery,
  useSearchActiveSuppliersMutation,
} from '@/store/features/apiSlice'

const formatCurrencyValue = (value) => {
  if (value === '' || value === null) return ''
  const num = Number(value)
  if (Number.isNaN(num)) return ''
  return num.toFixed(2)
}

function useDebounce(value, delay = 500) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return debounced
}

const highlightText = (text, search) => {
  if (!search) return text
  const regex = new RegExp(`(${search})`, 'gi')
  return text.split(regex).map((part, i) =>
    part.toLowerCase() === search.toLowerCase() ? (
      <mark key={i} className="px-1">
        {part}
      </mark>
    ) : (
      part
    ),
  )
}

export default function BatchManagement({
  isModal = false,
  initialVariant = null,
  initialSupplier = null,
  onClose,
  onBatchCreated,
  lockVariantSearch = false,
  lockSupplierSelection = false,
}) {
  const [search, setSearch] = useState('')
  const [showVariants, setShowVariants] = useState(false)
  const [page, setPage] = useState(1)
  const [allProducts, setAllProducts] = useState([])

  const [tempSelectedVariant, setTempSelectedVariant] = useState(null)
  const [confirmedVariant, setConfirmedVariant] = useState(null)

  const [batchNumber, setBatchNumber] = useState('')
  const [costPrice, setCostPrice] = useState('')
  const [sellingPrice, setSellingPrice] = useState('')
  const [manufactureDate, setManufactureDate] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [supplier, setSupplier] = useState(null)
  const [supplierSearch, setSupplierSearch] = useState('')
  const [supplierOptions, setSupplierOptions] = useState([])
  const [showAccessDeniedModal, setShowAccessDeniedModal] = useState(false)
  const shouldLockVariantSearch = isModal && lockVariantSearch && !!initialVariant
  const shouldLockSupplierSelection = isModal && lockSupplierSelection && !!initialSupplier?.supplier_id

  const debouncedBatchNumber = useDebounce(batchNumber, 500)
  const debouncedSupplierSearch = useDebounce(supplierSearch, 500)
  const { data: globalSettingsData, isLoading: isGlobalSettingsLoading } = useGetSystemGlobalSettingsQuery()

  const isBatchManagementAllowed = globalSettingsData?.system_settings?.field_config?.batch_no === true
  const shouldBlockBatchForm = !isGlobalSettingsLoading && !isBatchManagementAllowed

  const { data: currencyData } = useGetDiscountCurrencyQuery(undefined)

  const currency = currencyData?.currency || globalSettingsData?.system_settings?.currency || ''

  const [validateBatchNumber, { isLoading: isValidating }] = useValidateBatchNumberMutation()

  const [searchActiveSuppliers, { isLoading: isSupplierSearching }] = useSearchActiveSuppliersMutation()
  const [isBatchValid, setIsBatchValid] = useState(null)
  const [batchError, setBatchError] = useState('')

  const today = new Date().toISOString().split('T')[0]

  const { data, isLoading, isFetching, error } = useBatchProductSearchQuery({ query: search, page }, { skip: !search || !isBatchManagementAllowed })

  const [createBatch, { isLoading: isSaving }] = useCreateBatchManagementMutation()

  const pagination = data?.pagination

  useEffect(() => {
    if (!initialVariant) return

    setConfirmedVariant({
      product_id: initialVariant.product_id,
      product_title: initialVariant.product_title,
      image: initialVariant.image || '/package.png',
      variant_id: initialVariant.variant_id,
      variant_value: initialVariant.variant_value,
      variant_type: initialVariant.variant_type,
    })

    setTempSelectedVariant(null)
    setShowVariants(false)
    setSearch('')
    setAllProducts([])
    setBatchNumber('')
    setCostPrice('')
    setSellingPrice('')
    setManufactureDate('')
    setExpiryDate('')
    setSupplierSearch('')
    setIsBatchValid(null)
    setBatchError('')

    /*
     * Prefill supplier only when supplied by the GRN page.
     * Other BatchManagement usages continue with an empty supplier.
     */
    if (lockSupplierSelection && initialSupplier?.supplier_id) {
      const supplierOption = {
        value: initialSupplier.supplier_id,
        label: `${initialSupplier.business_name || 'Supplier'} (${initialSupplier.supplier_id})`,
        supplier: initialSupplier,
      }

      setSupplier(supplierOption)
      setSupplierOptions([supplierOption])
    } else {
      setSupplier(null)
      setSupplierOptions([])
    }
  }, [initialVariant, initialSupplier, lockSupplierSelection])
  useEffect(() => {
    if (shouldBlockBatchForm) {
      setShowAccessDeniedModal(true)
    }
  }, [shouldBlockBatchForm])

  useEffect(() => {
    if (!data?.results) return
    if (page === 1) setAllProducts(data.results)
    else setAllProducts((prev) => [...prev, ...data.results])
  }, [data, page])

  const isFormValid = useMemo(() => {
    return isBatchManagementAllowed && confirmedVariant && batchNumber.trim() && costPrice && sellingPrice && isBatchValid === true
  }, [isBatchManagementAllowed, confirmedVariant, shouldLockSupplierSelection, batchNumber, costPrice, sellingPrice, isBatchValid])

  const openAccessDeniedModal = () => {
    if (shouldBlockBatchForm) {
      setShowAccessDeniedModal(true)
    }
  }

  const handleSubmit = async () => {
    if (!isBatchManagementAllowed) {
      setShowAccessDeniedModal(true)
      return
    }

    if (!confirmedVariant) return

    const payload = {
      product_id: confirmedVariant.product_id,
      variant_id: confirmedVariant.variant_id,
      batch_number: batchNumber,
      cost_price: Number(costPrice),
      selling_price: Number(sellingPrice),
      manufacture_date: manufactureDate || null,
      expiry_date: expiryDate || null,
      supplier_id: supplier?.value || null,
    }

    const result = await Swal.fire({
      title: 'Confirm Batch Creation',
      html: `
      <div style="text-align:left;font-size:14px">
        <p><b>Product:</b> ${confirmedVariant.product_title}</p>
        <p><b>Variant:</b> ${confirmedVariant.variant_value}</p>
        <p><b>Batch Number:</b> ${batchNumber}</p>
        <p><b>Cost Price:</b> ${costPrice}</p>
        <p><b>Selling Price:</b> ${sellingPrice}</p>
        ${manufactureDate ? `<p><b>Manufacture Date:</b> ${manufactureDate}</p>` : ''}
        ${expiryDate ? `<p><b>Expiry Date:</b> ${expiryDate}</p>` : ''}
      </div>
    `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Create Batch',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      focusCancel: true,
    })

    if (!result.isConfirmed) return

    try {
      const createdBatch = await createBatch(payload).unwrap()
      await Swal.fire({
        icon: 'success',
        title: 'Batch Created',
        text: 'The batch has been created successfully.',
        timer: 2000,
        showConfirmButton: false,
      })

      const createdBatchNumber = createdBatch?.batch_number || batchNumber

      onBatchCreated?.({
        product_id: confirmedVariant.product_id,
        variant_id: confirmedVariant.variant_id,
        batch_number: createdBatchNumber,
      })

      if (isModal) {
        onClose?.()
        return
      }

      setConfirmedVariant(null)
      setBatchNumber('')
      setCostPrice('')
      setSellingPrice('')
      setManufactureDate('')
      setExpiryDate('')
      setSupplier(null)
      setSupplierSearch('')
      setSupplierOptions([])
      setSearch('')
      setAllProducts([])
    } catch (err) {
      console.error(err)

      Swal.fire({
        icon: 'error',
        title: 'Failed to Create Batch',
        text: 'Something went wrong. Please try again.',
      })
    }
  }

  const clearSearch = () => {
    setSearch('')
    setPage(1)
    setAllProducts([])
    setShowVariants(false)
    setTempSelectedVariant(null)
    setConfirmedVariant(null)
    setBatchNumber('')
    setIsBatchValid(null)
    setBatchError('')
  }

  // Search active suppliers
  useEffect(() => {
    if (!isBatchManagementAllowed) return
    if (shouldLockSupplierSelection) return

    let isCancelled = false

    const fetchSuppliers = async () => {
      try {
        const response = await searchActiveSuppliers({
          keyword: debouncedSupplierSearch.trim(),
        }).unwrap()

        if (isCancelled) return

        const options = (response?.suppliers || []).map((item) => ({
          value: item.supplier_id,
          label: `${item.business_name} (${item.supplier_id})`,
          supplier: item,
        }))

        setSupplierOptions(options)
      } catch (error) {
        if (!isCancelled) {
          console.error('Failed to search suppliers:', error)
          setSupplierOptions([])
        }
      }
    }

    fetchSuppliers()

    return () => {
      isCancelled = true
    }
  }, [debouncedSupplierSearch, searchActiveSuppliers, isBatchManagementAllowed])

  // Validate batch number
  useEffect(() => {
    if (!isBatchManagementAllowed) return

    if (!confirmedVariant || !debouncedBatchNumber.trim()) {
      setIsBatchValid(null)
      setBatchError('')
      return
    }

    let isCancelled = false

    const validate = async () => {
      try {
        const res = await validateBatchNumber({
          variant_id: confirmedVariant.variant_id,
          batch_number: debouncedBatchNumber.trim(),
        }).unwrap()

        if (isCancelled) return

        if (res.valid) {
          setIsBatchValid(true)
          setBatchError('')
        } else {
          setIsBatchValid(false)
          setBatchError('Cannot use same batch number for the same variant')
        }
      } catch {
        if (!isCancelled) {
          setIsBatchValid(false)
          setBatchError('Batch No. already exists for the selected Variant')
        }
      }
    }

    validate()

    return () => {
      isCancelled = true
    }
  }, [debouncedBatchNumber, confirmedVariant, validateBatchNumber, isBatchManagementAllowed])
  return (
    <>
      <Modal show={showAccessDeniedModal} onHide={() => setShowAccessDeniedModal(false)} centered backdrop="static">
        <Modal.Header closeButton>
          <Modal.Title>Batch Management Access Restricted</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <div className="text-center py-3">
            <div
              className="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-warning bg-opacity-10"
              style={{ width: 72, height: 72 }}>
              <span className="fs-1 text-warning">!</span>
            </div>

            <h5 className="fw-semibold mb-2">Batch Management Privilege Denied</h5>

            <p className="text-muted mb-0">
              You do not have permission to create or manage product batches. Please contact your administrator to enable batch management access.
            </p>
          </div>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowAccessDeniedModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Card className="shadow-sm border-0">
        <CardHeader className="py-3 bg-light">
          <h5 className="mb-0 fw-semibold">Add New Batch</h5>
          <small className="text-muted">
            {isBatchManagementAllowed
              ? 'Search product and select a variant'
              : 'Batch management privilege is denied. Please contact the administrator.'}
          </small>
        </CardHeader>

        <CardBody>
          <div className="position-relative">
            {shouldBlockBatchForm && (
              <div
                role="button"
                tabIndex={0}
                onClick={openAccessDeniedModal}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') openAccessDeniedModal()
                }}
                style={{
                  position: 'absolute',
                  inset: 0,
                  zIndex: 5,
                  cursor: 'not-allowed',
                  background: 'rgba(255, 255, 255, 0.15)',
                }}
              />
            )}

            <div
              style={{
                filter: shouldBlockBatchForm ? 'blur(3px)' : 'none',
                opacity: shouldBlockBatchForm ? 0.55 : 1,
                pointerEvents: shouldBlockBatchForm ? 'none' : 'auto',
                userSelect: shouldBlockBatchForm ? 'none' : 'auto',
                transition: 'filter 0.2s ease, opacity 0.2s ease',
              }}>
              <fieldset disabled={isGlobalSettingsLoading}>
                <Row className="g-4">
                  <Col md={12}>
                    <Form.Label className="fw-medium">Search Product / Variant *</Form.Label>

                    <InputGroup>
                      <Form.Control
                        placeholder={shouldLockVariantSearch ? 'Variant already selected.' : 'Product title / Product ID / Variant ID'}
                        value={search}
                        disabled={shouldLockVariantSearch}
                        onChange={(e) => {
                          if (shouldLockVariantSearch) return

                          setSearch(e.target.value)
                          setPage(1)
                          setShowVariants(true)
                        }}
                      />
                      {search && !shouldLockVariantSearch && (
                        <Button variant="outline-secondary" onClick={clearSearch}>
                          ✕
                        </Button>
                      )}
                    </InputGroup>

                    {shouldLockVariantSearch && (
                      <Form.Text className="text-muted">Variant is pre-selected from Stock In/Out. Search is disabled in this modal.</Form.Text>
                    )}
                  </Col>

                  {!shouldLockVariantSearch && showVariants && search && (
                    <Col md={12}>
                      <div
                        className="border border-top-0 rounded-bottom bg-white"
                        style={{
                          marginTop: '-1px',
                          maxHeight: 360,
                          overflowY: 'auto',
                        }}>
                        <div className="px-3 py-2 border-bottom fw-semibold small">Product / Variant</div>

                        <div className="px-3 py-2">
                          {isLoading || isFetching ? (
                            <div className="text-center py-3">
                              <Spinner size="sm" /> Searching…
                            </div>
                          ) : error ? (
                            <div className="text-danger small">Failed to load products</div>
                          ) : allProducts.length === 0 ? (
                            <div className="text-muted small">No matching products found</div>
                          ) : (
                            allProducts.map((product) => (
                              <div key={product.product_id} className="mb-3">
                                <div className="fw-semibold small px-2 py-1 rounded" style={{ background: '#EEF3FF' }}>
                                  {highlightText(product.product_title, search)}
                                  <span className="text-muted ms-2">({highlightText(String(product.product_id), search)})</span>
                                </div>

                                {product.variants?.map((variant) => (
                                  <Form.Check
                                    key={variant.variant_id}
                                    type="checkbox"
                                    className="ms-3 mt-1"
                                    label={
                                      <>
                                        {highlightText(variant.variant_value, search)} ({highlightText(String(variant.variant_id), search)})
                                      </>
                                    }
                                    checked={tempSelectedVariant?.variant_id === variant.variant_id}
                                    onChange={() =>
                                      setTempSelectedVariant({
                                        product_id: product.product_id,
                                        product_title: product.product_title,
                                        image: product.product_image || '/package.png',
                                        ...variant,
                                      })
                                    }
                                  />
                                ))}
                              </div>
                            ))
                          )}

                          {pagination && page < pagination.total_pages && (
                            <div className="text-center mt-2">
                              <Button size="sm" variant="link" disabled={isFetching} onClick={() => setPage((p) => p + 1)}>
                                Load more
                              </Button>
                            </div>
                          )}
                        </div>

                        <div className="d-flex justify-content-end px-3 py-2 border-top">
                          <Button
                            size="sm"
                            className="btn bg-primary border border-primary"
                            disabled={!tempSelectedVariant}
                            onClick={() => {
                              setConfirmedVariant(tempSelectedVariant)
                              setBatchNumber('')
                              setIsBatchValid(null)
                              setBatchError('')
                              setShowVariants(false)
                            }}>
                            Done
                          </Button>
                        </div>
                      </div>
                    </Col>
                  )}

                  {confirmedVariant && (
                    <Col md={12}>
                      <div className="border rounded bg-light px-2 py-2 d-flex align-items-center gap-3">
                        <img
                          src={confirmedVariant.image || '/package.png'}
                          width={72}
                          height={72}
                          onError={(e) => (e.currentTarget.src = '/package.png')}
                          style={{
                            borderRadius: '0.75rem',
                            objectFit: 'cover',
                            border: '1px solid #E5E7EB',
                            backgroundColor: '#fff',
                          }}
                        />
                        <div>
                          <div className="fw-semibold">{confirmedVariant.product_title}</div>
                          <small className="text-muted">{confirmedVariant.variant_value}</small>
                        </div>
                      </div>
                    </Col>
                  )}

                  <Col md={6}>
                    <Form.Label>Batch Number *</Form.Label>

                    <InputGroup>
                      <Form.Control
                        maxLength={30}
                        value={batchNumber}
                        disabled={!confirmedVariant}
                        isValid={isBatchValid === true}
                        isInvalid={isBatchValid === false}
                        placeholder={!confirmedVariant ? 'Select a variant first' : 'Enter batch number'}
                        onChange={(e) => {
                          setBatchNumber(e.target.value.replace(/[^a-zA-Z0-9]/g, ''))
                          setIsBatchValid(null)
                          setBatchError('')
                        }}
                      />

                      {isValidating && (
                        <InputGroup.Text className="bg-light">
                          <Spinner size="sm" />
                        </InputGroup.Text>
                      )}
                    </InputGroup>

                    {!confirmedVariant && (
                      <Form.Text className="text-muted">
                        Please select a product variant and click <b>Done</b>
                      </Form.Text>
                    )}

                    {batchError && <Form.Text className="text-danger">{batchError}</Form.Text>}
                  </Col>

                  <Col md={6}>
                    <Form.Label>Supplier</Form.Label>

                    <Select
                      options={supplierOptions}
                      value={supplier}
                      inputValue={shouldLockSupplierSelection ? '' : supplierSearch}
                      isDisabled={shouldLockSupplierSelection}
                      isClearable={!shouldLockSupplierSelection}
                      isSearchable={!shouldLockSupplierSelection}
                      isLoading={!shouldLockSupplierSelection && isSupplierSearching}
                      placeholder={shouldLockSupplierSelection ? 'Supplier selected from Purchase Order' : 'Search supplier name or supplier ID'}
                      noOptionsMessage={() => (isSupplierSearching ? 'Searching suppliers...' : 'No active suppliers found')}
                      loadingMessage={() => 'Searching suppliers...'}
                      onInputChange={(value, actionMeta) => {
                        if (shouldLockSupplierSelection) return ''

                        if (actionMeta.action === 'input-change') {
                          setSupplierSearch(value)
                          return value
                        }

                        if (actionMeta.action === 'set-value' || actionMeta.action === 'menu-close' || actionMeta.action === 'input-blur') {
                          return ''
                        }

                        return value
                      }}
                      onChange={(selectedOption) => {
                        if (shouldLockSupplierSelection) return

                        setSupplier(selectedOption)
                        setSupplierSearch('')
                      }}
                      filterOption={() => true}
                    />

                    {shouldLockSupplierSelection && (
                      <Form.Text className="text-muted">Supplier is selected from the Purchase Order and cannot be changed.</Form.Text>
                    )}
                  </Col>
                  <Col md={6}>
                    <Form.Label>Cost Price *</Form.Label>

                    <InputGroup>
                      <Form.Control
                        type="text"
                        inputMode="decimal"
                        value={costPrice}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9.]/g, '')
                          setCostPrice(val)
                        }}
                        onBlur={() => {
                          setCostPrice(formatCurrencyValue(costPrice))
                        }}
                      />

                      <InputGroup.Text className="bg-light fw-medium">{currency || 'LKR'}</InputGroup.Text>
                    </InputGroup>
                  </Col>

                  <Col md={6}>
                    <Form.Label>Selling Price *</Form.Label>

                    <InputGroup>
                      <Form.Control
                        type="text"
                        inputMode="decimal"
                        value={sellingPrice}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9.]/g, '')
                          setSellingPrice(val)
                        }}
                        onBlur={() => {
                          setSellingPrice(formatCurrencyValue(sellingPrice))
                        }}
                      />

                      <InputGroup.Text className="bg-light fw-medium">{currency || 'LKR'}</InputGroup.Text>
                    </InputGroup>
                  </Col>

                  <Col md={6}>
                    <Form.Label>Manufacture Date</Form.Label>
                    <Form.Control type="date" max={today} value={manufactureDate} onChange={(e) => setManufactureDate(e.target.value)} />
                  </Col>

                  <Col md={6}>
                    <Form.Label>Expiry Date</Form.Label>
                    <Form.Control type="date" min={today} value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
                  </Col>

                  <Col md={12} className="d-flex justify-content-end gap-2">
                    {isModal && (
                      <Button variant="outline-secondary" onClick={onClose} disabled={isSaving}>
                        Cancel
                      </Button>
                    )}

                    <Button className="btn bg-primary border border-primary px-4" disabled={!isFormValid || isSaving} onClick={handleSubmit}>
                      {isSaving ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          Adding Batch...
                        </>
                      ) : (
                        'Add Batch'
                      )}
                    </Button>
                  </Col>
                </Row>
              </fieldset>
            </div>
          </div>
        </CardBody>
      </Card>

      {!isModal && <BatchList />}
    </>
  )
}
