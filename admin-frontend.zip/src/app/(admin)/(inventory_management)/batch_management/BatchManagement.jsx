'use client'

import { useState, useMemo, useEffect } from 'react'
import { Card, CardBody, CardHeader, Row, Col, Form, Button, Spinner, InputGroup } from 'react-bootstrap'
import Select from 'react-select'
import BatchList from './BatchList'
import Swal from 'sweetalert2'
import { useValidateBatchNumberMutation } from '@/store/features/apiSlice'

import { useBatchProductSearchQuery, useCreateBatchManagementMutation, useGetDiscountCurrencyQuery } from '@/store/features/apiSlice'

/* ================= SUPPLIERS ================= */

const mockSuppliers = [
  { value: 1, label: 'ABC Pharma Suppliers' },
  { value: 2, label: 'Global Medical Distributors' },
]

const formatCurrencyValue = (value) => {
  if (value === '' || value === null) return ''
  const num = Number(value)
  if (Number.isNaN(num)) return ''
  return num.toFixed(2)
}
function useDebounce(value, delay = 500) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return debounced
}

/* ================= UTIL ================= */

const highlightText = (text, search) => {
  if (!search) return text
  const regex = new RegExp(`(${search})`, 'gi')
  return text.split(regex).map((part, i) =>
    part.toLowerCase() === search.toLowerCase() ? (
      <mark key={i} className="px-1">
        {part}
      </mark>
    ) : (
      part
    ),
  )
}

export default function BatchManagement() {
  const [search, setSearch] = useState('')
  const [showVariants, setShowVariants] = useState(false)
  const [page, setPage] = useState(1)
  const [allProducts, setAllProducts] = useState([])

  const [tempSelectedVariant, setTempSelectedVariant] = useState(null)
  const [confirmedVariant, setConfirmedVariant] = useState(null)

  const [batchNumber, setBatchNumber] = useState('')
  const [costPrice, setCostPrice] = useState('')
  const [sellingPrice, setSellingPrice] = useState('')
  const [manufactureDate, setManufactureDate] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [supplier, setSupplier] = useState(null)
  const debouncedBatchNumber = useDebounce(batchNumber, 500)

  const { data: currencyData, isLoading: isCurrencyLoading } = useGetDiscountCurrencyQuery(undefined)

  const currency = currencyData?.currency || ''

  const [validateBatchNumber, { isLoading: isValidating }] = useValidateBatchNumberMutation()

  const [isBatchValid, setIsBatchValid] = useState(null) // null | true | false
  const [batchError, setBatchError] = useState('')

  const today = new Date().toISOString().split('T')[0]

  /* ================= RTK QUERIES ================= */

  const { data, isLoading, isFetching, error } = useBatchProductSearchQuery({ query: search, page }, { skip: !search })

  const [createBatch, { isLoading: isSaving }] = useCreateBatchManagementMutation()

  const pagination = data?.pagination

  /* ================= PAGINATION APPEND ================= */

  useEffect(() => {
    if (!data?.results) return
    if (page === 1) setAllProducts(data.results)
    else setAllProducts((prev) => [...prev, ...data.results])
  }, [data, page])

  /* ================= FORM VALIDATION ================= */
  const isFormValid = useMemo(() => {
    return confirmedVariant && batchNumber.trim() && costPrice && sellingPrice && isBatchValid === true
  }, [confirmedVariant, batchNumber, costPrice, sellingPrice, isBatchValid])

  /* ================= SUBMIT ================= */

  const handleSubmit = async () => {
    if (!confirmedVariant) return

    const payload = {
      product_id: confirmedVariant.product_id,
      variant_id: confirmedVariant.variant_id,
      batch_number: batchNumber,
      cost_price: Number(costPrice),
      selling_price: Number(sellingPrice),
      manufacture_date: manufactureDate || null,
      expiry_date: expiryDate || null,
      supplier_id: 1, // temporary
    }

    /* ================= CONFIRMATION SWAL ================= */

    const result = await Swal.fire({
      title: 'Confirm Batch Creation',
      html: `
      <div style="text-align:left;font-size:14px">
        <p><b>Product:</b> ${confirmedVariant.product_title}</p>
        <p><b>Variant:</b> ${confirmedVariant.variant_value}</p>
        <p><b>Batch Number:</b> ${batchNumber}</p>
        <p><b>Cost Price:</b> ${costPrice}</p>
        <p><b>Selling Price:</b> ${sellingPrice}</p>
        ${manufactureDate ? `<p><b>Manufacture Date:</b> ${manufactureDate}</p>` : ''}
        ${expiryDate ? `<p><b>Expiry Date:</b> ${expiryDate}</p>` : ''}
      </div>
    `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Create Batch',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      focusCancel: true,
    })

    if (!result.isConfirmed) return

    /* ================= FIRE BACKEND ================= */

    try {
      await createBatch(payload).unwrap()

      await Swal.fire({
        icon: 'success',
        title: 'Batch Created',
        text: 'The batch has been created successfully.',
        timer: 2000,
        showConfirmButton: false,
      })

      // Reset form
      setConfirmedVariant(null)
      setBatchNumber('')
      setCostPrice('')
      setSellingPrice('')
      setManufactureDate('')
      setExpiryDate('')
      setSupplier(null)
      setSearch('')
      setAllProducts([])
    } catch (err) {
      console.error(err)

      Swal.fire({
        icon: 'error',
        title: 'Failed to Create Batch',
        text: 'Something went wrong. Please try again.',
      })
    }
  }

  const clearSearch = () => {
    setSearch('')
    setPage(1)
    setAllProducts([])
    setShowVariants(false)
    setTempSelectedVariant(null)
    setConfirmedVariant(null)
    setBatchNumber('')
    setIsBatchValid(null)
    setBatchError('')
  }

  useEffect(() => {
    // reset if no variant or empty batch
    if (!confirmedVariant || !debouncedBatchNumber.trim()) {
      setIsBatchValid(null)
      setBatchError('')
      return
    }

    let isCancelled = false

    const validate = async () => {
      try {
        const res = await validateBatchNumber({
          variant_id: confirmedVariant.variant_id,
          batch_number: debouncedBatchNumber.trim(),
        }).unwrap()

        if (isCancelled) return

        if (res.valid) {
          setIsBatchValid(true)
          setBatchError('')
        } else {
          setIsBatchValid(false)
          setBatchError('Cannot use same batch number for the same variant')
        }
      } catch {
        if (!isCancelled) {
          setIsBatchValid(false)
          setBatchError('Batch No. already exists for the selected Variant')
        }
      }
    }

    validate()

    return () => {
      isCancelled = true
    }
  }, [debouncedBatchNumber, confirmedVariant, validateBatchNumber])

  /* ================= RENDER ================= */

  return (
    <>
      <Card className="shadow-sm border-0">
        <CardHeader className="py-3 bg-light">
          <h5 className="mb-0 fw-semibold">Add New Batch</h5>
          <small className="text-muted">Search product and select a variant</small>
        </CardHeader>

        <CardBody>
          <Row className="g-4">
            {/* ================= SEARCH ================= */}
            <Col md={12}>
              <Form.Label className="fw-medium">Search Product / Variant *</Form.Label>

              <InputGroup>
                <Form.Control
                  placeholder="Product title / Product ID / Variant ID"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    setPage(1)
                    setShowVariants(true)
                  }}
                />
                {search && (
                  <Button variant="outline-secondary" onClick={clearSearch}>
                    ✕
                  </Button>
                )}
              </InputGroup>
            </Col>

            {/* ================= SEARCH PANEL ================= */}
            {showVariants && search && (
              <Col md={12}>
                <div
                  className="border border-top-0 rounded-bottom bg-white"
                  style={{
                    marginTop: '-1px',
                    maxHeight: 360,
                    overflowY: 'auto',
                  }}>
                  <div className="px-3 py-2 border-bottom fw-semibold small">Product / Variant</div>

                  <div className="px-3 py-2">
                    {isLoading || isFetching ? (
                      <div className="text-center py-3">
                        <Spinner size="sm" /> Searching…
                      </div>
                    ) : error ? (
                      <div className="text-danger small">Failed to load products</div>
                    ) : allProducts.length === 0 ? (
                      <div className="text-muted small">No matching products found</div>
                    ) : (
                      allProducts.map((product) => (
                        <div key={product.product_id} className="mb-3">
                          <div className="fw-semibold small px-2 py-1 rounded" style={{ background: '#EEF3FF' }}>
                            {highlightText(product.product_title, search)}
                            <span className="text-muted ms-2">({highlightText(String(product.product_id), search)})</span>
                          </div>

                          {product.variants?.map((variant) => (
                            <Form.Check
                              key={variant.variant_id}
                              type="checkbox"
                              className="ms-3 mt-1"
                              label={
                                <>
                                  {highlightText(variant.variant_value, search)} ({highlightText(String(variant.variant_id), search)})
                                </>
                              }
                              checked={tempSelectedVariant?.variant_id === variant.variant_id}
                              onChange={() =>
                                setTempSelectedVariant({
                                  product_id: product.product_id,
                                  product_title: product.product_title,
                                  image: product.product_image || '/package.png',
                                  ...variant,
                                })
                              }
                            />
                          ))}
                        </div>
                      ))
                    )}

                    {pagination && page < pagination.total_pages && (
                      <div className="text-center mt-2">
                        <Button size="sm" variant="link" disabled={isFetching} onClick={() => setPage((p) => p + 1)}>
                          Load more
                        </Button>
                      </div>
                    )}
                  </div>

                  <div className="d-flex justify-content-end px-3 py-2 border-top">
                    <Button
                      size="sm"
                      className="btn bg-primary border border-primary"
                      disabled={!tempSelectedVariant}
                      onClick={() => {
                        setConfirmedVariant(tempSelectedVariant)
                        setBatchNumber('')
                        setIsBatchValid(null)
                        setBatchError('')
                        setShowVariants(false)
                      }}>
                      Done
                    </Button>
                  </div>
                </div>
              </Col>
            )}

            {/* ================= CONFIRMED PRODUCT ================= */}
            {confirmedVariant && (
              <Col md={12}>
                <div className="border rounded bg-light px-2 py-2 d-flex align-items-center gap-3">
                  <img
                    src={confirmedVariant.image || '/package.png'}
                    width={72}
                    height={72}
                    onError={(e) => (e.currentTarget.src = '/package.png')}
                    style={{
                      borderRadius: '0.75rem',
                      objectFit: 'cover',
                      border: '1px solid #E5E7EB',
                      backgroundColor: '#fff',
                    }}
                  />
                  <div>
                    <div className="fw-semibold">{confirmedVariant.product_title}</div>
                    <small className="text-muted">{confirmedVariant.variant_value}</small>
                  </div>
                </div>
              </Col>
            )}

            {/* ================= FORM ================= */}
            <Col md={6}>
              <Form.Label>Batch Number *</Form.Label>

              <InputGroup>
                <Form.Control
                  maxLength={30}
                  value={batchNumber}
                  disabled={!confirmedVariant}
                  isValid={isBatchValid === true}
                  isInvalid={isBatchValid === false}
                  placeholder={!confirmedVariant ? 'Select a variant first' : 'Enter batch number'}
                  onChange={(e) => {
                    setBatchNumber(e.target.value.replace(/[^a-zA-Z0-9]/g, ''))
                    setIsBatchValid(null)
                    setBatchError('')
                  }}
                />

                {isValidating && (
                  <InputGroup.Text className="bg-light">
                    <Spinner size="sm" />
                  </InputGroup.Text>
                )}
              </InputGroup>

              {!confirmedVariant && (
                <Form.Text className="text-muted">
                  Please select a product variant and click <b>Done</b>
                </Form.Text>
              )}

              {batchError && <Form.Text className="text-danger">{batchError}</Form.Text>}
            </Col>

            <Col md={6}>
              <Form.Label>Supplier</Form.Label>
              <Select options={mockSuppliers} isClearable value={supplier} onChange={setSupplier} />
            </Col>

            <Col md={6}>
              <Form.Label>Cost Price *</Form.Label>

              <InputGroup>
                <Form.Control
                  type="text"
                  inputMode="decimal"
                  value={costPrice}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9.]/g, '')
                    setCostPrice(val)
                  }}
                  onBlur={() => {
                    setCostPrice(formatCurrencyValue(costPrice))
                  }}
                />

                <InputGroup.Text className="bg-light fw-medium">{currency || 'CAD'}</InputGroup.Text>
              </InputGroup>
            </Col>

            <Col md={6}>
              <Form.Label>Selling Price *</Form.Label>

              <InputGroup>
                <Form.Control
                  type="text"
                  inputMode="decimal"
                  value={sellingPrice}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9.]/g, '')
                    setSellingPrice(val)
                  }}
                  onBlur={() => {
                    setSellingPrice(formatCurrencyValue(sellingPrice))
                  }}
                />

                <InputGroup.Text className="bg-light fw-medium">{currency || 'CAD'}</InputGroup.Text>
              </InputGroup>
            </Col>

            <Col md={6}>
              <Form.Label>Manufacture Date</Form.Label>
              <Form.Control
                type="date"
                max={today} //today + past allowed
                value={manufactureDate}
                onChange={(e) => setManufactureDate(e.target.value)}
              />
            </Col>

            <Col md={6}>
              <Form.Label>Expiry Date</Form.Label>
              <Form.Control type="date" min={today} value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
            </Col>

            <Col md={12} className="d-flex justify-content-end">
              <Button className="btn bg-primary border border-primary px-4" disabled={!isFormValid || isSaving} onClick={handleSubmit}>
                {isSaving ? (
                  <>
                    <Spinner size="sm" className="me-2" />
                    Adding Batch...
                  </>
                ) : (
                  'Add Batch'
                )}
              </Button>
            </Col>
          </Row>
        </CardBody>
      </Card>

      <BatchList />
    </>
  )
}
