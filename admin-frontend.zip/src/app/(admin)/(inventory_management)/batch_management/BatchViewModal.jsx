'use client'

import { useState, useEffect } from 'react'
import { Modal, Table, Button, Badge, Row, Col, Image, Form } from 'react-bootstrap'
import Swal from 'sweetalert2'

import { useUpdateBatchStatusMutation } from '@/store/features/apiSlice'

export default function BatchViewModal({ show, onHide, batch }) {
  /* ================= STATE ================= */

  const [status, setStatus] = useState(batch?.status)
  const [isUpdating, setIsUpdating] = useState(false)

  const [updateBatchStatus] = useUpdateBatchStatusMutation()

  useEffect(() => {
    if (batch) {
      setStatus(batch.status)
    }
  }, [batch])

  /* ================= GUARD ================= */
  if (!batch) return null

  /* ================= HELPERS ================= */

  const formatDate = (v) => (v ? v.split('T')[0] : 'N/A')
  const formatDateTime = (v) => (v ? v.replace('T', ' ').slice(0, 16) : 'N/A')
  const formatNumber = (v) => (v !== null && v !== undefined ? Number(v).toFixed(2) : '0.00')

  const productImage = batch.image_url && batch.image_url.trim() !== '' ? batch.image_url : '/package.png'

  /* ================= STATUS TOGGLE ================= */

  const handleStatusToggle = async () => {
    const nextStatus = status === 'active' ? 'inactive' : 'active'

    const result = await Swal.fire({
      title: `${nextStatus === 'active' ? 'Activate' : 'Deactivate'} Batch`,
      html: `
        <div style="text-align:left;font-size:14px">
          <p>Are you sure you want to <b>${nextStatus}</b> this batch?</p>
          <p><b>Batch No:</b> ${batch.batch_number || 'N/A'}</p>
        </div>
      `,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, confirm',
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      focusCancel: true,
    })

    if (!result.isConfirmed) return

    try {
      setIsUpdating(true)

      await updateBatchStatus({
        batch_management_id: batch.batch_management_id,
        status: nextStatus,
      }).unwrap()

      setStatus(nextStatus)

      Swal.fire({
        icon: 'success',
        title: 'Status Updated',
        text: `Batch ${batch.batch_number} is now ${nextStatus}`,
        timer: 1500,
        showConfirmButton: false,
      })
    } catch (err) {
      console.error(err)
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: 'Could not update batch status.',
      })
    } finally {
      setIsUpdating(false)
    }
  }

  /* ================= RENDER ================= */

  return (
    <Modal show={show} onHide={onHide} size="lg" centered backdrop="static">
      {/* ================= HEADER ================= */}
      <Modal.Header
        closeButton
        style={{
          backgroundColor: '#DEE2E6',
          borderBottom: '1px solid #CED4DA',
        }}>
        <div>
          <div className="fw-semibold">Batch ID: {batch.batch_management_id}</div>
          <div className="text-muted small">Batch No: {batch.batch_number || 'N/A'}</div>
        </div>
      </Modal.Header>

      {/* ================= BODY ================= */}
      <Modal.Body>
        <Row className="g-4">
          {/* ================= PRODUCT ================= */}
          <Col md={4}>
            <div className="border rounded p-3 bg-light h-100">
              <div
                className="d-flex align-items-center justify-content-center mb-3"
                style={{
                  width: '100%',
                  height: 180,
                  background: '#fff',
                  borderRadius: 8,
                  overflow: 'hidden',
                }}>
                <Image
                  src={productImage}
                  alt={batch.product_title || 'Product Image'}
                  style={{
                    maxWidth: '100%',
                    maxHeight: '100%',
                    objectFit: 'contain',
                  }}
                  onError={(e) => (e.currentTarget.src = '/package.png')}
                />
              </div>

              <div className="text-center">
                <div className="fw-semibold">{batch.product_title || 'N/A'}</div>

                <div className="mt-2 d-flex justify-content-center gap-1 flex-wrap">
                  {batch.variant_id && <Badge bg="secondary">VID: {batch.variant_id}</Badge>}
                  {batch.variant_value && <Badge bg="info">{batch.variant_value}</Badge>}
                </div>
              </div>
            </div>
          </Col>

          {/* ================= DETAILS ================= */}
          <Col md={8}>
            <h6 className="fw-semibold mb-2">Batch Details</h6>

            <Table bordered size="sm" className="mb-3">
              <tbody>
                <tr>
                  <th style={{ width: 180 }}>Status</th>
                  <td>
                    <div className="d-flex align-items-center gap-3">
                      <Form.Check
                        type="switch"
                        checked={status === 'active'}
                        disabled={status === 'expired' || isUpdating}
                        onChange={handleStatusToggle}
                        style={{
                          marginBottom: 0,
                          transform: 'scale(1.35)',
                          transformOrigin: 'left center',
                        }}
                      />

                      <Badge
                        bg={status === 'active' ? 'success' : status === 'inactive' ? 'secondary' : 'danger'}
                        className="text-capitalize"
                        style={{
                          fontSize: '0.65rem',
                          padding: '2px 10px',
                          minWidth: 70,
                          textAlign: 'center',
                        }}>
                        {status}
                      </Badge>
                    </div>
                  </td>
                </tr>

                <tr>
                  <th>Supplier</th>
                  <td>{batch.supplier_name || 'N/A'}</td>
                </tr>

                <tr>
                  <th>Created At</th>
                  <td>{formatDateTime(batch.created_at)}</td>
                </tr>

                <tr>
                  <th>Created By</th>
                  <td>{batch.created_by_name || 'N/A'}</td>
                </tr>
              </tbody>
            </Table>

            <h6 className="fw-semibold mb-2">Dates</h6>
            <Table bordered size="sm" className="mb-3">
              <tbody>
                <tr>
                  <th style={{ width: 180 }}>Manufacture Date</th>
                  <td>{formatDate(batch.manufacture_date)}</td>
                </tr>
                <tr>
                  <th>Expiry Date</th>
                  <td>{formatDate(batch.expiry_date)}</td>
                </tr>
              </tbody>
            </Table>

            <h6 className="fw-semibold mb-2">Pricing</h6>
            <Table bordered size="sm">
              <tbody>
                <tr>
                  <th style={{ width: 180 }}>Cost Price</th>
                  <td className="text-end">{formatNumber(batch.cost_price)}</td>
                </tr>
                <tr>
                  <th>Selling Price</th>
                  <td className="text-end">{formatNumber(batch.selling_price)}</td>
                </tr>
              </tbody>
            </Table>
          </Col>
        </Row>
      </Modal.Body>

      {/* ================= FOOTER ================= */}
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  )
}
