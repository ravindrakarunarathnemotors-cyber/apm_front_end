'use client'

import { useState, useMemo, useEffect } from 'react'
import { Table, Card, CardHeader, CardBody, Row, Col, Form, Button, Spinner, Badge } from 'react-bootstrap'
import Select from 'react-select'
import { Icon } from '@iconify/react'
import AsyncSelect from 'react-select/async'
import Pagination from '@/components/Pagination'
import { useGetBatchManagementListQuery, useBatchProductSearchQuery } from '@/store/features/apiSlice'

import BatchViewModal from './BatchViewModal'

/* ================= CONSTANTS ================= */

const statusOptions = [
  { value: 'active', label: 'Active' },
  { value: 'expired', label: 'Expired' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'blocked', label: 'Blocked' },
]

/* ================= DEBOUNCE ================= */

function useDebounce(value, delay = 500) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return debounced
}

/* ================= COMPONENT ================= */

export default function BatchList() {
  const [productSearch, setProductSearch] = useState('')
  const debouncedSearch = useDebounce(productSearch, 500)

  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [status, setStatus] = useState(null)
  const [page, setPage] = useState(1)

  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedBatch, setSelectedBatch] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)

  const [filtersApplied, setFiltersApplied] = useState(false)
  const [appliedFilters, setAppliedFilters] = useState(null)
  const [expandedProducts, setExpandedProducts] = useState({})
  const [limit, setLimit] = useState(10)

  /* ================= PRODUCT SEARCH (RTK) ================= */

  const { data: productSearchData, isFetching: isProductSearching } = useBatchProductSearchQuery(
    { query: debouncedSearch, page: 1 },
    { skip: !debouncedSearch },
  )

  const productOptions = useMemo(() => {
    if (!productSearchData?.results) return []

    return productSearchData.results.map((p) => ({
      value: p.product_id,
      label: `${p.product_title} (${p.product_code})`,
    }))
  }, [productSearchData])

  const loadProducts = async (inputValue) => {
    setProductSearch(inputValue)
    return productOptions
  }

  /* ================= BATCH LIST QUERY ================= */

  const queryParams = useMemo(() => {
    if (!filtersApplied) {
      return { page, page_size: limit }
    }

    return {
      product_id: appliedFilters?.product_id || undefined,
      from_date: appliedFilters?.dateFrom || undefined,
      to_date: appliedFilters?.dateTo || undefined,
      status: appliedFilters?.status || undefined,
      page,
      page_size: limit,
    }
  }, [filtersApplied, appliedFilters, page, limit])

  const { data, isLoading, isFetching } = useGetBatchManagementListQuery(queryParams)

  const batches = data?.results || []
  const totalPages = data?.pagination?.total_pages || 1

  /* ================= HELPERS ================= */

  const hasAnyFilter = productSearch.trim() || dateFrom || dateTo || status

  const handleOpenView = (batch) => {
    setSelectedBatch(batch)
    setShowViewModal(true)
  }

  const handleCloseView = () => {
    setShowViewModal(false)
    setSelectedBatch(null)
  }

  const handleLimitChange = (newLimit) => {
    setLimit(newLimit)
    setPage(1)
  }

  const handleSearchOrReset = () => {
    if (filtersApplied) {
      setSelectedProduct(null)
      setProductSearch('')
      setDateFrom('')
      setDateTo('')
      setStatus(null)
      setAppliedFilters(null)
      setFiltersApplied(false)
      setPage(1)
      return
    }

    setAppliedFilters({
      product_id: selectedProduct?.value || null,
      dateFrom,
      dateTo,
      status: status?.value || null,
    })

    setFiltersApplied(true)
    setPage(1)
  }

  const toggleProductExpand = (id) => {
    setExpandedProducts((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  const formatDate = (v) => (v ? v.split('T')[0] : 'N/A')

  const getDaysUntilExpiry = (expiryDate) => {
    if (!expiryDate) return null

    const todayDate = new Date()
    todayDate.setHours(0, 0, 0, 0)

    const expiry = new Date(expiryDate)
    expiry.setHours(0, 0, 0, 0)

    const diffTime = expiry.getTime() - todayDate.getTime()
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  }

  const formatDaysUntilExpiry = (expiryDate) => {
    const days = getDaysUntilExpiry(expiryDate)

    if (days === null) return 'N/A'
    if (days < 0) return `Expired ${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} ago`
    if (days === 0) return 'Expires Today'
    return `${days} day${days === 1 ? '' : 's'}`
  }

  const getExpiryBadgeClass = (expiryDate) => {
    const days = getDaysUntilExpiry(expiryDate)

    if (days === null) return 'bg-secondary'
    if (days < 0) return 'bg-danger'
    if (days === 0) return 'bg-warning text-dark'
    if (days <= 30) return 'bg-warning text-dark'
    return 'bg-success'
  }

  const today = new Date().toISOString().split('T')[0]

  /* ================= RENDER ================= */

  const totalEntries = data?.pagination?.total_records || 0
  const currency = data?.currency?.currency || ''
  return (
    <Card className="shadow-sm border-0 mt-4">
      <CardHeader className="py-3 bg-light">
        <h5 className="mb-0 fw-semibold">Batch List</h5>
        <small className="text-muted">Filter and manage batches</small>
      </CardHeader>

      {/* ================= FILTERS ================= */}
      <CardBody className="border-bottom">
        <div className="po-filter-bar">
          <div className="row g-2 align-items-end">
            {/* Product Search */}
            <div className="col-12 col-sm-6 col-lg-4 col-xl-4">
              <div className="po-filter-label">Product Search</div>

              <AsyncSelect
                cacheOptions
                loadOptions={loadProducts}
                isLoading={isProductSearching}
                value={selectedProduct}
                onChange={setSelectedProduct}
                isClearable
                placeholder="Search & select product"
                isDisabled={filtersApplied}
                styles={{
                  control: (base, state) => ({
                    ...base,
                    minHeight: '36px',
                    height: '36px',
                    fontSize: '13px',
                    borderRadius: '8px',
                    borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                    boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                    background: '#fff',
                  }),
                  valueContainer: (b) => ({
                    ...b,
                    padding: '0 10px',
                  }),
                  indicatorsContainer: (b) => ({
                    ...b,
                    height: '36px',
                  }),
                  menu: (b) => ({
                    ...b,
                    zIndex: 9999,
                  }),
                  menuPortal: (b) => ({
                    ...b,
                    zIndex: 9999,
                  }),
                }}
                menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
              />
            </div>

            {/* Date From */}
            <div className="col-6 col-sm-3 col-lg-2 col-xl-2">
              <div className="po-filter-label">Date From</div>

              <Form.Control
                type="date"
                value={dateFrom}
                max={today}
                onChange={(e) => setDateFrom(e.target.value)}
                disabled={filtersApplied}
                className="form-control form-control-sm"
              />
            </div>

            {/* Date To */}
            <div className="col-6 col-sm-3 col-lg-2 col-xl-2">
              <div className="po-filter-label">Date To</div>

              <Form.Control
                type="date"
                value={dateTo}
                max={today}
                onChange={(e) => setDateTo(e.target.value)}
                disabled={filtersApplied}
                className="form-control form-control-sm"
              />
            </div>

            {/* Status */}
            <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
              <div className="po-filter-label">Status</div>

              <Select
                options={statusOptions}
                isClearable
                value={status}
                onChange={setStatus}
                isDisabled={filtersApplied}
                styles={{
                  control: (base, state) => ({
                    ...base,
                    minHeight: '36px',
                    height: '36px',
                    fontSize: '13px',
                    borderRadius: '8px',
                    borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                    boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                    background: '#fff',
                  }),
                  valueContainer: (b) => ({
                    ...b,
                    padding: '0 6px',
                  }),
                  menu: (b) => ({
                    ...b,
                    zIndex: 9999,
                  }),
                }}
              />
            </div>

            {/* Search Button */}
            <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
              <div className="d-flex gap-2">
                <Button
                  className="btn btn-dark btn-sm flex-grow-1 d-flex align-items-center justify-content-center gap-2"
                  disabled={!filtersApplied && !hasAnyFilter}
                  onClick={handleSearchOrReset}>
                  {filtersApplied ? 'Reset Filters' : 'Search'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardBody>

      {/* ================= TABLE ================= */}
      <CardBody className="p-0">
        <Table hover responsive className="mb-0 align-middle" style={{ tableLayout: 'fixed', width: '100%' }}>
          <thead className="table-light">
            <tr>
              <th style={{ width: 85 }}>Batch ID</th>
              <th style={{ width: 170, minWidth: 170 }}>Product</th>
              <th style={{ width: 110 }}>Batch No</th>
              <th style={{ width: 110 }} className="text-center">
                Current Stock
              </th>

              <th style={{ width: 80 }}>MFD</th>
              <th style={{ width: 90 }}>EXP</th>
              <th style={{ width: 130 }} className="text-center">
                Days Until Expiry
              </th>
              <th className="text-center" style={{ width: 85 }}>
                Status
              </th>
              <th className="text-end" style={{ width: 85 }}>
                Cost {currency ? `(${currency})` : ''}
              </th>
              <th className="text-end" style={{ width: 85 }}>
                Selling {currency ? `(${currency})` : ''}
              </th>
              <th style={{ width: 85 }} className="text-center">
                Action
              </th>
            </tr>
          </thead>

          <tbody>
            {(isLoading || isFetching) && (
              <tr>
                <td colSpan={11} className="text-center py-4">
                  <Spinner size="sm" /> Loading batches…
                </td>
              </tr>
            )}

            {!isLoading && batches.length === 0 && (
              <tr>
                <td colSpan={11} className="text-center py-4 text-muted">
                  No batches found
                </td>
              </tr>
            )}

            {batches.map((b) => {
              const expanded = expandedProducts[b.batch_management_id]
              const title = b.product_title || ''
              const isLong = title.length > 18
              return (
                <tr key={b.batch_management_id}>
                  <td className="fw-medium">{b.batch_management_id}</td>

                  <td style={{ width: 170, minWidth: 170, maxWidth: 200, verticalAlign: 'top' }}>
                    <div
                      style={{
                        maxHeight: expanded ? 90 : 18,
                        overflow: 'hidden',
                        transition: 'max-height 0.25s ease',
                      }}>
                      <div
                        style={{
                          whiteSpace: expanded ? 'normal' : 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          lineHeight: '1.2',
                          fontWeight: 500,
                          fontSize: '0.78rem',
                          wordBreak: expanded ? 'break-word' : 'normal',
                        }}
                        title={title || 'N/A'}>
                        {title || 'N/A'}
                      </div>
                    </div>

                    {title.length > 18 && (
                      <Button
                        variant="link"
                        size="sm"
                        className="p-0 mt-1 text-decoration-none d-inline-flex align-items-center"
                        style={{
                          fontSize: '0.68rem',
                          lineHeight: 1,
                        }}
                        onClick={() => toggleProductExpand(b.batch_management_id)}>
                        <Icon icon={expanded ? 'mdi:chevron-up' : 'mdi:chevron-down'} fontSize={14} />
                        {expanded ? 'Less' : 'More'}
                      </Button>
                    )}

                    <div className="mt-1 d-flex gap-1 flex-wrap">
                      {b.variant_id && (
                        <Badge bg="secondary" style={{ fontSize: '0.6rem' }}>
                          VID: {b.variant_id}
                        </Badge>
                      )}

                      {b.variant_value && (
                        <Badge bg="info" style={{ fontSize: '0.6rem' }}>
                          {b.variant_value}
                        </Badge>
                      )}
                    </div>
                  </td>
                  <td>{b.batch_number || 'N/A'}</td>

                  <td className="text-center">
                    <Badge
                      bg="light"
                      text="dark"
                      className="border px-2 py-1"
                      style={{
                        fontSize: '0.75rem',
                        fontWeight: 600,
                        minWidth: '46px',
                        display: 'inline-block',
                      }}>
                      {b.batch_current_stock ?? 0}
                    </Badge>
                  </td>

                  <td>{formatDate(b.manufacture_date)}</td>
                  <td>{formatDate(b.expiry_date)}</td>

                  <td className="text-center">
                    <span
                      className={`badge rounded-pill px-2 py-1 ${getExpiryBadgeClass(b.expiry_date)}`}
                      style={{
                        fontSize: '0.68rem',
                        fontWeight: 600,
                        minWidth: '82px',
                      }}>
                      {formatDaysUntilExpiry(b.expiry_date)}
                    </span>
                  </td>

                  <td className="text-center text-capitalize">{b.status}</td>
                  <td className="text-end">{Number(b.cost_price).toFixed(2)}</td>
                  <td className="text-end">{Number(b.selling_price).toFixed(2)}</td>
                  <td className="text-center">
                    <Button size="sm" variant="primary" onClick={() => handleOpenView(b)}>
                      View
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </Table>
      </CardBody>

      <Pagination
        currentPage={page}
        totalPages={totalPages}
        totalEntries={totalEntries}
        limit={limit}
        onPageChange={setPage}
        onLimitChange={handleLimitChange}
        showingFrom={batches.length === 0 ? 0 : (page - 1) * limit + 1}
        showingTo={(page - 1) * limit + batches.length}
      />

      {showViewModal && <BatchViewModal show={showViewModal} onHide={handleCloseView} batch={selectedBatch} />}
    </Card>
  )
}
