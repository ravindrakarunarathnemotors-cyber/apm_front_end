'use client'

import { useState, useMemo, useEffect } from 'react'
import { Table, Card, CardHeader, CardBody, Pagination, Row, Col, Form, Button, Spinner, Badge } from 'react-bootstrap'
import Select from 'react-select'
import { Icon } from '@iconify/react'
import AsyncSelect from 'react-select/async'

import { useGetBatchManagementListQuery, useBatchProductSearchQuery } from '@/store/features/apiSlice'

import BatchViewModal from './BatchViewModal'

/* ================= CONSTANTS ================= */

const PAGE_SIZE = 10

const statusOptions = [
  { value: 'active', label: 'Active' },
  { value: 'expired', label: 'Expired' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'blocked', label: 'Blocked' },
]

/* ================= DEBOUNCE ================= */

function useDebounce(value, delay = 500) {
  const [debounced, setDebounced] = useState(value)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])

  return debounced
}

/* ================= COMPONENT ================= */

export default function BatchList() {
  const [productSearch, setProductSearch] = useState('')
  const debouncedSearch = useDebounce(productSearch, 500)

  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [status, setStatus] = useState(null)
  const [page, setPage] = useState(1)

  const [showViewModal, setShowViewModal] = useState(false)
  const [selectedBatch, setSelectedBatch] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)

  const [filtersApplied, setFiltersApplied] = useState(false)
  const [appliedFilters, setAppliedFilters] = useState(null)
  const [expandedProducts, setExpandedProducts] = useState({})

  /* ================= PRODUCT SEARCH (RTK) ================= */

  const { data: productSearchData, isFetching: isProductSearching } = useBatchProductSearchQuery(
    { query: debouncedSearch, page: 1 },
    { skip: !debouncedSearch },
  )

  const productOptions = useMemo(() => {
    if (!productSearchData?.results) return []

    return productSearchData.results.map((p) => ({
      value: p.product_id,
      label: `${p.product_title} (${p.product_code})`,
    }))
  }, [productSearchData])

  const loadProducts = async (inputValue) => {
    setProductSearch(inputValue)
    return productOptions
  }

  /* ================= BATCH LIST QUERY ================= */

  const queryParams = useMemo(() => {
    if (!filtersApplied) {
      return { page, page_size: PAGE_SIZE }
    }

    return {
      product_id: appliedFilters?.product_id || undefined,
      from_date: appliedFilters?.dateFrom || undefined,
      to_date: appliedFilters?.dateTo || undefined,
      status: appliedFilters?.status || undefined,
      page,
      page_size: PAGE_SIZE,
    }
  }, [filtersApplied, appliedFilters, page])

  const { data, isLoading, isFetching } = useGetBatchManagementListQuery(queryParams)

  const batches = data?.results || []
  const totalPages = data?.pagination?.total_pages || 1

  /* ================= HELPERS ================= */

  const hasAnyFilter = productSearch.trim() || dateFrom || dateTo || status

  const handleOpenView = (batch) => {
    setSelectedBatch(batch)
    setShowViewModal(true)
  }

  const handleCloseView = () => {
    setShowViewModal(false)
    setSelectedBatch(null)
  }

  const handleSearchOrReset = () => {
    if (filtersApplied) {
      setSelectedProduct(null)
      setProductSearch('')
      setDateFrom('')
      setDateTo('')
      setStatus(null)
      setAppliedFilters(null)
      setFiltersApplied(false)
      setPage(1)
      return
    }

    setAppliedFilters({
      product_id: selectedProduct?.value || null,
      dateFrom,
      dateTo,
      status: status?.value || null,
    })

    setFiltersApplied(true)
    setPage(1)
  }

  const toggleProductExpand = (id) => {
    setExpandedProducts((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  const formatDate = (v) => (v ? v.split('T')[0] : 'N/A')
  const today = new Date().toISOString().split('T')[0]

  /* ================= RENDER ================= */

  return (
    <Card className="shadow-sm border-0 mt-4">
      <CardHeader className="py-3 bg-light">
        <h5 className="mb-0 fw-semibold">Batch List</h5>
        <small className="text-muted">Filter and manage batches</small>
      </CardHeader>

      {/* ================= FILTERS ================= */}
      <CardBody className="border-bottom">
        <Row className="g-3 align-items-end">
          <Col md={4}>
            <Form.Label>Product Search</Form.Label>
            <AsyncSelect
              cacheOptions
              loadOptions={loadProducts}
              isLoading={isProductSearching}
              value={selectedProduct}
              onChange={setSelectedProduct}
              isClearable
              placeholder="Search & select product"
              isDisabled={filtersApplied}
            />
          </Col>

          <Col md={2}>
            <Form.Label>Date From</Form.Label>
            <Form.Control type="date" value={dateFrom} max={today} onChange={(e) => setDateFrom(e.target.value)} disabled={filtersApplied} />
          </Col>

          <Col md={2}>
            <Form.Label>Date To</Form.Label>
            <Form.Control type="date" value={dateTo} max={today} onChange={(e) => setDateTo(e.target.value)} disabled={filtersApplied} />
          </Col>

          <Col md={2}>
            <Form.Label>Status</Form.Label>
            <Select options={statusOptions} isClearable value={status} onChange={setStatus} isDisabled={filtersApplied} />
          </Col>

          <Col md={2}>
            <Button
              className="btn bg-primary border border-primary mt-4 w-100"
              disabled={!filtersApplied && !hasAnyFilter}
              onClick={handleSearchOrReset}>
              {filtersApplied ? 'Reset Filters' : 'Search'}
            </Button>
          </Col>
        </Row>
      </CardBody>

      {/* ================= TABLE ================= */}
      <CardBody className="p-0">
        <Table hover responsive className="mb-0 align-middle">
          <thead className="table-light">
            <tr>
              <th style={{ width: 85 }}>Batch ID</th>
              <th style={{ width: 120 }}>Product</th>
              <th style={{ width: 110 }}>Batch No</th>
              <th style={{ width: 80 }}>MFD</th>
              <th style={{ width: 90 }}>EXP</th>
              <th style={{ width: 85 }}>Status</th>
              <th className="text-end" style={{ width: 85 }}>
                Cost
              </th>
              <th className="text-end" style={{ width: 85 }}>
                Selling
              </th>
              <th style={{ width: 85 }} className="text-center">
                Action
              </th>
            </tr>
          </thead>

          <tbody>
            {(isLoading || isFetching) && (
              <tr>
                <td colSpan={11} className="text-center py-4">
                  <Spinner size="sm" /> Loading batches…
                </td>
              </tr>
            )}

            {!isLoading && batches.length === 0 && (
              <tr>
                <td colSpan={11} className="text-center py-4 text-muted">
                  No batches found
                </td>
              </tr>
            )}

            {batches.map((b) => {
              const expanded = expandedProducts[b.batch_management_id]
              const title = b.product_title || ''
              const isLong = title.length > 35

              return (
                <tr key={b.batch_management_id}>
                  <td className="fw-medium">{b.batch_management_id}</td>

                  <td style={{ width: 120, verticalAlign: 'top' }}>
                    <div
                      style={{
                        maxHeight: expanded ? 50 : 16,
                        overflow: 'hidden',
                        transition: 'max-height 0.3s ease',
                      }}>
                      <div
                        style={{
                          whiteSpace: expanded ? 'normal' : 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          lineHeight: '1.25',
                          fontWeight: 500,
                        }}>
                        {title || 'N/A'}
                      </div>
                    </div>

                    {isLong && (
                      <Button
                        variant="link"
                        size="sm"
                        className="p-0 mt-1 text-decoration-none"
                        onClick={() => toggleProductExpand(b.batch_management_id)}>
                        <Icon icon={expanded ? 'mdi:chevron-up' : 'mdi:chevron-down'} fontSize={16} />
                      </Button>
                    )}

                    <div className="mt-1 d-flex gap-1">
                      {b.variant_id && <Badge bg="secondary">VID: {b.variant_id}</Badge>}
                      {b.variant_value && <Badge bg="info">{b.variant_value}</Badge>}
                    </div>
                  </td>

                  <td>{b.batch_number || 'N/A'}</td>
                  <td>{formatDate(b.manufacture_date)}</td>
                  <td>{formatDate(b.expiry_date)}</td>
                  <td className="text-capitalize">{b.status}</td>
                  <td className="text-end">{Number(b.cost_price).toFixed(2)}</td>
                  <td className="text-end">{Number(b.selling_price).toFixed(2)}</td>
                  <td className="text-center">
                    <Button size="sm" variant="primary" onClick={() => handleOpenView(b)}>
                      View
                    </Button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </Table>
      </CardBody>

      {/* ================= PAGINATION ================= */}
      {totalPages > 1 && (
        <div className="d-flex justify-content-end p-3">
          <Pagination className="mb-0">
            {(() => {
              const safeCurrent = Math.min(Math.max(page, 1), totalPages)
              const pages = []

              let start = safeCurrent - 2
              let end = safeCurrent + 2

              if (totalPages <= 5) {
                start = 1
                end = totalPages
              } else {
                if (start < 1) {
                  start = 1
                  end = 5
                }
                if (end > totalPages) {
                  end = totalPages
                  start = totalPages - 4
                }
              }

              for (let i = start; i <= end; i++) {
                pages.push(
                  <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setPage(i)}>
                    {i}
                  </Pagination.Item>,
                )
              }

              return (
                <>
                  {/* FIRST */}
                  <Pagination.Item disabled={safeCurrent === 1} onClick={() => setPage(1)}>
                    First
                  </Pagination.Item>

                  {/* PREV (<) */}
                  <Pagination.Item disabled={safeCurrent === 1} onClick={() => setPage(safeCurrent - 1)}>
                    {'<'}
                  </Pagination.Item>

                  {pages}

                  {/* NEXT (>) */}
                  <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setPage(safeCurrent + 1)}>
                    {'>'}
                  </Pagination.Item>

                  {/* LAST */}
                  <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setPage(totalPages)}>
                    Last
                  </Pagination.Item>
                </>
              )
            })()}
          </Pagination>
        </div>
      )}

      {showViewModal && <BatchViewModal show={showViewModal} onHide={handleCloseView} batch={selectedBatch} />}
    </Card>
  )
}
