'use client'
import { useCallback } from 'react'
import { useState, useMemo, useEffect, useRef } from 'react'
import debounce from 'lodash/debounce'
import { Card, CardBody, CardHeader, CardTitle, Row, Col, Form, FormGroup, Button, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import ProductTable from './table/components/ProductTable'
import ProductDetails from './components/ProductDetails'
import {
  useGetFilteredInventoryListMutation,
  useGetActiveOutletsQuery,
  useLazyGetInventoryProductSearchQuery,
  useGetProductSearchGlobalQuery,
  useGetProductSearchGlobalQuery as _unused, // keep imports shape if needed
} from '@/store/features/apiSlice'

const normalizeStatus = (status) => {
  if (status === null || status === undefined) return 'Inactive'

  const s = String(status).toLowerCase()

  if (s === '1' || s === 'active' || s === 'true') return 'Active'
  if (s === '0' || s === 'inactive' || s === 'false') return 'Inactive'

  return 'Inactive'
}

const InventorySearch = () => {
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [selectedOutlet, setSelectedOutlet] = useState({ value: 'ALL', label: 'All' })
  const [filteredProducts, setFilteredProducts] = useState([])
  const [status, setStatus] = useState('receive')
  const [showDetails, setShowDetails] = useState(false)
  const [productIdInput, setProductIdInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [isProductMenuOpen, setIsProductMenuOpen] = useState(false)
  const [productInputValue, setProductInputValue] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10
  const isSelectingRef = useRef(false)

  const [getFilteredInventoryList] = useGetFilteredInventoryListMutation()
  const { data: outletsData } = useGetActiveOutletsQuery()
  const [triggerProductSearch, { data: productSearchData }] = useLazyGetInventoryProductSearchQuery()

  // existing debounced input handler for title search
  const handleProductInputChange = debounce((inputValue) => {
    if (inputValue?.length >= 2) {
      triggerProductSearch(inputValue)
    }
  }, 300)

  // --- NEW: wrapper for react-select input change that clears the numeric ID ---
  const handleProductSelectInputChange = (inputValue, { action }) => {
    // ignore internal updates while selecting
    if (isSelectingRef.current) return

    if (action !== 'input-change') return

    setProductInputValue(inputValue)
    setIsProductMenuOpen(true)

    handleProductInputChange(inputValue)
  }

  // --- NEW: react-select onChange for selecting/clearing a product ---
  const handleProductSelectChange = (option) => {
    isSelectingRef.current = true

    setSelectedProduct(option || null)

    // IMPORTANT: clear inputValue so react-select uses option.label
    setProductInputValue('')

    setIsProductMenuOpen(false)

    // release flag after render
    setTimeout(() => {
      isSelectingRef.current = false
    }, 0)
  }

  useEffect(() => {
    return () => {
      handleProductInputChange.cancel()
    }
  }, [])

  const productOptions = useMemo(() => {
    return (
      productSearchData?.products?.map((p) => {
        const productPart = `Product #${p.product_id}`
        const variantPart = p.matched_variant_id ? ` | Variant #${p.matched_variant_id}` : ''

        return {
          label: `${p.title} | ${productPart}${variantPart}`,
          value: p.product_id,
          matchedVariantId: p.matched_variant_id || null,
          matchedBarcode: p.matched_barcode || null,
        }
      }) || []
    )
  }, [productSearchData])

  useEffect(() => {
    if (productOptions.length > 0) {
      setIsProductMenuOpen(true)
    }
  }, [productOptions])

  const outletOptions = useMemo(() => {
    const options =
      outletsData?.outlets?.map((outlet) => ({
        value: outlet.outlet_id,
        label: outlet.name,
      })) || []
    return [{ value: 'ALL', label: 'All Outlets' }, ...options]
  }, [outletsData])

  const fetchInventory = useCallback(
    async (showSummary = false) => {
      const noFilters = !productIdInput.trim() && !selectedProduct?.value && selectedOutlet?.value === 'ALL'

      if (showSummary && noFilters) {
        setShowDetails(false)
        setFilteredProducts([])
        return
      }

      setLoading(true)

      try {
        const res = await getFilteredInventoryList({
          id: Number(productIdInput),
          product_id: selectedProduct?.value || null,
          outlet_name: selectedOutlet?.value || 'ALL',
          merchant_id: '20001',
          page: 1,
        }).unwrap()

        if (res.success === false || !res.data || res.data.length === 0) {
          // No inventory found
          setFilteredProducts([])
          setShowDetails(false)
          return
        }

        const raw = res.data
        const flatProducts = []

        raw.forEach((product) => {
          const { product_id, product_name, status, product_created_at, outlet_variants, main_image_url } = product

          outlet_variants?.forEach((outlet) => {
            outlet.variants?.forEach((variant) => {
              flatProducts.push({
                id: variant.variant_id,
                name: `${product_name} | ${variant.variant_value}`,
                description: variant.variant_type,
                sku: variant.sku || 'N/A',
                pics:
                  variant.quantity !== null && variant.quantity !== undefined
                    ? `${variant.quantity} ${variant.measurement_value || ''}`.trim()
                    : `0 ${variant.measurement_value || ''}`.trim(),

                status,
                createdAt: variant.last_updated ? new Date(variant.last_updated) : null,
                outlet: outlet.outlet_name || 'No outlets linked',
                productId: product_id,
                productCreatedAt: product_created_at,
                mainImageUrl: main_image_url,
              })
            })
          })
        })

        setFilteredProducts(flatProducts)
        setShowDetails(showSummary && !noFilters)
      } catch (error) {
        console.error('❌ Inventory fetch error:', error)
        setFilteredProducts([])
        setShowDetails(false)
      } finally {
        setLoading(false)
      }
    },
    [productIdInput, selectedProduct, selectedOutlet, getFilteredInventoryList],
  )

  // debounced product id for query
  const [debouncedProductId, setDebouncedProductId] = useState('')

  useEffect(() => {
    const t = setTimeout(() => {
      setDebouncedProductId(productIdInput)
    }, 300)
    return () => clearTimeout(t)
  }, [productIdInput])

  // --- dropdown show state & ref for outside-click detection ---
  const [showIdDropdown, setShowIdDropdown] = useState(false)
  const idDropdownRef = useRef(null) // wrapper ref for input + dropdown

  useEffect(() => {
    function handleDocClick(e) {
      if (!idDropdownRef.current) return
      if (!idDropdownRef.current.contains(e.target)) {
        setShowIdDropdown(false)
      }
    }
    document.addEventListener('mousedown', handleDocClick)
    return () => document.removeEventListener('mousedown', handleDocClick)
  }, [])

  // use the global product search query for the debounced numeric input
  // skip when empty
  const { data: idSearchResults, isFetching: isFetchingIdSearch } = useGetProductSearchGlobalQuery(debouncedProductId, {
    skip: !debouncedProductId || debouncedProductId.length < 1,
  })

  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage) || 1

  const paginatedProducts = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage
    return filteredProducts.slice(start, start + itemsPerPage)
  }, [filteredProducts, currentPage])

  const groupedByOutlet = useMemo(() => {
    const grouped = {}
    for (const product of paginatedProducts) {
      if (!grouped[product.outlet]) {
        grouped[product.outlet] = []
      }
      grouped[product.outlet].push(product)
    }
    return grouped
  }, [paginatedProducts])

  const summaryData = useMemo(() => {
    if (!showDetails || filteredProducts.length === 0) return null
    const product = filteredProducts[0]
    const unitMatch = filteredProducts[0]?.pics?.match(/[a-zA-Z]+$/)
    const unit = unitMatch ? unitMatch[0] : ''

    const totalQtyNumber = filteredProducts.reduce((sum, p) => {
      const num = parseFloat(p.pics)
      return sum + (isNaN(num) ? 0 : num)
    }, 0)

    const totalQty = `${totalQtyNumber} ${unit}`.trim()

    return {
      productId: product.productId,
      name: product.name.split(' | ')[0],
      variantCount: new Set(filteredProducts.map((p) => p.id)).size,
      totalQty,
      status: normalizeStatus(product.status),

      createdAt: product.productCreatedAt ? new Date(product.productCreatedAt).toDateString() : 'N/A',
      mainImageUrl: product.mainImageUrl,
    }
  }, [filteredProducts, showDetails])

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-3 bg-light">
            <div className="d-flex justify-content-between align-items-center">
              <CardTitle as="h4" className="mb-0">
                Inventory Search
              </CardTitle>
            </div>
          </CardHeader>

          <div className="py-2">
            <CardBody className="pt-0">
              <Form className="row gx-3 mb-2">
                {/* Product ID block — drop this in place of your current FormGroup for Product ID */}

                {/* ----- REPLACED Product Name Select (uses wrapper handlers) ----- */}
                <FormGroup className="col-md-4 ps-0">
                  <Select
                    options={productOptions}
                    value={selectedProduct}
                    inputValue={productInputValue}
                    onInputChange={handleProductSelectInputChange}
                    onChange={handleProductSelectChange}
                    placeholder="Search by name, variant ID, barcode, keyword"
                    isClearable
                    isSearchable
                    menuIsOpen={isProductMenuOpen}
                    onMenuClose={() => setIsProductMenuOpen(false)}
                    filterOption={null}
                  />
                </FormGroup>

                <FormGroup className="col-md-3">
                  <Select
                    options={outletOptions}
                    onChange={(option) => setSelectedOutlet(option)}
                    placeholder="Outlet"
                    isClearable={false}
                    isSearchable
                    value={selectedOutlet}
                  />
                </FormGroup>

                <FormGroup className="col-md-2 d-flex align-items-end gap-2">
                  <Button type="button" className="btn bg-primary border border-primary w-100" onClick={() => fetchInventory(true)}>
                    Search
                  </Button>
                </FormGroup>
              </Form>

              {loading ? (
                <div className="text-muted">Loading inventory...</div>
              ) : showDetails && summaryData ? (
                <ProductDetails
                  productId={summaryData.productId}
                  name={summaryData.name}
                  variantCount={summaryData.variantCount}
                  quantity={summaryData.totalQty}
                  status={summaryData.status}
                  createdAt={summaryData.createdAt}
                  imageUrl={summaryData.mainImageUrl}
                />
              ) : null}

              <Row>
                <Col xs={12}>
                  {Object.keys(groupedByOutlet).length === 0 ? (
                    <div className="text-center text-muted my-5" style={{ fontSize: '1.2rem' }}>
                      No inventory found.
                    </div>
                  ) : (
                    Object.entries(groupedByOutlet).map(([outlet, products]) => (
                      <div key={outlet} className="mb-4">
                        <h5 className="mt-2 mb-2 text-primary">{outlet === 'No outlets linked' ? outlet : `${outlet} Outlet`}</h5>
                        <ProductTable products={products} />
                      </div>
                    ))
                  )}
                </Col>
              </Row>

              {/* ================= PAGINATION ================= */}
              {filteredProducts.length > 0 && totalPages > 1 && (
                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    {(() => {
                      const safeCurrent = Math.min(Math.max(currentPage, 1), totalPages)
                      const pages = []

                      let start = safeCurrent - 2
                      let end = safeCurrent + 2

                      if (totalPages <= 5) {
                        start = 1
                        end = totalPages
                      } else {
                        if (start < 1) {
                          start = 1
                          end = 5
                        }
                        if (end > totalPages) {
                          end = totalPages
                          start = totalPages - 4
                        }
                      }

                      for (let i = start; i <= end; i++) {
                        pages.push(
                          <Pagination.Item key={i} active={i === safeCurrent} onClick={() => setCurrentPage(i)}>
                            {i}
                          </Pagination.Item>,
                        )
                      }

                      return (
                        <>
                          <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(1)}>
                            First
                          </Pagination.Item>

                          <Pagination.Item disabled={safeCurrent === 1} onClick={() => setCurrentPage(safeCurrent - 1)}>
                            {'<'}
                          </Pagination.Item>

                          {pages}

                          <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(safeCurrent + 1)}>
                            {'>'}
                          </Pagination.Item>

                          <Pagination.Item disabled={safeCurrent === totalPages} onClick={() => setCurrentPage(totalPages)}>
                            Last
                          </Pagination.Item>
                        </>
                      )
                    })()}
                  </Pagination>
                </div>
              )}
            </CardBody>
          </div>
        </Card>
      </Col>
    </Row>
  )
}

export default InventorySearch
