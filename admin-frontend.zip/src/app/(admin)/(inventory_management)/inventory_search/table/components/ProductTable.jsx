'use client'

import { useState } from 'react'
import ReactTable from '@/components/Table'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { Modal, Button, Table } from 'react-bootstrap'

const ProductTable = ({ products }) => {
  const [showBatchModal, setShowBatchModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState(null)

  const pageSizeList = [2, 5, 10, 20, 50]
  const hasVariants = products?.some((p) => p.id)

  const handleOpenBatchModal = (product) => {
    if (!product?.batches || product.batches.length === 0) return
    setSelectedProduct(product)
    setShowBatchModal(true)
  }

  const handleCloseBatchModal = () => {
    setShowBatchModal(false)
    setSelectedProduct(null)
  }

  const formatDate = (value) => {
    if (!value) return 'N/A'
    return new Date(value).toLocaleDateString()
  }

  const columns = [
    {
      id: 'id',
      header: 'Variant ID',
      accessorKey: 'id',
    },
    {
      header: 'Name',
      cell: ({ row: { original } }) => {
        const hasBatches = Array.isArray(original.batches) && original.batches.length > 0

        return (
          <div className="ps-0 d-flex align-items-start gap-2">
            <p
              className="d-inline-block align-middle mb-0"
              style={{
                maxWidth: '520px',
                whiteSpace: 'normal',
                wordBreak: 'break-word',
                overflowWrap: 'anywhere',
                lineHeight: '1.35',
              }}>
              {original.name}
            </p>

            <button
              type="button"
              title={hasBatches ? `View ${original.batches.length} batch detail(s)` : 'No batch details available'}
              disabled={!hasBatches}
              onClick={() => handleOpenBatchModal(original)}
              style={{
                border: 'none',
                background: 'transparent',
                padding: '0 2px',
                marginTop: '1px',
                fontSize: '18px',
                lineHeight: 1,
                color: hasBatches ? '#0B2E6F' : '#9ca3af',
                cursor: hasBatches ? 'pointer' : 'not-allowed',
                opacity: hasBatches ? 1 : 0.55,
              }}>
              <IconifyIcon icon="solar:document-text-bold" />
            </button>
          </div>
        )
      },
    },
    {
      header: 'Variant',
      cell: ({
        row: {
          original: { description },
        },
      }) => (
        <div className="ps-0">
          <p className="d-inline-block align-middle mb-0">
            <span className="font-13">{description}</span>
          </p>
        </div>
      ),
    },
    {
      header: 'Last Updated',
      cell: ({
        row: {
          original: { createdAt },
        },
      }) => <span>{createdAt instanceof Date ? `${createdAt.toDateString()}, ${createdAt.toLocaleTimeString()}` : 'N/A'}</span>,
    },
    {
      header: 'SKU',
      accessorKey: 'sku',
    },
    {
      header: 'Quantity',
      accessorKey: 'pics',
    },
  ]

  if (!hasVariants) {
    return <h5 className="mt-2 mb-2 text-primary">No variants linked</h5>
  }

  return (
    <>
      <ReactTable
        columns={columns}
        data={products}
        rowsPerPageList={pageSizeList}
        pageSize={10}
        tableClass="mb-0 checkbox-all"
        theadClass="table-light"
      />

      <Modal show={showBatchModal} onHide={handleCloseBatchModal} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Batch Details</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {selectedProduct && (
            <>
              <div className="mb-3">
                <div>
                  <strong>Variant Value:</strong> {selectedProduct.variantValue || 'N/A'}
                </div>
                <div>
                  <strong>Variant ID:</strong> {selectedProduct.variantId || selectedProduct.id}
                </div>
              </div>

              <Table size="sm" striped bordered hover className="mb-2">
                <thead className="table-light">
                  <tr>
                    <th>Batch No</th>
                    <th>Cost Price </th>
                    <th>Selling Price</th>
                    <th>Manufacture Date</th>
                    <th>Expiry Date</th>
                    <th>Status</th>
                  </tr>
                </thead>

                <tbody style={{fontSize:'10px', textTransform:'capitalize'}}>
                  {selectedProduct.batches.map((batch) => (
                    <tr key={batch.batch_management_id || batch.batch_number}>
                      <td>{batch.batch_number || 'N/A'}</td>
                      <td className='text-end pe-2'>{batch.cost_price ?? 0}</td>
                      <td className='text-end pe-2'>{batch.selling_price ?? 0}</td>
                      <td>{formatDate(batch.manufacture_date)}</td>
                      <td>{formatDate(batch.expiry_date)}</td>
                      <td>{batch.status || 'N/A'}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </>
          )}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" size="sm" onClick={handleCloseBatchModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default ProductTable
