'use client'

import ReactTable from '@/components/Table'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { currency } from '@/context/constants'
import { getProductStatusIcon, getProductStatusVariant } from '@/utils/variants-icons'
import Image from 'next/image'
import Link from 'next/link'
import { FormCheck } from 'react-bootstrap'
const columns = [
  {
    id: 'id',
    header: 'Variant ID',
    accessorKey: 'id',
  },

  {
    header: 'Name',
    cell: ({
      row: {
        original: { image, name },
      },
    }) => (
      <div className="ps-0">
        <p className="d-inline-block align-middle mb-0">
        
            {name}
        
        </p>
      </div>
    ),
  },
  {
    header: 'Variant',
    cell: ({
      row: {
        original: { image, description },
      },
    }) => (
      <div className="ps-0">
        <p className="d-inline-block align-middle mb-0">
          <span className="font-13">{description}</span>
        </p>
      </div>
    ),
  },

  {
    header: 'Last Updated',
    cell: ({
      row: {
        original: { createdAt },
      },
    }) => <span>{createdAt instanceof Date ? `${createdAt.toDateString()}, ${createdAt.toLocaleTimeString()}` : 'N/A'}</span>,
  },

  {
    header: 'SKU',
    accessorKey: 'sku',
  },

  {
    header: 'Quantity',
    accessorKey: 'pics',
  },
  // {
  //   header: 'Status',
  //   cell: ({
  //     row: {
  //       original: { status },
  //     },
  //   }) => (
  //     <span className={`badge bg-${getProductStatusVariant(status)}-subtle text-${getProductStatusVariant(status)}`}>
  //       <IconifyIcon icon={getProductStatusIcon(status)} className="me-1" /> {status}
  //     </span>
  //   ),
  // },
]

const ProductTable = ({ products }) => {
  const pageSizeList = [2, 5, 10, 20, 50]
  const hasVariants = products?.some((p) => p.id)
  if (!hasVariants) {
    return <h5 className="mt-2 mb-2 text-primary">No variants linked</h5>
  }
  return (
    <ReactTable
      columns={columns}
      data={products}
      rowsPerPageList={pageSizeList}
      pageSize={10}
      tableClass="mb-0 checkbox-all text-nowrap"
      theadClass="table-light"
      // showPagination
    />
  )
}
export default ProductTable
