import IconifyIcon from '@/components/wrappers/IconifyIcon';
import clsx from 'clsx';
import React from 'react';
import { Card, CardBody, CardHeader, CardTitle, Col, Dropdown, DropdownMenu, DropdownToggle, FormCheck, Row } from 'react-bootstrap';
import ProductTable from './components/ProductTable';
import { getAllProducts } from '@/helpers/data';
import ProductDetails from '../components/ProductDetails';
 
const Products = async () => {
  const filters = ['All', 'Fashion', 'Plants', 'Toys', 'Gadgets', 'Food', 'Drinks'];
  const products = await getAllProducts();
  return <Row>
      <Col xs={12}>
        <Card>
          <CardBody className='pt-1' >
            <ProductDetails />
            <ProductTable products={products} />
          </CardBody>
        </Card>
      </Col>
    </Row>;
};
export default Products;