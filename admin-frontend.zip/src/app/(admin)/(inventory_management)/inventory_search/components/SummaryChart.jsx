'use client'

import ReactApexChart from 'react-apexcharts'
import { Button, CardBody, CardTitle } from 'react-bootstrap'
const SummaryChart = () => {
  const chartOptions = {
    chart: {
      height: 260,
      type: 'donut',
    },
    plotOptions: {
      pie: {
        donut: {
          size: '80%',
        },
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent'],
    },
    series: [50, 25, 25],
    legend: {
      show: true,
      position: 'bottom',
      horizontalAlign: 'center',
      floating: false,
      fontSize: '13px',
      fontFamily: 'Be Vietnam Pro, sans-serif',
      offsetX: 0,
      offsetY: 0,
    },
    labels: ['Active', 'Completed', 'Assigned'],
    colors: ['#22c55e', '#08b0e7', '#ffc728'],
    responsive: [
      {
        breakpoint: 600,
        options: {
          plotOptions: {
            donut: {
              customScale: 0.2,
            },
          },
          chart: {
            height: 240,
          },
          legend: {
            show: false,
          },
        },
      },
    ],
    tooltip: {
      y: {
        formatter: function (val) {
          return val + ' %'
        },
      },
    },
  }
  return (
    <div>
      <CardBody className=" text-center">
        <ReactApexChart height={200} options={chartOptions} series={chartOptions.series} type="donut" />
      </CardBody>
    </div>
  )
}
export default SummaryChart
