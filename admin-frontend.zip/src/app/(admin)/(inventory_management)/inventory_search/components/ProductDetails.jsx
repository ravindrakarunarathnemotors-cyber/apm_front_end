'use client'

import { CardBody, Row, Col } from 'react-bootstrap'
import Image from 'next/image'
import { useMemo, useState, useEffect } from 'react'

const FALLBACK = '/defimg.png'

function normalizeUrl(url) {
  if (typeof url !== 'string' || !url.trim()) return ''
  try {
    // encode only the problematic characters commonly breaking CDNs
    return url
      .replace(/ /g, '%20')
      .replace(/\(/g, '%28')
      .replace(/\)/g, '%29')
  } catch {
    return ''
  }
}

const ProductDetails = ({ productId, name, variantCount, quantity, status, createdAt, imageUrl }) => {
  const normalized = useMemo(() => normalizeUrl(imageUrl), [imageUrl])
  const [src, setSrc] = useState(normalized)
  useEffect(() => setSrc(normalized), [normalized])

  return (
    <CardBody className="text-center p-2 mb-2 border rounded">
      <Row className="justify-content-center align-items-center ps-2">
        <Image
          src={src || FALLBACK}
          alt={name || 'product'}
          className="border rounded me-3"
          width={120}
          height={120}
          style={{ width: '140px', height: '120px', objectFit: 'cover' }}
          onError={() => setSrc('')}   // fallback on load error
          unoptimized                   // <-- bypass optimizer to rule it out
          priority
        />
        <Col>
          <table>
            <tbody>
              <tr className="text-start d-flex align-items-center gap-2">
                <td>
                  <span className="text-secondary">
                    Product Id <br />
                    Name <br />
                    Variants <br />
                    Quantity <br />
                    Status <br />
                    Create Date
                  </span>
                </td>
                <td>
                  <span className="fw-semibold m-0">
                    : {productId} <br />
                    : {name} <br />
                    : {variantCount} <br />
                    : {quantity} <br />
                    : {status} <br />
                    : {createdAt}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </Col>
      </Row>
    </CardBody>
  )
}

export default ProductDetails
