import clsx from 'clsx'
import { Card, CardBody, Col, Row } from 'react-bootstrap'
const taskStats = [
  {
    stat: '38',
    title: 'Quantity',
    variant: 'text-danger',
  },
  {
    stat: '2000.00',
    title: 'Default Cost (LKR)',
    variant: 'text-warning',
  },
  {
    stat: '2500.00',
    title: 'Selling Price (LKR)',
    variant: 'text-success',
  },
]
const TaskStats = () => {
  return (
    <>
      <Row>
        {taskStats.map((task, idx) => (
          <Col md={4} key={idx} >
            <Card>
              <CardBody className='p-2'>
                <div className="text-center">
                  <span className={clsx('fs-24 fw-normal', task.variant)}>{task.stat}</span>
                  <h6 className="text-uppercase fs-12 text-muted mt-2 m-0">{task.title}</h6>
                </div>
              </CardBody>
            </Card>
          </Col>
        ))}
      </Row>
    </>
  )
}
export default TaskStats
