import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Inventory Search',
}

const InventorySearch = dynamic(() => import('./InventorySearch'), { ssr: false })

export default function InventorySearchPage() {
  return <InventorySearch />
}