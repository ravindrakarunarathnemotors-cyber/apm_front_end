'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, Card, Button, Modal, Form, Container } from 'react-bootstrap'
import Image from 'next/image'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import Swal from 'sweetalert2'
import {
  useGetPluginDetailsQuery,
  useUpdatePluginStatusMutation,
  useUpdatePluginPhoneMutation,
  useSaveAndActivatePluginMutation
} from '@/store/features/apiSlice'

const Plugins = () => {
  const { data, isLoading, error } = useGetPluginDetailsQuery()
  const [updateStatus] = useUpdatePluginStatusMutation()
  const [updatePhone] = useUpdatePluginPhoneMutation()
  const [saveAndActivate] = useSaveAndActivatePluginMutation()

  const [plugins, setPlugins] = useState([])
  const [showEditModal, setShowEditModal] = useState(false)
  const [editData, setEditData] = useState(null)
  const [phoneNumber, setPhoneNumber] = useState('')

  // Load API data into state
  useEffect(() => {
    if (data) {
      const mappedData = data.map(p => ({
        payment_method_id: p.plugin_id,
        method_name: p.plugin_name,
        phone_number: p.information,
        logo: p.logo,
        status: p.status,
      }))
      setPlugins(mappedData)
    }
  }, [data])

  // Toggle active/inactive status
  const handleToggleStatus = async (plugin) => {
    const result = await Swal.fire({
      title: `Are you sure to ${plugin.status === 'active' ? 'deactivate' : 'activate'}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
    })
    if (result.isConfirmed) {
      const newStatus = plugin.status === 'active' ? 'inactive' : 'active'
      await updateStatus({ plugin_id: plugin.payment_method_id, status: newStatus })
      setPlugins(prev => prev.map(p => p.payment_method_id === plugin.payment_method_id ? { ...p, status: newStatus } : p))
      Swal.fire('Success', 'Status updated!', 'success')
    }
  }

  // Save phone number only
  const handleSave = async () => {
    if (!editData) return
    await updatePhone({ plugin_id: editData.payment_method_id, phone_number: phoneNumber })
    setPlugins(prev => prev.map(p => p.payment_method_id === editData.payment_method_id ? { ...p, phone_number: phoneNumber } : p))
    Swal.fire('Saved', 'Phone number updated!', 'success')
    setShowEditModal(false)
  }

  // Save phone number and activate plugin
  const handleSaveAndActivate = async () => {
    if (!editData) return
    await saveAndActivate({ plugin_id: editData.payment_method_id, phone_number: phoneNumber })
    setPlugins(prev => prev.map(p => p.payment_method_id === editData.payment_method_id ? { ...p, phone_number: phoneNumber, status: 'active' } : p))
    Swal.fire('Success', 'Phone and status updated!', 'success')
    setShowEditModal(false)
  }

  if (isLoading) return <p>Loading plugins...</p>
  if (error) return <p>Failed to load plugins</p>

  return (
    <>
      <Container fluid>
        <Row className="mb-3">
          <Col>
            <h4>Plugins</h4>
          </Col>
        </Row>

        <Row className="gy-4">
          {plugins.map((plugin) => (
            <Col key={plugin.payment_method_id} xs={12} sm={6} md={4} lg={3}>
              <Card className="h-100">
                <Card.Body className="text-center d-flex flex-column justify-content-between">
                  <div className="mb-3">
                    <Image
                      src={plugin.logo}
                      alt={plugin.method_name}
                      width={90}
                      height={90}
                      style={{ objectFit: 'contain' }}
                    />
                  </div>

                  <h5 className="fw-bold">{plugin.method_name}</h5>

                  <div className="d-flex flex-column gap-2 align-items-center mt-3">
                    <span
                      role="button"
                      onClick={() => handleToggleStatus(plugin)}
                    >
                      <IconifyIcon
                        icon={plugin.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                        className={plugin.status === 'active' ? 'text-success' : 'text-danger'}
                        style={{ fontSize: 40 }}
                      />
                      <span className="ms-2">
                        {plugin.status
                          ? plugin.status.charAt(0).toUpperCase() + plugin.status.slice(1)
                          : ''}
                      </span>

                    </span>

                    <span
                      role="button"
                      onClick={() => {
                        setEditData(plugin)
                        setPhoneNumber(plugin.phone_number)
                        setShowEditModal(true)
                      }}
                    >
                      <IconifyIcon
                        icon="mdi:cog-outline"
                        className="text-primary"
                        style={{ fontSize: 28 }}
                      />
                      <span className="ms-2">Config</span>
                    </span>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Config Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Config {editData?.method_name}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {/* <Form.Group className="mb-3">
            <Form.Label>Phone Number</Form.Label>
            <Form.Control
              type="text"
              placeholder="+9477xxxxxxx"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
          </Form.Group> */}
          {/* <Form.Group className="mb-3">
  <Form.Label>Phone Number</Form.Label>
  <Form.Control
    type="text"
    placeholder="+9477xxxxxxx"
    value={phoneNumber}
    onChange={(e) => {
      // Allow only digits and optional leading '+'
      let value = e.target.value;

      // Remove invalid characters
      value = value.replace(/[^+\d]/g, '');

      // Only allow a single '+' at the start
      if (value.indexOf('+') > 0) {
        value = value.replace(/\+/g, '');
      }

      // Limit length to max 13 chars (e.g., +94770000000)
      if (value.length > 13) value = value.slice(0, 13);

      setPhoneNumber(value);
    }}
  />
</Form.Group> */}

          <Form.Group className="mb-3">
            <Form.Label>
              {editData?.method_name === 'Tawk.to' ? 'Widget URL' : 'Phone Number'}
            </Form.Label>

            <Form.Control
              type="text"
              placeholder={
                editData?.method_name === 'Tawk.to'
                  ? 'https://tawk.to/chat/xxxxxxxx'
                  : '+9477xxxxxxx'
              }
              value={phoneNumber}
              onChange={(e) => {
                let value = e.target.value;

                // ✅ Tawk.to → allow full URL, no filtering
                if (editData?.method_name === 'Tawk.to') {
                  setPhoneNumber(value);
                  return;
                }

                // ✅ WhatsApp → phone number validation (existing behavior)
                value = value.replace(/[^+\d]/g, '');

                if (value.indexOf('+') > 0) {
                  value = value.replace(/\+/g, '');
                }

                if (value.length > 13) value = value.slice(0, 13);

                setPhoneNumber(value);
              }}
            />
          </Form.Group>


        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save
          </Button>
          <Button variant="success" onClick={handleSaveAndActivate}>
            Save & Activate
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default Plugins


