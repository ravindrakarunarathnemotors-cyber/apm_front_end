'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useParams } from 'next/navigation'
import { useGetTemplateSectionsQuery, useUpdateTemplateSectionsMutation } from '@/store/features/webstoreApi'
import { DndContext, closestCenter, useSensor, useSensors, PointerSensor } from '@dnd-kit/core'
import { SortableContext, useSortable, verticalListSortingStrategy, arrayMove } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { Button, Row, Col, Spinner, Modal, Alert } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import SectionConfigModalRHF from '@/components/SectionConfigModalRHF'

const apiFetch = (path, init = {}) =>
  fetch(`${process.env.NEXT_PUBLIC_BASE_URL}${path}`, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
    },
    ...init,
  })

/* ------------------- Sortable list item ------------------- */
function SortableSection({ section, idx, onRemove, onConfig }) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: section.id })

  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.7 : 1,
        background: isDragging ? '#f8fafc' : undefined,
        boxShadow: isDragging ? '0 2px 8px rgba(0,0,0,.08)' : undefined,
      }}
      className={`card mb-2 p-3 d-flex flex-row align-items-center ${isDragging ? 'shadow border-primary' : ''}`}
      {...attributes}>
      <span {...listeners} style={{ cursor: 'grab' }} className="me-3" title="Drag to reorder" aria-label="Drag to reorder">
        <Icon icon="icon-park-outline:drag" width={24} height={24} />
      </span>
      <span className="badge bg-secondary me-2">{idx + 1}</span>
      <b className="text-muted pe-2">{section.name}</b>
      <div className="flex-grow-1 ps-2 w-100">
        <img src={section.image} alt={section.name} className="w-100 rounded" style={{ objectFit: 'cover', maxHeight: 160 }} />
        {section.description && <div className="text-muted small mt-1">{section.description}</div>}
      </div>
      <div>
        <button className="btn btn-danger btn-sm ms-2 m-1 w-100" onClick={() => onRemove(section.id)}>
          <Icon icon="mdi:minus-circle-outline" className="me-1" /> Remove
        </button>
        <button className="btn btn-dark btn-sm ms-2 m-1 w-100" onClick={() => onConfig(section)}>
          <Icon icon="mdi:cog-outline" className="me-1" /> Config
        </button>
      </div>
    </div>
  )
}

/* ----------------------------- Page ----------------------------- */
export default function ElementorPage() {
  const searchParams = useSearchParams()
  const isDefault = searchParams.get('default') === '1'
  const { templateId } = useParams()

  const merchantId = 20001 // TODO: derive from session/auth

  // modal state
  const [configOpen, setConfigOpen] = useState(false)
  const [selectedSection, setSelectedSection] = useState(null)
  const [siteCfg, setSiteCfg] = useState(null)
  const [cfgLoading, setCfgLoading] = useState(false)

  // page state
  const { data, isLoading, isFetching } = useGetTemplateSectionsQuery(templateId)
  const [updateTemplateSections] = useUpdateTemplateSectionsMutation()
  const [activeSections, setActiveSections] = useState([])
  const [removedSections, setRemovedSections] = useState([])
  const [initialSections, setInitialSections] = useState([])
  const [isDirty, setIsDirty] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [saveError, setSaveError] = useState(null)
  const [showSuccess, setShowSuccess] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activating, setActivating] = useState(false)
  console.log('firstdata', data)

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }))

  // init sections from API
  useEffect(() => {
    if (data?.sections) {
      setActiveSections(data.sections.filter((s) => s.display !== false))
      setRemovedSections(data.sections.filter((s) => s.display === false))
      setInitialSections(data.sections)
    }
  }, [data])

  // dirty flag
  useEffect(() => {
    const initialActive = initialSections.filter((s) => s.display !== false).map((s) => s.id)
    const nowActive = activeSections.map((s) => s.id)
    const initialRemoved = initialSections.filter((s) => s.display === false).map((s) => s.id)
    const nowRemoved = removedSections.map((s) => s.id)
    setIsDirty(JSON.stringify(initialActive) !== JSON.stringify(nowActive) || JSON.stringify(initialRemoved) !== JSON.stringify(nowRemoved))
  }, [activeSections, removedSections, initialSections])

  // dnd reorder
  const onDragEnd = ({ active, over }) => {
    if (!over || active.id === over.id) return
    const oldIdx = activeSections.findIndex((s) => s.id === active.id)
    const newIdx = activeSections.findIndex((s) => s.id === over.id)
    setActiveSections((prev) => arrayMove(prev, oldIdx, newIdx))
  }

  const onRemove = (id) => {
    const idx = activeSections.findIndex((s) => s.id === id)
    if (idx === -1) return
    setRemovedSections((prev) => [{ ...activeSections[idx], display: false }, ...prev])
    setActiveSections((prev) => prev.filter((s) => s.id !== id))
  }

  const onAddBack = (id) => {
    const idx = removedSections.findIndex((s) => s.id === id)
    if (idx === -1) return
    setActiveSections((prev) => [...prev, { ...removedSections[idx], display: true }])
    setRemovedSections((prev) => prev.filter((s) => s.id !== id))
  }

  /* -------------------- Config open/save -------------------- */
  const onConfig = useCallback(
    async (section) => {
      setSelectedSection(section)
      setConfigOpen(true)
      setCfgLoading(true)
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/site-section-configs?merchant_id=${merchantId}&template_section_id=${section.id}`,
        )
        const json = await res.json()
        console.log('Fetched config JSON:', json);
        setSiteCfg(json && json.config ? json : json ? { config: json } : null)
      } catch {
        setSiteCfg(null)
      } finally {
        setCfgLoading(false)
      }
    },
    [merchantId],
  )

  const saveConfig = useCallback(
    async (values) => {
      await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/site-section-configs/upsert`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          merchant_id: Number(merchantId),
          template_id: Number(templateId),
          template_section_id: Number(selectedSection.id),
          enabled: true,
          sort_order: selectedSection.order ?? 0,
          config: values,
        }),
      })
    },
    [merchantId, templateId, selectedSection],
  )

  /* ---------------- Publish / Activate ---------------- */
  const handleSaveAndActivate = async () => {
    setSaving(true)
    setSaveError(null)
    setShowSuccess(false)
    try {
      const payload = [
        ...activeSections.map((s, i) => ({ id: s.id, display: true, order: i })),
        ...removedSections.map((s) => ({ id: s.id, display: false, order: null })),
      ]
      await updateTemplateSections({ templateId, sections: payload, salesChannelId: 1 }).unwrap()
      setShowSuccess(true)
      setInitialSections([...activeSections, ...removedSections])
    } catch {
      setSaveError('Failed to save changes. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleActivateOnly = async () => {
    setActivating(true)
    setSaveError(null)
    setShowSuccess(false)
    try {
      await updateTemplateSections({ templateId, sections: [], salesChannelId: 1 }).unwrap()
      setShowSuccess(true)
    } catch {
      setSaveError('Failed to activate. Please try again.')
    } finally {
      setActivating(false)
    }
  }

  if (isLoading || isFetching) {
    return (
      <div className="d-flex justify-content-center py-5">
        <Spinner animation="border" />
      </div>
    )
  }

  return (
    <>
      <div className="container-fluid py-4">
        <div className="row">
          {/* Active sections */}
          <div className="col-md-8">
            <h4 className="mb-3">Active Sections {isDefault && <span className="badge bg-danger ms-2">Published</span>}</h4>

            {showSuccess && (
              <Alert variant="success" onClose={() => setShowSuccess(false)} dismissible>
                Saved & Activated successfully!
              </Alert>
            )}
            {saveError && (
              <Alert variant="danger" onClose={() => setSaveError(null)} dismissible>
                {saveError}
              </Alert>
            )}

            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
              <SortableContext items={activeSections.map((s) => s.id)} strategy={verticalListSortingStrategy}>
                {activeSections.map((section, idx) => (
                  <SortableSection key={section.id} section={section} idx={idx} onRemove={onRemove} onConfig={onConfig} />
                ))}
              </SortableContext>
            </DndContext>
          </div>

          {/* Removed sections */}
          <div className="col-md-4">
            <h5 className="mb-3">Removed Sections</h5>
            {removedSections.length === 0 && <div className="text-muted">No removed sections.</div>}

            {removedSections.map((section) => (
              <div className="card mb-2 p-3 d-flex flex-row align-items-center" key={section.id}>
                <div className="flex-grow-1">
                  <b>{section.name}</b>
                </div>
                <button className="btn btn-outline-success btn-sm ms-2" onClick={() => onAddBack(section.id)}>
                  Add
                </button>
              </div>
            ))}

            <Row className="mt-4">
              <Col className="d-flex justify-content-end gap-2">
                <Button variant="secondary" onClick={() => setShowPreview(true)}>
                  <Icon icon="qlementine-icons:eye-24" width="20" height="20" className="me-1" />
                  Live Preview
                </Button>
                <Button
                  variant={isDirty ? 'primary' : isDefault ? 'success' : 'primary'}
                  disabled={saving || activating || (isDefault && !isDirty)}
                  onClick={isDirty ? handleSaveAndActivate : handleActivateOnly}>
                  {(saving || activating) && <Spinner size="sm" className="me-1" />}
                  {isDirty ? 'Save & Publish' : isDefault ? 'Published' : 'Publish'}
                </Button>
              </Col>
            </Row>
          </div>
        </div>
      </div>

      {/* Live Preview */}
      <Modal show={showPreview} onHide={() => setShowPreview(false)} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div style={{ maxHeight: 600, overflowY: 'auto' }} className="d-flex flex-column gap-3 border">
            {activeSections.map((s) => (
              <div key={s.id}>
                <img src={s.image} alt={s.name} className="w-100 rounded" style={{ maxHeight: 600, objectFit: 'cover' }} />
              </div>
            ))}
          </div>
        </Modal.Body>
      </Modal>

      {/* Config Modal */}
      {configOpen && selectedSection && (
        <SectionConfigModalRHF
          show={configOpen}
          onHide={(saved) => {
            setConfigOpen(false)
            setSelectedSection(null)
            setSiteCfg(null)
            // optionally refetch things on save
          }}
          section={selectedSection}
          siteConfig={siteCfg}
          onSave={saveConfig}
          loading={cfgLoading}
        />
      )}
    </>
  )
}
