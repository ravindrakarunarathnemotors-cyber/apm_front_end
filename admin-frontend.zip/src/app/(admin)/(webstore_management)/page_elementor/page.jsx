import dynamic from 'next/dynamic'

export const metadata = {
  title: 'PageBuilder',
}

const PageBuilder = dynamic(() => import('./PageBuilder'), { ssr: false })

export default function PageBuilderPage() {
  return <PageBuilder page_id={1}   />
}