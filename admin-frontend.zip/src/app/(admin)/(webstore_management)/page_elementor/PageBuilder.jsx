'use client'

import React, { useEffect, useState } from 'react'
import { Row, Col, Card, Button, Spinner, ListGroup, Alert } from 'react-bootstrap'
import { DndContext, useSensor, useSensors, PointerSensor, closestCenter } from '@dnd-kit/core'
import { arrayMove, SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  useGetComponentsQuery,
  useGetPageComponentsQuery,
  useCreatePageComponentMutation,
  useUpdatePageComponentMutation,
  useDeletePageComponentMutation,
} from '@/store/features/webstoreApi'

const PageBuilder = ({ page_id }) => {
  // --- API
  const { data: components, isLoading: loadingComps } = useGetComponentsQuery(undefined)
  const { data: pageSections, isLoading: loadingSections, refetch } = useGetPageComponentsQuery(page_id)
  const [createSection] = useCreatePageComponentMutation()
  const [updateSection] = useUpdatePageComponentMutation()
  const [deleteSection] = useDeletePageComponentMutation()

  // --- Local state for sort order
  const [items, setItems] = useState([])

  // --- DnD sensors
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }))

  // --- On load, sync items from API
  useEffect(() => {
    if (pageSections) setItems([...pageSections].sort((a, b) => a.order - b.order))
  }, [pageSections])

  // --- DnD Sortable Row
  function SortableItem({ id, name, onRemove }) {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: id.toString() })
    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
      cursor: 'grab',
      opacity: isDragging ? 0.5 : 1,
    }
    return (
      <ListGroup.Item
        ref={setNodeRef}
        style={style}
        {...attributes}
        {...listeners}
        className="d-flex justify-content-between align-items-center"
      >
        <span>{name}</span>
        <Button
          size="sm"
          variant="danger"
          onMouseDown={(e) => e.stopPropagation()}
          onClick={onRemove}
        >
          Remove
        </Button>
      </ListGroup.Item>
    )
  }

  // --- Handle drag end (reorder)
  const handleDragEnd = async (event) => {
    const { active, over } = event
    if (!over) return
    if (active.id !== over.id) {
      const oldIndex = items.findIndex((i) => i.id.toString() === active.id.toString())
      const newIndex = items.findIndex((i) => i.id.toString() === over.id.toString())
      const newItems = arrayMove(items, oldIndex, newIndex).map((item, idx) => ({
        ...item,
        order: idx + 1,
      }))
      setItems(newItems)
      // Save new order to backend
      for (const item of newItems) {
        await updateSection({ id: item.id, order: item.order })
      }
      refetch()
    }
  }

  // --- Add component to page
  const handleAddComponent = async (component) => {
    const order = items.length ? Math.max(...items.map((i) => i.order)) + 1 : 1
    await createSection({
      page_id,
      component_id: component.id,
      order,
      props_json: {},
      status: 'active',
    })
    refetch()
  }

  // --- Remove section
  const handleRemoveSection = async (sectionId) => {
    await deleteSection(sectionId)
    refetch()
  }

  // --- Render
  return (
    <Row className="mt-4">
      {/* Left: Components list */}
      <Col md={3}>
        <Card>
          <Card.Header>
            <b>Active Components</b>
          </Card.Header>
          <ListGroup>
            {loadingComps && (
              <ListGroup.Item>
                <Spinner animation="border" size="sm" /> Loading...
              </ListGroup.Item>
            )}
            {components &&
              components
                .filter((c) => c.status === 'active')
                .map((comp) => (
                  <ListGroup.Item key={comp.id} className="d-flex justify-content-between align-items-center">
                    <span>{comp.name}</span>
                    <Button size="sm" onClick={() => handleAddComponent(comp)}>
                      Add
                    </Button>
                  </ListGroup.Item>
                ))}
            {!loadingComps && components && components.filter((c) => c.status === 'active').length === 0 && (
              <ListGroup.Item>No active components.</ListGroup.Item>
            )}
          </ListGroup>
        </Card>
      </Col>

      {/* Right: Page sections */}
      <Col md={9}>
        <Card>
          <Card.Header>
            <b>Page Sections</b> (Drag to reorder)
          </Card.Header>
          <Card.Body>
            {loadingSections && <Spinner animation="border" size="sm" />}
            {!loadingSections && items.length === 0 && <Alert variant="info">No sections yet! Add a component to start building.</Alert>}

            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
              <SortableContext items={items.map((i) => i.id.toString())} strategy={verticalListSortingStrategy}>
                <ListGroup>
                  {items.map((section) => (
                    <SortableItem
                      key={section.id}
                      id={section.id.toString()}
                      name={section.component?.name || `Component ${section.component_id}`}
                      onRemove={() => handleRemoveSection(section.id)}
                    />
                  ))}
                </ListGroup>
              </SortableContext>
            </DndContext>
          </Card.Body>
        </Card>
      </Col>
    </Row>
  )
}

export default PageBuilder
