'use client'

import React from 'react'
import { Modal, Button, FormControl, FormLabel } from 'react-bootstrap'
import FormikRichText from './FormikRichText'

const PageEditModal = ({ show, onClose, title, setTitle, value, setValue, onSave }) => {
  return (
    <Modal show={show} onHide={onClose} size="lg" centered backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>Edit Page</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <FormLabel>Page Title</FormLabel>
        <FormControl
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="mb-3"
        />
        <FormikRichText value={value} setValue={setValue} />
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button variant="success" onClick={onSave}>Save</Button>
      </Modal.Footer>
    </Modal>
  )
}

export default PageEditModal

