'use client'

import React, { useMemo, useRef } from 'react'
import ReactQuill from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import axios from 'axios'
import { Col } from 'react-bootstrap'

export default function FormikRichText({ value, setValue }) {
  const quillRef = useRef()
  const API_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL

  const imageHandler = () => {
    const editor = quillRef.current.getEditor()
    const input = document.createElement('input')
    input.setAttribute('type', 'file')
    input.setAttribute('accept', 'image/*')
    input.click()

    input.onchange = async () => {
      const file = input.files[0]
      if (/^image\//.test(file.type)) {
        const formData = new FormData()
        formData.append('files', file)

        const res = await axios.post(`${API_BASE_URL}/product-media/upload-staging`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        })

        const url = res.data.media?.[0]?.media_url
        editor.insertEmbed(editor.getSelection(), 'image', url)
      } else {
        alert('You can only upload images.')
      }
    }
  }

  const modules = useMemo(
    () => ({
      toolbar: {
        container: [
          [{ header: [1, 2, 3, false] }],
          ['bold', 'italic', 'underline'],
          [{ list: 'ordered' }, { list: 'bullet' }],
          ['image', 'link'],
        ],
        handlers: {
          image: imageHandler,
        },
      },
    }),
    [],
  )

  return (
    <Col md={12} className="mt-3">
      <ReactQuill
        theme="snow"
        ref={quillRef}
        value={value}
        onChange={setValue}
        modules={modules}
        placeholder="Edit page content here..."
      />
    </Col>
  )
}
