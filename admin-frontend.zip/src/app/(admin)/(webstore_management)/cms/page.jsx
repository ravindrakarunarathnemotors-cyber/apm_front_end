'use client'

import React, { useState, useEffect, useRef } from 'react'
import dynamic from 'next/dynamic'
import { useGetFilteredAllwebpageMutation, useUpdateWebpageMutation, useToggleWebpageStatusMutation } from '@/store/features/apiSlice'
const PageEditModal = dynamic(() => import('./modals/PageEditModal'), { ssr: false })
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useRouter } from 'next/navigation'
import { Row, Col, Card, CardHeader, CardBody, CardTitle, Button, Table, Pagination } from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Select from 'react-select'
import Swal from 'sweetalert2'

function AllWebpage() {
  const [editingPage, setEditingPage] = useState(null)
  const [editingTitle, setEditingTitle] = useState('')
  const [editingContent, setEditingContent] = useState('')
  const [editorContent, setEditorContent] = useState('')
  const logsPerPage = 25
  const [currentPage, setCurrentPage] = useState(1)
  const [loading, setLoading] = useState(false)
  const [totalPages, setTotalPages] = useState(1)
  const [webpage, setLogs] = useState([])
  const [fetchFilteredWebpage, { isLoading, error }] = useGetFilteredAllwebpageMutation()
  const [updateWebpage] = useUpdateWebpageMutation()
  const [toggleWebpageStatus] = useToggleWebpageStatusMutation()

  const handleEditClick = (page) => {
    setEditingPage(page)
    setEditingTitle(page.title || '')
    setEditingContent(page.content_html || '')
  }

  const handleToggleStatus = async (id) => {
    const page = webpage.find((p) => p.id === id)
    if (!page) return

    const newStatus = page.is_homepage ? false : true

    const result = await Swal.fire({
      title: `Confirm Status Change`,
      html: `Are you sure you want to <strong>${newStatus ? 'activate' : 'deactivate'}</strong> this page: <strong>${page.title}</strong>?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: `Yes, ${newStatus ? 'Activate' : 'Deactivate'}`,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
    })

    if (!result.isConfirmed) return

    try {
      await toggleWebpageStatus({ id, is_homepage: newStatus }).unwrap()

      Swal.fire('Success', 'Page status updated successfully!', 'success')

      setLogs((prev) => prev.map((p) => (p.id === id ? { ...p, is_homepage: newStatus } : p)))
    } catch (error) {
      console.error('Failed to update page status:', error)
      Swal.fire('Error', 'Failed to update page status.', 'error')
    }
  }

  const handleSave = async () => {
    try {
      const payload = {
        id: editingPage.id,
        title: editingTitle,
        content_html: editingContent,
      }

      const res = await updateWebpage(payload).unwrap()

      Swal.fire('Success', 'Page updated successfully!', 'success')
      setEditingPage(null)
      fetchLogs(currentPage)
    } catch (err) {
      console.error('Failed to update page:', err)
      Swal.fire('Error', 'Failed to update the page.', 'error')
    }
  }

  const printSectionRef = useRef()
  const router = useRouter()

  const fetchLogs = async (page) => {
    setLoading(true)
    try {
      const res = await fetchFilteredWebpage({
        page,
        limit: logsPerPage,
      }).unwrap()

      setLogs(res.webpage || [])
      setTotalPages(res.totalPages || 1)
      setCurrentPage(page)
    } catch (err) {
      console.error('Failed to fetch web page:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs(1)
  }, [])

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    fetchLogs(pageNumber)
  }

  const getPaginationRange = () => {
    const maxVisiblePages = 7
    let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
    let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(endPage - maxVisiblePages + 1, 1)
    }
    return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
  }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          <CardHeader className="py-2" style={{ backgroundColor: '#e5e8ed' , color: 'black'}}>
            <CardTitle as="h4" className="mb-0">
              Pages
            </CardTitle>
          </CardHeader>
          <CardBody>
            <div ref={printSectionRef}>
              <>
                <Table striped className="table mb-0">
                  <thead className="table-light">
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Publish</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {webpage.map((page) => (
                      <tr key={page.id}>
                        <td>{page.id}</td>
                        <td>{page.title}</td>
                        <td>{page.is_homepage ? 'Active' : 'Inactive'}</td>
                        <td className="text-end no-print">
                          <div className="d-flex align-items-center justify-content-start">
                            <Button
                              className="d-flex align-items-center"
                              style={{
                                minWidth: 'auto',
                                padding: '0.3rem 0.6rem',
                                fontSize: '0.65rem',
                                height: '30px',
                                borderRadius: '15px',
                                backgroundColor: '#fd7e14',
                                borderColor: '#fd7e14',
                                color: '#fff',
                              }}
                              onClick={() => handleEditClick(page)}>
                              <Icon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                              <span>Edit</span>
                            </Button>
                            <span className="ms-2">
                              <Button
                                className="d-flex align-items-center"
                                style={{
                                  minWidth: 'auto',
                                  padding: '0.3rem 0.6rem',
                                  fontSize: '0.65rem',
                                  height: '30px',
                                  borderRadius: '15px',
                                  backgroundColor: page.is_homepage ? '#28a745' : '#dc3545',
                                  borderColor: page.is_homepage ? '#28a745' : '#dc3545',
                                  color: '#fff',
                                }}
                                onClick={() => handleToggleStatus(page.id)}
                                title={page.is_homepage ? 'Set Inactive' : 'Set Active'}>
                                <IconifyIcon
                                  icon={page.is_homepage ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                  style={{ fontSize: '20px', marginRight: '4px' }}
                                />
                                <span>{page.is_homepage ? 'Active' : 'Inactive'}</span>
                              </Button>
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} />
                    {getPaginationRange().map((pageNum) => (
                      <Pagination.Item key={pageNum} active={pageNum === currentPage} onClick={() => handlePageChange(pageNum)}>
                        {pageNum}
                      </Pagination.Item>
                    ))}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} />
                  </Pagination>
                </div>
              </>
            </div>
          </CardBody>
        </Card>
      </Col>

      {editingPage && (
        <PageEditModal
          show={true}
          onClose={() => setEditingPage(null)}
          title={editingTitle}
          setTitle={setEditingTitle}
          value={editingContent}
          setValue={setEditingContent}
          onSave={handleSave}
        />
      )}
    </Row>
  )
}

export default AllWebpage
