"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import SectionConfigInline from "@/components/wrappers/SectionConfigInline";
import {
  useGetComponentsQuery,
  useUpdateComponentMutation,
} from "@/store/features/webstoreApi"; // <- keep your path

// ---------- helpers ----------
const pretty = (obj) => {
  try {
    return JSON.stringify(obj, null, 2);
  } catch {
    return "";
  }
};
const safeParse = (txt) => {
  try {
    return JSON.parse(txt);
  } catch {
    return null;
  }
};

export default function ComponentManagement() {
  const { data: components = [], isLoading, refetch } = useGetComponentsQuery(
    undefined
  );
  const [updateComponent, { isLoading: isSaving }] =
    useUpdateComponentMutation();

  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);
  const [editorText, setEditorText] = useState("");
  const [msg, setMsg] = useState(null);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return components;
    return components.filter(
      (c) =>
        String(c.name || "").toLowerCase().includes(term) ||
        String(c.section_key || "").toLowerCase().includes(term)
    );
  }, [components, q]);

  const parsedSchema = useMemo(() => safeParse(editorText), [editorText]);

  // list -> editor transition
  const [view, setView] = useState("list"); // 'list' | 'editor'
  const pick = useCallback((it) => {
    setSelected(it);
    // if component already has a ui_schema column use it; otherwise fall back to empty
    const ui = it?.ui_schema ?? {};
    setEditorText(pretty(ui));
    setMsg(null);
    setView("editor");
  }, []);

  const backToList = () => setView("list");

  // initial selection
  useEffect(() => {
    if (!selected && components?.length) pick(components[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [components]);

  // right-pane save handler: stores VALUES into ui_schema
  const handleSaveValues = async (values) => {
    if (!selected) return;
    try {
      await updateComponent({
        id: selected.id,
        ui_schema: values, // <- backend expects { ui_schema }
      }).unwrap();
      setMsg({ type: "success", text: "Saved!" });
      refetch();
    } catch (e) {
      setMsg({
        type: "danger",
        text: e?.data?.message || "Save failed.",
      });
    }
  };

  return (
    <div className="container-fluid py-3">
      <div className="d-flex gap-2 mb-3">
        <input
          className="form-control"
          placeholder="Search by name or section_key"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button
          className="btn btn-outline-secondary"
          onClick={() => refetch()}
          disabled={isLoading}
        >
          {isLoading ? "Loading…" : "Reload"}
        </button>
      </div>

      {msg && <div className={`alert alert-${msg.type} py-2`}>{msg.text}</div>}

      <div className="row g-3">
        {view === "list" ? (
          // -------- STEP 1: LIST ----------
          <div className="col-12">
            <div className="card shadow-sm">
              <div className="card-header d-flex justify-content-between align-items-center">
                <strong>Components</strong>
                <button
                  className="btn btn-outline-secondary btn-sm"
                  onClick={() => refetch()}
                  disabled={isLoading}
                >
                  {isLoading ? "Loading…" : "Reload"}
                </button>
              </div>

              <div className="card-body p-0">
                <div className="p-3">
                  <input
                    className="form-control"
                    placeholder="Search by name or section_key"
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                  />
                </div>

                <div
                  className="list-group list-group-flush"
                  style={{ maxHeight: 420, overflowY: "auto" }}
                >
                  {filtered.map((it) => (
                    <button
                      key={it.id}
                      className={`list-group-item list-group-item-action d-flex justify-content-between align-items-center`}
                      onClick={() => pick(it)}
                    >
                      <span>
                        <strong>{it.name || "Untitled"}</strong>
                        <span className="text-muted ms-2">({it.section_key})</span>
                      </span>
                      <span className="badge bg-secondary">#{it.id}</span>
                    </button>
                  ))}
                  {!filtered.length && (
                    <div className="p-3 text-muted">No results.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          // -------- STEP 2: SCHEMA (left) + INLINE CONFIG PREVIEW (right) ----------
          <>
            {/* LEFT: schema editor */}
            <div className="col-12 col-lg-5">
              <div className="card shadow-sm h-100">
                <div className="card-header d-flex justify-content-between align-items-center">
                  <div>
                    <button className="btn btn-link p-0 me-2" onClick={backToList}>
                      ← Back to components
                    </button>
                    <strong>Schema</strong>{" "}
                    <span className="text-muted">
                      {selected?.name} · #{selected?.id}
                    </span>
                  </div>
                </div>

                <div className="card-body">
                  <label className="form-label">ui_schema (JSON)</label>
                  <textarea
                    className="form-control"
                    rows={28}
                    spellCheck={false}
                    value={editorText}
                    onChange={(e) => setEditorText(e.target.value)}
                    placeholder='{"form":{"fields":[...]}}'
                  />
                  <small
                    className={`d-block mt-2 text-${
                      parsedSchema ? "muted" : "danger"
                    }`}
                  >
                    {parsedSchema ? "JSON looks valid" : "Invalid JSON"}
                  </small>
                  <div className="form-text">
                    Changes here instantly update the right-hand preview/editor.
                    Saving of values happens on the right.
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT: reuse SectionConfigModalRHF inline (preview + value editor) */}
            <div className="col-12 col-lg-7">
              <SectionConfigInline
                // force remount when schema text changes to fully rebuild form
                key={`${selected?.id}-${editorText.length}`}
                // pass the live schema from the editor
                section={{
                  id: selected?.id,
                  name: selected?.name,
                  ui_schema: parsedSchema || { form: { fields: [] } },
                  default_config: selected?.default_config || {}, // if you have defaults
                }}
                // pass current saved values
                siteConfig={{
                  config: selected?.ui_schema || {},
                }}
                // save handler -> updates ui_schema
                onSave={handleSaveValues}
                loading={isSaving}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
