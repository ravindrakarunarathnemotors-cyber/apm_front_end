import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Components',
}

const Components = dynamic(() => import('./ComponentManagement'), { ssr: false })

export default function ComponentManagementPage() {
  return <Components />
}