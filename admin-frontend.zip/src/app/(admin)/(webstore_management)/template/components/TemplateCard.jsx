import React from 'react'
import { useRouter } from 'next/navigation'

export default function TemplateCard({ tpl, isDefault, onPreview, onSetDefault }) {
  const router = useRouter()
  return (
    <div className={`card  shadow-sm ${isDefault ? 'border-primary border-3' : ''}`}>
      <img src={tpl.image} className="card-img-top" style={{ objectFit: 'cover',  }} alt={tpl.name} />
      <div className="card-body d-flex flex-column">
        <h5 className="card-title mb-2">
          {tpl.name}
          {isDefault && <span className="badge bg-danger ms-2 align-text-bottom">Published</span>}
        </h5>
        <p className="card-text text-muted ">{tpl.description}</p>
        <div className="d-flex flex-wrap gap-2 mt-1">
          <button className="btn btn-secondary" onClick={onPreview}>
            <i className="bi bi-eye"></i> Preview
          </button>

            <button className="btn btn-dark" onClick={() => router.push(`/page_elementor/${tpl.id}?default=${isDefault ? '1' : '0'}`)}>
              <i className="bi bi-check-circle"></i> Customize
            </button>

          {/* {isDefault && (
            <button className="btn btn-secondary" disabled>
              <i className="bi bi-star-fill"></i> Activated
            </button>
          )} */}
        </div>
      </div>
    </div>
  )
}
