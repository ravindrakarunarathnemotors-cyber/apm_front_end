import React from 'react'
import { Modal, Button } from 'react-bootstrap'

export default function TemplateModal({
  show,
  template,
  onClose,
  onConfirm,
  isDefault,
  type // 'preview' or 'confirm'
}) {
  if (!template) return null

  return (
    <Modal show={show} onHide={onClose} centered size={type === 'preview' ? 'lg' : undefined}>
      {type === 'preview' && (
        <>
          <Modal.Header closeButton>
            <Modal.Title>
              {template.name}
              {isDefault && <span className="badge bg-danger ms-3">Published</span>}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <img src={template.image} className="img-fluid rounded mb-3 shadow-sm" alt={template.name} />
            <p className="lead">{template.description}</p>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={onClose}>
              Close
            </Button>
            {!isDefault && onConfirm && (
              <Button variant="success" onClick={onConfirm}>
                Set as Default
              </Button>
            )}
          </Modal.Footer>
        </>
      )}

      {type === 'confirm' && (
        <>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Default Template</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            Do you want to confirm this template as the default?
            <div className="alert alert-info mt-3 mb-0">
              <strong>{template.name}</strong>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={onConfirm}
              disabled={!template}
            >
              Customize
            </Button>
          </Modal.Footer>
        </>
      )}
    </Modal>
  )
}
