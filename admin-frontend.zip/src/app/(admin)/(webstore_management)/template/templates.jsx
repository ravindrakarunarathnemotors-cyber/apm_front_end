'use client'
import { useState, useEffect } from 'react'
import { useGetTemplateListQuery } from '@/store/features/apiSlice'
import { useGetSelectedTemplateQuery } from '@/store/features/webstoreApi'
import TemplateCard from './components/TemplateCard'
import TemplateModal from './components/TemplateModal'

export default function TemplatesPage() {
  const { data, error, isLoading } = useGetTemplateListQuery()
  const { data: selectedTemplateData } = useGetSelectedTemplateQuery()
  const [selected, setSelected] = useState(null)
  const [confirmFor, setConfirmFor] = useState(null)

  const activatedTemplateId = selectedTemplateData?.template_id

  // For improved user experience, optional loading placeholders
  if (isLoading) return (
    <div className="container py-5 text-center">
      <div className="spinner-border text-primary" role="status" />
      <div>Loading templates...</div>
    </div>
  )

  if (error) return (
    <div className="container py-5">
      <div className="alert alert-danger">Failed to load templates.</div>
    </div>
  )

  return (
    <div className="container py-3">
      <h2 className="mb-4 fw-bold text-center">Templates Gallery</h2>
      <div className="row g-4">
        {data?.templates?.map((tpl) => (
          <div className="col-12 col-sm-6 col-lg-4" key={tpl.id}>
            <TemplateCard
              tpl={tpl}
              isDefault={tpl.id === activatedTemplateId}
              onPreview={() => setSelected(tpl)}
              onSetDefault={() => setConfirmFor(tpl)}
            />
          </div>
        ))}
      </div>

      {/* Preview Modal */}
      <TemplateModal
        show={!!selected}
        template={selected}
        type="preview"
        isDefault={selected?.id === activatedTemplateId}
        onClose={() => setSelected(null)}
      />

      {/* Confirm Default Modal */}
      <TemplateModal
        show={!!confirmFor}
        template={confirmFor}
        type="confirm"
        onClose={() => setConfirmFor(null)}
        onConfirm={() => {
          // TODO: call mutation to activate template
          setConfirmFor(null)
        }}
      />
    </div>
  )
}
