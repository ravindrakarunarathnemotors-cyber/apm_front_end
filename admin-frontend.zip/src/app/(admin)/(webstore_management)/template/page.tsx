import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Templates',
}

const Templates = dynamic(() => import('./templates'), { ssr: false })

export default function TemplatesPage() {
  return <Templates />
}
