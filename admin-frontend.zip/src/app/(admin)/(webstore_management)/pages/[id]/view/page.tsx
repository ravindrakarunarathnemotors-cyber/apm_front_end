'use client'
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function PublicPageView({ params }: { params: { id: string } }) {
  const { id } = params;
  const [page, setPage] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchPage() {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/web/pages/${id}`);
        if (!res.ok) throw new Error('Failed to load page');
        const data = await res.json();
        setPage(data);
      } catch (err: any) {
        setError(err.message);
      }
      setLoading(false);
    }
    fetchPage();
  }, [id]);

  if (loading) return <div className="container py-5">Loading...</div>;
  if (error) return <div className="container py-5 text-danger">{error}</div>;
  if (!page) return <div className="container py-5">Page not found.</div>;

  return (
    <div className="container py-5">
      <h1>{page.title}</h1>
      <div dangerouslySetInnerHTML={{ __html: page.content_html }} />
    </div>
  );
}
