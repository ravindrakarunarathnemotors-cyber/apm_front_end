'use client'

// At the top of your file, or in a .d.ts file in your src:
declare global {
  interface Window {
    bootstrap: any
  }
}
 
import { useEffect, useState, useRef } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useGetPageQuery, useUpdatePageMutation } from '@/store/features/apiSlice'
import CustomQuill from '@/components/CustomQuill'
import 'bootstrap/dist/css/bootstrap.min.css'

export default function EditPage() {
  const { id } = useParams()
  const router = useRouter()
  const { data, isLoading, error } = useGetPageQuery(id)
  const [updatePage] = useUpdatePageMutation()

  // State
  const [title, setTitle] = useState('')
  const [slug, setSlug] = useState('')
  const [content, setContent] = useState('')
  const [status, setStatus] = useState('active')
  const [showPreview, setShowPreview] = useState(false)
  const previewModalRef = useRef(null)
  const [feedback, setFeedback] = useState('')

  // Set form fields when data loads
  useEffect(() => {
    if (data) {
      setTitle(data.title)
      setSlug(data.slug)
      setContent(data.content_html)
      setStatus(data.status)
    }
  }, [data])

  // Bootstrap Modal show/hide
  useEffect(() => {
    if (showPreview && previewModalRef.current && typeof window !== 'undefined' && window.bootstrap) {
      const modal = window.bootstrap.Modal.getOrCreateInstance(previewModalRef.current)
      modal.show()
    }
  }, [showPreview])

  // Handle Save
  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {

    e.preventDefault()
    try {
      await updatePage({ id, title, slug, content_html: content, status }).unwrap()
      setFeedback('Page saved!')
      setTimeout(() => setFeedback(''), 2000)
    } catch (err) {
      setFeedback('Error saving page')
      setTimeout(() => setFeedback(''), 2000)
    }
  }

  if (isLoading) return <div className="container py-4">Loading...</div>
  if (error) return <div className="container py-4 text-danger">Error loading page.</div>

  return (
    <div className="container py-4">
      <h2>Edit Page</h2>
      {feedback && <div className="alert alert-info">{feedback}</div>}
      <form onSubmit={handleSave}>
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input className="form-control" value={title} onChange={e => {
            setTitle(e.target.value)
            // Optional: auto-generate slug on title change
            if (!slug || slug === data?.slug) setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-'))
          }} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Slug</label>
          <input className="form-control" value={slug} onChange={e => setSlug(e.target.value)} required />
          <small className="text-muted">URL: /{slug || 'your-page'}</small>
        </div>
        <div className="mb-3">
          <label className="form-label">Content</label>
          <CustomQuill id="content" label="Content" value={content} setValue={setContent} />

        </div>
        <div className="mb-3">
          <label className="form-label me-3">Status</label>
          <input
            type="checkbox"
            checked={status === 'active'}
            onChange={e => setStatus(e.target.checked ? 'active' : 'inactive')}
          />
          <span className="ms-2">{status === 'active' ? 'Active' : 'Inactive'}</span>
        </div>
        <button className="btn btn-primary me-2" type="submit">Save</button>
        <button className="btn btn-secondary me-2" type="button" onClick={() => router.push('/pages')}>Cancel</button>
        <button className="btn btn-outline-primary" type="button" onClick={() => setShowPreview(true)}>Preview</button>
      </form>

      {/* Preview Modal */}
      <div
        className="modal fade"
        id="previewModal"
        tabIndex={-1}
        aria-labelledby="previewModalLabel"
        aria-hidden="true"
        ref={previewModalRef}
      >
        <div className="modal-dialog modal-xl modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="previewModalLabel">{title || 'Preview'}</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={() => setShowPreview(false)}
              ></button>
            </div>
            <div className="modal-body">
              <div dangerouslySetInnerHTML={{ __html: content }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
