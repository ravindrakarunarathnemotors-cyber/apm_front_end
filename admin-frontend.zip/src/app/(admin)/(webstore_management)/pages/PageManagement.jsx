'use client'

import React, { useState } from 'react'
import { Button, Card, Row, Col, Alert, Form, Table, Badge, Spinner } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useGetPagesQuery, useCreatePageMutation, useUpdatePageMutation, useDeletePageMutation } from '@/store/features/webstoreApi'
import { useRouter } from 'next/navigation'



const defaultForm = {
  title: '',
  slug: '',
  status: 'active',
}

const PageManagement = () => {
  const { data: pages, isLoading, refetch } = useGetPagesQuery(undefined)
  const [createPage, { isLoading: creating }] = useCreatePageMutation()
  const [updatePage] = useUpdatePageMutation()
  const [deletePage] = useDeletePageMutation()

  const [form, setForm] = useState(defaultForm)
  const [editId, setEditId] = useState(null)
  const [error, setError] = useState('')

  const router = useRouter()
  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.title || !form.slug) {
      setError('Title and slug required')
      return
    }
    try {
      if (editId) {
        await updatePage({ id: editId, ...form }).unwrap()
        Swal.fire('Updated!', 'Page updated successfully.', 'success')
      } else {
        await createPage(form).unwrap()
        Swal.fire('Created!', 'Page created.', 'success')
      }
      setForm(defaultForm)
      setEditId(null)
      setError('')
      refetch()
    } catch (err) {
      setError(err?.data?.error || 'Failed to save page')
    }
  }

  const handleEdit = (page) => {
    setForm({
      title: page.title,
      slug: page.slug,
      status: page.status,
    })
    setEditId(page.id)
    setError('')
  }

  const handleDelete = async (id) => {
    const confirmed = await Swal.fire({
      title: 'Are you sure?',
      text: 'This will permanently delete the page.',
      icon: 'warning',
      showCancelButton: true,
    }).then((r) => r.isConfirmed)
    if (confirmed) {
      await deletePage(id).unwrap()
      Swal.fire('Deleted!', 'Page deleted.', 'success')
      refetch()
    }
  }

  const handleToggleStatus = async (page) => {
    await updatePage({
      id: page.id,
      status: page.status === 'active' ? 'inactive' : 'active',
    }).unwrap()
    refetch()
  }

  return (
    <Row className="justify-content-center mt-4">
      <Col md={12}>
        <Card>
          <Card.Header className="py-2" style={{ backgroundColor: '#e5e8ed', color: 'black' }}>
            <Row className="align-items-center justify-content-between">
              <Col>
                <h4 className="mb-0">Page Management</h4>
              </Col>
            </Row>
          </Card.Header>
          <Card.Body>
            {error && <Alert variant="danger">{error}</Alert>}

            <Form onSubmit={handleSubmit} className="row g-3 mb-3">
              <Form.Group className="col-md-4">
                <Form.Label>Title</Form.Label>
                <Form.Control type="text" name="title" value={form.title || ''} onChange={handleChange} required />
              </Form.Group>
              <Form.Group className="col-md-4">
                <Form.Label>Slug</Form.Label>
                <Form.Control
                  type="text"
                  name="slug"
                  value={form.slug || ''}
                  onChange={handleChange}
                  placeholder="e.g. home, about, contact"
                  required
                />
              </Form.Group>
              <Form.Group className="col-md-4">
                <Form.Label>Status</Form.Label>
                <Form.Select name="status" value={form.status} onChange={handleChange}>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </Form.Select>
              </Form.Group>
              <div className="col-12 d-flex justify-content-end">
                <Button type="submit" variant="primary" disabled={creating}>
                  {editId ? 'Update' : 'Create'}
                </Button>
                {editId && (
                  <Button
                    type="button"
                    className="ms-2"
                    variant="secondary"
                    onClick={() => {
                      setForm(defaultForm)
                      setEditId(null)
                      setError('')
                    }}>
                    Cancel
                  </Button>
                )}
              </div>
            </Form>

            <Table bordered hover responsive>
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Slug</th>
                  <th>Status</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr>
                    <td colSpan={4} className="text-center">
                      <Spinner animation="border" size="sm" /> Loading...
                    </td>
                  </tr>
                )}
                {Array.isArray(pages?.pages) &&
                  pages.pages.map((page) => (
                    <tr key={page.id}>
                      <td>{page.title}</td>
                      <td>/{page.slug}</td>
                      <td>
                        <Badge
                          bg={page.status === 'active' ? 'success' : 'secondary'}
                          style={{ cursor: 'pointer' }}
                          onClick={() => handleToggleStatus(page)}>
                          {page.status}
                        </Badge>
                      </td>
                      <td>
                        <Button variant="info" size="sm" onClick={() => handleEdit(page)}>
                          Edit Page Details
                        </Button>{' '}
                        <Button variant="secondary" size="sm" onClick={() => (window.location.href = `/page_elementor?page_id=${page.id}`)}>
                          Edit Layout
                        </Button>{' '}
                        <Button variant="danger" size="sm" onClick={() => handleDelete(page.id)}>
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))}
                {!isLoading && (!Array.isArray(pages?.pages) || pages.pages.length === 0) && (
                  <tr>
                    <td colSpan={4} className="text-center">
                      No pages found.
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>
          </Card.Body>
        </Card>
      </Col>
    </Row>
  )
}

export default PageManagement
