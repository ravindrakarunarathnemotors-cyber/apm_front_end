import dynamic from 'next/dynamic'

export const metadata = {
  title: 'PageManagement',
}

const PageManagement = dynamic(() => import('./PageManagement'), { ssr: false })

export default function PageManagementPage() {
  return <PageManagement />
}