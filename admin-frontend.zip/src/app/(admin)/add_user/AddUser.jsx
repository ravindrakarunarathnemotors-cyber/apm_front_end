'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  useAddUserMutation,
  useGetRolesMutation,
  useCheckUsernameMutation,
  useGetBranchMutation,
  useGetActiveBranchesQuery,
} from '../../../store/features/apiSlice'
import { Button, Col, Form, FormControl, FormLabel, FormSelect, Row, ListGroup } from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { useState, useEffect, useRef, useCallback } from 'react'

import Swal from 'sweetalert2'
import ResponseCache from 'next/dist/server/response-cache'
import { Icon } from '@iconify/react/dist/iconify.js'
import { debounce } from 'lodash'

const client_id = 1

const schema = yup.object({
  username: yup.string().required('Username is required'),
  firstName: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'First name can only contain letters')
    .required('First Name is required'),

  lastName: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'Last name can only contain letters')
    .required('Last Name is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  phone: yup
    .string()
    .matches(/^\d{10,11}$/, 'Phone number must be between 10 and 11 digits')
    .required('Phone is required'),

  password: yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  role: yup.string().required('Role is required'),
})

const AddUser = () => {
  const [query, setQuery] = useState('')
  const [fetchBranch, { data: branchs, isLoading, isError }] = useGetBranchMutation()
  const [addUser, { isLoading: isAddingUser, isError: isAddUserError, error }] = useAddUserMutation()
  const [fetchRoles, { data: roles, isLoading: isRolesLoading, isError: isRolesError }] = useGetRolesMutation()
  const { data: branches, isLoading: isBranchLoading, isError: isBranchError } = useGetActiveBranchesQuery()
  const fetchRolesCallback = useCallback(() => {
    fetchRoles()
  }, [fetchRoles])

  const [showDropdown, setShowDropdown] = useState(false)
  const dropdownRef = useRef(null)
  const [isTyping, setIsTyping] = useState(false) // Track typing state
  const [selectedBranch, setSelectedBranch] = useState(null) // ✅ Added state for selectedHub

  const [checkUsername, { data: usernameExists, isLoading: isChecking }] = useCheckUsernameMutation()
  const [usernameError, setUsernameError] = useState('')
  const branchOptions =
    branches?.map((b) => ({
      value: b.branch_id,
      label: `${b.branch_name}  #${b.branch_id}`,
    })) || []
  useEffect(() => {
    const safeQuery = typeof query === 'string' ? query : ''
    if (safeQuery.length > 1 && isTyping) {
      setShowDropdown(true)
      const debounce = setTimeout(() => {
        fetchBranch(query)
      }, 500) // Debounce API calls

      return () => clearTimeout(debounce)
    } else {
      setShowDropdown(false)
    }
  }, [query, fetchBranch, isTyping])

  const handleSelectBranch = (branch) => {
    setQuery(branch.branch_name)
    setSelectedBranch(branch.branch_id)
    setShowDropdown(false)
    setIsTyping(false)
    setValue('branch', branch.branch_id, { shouldValidate: true })
  }

  const handleInputChange = (e) => {
    if (selectedBranch) return // Prevent further fetching if a hub is already selected
    setQuery(e.target.value)
    setIsTyping(true)
    setShowDropdown(true)
  }

  // Click outside to hide dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  useEffect(() => {
    fetchRolesCallback()
  }, [fetchRolesCallback])

  
  const [successMessage, setSuccessMessage] = useState('')

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue, // Add setValue to manually set hub ID
  } = useForm({ resolver: yupResolver(schema), mode: 'onChange' })

  
  

  const handleUsernameChange = debounce(async (e) => {
    const username = e.target.value.trim()
    if (username.length > 2) {
      try {
        const response = await checkUsername(username).unwrap()
        if (response.exists) {
          setUsernameError('Username already exists')
        } else {
          setUsernameError('')
        }
      } catch (error) {
        setUsernameError('Error checking username')
      }
    } else {
      setUsernameError('')
    }
  }, 500)

  const onSubmit = async (data) => {
    // 🔥 Get readable values
    const selectedRole = roles?.find((r) => r.id == data.role)
    const selectedBranchObj = branches?.find((b) => b.branch_id == data.branch)

    const roleName = selectedRole?.role_name || '-'
    const branchName = selectedBranchObj ? `${selectedBranchObj.branch_name} (#${selectedBranchObj.branch_id})` : '-'

    // 🔥 SHOW SUMMARY CONFIRMATION
    const result = await Swal.fire({
      title: 'Confirm User Creation',
      html: `
      <div style="text-align:left; font-size:14px">
        <b>Username:</b> ${data.username}<br/>
        <b>Name:</b> ${data.firstName} ${data.lastName}<br/>
        <b>Email:</b> ${data.email}<br/>
        <b>Phone:</b> ${data.phone}<br/>
        <b>Role:</b> ${roleName}<br/>
        <b>Branch:</b> ${branchName}
      </div>
    `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, Add User',
      cancelButtonText: 'Cancel',
    })

    // ❌ Stop if cancelled
    if (!result.isConfirmed) return

    // ✅ Continue original logic
    try {


      const requestdata = { ...data, client_id }
      console.log('Submitting to backend:', requestdata)

      const response = await addUser(requestdata).unwrap()

      if (response.message == 'sameuser') {
        Swal.fire({
          title: 'Username Exist',
          text: 'Same User Found',
          icon: 'error',
        })
      } else {
        Swal.fire({
          title: 'Success!',
          text: 'User added successfully!',
          icon: 'success',
        })

        reset()
        setSelectedBranch(null)
        setValue('branch', '')
        setQuery('')
      }
    } catch (err) {
      Swal.fire({
        title: 'Error',
        text: 'Failed to add user.',
        icon: 'error',
      })
    }
  }
  //   useEffect(() => {
  //     if (!selectedHub) {
  //         setQuery(""); // Clear input field if no hub is selected
  //     }
  // }, [selectedHub]);
  return (
    <Row className="justify-content-center">
      <Col>
        <ComponentContainerCard title="Add New User">
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row className="my-3">
              <Col lg="12" className="d-flex flex-column gap-2">
                <Row>
                  <Col md="6">
                    <FormLabel className="col-sm-2 col-form-label text-start">Username</FormLabel>
                    <Col sm="12">
                      <FormControl type="username" {...register('username')} placeholder="Enter Username" onChange={handleUsernameChange} />
                      <p className="text-danger">{errors.username?.message || usernameError}</p>
                    </Col>
                  </Col>
                  <Col md="6">
                    <FormLabel className="col-sm-2 col-form-label text-start">Password</FormLabel>
                    <Col sm="12">
                      <FormControl type="password" {...register('password')} placeholder="Enter password" />
                      <p className="text-danger">{errors.password?.message}</p>
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col md="6">
                    <FormLabel className="col-sm-2 col-form-label text-start">First Name</FormLabel>
                    <Col sm="12">
                      <FormControl type="text" {...register('firstName')} placeholder="Enter first name" />
                      <p className="text-danger">{errors.firstName?.message}</p>
                    </Col>
                  </Col>
                  <Col md="6">
                    {' '}
                    <FormLabel className="col-sm-2 col-form-label text-start">Last Name</FormLabel>
                    <Col sm="12">
                      <FormControl type="text" {...register('lastName')} placeholder="Enter last name" />
                      <p className="text-danger">{errors.lastName?.message}</p>
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col md="6">
                    <FormLabel className="col-sm-2 col-form-label text-start">Email</FormLabel>
                    <Col sm="12">
                      <FormControl type="email" {...register('email')} placeholder="Enter email" />
                      <p className="text-danger">{errors.email?.message}</p>
                    </Col>
                  </Col>
                  <Col md="6">
                    <FormLabel className="col-sm-12 col-form-label text-start">Mobile Number</FormLabel>

                    <Col sm="12">
                      <FormControl type="tel" {...register('phone')} placeholder="Enter Mobile number 947xxxxxxxx" />
                      <p className="text-danger">{errors.phone?.message}</p>
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col md="6">
                    <FormLabel className="col-sm-2 col-form-label text-start">Select Role</FormLabel>
                    <Col sm="12">
                      <FormSelect {...register('role')}>
                        <option value="">Select Role</option>
                        {isRolesLoading && <option>Loading roles...</option>}
                        {isRolesLoading && <option className="text-danger">Error loading roles</option>}
                        {roles &&
                          roles.map((role) => (
                            <option key={role.id} value={role.id}>
                              {role.role_name}
                            </option>
                          ))}
                      </FormSelect>
                      <p className="text-danger">{errors.role?.message}</p>
                    </Col>
                  </Col>

                  <Col md="6">
                    <Col sm="12">
                      <Col md="6">
                        <FormLabel className="col-sm-2 col-form-label text-start" style={{ whiteSpace: 'nowrap' }}>
                          Select Branch
                        </FormLabel>

                        <FormSelect
                          {...register('branch')}
                          onChange={(e) => {
                            setValue('branch', e.target.value, { shouldValidate: true })
                          }}>
                          <option value="">Select Branch</option>

                          {isBranchLoading && <option>Loading branches...</option>}
                          {isBranchError && <option>Error loading branches</option>}

                          {branchOptions.map((branch) => (
                            <option key={branch.value} value={branch.value}>
                              {branch.label}
                            </option>
                          ))}
                        </FormSelect>

                        <p className="text-danger">{errors.branch?.message}</p>
                      </Col>
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col sm="10" className="offset-sm-2 text-end">
                    <Button className="btn bg-primary border border-primary" type="submit" disabled={isRolesLoading}>
                      <div className="d-flex align-items-center gap-1 px-3">
                        <Icon icon="material-symbols:group-add-rounded" width="20" height="20" />
                        <span>{isRolesLoading ? 'Adding...' : 'Add User'}</span>
                      </div>
                    </Button>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Form>
        </ComponentContainerCard>
      </Col>
    </Row>
  )
}

export default AddUser
