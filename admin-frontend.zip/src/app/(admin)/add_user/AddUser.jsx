'use client'

import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import {
  useAddUserMutation,
  useGetRolesMutation,
  useCheckUsernameMutation,
  useGetBranchMutation,
  useGetActiveBranchesQuery,
} from '../../../store/features/apiSlice'
import { Button, Col, Form, FormControl, FormLabel, FormSelect, Row, ListGroup, Spinner } from 'react-bootstrap'
import ComponentContainerCard from '@/components/ComponentContainerCard'
import { useState, useEffect, useRef, useCallback } from 'react'

import Swal from 'sweetalert2'
import ResponseCache from 'next/dist/server/response-cache'
import { Icon } from '@iconify/react/dist/iconify.js'
import { debounce } from 'lodash'
import { useRouter } from 'next/navigation'
import axiosInstance from '@/lib/axiosInstance';
import useRefreshToken from '@/hooks/useRefreshToken'

const client_id = 1

const schema = yup.object({
  username: yup.string().required('Username is required'),
  firstName: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'First name can only contain letters')
    .required('First Name is required'),

  lastName: yup
    .string()
    .matches(/^[A-Za-z\s]+$/, 'Last name can only contain letters')
    .required('Last Name is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  phone: yup
    .string()
    .matches(/^\d{10,11}$/, 'Phone number must be between 10 and 11 digits')
    .required('Phone is required'),

  password: yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  role: yup.string().required('Role is required'),
})



const AddUser = () => {
  const [query, setQuery] = useState('')
  const [userMode, setUserMode] = useState('employee-existing')
  const [employee, setEmployee] = useState('')
  const [allEmployees, setAllEmployees] = useState([])
  const [loading, setLoading] = useState(false)
  const [show, setShow] = useState(false)

  const [usernameError, setUsernameError] = useState('')
  const [showDropdown, setShowDropdown] = useState(false)
  const [isTyping, setIsTyping] = useState(false) // Track typing state
  const [selectedBranch, setSelectedBranch] = useState(null) // ✅ Added state for selectedHub

  const dropdownRef = useRef(null)
  const router = useRouter()

  const [fetchBranch, { data: branchs, isLoading, isError }] = useGetBranchMutation()
  const [addUser, { isLoading: isAddingUser, isError: isAddUserError, error }] = useAddUserMutation()
  const [fetchRoles, { data: roles, isLoading: isRolesLoading, isError: isRolesError }] = useGetRolesMutation()
  const { data: branches, isLoading: isBranchLoading, isError: isBranchError } = useGetActiveBranchesQuery()
  const fetchRolesCallback = useCallback(() => {
    fetchRoles()
  }, [fetchRoles])
  const [checkUsername, { data: usernameExists, isLoading: isChecking }] = useCheckUsernameMutation()


  const branchOptions = branches?.map((b) => ({
    value: b.branch_id,
    label: `${b.branch_name}  #${b.branch_id}`,
  })) || []

  useEffect(() => {
    const safeQuery = typeof query === 'string' ? query : ''
    if (safeQuery.length > 1 && isTyping) {
      setShowDropdown(true)
      const debounce = setTimeout(() => {
        fetchBranch(query)
      }, 500) // Debounce API calls

      return () => clearTimeout(debounce)
    } else {
      setShowDropdown(false)
    }
  }, [query, fetchBranch, isTyping])

  // Click outside to hide dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  useEffect(() => {
    fetchRolesCallback()
  }, [fetchRolesCallback])

  useEffect(() => {
    fetchEmployees()
    handlepermission()
  }, [])

  const fetchEmployees = async () => {

    try {
      const response = await axiosInstance.get(
        `/api/user/get_employee`
      )

      if (response.status === 200) {
        setAllEmployees(response.data.result)
      }
    } catch (error) {
      console.error('Search failed:', error)
    }
  }

  const handlepermission = async () => {

    try {
      setLoading(true)
      const response = await axiosInstance.get(`/common/getPermissionforuseremployee`);

      if (response.status === 200) {
        const newarray = response.data.data
        const check = newarray.includes(92)

        setShow(check)
        if (!check) setUserMode('user-only') // Set default mode based on permission
      }

    } catch (error) {
      console.log(error)
    } finally {
      setLoading(false)
    }
  };


  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue, // Add setValue to manually set hub ID
  } = useForm({ resolver: yupResolver(schema), mode: 'onChange' })

  const handleUsernameChange = debounce(async (e) => {
    const username = e.target.value.trim()
    if (username.length > 2) {
      try {
        const response = await checkUsername(username).unwrap()
        if (response.exists) {
          setUsernameError('Username already exists')
        } else {
          setUsernameError('')
        }
      } catch (error) {
        setUsernameError('Error checking username')
      }
    } else {
      setUsernameError('')
    }
  }, 500)

  const onSubmit = async (data) => {
    // 🔥 Get readable values
    const selectedRole = roles?.find((r) => r.id == data.role)
    const selectedBranchObj = branches?.find((b) => b.branch_id == data.branch)

    const roleName = selectedRole?.role_name || '-'
    const branchName = selectedBranchObj ? `${selectedBranchObj.branch_name} (#${selectedBranchObj.branch_id})` : '-'

    // 🔥 SHOW SUMMARY CONFIRMATION
    const result = await Swal.fire({
      title: 'Confirm User Creation',
      html: `
      <div style="text-align:left; font-size:14px">
        <b>Username:</b> ${data.username}<br/>
        <b>Name:</b> ${data.firstName} ${data.lastName}<br/>
        <b>Email:</b> ${data.email}<br/>
        <b>Phone:</b> ${data.phone}<br/>
        <b>Role:</b> ${roleName}<br/>
        <b>Branch:</b> ${branchName}
      </div>
    `,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, Add User',
      cancelButtonText: 'Cancel',
    })

    // ❌ Stop if cancelled
    if (!result.isConfirmed) return

    // ✅ Continue original logic
    try {


      const requestdata = { ...data, client_id, employee }
      console.log('Submitting to backend:', requestdata)

      const response = await addUser(requestdata).unwrap()

      if (response.message == 'sameuser') {
        Swal.fire({
          title: 'Username Exist',
          text: 'Same User Found',
          icon: 'error',
        })
      } else {
        Swal.fire({
          title: 'Success!',
          text: 'User added successfully!',
          icon: 'success',
        })

        reset()
        setSelectedBranch(null)
        setValue('branch', '')
        setQuery('')
        fetchEmployees()
      }
    } catch (err) {
      console.log(err)
      if (err.status === 460) {
        Swal.fire({
          icon: "warning",
          iconColor: "#f59e0b", // Modern amber/warning color
          title: '<span style="font-family: sans-serif; font-weight: 600; color: #1f2937;">User Limit Reached</span>',
          html: `
                <div style="text-align: center; color: #4b5563; font-family: sans-serif; font-size: 15px; line-height: 1.6; padding: 0 10px;">
                  <p style="margin: 0;">You have reached the maximum number of users allowed for your current plan.</p>
                  <p style="margin: 12px 0 0 0; font-weight: 600; color: #111827;">
                    Please contact your administrator to upgrade your subscription.
                  </p>
                </div>
              `,
          confirmButtonText: "Got it",
          confirmButtonColor: "#1f2937", // Pure inline background color
          background: "#ffffff",
          // This inline style rounds the default button beautifully
          didOpen: () => {
            const confirmButton = Swal.getConfirmButton();
            if (confirmButton) {
              confirmButton.style.borderRadius = "8px";
              confirmButton.style.padding = "10px 24px";
              confirmButton.style.fontSize = "14px";
              confirmButton.style.fontFamily = "sans-serif";
            }
          }
        });
        return;
      }

      Swal.fire({
        title: 'Error',
        text: 'Failed to add user.',
        icon: 'error',
      })
    }
  }

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  return (
    <div>


      {/* Main Form Card Container */}
      <ComponentContainerCard title="Add New User">

        {/* User Type Selection Group */}
        {show && (
          <div className="mb-4">
            <FormLabel className="text-secondary fw-semibold small text-uppercase mb-3 d-block tracking-wide">
              User Creation Type
            </FormLabel>

            <div className="d-flex gap-3 flex-wrap">
              {/* Mode Card: Existing Employee */}
              <div
                onClick={() => {
                  setUserMode('employee-existing')
                  reset()
                  setEmployee(null)
                }}
                className={`border rounded-3 p-3 flex-grow-1 shadow-sm transition-all ${userMode === 'employee-existing'
                  ? 'border-primary bg-primary bg-opacity-10 text-primary'
                  : 'bg-white border-light-subtle text-dark'
                  }`}
                style={{
                  cursor: 'pointer',
                  minWidth: '240px',
                  transition: 'all 0.2s ease-in-out',
                  transform: userMode === 'employee-existing' ? 'scale(1.01)' : 'none'
                }}
              >
                <div className="d-flex align-items-center gap-2 mb-1">
                  <span style={{ fontSize: '1.2rem' }}>👤</span>
                  <h6 className="mb-0 fw-bold">Existing Employee</h6>
                </div>
                <small className={userMode === 'employee-existing' ? 'text-primary-emphasis' : 'text-muted'}>
                  Create login credentials for an active employee
                </small>
              </div>

              {/* Mode Card: User Only */}
              <div
                onClick={() => {
                  setUserMode('user-only')
                  reset()
                  setEmployee(null)
                }}
                className={`border rounded-3 p-3 flex-grow-1 shadow-sm transition-all ${userMode === 'user-only'
                  ? 'border-primary bg-primary bg-opacity-10 text-primary'
                  : 'bg-white border-light-subtle text-dark'
                  }`}
                style={{
                  cursor: 'pointer',
                  minWidth: '240px',
                  transition: 'all 0.2s ease-in-out',
                  transform: userMode === 'user-only' ? 'scale(1.01)' : 'none'
                }}
              >
                <div className="d-flex align-items-center gap-2 mb-1">
                  <span style={{ fontSize: '1.2rem' }}>🔑</span>
                  <h6 className="mb-0 fw-bold">User Only</h6>
                </div>
                <small className={userMode === 'user-only' ? 'text-primary-emphasis' : 'text-muted'}>
                  Create an independent system user account
                </small>
              </div>

              {/* Mode Card: Navigation Shortcut */}
              <div
                onClick={() => router.push('/add_employee')}
                className="border border-light-subtle rounded-3 p-3 flex-grow-1 bg-white shadow-sm hover-actions"
                style={{
                  cursor: 'pointer',
                  minWidth: '240px',
                  transition: 'all 0.2s ease-in-out',
                }}
              >
                <div className="d-flex align-items-center gap-2 mb-1 text-success">
                  <span style={{ fontSize: '1.2rem' }}>➕</span>
                  <h6 className="mb-0 fw-bold">Create Employee</h6>
                </div>
                <small className="text-muted">
                  Go to full employee onboarding directory page
                </small>
              </div>
            </div>
          </div>
        )}

        {/* Employee Selection Dropdown Area */}
        {userMode === 'employee-existing' && (
          <div className="mb-4 p-3 bg-light rounded-3 border border-light-subtle animate-fade-in">
            <FormLabel className="fw-semibold text-secondary small text-uppercase mb-2">
              Select Employee Profile
            </FormLabel>

            <FormSelect
              className="form-control-lg border-light-subtle bg-white shadow-sm"
              onChange={(e) => {
                const employee = allEmployees.find(
                  (emp) => emp.employee_id === Number(e.target.value)
                )

                if (!employee) return

                setEmployee(employee.employee_id)

                setValue('firstName', employee.first_name)
                setValue('lastName', employee.last_name)
                setValue('email', employee.email)
                setValue('phone', employee.contact_no)
              }}
            >
              <option value="">Choose an employee from records...</option>

              {allEmployees.map((employee) => (
                <option key={employee.employee_id} value={employee.employee_id}>
                  ID: {employee.employee_id} — {employee.first_name} {employee.last_name}
                </option>
              ))}
            </FormSelect>
          </div>
        )}

        {/* Structured Dynamic Content Form */}
        {(userMode === 'user-only' || (userMode === 'employee-existing' && employee)) && (
          <Form onSubmit={handleSubmit(onSubmit)} className="mt-2 animate-fade-in">
            <Row className="g-4">

              {/* Section 1: Security Credentials */}
              <Col xs={12}>
                <div className="d-flex align-items-center gap-2 pb-2 mb-1 border-bottom border-light-subtle">
                  <Icon icon="material-symbols:lock-outline" className="text-secondary" width="18" height="18" />
                  <span className="fw-bold text-dark text-uppercase small tracking-wide">Account Credentials</span>
                </div>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Username</FormLabel>
                <FormControl
                  type="text"
                  placeholder="Enter unique username"
                  autoComplete="new-password"
                  className="border-light-subtle shadow-sm py-2"
                  {...register('username')}
                  onChange={handleUsernameChange}
                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {(errors.username?.message || usernameError) && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.username?.message || usernameError}
                    </>
                  )}
                </p>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Password</FormLabel>
                <FormControl
                  type="password"
                  placeholder="Create secure password"
                  autoComplete="new-password"
                  className="border-light-subtle shadow-sm py-2"
                  {...register('password')}
                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.password?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.password?.message}
                    </>
                  )}
                </p>
              </Col>

              {/* Section 2: Personal Profile */}
              <Col xs={12} className="mt-4">
                <div className="d-flex align-items-center gap-2 pb-2 mb-1 border-bottom border-light-subtle">
                  <Icon icon="material-symbols:badge-outline" className="text-secondary" width="18" height="18" />
                  <span className="fw-bold text-dark text-uppercase small tracking-wide">Personal Information</span>
                </div>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">First Name</FormLabel>
                <FormControl
                  className="border-light-subtle shadow-sm py-2 bg-body-secondary"
                  placeholder="First name profile value"
                  {...register('firstName')}
                  disabled={userMode === 'employee-existing'}
                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.firstName?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.firstName?.message}
                    </>
                  )}
                </p>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Last Name</FormLabel>
                <FormControl
                  className="border-light-subtle shadow-sm py-2 bg-body-secondary"
                  placeholder="Last name profile value"
                  {...register('lastName')}
                  disabled={userMode === 'employee-existing'}
                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.lastName?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.lastName?.message}
                    </>
                  )}
                </p>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Email Address</FormLabel>
                <FormControl
                  type="email"
                  placeholder="example@domain.com"
                  className="border-light-subtle shadow-sm py-2 bg-body-secondary"
                  {...register('email')}

                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.email?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.email?.message}
                    </>
                  )}
                </p>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Mobile Number</FormLabel>
                <FormControl
                  placeholder="+1 (555) 000-0000"
                  className="border-light-subtle shadow-sm py-2 bg-body-secondary"
                  {...register('phone')}

                />
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.phone?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.phone?.message}
                    </>
                  )}
                </p>
              </Col>

              {/* Section 3: Access Scope / Assignment */}
              <Col xs={12} className="mt-4">
                <div className="d-flex align-items-center gap-2 pb-2 mb-1 border-bottom border-light-subtle">
                  <Icon icon="material-symbols:universal-local-outline" className="text-secondary" width="18" height="18" />
                  <span className="fw-bold text-dark text-uppercase small tracking-wide">Access & Assignment</span>
                </div>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Assign Security Role</FormLabel>
                <FormSelect {...register('role')} className="border-light-subtle shadow-sm py-2">
                  <option value="">Select System Role Scope</option>
                  {roles?.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.role_name}
                    </option>
                  ))}
                </FormSelect>
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.role?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.role?.message}
                    </>
                  )}
                </p>
              </Col>

              <Col md={6}>
                <FormLabel className="form-label text-secondary fw-medium small mb-1">Assign Operational Branch</FormLabel>
                <FormSelect
                  {...register('branch')}
                  className="border-light-subtle shadow-sm py-2"
                  onChange={(e) =>
                    setValue(
                      'branch',
                      e.target.value,
                      { shouldValidate: true }
                    )
                  }
                >
                  <option value="">Select Branch Base</option>
                  {branchOptions.map((branch) => (
                    <option key={branch.value} value={branch.value}>
                      {branch.label}
                    </option>
                  ))}
                </FormSelect>
                <p className="text-danger small mt-1 mb-0 d-flex align-items-center gap-1">
                  {errors.branch?.message && (
                    <>
                      <Icon icon="material-symbols:error-outline" width="14" height="14" />
                      {errors.branch?.message}
                    </>
                  )}
                </p>
              </Col>

              {/* Submission Row */}
              <Col md={12} className="text-end mt-4 pt-2">
                <Button
                  type="submit"
                  className="btn btn-primary px-4 py-2 shadow d-inline-flex align-items-center justify-content-center"
                  style={{ minWidth: '140px', borderRadius: '6px' }}
                >
                  <Icon
                    icon="material-symbols:group-add-rounded"
                    width="20"
                    height="20"
                  />
                  <span className="ms-2 fw-medium">Add User Account</span>
                </Button>
              </Col>

            </Row>
          </Form>
        )}
      </ComponentContainerCard>
    </div>
  )
}

export default AddUser
