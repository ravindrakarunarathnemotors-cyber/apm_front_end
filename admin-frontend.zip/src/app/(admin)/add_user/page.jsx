import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Add User',
}

const AddUser = dynamic(() => import('./AddUser'), { ssr: false })

export default function AddUserPage() {
  return <AddUser />
}