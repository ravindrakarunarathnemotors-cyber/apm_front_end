'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  Row, Col, Card, CardHeader, CardBody, CardTitle,
  Form, FormGroup, FormLabel, Button, Table, Spinner,
  Badge, Pagination,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import {
  useGetDeletedJobsQuery,
  useRestoreJobMutation,     
} from '@/store/features/serviceSlice'

// ─── Status helpers (same as joblist) ────────────────────────────────────────
function StatusDot({ status }) {
  const colorMap = {
    PENDING: '#ffc107', IN_PROGRESS: '#0d6efd',
    COMPLETED: '#198754', CANCELLED: '#dc3545', ON_HOLD: '#f97316',
  }
  const color = colorMap[status] || '#6c757d'
  return (
    <span className="d-flex align-items-center gap-1"
      style={{ fontSize: '0.82rem', fontWeight: 500, color: '#374151' }}>
      <span style={{
        width: 8, height: 8, borderRadius: '50%',
        backgroundColor: color, display: 'inline-block',
      }} />
      {status?.replace('_', ' ')}
    </span>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function DeletedJobList() {
  const router = useRouter()

  const [currentPage, setCurrentPage] = useState(1)
  const [keyword,     setKeyword]     = useState('')
  const [fromDate,    setFromDate]    = useState('')
  const [toDate,      setToDate]      = useState('')

  const logsPerPage = 25

  const { data: deletedJobsData, isLoading, refetch } = useGetDeletedJobsQuery()
  const [restoreJob] = useRestoreJobMutation?.() ?? [async () => {}, {}]

  const allJobs = (deletedJobsData?.data ?? []).filter((job) => {
    const kw = keyword.trim().toLowerCase()
    const matchKw  = !kw || job.job_name?.toLowerCase().includes(kw) || String(job.id).includes(kw)
    const deletedAt = job.deleted_at ? new Date(job.deleted_at) : null
    const matchFrom = !fromDate || (deletedAt && deletedAt >= new Date(fromDate))
    const matchTo   = !toDate   || (deletedAt && deletedAt <= new Date(toDate + 'T23:59:59'))
    return matchKw && matchFrom && matchTo
  })

  const totalPages = Math.ceil(allJobs.length / logsPerPage) || 1
  const jobs = allJobs.slice((currentPage - 1) * logsPerPage, currentPage * logsPerPage)

  const handleSearch = () => setCurrentPage(1)

  const handleRestore = async (id, name) => {
    const result = await Swal.fire({
      icon: 'question',
      title: 'Restore Job?',
      text: `"${name}" will be restored and visible in the Job List.`,
      showCancelButton: true,
      confirmButtonColor: '#198754',
      confirmButtonText: 'Restore',
    })
    if (!result.isConfirmed) return
    try {
      await restoreJob(id).unwrap()
      Swal.fire({
        icon: 'success', title: 'Job restored',
        toast: true, timer: 1500, position: 'top-end', showConfirmButton: false,
      })
      refetch()
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to restore job' })
    }
  }

  const formatDate   = (d) => d
    ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    : '-'
  const formatAmount = (v) => { const n = Number(v); return isNaN(n) ? '0.00' : n.toFixed(2) }

  return (
    <Row className="justify-content-center">
      <Col>
        <Card>
          {/* ── Header ── */}
          <CardHeader className="py-3 bg-light">
            <Row className="align-items-center justify-content-between">
              <Col>
                <CardTitle as="h4" className="mb-0 d-flex align-items-center gap-2">
                  <Icon icon="mdi:trash-can-outline" width={22} style={{ color: '#dc3545' }} />
                  Deleted Jobs
                </CardTitle>
              </Col>
              <Col xs="auto">
                <Button
                  variant="outline-secondary"
                  onClick={() => router.push('/job-list')}
                  className="d-flex align-items-center gap-1"
                >
                  <Icon icon="mdi:arrow-left" width={16} /> Back to Job List
                </Button>
              </Col>
            </Row>
          </CardHeader>

          <CardBody>
            {/* ── Filters ── */}
            <Form className="row g-1 mb-3">
              <FormGroup className="col-md-6">
                <FormLabel>Keyword</FormLabel>
                <Form.Control
                  type="text"
                  placeholder="Search by job name or ID…"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  style={{ borderRadius: '999px' }}
                />
              </FormGroup>
              <FormGroup className="col-md-4">
                <div className="row g-1">
                  <div className="col-6">
                    <FormLabel>Deleted From</FormLabel>
                    <Form.Control type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
                  </div>
                  <div className="col-6">
                    <FormLabel>Deleted To</FormLabel>
                    <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                  </div>
                </div>
              </FormGroup>
              <FormGroup className="col-md-2 d-flex align-items-end">
                <Button
                  className="bg-primary border border-primary flex-grow-1"
                  onClick={handleSearch}
                >
                  Search
                </Button>
              </FormGroup>
            </Form>

            {/* ── Table ── */}
            <Table striped bordered hover responsive>
              <thead className="table-light">
                <tr>
                  <th>ID</th>
                  <th>Created</th>
                  <th>Deleted At</th>
                  <th>Job Name</th>
                  <th>Customer</th>
                  <th>Assigned To</th>
                  <th>Status</th>
                  <th className="text-end">Grand Total</th>
                  <th className="text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan="9" className="text-center">
                      <Spinner animation="border" size="sm" /> Loading…
                    </td>
                  </tr>
                ) : jobs.length > 0 ? (
                  jobs.map((job) => {
                    const assignedUsers = (() => {
                      try {
                        return Array.isArray(job.assigned_users)
                          ? job.assigned_users
                          : JSON.parse(job.assigned_users || '[]')
                      } catch { return [] }
                    })()

                    return (
                      <tr key={job.id} style={{ opacity: 0.82 }}>
                        {/* ID */}
                        <td style={{ fontWeight: 600, color: '#dc3545' }}>#{job.id}</td>

                        {/* Created */}
                        <td style={{ fontSize: '0.85rem' }}>{formatDate(job.created_at)}</td>

                        {/* Deleted At */}
                        <td style={{ fontSize: '0.85rem', color: '#dc3545' }}>
                          {formatDate(job.deleted_at)}
                        </td>

                        {/* Job Name */}
                        <td style={{ fontWeight: 600 }}>{job.job_name}</td>

                        {/* Customer */}
                        <td style={{ fontSize: '0.83rem' }}>
                          {job.customer_name ? (
                            <>
                              <div className="fw-semibold">{job.customer_name}</div>
                              <div className="text-muted" style={{ fontSize: '0.72rem' }}>
                                {job.customer_phone || ''}
                              </div>
                            </>
                          ) : (
                            <span style={{ color: '#d1d5db' }}>—</span>
                          )}
                        </td>

                        {/* Assigned Users */}
                        <td>
                          {assignedUsers.length > 0 ? (
                            <div className="d-flex flex-wrap gap-1">
                              {assignedUsers.slice(0, 2).map((u) => (
                                <span key={u.id} style={{
                                  background: '#f3f4f6', borderRadius: 20,
                                  padding: '2px 8px', fontSize: '0.72rem', fontWeight: 500,
                                }}>
                                  {u.name}
                                </span>
                              ))}
                              {assignedUsers.length > 2 && (
                                <span style={{ fontSize: '0.72rem', color: '#9ca3af' }}>
                                  +{assignedUsers.length - 2}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span style={{ color: '#d1d5db', fontSize: '0.78rem' }}>—</span>
                          )}
                        </td>

                        {/* Status */}
                        <td><StatusDot status={job.status} /></td>

                        {/* Grand Total */}
                        <td className="text-end" style={{ fontWeight: 600 }}>
                          {formatAmount(job.grand_total)}
                        </td>

                        {/* Actions */}
                        <td className="text-end">
                          <div className="d-flex justify-content-end align-items-center gap-1 flex-wrap">
                            {/* Restore */}
                            <Button
                              onClick={() => handleRestore(job.id, job.job_name)}
                              style={{
                                padding: '0.25rem 0.5rem', fontSize: '0.65rem',
                                height: 28, borderRadius: 14,
                                backgroundColor: '#198754', borderColor: '#198754',
                                color: '#fff', display: 'flex', alignItems: 'center', gap: 3,
                              }}
                            >
                              <Icon icon="mdi:restore" width={12} /> Restore
                            </Button>
                          </div>
                        </td>
                      </tr>
                    )
                  })
                ) : (
                  <tr>
                    <td colSpan="9" className="text-center text-muted">
                      No deleted jobs found
                    </td>
                  </tr>
                )}
              </tbody>
            </Table>

            {/* ── Pagination ── */}
            {totalPages > 1 && (
              <div className="d-flex justify-content-end mt-3">
                <Pagination>
                  <Pagination.Item
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(1)}
                  >
                    First
                  </Pagination.Item>
                  <Pagination.Prev
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage((p) => p - 1)}
                  />
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let start = Math.max(1, currentPage - 2)
                    if (start + 4 > totalPages) start = Math.max(1, totalPages - 4)
                    const page = start + i
                    return page <= totalPages ? (
                      <Pagination.Item
                        key={page}
                        active={page === currentPage}
                        onClick={() => setCurrentPage(page)}
                      >
                        {page}
                      </Pagination.Item>
                    ) : null
                  })}
                  <Pagination.Next
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage((p) => p + 1)}
                  />
                  <Pagination.Item
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(totalPages)}
                  >
                    Last
                  </Pagination.Item>
                </Pagination>
              </div>
            )}
          </CardBody>
        </Card>
      </Col>
    </Row>
  )
}
