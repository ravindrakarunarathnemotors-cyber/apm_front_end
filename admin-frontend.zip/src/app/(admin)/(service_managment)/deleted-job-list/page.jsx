import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Delete Job List - Service Management',
}

// This must match the filename 'deleted-job-list.jsx' exactly
const DeleteJobList = dynamic(() => import('./deleted-job-list'), { ssr: false })

export default function DeleteJobListPage() {
  return <DeleteJobList />
}