import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Job Dashboard - Service Management',
}


const JobDashboard = dynamic(() => import('./jobdashboard'), { ssr: false })

export default function JobListPage() {
  return <JobDashboard />
}