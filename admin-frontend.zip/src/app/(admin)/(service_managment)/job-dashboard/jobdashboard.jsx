'use client'

import React, { useMemo, useState, useEffect, useRef } from 'react'

// ── ⚠️  CHANGE THIS IMPORT to match your actual slice path ──────────────────
import { useGetAllJobsQuery } from '@/store/features/serviceSlice'
// ────────────────────────────────────────────────────────────────────────────

// ── DATE HELPERS ─────────────────────────────────────────────────────────────
function daysBetween(dateStr) {
  if (!dateStr) return 0
  const created = new Date(dateStr)
  const now = new Date()
  return Math.floor((now - created) / (1000 * 60 * 60 * 24))
}

function todayLabel() {
  return new Date().toLocaleDateString('en-GB', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  })
}


const DEFAULT_SLA = 7
// ────────────────────────────────────────────────────────────────────────────
const STATUS_CFG = {
  PENDING:     { label: 'Pending',     color: '#EF9F27', bg: '#FAEEDA', tc: '#633806' },
  IN_PROGRESS: { label: 'In progress', color: '#378ADD', bg: '#E6F1FB', tc: '#0C447C' },
  COMPLETED:   { label: 'Completed',   color: '#1D9E75', bg: '#EAF3DE', tc: '#27500A' },
  ON_HOLD:     { label: 'On hold',     color: '#D4537E', bg: '#FBEAF0', tc: '#4B1528' },
  CANCELLED:   { label: 'Cancelled',   color: '#888780', bg: '#F1EFE8', tc: '#444441' },
}

// ── AGE BUCKETS (days) ────────────────────────────────────────────────────────
const BUCKETS = [
  { lbl: '0–3 days',  max: 3,   color: '#1D9E75' },
  { lbl: '4–5 days',  max: 5,   color: '#378ADD' },
  { lbl: '6–10 days', max: 10,  color: '#EF9F27' },
  { lbl: '11–20 days',max: 20,  color: '#D4537E' },
  { lbl: '21+ days',  max: 9999,color: '#A32D2D' },
]

function getBucket(days) {
  return BUCKETS.find(b => days <= b.max) ?? BUCKETS[BUCKETS.length - 1]
}

// ── AVATAR COLORS ─────────────────────────────────────────────────────────────
const AVATAR_COLORS = ['#378ADD', '#1D9E75', '#EF9F27', '#D4537E', '#a855f7', '#14b8a6', '#f97316', '#0ea5e9']

function getInitials(name = '') {
  const parts = name.trim().split(' ')
  return (parts[0]?.[0] ?? '') + (parts[1]?.[0] ?? '')
}

// ── ICONS ─────────────────────────────────────────────────────────────────────
const IconUsers = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
)
const IconClock = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
  </svg>
)
const IconCheck = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
    <polyline points="16 11 18 13 22 9"/>
  </svg>
)
const IconBriefcase = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="7" width="20" height="14" rx="2"/>
    <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
  </svg>
)
const IconLoader = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"
    style={{ animation: 'spin 1s linear infinite' }}>
    <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
  </svg>
)

// ── CHART COMPONENT (using canvas) ────────────────────────────────────────────
function WorkloadChart({ users }) {
  const canvasRef = useRef(null)
  const chartRef  = useRef(null)

  useEffect(() => {
    if (!canvasRef.current || !users.length) return

    import('chart.js/auto').then(({ default: Chart }) => {
      if (chartRef.current) chartRef.current.destroy()
      chartRef.current = new Chart(canvasRef.current, {
        type: 'bar',
        data: {
          labels: users.map(u => u.name.split(' ')[0]),
          datasets: [
            { label: 'Pending',     data: users.map(u => u.pending),  backgroundColor: '#EF9F27', borderRadius: 2 },
            { label: 'In progress', data: users.map(u => u.ongoing),  backgroundColor: '#378ADD', borderRadius: 2 },
            { label: 'Completed',   data: users.map(u => u.completed),backgroundColor: '#1D9E75', borderRadius: 2 },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: { stacked: true, grid: { display: false }, ticks: { font: { size: 11 } } },
            y: { stacked: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { size: 11 }, stepSize: 1 } },
          },
        },
      })
    })
    return () => chartRef.current?.destroy()
  }, [users])

  return (
    <div style={{ position: 'relative', height: 220 }}>
      <canvas ref={canvasRef} />
    </div>
  )
}

// ── STYLES (inline CSS-in-JS object shortcuts) ────────────────────────────────
const S = {
  card: {
    background: '#fff',
    border: '1px solid #f3f4f6',
    borderRadius: 14,
    padding: 16,
    boxShadow: '0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)',
  },
  cardHdr: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '12px 16px',
    borderBottom: '1px solid #f3f4f6',
    margin: '-16px -16px 14px',
  },
  iconBox: (bg) => ({
    width: 28, height: 28, borderRadius: 9,
    background: bg,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  }),
  badge: (bg, tc) => ({
    fontSize: 10, fontWeight: 700, padding: '2px 8px',
    borderRadius: 20, background: bg, color: tc,
  }),
  miniBadge: (bg, tc) => ({
    display: 'inline-block',
    fontSize: 10, fontWeight: 700, padding: '2px 7px',
    borderRadius: 20, background: bg, color: tc,
  }),
  progWrap: {
    height: 6, background: '#f3f4f6', borderRadius: 99, overflow: 'hidden',
  },
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
export default function ServiceDashboard() {

  const { data: jobsResp, isLoading, isError } = useGetAllJobsQuery()

  const allJobs = useMemo(() => jobsResp?.data ?? [], [jobsResp])

  // ── AGE FILTER STATE ────────────────────────────────────────────────────────
  const [ageFilter, setAgeFilter] = useState('all')

  // ── COMPUTED STATS ──────────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const total      = allJobs.length
    const pending    = allJobs.filter(j => j.status === 'PENDING').length
    const ongoing    = allJobs.filter(j => j.status === 'IN_PROGRESS').length
    const completed  = allJobs.filter(j => j.status === 'COMPLETED').length
    const onHold     = allJobs.filter(j => j.status === 'ON_HOLD').length
    const cancelled  = allJobs.filter(j => j.status === 'CANCELLED').length

    // ── Assigned users map ────────────────────────────────────────────────────

    const userMap = {}
    allJobs.forEach(job => {
      let assignedList = []
      try {
        assignedList = typeof job.assigned_users === 'string'
          ? JSON.parse(job.assigned_users)
          : (job.assigned_users ?? [])
      } catch { assignedList = [] }

      assignedList.forEach(u => {
        if (!u?.id) return
        if (!userMap[u.id]) {
          userMap[u.id] = { name: u.name ?? u.username ?? 'Unknown', pending: 0, ongoing: 0, completed: 0 }
        }
        if (job.status === 'PENDING')     userMap[u.id].pending++
        if (job.status === 'IN_PROGRESS') userMap[u.id].ongoing++
        if (job.status === 'COMPLETED')   userMap[u.id].completed++
      })
    })

    const assignedUsers = Object.values(userMap).sort((a, b) =>
      (b.pending + b.ongoing + b.completed) - (a.pending + a.ongoing + a.completed)
    )

    // ── Jobs with age (days since created_at) ─────────────────────────────────
    const activeStatuses = ['PENDING', 'IN_PROGRESS', 'ON_HOLD']
    const jobsWithAge = allJobs
      .filter(j => activeStatuses.includes(j.status))
      .map(j => ({
        id:     j.id,
        name:   j.job_name,
        status: j.status,
        days:   daysBetween(j.created_at),
        // ⚠️  If you add an `sla_days` column to your job table, use: j.sla_days ?? DEFAULT_SLA
        sla:    DEFAULT_SLA,
        customer: j.customer_name ?? '',
      }))
      .sort((a, b) => b.days - a.days)

    return { total, pending, ongoing, completed, onHold, cancelled, assignedUsers, jobsWithAge }
  }, [allJobs])

  // ── FILTERED JOBS FOR AGE SECTION ───────────────────────────────────────────
  const filteredJobs = useMemo(() => {
    if (ageFilter === 'all') return stats.jobsWithAge
    return stats.jobsWithAge.filter(j => j.status === ageFilter)
  }, [stats.jobsWithAge, ageFilter])

  // ── LOADING / ERROR STATES ──────────────────────────────────────────────────
  if (isLoading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh', gap: 10, color: '#9ca3af' }}>
      <IconLoader /> <span style={{ fontSize: 14 }}>Loading service data…</span>
    </div>
  )
  if (isError) return (
    <div style={{ textAlign: 'center', padding: 40, color: '#E24B4A', fontSize: 14 }}>
      Failed to load jobs. Check your API connection.
    </div>
  )

  // ── RENDER ──────────────────────────────────────────────────────────────────
  return (
    <>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
        .svc-card { animation: fadeUp 0.3s ease both; }
        .svc-card:nth-child(1){animation-delay:.04s}
        .svc-card:nth-child(2){animation-delay:.08s}
        .svc-card:nth-child(3){animation-delay:.12s}
        .svc-card:nth-child(4){animation-delay:.16s}
        .age-row-hover:hover { background: #f9fafb; }
        .filter-pill { font-size:11px; padding:3px 10px; border-radius:20px; border:1px solid #e5e7eb; color:#6b7280; cursor:pointer; background:#fff; transition:all 0.15s; }
        .filter-pill:hover { border-color:#378ADD; color:#185FA5; }
        .filter-pill.active { background:#378ADD; color:#fff; border-color:#378ADD; }
        .svc-th { font-size:10px; font-weight:700; color:#9ca3af; text-transform:uppercase; letter-spacing:.05em; padding:0 8px 8px; text-align:left; border-bottom:1px solid #f3f4f6; }
        .svc-td { padding:9px 8px; border-bottom:1px solid #f3f4f6; color:#111827; vertical-align:middle; font-size:12px; }
        .stat-bar-bg { height:3px; background:#f3f4f6; border-radius:99px; margin-top:8px; overflow:hidden; }
      `}</style>

      <div style={{ fontFamily: '"DM Sans","Segoe UI",sans-serif', padding: '22px 20px', background: '#f9fafb', minHeight: '100vh' }}>

        {/* ── PAGE HEADER ────────────────────────────────────────────────────── */}
        <div style={{ marginBottom: 20 }}>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#111827', margin: 0, letterSpacing: '-0.02em' }}>
            Service Management
          </h1>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '3px 0 0' }}>{todayLabel()}</p>
        </div>

        {/* ── ROW 1: 4 STAT CARDS ─────────────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 16 }}>

          {/* Total */}
          <div className="svc-card" style={{ ...S.card }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{ ...S.iconBox('#e0eaff'), color: '#185FA5' }}><IconBriefcase /></div>
              <span style={S.badge('#E6F1FB', '#0C447C')}>All</span>
            </div>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#185FA5', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>Total Jobs</p>
            <p style={{ fontSize: 32, fontWeight: 800, color: '#111827', lineHeight: 1, letterSpacing: '-0.03em' }}>{stats.total}</p>
            <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>All time (non-deleted)</p>
            <div className="stat-bar-bg"><div style={{ height: '100%', width: '100%', background: '#378ADD', borderRadius: 99 }} /></div>
          </div>

          {/* Pending */}
          <div className="svc-card" style={{ ...S.card }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{ ...S.iconBox('#FAEEDA'), color: '#BA7517' }}><IconClock /></div>
              <span style={S.badge('#FAEEDA', '#633806')}>Waiting</span>
            </div>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#BA7517', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>Pending</p>
            <p style={{ fontSize: 32, fontWeight: 800, color: '#111827', lineHeight: 1, letterSpacing: '-0.03em' }}>{stats.pending}</p>
            <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>Awaiting action</p>
            <div className="stat-bar-bg">
              <div style={{ height: '100%', width: `${stats.total ? Math.round(stats.pending / stats.total * 100) : 0}%`, background: '#EF9F27', borderRadius: 99 }} />
            </div>
          </div>

          {/* In Progress */}
          <div className="svc-card" style={{ ...S.card }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{ ...S.iconBox('#EAF3DE'), color: '#3B6D11' }}><IconCheck /></div>
              {stats.ongoing > 0 && <span style={S.badge('#EAF3DE', '#27500A')}>Live</span>}
            </div>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#3B6D11', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>In Progress</p>
            <p style={{ fontSize: 32, fontWeight: 800, color: '#111827', lineHeight: 1, letterSpacing: '-0.03em' }}>{stats.ongoing}</p>
            <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>Currently active</p>
            <div className="stat-bar-bg">
              <div style={{ height: '100%', width: `${stats.total ? Math.round(stats.ongoing / stats.total * 100) : 0}%`, background: '#1D9E75', borderRadius: 99 }} />
            </div>
          </div>

          {/* Completed */}
          <div className="svc-card" style={{ ...S.card }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{ ...S.iconBox('#E1F5EE'), color: '#085041' }}><IconCheck /></div>
              <span style={S.badge('#E1F5EE', '#085041')}>{stats.total ? Math.round(stats.completed / stats.total * 100) : 0}%</span>
            </div>
            <p style={{ fontSize: 11, fontWeight: 700, color: '#085041', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 3 }}>Completed</p>
            <p style={{ fontSize: 32, fontWeight: 800, color: '#111827', lineHeight: 1, letterSpacing: '-0.03em' }}>{stats.completed}</p>
            <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 3 }}>Successfully closed</p>
            <div className="stat-bar-bg">
              <div style={{ height: '100%', width: `${stats.total ? Math.round(stats.completed / stats.total * 100) : 0}%`, background: '#0F6E56', borderRadius: 99 }} />
            </div>
          </div>
        </div>

        {/* ── ROW 2: ASSIGNED USERS + CHART ──────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>

          {/* Assigned users table */}
          <div style={{ ...S.card }}>
            <div style={S.cardHdr}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ ...S.iconBox('#E6F1FB'), color: '#185FA5' }}><IconUsers /></div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>Assigned Technicians</p>
                  <p style={{ fontSize: 11, color: '#9ca3af' }}>Job distribution per staff member</p>
                </div>
              </div>
              <span style={S.miniBadge('#E6F1FB', '#0C447C')}>{stats.assignedUsers.length} staff</span>
            </div>

            {stats.assignedUsers.length === 0 ? (
              <p style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '24px 0' }}>
                No assigned users found. Make sure jobs have assigned_users set.
              </p>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead>
                    <tr>
                      <th className="svc-th">Technician</th>
                      <th className="svc-th" style={{ textAlign: 'center' }}>Pending</th>
                      <th className="svc-th" style={{ textAlign: 'center' }}>Ongoing</th>
                      <th className="svc-th" style={{ textAlign: 'center' }}>Done</th>
                      <th className="svc-th" style={{ textAlign: 'center' }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats.assignedUsers.map((u, i) => {
                      const total = u.pending + u.ongoing + u.completed
                      const color = AVATAR_COLORS[i % AVATAR_COLORS.length]
                      return (
                        <tr key={i}>
                          <td className="svc-td">
                            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                              <div style={{
                                width: 26, height: 26, borderRadius: '50%',
                                background: color + '22', color,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                fontSize: 10, fontWeight: 700, flexShrink: 0,
                              }}>
                                {getInitials(u.name).toUpperCase()}
                              </div>
                              <span style={{ fontSize: 12, color: '#111827', fontWeight: 500 }}>{u.name}</span>
                            </div>
                          </td>
                          <td className="svc-td" style={{ textAlign: 'center' }}>
                            <span style={S.miniBadge('#FAEEDA', '#633806')}>{u.pending}</span>
                          </td>
                          <td className="svc-td" style={{ textAlign: 'center' }}>
                            <span style={S.miniBadge('#E6F1FB', '#0C447C')}>{u.ongoing}</span>
                          </td>
                          <td className="svc-td" style={{ textAlign: 'center' }}>
                            <span style={S.miniBadge('#EAF3DE', '#27500A')}>{u.completed}</span>
                          </td>
                          <td className="svc-td" style={{ textAlign: 'center', fontWeight: 700 }}>{total}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Workload bar chart */}
          <div style={{ ...S.card }}>
            <div style={S.cardHdr}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ ...S.iconBox('#EAF3DE'), color: '#3B6D11' }}><IconBriefcase /></div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>Workload distribution</p>
                  <p style={{ fontSize: 11, color: '#9ca3af' }}>Jobs per status across team</p>
                </div>
              </div>
            </div>
            {stats.assignedUsers.length === 0 ? (
              <p style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '24px 0' }}>No data</p>
            ) : (
              <>
                <WorkloadChart users={stats.assignedUsers} />
                <div style={{ display: 'flex', gap: 12, marginTop: 10, fontSize: 11, color: '#6b7280' }}>
                  {[['#EF9F27','Pending'],['#378ADD','In progress'],['#1D9E75','Completed']].map(([c, l]) => (
                    <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                      <span style={{ width: 10, height: 10, borderRadius: 2, background: c, display: 'inline-block' }} />
                      {l}
                    </span>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        {/* ── ROW 3: AGE ANALYSIS ──────────────────────────────────────────────── */}
        <div style={{ ...S.card }}>

          {/* Header */}
          <div style={{ ...S.cardHdr, flexWrap: 'wrap', gap: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ ...S.iconBox('#FAEEDA'), color: '#854F0B' }}><IconClock /></div>
              <div>
                <p style={{ fontSize: 13, fontWeight: 700, color: '#111827' }}>Job age analysis</p>
                <p style={{ fontSize: 11, color: '#9ca3af' }}>
                  Time elapsed vs SLA ({DEFAULT_SLA}d default) — active jobs only
                </p>
              </div>
            </div>
            {/* ── FILTER PILLS ──────────────────────────────────────────────── */}
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {[
                { key: 'all',         label: 'All' },
                { key: 'PENDING',     label: 'Pending' },
                { key: 'IN_PROGRESS', label: 'In progress' },
                { key: 'ON_HOLD',     label: 'On hold' },
              ].map(f => (
                <button
                  key={f.key}
                  className={`filter-pill${ageFilter === f.key ? ' active' : ''}`}
                  onClick={() => setAgeFilter(f.key)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Bucket summary row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8, marginBottom: 16 }}>
            {BUCKETS.map(b => {
              const count = filteredJobs.filter(j => getBucket(j.days) === b).length
              return (
                <div key={b.lbl} style={{ background: '#f9fafb', borderRadius: 9, padding: '10px 12px', textAlign: 'center', border: '1px solid #f3f4f6' }}>
                  <p style={{ fontSize: 22, fontWeight: 800, color: b.color, lineHeight: 1 }}>{count}</p>
                  <p style={{ fontSize: 10, color: '#6b7280', marginTop: 3 }}>{b.lbl}</p>
                  <div style={{ height: 3, borderRadius: 99, marginTop: 6, background: count > 0 ? b.color : '#e5e7eb', opacity: count > 0 ? 0.8 : 0.3 }} />
                </div>
              )
            })}
          </div>

          {/* Legend */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 10, fontSize: 11, color: '#6b7280', flexWrap: 'wrap' }}>
            {[['#378ADD','Days elapsed'],['#EF9F27','SLA remaining (30% opacity)'],['#E24B4A','Overdue']].map(([c,l]) => (
              <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: c, display: 'inline-block' }} />{l}
              </span>
            ))}
          </div>

          {/* Column headers */}
          <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 90px 80px', gap: 12, paddingBottom: 7, borderBottom: '1px solid #f3f4f6' }}>
            {['Job', 'Age / SLA progress', 'Elapsed', 'Status'].map((h, i) => (
              <span key={h} style={{ fontSize: 10, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em', textAlign: i >= 2 ? 'right' : 'left' }}>{h}</span>
            ))}
          </div>

          {/* Job rows */}
          <div style={{ maxHeight: 360, overflowY: 'auto' }}>
            {filteredJobs.length === 0 ? (
              <p style={{ textAlign: 'center', color: '#9ca3af', fontSize: 13, padding: '24px 0' }}>No jobs match this filter</p>
            ) : filteredJobs.map(j => {
              const overdue  = j.days > j.sla
              const elPct    = Math.min(Math.round(j.days / j.sla * 100), 100)
              const remain   = Math.max(j.sla - j.days, 0)
              const bucket   = getBucket(j.days)
              const cfg      = STATUS_CFG[j.status] ?? STATUS_CFG.PENDING
              const barColor = overdue ? '#E24B4A' : bucket.color

              return (
                <div
                  key={j.id}
                  className="age-row-hover"
                  style={{
                    display: 'grid', gridTemplateColumns: '140px 1fr 90px 80px',
                    gap: 12, padding: '9px 4px', borderBottom: '1px solid #f3f4f6',
                    alignItems: 'center', transition: 'background 0.15s',
                  }}
                >
                  {/* Job name */}
                  <div>
                    <p style={{ fontSize: 12, fontWeight: 600, color: '#111827', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {j.name}
                    </p>
                    <p style={{ fontSize: 10, color: '#9ca3af' }}>#{j.id} {j.customer ? `· ${j.customer}` : ''}</p>
                  </div>

                  {/* Progress bar */}
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                      <span style={{ fontSize: 11, color: barColor, fontWeight: 600 }}>{j.days}d elapsed</span>
                      <span style={{ fontSize: 10, color: '#9ca3af' }}>/ SLA {j.sla}d</span>
                      {overdue && (
                        <span style={S.miniBadge('#FCEBEB', '#A32D2D')}>Overdue</span>
                      )}
                    </div>
                    <div style={S.progWrap}>
                      <div style={{ display: 'flex', width: '100%', height: '100%', borderRadius: 99, overflow: 'hidden' }}>
                        <div style={{ width: `${elPct}%`, background: barColor, borderRadius: 99 }} />
                        {!overdue && <div style={{ flex: 1, background: '#EF9F27', opacity: 0.25 }} />}
                      </div>
                    </div>
                    <p style={{ fontSize: 10, color: '#9ca3af', marginTop: 3 }}>
                      {overdue ? `${j.days - j.sla}d past SLA` : `${remain}d remaining`}
                    </p>
                  </div>

                  {/* % elapsed */}
                  <div style={{ textAlign: 'right' }}>
                    <p style={{ fontSize: 14, fontWeight: 800, color: '#111827' }}>{elPct}%</p>
                    <p style={{ fontSize: 10, color: '#9ca3af' }}>of SLA</p>
                  </div>

                  {/* Status badge */}
                  <div style={{ textAlign: 'right' }}>
                    <span style={S.miniBadge(cfg.bg, cfg.tc)}>{cfg.label}</span>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Footer totals */}
          <div style={{ padding: '10px 4px 0', borderTop: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
            <span style={{ fontSize: 11, color: '#9ca3af' }}>
              Showing {filteredJobs.length} of {stats.jobsWithAge.length} active jobs
            </span>
            <span style={{ fontSize: 11, color: '#E24B4A', fontWeight: 600 }}>
              {filteredJobs.filter(j => j.days > j.sla).length} overdue
            </span>
          </div>
        </div>

      </div>
    </>
  )
}
