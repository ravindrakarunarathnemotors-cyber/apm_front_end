import dynamic from 'next/dynamic'

export const metadata = {
  title: 'CreateJob - Service Management',
}


const CreateJob = dynamic(() => import('./createjob'), { ssr: false })

export default function CreateJobPage() {
  return <CreateJob />
}