'use client'

import React, { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import {
  Card, CardHeader, CardTitle, CardBody,
  Row, Col, Button, Form, Table, Badge,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import {
  useCreateJobMutation,
  useSearchProductsQuery,
  useSearchCustomersQuery, 
  useCreateCustomerMutation,
} from '@/store/features/serviceSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'

// ─── Helpers ──────────────────────────────────────────────────────────────────
function SectionHeading({ icon, title, badge }) {
  return (
    <div
      className="d-flex align-items-center gap-2 mb-3"
      style={{ borderBottom: '1.5px solid #e9ecef', paddingBottom: '10px' }}
    >
      <div style={{ width: 32, height: 32, borderRadius: '8px', background: 'rgba(var(--bs-primary-rgb), 0.10)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon icon={icon} width={17} style={{ color: 'var(--bs-primary)' }} />
      </div>
      <span style={{ fontWeight: 700, fontSize: '0.88rem', color: '#111827' }}>{title}</span>
      {badge !== undefined && badge > 0 && (
        <Badge bg="primary" style={{ fontSize: '0.68rem', borderRadius: '20px', marginLeft: 2 }}>{badge}</Badge>
      )}
    </div>
  )
}

function EmptyHint({ icon, text }) {
  return (
    <div className="d-flex flex-column align-items-center justify-content-center py-4" style={{ color: '#d1d5db' }}>
      <Icon icon={icon} width={36} style={{ opacity: 0.45, display: 'block', marginBottom: 6 }} />
      <span style={{ fontSize: '0.78rem' }}>{text}</span>
    </div>
  )
}

// ─── Job Product Search Modal ─────────────────────────────────────────────────
function JobProductSearch({ search, setSearch, onClose, addedProducts, setAddedproducts }) {
  const { data: searchData, isFetching } = useSearchProductsQuery(search, {
    skip: search.trim().length < 2,
  })
  const results = searchData?.data ?? []
  const { currency } = useCurrencySymbol()

  const handleSelect = (product) => {
    const alreadyAdded = addedProducts.some((p) => p.variant_id === product.variant_id)
    if (alreadyAdded) {
      Swal.fire({ icon: 'info', title: 'Already added', text: `${product.title} is already in the list.`, timer: 1500, showConfirmButton: false })
      return
    }
    setAddedproducts((prev) => [
      ...prev,
      {
        variant_id:    product.variant_id,
        product_id:    product.product_id,
        title:         product.title,
        price:         Number(product.variant_price || product.base_price || 0),
        selectedQty:   1,
        isTemp:        false,
        sku:           product.sku,
        variant_value: product.variant_value,
      },
    ])
    onClose()
  }

  return (
    <div
      style={{ position: 'fixed', inset: 0, zIndex: 1050, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}
    >
      <div
        style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 580, maxHeight: '80vh', display: 'flex', flexDirection: 'column', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="d-flex align-items-center gap-2 p-3" style={{ borderBottom: '1px solid #e9ecef' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <input
              autoFocus
              type="search"
              className="form-control"
              placeholder="Search by name, SKU, barcode…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ borderRadius: 8, paddingRight: 36 }}
            />
            <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af', pointerEvents: 'none' }}>
              {isFetching
                ? <span className="spinner-border spinner-border-sm" />
                : <Icon icon="iconoir:search" width={18} />}
            </span>
          </div>
          <button
            onClick={onClose}
            style={{ border: 'none', background: '#f3f4f6', borderRadius: 8, width: 36, height: 36, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
          >
            <Icon icon="mdi:close" width={18} style={{ color: '#6b7280' }} />
          </button>
        </div>

        {/* Results */}
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {search.trim().length < 2 && (
            <div className="d-flex flex-column align-items-center justify-content-center py-5" style={{ color: '#d1d5db' }}>
              <Icon icon="iconoir:search" width={40} style={{ opacity: 0.4, marginBottom: 8 }} />
              <span style={{ fontSize: '0.85rem' }}>Type at least 2 characters to search</span>
            </div>
          )}

          {!isFetching && search.trim().length >= 2 && results.length === 0 && (
            <div className="d-flex flex-column align-items-center justify-content-center py-5" style={{ color: '#9ca3af' }}>
              <Icon icon="mdi:package-variant-closed-remove" width={40} style={{ opacity: 0.4, marginBottom: 8 }} />
              <span style={{ fontSize: '0.85rem' }}>No products found for {search}</span>
            </div>
          )}

          {!isFetching && results.map((product) => {
            const isAdded = addedProducts.some((p) => p.variant_id === product.variant_id)
            return (
              <div
                key={product.variant_id}
                className="d-flex align-items-center gap-3 px-3 py-2"
                style={{
                  cursor: isAdded ? 'default' : 'pointer',
                  borderBottom: '1px solid #f3f4f6',
                  fontSize: '0.85rem',
                  opacity: isAdded ? 0.5 : 1,
                  background: '#fff',
                  transition: 'background 0.15s',
                }}
                onMouseEnter={(e) => { if (!isAdded) e.currentTarget.style.background = '#f9fafb' }}
                onMouseLeave={(e) => { e.currentTarget.style.background = '#fff' }}
                onClick={() => { if (!isAdded) handleSelect(product) }}
              >
                <div style={{ width: 44, height: 44, borderRadius: 8, background: 'rgba(var(--bs-primary-rgb),0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon icon="mdi:package-variant" width={22} style={{ color: 'var(--bs-primary)' }} />
                </div>
                <div className="flex-grow-1 overflow-hidden">
                  <div className="fw-semibold text-truncate">{product.title}</div>
                  <div className="text-muted" style={{ fontSize: '0.75rem' }}>
                    {product.variant_value && <span className="me-2">{product.variant_value}</span>}
                    {product.sku && <span>SKU: {product.sku}</span>}
                  </div>
                </div>
                <div className="d-flex flex-column align-items-end gap-1" style={{ flexShrink: 0 }}>
                  <span className="text-primary fw-semibold">
                    {currency} {Number(product.variant_price || product.base_price || 0).toFixed(2)}
                  </span>
                  {isAdded && (
                    <span style={{ fontSize: '0.68rem', background: '#e5e7eb', color: '#6b7280', borderRadius: 20, padding: '1px 8px' }}>Added</span>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Footer */}
        <div className="px-3 py-2" style={{ borderTop: '1px solid #e9ecef', fontSize: '0.75rem', color: '#9ca3af' }}>
          {results.length > 0 ? `${results.length} result${results.length > 1 ? 's' : ''} found` : 'Search products from catalogue'}
        </div>
      </div>
    </div>
  )
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function CreateJob() {
  const { currency } = useCurrencySymbol()

  const [createJob, { isLoading: isSubmitting }] = useCreateJobMutation()

  const [job, setJob] = useState({ name: '', description: '' })
  const [equipmentInput, setEquipmentInput] = useState({ name: '', serialNumber: '' })
  const [equipments, setEquipments] = useState([])
  const [services, setServices] = useState([])
  const [serviceInput, setServiceInput] = useState({ name: '', amount: '' })
  const [addedProducts, setAddedproducts] = useState([])
  const tempCounterRef = useRef(300)
  const [tempItem, setTempItem] = useState({ name: '', qty: 1, price: '' })
  const [showTempForm, setShowTempForm] = useState(false)
  const [search, setSearch] = useState('')
  const [showProductModal, setShowProductModal] = useState(false)
  // ── Customer state ──────────────────────────────────────────────────────────
  const [customerSearch, setCustomerSearch]     = useState('')
  const [selectedCustomer, setSelectedCustomer] = useState(null)
  const [showNewCustomerForm, setShowNewCustomerForm] = useState(false)
  const [newCustomer, setNewCustomer] = useState({ name: '', email: '', phone: '', address: '' })
  const [createCustomer, { isLoading: isCreatingCustomer }] = useCreateCustomerMutation()
  const { data: customerData, isFetching: customerFetching } = useSearchCustomersQuery(customerSearch, {
    skip: customerSearch.trim().length < 2,
  })
  const customerResults = customerData?.data ?? []

  useEffect(() => {
    if (search.length > 1) setShowProductModal(true)
  }, [search])

  // ── Equipment handlers ──────────────────────────────────────────────────────
  const addEquipment = () => {
    const v = equipmentInput.name.trim()
    if (!v) return
    setEquipments((prev) => [...prev, { id: Date.now(), name: v, serialNumber: equipmentInput.serialNumber.trim() }])
    setEquipmentInput({ name: '', serialNumber: '' })
  }
  const removeEquipment = (id) => setEquipments((prev) => prev.filter((e) => e.id !== id))

  // ── Service handlers ────────────────────────────────────────────────────────
  const addService = () => {
    if (!serviceInput.name.trim() || !serviceInput.amount) return
    setServices((prev) => [...prev, { id: Date.now(), name: serviceInput.name.trim(), amount: parseFloat(serviceInput.amount) || 0 }])
    setServiceInput({ name: '', amount: '' })
  }
  const removeService = (id) => setServices((prev) => prev.filter((s) => s.id !== id))
  const totalServiceFee = services.reduce((s, x) => s + x.amount, 0)

  // ── Temp item handlers ──────────────────────────────────────────────────────
  const addTempItem = () => {
    if (!tempItem.name.trim() || !tempItem.price) return
    const id = `TEMP-${tempCounterRef.current++}`
    setAddedproducts((prev) => [...prev, { variant_id: id, product_id: null, title: tempItem.name.trim(), price: parseFloat(tempItem.price) || 0, selectedQty: Math.max(1, parseInt(tempItem.qty) || 1), isTemp: true }])
    setTempItem({ name: '', qty: 1, price: '' })
    setShowTempForm(false)
  }

  const handleProductQty = (variant_id, val) =>
    setAddedproducts((prev) => prev.map((p) => p.variant_id === variant_id ? { ...p, selectedQty: Math.max(1, Number(val) || 1) } : p))

  const removeProduct = (variant_id) =>
    setAddedproducts((prev) => prev.filter((p) => p.variant_id !== variant_id))

  const totalProducts = addedProducts.reduce((s, p) => s + p.price * p.selectedQty, 0)
  const grandTotal = totalProducts + totalServiceFee

  // ── Customer handlers ───────────────────────────────────────────────────────
  const handleCreateNewCustomer = async () => {
    if (!newCustomer.name.trim()) {
      Swal.fire({ icon: 'error', title: 'Name required', text: 'Please enter the customer name.' })
      return
    }
    try {
      const res = await createCustomer(newCustomer).unwrap()
      setSelectedCustomer(res.data)
      setShowNewCustomerForm(false)
      setNewCustomer({ name: '', email: '', phone: '', address: '' })
      setCustomerSearch('')
      Swal.fire({ icon: 'success', title: 'Customer created', toast: true, timer: 1800, position: 'top-end', showConfirmButton: false })
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Failed', text: err?.data?.message || 'Could not create customer.' })
    }
  }

  // ── Reset ───────────────────────────────────────────────────────────────────
  const resetForm = () => {
    setJob({ name: '', description: '' })
    setSelectedCustomer(null)        
    setCustomerSearch('')              
    setShowNewCustomerForm(false)      
    setNewCustomer({ name: '', email: '', phone: '', address: '' }) 
    setEquipments([])
    setEquipmentInput({ name: '', serialNumber: '' })
    setServices([])
    setServiceInput({ name: '', amount: '' })
    setAddedproducts([])
    setSearch('')
    setShowTempForm(false)
    setTempItem({ name: '', qty: 1, price: '' })
  }

  // ── Submit ──────────────────────────────────────────────────────────────────
  const handleCreate = async () => {
    if (!job.name.trim()) {
      Swal.fire({ icon: 'error', title: 'Error', text: 'Job Name is required.' })
      return
    }

    const payload = {
      job_name:        job.name.trim(),
      job_description: job.description.trim() || null,
      customer_id:     selectedCustomer?.id || null, 
      equipment: equipments.map((e) => ({
      equipment_name: e.name,
      serial_number: e.serialNumber?.trim().length > 0 ? e.serialNumber.trim() : null,
    })),
      items: [
        ...addedProducts.filter((p) => !p.isTemp).map((p) => ({ item_type: 'PRODUCT', product_id: p.product_id, item_name: p.title, quantity: p.selectedQty, unit_price: p.price })),
        ...addedProducts.filter((p) => p.isTemp).map((p) => ({ item_type: 'CUSTOM', item_name: p.title, quantity: p.selectedQty, unit_price: p.price })),
      ],
      services: services.map((s) => ({ service_name: s.name, amount: s.amount })),
    }

    console.log('[handleCreate] payload:', JSON.stringify(payload, null, 2))

    try {
      await createJob(payload).unwrap()
      Swal.fire({ icon: 'success', title: 'Job created successfully', toast: true, timer: 2000, position: 'top-end', showConfirmButton: false })
      resetForm()
    } catch (error) {
      Swal.fire({ icon: 'error', title: 'Failed to create job', text: error?.data?.message || 'Something went wrong.' })
    }
  }

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div>
      <Card>
        {/* ── Header with Back button ── */}
        <CardHeader className="py-3 bg-light">
          <Row className="align-items-center justify-content-between">
            <Col>
              <CardTitle as="h4" className="mb-0">Create Job</CardTitle>
            </Col>
          </Row>
        </CardHeader>

        <CardBody>
          <Row className="g-4">

            {/* 1. JOB INFO */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:briefcase-outline" title="Job Information" />
                  <Row className="g-0" style={{ minHeight: 220 }}>
                    
                     {/* ── RIGHT: Job Name + Description ── */}
                    <Col md={7} style={{ borderRight: '1.5px solid #e9ecef', paddingRight: 20 }}>
                      <div style={{ fontWeight: 700, fontSize: '0.82rem', marginBottom: 10, color: '#374151' }}>
                        <Icon icon="mdi:briefcase-edit-outline" width={15} style={{ marginRight: 5 }} />
                        Job Details
                      </div>
                      <div className="d-flex flex-column gap-3">
                        <div>
                          <Form.Label style={{ fontWeight: 600, fontSize: '0.82rem' }}>Job Name <span className="text-danger">*</span></Form.Label>
                          <Form.Control type="text" placeholder="e.g. AC Repair – Unit 3B" value={job.name} onChange={(e) => setJob((j) => ({ ...j, name: e.target.value }))} style={{ borderRadius: 8 }} />
                        </div>
                        <div>
                          <Form.Label style={{ fontWeight: 600, fontSize: '0.82rem' }}>Job Description</Form.Label>
                          <Form.Control as="textarea" rows={3} placeholder="Brief description of the work to be done…" value={job.description} onChange={(e) => setJob((j) => ({ ...j, description: e.target.value }))} style={{ borderRadius: 8, resize: 'vertical' }} />
                        </div>
                      </div>
                    </Col>

                    {/* ── LEFT: Customer Panel ── */}
                    <Col md={5} style={{ paddingLeft: 24 }}>
                      <div style={{ fontWeight: 700, fontSize: '0.82rem', marginBottom: 10, color: '#374151' }}>
                        <Icon icon="mdi:account-outline" width={15} style={{ marginRight: 5 }} />
                        Customer
                      </div>

                      {/* Selected customer chip */}
                      {selectedCustomer ? (
                        <div style={{ background: 'rgba(var(--bs-primary-rgb),0.07)', border: '1.5px solid rgba(var(--bs-primary-rgb),0.18)', borderRadius: 10, padding: '10px 14px', marginBottom: 10 }}>
                          <div className="d-flex justify-content-between align-items-start">
                            <div>
                              <div className="fw-semibold" style={{ fontSize: '0.88rem' }}>{selectedCustomer.name}</div>
                              {selectedCustomer.phone && <div className="text-muted" style={{ fontSize: '0.75rem' }}>{selectedCustomer.phone}</div>}
                              {selectedCustomer.email && <div className="text-muted" style={{ fontSize: '0.75rem' }}>{selectedCustomer.email}</div>}
                            </div>
                            <button onClick={() => setSelectedCustomer(null)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#9ca3af', padding: 0 }}>
                              <Icon icon="mdi:close" width={16} />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {/* Search input */}
                          <div style={{ position: 'relative', marginBottom: 8 }}>
                            <Form.Control
                              type="search"
                              placeholder="Search by name, phone, email…"
                              value={customerSearch}
                              onChange={(e) => { setCustomerSearch(e.target.value); setShowNewCustomerForm(false) }}
                              style={{ borderRadius: 8, paddingRight: 36, fontSize: '0.83rem' }}
                            />
                            <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }}>
                              {customerFetching
                                ? <span className="spinner-border spinner-border-sm" style={{ width: 14, height: 14 }} />
                                : <Icon icon="iconoir:search" width={15} />}
                            </span>
                          </div>

                          {/* Dropdown results */}
                          {customerSearch.trim().length >= 2 && !showNewCustomerForm && (
                            <div style={{ border: '1px solid #e9ecef', borderRadius: 8, overflow: 'hidden', marginBottom: 8, maxHeight: 180, overflowY: 'auto' }}>
                              {customerResults.length === 0 && !customerFetching && (
                                <div className="text-center py-3" style={{ fontSize: '0.78rem', color: '#9ca3af' }}>No customers found</div>
                              )}
                              {customerResults.map((c) => (
                                <div
                                  key={c.id}
                                  onClick={() => { setSelectedCustomer(c); setCustomerSearch('') }}
                                  style={{ padding: '8px 12px', cursor: 'pointer', borderBottom: '1px solid #f3f4f6', fontSize: '0.82rem', transition: 'background 0.12s' }}
                                  onMouseEnter={(e) => e.currentTarget.style.background = '#f9fafb'}
                                  onMouseLeave={(e) => e.currentTarget.style.background = '#fff'}
                                >
                                  <div className="fw-semibold">{c.name}</div>
                                  <div className="text-muted" style={{ fontSize: '0.72rem' }}>{[c.phone, c.email].filter(Boolean).join(' · ')}</div>
                                </div>
                              ))}
                            </div>
                          )}
                        </>
                      )}

                      {/* New customer toggle */}
                      {!selectedCustomer && (
                        <button
                          onClick={() => { setShowNewCustomerForm((v) => !v); setCustomerSearch('') }}
                          style={{ background: 'none', border: 'none', padding: 0, color: 'var(--bs-primary)', fontSize: '0.80rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}
                        >
                          <Icon icon={showNewCustomerForm ? 'mdi:chevron-up' : 'ic:baseline-plus'} width={16} />
                          {showNewCustomerForm ? 'Cancel' : 'New Customer'}
                        </button>
                      )}

                      {/* New customer inline form */}
                      {showNewCustomerForm && (
                        <div className="mt-2 d-flex flex-column gap-2">
                          <Form.Control size="sm" type="text" placeholder="Full name *" value={newCustomer.name} onChange={(e) => setNewCustomer((c) => ({ ...c, name: e.target.value }))} style={{ borderRadius: 7 }} />
                          <Form.Control size="sm" type="text" placeholder="Phone" value={newCustomer.phone} onChange={(e) => setNewCustomer((c) => ({ ...c, phone: e.target.value }))} style={{ borderRadius: 7 }} />
                          <Form.Control size="sm" type="email" placeholder="Email" value={newCustomer.email} onChange={(e) => setNewCustomer((c) => ({ ...c, email: e.target.value }))} style={{ borderRadius: 7 }} />
                          <Form.Control size="sm" type="text" placeholder="Address" value={newCustomer.address} onChange={(e) => setNewCustomer((c) => ({ ...c, address: e.target.value }))} style={{ borderRadius: 7 }} />
                          <Button size="sm" variant="primary" onClick={handleCreateNewCustomer} disabled={isCreatingCustomer} style={{ borderRadius: 7, fontWeight: 600, fontSize: '0.80rem' }}>
                            {isCreatingCustomer ? 'Saving…' : 'Save Customer'}
                          </Button>
                        </div>
                      )}
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>

            {/* 2. EQUIPMENT */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:tools" title="Equipment from Customer" badge={equipments.length} />
                  <div className="d-flex gap-2 mb-3 flex-wrap">
                    <Form.Control
                      type="text"
                      placeholder="Equipment name e.g. Old Compressor…"
                      value={equipmentInput.name}
                      onChange={(e) => setEquipmentInput((v) => ({ ...v, name: e.target.value }))}
                      onKeyDown={(e) => e.key === 'Enter' && addEquipment()}
                      style={{ borderRadius: 8, flex: '2 1 200px' }}
                    />
                    <Form.Control
                      type="text"
                      placeholder="Serial number (optional)"
                      value={equipmentInput.serialNumber}
                      onChange={(e) => setEquipmentInput((v) => ({ ...v, serialNumber: e.target.value }))}
                      onKeyDown={(e) => e.key === 'Enter' && addEquipment()}
                      style={{ borderRadius: 8, flex: '1 1 150px' }}
                    />
                    <Button variant="outline-primary" onClick={addEquipment} style={{ borderRadius: 8, fontWeight: 600, fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
                      <Icon icon="ic:baseline-plus" width={18} /> Add
                    </Button>
                  </div>
                  {equipments.length === 0 ? <EmptyHint icon="mdi:wrench-outline" text="No equipment added yet" /> : (
                    <div className="d-flex flex-wrap gap-2">
                      {equipments.map((eq) => (
                        <div key={eq.id} className="d-flex align-items-center gap-1" style={{ background: '#f3f4f6', borderRadius: 20, padding: '5px 12px', fontSize: '0.82rem', fontWeight: 500, color: '#374151' }}>
                          <Icon icon="mdi:wrench" width={14} style={{ color: '#6b7280' }} />
                          {eq.name}
                          {eq.serialNumber && (
                            <span style={{ fontSize: '0.70rem', color: '#6b7280', background: '#e5e7eb', borderRadius: 10, padding: '1px 7px', marginLeft: 2 }}>
                              S/N: {eq.serialNumber}
                            </span>
                          )}
                          <button onClick={() => removeEquipment(eq.id)} style={{ border: 'none', background: 'none', padding: 0, marginLeft: 4, cursor: 'pointer', color: '#9ca3af', display: 'flex', alignItems: 'center' }}>
                            <Icon icon="mdi:close" width={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardBody>
              </Card>
            </Col>

            {/* 3. BILLING ITEMS */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:package-variant-closed" title="Billing Items" badge={addedProducts.length} />

                  <div className="d-flex gap-1 w-100 mb-3 flex-wrap">
                    <div className="d-flex border rounded overflow-hidden flex-grow-1">
                      <input
                        type="search"
                        className="form-control border-0 shadow-none"
                        placeholder="Search products by name, SKU, barcode…"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        autoComplete="off"
                      />
                      <button className="btn border-0 bg-white">
                        <Icon icon="iconoir:search" />
                      </button>
                    </div>
                    <Button
                      variant="outline"
                      className="d-flex btn-outline-primary align-items-center justify-content-center gap-1 btn-sm"
                      style={{ borderRadius: 10, minHeight: 36, whiteSpace: 'nowrap' }}
                      onClick={() => setShowTempForm((v) => !v)}
                    >
                      <Icon icon="ic:baseline-plus" width={20} /> Add Temporary Item
                    </Button>
                  </div>

                  {/* Temp item form */}
                  {showTempForm && (
                    <div className="d-flex gap-2 mb-3 flex-wrap p-3" style={{ background: '#f9fafb', borderRadius: 10, border: '1.5px dashed #dee2e6' }}>
                      <Form.Control type="text" placeholder="Item name" value={tempItem.name} onChange={(e) => setTempItem((t) => ({ ...t, name: e.target.value }))} style={{ borderRadius: 8, maxWidth: 600 }} />
                      <Form.Control type="number" placeholder="Qty" min={1} value={tempItem.qty} onChange={(e) => setTempItem((t) => ({ ...t, qty: e.target.value }))} style={{ borderRadius: 8, maxWidth: 80 }} />
                      <Form.Control type="number" placeholder="Price" min={0} value={tempItem.price} onChange={(e) => setTempItem((t) => ({ ...t, price: e.target.value }))} style={{ borderRadius: 8, maxWidth: 150 }} />
                      <Button variant="primary" onClick={addTempItem} style={{ borderRadius: 8, fontWeight: 600, fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Icon icon="mdi:check" width={16} /> Add Item
                      </Button>
                      <Button variant="link" className="text-secondary p-0" onClick={() => setShowTempForm(false)} style={{ fontSize: '0.82rem', alignSelf: 'center' }}>
                        Cancel
                      </Button>
                    </div>
                  )}

                  {/* Products table */}
                  {addedProducts.length === 0 ? (
                    <div className="d-flex justify-content-center align-items-center" style={{ minHeight: 180 }}>
                      <EmptyHint icon="mdi:package-variant-closed" text="Search products or add temporary items" />
                    </div>
                  ) : (
                    <Table responsive>
                      <thead style={{ backgroundColor: '#e5e5f8b4', color: 'black' }}>
                        <tr>
                          <th style={{ minWidth: 180 }}>Product</th>
                          <th style={{ width: 110, textAlign: 'center' }}>Quantity</th>
                          <th style={{ minWidth: 80, textAlign: 'right' }}>Total ({currency})</th>
                          <th style={{ width: 40, textAlign: 'center' }}>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {addedProducts.map((item) => {
                          const qty   = Number(item.selectedQty ?? 1)
                          const total = Number(item.price || 0) * qty
                          return (
                            <tr key={item.variant_id}>
                              <td>
                                <div className="d-flex gap-2 align-items-center">
                                  <div style={{ width: 48, height: 48, borderRadius: 8, flexShrink: 0, background: item.isTemp ? 'rgba(var(--bs-primary-rgb),0.08)' : '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <Icon icon={item.isTemp ? 'mdi:package-variant' : 'mdi:barcode'} width={22} style={{ color: item.isTemp ? 'var(--bs-primary)' : '#9ca3af' }} />
                                  </div>
                                  <div>
                                    <div className="fw-semibold" style={{ fontSize: '0.88rem' }}>
                                      {item.isTemp && <Badge bg="secondary" style={{ fontSize: '0.62rem', marginRight: 4, borderRadius: 4 }}>TEMP</Badge>}
                                      {item.title}
                                    </div>
                                    {item.variant_value && <span className="badge badge-pill bg-dark text-light me-1" style={{ fontSize: '0.68rem' }}>{item.variant_value}</span>}
                                    {item.sku && <div className="text-muted" style={{ fontSize: '0.72rem' }}>SKU: {item.sku}</div>}
                                    <div className="text-primary mt-1" style={{ fontSize: '0.82rem' }}>{currency} {Number(item.price).toFixed(2)}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="text-center">
                                <Form.Control type="number" size="sm" min={1} value={item.selectedQty ?? 1} onChange={(e) => handleProductQty(item.variant_id, e.target.value)} style={{ width: 80, textAlign: 'end', margin: '0 auto' }} />
                              </td>
                              <td className="text-end">{total.toFixed(2)}</td>
                              <td className="text-center">
                                <Button variant="link" className="text-danger p-0" onClick={() => removeProduct(item.variant_id)}>
                                  <Icon icon="material-symbols:delete" width={20} style={{ color: '#ff2626' }} />
                                </Button>
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </Table>
                  )}
                </CardBody>
              </Card>
            </Col>

            {/* 4. LABOUR & SERVICE FEE */}
            <Col md={12}>
              <Card className="border" style={{ borderRadius: 12 }}>
                <CardBody>
                  <SectionHeading icon="mdi:account-hard-hat-outline" title="Labour & Service Fee" badge={services.length} />
                  <div className="d-flex gap-2 mb-3 flex-wrap">
                    <Form.Control type="text" placeholder="Service name (e.g. Technician Fee)" value={serviceInput.name} onChange={(e) => setServiceInput((s) => ({ ...s, name: e.target.value }))} style={{ borderRadius: 8, maxWidth: 600 }} />
                    <Form.Control type="number" placeholder="Amount" min={0} value={serviceInput.amount} onChange={(e) => setServiceInput((s) => ({ ...s, amount: e.target.value }))} style={{ borderRadius: 8, maxWidth: 230 }} />
                    <Button variant="outline-primary" onClick={addService} style={{ borderRadius: 8, fontWeight: 600, fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
                      <Icon icon="ic:baseline-plus" width={18} /> Add
                    </Button>
                  </div>
                  {services.length === 0 ? <EmptyHint icon="mdi:account-hard-hat-outline" text="No services added yet" /> : (
                    <Table responsive size="sm" style={{ fontSize: '0.85rem' }}>
                      <thead style={{ backgroundColor: '#e5e5f8b4', color: 'black' }}>
                        <tr><th>Service Name</th><th className="text-end">Amount ({currency})</th><th style={{ width: 40 }} /></tr>
                      </thead>
                      <tbody>
                        {services.map((s) => (
                          <tr key={s.id}>
                            <td>{s.name}</td>
                            <td className="text-end">{s.amount.toFixed(2)}</td>
                            <td className="text-center"><Button variant="link" className="p-0 text-danger" onClick={() => removeService(s.id)}><Icon icon="material-symbols:delete" width={18} /></Button></td>
                          </tr>
                        ))}
                        <tr><td className="fw-semibold">Total</td><td className="text-end fw-semibold">{totalServiceFee.toFixed(2)}</td><td /></tr>
                      </tbody>
                    </Table>
                  )}
                </CardBody>
              </Card>
            </Col>

            {/* 5. SUMMARY */}
            {(services.length > 0 || addedProducts.length > 0) && (
              <Col md={12}>
                <Card className="border mt-1" style={{ maxWidth: 700, borderRadius: 12 }}>
                  <CardHeader className="py-2 fs-5" style={{ backgroundColor: '#e5e5f8b4', color: 'black' }}>Job Summary</CardHeader>
                  <CardBody className="py-2">
                    {addedProducts.length > 0 && <div className="d-flex justify-content-between align-items-center"><div>Billing Items</div><div>{currency} {totalProducts.toFixed(2)}</div></div>}
                    {services.length > 0 && <div className="d-flex justify-content-between align-items-center mt-1"><div>Labour & Service Fee</div><div>{currency} {totalServiceFee.toFixed(2)}</div></div>}
                    <hr className="my-2" />
                    <div className="d-flex justify-content-between align-items-center"><div className="fw-semibold">Grand Total</div><div className="fw-semibold">{currency} {grandTotal.toFixed(2)}</div></div>
                  </CardBody>
                </Card>
              </Col>
            )}

            <Col md={12}>
              <div className="text-end">
                <Button variant="primary" className="bg-primary border-primary px-4" onClick={handleCreate} disabled={isSubmitting}>
                  {isSubmitting ? 'Creating…' : 'Create Job'}
                </Button>
              </div>
            </Col>

          </Row>
        </CardBody>
      </Card>

      {/* ── Job Product Search Modal ── */}
      {showProductModal && (
        <JobProductSearch
          search={search}
          setSearch={setSearch}
          onClose={() => { setShowProductModal(false); setSearch('') }}
          addedProducts={addedProducts}
          setAddedproducts={setAddedproducts}
        />
      )}

    </div>
  )
}
