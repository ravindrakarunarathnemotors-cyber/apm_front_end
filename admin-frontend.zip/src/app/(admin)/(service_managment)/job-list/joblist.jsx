'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import {
  Row, Col, Card, CardHeader, CardBody, CardTitle,
  Form, FormGroup, FormLabel, Button, Table, Spinner,
  Badge, Pagination, Modal,
} from 'react-bootstrap'
import { Icon } from '@iconify/react'
import Swal from 'sweetalert2'
import {
  useGetAllJobsQuery,
  useGetJobByIdQuery,
  useUpdateJobStatusMutation,
  useUpdateJobMutation,
  useAssignUsersToJobMutation,
  useDeleteJobMutation,
  useSearchUsersQuery,
  useSearchProductsQuery,
  useSearchCustomersQuery,
  useGetJobLogsQuery,
  useUpdateJobNoteMutation,
  useConvertJobToInvoiceMutation,
  useGetJobInvoiceQuery,
  useConvertJobToQuotationMutation,
  useGetJobQuotationQuery,
  useUpdateQuotationLinkMutation,

} from '@/store/features/serviceSlice'
import useCurrencySymbol from '@/hooks/useCurrencySymbo'
import UseLogout from '@/hooks/useLogout'
import useRefreshToken from '@/hooks/useRefreshToken'

// ─── Shared helpers ───────────────────────────────────────────────────────────
function SectionHeading({ icon, title, badge }) {
  return (
    <div className="d-flex align-items-center gap-2 mb-3"
      style={{ borderBottom: '1.5px solid #e9ecef', paddingBottom: '10px' }}>
      <div style={{ width: 32, height: 32, borderRadius: '8px', background: 'rgba(var(--bs-primary-rgb),0.10)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon icon={icon} width={17} style={{ color: 'var(--bs-primary)' }} />
      </div>
      <span style={{ fontWeight: 700, fontSize: '0.88rem', color: '#111827' }}>{title}</span>
      {badge !== undefined && badge > 0 && (
        <Badge bg="primary" style={{ fontSize: '0.68rem', borderRadius: '20px', marginLeft: 2 }}>{badge}</Badge>
      )}
    </div>
  )
}

function EmptyHint({ icon, text }) {
  return (
    <div className="d-flex flex-column align-items-center justify-content-center py-4" style={{ color: '#d1d5db' }}>
      <Icon icon={icon} width={36} style={{ opacity: 0.45, marginBottom: 6 }} />
      <span style={{ fontSize: '0.78rem' }}>{text}</span>
    </div>
  )
}

// ─── Product Search Modal ─────────────────────────────────────────────────────
function JobProductSearch({ search, setSearch, onClose, addedProducts, setAddedProducts }) {
  const { data: searchData, isFetching } = useSearchProductsQuery(search, { skip: search.trim().length < 2 })
  const results = searchData?.data ?? []
  const { currency } = useCurrencySymbol()

  const handleSelect = (product) => {
    if (addedProducts.some((p) => p.variant_id === product.variant_id)) {
      Swal.fire({ icon: 'info', title: 'Already added', timer: 1500, showConfirmButton: false })
      return
    }
    setAddedProducts((prev) => [...prev, {
      variant_id: product.variant_id, product_id: product.product_id,
      title: product.title, price: Number(product.variant_price || product.base_price || 0),
      selectedQty: 1, isTemp: false, sku: product.sku, variant_value: product.variant_value,
    }])
    onClose()
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1100, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}>
      <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 580, maxHeight: '80vh', display: 'flex', flexDirection: 'column', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
        onClick={(e) => e.stopPropagation()}>
        <div className="d-flex align-items-center gap-2 p-3" style={{ borderBottom: '1px solid #e9ecef' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <input autoFocus type="search" className="form-control" placeholder="Search by name, SKU…"
              value={search} onChange={(e) => setSearch(e.target.value)} style={{ borderRadius: 8, paddingRight: 36 }} />
            <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af', pointerEvents: 'none' }}>
              {isFetching ? <span className="spinner-border spinner-border-sm" /> : <Icon icon="iconoir:search" width={18} />}
            </span>
          </div>
          <button onClick={onClose} style={{ border: 'none', background: '#f3f4f6', borderRadius: 8, width: 36, height: 36, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon icon="mdi:close" width={18} style={{ color: '#6b7280' }} />
          </button>
        </div>
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {search.trim().length < 2 && <div className="text-center py-5" style={{ color: '#d1d5db', fontSize: '0.85rem' }}>Type at least 2 characters</div>}
          {!isFetching && search.trim().length >= 2 && results.length === 0 && <div className="text-center py-5" style={{ color: '#9ca3af', fontSize: '0.85rem' }}>No products found</div>}
          {!isFetching && results.map((product) => {
            const isAdded = addedProducts.some((p) => p.variant_id === product.variant_id)
            return (
              <div key={product.variant_id}
                className="d-flex align-items-center gap-3 px-3 py-2"
                style={{ cursor: isAdded ? 'default' : 'pointer', borderBottom: '1px solid #f3f4f6', fontSize: '0.85rem', opacity: isAdded ? 0.5 : 1 }}
                onClick={() => { if (!isAdded) handleSelect(product) }}>
                <div style={{ width: 44, height: 44, borderRadius: 8, background: 'rgba(var(--bs-primary-rgb),0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon icon="mdi:package-variant" width={22} style={{ color: 'var(--bs-primary)' }} />
                </div>
                <div className="flex-grow-1 overflow-hidden">
                  <div className="fw-semibold text-truncate">{product.title}</div>
                  <div className="text-muted" style={{ fontSize: '0.75rem' }}>{product.sku && `SKU: ${product.sku}`}</div>
                </div>
                <span className="text-primary fw-semibold">{currency} {Number(product.variant_price || product.base_price || 0).toFixed(2)}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ─── Hold Reason Modal ────────────────────────────────────────────────────────
function HoldReasonModal({ show, onHide, onConfirm }) {
  const [reason, setReason] = useState('')
  const handleConfirm = () => {
    if (!reason.trim()) {
      Swal.fire({ icon: 'warning', title: 'Reason required', text: 'Please enter a hold reason.', timer: 1800, showConfirmButton: false })
      return
    }
    onConfirm(reason.trim())
    setReason('')
  }
  return (
    <Modal show={show} onHide={onHide} centered size="sm">
      <Modal.Header closeButton style={{ background: '#fff8e1', borderBottom: '1px solid #fcd34d' }}>
        <Modal.Title style={{ fontSize: '0.95rem', fontWeight: 700, color: '#b45309', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon icon="mdi:pause-circle-outline" width={18} /> Hold Job
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Label style={{ fontWeight: 600, fontSize: '0.82rem' }}>Reason for Hold <span className="text-danger">*</span></Form.Label>
        <Form.Control as="textarea" rows={3} placeholder="e.g. Waiting for spare parts…"
          value={reason} onChange={(e) => setReason(e.target.value)} style={{ borderRadius: 8, resize: 'none' }} />
      </Modal.Body>
      <Modal.Footer style={{ borderTop: '1px solid #e9ecef' }}>
        <Button variant="secondary" size="sm" onClick={onHide} style={{ borderRadius: 8 }}>Cancel</Button>
        <Button size="sm" onClick={handleConfirm}
          style={{ borderRadius: 8, background: '#b45309', border: 'none', fontWeight: 600 }}>Confirm Hold</Button>
      </Modal.Footer>
    </Modal>
  )
}

// ─── Assign Users Modal ───────────────────────────────────────────────────────
function AssignUsersModal({ show, onHide, jobId, currentAssigned = [], onSaved }) {
  const [userSearch, setUserSearch] = useState('')
  const [selected, setSelected] = useState(currentAssigned)
  const [assignUsers, { isLoading }] = useAssignUsersToJobMutation()
  const { data: usersData, isFetching } = useSearchUsersQuery(userSearch, { skip: false })
  const results = usersData?.data ?? []

  React.useEffect(() => { if (show) setSelected(currentAssigned) }, [show])

  const toggle = (user) => {
    setSelected((prev) =>
      prev.some((u) => u.id === user.id)
        ? prev.filter((u) => u.id !== user.id)
        : [...prev, { id: user.id, name: user.name, role: user.role }]
    )
  }

  const handleSave = async () => {
    try {
      const result = await assignUsers({ id: jobId, users: selected }).unwrap()
      onHide()
      await onSaved(selected)
      Swal.fire({ icon: 'success', title: selected.length > 0 ? `${selected.length} user(s) assigned` : 'Assignment cleared', toast: true, timer: 1800, position: 'top-end', showConfirmButton: false })
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to assign users' })
    }
  }

  return (
    <Modal show={show} onHide={onHide} centered size="sm">
      <Modal.Header closeButton style={{ background: 'linear-gradient(135deg,#1e3a5f,#2563eb)', borderBottom: 'none' }}>
        <Modal.Title style={{ color: '#fff', fontSize: '0.95rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon icon="mdi:account-multiple-plus" width={18} /> Assign Users
        </Modal.Title>
      </Modal.Header>
      <Modal.Body style={{ padding: '1rem' }}>
        {selected.length > 0 && (
          <div className="d-flex flex-wrap gap-1 mb-3">
            {selected.map((u) => (
              <span key={u.id} style={{ background: 'rgba(var(--bs-primary-rgb),0.1)', color: 'var(--bs-primary)', borderRadius: 20, padding: '3px 10px', fontSize: '0.75rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                {u.name}
                <button onClick={() => toggle(u)} style={{ border: 'none', background: 'none', padding: 0, cursor: 'pointer', color: 'inherit', display: 'flex' }}>
                  <Icon icon="mdi:close" width={12} />
                </button>
              </span>
            ))}
          </div>
        )}
        <div style={{ position: 'relative', marginBottom: 8 }}>
          <Form.Control type="search" placeholder="Search users…" size="sm"
            value={userSearch} onChange={(e) => setUserSearch(e.target.value)}
            style={{ borderRadius: 8, paddingRight: 32 }} />
          <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }}>
            {isFetching ? <span className="spinner-border spinner-border-sm" style={{ width: 12, height: 12 }} /> : <Icon icon="iconoir:search" width={14} />}
          </span>
        </div>
        <div style={{ maxHeight: 220, overflowY: 'auto', border: '1px solid #e9ecef', borderRadius: 8 }}>
          {results.length === 0 && !isFetching && (
            <div className="text-center py-3" style={{ fontSize: '0.78rem', color: '#9ca3af' }}>No users found</div>
          )}
          {results.map((u) => {
            const isSelected = selected.some((s) => s.id === u.id)
            return (
              <div key={u.id} onClick={() => toggle(u)}
                style={{ padding: '8px 12px', cursor: 'pointer', borderBottom: '1px solid #f3f4f6', display: 'flex', alignItems: 'center', gap: 10, background: isSelected ? 'rgba(var(--bs-primary-rgb),0.06)' : '#fff' }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'rgba(var(--bs-primary-rgb),0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon icon="mdi:account" width={16} style={{ color: 'var(--bs-primary)' }} />
                </div>
                <div className="flex-grow-1">
                  <div style={{ fontSize: '0.83rem', fontWeight: 600 }}>{u.name}</div>
                  <div style={{ fontSize: '0.72rem', color: '#6b7280' }}>{u.role} {u.email ? `· ${u.email}` : ''}</div>
                </div>
                {isSelected && <Icon icon="mdi:check-circle" width={18} style={{ color: 'var(--bs-primary)', flexShrink: 0 }} />}
              </div>
            )
          })}
        </div>
      </Modal.Body>
      <Modal.Footer style={{ borderTop: '1px solid #e9ecef' }}>
        <Button variant="secondary" size="sm" onClick={onHide} style={{ borderRadius: 8 }}>Cancel</Button>
        <Button size="sm" onClick={handleSave} disabled={isLoading} style={{ borderRadius: 8, background: 'var(--bs-primary)', border: 'none', fontWeight: 600 }}>
          {isLoading ? 'Saving…' : `Save (${selected.length})`}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

// ─── Status helpers ───────────────────────────────────────────────────────────
function StatusDot({ status }) {
  const colorMap = {
    PENDING: '#ffc107',
    ASSIGNED: '#3b82f6',
    IN_PROGRESS: '#8b5cf6',
    ON_HOLD: '#f97316',
    COMPLETED: '#198754',
    CLOSED: '#6b7280',
    CANCELLED: '#dc3545',
  }
  const color = colorMap[status] || '#6c757d'
  return (
    <span className="d-flex align-items-center gap-1" style={{ fontSize: '0.82rem', fontWeight: 500, color: '#374151' }}>
      <span style={{ width: 8, height: 8, borderRadius: '50%', backgroundColor: color, display: 'inline-block' }} />
      {status?.replace(/_/g, ' ')}
    </span>
  )
}

function StatusPill({ status }) {
  const map = {
    PENDING: { bg: '#fff8e1', color: '#b45309', border: '#fcd34d' },
    IN_PROGRESS: { bg: '#eff6ff', color: '#1d4ed8', border: '#93c5fd' },
    COMPLETED: { bg: '#f0fdf4', color: '#15803d', border: '#86efac' },
    CANCELLED: { bg: '#fff1f2', color: '#be123c', border: '#fda4af' },
    ON_HOLD: { bg: '#fff7ed', color: '#c2410c', border: '#fdba74' },
  }
  const s = map[status] || { bg: '#f3f4f6', color: '#374151', border: '#d1d5db' }
  return (
    <span style={{ backgroundColor: s.bg, color: s.color, border: `1px solid ${s.border}`, borderRadius: 20, padding: '3px 12px' }}>
      {status?.replace('_', ' ')}
    </span>
  )
}

// ─── Job Invoice Modal (inline, no external imports) ─────────────────────────
function JobInvoiceModal({ show, onHide, invoiceId, jobName }) {
  const { currency } = useCurrencySymbol()

  const { data, isLoading } = useGetJobInvoiceQuery(invoiceId, { skip: !invoiceId || !show })

  const order = data?.order ?? null
  const invoiceItems = data?.items ?? []
  const branding = data?.branding ?? null

  // ── derived values ──────────────────────────────────────────────────────────
  const subTotal = Number(order?.total_value || 0)
  const fullAmount = Number(order?.full_amount || 0)
  const amountPaid = Number(order?.amount_paid || 0)
  const taxAmount = Number(order?.tax?.value || 0)
  const taxName = order?.tax?.name || 'Tax'
  const taxPct = order?.tax_percentage
  const orderDiscount = Number(order?.discount || 0)
  const paymentStatus = order?.status
  const hasItemDiscount = invoiceItems.some((it) => Number(it.discount || 0) > 0)

  const statusColors = {
    paid: { bg: '#f0fdf4', color: '#15803d', border: '#86efac' },
    unpaid: { bg: '#fff1f2', color: '#be123c', border: '#fda4af' },
    'partially paid': { bg: '#fff8e1', color: '#b45309', border: '#fcd34d' },
  }
  const sc = statusColors[paymentStatus] || { bg: '#f3f4f6', color: '#374151', border: '#d1d5db' }

  const fmt = (v) => Number(v || 0).toFixed(2)
  const fmtDate = (d) => {
    if (!d) return '—'
    return new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
  }

  // ── print ───────────────────────────────────────────────────────────────────
  const handlePrint = () => {
    const productsHtml = invoiceItems.map((it, i) => `
      <tr>
        <td style="text-align:center;color:#6b7280;padding:9px 12px">${i + 1}</td>
        <td style="padding:9px 12px">
          <div style="font-weight:600">#${it.product_id || '—'} — ${it.name}</div>
          ${it.variant_value && it.variant_value !== 'Default' ? `<div style="font-size:11px;color:#9ca3af">${it.variant_value}</div>` : ''}
        </td>
        <td style="text-align:center;padding:9px 12px">${it.quantity}</td>
        <td style="text-align:right;padding:9px 12px">${fmt(it.unit_price)}</td>
        <td style="text-align:right;padding:9px 12px;font-weight:600">${fmt(it.total_price)}</td>
      </tr>`).join('')

    const w = window.open('', '_blank', 'width=860,height=700')
    w.document.write(`<!DOCTYPE html><html><head>
    <title>Invoice #${invoiceId}</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600;700&display=swap');
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'DM Sans',sans-serif;font-size:13px;color:#111827;background:#fff}
      .page{width:100%;max-width:760px;margin:0 auto;padding:44px 52px}
      .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid #111827}
      .title{font-family:'DM Serif Display',serif;font-size:28px;color:#111827;letter-spacing:-0.5px}
      .badge-dark{background:#111827;color:#fff;font-size:11px;font-weight:700;border-radius:4px;padding:4px 12px;display:inline-block}
      .status-pill{display:inline-block;padding:3px 14px;border-radius:20px;font-size:11px;font-weight:700;background:${sc.bg};color:${sc.color};border:1.5px solid ${sc.border}}
      .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:24px}
      .info-card{border:1.5px solid #e5e7eb;border-radius:10px;padding:14px 18px}
      .info-card.accent{border-color:#111827;background:#f9fafb}
      .lbl{font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px}
      .val{font-size:14px;font-weight:700;color:#111827}
      .sub{font-size:11px;color:#6b7280;margin-top:3px}
      table{width:100%;border-collapse:collapse;margin-bottom:18px}
      thead tr{background:#111827}
      thead th{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:10px 12px;text-align:left}
      tbody tr{border-bottom:1px solid #f3f4f6}
      tbody tr:nth-child(even){background:#fafafa}
      tfoot tr td{font-weight:700;border-top:2px solid #e5e7eb;padding:10px 12px;background:#f9fafb}
      .summary{border:1.5px solid #111827;border-radius:10px;padding:16px 20px;max-width:300px;margin-left:auto;margin-bottom:24px;background:#f9fafb}
      .sum-row{display:flex;justify-content:space-between;font-size:12px;color:#374151;padding:4px 0}
      .sum-row.total{font-size:15px;font-weight:700;color:#111827;border-top:1.5px solid #e5e7eb;padding-top:10px;margin-top:6px}
      .footer{margin-top:40px;padding-top:14px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;font-size:10px;color:#9ca3af}
      @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{padding:32px 40px}}
    </style></head><body>
    <div class="page">
      <div class="header">
        <div>
          <div class="title">Invoice</div>
          <div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.12em;margin-top:4px">From Job: ${jobName || ''}</div>
        </div>
        <div style="text-align:right">
          <div class="badge-dark">#${invoiceId}</div>
          <div style="margin-top:6px"><span class="status-pill">${(paymentStatus || '').toUpperCase()}</span></div>
          <div style="font-size:11px;color:#6b7280;margin-top:6px">Printed: ${fmtDate(new Date())}</div>
        </div>
      </div>
      <div class="info-grid">
        <div class="info-card accent">
          <div class="lbl">From</div>
          <div class="val">${branding?.company_name || '—'}</div>
          ${branding?.address_1 ? `<div class="sub">${branding.address_1}</div>` : ''}
          ${branding?.hotline ? `<div class="sub">Hotline: ${branding.hotline}</div>` : ''}
        </div>
        <div class="info-card">
          <div class="lbl">Invoice To</div>
          <div class="val">${order?.sender_name || '—'}</div>
          ${order?.sender_phone ? `<div class="sub">${order.sender_phone}</div>` : ''}
          ${order?.sender_email ? `<div class="sub">${order.sender_email}</div>` : ''}
        </div>
      </div>
      <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#6b7280;margin-bottom:10px">Line Items</div>
      <table>
        <thead><tr>
          <th style="width:36px;text-align:center">#</th>
          <th>Description</th>
          <th style="width:70px;text-align:center">Qty</th>
          <th style="width:110px;text-align:right">Unit Price</th>
          <th style="width:110px;text-align:right">Total</th>
        </tr></thead>
        <tbody>${productsHtml}</tbody>
        <tfoot><tr>
          <td colspan="4" style="text-align:right;padding:10px 12px">Subtotal</td>
          <td style="text-align:right;padding:10px 12px">${fmt(subTotal)}</td>
        </tr></tfoot>
      </table>
      <div class="summary">
        <div class="sum-row"><span>Subtotal</span><span>${fmt(subTotal)}</span></div>
        ${orderDiscount > 0 ? `<div class="sum-row"><span>Discount</span><span>-${fmt(orderDiscount)}</span></div>` : ''}
        ${taxAmount > 0 ? `<div class="sum-row"><span>${taxName} (${taxPct}%)</span><span>${fmt(taxAmount)}</span></div>` : ''}
        <div class="sum-row total"><span>Total</span><span>${fmt(fullAmount)}</span></div>
        ${amountPaid > 0 ? `<div class="sum-row"><span>Paid</span><span>${fmt(amountPaid)}</span></div>` : ''}
      </div>
      <div class="footer">
        <span>Invoice #${invoiceId}</span>
        <span>Thank you for your business.</span>
      </div>
    </div>
    </body></html>`)
    w.document.close()
    w.focus()
    setTimeout(() => { w.print(); w.close() }, 400)
  }

  // ── render ──────────────────────────────────────────────────────────────────
  return (
    <Modal show={show} onHide={onHide} centered size="lg" scrollable style={{ zIndex: 1060 }}
      backdropClassName="invoice-backdrop">
      <style>{`
        .invoice-backdrop { 
          z-index: 1055 !important;
          background-color: rgba(0, 0, 0, 0.75) !important;
          opacity: 1 !important;
          animation: backdropFadeIn 0.25s ease forwards;
        }
        
        @keyframes backdropFadeIn {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
      `}</style>

      <Modal.Header closeButton closeVariant="white"
        style={{ background: 'linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%)', borderBottom: 'none', padding: '0.9rem 1.4rem' }}>
        <Modal.Title style={{ color: '#fff', fontSize: '0.97rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
          <Icon icon="mdi:receipt-text-outline" width={20} />
          Invoice&nbsp;
          {invoiceId ? <span style={{ opacity: 0.8, fontWeight: 400 }}>#{invoiceId}</span> : ''}
          {jobName && <span style={{ opacity: 0.55, fontSize: '0.78rem', fontWeight: 400, marginLeft: 4 }}>· {jobName}</span>}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body style={{ background: '#f8fafc', padding: '1.2rem 1.4rem' }}>
        {isLoading ? (
          <div className="text-center py-5"><Spinner animation="border" /></div>
        ) : !order ? (
          <div className="text-center py-5 text-muted">Invoice data not found.</div>
        ) : (
          <>
            {/* ── Top meta bar ── */}
            <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
              <div className="d-flex align-items-center gap-2 flex-wrap">
                <span style={{ fontWeight: 700, fontSize: '1.05rem', color: '#111827' }}>#{invoiceId}</span>
                <span style={{ padding: '3px 12px', borderRadius: 20, fontSize: '0.75rem', fontWeight: 700, background: sc.bg, color: sc.color, border: `1.5px solid ${sc.border}` }}>
                  {(paymentStatus || '').toUpperCase()}
                </span>
                <span style={{ fontSize: '0.78rem', color: '#9ca3af' }}>
                  {order.created_at ? new Date(order.created_at).toLocaleString('en-GB', {
                    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
                  }) : '—'}
                </span>
              </div>
              <span style={{ fontSize: '0.78rem', color: '#6b7280' }}>Interface: {order.interface || '—'}</span>
            </div>

            {/* ── From / To ── */}
            <div className="d-flex gap-3 mb-3 flex-wrap">
              <div style={{ flex: '1 1 220px', background: '#fff', border: '1.5px solid #111827', borderRadius: 10, padding: '12px 16px' }}>
                <div style={{ fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#9ca3af', marginBottom: 6 }}>From</div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{branding?.company_name || '—'}</div>
                {branding?.address_1 && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>{branding.address_1}</div>}
                {branding?.address_2 && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>{branding.address_2}</div>}
                {branding?.hotline && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>Hotline: {branding.hotline}</div>}
              </div>
              <div style={{ flex: '1 1 220px', background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 10, padding: '12px 16px' }}>
                <div style={{ fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#9ca3af', marginBottom: 6 }}>Invoice To</div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{order.sender_name || '—'}</div>
                {order.sender_phone && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}><Icon icon="mdi:phone" width={12} className="me-1" />{order.sender_phone}</div>}
                {order.sender_email && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}><Icon icon="mdi:email-outline" width={12} className="me-1" />{order.sender_email}</div>}
                {order.sender_address && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}><Icon icon="mdi:map-marker-outline" width={12} className="me-1" />{order.sender_address}</div>}
              </div>
            </div>

            {/* ── Line items table ── */}
            <div style={{ background: '#fff', border: '1.5px solid #e5e7eb', borderRadius: 10, overflow: 'hidden', marginBottom: 12 }}>
              <div style={{ padding: '10px 16px', borderBottom: '1.5px solid #e5e7eb', fontWeight: 700, fontSize: '0.8rem', color: '#374151', display: 'flex', alignItems: 'center', gap: 6 }}>
                <Icon icon="mdi:format-list-bulleted" width={15} style={{ color: 'var(--bs-primary)' }} />
                Line Items
                <Badge bg="primary" style={{ fontSize: '0.65rem', borderRadius: 20 }}>{invoiceItems.length}</Badge>
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                  <thead>
                    <tr style={{ background: '#1e3a5f' }}>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'center', width: 36 }}>#</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase' }}>Description</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'center', width: 70 }}>Qty</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 110 }}>Unit Price</th>
                      {hasItemDiscount && <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 90 }}>Discount</th>}
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 110 }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoiceItems.length === 0 ? (
                      <tr><td colSpan={hasItemDiscount ? 6 : 5} style={{ textAlign: 'center', padding: '24px', color: '#9ca3af', fontSize: '0.8rem' }}>No line items</td></tr>
                    ) : invoiceItems.map((it, idx) => (
                      <tr key={idx} style={{ borderBottom: '1px solid #f3f4f6', background: idx % 2 === 1 ? '#fafafa' : '#fff' }}>
                        <td style={{ padding: '9px 12px', textAlign: 'center', color: '#9ca3af' }}>{idx + 1}</td>
                        <td style={{ padding: '9px 12px' }}>
                          <div style={{ fontWeight: 600 }}>
                            {it.is_custom
                              ? <Badge bg="secondary" style={{ fontSize: '0.6rem', marginRight: 4 }}>SERVICE</Badge>
                              : <span style={{ fontSize: '0.72rem', color: '#9ca3af', marginRight: 4 }}>#{it.product_id}</span>
                            }
                            {it.name}
                          </div>
                          {it.variant_value && it.variant_value !== 'Default' && (
                            <div style={{ fontSize: '0.72rem', color: '#9ca3af' }}>{it.variant_value}</div>
                          )}
                        </td>
                        <td style={{ padding: '9px 12px', textAlign: 'center' }}>{it.quantity}</td>
                        <td style={{ padding: '9px 12px', textAlign: 'right' }}>{fmt(it.unit_price)}</td>
                        {hasItemDiscount && <td style={{ padding: '9px 12px', textAlign: 'right', color: '#dc3545' }}>{fmt(it.discount)}</td>}
                        <td style={{ padding: '9px 12px', textAlign: 'right', fontWeight: 600 }}>{fmt(it.total_price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals */}
              <div style={{ padding: '10px 16px', borderTop: '1.5px solid #e5e7eb', display: 'flex', justifyContent: 'flex-end' }}>
                <div style={{ minWidth: 260 }}>
                  {[
                    { label: 'Subtotal', value: fmt(subTotal) },
                    ...(orderDiscount > 0 ? [{ label: 'Discount', value: `-${fmt(orderDiscount)}`, color: '#dc3545' }] : []),
                    ...(taxAmount > 0 ? [{ label: `${taxName} (${taxPct}%)`, value: fmt(taxAmount) }] : []),
                  ].map((row, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: row.color || '#374151', padding: '3px 0' }}>
                      <span>{row.label}</span><span>{row.value}</span>
                    </div>
                  ))}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '0.95rem', color: '#111827', borderTop: '1.5px solid #e5e7eb', paddingTop: 8, marginTop: 4 }}>
                    <span>Total</span><span>{currency} {fmt(fullAmount)}</span>
                  </div>
                  {amountPaid > 0 && (
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#15803d', padding: '3px 0' }}>
                      <span>Paid</span><span>{currency} {fmt(amountPaid)}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </Modal.Body>

      <Modal.Footer style={{ background: '#f8fafc', borderTop: '1px solid #e5e7eb', gap: 8 }}>
        <Button variant="outline-secondary" size="sm" onClick={handlePrint}
          style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
          <Icon icon="mdi:printer-outline" width={15} /> Print
        </Button>
        <div style={{ flex: 1 }} />
        <Button variant="secondary" size="sm" onClick={onHide} style={{ borderRadius: 8, fontWeight: 600 }}>Close</Button>
      </Modal.Footer>
    </Modal>
  )
}

function QuotationTriggerButton({ isQuoting, onConfirm }) {
  const [show, setShow] = useState(false)
  const [timePeriod, setTimePeriod] = useState('7')

  const handleConfirm = () => {
    if (!timePeriod || isNaN(Number(timePeriod)) || Number(timePeriod) < 1) {
      Swal.fire({
        icon: 'warning', title: 'Invalid period',
        text: 'Enter a valid number of days.', timer: 1800, showConfirmButton: false
      })
      return
    }
    setShow(false)
    onConfirm(Number(timePeriod))
  }

  return (
    <>
      <Button variant="outline-success" disabled={isQuoting}
        onClick={() => setShow(true)}
        style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
        {isQuoting
          ? <><Spinner animation="border" size="sm" style={{ width: 13, height: 13 }} /> Creating…</>
          : <><Icon icon="mdi:file-document-outline" width={16} /> Quotation</>
        }
      </Button>

      <Modal show={show} onHide={() => setShow(false)} centered size="sm">
        <Modal.Header closeButton style={{ background: '#f0fdf4', borderBottom: '1px solid #86efac' }}>
          <Modal.Title style={{
            fontSize: '0.95rem', fontWeight: 700, color: '#15803d',
            display: 'flex', alignItems: 'center', gap: 6
          }}>
            <Icon icon="mdi:file-document-outline" width={18} /> Create Quotation
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Label style={{ fontWeight: 600, fontSize: '0.82rem' }}>
            Valid for (days) <span className="text-danger">*</span>
          </Form.Label>
          <Form.Control type="number" min={1} placeholder="e.g. 7"
            value={timePeriod} onChange={(e) => setTimePeriod(e.target.value)}
            style={{ borderRadius: 8 }} />
          <div style={{ fontSize: '0.75rem', color: '#6b7280', marginTop: 6 }}>
            Quotation will be valid for <strong>{timePeriod || '—'}</strong> day(s) from today.
          </div>
        </Modal.Body>
        <Modal.Footer style={{ borderTop: '1px solid #e9ecef' }}>
          <Button variant="secondary" size="sm" onClick={() => setShow(false)}
            style={{ borderRadius: 8 }}>Cancel</Button>
          <Button size="sm" onClick={handleConfirm}
            style={{ borderRadius: 8, background: '#15803d', border: 'none', fontWeight: 600 }}>
            Create Quotation
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

function JobQuotationModal({ show, onHide, quotationId, jobName }) {
  const { currency } = useCurrencySymbol()
  const { data, isLoading } = useGetJobQuotationQuery(quotationId, { skip: !quotationId || !show })
  const [updateQuotationLink] = useUpdateQuotationLinkMutation()

  const [uploadStatus, setUploadStatus] = useState(null) // null | 'uploading' | 'done' | 'error'
  const [s3Url, setS3Url] = useState(null)
  const hasUploaded = React.useRef(false)

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  const order = data?.order ?? null
  const quotationItems = data?.items ?? []
  const branding = data?.branding ?? null

  const subTotal = Number(order?.total_value || 0)
  const fullAmount = Number(order?.full_amount || 0)
  const orderDiscount = Number(order?.discount || 0)
  const paymentStatus = order?.payment_status
  const timePeriod = order?.time_period
  const quotationDate = order?.quotation_date
  const hasItemDiscount = quotationItems.some((it) => Number(it.discount || 0) > 0)

  const sc = { bg: '#eff6ff', color: '#1d4ed8', border: '#93c5fd' }
  const fmt = (v) => Number(v || 0).toFixed(2)
  const fmtDate = (d) => d
    ? new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    : '—'

  // ── Build HTML for both print and S3 upload ────────────────────────────────
  const buildPrintHtml = () => {
    const itemsHtml = quotationItems.map((it, i) => `
      <tr>
        <td style="text-align:center;color:#6b7280;padding:9px 12px">${i + 1}</td>
        <td style="padding:9px 12px">
          <div style="font-weight:600">
            ${it.is_custom
        ? '<span style="background:#e5e7eb;border-radius:3px;padding:1px 5px;font-size:9px;font-weight:700;color:#374151;margin-right:4px">SERVICE</span>'
        : `<span style="font-size:11px;color:#9ca3af;margin-right:4px">#${it.product_id || '—'}</span>`
      }${it.name}
          </div>
        </td>
        <td style="text-align:center;padding:9px 12px">${it.quantity}</td>
        <td style="text-align:right;padding:9px 12px">${fmt(it.unit_price)}</td>
        <td style="text-align:right;padding:9px 12px;font-weight:600">${fmt(it.total_price)}</td>
      </tr>`).join('')

    return `<!DOCTYPE html><html><head><title>Quotation #${quotationId}</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600;700&display=swap');
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:'DM Sans',sans-serif;font-size:13px;color:#111827;background:#fff}
      .page{width:100%;max-width:760px;margin:0 auto;padding:44px 52px}
      .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px;padding-bottom:20px;border-bottom:2px solid #111827}
      .title{font-family:'DM Serif Display',serif;font-size:28px;color:#111827;letter-spacing:-0.5px}
      .badge-dark{background:#111827;color:#fff;font-size:11px;font-weight:700;border-radius:4px;padding:4px 12px;display:inline-block}
      .validity{background:#f0fdf4;border:1px solid #86efac;border-radius:6px;padding:6px 14px;font-size:11px;font-weight:600;color:#15803d;margin-top:8px;display:inline-block}
      .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:24px}
      .info-card{border:1.5px solid #e5e7eb;border-radius:10px;padding:14px 18px}
      .info-card.accent{border-color:#111827;background:#f9fafb}
      .lbl{font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px}
      .val{font-size:14px;font-weight:700;color:#111827}
      .sub{font-size:11px;color:#6b7280;margin-top:3px}
      table{width:100%;border-collapse:collapse;margin-bottom:18px}
      thead tr{background:#15803d}
      thead th{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:10px 12px;text-align:left}
      tbody tr{border-bottom:1px solid #f3f4f6}
      tbody tr:nth-child(even){background:#fafafa}
      tfoot tr td{font-weight:700;border-top:2px solid #e5e7eb;padding:10px 12px;background:#f9fafb}
      .summary{border:1.5px solid #111827;border-radius:10px;padding:16px 20px;max-width:300px;margin-left:auto;margin-bottom:24px;background:#f9fafb}
      .sum-row{display:flex;justify-content:space-between;font-size:12px;color:#374151;padding:4px 0}
      .sum-row.total{font-size:15px;font-weight:700;color:#111827;border-top:1.5px solid #e5e7eb;padding-top:10px;margin-top:6px}
      .validity-note{border:1px solid #86efac;border-radius:8px;padding:10px 14px;background:#f0fdf4;font-size:11px;color:#15803d;margin-bottom:16px}
      .footer{margin-top:40px;padding-top:14px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;font-size:10px;color:#9ca3af}
      @media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{padding:32px 40px}}
    </style></head><body>
    <div class="page">
      <div class="header">
        <div>
          <div class="title">Quotation</div>
          <div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.12em;margin-top:4px">
            From Job: ${jobName || ''}
          </div>
        </div>
        <div style="text-align:right">
          <div class="badge-dark">#${quotationId}</div>
          ${timePeriod ? `<div class="validity">Valid ${timePeriod} days · Issued: ${fmtDate(quotationDate)}</div>` : ''}
          <div style="font-size:11px;color:#6b7280;margin-top:6px">Generated: ${fmtDate(new Date())}</div>
        </div>
      </div>
      <div class="info-grid">
        <div class="info-card accent">
          <div class="lbl">From</div>
          <div class="val">${branding?.company_name || '—'}</div>
          ${branding?.address_1 ? `<div class="sub">${branding.address_1}</div>` : ''}
          ${branding?.hotline ? `<div class="sub">Hotline: ${branding.hotline}</div>` : ''}
        </div>
        <div class="info-card">
          <div class="lbl">Quotation To</div>
          <div class="val">${order?.sender_name || '—'}</div>
          ${order?.sender_phone ? `<div class="sub">${order.sender_phone}</div>` : ''}
          ${order?.sender_email ? `<div class="sub">${order.sender_email}</div>` : ''}
        </div>
      </div>
      <table>
        <thead><tr>
          <th style="width:36px;text-align:center">#</th>
          <th>Description</th>
          <th style="width:70px;text-align:center">Qty</th>
          <th style="width:110px;text-align:right">Unit Price</th>
          <th style="width:110px;text-align:right">Total</th>
        </tr></thead>
        <tbody>${itemsHtml}</tbody>
        <tfoot><tr>
          <td colspan="4" style="text-align:right;padding:10px 12px">Subtotal</td>
          <td style="text-align:right;padding:10px 12px">${fmt(subTotal)}</td>
        </tr></tfoot>
      </table>
      <div class="summary">
        <div class="sum-row"><span>Subtotal</span><span>${fmt(subTotal)}</span></div>
        ${orderDiscount > 0 ? `<div class="sum-row"><span>Discount</span><span>-${fmt(orderDiscount)}</span></div>` : ''}
        <div class="sum-row total"><span>Total</span><span>${currency} ${fmt(fullAmount)}</span></div>
      </div>
      ${timePeriod ? `<div class="validity-note">This quotation is valid for <strong>${timePeriod} days</strong> from the date of issue (${fmtDate(quotationDate)}).</div>` : ''}
      <div class="footer">
        <span>Quotation #${quotationId}</span>
        <span>Thank you for your interest.</span>
      </div>
    </div></body></html>`
  }

  // ── Auto upload when modal opens and data is ready ─────────────────────────
  useEffect(() => {
    if (!show || !order || !quotationId || hasUploaded.current) return

    // Already has a stored link — just use it
    if (order.quotation_link) {
      setS3Url(order.quotation_link)
      hasUploaded.current = true
      return
    }

    const uploadQuotationFile = async () => {
      setUploadStatus('uploading')
      hasUploaded.current = true

      try {
        // Build HTML blob
        const htmlContent = buildPrintHtml()
        const blob = new Blob([htmlContent], { type: 'text/html' })
        const file = new File(
          [blob],
          `quotation-${quotationId}-${Date.now()}.html`,
          { type: 'text/html' }
        )

        // Upload to S3
        const formData = new FormData()
        formData.append('file', file)
        formData.append('file_type', 'quotation')

        const uploadRes = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/emsupload/upload-ems`,
          {
            method: 'POST',
            headers: {},
            body: formData,
          }
        )

        if (!uploadRes.ok) throw new Error('Upload failed')
        const { url } = await uploadRes.json()

        // Save link to DB
        await updateQuotationLink({ quotationId, quotation_link: url }).unwrap()

        setS3Url(url)
        setUploadStatus('done')
      } catch (err) {
        console.error('[QuotationUpload] Failed:', err)
        setUploadStatus('error')
        hasUploaded.current = false // allow retry on next open
      }
    }

    uploadQuotationFile()
  }, [show, order, quotationId])

  // ── Reset when modal closes ────────────────────────────────────────────────
  useEffect(() => {
    if (!show) {
      hasUploaded.current = false
      setUploadStatus(null)
      setS3Url(null)
    }
  }, [show])

  const handlePrint = () => {
    const w = window.open('', '_blank', 'width=860,height=700')
    w.document.write(buildPrintHtml())
    w.document.close()
    w.focus()
    setTimeout(() => { w.print(); w.close() }, 400)
  }

  return (
    <Modal show={show} onHide={onHide} centered size="lg" scrollable
      style={{ zIndex: 1060 }} backdropClassName="invoice-backdrop">
      <style>{`
          .invoice-backdrop { 
            z-index: 1055 !important;
            background-color: rgba(0, 0, 0, 0.75) !important;
            opacity: 1 !important;
            animation: backdropFadeIn 0.25s ease forwards;
          }
          @keyframes backdropFadeIn {
            from { opacity: 0; }
            to   { opacity: 1; }
          }
        `}</style>
      <Modal.Header closeButton closeVariant="white"
        style={{
          background: 'linear-gradient(135deg,#15803d 0%,#16a34a 100%)',
          borderBottom: 'none', padding: '0.9rem 1.4rem'
        }}>
        <Modal.Title style={{
          color: '#fff', fontSize: '0.97rem', fontWeight: 700,
          display: 'flex', alignItems: 'center', gap: 8
        }}>
          <Icon icon="mdi:file-document-outline" width={20} />
          Quotation&nbsp;
          {quotationId && <span style={{ opacity: 0.8, fontWeight: 400 }}>#{quotationId}</span>}
          {jobName && <span style={{ opacity: 0.55, fontSize: '0.78rem', fontWeight: 400, marginLeft: 4 }}>· {jobName}</span>}
        </Modal.Title>
      </Modal.Header>

      <Modal.Body style={{ background: '#f8fafc', padding: '1.2rem 1.4rem' }}>
        {isLoading ? (
          <div className="text-center py-5"><Spinner animation="border" /></div>
        ) : !order ? (
          <div className="text-center py-5 text-muted">Quotation data not found.</div>
        ) : (
          <>
            {/* Upload status bar */}
            {uploadStatus === 'uploading' && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: '#eff6ff', border: '1px solid #93c5fd', borderRadius: 8,
                padding: '8px 14px', marginBottom: 12, fontSize: '0.8rem', color: '#1d4ed8'
              }}>
                <Spinner animation="border" size="sm" style={{ width: 14, height: 14 }} />
                Saving quotation to cloud…
              </div>
            )}
            {uploadStatus === 'done' && s3Url && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
                padding: '8px 14px', marginBottom: 12, fontSize: '0.8rem', color: '#15803d'
              }}>
                <Icon icon="mdi:cloud-check-outline" width={16} />
                Quotation saved to cloud.&nbsp;
                <a href={s3Url} target="_blank" rel="noreferrer"
                  style={{ color: '#15803d', fontWeight: 600, textDecoration: 'underline' }}>
                  View file
                </a>
              </div>
            )}
            {/* Show stored link if already uploaded previously */}
            {uploadStatus === null && s3Url && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: '#f0fdf4', border: '1px solid #86efac', borderRadius: 8,
                padding: '8px 14px', marginBottom: 12, fontSize: '0.8rem', color: '#15803d'
              }}>
                <Icon icon="mdi:cloud-check-outline" width={16} />
                Quotation stored in cloud.&nbsp;
                <a href={s3Url} target="_blank" rel="noreferrer"
                  style={{ color: '#15803d', fontWeight: 600, textDecoration: 'underline' }}>
                  View file
                </a>
              </div>
            )}
            {uploadStatus === 'error' && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: '#fff1f2', border: '1px solid #fda4af', borderRadius: 8,
                padding: '8px 14px', marginBottom: 12, fontSize: '0.8rem', color: '#be123c'
              }}>
                <Icon icon="mdi:alert-outline" width={16} />
                Cloud save failed. Quotation is still accessible below.
              </div>
            )}

            {/* Meta bar */}
            <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
              <div className="d-flex align-items-center gap-2 flex-wrap">
                <span style={{ fontWeight: 700, fontSize: '1.05rem', color: '#111827' }}>#{quotationId}</span>
                <span style={{
                  padding: '3px 12px', borderRadius: 20, fontSize: '0.75rem',
                  fontWeight: 700, background: sc.bg, color: sc.color, border: `1.5px solid ${sc.border}`
                }}>
                  {(paymentStatus || 'SENT').toUpperCase()}
                </span>
                {timePeriod && (
                  <span style={{
                    padding: '3px 10px', borderRadius: 20, fontSize: '0.72rem',
                    fontWeight: 600, background: '#f0fdf4', color: '#15803d', border: '1px solid #86efac'
                  }}>
                    <Icon icon="mdi:clock-outline" width={12} className="me-1" />
                    Valid {timePeriod} days · Issued {fmtDate(quotationDate)}
                  </span>
                )}
              </div>
            </div>

            {/* From / To */}
            <div className="d-flex gap-3 mb-3 flex-wrap">
              <div style={{
                flex: '1 1 220px', background: '#fff', border: '1.5px solid #111827',
                borderRadius: 10, padding: '12px 16px'
              }}>
                <div style={{
                  fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase',
                  letterSpacing: '0.1em', color: '#9ca3af', marginBottom: 6
                }}>From</div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{branding?.company_name || '—'}</div>
                {branding?.address_1 && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>{branding.address_1}</div>}
                {branding?.hotline && <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>Hotline: {branding.hotline}</div>}
              </div>
              <div style={{
                flex: '1 1 220px', background: '#fff', border: '1.5px solid #e5e7eb',
                borderRadius: 10, padding: '12px 16px'
              }}>
                <div style={{
                  fontSize: '0.68rem', fontWeight: 700, textTransform: 'uppercase',
                  letterSpacing: '0.1em', color: '#9ca3af', marginBottom: 6
                }}>Quotation To</div>
                <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{order.sender_name || '—'}</div>
                {order.sender_phone && (
                  <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>
                    <Icon icon="mdi:phone" width={12} className="me-1" />{order.sender_phone}
                  </div>
                )}
                {order.sender_email && (
                  <div style={{ fontSize: '0.78rem', color: '#6b7280' }}>
                    <Icon icon="mdi:email-outline" width={12} className="me-1" />{order.sender_email}
                  </div>
                )}
              </div>
            </div>

            {/* Line items table */}
            <div style={{
              background: '#fff', border: '1.5px solid #e5e7eb',
              borderRadius: 10, overflow: 'hidden', marginBottom: 12
            }}>
              <div style={{
                padding: '10px 16px', borderBottom: '1.5px solid #e5e7eb',
                fontWeight: 700, fontSize: '0.8rem', color: '#374151',
                display: 'flex', alignItems: 'center', gap: 6
              }}>
                <Icon icon="mdi:format-list-bulleted" width={15} style={{ color: '#15803d' }} />
                Line Items
                <Badge bg="success" style={{ fontSize: '0.65rem', borderRadius: 20 }}>{quotationItems.length}</Badge>
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.83rem' }}>
                  <thead>
                    <tr style={{ background: '#15803d' }}>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'center', width: 36 }}>#</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase' }}>Description</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'center', width: 70 }}>Qty</th>
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 110 }}>Unit Price</th>
                      {hasItemDiscount && <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 90 }}>Discount</th>}
                      <th style={{ color: '#fff', padding: '9px 12px', fontWeight: 600, fontSize: '0.7rem', textTransform: 'uppercase', textAlign: 'right', width: 110 }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {quotationItems.length === 0 ? (
                      <tr><td colSpan={hasItemDiscount ? 6 : 5}
                        style={{ textAlign: 'center', padding: '24px', color: '#9ca3af' }}>No line items</td></tr>
                    ) : quotationItems.map((it, idx) => (
                      <tr key={idx} style={{
                        borderBottom: '1px solid #f3f4f6',
                        background: idx % 2 === 1 ? '#fafafa' : '#fff'
                      }}>
                        <td style={{ padding: '9px 12px', textAlign: 'center', color: '#9ca3af' }}>{idx + 1}</td>
                        <td style={{ padding: '9px 12px' }}>
                          <div style={{ fontWeight: 600 }}>
                            {it.is_custom
                              ? <Badge bg="secondary" style={{ fontSize: '0.6rem', marginRight: 4 }}>SERVICE</Badge>
                              : <span style={{ fontSize: '0.72rem', color: '#9ca3af', marginRight: 4 }}>#{it.product_id}</span>
                            }
                            {it.name}
                          </div>
                          {it.variant_value && it.variant_value !== 'Default' && (
                            <div style={{ fontSize: '0.72rem', color: '#9ca3af' }}>{it.variant_value}</div>
                          )}
                        </td>
                        <td style={{ padding: '9px 12px', textAlign: 'center' }}>{it.quantity}</td>
                        <td style={{ padding: '9px 12px', textAlign: 'right' }}>{fmt(it.unit_price)}</td>
                        {hasItemDiscount && (
                          <td style={{ padding: '9px 12px', textAlign: 'right', color: '#dc3545' }}>{fmt(it.discount)}</td>
                        )}
                        <td style={{ padding: '9px 12px', textAlign: 'right', fontWeight: 600 }}>{fmt(it.total_price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals */}
              <div style={{ padding: '10px 16px', borderTop: '1.5px solid #e5e7eb', display: 'flex', justifyContent: 'flex-end' }}>
                <div style={{ minWidth: 260 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#374151', padding: '3px 0' }}>
                    <span>Subtotal</span><span>{fmt(subTotal)}</span>
                  </div>
                  {orderDiscount > 0 && (
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', color: '#dc3545', padding: '3px 0' }}>
                      <span>Discount</span><span>-{fmt(orderDiscount)}</span>
                    </div>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '0.95rem', color: '#111827', borderTop: '1.5px solid #e5e7eb', paddingTop: 8, marginTop: 4 }}>
                    <span>Total</span><span>{currency} {fmt(fullAmount)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Validity notice */}
            {timePeriod && (
              <div style={{
                border: '1px solid #86efac', borderRadius: 8, padding: '10px 14px',
                background: '#f0fdf4', fontSize: '0.8rem', color: '#15803d'
              }}>
                <Icon icon="mdi:clock-check-outline" width={14} className="me-1" />
                This quotation is valid for <strong>{timePeriod} days</strong> from the date of issue ({fmtDate(quotationDate)}).
              </div>
            )}
          </>
        )}
      </Modal.Body>

      <Modal.Footer style={{ background: '#f8fafc', borderTop: '1px solid #e5e7eb', gap: 8 }}>
        <Button variant="outline-secondary" size="sm" onClick={handlePrint}
          style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
          <Icon icon="mdi:printer-outline" width={15} /> Print
        </Button>
        {s3Url && (
          <a href={s3Url} target="_blank" rel="noreferrer">
            <Button variant="outline-success" size="sm"
              style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
              <Icon icon="mdi:cloud-download-outline" width={15} /> Download
            </Button>
          </a>
        )}
        <div style={{ flex: 1 }} />
        <Button variant="secondary" size="sm" onClick={onHide}
          style={{ borderRadius: 8, fontWeight: 600 }}>Close</Button>
      </Modal.Footer>
    </Modal>
  )
}

// ─── View / Edit Job Modal ────────────────────────────────────────────────────
function ViewJobModal({ jobId, show, onHide, onUpdated }) {
  const { currency } = useCurrencySymbol()
  const { data: jobData, isLoading: jobLoading } = useGetJobByIdQuery(jobId, { skip: !jobId || !show })
  const [updateJob, { isLoading: isSaving }] = useUpdateJobMutation()
  const { data: logsData, isLoading: logsLoading } = useGetJobLogsQuery(jobId, { skip: !jobId || !show })
  const jobLogs = logsData?.data ?? []
  const [updateJobNote] = useUpdateJobNoteMutation()
  const [adminNote, setAdminNote] = useState('')
  const [noteEditMode, setNoteEditMode] = useState(false)
  const [convertJobToInvoice, { isLoading: isConverting }] = useConvertJobToInvoiceMutation()

  // Invoice modal state
  const [showInvoiceModal, setShowInvoiceModal] = useState(false)
  const [createdInvoiceId, setCreatedInvoiceId] = useState(null)

  // Local editable state
  const [equipments, setEquipments] = useState([])
  const [equipInput, setEquipInput] = useState({ name: '', serialNumber: '' })
  const [addedProducts, setAddedProducts] = useState([])
  const [services, setServices] = useState([])
  const [serviceInput, setServiceInput] = useState({ name: '', amount: '' })
  const [productSearch, setProductSearch] = useState('')
  const [showProductSearch, setShowProductSearch] = useState(false)
  const [showTempForm, setShowTempForm] = useState(false)
  const [tempItem, setTempItem] = useState({ name: '', qty: 1, price: '' })
  // Quotation modal state  ← ADD THESE 3 LINES
  const [showQuotationModal, setShowQuotationModal] = useState(false)
  const [createdQuotationId, setCreatedQuotationId] = useState(null)
  const [convertJobToQuotation, { isLoading: isQuoting }] = useConvertJobToQuotationMutation()
  const tempRef = React.useRef(900)

  const [isDirty, setIsDirty] = useState(false)
  const initialStateRef = React.useRef(null)

  const checkDirty = (newEquipments, newProducts, newServices, newNote) => {
    if (!initialStateRef.current) return
    const current = JSON.stringify({
      equipments: newEquipments.map(e => ({ name: e.name, serialNumber: e.serialNumber })),
      addedProducts: newProducts.map(p => ({ variant_id: p.variant_id, selectedQty: p.selectedQty })),
      services: newServices.map(s => ({ name: s.name, amount: s.amount })),
      adminNote: newNote,
    })
    setIsDirty(current !== initialStateRef.current)
  }


  React.useEffect(() => {
    if (!jobData) return

    const equipmentsMapped = (jobData.equipment || []).map((e) => ({
      id: e.id, name: e.equipment_name, serialNumber: e.serial_number || '',
    }))
    const productsMapped = (jobData.items || []).map((it) => ({
      variant_id: it.variant_id || `DB-${it.id}`,
      product_id: it.product_id,
      title: it.item_name,
      price: Number(it.unit_price),
      selectedQty: Number(it.quantity),
      isTemp: it.item_type === 'CUSTOM',
      sku: it.sku,
      variant_value: it.variant_value,
      item_type: it.item_type,
    }))
    const servicesMapped = (jobData.services || []).map((s) => ({
      id: s.id, name: s.service_name, amount: Number(s.amount),
    }))
    const noteMapped = jobData.admin_note || ''

    setEquipments(equipmentsMapped)
    setAddedProducts(productsMapped)
    setServices(servicesMapped)
    setAdminNote(noteMapped)
    setIsDirty(false)

    // Capture clean snapshot (exclude volatile ids for temp items)
    initialStateRef.current = JSON.stringify({
      equipments: equipmentsMapped.map(e => ({ name: e.name, serialNumber: e.serialNumber })),
      addedProducts: productsMapped.map(p => ({ variant_id: p.variant_id, selectedQty: p.selectedQty })),
      services: servicesMapped.map(s => ({ name: s.name, amount: s.amount })),
      adminNote: noteMapped,
    })
  }, [jobData])

  // REPLACE addEquipment:
  const addEquipment = () => {
    if (!equipInput.name.trim()) return
    const next = [...equipments, { id: Date.now(), name: equipInput.name.trim(), serialNumber: equipInput.serialNumber.trim() }]
    setEquipments(next)
    setEquipInput({ name: '', serialNumber: '' })
    checkDirty(next, addedProducts, services, adminNote)
  }

  // REPLACE removeEquipment:
  const removeEquipment = (id) => {
    const next = equipments.filter((e) => e.id !== id)
    setEquipments(next)
    checkDirty(next, addedProducts, services, adminNote)
  }

  // REPLACE addService:
  const addService = () => {
    if (!serviceInput.name.trim() || !serviceInput.amount) return
    const next = [...services, { id: Date.now(), name: serviceInput.name.trim(), amount: parseFloat(serviceInput.amount) || 0 }]
    setServices(next)
    setServiceInput({ name: '', amount: '' })
    checkDirty(equipments, addedProducts, next, adminNote)
  }

  // REPLACE removeService:
  const removeService = (id) => {
    const next = services.filter((s) => s.id !== id)
    setServices(next)
    checkDirty(equipments, addedProducts, next, adminNote)
  }

  // REPLACE addTempItem:
  const addTempItem = () => {
    if (!tempItem.name.trim() || !tempItem.price) return
    const id = `TEMP-${tempRef.current++}`
    const next = [...addedProducts, { variant_id: id, product_id: null, title: tempItem.name.trim(), price: parseFloat(tempItem.price) || 0, selectedQty: Math.max(1, parseInt(tempItem.qty) || 1), isTemp: true }]
    setAddedProducts(next)
    setTempItem({ name: '', qty: 1, price: '' })
    setShowTempForm(false)
    checkDirty(equipments, next, services, adminNote)
  }

  // REPLACE handleProductQty:
  const handleProductQty = (variant_id, val) => {
    const next = addedProducts.map((p) => p.variant_id === variant_id ? { ...p, selectedQty: Math.max(1, Number(val) || 1) } : p)
    setAddedProducts(next)
    checkDirty(equipments, next, services, adminNote)
  }

  // REPLACE removeProduct:
  const removeProduct = (variant_id) => {
    const next = addedProducts.filter((p) => p.variant_id !== variant_id)
    setAddedProducts(next)
    checkDirty(equipments, next, services, adminNote)
  }

  const totalProducts = addedProducts.reduce((s, p) => s + p.price * p.selectedQty, 0)
  const totalServiceFee = services.reduce((s, x) => s + x.amount, 0)
  const grandTotal = totalProducts + totalServiceFee

  const handleSave = async () => {
    try {
      await updateJob({
        id: jobId,
        job_name: jobData.job_name,
        job_description: jobData.job_description,
        equipment: equipments.map((e) => ({ equipment_name: e.name, serial_number: e.serialNumber || null })),
        items: [
          ...addedProducts.filter((p) => !p.isTemp).map((p) => ({ item_type: 'PRODUCT', product_id: p.product_id, item_name: p.title, quantity: p.selectedQty, unit_price: p.price })),
          ...addedProducts.filter((p) => p.isTemp).map((p) => ({ item_type: 'CUSTOM', item_name: p.title, quantity: p.selectedQty, unit_price: p.price })),
        ],
        services: services.map((s) => ({ service_name: s.name, amount: s.amount })),
      }).unwrap()
      Swal.fire({ icon: 'success', title: 'Job updated', toast: true, timer: 1800, position: 'top-end', showConfirmButton: false })
      onUpdated?.()
      onHide()
      setIsDirty(false)
      initialStateRef.current = null
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to update job' })
    }
  }

  const handleClose = () => {
    if (!isDirty) { onHide(); return }
    Swal.fire({
      icon: 'warning',
      title: 'Unsaved Changes',
      text: 'You have unsaved changes. Close without saving?',
      showCancelButton: true,
      confirmButtonText: 'Close Without Saving',
      cancelButtonText: 'Keep Editing',
      confirmButtonColor: '#dc3545',
      reverseButtons: true,
    }).then((result) => {
      if (result.isConfirmed) onHide()
    })
  }


  // ── Convert to Invoice ──────────────────────────────────────────────────────
  const handleConvertToInvoice = async () => {
    if (addedProducts.length === 0 && services.length === 0) {
      Swal.fire({ icon: 'warning', title: 'Nothing to invoice', text: 'Add at least one billing item or service first.' })
      return
    }
    const result = await Swal.fire({
      icon: 'question',
      title: 'Convert to Invoice?',
      html: `Create an invoice from <strong>${jobData?.job_name}</strong><br/>Grand Total: <strong>${currency} ${grandTotal.toFixed(2)}</strong>`,
      showCancelButton: true,
      confirmButtonText: 'Create Invoice',
      confirmButtonColor: '#0d6efd',
      cancelButtonText: 'Cancel',
    })
    if (!result.isConfirmed) return

    try {
      const res = await convertJobToInvoice(jobId).unwrap()
      setCreatedInvoiceId(res.invoice_id)
      setShowInvoiceModal(true)
      onUpdated?.()
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Failed to create invoice', text: err?.data?.message || '' })
    }
  }

  const handleConvertToQuotation = async (timePeriod) => {
    try {
      const res = await convertJobToQuotation({ id: jobId, time_period: timePeriod }).unwrap()
      setCreatedQuotationId(res.quotation_id)
      setShowQuotationModal(true)
      onUpdated?.()
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Failed to create quotation', text: err?.data?.message || '' })
    }
  }

  const handleSaveNote = async () => {
    try {
      await updateJobNote({ id: jobId, admin_note: adminNote }).unwrap()
      Swal.fire({ icon: 'success', title: 'Note saved', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
      setNoteEditMode(false)
      onUpdated?.()
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to save note' })
    }
  }

  const handlePrint = () => {
    const hasPricing = addedProducts.length > 0 || services.length > 0
    const printWindow = window.open('', '_blank', 'width=900,height=700')
    const productsHtml = addedProducts.map((p, i) => `
      <tr>
        <td style="text-align:center;color:#6b7280">${i + 1}</td>
        <td><div style="font-weight:600">${p.title}${p.isTemp ? ' <span class="temp-badge">CUSTOM</span>' : ''}</div>${p.sku ? `<div style="font-size:10px;color:#9ca3af">SKU: ${p.sku}</div>` : ''}</td>
        <td style="text-align:center">${p.selectedQty}</td>
        <td style="text-align:right">${currency} ${Number(p.price).toFixed(2)}</td>
        <td style="text-align:right;font-weight:600">${currency} ${(p.price * p.selectedQty).toFixed(2)}</td>
      </tr>`).join('')
    const servicesHtml = services.map((s, i) => `
      <tr>
        <td style="text-align:center;color:#6b7280">${i + 1}</td>
        <td style="font-weight:600">${s.name}</td>
        <td style="text-align:right;font-weight:600">${currency} ${s.amount.toFixed(2)}</td>
      </tr>`).join('')
    const assignedHtml = Array.isArray(jobData?.assigned_users) && jobData.assigned_users.length > 0
      ? jobData.assigned_users.map(u => `<span class="user-chip">${u.name}${u.role ? ` <span class="role-label">${u.role}</span>` : ''}</span>`).join('')
      : '<span style="color:#9ca3af;font-size:12px">Not assigned</span>'
    const dateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })
    const jobDateStr = jobData?.created_at ? new Date(jobData.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' }) : '—'
    const statusColors = { PENDING: { bg: '#fff8e1', color: '#b45309', border: '#fcd34d' }, IN_PROGRESS: { bg: '#eff6ff', color: '#1d4ed8', border: '#93c5fd' }, COMPLETED: { bg: '#f0fdf4', color: '#15803d', border: '#86efac' }, CANCELLED: { bg: '#fff1f2', color: '#be123c', border: '#fda4af' }, ON_HOLD: { bg: '#fff7ed', color: '#c2410c', border: '#fdba74' } }
    const sc = statusColors[jobData?.status] || { bg: '#f3f4f6', color: '#374151', border: '#d1d5db' }
    printWindow.document.write(`<!DOCTYPE html><html><head><title>Job Sheet #${jobId}</title><style>@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600;700&display=swap');*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;font-size:13px;color:#111827;background:#fff}.page{width:100%;max-width:760px;margin:0 auto;padding:48px 52px}.page-break{page-break-before:always;padding-top:48px}.doc-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;padding-bottom:24px;border-bottom:2px solid #111827}.doc-title{font-family:'DM Serif Display',serif;font-size:26px;color:#111827;letter-spacing:-0.5px}.doc-subtitle{font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.12em;margin-top:4px}.doc-badge{background:#111827;color:#fff;font-size:11px;font-weight:700;border-radius:4px;padding:4px 12px;letter-spacing:.06em;margin-bottom:4px;display:inline-block}.doc-date{font-size:11px;color:#6b7280;margin-top:2px;text-align:right}.status-pill{display:inline-block;padding:3px 14px;border-radius:20px;font-size:11px;font-weight:700;background:${sc.bg};color:${sc.color};border:1.5px solid ${sc.border}}.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}.info-card{border:1.5px solid #e5e7eb;border-radius:10px;padding:14px 18px}.info-card.accent{border-color:#111827;background:#f9fafb}.info-label{font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px}.info-value{font-size:14px;font-weight:700;color:#111827}.info-sub{font-size:11px;color:#6b7280;margin-top:3px}.user-chip{display:inline-flex;align-items:center;gap:4px;background:#f3f4f6;border:1px solid #e5e7eb;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:600;color:#374151;margin:2px}.role-label{font-weight:400;color:#9ca3af;font-size:10px}.section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#6b7280}.temp-badge{background:#e5e7eb;border-radius:3px;padding:1px 5px;font-size:9px;font-weight:700;color:#374151;margin-left:4px}table{width:100%;border-collapse:collapse;margin-bottom:20px}thead tr{background:#111827}thead th{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:10px 12px;text-align:left}tbody tr{border-bottom:1px solid #f3f4f6}tbody tr:nth-child(even){background:#fafafa}td{padding:10px 12px;font-size:12px;vertical-align:middle}tfoot tr td{font-weight:700;font-size:12px;border-top:2px solid #e5e7eb;padding:10px 12px;background:#f9fafb}.summary-card{border:1.5px solid #111827;border-radius:10px;padding:16px 20px;max-width:320px;margin-left:auto;margin-bottom:28px;background:#f9fafb}.summary-row{display:flex;justify-content:space-between;font-size:12px;color:#374151;padding:4px 0}.summary-row.total{font-size:15px;font-weight:700;color:#111827;border-top:1.5px solid #e5e7eb;padding-top:10px;margin-top:6px}.sig-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:48px}.sig-space{height:52px}.sig-line{border-top:1.5px solid #374151;margin-bottom:8px}.sig-name{font-size:11px;font-weight:700;color:#374151}.sig-sub{font-size:10px;color:#9ca3af;margin-top:2px}.log-table thead tr{background:#374151}.log-action{background:rgba(17,24,39,0.08);border-radius:4px;padding:1px 7px;font-size:10px;font-weight:700;letter-spacing:.04em;color:#374151}.doc-footer{margin-top:40px;padding-top:16px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;font-size:10px;color:#9ca3af}.note-box{border:1.5px solid #fcd34d;border-left:4px solid #f59e0b;border-radius:8px;padding:12px 16px;margin-bottom:24px;background:#fffbeb}.note-box strong{display:block;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#92400e;margin-bottom:4px}.note-box p{font-size:12px;color:#78350f}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{padding:32px 40px}.page-break{padding-top:32px}}</style></head><body>
    <div class="page">
      <div class="doc-header"><div><div class="doc-title">Job Sheet</div><div class="doc-subtitle">Service & Work Order</div></div><div style="text-align:right"><div class="doc-badge">Job #${jobId}</div><div style="margin-top:6px"><span class="status-pill">${jobData?.status?.replace(/_/g, ' ')}</span></div><div class="doc-date" style="margin-top:6px">Printed: ${dateStr}</div><div class="doc-date">Job Date: ${jobDateStr}</div></div></div>
      ${adminNote ? `<div class="note-box"><strong>⚠ Admin Note</strong><p>${adminNote}</p></div>` : ''}
      <div class="info-grid"><div class="info-card accent"><div class="info-label">Job Name</div><div class="info-value">${jobData?.job_name || '—'}</div>${jobData?.job_description ? `<div class="info-sub">${jobData.job_description}</div>` : ''}${jobData?.status === 'ON_HOLD' && jobData?.hold_reason ? `<div class="info-sub" style="color:#c2410c;margin-top:6px">On Hold: ${jobData.hold_reason}</div>` : ''}</div><div class="info-card"><div class="info-label">Customer</div>${jobData?.customer ? `<div class="info-value">${jobData.customer.name}</div>${jobData.customer.phone ? `<div class="info-sub">📞 ${jobData.customer.phone}</div>` : ''}${jobData.customer.email ? `<div class="info-sub">✉ ${jobData.customer.email}</div>` : ''}${jobData.customer.address ? `<div class="info-sub">📍 ${jobData.customer.address}</div>` : ''}` : '<div class="info-value" style="color:#9ca3af">No customer linked</div>'}</div><div class="info-card" style="grid-column:1/-1"><div class="info-label">Assigned Staff</div><div style="margin-top:4px">${assignedHtml}</div></div></div>
      ${hasPricing ? `${addedProducts.length > 0 ? `<div class="section-title" style="margin-bottom:10px">Billing Items</div><table><thead><tr><th style="width:36px;text-align:center">#</th><th>Product / Item</th><th style="width:70px;text-align:center">Qty</th><th style="width:110px;text-align:right">Unit Price</th><th style="width:110px;text-align:right">Total</th></tr></thead><tbody>${productsHtml}</tbody><tfoot><tr><td colspan="4" style="text-align:right">Items Subtotal</td><td style="text-align:right">${currency} ${totalProducts.toFixed(2)}</td></tr></tfoot></table>` : ''}${services.length > 0 ? `<div class="section-title" style="margin-bottom:10px">Labour &amp; Service Fee</div><table><thead><tr><th style="width:36px;text-align:center">#</th><th>Service Description</th><th style="width:130px;text-align:right">Amount</th></tr></thead><tbody>${servicesHtml}</tbody><tfoot><tr><td colspan="2" style="text-align:right">Services Subtotal</td><td style="text-align:right">${currency} ${totalServiceFee.toFixed(2)}</td></tr></tfoot></table>` : ''}<div class="summary-card">${addedProducts.length > 0 ? `<div class="summary-row"><span>Billing Items</span><span>${currency} ${totalProducts.toFixed(2)}</span></div>` : ''}${services.length > 0 ? `<div class="summary-row"><span>Labour &amp; Service</span><span>${currency} ${totalServiceFee.toFixed(2)}</span></div>` : ''}<div class="summary-row total"><span>Grand Total</span><span>${currency} ${grandTotal.toFixed(2)}</span></div></div>` : ''}
      <div class="sig-grid"><div><div class="sig-space"></div><div class="sig-line"></div><div class="sig-name">Client Signature</div><div class="sig-sub">Name &amp; Date</div></div><div><div class="sig-space"></div><div class="sig-line"></div><div class="sig-name">Staff Signature</div><div class="sig-sub">Name &amp; Date</div></div></div>
      <div class="doc-footer"><span>Job #${jobId} — ${jobData?.job_name || ''}</span><span>Printed: ${dateStr}</span></div>
    </div>
    <div class="page page-break">
      <div class="doc-header"><div><div class="doc-title">Activity Log</div><div class="doc-subtitle">Job #${jobId} — ${jobData?.job_name || ''}</div></div><div style="text-align:right"><div class="doc-badge">Job #${jobId}</div><div class="doc-date" style="margin-top:6px">Printed: ${dateStr}</div></div></div>
      ${jobLogs.length > 0 ? `<table class="log-table"><thead><tr><th style="width:130px">Action</th><th>Description</th><th style="width:120px">Performed By</th><th style="width:130px">Date &amp; Time</th></tr></thead><tbody>${jobLogs.map(log => `<tr><td><span class="log-action">${log.action?.replace(/_/g, ' ')}</span></td><td style="font-size:12px;color:#374151">${log.description}</td><td style="font-size:12px;color:#374151">${log.performed_by_name || '—'}</td><td style="font-size:11px;color:#6b7280">${new Date(log.created_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td></tr>`).join('')}</tbody></table>` : '<div style="border:1.5px dashed #e5e7eb;border-radius:8px;padding:20px;text-align:center;color:#9ca3af;font-size:12px">No activity logs recorded for this job.</div>'}
      <div class="doc-footer"><span>Job #${jobId} — Activity Log</span><span>Printed: ${dateStr}</span></div>
    </div>
    </body></html>`)
    printWindow.document.close()
    printWindow.focus()
    setTimeout(() => { printWindow.print(); printWindow.close() }, 400)
  }

  const handlePrintAcknowledgment = () => {
    const printWindow = window.open('', '_blank', 'width=860,height=700')
    const itemsHtml = equipments.map((eq, i) => `<tr><td style="text-align:center;color:#6b7280">${i + 1}</td><td style="font-weight:600">${eq.name}</td><td style="text-align:left;color:#6b7280;font-size:11px">${eq.serialNumber ? `S/N: ${eq.serialNumber}` : '—'}</td><td style="text-align:center"><span style="display:inline-block;width:14px;height:14px;border:1.5px solid #d1d5db;border-radius:3px"></span></td></tr>`).join('')
    const assignedHtml = Array.isArray(jobData?.assigned_users) && jobData.assigned_users.length > 0
      ? jobData.assigned_users.map(u => `<span style="display:inline-flex;align-items:center;gap:4px;background:#f3f4f6;border:1px solid #e5e7eb;border-radius:20px;padding:3px 10px;font-size:11px;font-weight:600;color:#374151;margin:2px">${u.name}${u.role ? ` <span style="font-weight:400;color:#9ca3af;font-size:10px">${u.role}</span>` : ''}</span>`).join('')
      : '<span style="color:#9ca3af;font-size:12px">Not assigned</span>'
    const dateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })
    const jobDateStr = jobData?.created_at ? new Date(jobData.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' }) : '—'
    printWindow.document.write(`<!DOCTYPE html><html><head><title>Item Receipt — Job #${jobId}</title><style>@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600;700&display=swap');*{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;font-size:13px;color:#111827;background:#fff}.page{width:100%;max-width:760px;margin:0 auto;padding:48px 52px}.doc-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;padding-bottom:24px;border-bottom:2px solid #111827}.doc-title{font-family:'DM Serif Display',serif;font-size:26px;color:#111827;letter-spacing:-0.5px}.doc-badge{background:#111827;color:#fff;font-size:11px;font-weight:700;border-radius:4px;padding:4px 12px}.doc-date{font-size:11px;color:#6b7280;margin-top:2px;text-align:right}.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:28px}.info-card{border:1.5px solid #e5e7eb;border-radius:10px;padding:14px 18px}.info-card.accent{border-color:#111827;background:#f9fafb}.info-label{font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.1em;margin-bottom:6px}.info-value{font-size:14px;font-weight:700;color:#111827}.info-sub{font-size:11px;color:#6b7280;margin-top:2px}.section-title{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:#6b7280;margin-bottom:10px}table{width:100%;border-collapse:collapse;margin-bottom:28px}thead tr{background:#111827}thead th{color:#fff;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:10px 12px;text-align:left}tbody tr{border-bottom:1px solid #f3f4f6}tbody tr:nth-child(even){background:#fafafa}td{padding:10px 12px;font-size:12px;vertical-align:middle}.notice{border:1.5px solid #e5e7eb;border-left:4px solid #111827;border-radius:8px;padding:12px 16px;margin-bottom:32px;font-size:12px;color:#374151;background:#f9fafb}.notice strong{display:block;margin-bottom:4px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:#111827}.sig-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:32px;margin-top:48px}.sig-space{height:48px}.sig-line{border-top:1.5px solid #374151;margin-bottom:8px}.sig-name{font-size:11px;font-weight:700;color:#374151}.sig-sub{font-size:10px;color:#9ca3af;margin-top:2px}.doc-footer{margin-top:40px;padding-top:16px;border-top:1px solid #e5e7eb;display:flex;justify-content:space-between;font-size:10px;color:#9ca3af}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{padding:32px 40px}}</style></head><body>
    <div class="page">
      <div class="doc-header"><div><div class="doc-title">Item Receipt</div><div class="doc-title" style="font-size:18px;color:#6b7280">Acknowledgment</div><div style="font-size:11px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.12em;margin-top:4px">Please verify all items received</div></div><div style="text-align:right"><div class="doc-badge">Job #${jobId}</div><div class="doc-date">Printed: ${dateStr}</div><div class="doc-date">Job Date: ${jobDateStr}</div></div></div>
      <div class="info-grid"><div class="info-card accent"><div class="info-label">Job Name</div><div class="info-value">${jobData?.job_name || '—'}</div>${jobData?.job_description ? `<div class="info-sub">${jobData.job_description}</div>` : ''}</div><div class="info-card"><div class="info-label">Customer</div>${jobData?.customer ? `<div class="info-value">${jobData.customer.name}</div>${jobData.customer.phone ? `<div class="info-sub">${jobData.customer.phone}</div>` : ''}${jobData.customer.email ? `<div class="info-sub">${jobData.customer.email}</div>` : ''}` : '<div class="info-value" style="color:#9ca3af">No customer linked</div>'}</div><div class="info-card"><div class="info-label">Assigned Staff</div><div style="margin-top:4px">${assignedHtml}</div></div><div class="info-card"><div class="info-label">Status</div><div class="info-value">${jobData?.status?.replace(/_/g, ' ') || '—'}</div>${jobData?.status === 'ON_HOLD' && jobData?.hold_reason ? `<div class="info-sub" style="color:#c2410c">Hold: ${jobData.hold_reason}</div>` : ''}</div></div>
      <div class="section-title">Items Received from Customer</div>
      ${equipments.length > 0 ? `<table><thead><tr><th style="width:36px;text-align:center">#</th><th>Equipment / Item</th><th style="width:160px">Serial Number</th><th style="width:70px;text-align:center">Received ✓</th></tr></thead><tbody>${itemsHtml}</tbody></table>` : `<div style="border:1.5px dashed #e5e7eb;border-radius:8px;padding:20px;text-align:center;color:#9ca3af;font-size:12px;margin-bottom:28px">No items listed for this job</div>`}
      <div class="notice"><strong>Important Notice</strong>Please inspect all items carefully before signing. By signing below, you confirm that all listed items have been received in the described condition.</div>
      <div class="sig-grid"><div><div class="sig-space"></div><div class="sig-line"></div><div class="sig-name">Customer Signature</div><div class="sig-sub">Name &amp; Date</div></div><div><div class="sig-space"></div><div class="sig-line"></div><div class="sig-name">Staff Signature</div><div class="sig-sub">Name &amp; Date</div></div><div><div class="sig-space"></div><div class="sig-line"></div><div class="sig-name">Authorized By</div><div class="sig-sub">Name &amp; Date</div></div></div>
      <div class="doc-footer"><span>Job #${jobId} — Item Receipt Acknowledgment</span><span>Printed: ${dateStr}</span></div>
    </div></body></html>`)
    printWindow.document.close()
    printWindow.focus()
    setTimeout(() => { printWindow.print(); printWindow.close() }, 400)
  }

  return (
    <>
      <Modal show={show} onHide={handleClose} centered size="xl" scrollable>
        <Modal.Header closeButton closeVariant="white" style={{ background: 'linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%)', borderBottom: 'none', padding: '1rem 1.5rem' }}>
          <Modal.Title style={{ color: '#fff', fontSize: '1rem', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon icon="mdi:briefcase-edit-outline" width={20} /> Job Details &amp; Edit
          </Modal.Title>
        </Modal.Header>

        <Modal.Body style={{ background: '#f8fafc', padding: '1.25rem 1.5rem' }}>
          {jobLoading ? (
            <div className="text-center py-5"><Spinner animation="border" /></div>
          ) : !jobData ? null : (
            <Row className="g-4">

              {/* ── 1. JOB INFO ── */}
              <Col md={12}>
                <Card className="border" style={{ borderRadius: 12 }}>
                  <CardBody>
                    <SectionHeading icon="mdi:briefcase-outline" title="Job Information" />
                    <Row className="g-0" style={{ minHeight: 140 }}>
                      <Col md={5} style={{ borderRight: '1.5px solid #e9ecef', paddingRight: 20 }}>
                        <div style={{ fontWeight: 700, fontSize: '0.78rem', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Customer</div>
                        {jobData.customer ? (
                          <div style={{ background: 'rgba(var(--bs-primary-rgb),0.06)', border: '1.5px solid rgba(var(--bs-primary-rgb),0.15)', borderRadius: 10, padding: '10px 14px' }}>
                            <div className="fw-semibold" style={{ fontSize: '0.9rem' }}>{jobData.customer.name}</div>
                            {jobData.customer.phone && <div className="text-muted" style={{ fontSize: '0.78rem' }}><Icon icon="mdi:phone" width={12} className="me-1" />{jobData.customer.phone}</div>}
                            {jobData.customer.email && <div className="text-muted" style={{ fontSize: '0.78rem' }}><Icon icon="mdi:email-outline" width={12} className="me-1" />{jobData.customer.email}</div>}
                            {jobData.customer.address && <div className="text-muted" style={{ fontSize: '0.78rem' }}><Icon icon="mdi:map-marker-outline" width={12} className="me-1" />{jobData.customer.address}</div>}
                          </div>
                        ) : (
                          <div style={{ color: '#9ca3af', fontSize: '0.82rem' }}>No customer linked</div>
                        )}
                      </Col>
                      <Col md={7} style={{ paddingLeft: 24 }}>
                        <div style={{ fontWeight: 700, fontSize: '0.78rem', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Job Details</div>
                        <div className="d-flex gap-2 align-items-center mb-2 flex-wrap">
                          <span style={{ fontWeight: 700, fontSize: '0.95rem', color: '#111827' }}>{jobData.job_name}</span>
                          <StatusPill status={jobData.status} />
                          {jobData.status === 'ON_HOLD' && jobData.hold_reason && (
                            <span style={{ fontSize: '0.75rem', color: '#c2410c', background: '#fff7ed', border: '1px solid #fdba74', borderRadius: 8, padding: '2px 10px' }}>
                              <Icon icon="mdi:information-outline" width={12} className="me-1" />{jobData.hold_reason}
                            </span>
                          )}
                        </div>
                        {jobData.job_description && <div style={{ fontSize: '0.83rem', color: '#6b7280' }}>{jobData.job_description}</div>}
                        {Array.isArray(jobData.assigned_users) && jobData.assigned_users.length > 0 && (
                          <div className="mt-2 d-flex flex-wrap gap-1">
                            {jobData.assigned_users.map((u) => (
                              <span key={u.id} style={{ background: '#f3f4f6', borderRadius: 20, padding: '3px 10px', fontSize: '0.72rem', fontWeight: 500, color: '#374151', display: 'flex', alignItems: 'center', gap: 4 }}>
                                <Icon icon="mdi:account" width={12} />{u.name}
                                {u.role && <span style={{ color: '#9ca3af' }}>· {u.role}</span>}
                              </span>
                            ))}
                          </div>
                        )}
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </Col>

              {/* ── 2. EQUIPMENT ── */}
              <Col md={12}>
                <Card className="border" style={{ borderRadius: 12 }}>
                  <CardBody>
                    <SectionHeading icon="mdi:tools" title="Equipment from Customer" badge={equipments.length} />
                    <div className="d-flex gap-2 mb-3 flex-wrap">
                      <Form.Control type="text" placeholder="Equipment name…" value={equipInput.name}
                        onChange={(e) => setEquipInput((v) => ({ ...v, name: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && addEquipment()}
                        style={{ borderRadius: 8, flex: '2 1 180px' }} />
                      <Form.Control type="text" placeholder="Serial number (optional)" value={equipInput.serialNumber}
                        onChange={(e) => setEquipInput((v) => ({ ...v, serialNumber: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && addEquipment()}
                        style={{ borderRadius: 8, flex: '1 1 140px' }} />
                      <Button variant="outline-primary" onClick={addEquipment} style={{ borderRadius: 8, fontWeight: 600, fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap' }}>
                        <Icon icon="ic:baseline-plus" width={18} /> Add
                      </Button>
                    </div>
                    {equipments.length === 0 ? <EmptyHint icon="mdi:wrench-outline" text="No equipment added yet" /> : (
                      <div className="d-flex flex-wrap gap-2">
                        {equipments.map((eq) => (
                          <div key={eq.id} className="d-flex align-items-center gap-1"
                            style={{ background: '#f3f4f6', borderRadius: 20, padding: '5px 12px', fontSize: '0.82rem', fontWeight: 500, color: '#374151' }}>
                            <Icon icon="mdi:wrench" width={14} style={{ color: '#6b7280' }} />
                            {eq.name}
                            {eq.serialNumber && (
                              <span style={{ fontSize: '0.70rem', color: '#6b7280', background: '#e5e7eb', borderRadius: 10, padding: '1px 7px', marginLeft: 2 }}>
                                S/N: {eq.serialNumber}
                              </span>
                            )}
                            <button onClick={() => removeEquipment(eq.id)} style={{ border: 'none', background: 'none', padding: 0, marginLeft: 4, cursor: 'pointer', color: '#9ca3af', display: 'flex', alignItems: 'center' }}>
                              <Icon icon="mdi:close" width={14} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardBody>
                </Card>
              </Col>

              {/* ── 3. BILLING ITEMS ── */}
              <Col md={12}>
                <Card className="border" style={{ borderRadius: 12 }}>
                  <CardBody>
                    <SectionHeading icon="mdi:package-variant-closed" title="Billing Items" badge={addedProducts.length} />
                    <div className="d-flex gap-1 w-100 mb-3 flex-wrap">
                      <div className="d-flex border rounded overflow-hidden flex-grow-1">
                        <input type="search" className="form-control border-0 shadow-none"
                          placeholder="Search products…" value={productSearch}
                          onChange={(e) => { setProductSearch(e.target.value); if (e.target.value.length > 1) setShowProductSearch(true) }}
                          autoComplete="off" />
                        <button className="btn border-0 bg-white"><Icon icon="iconoir:search" /></button>
                      </div>
                      <Button variant="outline-primary" className="btn-sm d-flex align-items-center gap-1"
                        style={{ borderRadius: 10, minHeight: 36, whiteSpace: 'nowrap' }}
                        onClick={() => setShowTempForm((v) => !v)}>
                        <Icon icon="ic:baseline-plus" width={18} /> Temp Item
                      </Button>
                    </div>
                    {showTempForm && (
                      <div className="d-flex gap-2 mb-3 flex-wrap p-3" style={{ background: '#f9fafb', borderRadius: 10, border: '1.5px dashed #dee2e6' }}>
                        <Form.Control type="text" placeholder="Item name" value={tempItem.name} onChange={(e) => setTempItem((t) => ({ ...t, name: e.target.value }))} style={{ borderRadius: 8, maxWidth: 300 }} />
                        <Form.Control type="number" placeholder="Qty" min={1} value={tempItem.qty} onChange={(e) => setTempItem((t) => ({ ...t, qty: e.target.value }))} style={{ borderRadius: 8, maxWidth: 80 }} />
                        <Form.Control type="number" placeholder="Price" min={0} value={tempItem.price} onChange={(e) => setTempItem((t) => ({ ...t, price: e.target.value }))} style={{ borderRadius: 8, maxWidth: 120 }} />
                        <Button variant="primary" onClick={addTempItem} size="sm" style={{ borderRadius: 8, fontWeight: 600 }}>
                          <Icon icon="mdi:check" width={16} /> Add
                        </Button>
                        <Button variant="link" className="text-secondary p-0" size="sm" onClick={() => setShowTempForm(false)}>Cancel</Button>
                      </div>
                    )}
                    {addedProducts.length === 0 ? (
                      <div className="d-flex justify-content-center" style={{ minHeight: 120 }}>
                        <EmptyHint icon="mdi:package-variant-closed" text="No items yet" />
                      </div>
                    ) : (
                      <Table responsive>
                        <thead style={{ backgroundColor: '#e5e5f8b4' }}>
                          <tr>
                            <th style={{ minWidth: 180 }}>Product</th>
                            <th style={{ width: 110, textAlign: 'center' }}>Quantity</th>
                            <th style={{ minWidth: 80, textAlign: 'right' }}>Total ({currency})</th>
                            <th style={{ width: 40, textAlign: 'center' }}>Del</th>
                          </tr>
                        </thead>
                        <tbody>
                          {addedProducts.map((item) => {
                            const qty = Number(item.selectedQty ?? 1)
                            const total = Number(item.price || 0) * qty
                            return (
                              <tr key={item.variant_id}>
                                <td>
                                  <div className="d-flex gap-2 align-items-center">
                                    <div style={{ width: 40, height: 40, borderRadius: 8, flexShrink: 0, background: item.isTemp ? 'rgba(var(--bs-primary-rgb),0.08)' : '#f3f4f6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                      <Icon icon={item.isTemp ? 'mdi:package-variant' : 'mdi:barcode'} width={20} style={{ color: item.isTemp ? 'var(--bs-primary)' : '#9ca3af' }} />
                                    </div>
                                    <div>
                                      <div className="fw-semibold" style={{ fontSize: '0.85rem' }}>
                                        {item.isTemp && <Badge bg="secondary" style={{ fontSize: '0.60rem', marginRight: 4 }}>TEMP</Badge>}
                                        {item.title}
                                      </div>
                                      {item.sku && <div className="text-muted" style={{ fontSize: '0.72rem' }}>SKU: {item.sku}</div>}
                                      <div className="text-primary" style={{ fontSize: '0.78rem' }}>{currency} {Number(item.price).toFixed(2)}</div>
                                    </div>
                                  </div>
                                </td>
                                <td className="text-center">
                                  <Form.Control type="number" size="sm" min={1} value={item.selectedQty ?? 1}
                                    onChange={(e) => handleProductQty(item.variant_id, e.target.value)}
                                    style={{ width: 70, textAlign: 'end', margin: '0 auto' }} />
                                </td>
                                <td className="text-end">{total.toFixed(2)}</td>
                                <td className="text-center">
                                  <Button variant="link" className="p-0 text-danger" onClick={() => removeProduct(item.variant_id)}>
                                    <Icon icon="material-symbols:delete" width={18} style={{ color: '#ff2626' }} />
                                  </Button>
                                </td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </Table>
                    )}
                  </CardBody>
                </Card>
              </Col>

              {/* ── 4. SERVICES ── */}
              <Col md={12}>
                <Card className="border" style={{ borderRadius: 12 }}>
                  <CardBody>
                    <SectionHeading icon="mdi:account-hard-hat-outline" title="Labour & Service Fee" badge={services.length} />
                    <div className="d-flex gap-2 mb-3 flex-wrap">
                      <Form.Control type="text" placeholder="Service name…" value={serviceInput.name}
                        onChange={(e) => setServiceInput((s) => ({ ...s, name: e.target.value }))} style={{ borderRadius: 8, maxWidth: 400 }} />
                      <Form.Control type="number" placeholder="Amount" min={0} value={serviceInput.amount}
                        onChange={(e) => setServiceInput((s) => ({ ...s, amount: e.target.value }))} style={{ borderRadius: 8, maxWidth: 160 }} />
                      <Button variant="outline-primary" onClick={addService} style={{ borderRadius: 8, fontWeight: 600, fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Icon icon="ic:baseline-plus" width={18} /> Add
                      </Button>
                    </div>
                    {services.length === 0 ? <EmptyHint icon="mdi:account-hard-hat-outline" text="No services yet" /> : (
                      <Table responsive size="sm" style={{ fontSize: '0.85rem' }}>
                        <thead style={{ backgroundColor: '#e5e5f8b4' }}>
                          <tr><th>Service</th><th className="text-end">Amount ({currency})</th><th style={{ width: 40 }} /></tr>
                        </thead>
                        <tbody>
                          {services.map((s) => (
                            <tr key={s.id}>
                              <td>{s.name}</td>
                              <td className="text-end">{s.amount.toFixed(2)}</td>
                              <td className="text-center">
                                <Button variant="link" className="p-0 text-danger" onClick={() => removeService(s.id)}>
                                  <Icon icon="material-symbols:delete" width={16} />
                                </Button>
                              </td>
                            </tr>
                          ))}
                          <tr><td className="fw-semibold">Total</td><td className="text-end fw-semibold">{totalServiceFee.toFixed(2)}</td><td /></tr>
                        </tbody>
                      </Table>
                    )}
                  </CardBody>
                </Card>
              </Col>

              {/* ── 5. SUMMARY + ADMIN NOTE ── */}
              <Col md={12}>
                <div className="d-flex gap-3 align-items-stretch flex-wrap">
                  {(addedProducts.length > 0 || services.length > 0) && (
                    <div style={{ flex: '1 1 300px', minWidth: 260 }}>
                      <Card className="border h-100" style={{ borderRadius: 12 }}>
                        <CardHeader className="py-2 fs-6 fw-semibold" style={{ backgroundColor: '#e5e5f8b4' }}>Job Summary</CardHeader>
                        <CardBody className="py-2">
                          {addedProducts.length > 0 && <div className="d-flex justify-content-between"><span>Billing Items</span><span>{currency} {totalProducts.toFixed(2)}</span></div>}
                          {services.length > 0 && <div className="d-flex justify-content-between mt-1"><span>Labour & Service</span><span>{currency} {totalServiceFee.toFixed(2)}</span></div>}
                          <hr className="my-2" />
                          <div className="d-flex justify-content-between fw-semibold"><span>Grand Total</span><span>{currency} {grandTotal.toFixed(2)}</span></div>
                        </CardBody>
                      </Card>
                    </div>
                  )}
                  <div style={{ flex: '2 1 340px', minWidth: 280 }}>
                    <Card className="border h-100" style={{ borderRadius: 12, borderLeft: '4px solid #f59e0b' }}>
                      <CardBody>
                        <div className="d-flex align-items-center justify-content-between mb-2">
                          <SectionHeading icon="mdi:note-alert-outline" title="Admin Note" />
                          <Button variant="link" size="sm" className="p-0 text-secondary" onClick={() => setNoteEditMode((v) => !v)}>
                            <Icon icon={noteEditMode ? 'mdi:close' : 'mdi:pencil-outline'} width={16} />
                          </Button>
                        </div>
                        {noteEditMode ? (
                          <div className="d-flex flex-column gap-2">
                            <Form.Control as="textarea" rows={3} value={adminNote}
                              onChange={(e) => setAdminNote(e.target.value)}
                              placeholder="Add an internal admin note…"
                              style={{ borderRadius: 8, resize: 'none', fontSize: '0.85rem' }} />
                            <div className="d-flex gap-2">
                              <Button size="sm" onClick={handleSaveNote}
                                style={{ borderRadius: 8, background: '#f59e0b', border: 'none', fontWeight: 600, color: '#fff' }}>
                                Save Note
                              </Button>
                              <Button variant="secondary" size="sm"
                                onClick={() => { setNoteEditMode(false); setAdminNote(jobData?.admin_note || '') }}
                                style={{ borderRadius: 8 }}>Cancel</Button>
                            </div>
                          </div>
                        ) : adminNote ? (
                          <p style={{ fontSize: '0.85rem', color: '#374151', margin: 0, whiteSpace: 'pre-wrap' }}>{adminNote}</p>
                        ) : (
                          <EmptyHint icon="mdi:note-off-outline" text="No admin note. Click pencil to add one." />
                        )}
                      </CardBody>
                    </Card>
                  </div>
                </div>
              </Col>

              {/* ── 6. ACTIVITY LOG ── */}
              <Col md={12}>
                <Card className="border" style={{ borderRadius: 12 }}>
                  <CardBody>
                    <SectionHeading icon="mdi:clipboard-text-clock-outline" title="Activity Log" badge={jobLogs.length} />
                    {logsLoading ? (
                      <div className="text-center py-3"><Spinner animation="border" size="sm" /></div>
                    ) : jobLogs.length === 0 ? (
                      <EmptyHint icon="mdi:clipboard-text-outline" text="No activity logs yet" />
                    ) : (
                      <div style={{ maxHeight: 320, overflowY: 'auto' }}>
                        {jobLogs.map((log, index) => (
                          <div key={log.log_id} className="d-flex gap-3 align-items-start"
                            style={{ padding: '10px 0', borderBottom: index < jobLogs.length - 1 ? '1px solid #f3f4f6' : 'none' }}>
                            <div style={{ width: 34, height: 34, borderRadius: '50%', flexShrink: 0, background: 'rgba(var(--bs-primary-rgb), 0.10)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                              <Icon icon={
                                log.action === 'JOB_CREATE' ? 'mdi:briefcase-plus-outline' :
                                  log.action === 'STATUS_UPDATE' ? 'mdi:swap-horizontal' :
                                    log.action === 'JOB_UPDATE' ? 'mdi:briefcase-edit-outline' :
                                      log.action === 'INVOICE_CREATED' ? 'mdi:receipt-text-outline' :
                                        'mdi:clipboard-text-outline'
                              } width={16} style={{ color: 'var(--bs-primary)' }} />
                            </div>
                            <div className="flex-grow-1">
                              <div className="d-flex align-items-center gap-2 flex-wrap">
                                <span style={{ background: 'rgba(var(--bs-primary-rgb), 0.08)', color: 'var(--bs-primary)', borderRadius: 6, padding: '1px 8px', fontSize: '0.70rem', fontWeight: 700, letterSpacing: '0.04em' }}>
                                  {log.action?.replace(/_/g, ' ')}
                                </span>
                                <span style={{ fontSize: '0.83rem', color: '#374151' }}>{log.description}</span>
                              </div>
                              <div className="d-flex align-items-center gap-2 mt-1 flex-wrap">
                                {log.performed_by_name && (
                                  <span className="d-flex align-items-center gap-1" style={{ fontSize: '0.75rem', color: '#6b7280' }}>
                                    <Icon icon="mdi:account-outline" width={13} />{log.performed_by_name}
                                  </span>
                                )}
                                <span className="d-flex align-items-center gap-1" style={{ fontSize: '0.72rem', color: '#9ca3af' }}>
                                  <Icon icon="mdi:clock-outline" width={12} />
                                  {new Date(log.created_at).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardBody>
                </Card>
              </Col>

            </Row>
          )}
        </Modal.Body>

        <Modal.Footer style={{ background: '#f8fafc', borderTop: '1px solid #e5e7eb', gap: 8 }}>
          <Button variant="outline-secondary" onClick={handlePrint}
            style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
            <Icon icon="mdi:printer-outline" width={16} /> Print Job Sheet
          </Button>
          <Button variant="outline-secondary" onClick={handlePrintAcknowledgment}
            style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4, borderColor: '#374151', color: '#374151' }}>
            <Icon icon="mdi:clipboard-check-outline" width={16} /> Item Receipt
          </Button>
          {jobData?.quotation_id ? (
            <Button variant="outline-success"
              onClick={() => { setCreatedQuotationId(jobData.quotation_id); setShowQuotationModal(true) }}
              style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
              <Icon icon="mdi:file-document-check-outline" width={16} />
              View Quotation #{jobData.quotation_id}
            </Button>
          ) : (
            <QuotationTriggerButton isQuoting={isQuoting} onConfirm={handleConvertToQuotation} />
          )}
          {/* ── Invoice button ── */}

          {jobData?.invoice_id ? (
            <Button
              variant="outline-success"
              onClick={() => {
                setCreatedInvoiceId(jobData.invoice_id)
                setShowInvoiceModal(true)
              }}
              style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
              <Icon icon="mdi:receipt-text-check-outline" width={16} />
              View Invoice #{jobData.invoice_id}
            </Button>
          ) : (
            <Button
              variant="outline-primary"
              onClick={handleConvertToInvoice}
              disabled={isConverting}
              style={{ borderRadius: 8, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
              {isConverting
                ? <><Spinner animation="border" size="sm" style={{ width: 13, height: 13 }} /> Creating…</>
                : <><Icon icon="mdi:receipt-text-outline" width={16} /> Invoice</>
              }
            </Button>
          )}
          <div style={{ flex: 1 }} />
          {/* <Button variant="secondary" onClick={onHide} style={{ borderRadius: 8, fontWeight: 600 }}>Close</Button> */}
          {isDirty && (
            <Button onClick={handleSave} disabled={isSaving || jobLoading}
              style={{ borderRadius: 8, background: '#16a34a', border: 'none', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6, boxShadow: '0 0 0 3px rgba(22,163,74,0.25)', animation: 'pulse-green 1.5s infinite' }}>
              <Icon icon="mdi:content-save-outline" width={16} />
              {isSaving ? 'Saving…' : 'Save Changes'}
            </Button>
          )}
        </Modal.Footer>

        {showProductSearch && (
          <JobProductSearch
            search={productSearch} setSearch={setProductSearch}
            onClose={() => { setShowProductSearch(false); setProductSearch('') }}
            addedProducts={addedProducts}
            setAddedProducts={(next) => {
              const resolved = typeof next === 'function' ? next(addedProducts) : next
              setAddedProducts(resolved)
              checkDirty(equipments, resolved, services, adminNote)
            }}
          />
        )}
      </Modal>

      {/* ── Inline Invoice Modal — opens on top of ViewJobModal ── */}
      {showInvoiceModal && createdInvoiceId && (
        <JobInvoiceModal
          show={showInvoiceModal}
          onHide={() => { setShowInvoiceModal(false); setCreatedInvoiceId(null) }}
          invoiceId={createdInvoiceId}
          jobName={jobData?.job_name}
        />
      )}

      {/* ── Inline Quotation Modal — ADD THIS ── */}
      {showQuotationModal && createdQuotationId && (
        <JobQuotationModal
          show={showQuotationModal}
          onHide={() => { setShowQuotationModal(false); setCreatedQuotationId(null) }}
          quotationId={createdQuotationId}
          jobName={jobData?.job_name}
        />
      )}
    </>
  )
}

// ─── Main Component ────────────────────────────────────────────────────────────
export default function JobList() {
  const router = useRouter()

  const [currentPage, setCurrentPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState('')
  const [keyword, setKeyword] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [appliedFilters, setAppliedFilters] = useState({})

  const [viewJobId, setViewJobId] = useState(null)
  const [showViewModal, setShowViewModal] = useState(false)
  const [holdTarget, setHoldTarget] = useState(null)
  const [showHoldModal, setShowHoldModal] = useState(false)
  const [assignTarget, setAssignTarget] = useState(null)
  const [showAssignModal, setShowAssignModal] = useState(false)
  const [showAssignBtn, setShowAssignBtn] = useState(false)
  const [showDeleteBtn, setShowDeleteBtn] = useState(false)

  const logsPerPage = 25

  const { Logout } = UseLogout()
  const { refresh } = useRefreshToken()

  const handlePermission = async () => {
    console.log('=== handlePermission called ===')
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/common/getPermissionforuser`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: 'include',
      })
      if (response.status === 401 || response.status === 403) {
        try {
          await refresh()
          return handlePermission()
        } catch (refreshError) {
          console.error('Error refreshing token:', refreshError)
          Logout()
        }
      }
      if (response.status === 200) {
        const data = await response.json()
        const permissions = (data.data || []).map(Number)
        setShowAssignBtn(permissions.includes(163))
        setShowDeleteBtn(permissions.includes(164))
      }
    } catch (error) {
      console.error('Permission fetch error:', error)
    }
  }

  const { data: jobsData, isLoading, refetch } = useGetAllJobsQuery(appliedFilters, { refetchOnMountOrArgChange: true })
  useEffect(() => {
    handlePermission()
  }, [])
  const [updateJobStatus] = useUpdateJobStatusMutation()
  const [deleteJob] = useDeleteJobMutation()

  const allJobs = jobsData?.data ?? []
  const totalPages = Math.ceil(allJobs.length / logsPerPage) || 1
  const jobs = allJobs.slice((currentPage - 1) * logsPerPage, currentPage * logsPerPage)

  const handleSearch = () => {
    setCurrentPage(1)
    const filters = {
      ...(keyword.trim() && { keyword: keyword.trim() }),
      ...(statusFilter && { status: statusFilter }),
      ...(fromDate && toDate && { from_date: fromDate, to_date: toDate }),
    }
    if (JSON.stringify(filters) === JSON.stringify(appliedFilters)) refetch()
    else setAppliedFilters(filters)
  }

  const handleStatusChange = async (id, newStatus) => {
    try {
      await updateJobStatus({ id, status: newStatus }).unwrap()
      Swal.fire({ icon: 'success', title: 'Status updated', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
      refetch()
    } catch (err) {
      const msg = err?.data?.message || 'Could not update status.'
      const code = err?.data?.code
      if (code === 'ASSIGN_REQUIRED') {
        const job = allJobs.find(j => j.id === id)  // ← use allJobs directly, no refetch
        Swal.fire({
          icon: 'warning',
          title: '👤 Assign First',
          text: msg,
          confirmButtonText: 'Assign Now',
          showCancelButton: true,
          cancelButtonText: 'Later',
        }).then((result) => {
          if (result.isConfirmed && job) {
            const assignedUsers = (() => {
              try { return Array.isArray(job.assigned_users) ? job.assigned_users : JSON.parse(job.assigned_users || '[]') } catch { return [] }
            })()
            setAssignTarget({ id: job.id, assigned_users: assignedUsers })
            setShowAssignModal(true)
          }
        })
      } else {
        Swal.fire({ icon: 'error', title: 'Cannot Update Status', text: msg })
      }
    }
  }

  const handleHoldConfirm = async (reason) => {
    try {
      await updateJobStatus({ id: holdTarget.id, status: 'ON_HOLD', hold_reason: reason }).unwrap()
      Swal.fire({ icon: 'success', title: 'Job put on hold', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
      setShowHoldModal(false)
      setHoldTarget(null)
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to put job on hold' })
    }
  }

  const handleDelete = async (id, name) => {
    const result = await Swal.fire({
      icon: 'warning', title: 'Delete Job?',
      text: `"${name}" and all its items will be permanently deleted.`,
      showCancelButton: true, confirmButtonColor: '#dc3545', confirmButtonText: 'Delete',
    })
    if (!result.isConfirmed) return
    try {
      await deleteJob(id).unwrap()
      Swal.fire({ icon: 'success', title: 'Job deleted', toast: true, timer: 1500, position: 'top-end', showConfirmButton: false })
    } catch {
      Swal.fire({ icon: 'error', title: 'Failed to delete job' })
    }
  }

  const formatDate = (d) => d ? new Date(d).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  }) : '-'
  const formatAmount = (v) => { const n = Number(v); return isNaN(n) ? '0.00' : n.toFixed(2) }

  return (
    <>
      <HoldReasonModal show={showHoldModal} onHide={() => setShowHoldModal(false)} onConfirm={handleHoldConfirm} />

      {assignTarget && (
        <AssignUsersModal
          show={showAssignModal}
          onHide={() => setShowAssignModal(false)}
          jobId={assignTarget.id}
          currentAssigned={assignTarget.assigned_users || []}
          onSaved={async () => {
            await refetch()
          }}  // refetch() already returns a promise, this is fine
        />
      )}

      {showViewModal && (
        <ViewJobModal
          jobId={viewJobId}
          show={showViewModal}
          onHide={() => setShowViewModal(false)}
          onUpdated={refetch}
        />
      )}

      <Row className="justify-content-center">
        <Col>
          <Card>
            <CardHeader className="py-3 bg-light">
              <Row className="align-items-center justify-content-between">
                <Col><CardTitle as="h4" className="mb-0">Job List</CardTitle></Col>
                <Col xs="auto">
                  <Button className="btn bg-primary border border-primary" onClick={() => router.push('/create-job')}>
                    <IconifyIcon icon="fa6-solid:plus" className="me-1" /> Create Job
                  </Button>
                </Col>
              </Row>
            </CardHeader>

            <CardBody>
              {/* Filters */}
              <div className="po-filter-bar mb-3">
                <div className="row g-2 align-items-end">

                  {/* Keyword */}
                  <div className="col-12 col-sm-6 col-lg-4 col-xl-4">
                    <div className="po-filter-label">Keyword</div>
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      placeholder="Search by job name or ID..."
                      value={keyword}
                      onChange={(e) => setKeyword(e.target.value)}
                    />
                  </div>

                  {/* From Date */}
                  <div className="col-6 col-sm-3 col-lg-2 col-xl-2">
                    <div className="po-filter-label">From Date</div>
                    <input
                      type="date"
                      className="form-control form-control-sm"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                    />
                  </div>

                  {/* To Date */}
                  <div className="col-6 col-sm-3 col-lg-2 col-xl-2">
                    <div className="po-filter-label">To Date</div>
                    <input
                      type="date"
                      className="form-control form-control-sm"
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                    />
                  </div>

                  {/* Status */}
                  <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                    <div className="po-filter-label">Status</div>
                    <select
                      className="form-select form-select-sm"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="">All</option>
                      <option value="PENDING">PENDING</option>
                      <option value="ASSIGNED">ASSIGNED</option>
                      <option value="IN_PROGRESS">IN PROGRESS</option>
                      <option value="ON_HOLD">ON HOLD</option>
                      <option value="COMPLETED">COMPLETED</option>
                      <option value="CLOSED">CLOSED</option>
                      <option value="CANCELLED">CANCELLED</option>
                    </select>
                  </div>

                  {/* Search Button */}
                  <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                    <button
                      className="btn btn-dark btn-sm w-100 d-flex align-items-center justify-content-center gap-2"
                      onClick={handleSearch}
                    >
                      Search
                    </button>
                  </div>

                </div>
              </div>

              {/* Table */}
              <Table striped bordered hover responsive>
                <thead className="table-light">
                  <tr>
                    <th>ID</th>
                    <th>Created</th>
                    <th>Job Name</th>
                    <th>Customer</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                    <th className="text-end">Grand Total</th>
                    <th className="text-end">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr><td colSpan="9" className="text-center"><Spinner animation="border" size="sm" /> Loading…</td></tr>
                  ) : jobs.length > 0 ? jobs.map((job) => {
                    const assignedUsers = (() => { try { return Array.isArray(job.assigned_users) ? job.assigned_users : JSON.parse(job.assigned_users || '[]') } catch { return [] } })()
                    return (
                      <tr key={job.id}>
                        <td style={{ fontWeight: 600, color: 'var(--bs-primary)' }}>#{job.id}</td>
                        <td style={{ fontSize: '0.75rem' }}>{formatDate(job.created_at)}</td>
                        <td style={{ fontWeight: 600 }}>{job.job_name}</td>
                        <td style={{ fontSize: '0.83rem' }}>
                          {job.customer_name
                            ? <><div className="fw-semibold">{job.customer_name}</div><div className="text-muted" style={{ fontSize: '0.72rem' }}>{job.customer_phone || ''}</div></>
                            : <span style={{ color: '#d1d5db' }}>—</span>}
                        </td>
                        <td>
                          {assignedUsers.length > 0
                            ? <div className="d-flex flex-wrap gap-1">
                              {assignedUsers.slice(0, 2).map((u) => (
                                <span key={u.id} style={{
                                  background: '#eff6ff',
                                  border: '1px solid #bfdbfe',
                                  borderRadius: 20,
                                  padding: '3px 10px',
                                  fontSize: '0.72rem',
                                  fontWeight: 500,
                                  color: '#1d4ed8',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: 4,
                                }}>
                                  <Icon icon="mdi:account" width={11} />
                                  {u.name}
                                  <span style={{
                                    background: '#dbeafe',
                                    borderRadius: 10,
                                    padding: '0px 5px',
                                    fontSize: '0.65rem',
                                    fontWeight: 700,
                                    color: '#1e40af',
                                  }}>
                                    #{u.id}
                                  </span>
                                </span>
                              ))}
                              {assignedUsers.length > 2 && (
                                <span style={{
                                  background: '#f3f4f6',
                                  borderRadius: 20,
                                  padding: '3px 8px',
                                  fontSize: '0.70rem',
                                  color: '#6b7280',
                                  fontWeight: 600,
                                }}>
                                  +{assignedUsers.length - 2} more
                                </span>
                              )}
                            </div>
                            : <span style={{ color: '#d1d5db', fontSize: '0.78rem' }}>—</span>}
                        </td>
                        <td>
                          <div className="d-flex align-items-center gap-1">
                            <StatusDot status={job.status} />
                            {job.admin_note && (
                              <span title={job.admin_note} style={{ cursor: 'pointer', color: '#f59e0b', display: 'flex', alignItems: 'center' }}>
                                <Icon icon="mdi:help-circle-outline" width={15} />
                              </span>
                            )}
                          </div>
                          {job.status === 'ON_HOLD' && job.hold_reason && (
                            <div style={{ fontSize: '0.68rem', color: '#c2410c', marginTop: 2 }} title={job.hold_reason}>
                              <Icon icon="mdi:information-outline" width={11} /> {job.hold_reason.length > 30 ? job.hold_reason.slice(0, 30) + '…' : job.hold_reason}
                            </div>
                          )}
                        </td>
                        <td className="text-end" style={{ fontWeight: 600 }}>{formatAmount(job.grand_total)}</td>
                        <td className="text-end">
                          <div className="d-flex justify-content-end align-items-center gap-1 flex-wrap">

                            {/* ── PENDING: Assign + disabled Start with warning ── */}
                            {job.status === 'PENDING' && (
                              <>
                                {showAssignBtn && (
                                  <Button
                                    onClick={() => { setAssignTarget({ id: job.id, assigned_users: assignedUsers }); setShowAssignModal(true) }}
                                    style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#6366f1', borderColor: '#6366f1', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                    <Icon icon="mdi:account-plus" width={12} /> Assign
                                  </Button>
                                )}
                                <button
                                  disabled
                                  title="Assign a technician first to start this job"
                                  style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, border: '1px solid #d1d5db', backgroundColor: '#f3f4f6', color: '#9ca3af', display: 'flex', alignItems: 'center', gap: 3, cursor: 'not-allowed', opacity: 0.6 }}>
                                  <Icon icon="mdi:play" width={12} /> Start
                                </button>
                                {showAssignBtn && (
                                  <span style={{ fontSize: '0.60rem', color: '#92400e', background: '#fef9c3', border: '1px solid #fbbf24', borderRadius: 10, padding: '2px 6px', display: 'flex', alignItems: 'center', gap: 2, height: 22 }}>
                                    ⚠️ Assign first
                                  </span>
                                )}
                              </>
                            )}

                            {/* ── ASSIGNED: active Start + Reassign ── */}
                            {job.status === 'ASSIGNED' && (
                              <>
                                <Button
                                  onClick={() => handleStatusChange(job.id, 'IN_PROGRESS')}
                                  style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#10b981', borderColor: '#10b981', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                  <Icon icon="mdi:play" width={12} /> Start
                                </Button>
                                {showAssignBtn && (
                                  <Button
                                    onClick={() => { setAssignTarget({ id: job.id, assigned_users: assignedUsers }); setShowAssignModal(true) }}
                                    style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#6366f1', borderColor: '#6366f1', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                    <Icon icon="mdi:account-edit" width={12} /> Reassign
                                  </Button>
                                )}
                              </>
                            )}

                            {/* ── IN_PROGRESS: Hold + Complete ── */}
                            {job.status === 'IN_PROGRESS' && (
                              <>
                                <Button
                                  onClick={() => handleStatusChange(job.id, 'COMPLETED')}
                                  style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#198754', borderColor: '#198754', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                  <Icon icon="mdi:check" width={12} /> Complete
                                </Button>
                                <Button
                                  onClick={() => { setHoldTarget({ id: job.id, name: job.job_name }); setShowHoldModal(true) }}
                                  style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#f97316', borderColor: '#f97316', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                  <Icon icon="mdi:pause" width={12} /> Hold
                                </Button>
                              </>
                            )}

                            {/* ── ON_HOLD: Resume only ── */}
                            {job.status === 'ON_HOLD' && (
                              <Button
                                onClick={() => handleStatusChange(job.id, 'IN_PROGRESS')}
                                style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#3b82f6', borderColor: '#3b82f6', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                <Icon icon="mdi:play" width={12} /> Resume
                              </Button>
                            )}

                            {/* ── COMPLETED: Close ── */}
                            {job.status === 'COMPLETED' && (
                              <Button
                                onClick={() => handleStatusChange(job.id, 'CLOSED')}
                                style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#374151', borderColor: '#374151', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                <Icon icon="mdi:lock-outline" width={12} /> Close
                              </Button>
                            )}

                            {/* ── Always visible: View + Delete ── */}
                            <Button
                              onClick={() => { setViewJobId(job.id); setShowViewModal(true) }}
                              style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#5f5f5f', borderColor: '#5f5f5f', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                              <Icon icon="mdi:eye" width={12} /> View
                            </Button>

                            {!['CLOSED', 'CANCELLED', 'COMPLETED'].includes(job.status) && showDeleteBtn && (
                              <Button
                                onClick={() => handleDelete(job.id, job.job_name)}
                                style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#dc3545', borderColor: '#dc3545', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                <Icon icon="mdi:trash-can-outline" width={12} /> Delete
                              </Button>
                            )}

                            {/* ── Invoiced badge ── */}
                            {job.invoice_id && (
                              <span
                                title={`Invoice #${job.invoice_id} created`}
                                style={{ padding: '0.25rem 0.5rem', fontSize: '0.65rem', height: 28, borderRadius: 14, backgroundColor: '#198754', color: '#fff', display: 'flex', alignItems: 'center', gap: 3 }}>
                                <Icon icon="mdi:receipt-text-check-outline" width={12} /> Invoiced
                              </span>
                            )}

                          </div>
                        </td>
                      </tr>
                    )
                  }) : (
                    <tr><td colSpan="9" className="text-center">No Jobs Found</td></tr>
                  )}
                </tbody>
              </Table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="d-flex justify-content-end mt-3">
                  <Pagination>
                    <Pagination.Item disabled={currentPage === 1} onClick={() => setCurrentPage(1)}>First</Pagination.Item>
                    <Pagination.Prev disabled={currentPage === 1} onClick={() => setCurrentPage((p) => p - 1)} />
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let start = Math.max(1, currentPage - 2)
                      if (start + 4 > totalPages) start = Math.max(1, totalPages - 4)
                      const page = start + i
                      return page <= totalPages ? (
                        <Pagination.Item key={page} active={page === currentPage} onClick={() => setCurrentPage(page)}>{page}</Pagination.Item>
                      ) : null
                    })}
                    <Pagination.Next disabled={currentPage === totalPages} onClick={() => setCurrentPage((p) => p + 1)} />
                    <Pagination.Item disabled={currentPage === totalPages} onClick={() => setCurrentPage(totalPages)}>Last</Pagination.Item>
                  </Pagination>
                </div>
              )}
            </CardBody>
          </Card>
        </Col>
      </Row>
    </>
  )
}
