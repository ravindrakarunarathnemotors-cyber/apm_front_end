import dynamic from 'next/dynamic'

export const metadata = {
  title: 'Job List - Service Management',
}


const JobList = dynamic(() => import('./joblist'), { ssr: false })

export default function JobListPage() {
  return <JobList />
}