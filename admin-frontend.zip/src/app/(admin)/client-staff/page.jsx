'use client'

import { useEffect } from "react";
import { useGetClientStaffQuery, useRefreshTokenMutation } from '../../../store/features/apiSlice';



const ClientStaffTable = () => {
  const { data, error, refetch } = useGetClientStaffQuery();
  const [refreshToken] = useRefreshTokenMutation();

  if (error) return <p>Error: {error.data?.message || "Something went wrong"}</p>;
  if (!data) return <p>Loading...</p>;

  return (
    <table border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Role</th>
        </tr>
      </thead>
      <tbody>
        {data.map((staff) => (
          <tr key={staff.id}>
            <td>{staff.id}</td>
            <td>{staff.name}</td>
            <td>{staff.role}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ClientStaffTable;
