'use client'

import { useEffect } from "react";
import { useGetClientStaffQuery, useRefreshTokenMutation } from '../../../store/features/apiSlice';



const ClientStaffTable = () => {
  const { data, error, refetch } = useGetClientStaffQuery();
  const [refreshToken] = useRefreshTokenMutation();

  useEffect(() => {
    if (error && error.status === 403) {
      const refresh = async () => {
        const refresh_token = localStorage.getItem("refresh_token");
        if (!refresh_token) {
          console.log("No refresh token found. Redirect to login.");
          return;
        }

        try {
          const res = await refreshToken({ refresh_token }).unwrap();
          if (res.access_token) {
            sessionStorage.setItem("access_token", res.access_token);
            
            // Ensure new token is used before refetching
            setTimeout(() => {
              refetch();
            }, 100);
          }
        } catch (refreshError) {
          console.error("Token refresh failed", refreshError);
        }
      };

      refresh();
    }
  }, [error, refreshToken, refetch]);

  if (error) return <p>Error: {error.data?.message || "Something went wrong"}</p>;
  if (!data) return <p>Loading...</p>;

  return (
    <table border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Role</th>
        </tr>
      </thead>
      <tbody>
        {data.map((staff) => (
          <tr key={staff.id}>
            <td>{staff.id}</td>
            <td>{staff.name}</td>
            <td>{staff.role}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ClientStaffTable;
