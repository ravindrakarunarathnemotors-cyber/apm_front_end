'use client'

import React, { useState, useRef, useEffect } from 'react'
import Swal from 'sweetalert2'
import { Card, CardBody, Row, Col, Badge, Spinner, Alert } from 'react-bootstrap'
import { useRouter } from 'next/navigation'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import axios from 'axios'
import useLogout from '@/hooks/useLogout'
import { useRefreshTokenMutation, useGetUserMutation, useUpdateUserProfileMutation } from '@/store/features/apiSlice'

const AVATAR_PLACEHOLDER = '/assets/defavatar.jpg'

// ─── Skeleton ──────────────────────────────────────────────────────────────────
function Skeleton({ className = '', style = {} }) {
  return <div className={`skeleton-shimmer rounded ${className}`} style={style} />
}

// ─── SVG upload ring ───────────────────────────────────────────────────────────
function UploadRing({ progress, size = 124 }) {
  const r = (size - 8) / 2
  const circ = 2 * Math.PI * r
  const offset = circ - (progress / 100) * circ
  return (
    <svg width={size} height={size} className="position-absolute top-0 start-0" style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#dee2e6" strokeWidth={4} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke="#0d6efd"
        strokeWidth={4}
        strokeDasharray={circ}
        strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ transition: 'stroke-dashoffset 0.2s ease' }}
      />
    </svg>
  )
}

// ─── Info row ──────────────────────────────────────────────────────────────────
function InfoRow({ icon, value, skeleton }) {
  return (
    <div className="d-flex align-items-center gap-2 py-2 border-bottom border-light-subtle">
      <div
        className="d-flex align-items-center justify-content-center rounded-3 bg-primary bg-opacity-10 flex-shrink-0"
        style={{ width: 32, height: 32 }}>
        <IconifyIcon icon={icon} width={15} height={15} color="#0d6efd" />
      </div>
      {skeleton ? <Skeleton className="flex-fill" style={{ height: 13 }} /> : <span className="small fw-medium text-secondary">{value || '—'}</span>}
    </div>
  )
}

// ─── Password strength bar ─────────────────────────────────────────────────────
function StrengthBar({ pwd }) {
  const score = !pwd ? 0 : [pwd.length >= 8, /[A-Z]/.test(pwd), /[0-9]/.test(pwd), /[^a-zA-Z0-9]/.test(pwd)].filter(Boolean).length
  const bsColor = ['secondary', 'danger', 'warning', 'info', 'success'][score]
  const label = ['', 'Weak', 'Fair', 'Good', 'Strong'][score]
  if (!pwd) return null
  return (
    <div className="mt-2">
      <div className="d-flex gap-1 mb-1">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`rounded-pill ${i <= score ? `bg-${bsColor}` : 'bg-light'}`}
            style={{ flex: 1, height: 4, transition: 'background 0.3s' }}
          />
        ))}
      </div>
      <small className={`fw-semibold text-${bsColor}`}>{label}</small>
    </div>
  )
}

// ─── Unsaved changes modal ─────────────────────────────────────────────────────
function UnsavedModal({ show, onSaveAndExit, onExit, onCancel, saving }) {
  if (!show) return null
  return (
    <div
      className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center"
      style={{ background: 'rgba(10,14,40,0.55)', zIndex: 9999, backdropFilter: 'blur(4px)', animation: 'fadeIn 0.18s ease' }}>
      <div className="bg-white rounded-4 shadow-lg p-4 text-center mx-3" style={{ maxWidth: 400, width: '100%', animation: 'slideUp 0.22s ease' }}>
        <div
          className="d-flex align-items-center justify-content-center rounded-circle border border-warning mx-auto mb-3"
          style={{ width: 56, height: 56, background: '#fff8ec' }}>
          <IconifyIcon icon="mdi:camera-outline" width={26} height={26} color="#f59e0b" />
        </div>

        <h5 className="fw-bold text-dark mb-2">Unsaved Profile Photo</h5>
        <p className="text-muted small mb-4">You changed your profile picture but haven&apos;t saved it yet. What would you like to do?</p>

        <div className="d-flex flex-column gap-2">
          <button className="btn btn-primary rounded-3 py-2 fw-semibold" onClick={onSaveAndExit} disabled={saving}>
            {saving ? (
              <>
                <Spinner size="sm" className="me-2" />
                Saving…
              </>
            ) : (
              '💾 Save & Exit'
            )}
          </button>
          <button className="btn btn-danger rounded-3 py-2 fw-semibold" onClick={onExit} disabled={saving}>
            🚪 Exit Without Saving
          </button>
          <button className="btn btn-outline-secondary rounded-3 py-2" onClick={onCancel} disabled={saving}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Main ──────────────────────────────────────────────────────────────────────
export default function ProfilePage() {
  const router = useRouter()

  const [customerInfo, setCustomerInfo] = useState({
    first_name: '',
    last_name: '',
    contact_number_1: '',
    email: '',
    username: '',
    status: '',
    role_name: '',
    outlet_name: '',
    avatar: AVATAR_PLACEHOLDER,
  })
  const [savedAvatar, setSavedAvatar] = useState(AVATAR_PLACEHOLDER)
  const [avatarChanged, setAvatarChanged] = useState(false)
  const [pwd, setPwd] = useState('')
  const [pwd2, setPwd2] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [showPwd2, setShowPwd2] = useState(false)
  const [errors, setErrors] = useState({ password: '', confirm: '' })
  const [loadingUser, setLoadingUser] = useState(true)
  const [error, setError] = useState(null)
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [pwdSuccess, setPwdSuccess] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [pendingNavUrl, setPendingNavUrl] = useState(null)
  const [modalSaving, setModalSaving] = useState(false)
  const [currentPwd, setCurrentPwd] = useState('')
  const [showCurrentPwd, setShowCurrentPwd] = useState(false)

  const fileRef = useRef(null)

  const [getUser, { data, isLoading, isError }] = useGetUserMutation()
  const [updateUserProfile] = useUpdateUserProfileMutation()
  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()

  useEffect(() => {
    const fetch = async () => {
      try {
        setLoadingUser(true)
        await getUser({ user_id: 1 }).unwrap()
      } catch {
        setError('Error fetching user data')
      } finally {
        setLoadingUser(false)
      }
    }
    fetch()
  }, [])

  useEffect(() => {
    const u = data?.user
    if (!u) return
    const av = u.picture || AVATAR_PLACEHOLDER
    setCustomerInfo({
      first_name: u.first_name || '',
      last_name: u.last_name || '',
      contact_number_1: u.mobile || '',
      email: u.email || '',
      username: u.username || '',
      status: u.status || '',
      role_name: u.role_name || '',
      outlet_name: u.outlet_name || '',
      avatar: av,
    })
    setSavedAvatar(av)
    setAvatarChanged(false)
  }, [data])

  useEffect(() => {
    const h = (e) => {
      if (avatarChanged) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', h)
    return () => window.removeEventListener('beforeunload', h)
  }, [avatarChanged])

  useEffect(() => {
    if (!avatarChanged) return
    const h = (url) => {
      router.events?.emit('routeChangeError')
      setPendingNavUrl(url)
      setShowModal(true)
      throw 'routeChange aborted'
    }
    router.events?.on('routeChangeStart', h)
    return () => router.events?.off('routeChangeStart', h)
  }, [avatarChanged, router])

  const pickImage = () => fileRef.current?.click()

  const onImageSelected = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setCustomerInfo((p) => ({ ...p, avatar: URL.createObjectURL(file) }))
    setAvatarChanged(true)
    const fd = new FormData()
    fd.append('files', file)
    fd.append('product_id', 'temp-brand')
    try {
      setUploading(true)
      setUploadProgress(0)
      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (pe) => pe.total && setUploadProgress(Math.round((pe.loaded * 100) / pe.total)),
      })
      const url = res?.data?.media?.[0]?.media_url
      if (!url) throw new Error('Upload failed')
      setCustomerInfo((p) => ({ ...p, avatar: url }))
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Upload Failed', text: err?.message || 'Image upload failed' })
      setCustomerInfo((p) => ({ ...p, avatar: savedAvatar }))
      setAvatarChanged(false)
    } finally {
      setUploading(false)
      setUploadProgress(0)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const doSaveProfile = async () => {
    const body = {
      user_id: 1,
      first_name: customerInfo.first_name?.trim(),
      last_name: customerInfo.last_name?.trim(),
      email: customerInfo.email?.trim(),
      mobile: customerInfo.contact_number_1?.trim(),
      picture: customerInfo.avatar || null,
    }
    try {
      await updateUserProfile(body).unwrap()
      setSavedAvatar(customerInfo.avatar)
      setAvatarChanged(false)
      await getUser({ user_id: 1 }).unwrap()
      return true
    } catch (err) {
      if (err?.status === 401) {
        try {
          await refreshtoken().unwrap()
          await updateUserProfile(body).unwrap()
          setSavedAvatar(customerInfo.avatar)
          setAvatarChanged(false)
          await getUser({ user_id: 1 }).unwrap()
          return true
        } catch {
          Logout()
        }
      }
      Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
      return false
    }
  }

  const handleSaveProfile = async () => {
    setSavingProfile(true)
    const ok = await doSaveProfile()
    if (ok) Swal.fire({ icon: 'success', title: 'Saved!', text: 'Profile photo updated.', timer: 1800, showConfirmButton: false })
    setSavingProfile(false)
  }

  const handleModalSaveAndExit = async () => {
    setModalSaving(true)
    const ok = await doSaveProfile()
    setModalSaving(false)
    setShowModal(false)
    if (ok && pendingNavUrl) {
      setAvatarChanged(false)
      router.push(pendingNavUrl)
    }
  }
  const handleModalExit = () => {
    setCustomerInfo((p) => ({ ...p, avatar: savedAvatar }))
    setAvatarChanged(false)
    setShowModal(false)
    if (pendingNavUrl) router.push(pendingNavUrl)
  }
  const handleModalCancel = () => {
    setShowModal(false)
    setPendingNavUrl(null)
  }

  const validatePasswords = () => {
    const next = { password: '', confirm: '' }
    let ok = true
    if (pwd.length < 6) {
      next.password = 'Minimum 6 characters'
      ok = false
    }
    if (pwd !== pwd2) {
      next.confirm = 'Passwords do not match'
      ok = false
    }
    setErrors(next)
    return ok
  }



  const handleChangePassword = async () => {
    // validate passwords first
    if (!validatePasswords()) return

    // current password required
    if (!currentPwd.trim()) {
      Swal.fire({
        icon: 'warning',
        title: 'Current Password Required',
        text: 'Please enter your current password.',
      })
      return
    }

    setSavingPassword(true)

    const body = {
      current_password: currentPwd,
      password: pwd,
    }

    try {
      await updateUserProfile(body).unwrap()

      setPwdSuccess(true)

      // clear fields
      setCurrentPwd('')
      setPwd('')
      setPwd2('')

      setTimeout(() => setPwdSuccess(false), 3500)

      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Password updated successfully!',
        timer: 1800,
        showConfirmButton: false,
      })
    } catch (err) {
      // token expired
      if (err?.status === 401) {
        try {
          await refreshtoken().unwrap()

          await updateUserProfile(body).unwrap()

          setPwdSuccess(true)

          setCurrentPwd('')
          setPwd('')
          setPwd2('')

          setTimeout(() => setPwdSuccess(false), 3500)

          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Password updated successfully!',
            timer: 1800,
            showConfirmButton: false,
          })
        } catch (refreshErr) {
          // backend current password error
          if (
            refreshErr?.data?.error ===
            'Current password is incorrect'
          ) {
            Swal.fire({
              icon: 'error',
              title: 'Wrong Password',
              text: 'Current password is incorrect.',
            })
          } else {
            Logout()
          }
        }
      } else {
        // backend current password error
        if (
          err?.data?.error ===
          'Current password is incorrect'
        ) {
          Swal.fire({
            icon: 'error',
            title: 'Wrong Password',
            text: 'Current password is incorrect.',
          })
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Update Failed',
            text: err?.data?.error || 'Please try again.',
          })
        }
      }
    } finally {
      setSavingPassword(false)
    }
  }

  const pwdValid = pwd.length >= 8 && /[A-Z]/.test(pwd) && /[0-9]/.test(pwd) && /[^a-zA-Z0-9]/.test(pwd) && pwd === pwd2 && pwd2.length > 0

  const isLoading_ = loadingUser || isLoading

  if (error || isError)
    return (
      <div className="container mt-5">
        <Alert variant="danger" className="rounded-3 d-flex align-items-center gap-2">
          <IconifyIcon icon="mdi:alert-circle-outline" width={20} height={20} />
          {error || 'Failed to load user data'}
        </Alert>
      </div>
    )

  return (
    <>
      <style>{`
        @keyframes shimmer  { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        @keyframes fadeIn   { from{opacity:0} to{opacity:1} }
        @keyframes slideUp  { from{transform:translateY(20px);opacity:0} to{transform:translateY(0);opacity:1} }
        @keyframes popIn    { 0%{transform:scale(0.85);opacity:0} 70%{transform:scale(1.04)} 100%{transform:scale(1);opacity:1} }
        .skeleton-shimmer {
          background: linear-gradient(90deg,#e9ecef 25%,#f8f9fa 50%,#e9ecef 75%);
          background-size: 200% 100%;
          animation: shimmer 1.4s infinite;
          min-height: 13px;
        }
        .avatar-wrap:hover .avatar-overlay { opacity: 1 !important; }
        .save-pic-enter { animation: popIn 0.28s ease; }
      `}</style>

      <UnsavedModal
        show={showModal}
        onSaveAndExit={handleModalSaveAndExit}
        onExit={handleModalExit}
        onCancel={handleModalCancel}
        saving={modalSaving}
      />

      <div className="container-fluid py-4  px-md-0 px-3" >
        <Row className="g-4 align-items-stretch">
          {/* ── LEFT: Profile card ── */}
          <Col md={4}>
            <Card className="shadow-sm rounded-4 overflow-hidden border-0 h-100">
              {/* Banner */}
              <div
                className=" text-white text-center py-4 position-relative"
                style={{ background: 'linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%)' }}>
                {isLoading_ ? (
                  <Skeleton className="position-absolute rounded-pill" style={{ width: 60, height: 22, top: 12, right: 12 }} />
                ) : (
                  <Badge
                    bg={customerInfo.status?.toLowerCase() === 'active' ? 'success' : 'secondary'}
                    className="position-absolute top-0 end-0 m-2 text-capitalize fw-semibold rounded-pill"
                    style={{ fontSize: 11 }}>
                    {customerInfo.status || 'Unknown'}
                  </Badge>
                )}

                {/* Avatar */}
                <div className="d-flex justify-content-center">
                  <div className="avatar-wrap position-relative" style={{ width: 124, height: 124 }}>
                    {uploading && <UploadRing progress={uploadProgress} size={124} />}
                    <img
                      src={customerInfo.avatar}
                      alt="Profile"
                      className="rounded-circle border border-4 border-white shadow-sm"
                      style={{
                        width: 116,
                        height: 116,
                        objectFit: 'cover',
                        margin: 4,
                        filter: uploading ? 'brightness(0.65)' : 'none',
                        transition: 'filter 0.3s',
                      }}
                    />
                    {/* Hover overlay */}
                    <div
                      className="avatar-overlay position-absolute rounded-circle d-flex align-items-center justify-content-center"
                      style={{ inset: 4, background: 'rgba(0,0,0,0.4)', opacity: 0, transition: 'opacity 0.2s', cursor: 'pointer' }}
                      onClick={pickImage}>
                      <IconifyIcon icon="mdi:camera" width={28} height={28} color="#fff" />
                    </div>
                    {/* Camera FAB */}
                    <button
                      onClick={pickImage}
                      disabled={uploading}
                      className="btn btn-white border border-primary d-flex align-items-center justify-content-center rounded-circle p-0 position-absolute shadow-sm"
                      style={{ width: 32, height: 32, bottom: 4, right: 4, zIndex: 2, background: '#fff' }}
                      title="Change photo">
                      {uploading ? (
                        <Spinner size="sm" variant="primary" style={{ width: 13, height: 13 }} />
                      ) : (
                        <IconifyIcon icon="mdi:camera-outline" width={15} height={15} color="#0d6efd" />
                      )}
                    </button>
                    <input ref={fileRef} type="file" accept="image/*" onChange={onImageSelected} className="d-none" />
                  </div>
                </div>

                {uploading && <p className="small text-white-50 fw-semibold mb-0 mt-2">Uploading {uploadProgress}%…</p>}
              </div>

              {/* Name chip — overlaps banner */}
              <div className="text-center px-4" style={{ marginTop: -28 }}>
                <div className="bg-white rounded-3 shadow-sm pt-4 pb-3 px-3 position-relative">
                  {isLoading_ ? (
                    <>
                      <Skeleton className="mx-auto mb-2 rounded-pill" style={{ width: '55%', height: 16 }} />
                      <Skeleton className="mx-auto rounded-pill" style={{ width: '38%', height: 13 }} />
                    </>
                  ) : (
                    <>
                      <h5 className="fw-bold text-dark mb-2">
                        {customerInfo.first_name} {customerInfo.last_name}
                      </h5>
                      <Badge
                        bg="primary"
                        className="bg-opacity-10 text-wrap text-primary fw-semibold rounded-pill px-3 py-1"
                        style={{ fontSize: 12 }}>
                        <IconifyIcon icon="mdi:account-cog" width={13} height={13} className="me-1" />
                        {customerInfo.role_name}
                      </Badge>
                    </>
                  )}
                </div>
              </div>

              {/* Info rows */}
              <CardBody className="px-4 pb-4 pt-2">
                <InfoRow icon="mdi:email-outline" value={customerInfo.email} skeleton={isLoading_} />
                <InfoRow icon="mdi:store-outline" value={customerInfo.outlet_name} skeleton={isLoading_} />
                <InfoRow icon="mdi:phone-outline" value={customerInfo.contact_number_1} skeleton={isLoading_} />

                {avatarChanged && !uploading && (
                  <div className="mt-4 save-pic-enter">
                    <button
                      onClick={handleSaveProfile}
                      disabled={savingProfile}
                      className="btn btn-primary w-100 rounded-3 fw-bold d-flex align-items-center justify-content-center gap-2 py-2">
                      {savingProfile ? (
                        <>
                          <Spinner size="sm" />
                          Saving Photo…
                        </>
                      ) : (
                        <>
                          <IconifyIcon icon="mdi:content-save-outline" width={18} height={18} />
                          Save Profile Photo
                        </>
                      )}
                    </button>
                    <p className="text-center text-muted mt-2 mb-0" style={{ fontSize: 11 }}>
                      ⚠️ Unsaved — will be lost if you leave
                    </p>
                  </div>
                )}
              </CardBody>
            </Card>
          </Col>

          {/* ── RIGHT: Change Password card ── */}
          <Col md={8}>
            <Card className="shadow-sm rounded-4 border-0 h-100">
              <CardBody className="p-4">
                {/* Header */}
                <div className="d-flex align-items-center gap-3 mb-3">
                  <div
                    className="d-flex align-items-center justify-content-center rounded-3  flex-shrink-0 shadow-sm"
                    style={{ width: 44, height: 44, background: 'linear-gradient(0deg, var(--primary-color) 0%, var(--secondary-color) 100%)' }}>
                    <IconifyIcon icon="mdi:lock-outline" width={22} height={22} color="#fff" />
                  </div>
                  <div>
                    <h5 className="fw-bold text-dark mb-0">Change Password</h5>
                    <small className="text-muted">Choose a strong password to protect your account</small>
                  </div>
                </div>

                <hr className="border-light-subtle mb-4" />

                {/* Success alert */}
                {pwdSuccess && (
                  <Alert
                    variant="success"
                    className="d-flex align-items-center gap-2 rounded-3 py-2 mb-4 border-0"
                    style={{ animation: 'popIn 0.3s ease' }}>
                    <IconifyIcon icon="mdi:check-circle" width={20} height={20} />
                    <span className="fw-semibold small">Password updated successfully!</span>
                  </Alert>
                )}

                <Row className="g-3 mb-3">
                  <Col md={12}>
                    <label className="form-label small fw-semibold text-secondary mb-1">
                      Current Password
                    </label>

                    <div className="input-group">
                      <input
                        className="form-control rounded-start-3"
                        type={showCurrentPwd ? 'text' : 'password'}
                        value={currentPwd}
                        onChange={(e) => setCurrentPwd(e.target.value)}
                        placeholder="Enter current password"
                      />

                      <button
                        type="button"
                        className="btn btn-outline-secondary rounded-end-3"
                        onClick={() => setShowCurrentPwd((s) => !s)}
                      >
                        <IconifyIcon
                          icon={
                            showCurrentPwd
                              ? 'mdi:eye-off-outline'
                              : 'mdi:eye-outline'
                          }
                          width={18}
                          height={18}
                        />
                      </button>
                    </div>
                  </Col>
                  {/* New password */}
                  <Col md={6}>
                    <label className="form-label small fw-semibold text-secondary mb-1">New Password</label>
                    <div className="input-group">
                      <input
                        className={`form-control rounded-start-3 ${errors.password ? 'is-invalid' : ''}`}
                        type={showPwd ? 'text' : 'password'}
                        value={pwd}
                        onChange={(e) => {
                          setPwd(e.target.value)
                          if (errors.password) setErrors((p) => ({ ...p, password: '' }))
                        }}
                        placeholder="Enter new password"
                      />
                      <button type="button" className="btn btn-outline-secondary rounded-end-3" onClick={() => setShowPwd((s) => !s)}>
                        <IconifyIcon icon={showPwd ? 'mdi:eye-off-outline' : 'mdi:eye-outline'} width={18} height={18} />
                      </button>
                      {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                    </div>
                    <StrengthBar pwd={pwd} />
                  </Col>

                  {/* Confirm password */}
                  <Col md={6}>
                    <label className="form-label small fw-semibold text-secondary mb-1">Confirm Password</label>
                    <div className="input-group">
                      <input
                        className={`form-control rounded-start-3 ${errors.confirm ? 'is-invalid' : ''}`}
                        type={showPwd2 ? 'text' : 'password'}
                        value={pwd2}
                        onChange={(e) => {
                          setPwd2(e.target.value)
                          if (errors.confirm) setErrors((p) => ({ ...p, confirm: '' }))
                        }}
                        placeholder="Repeat new password"
                      />
                      <button type="button" className="btn btn-outline-secondary rounded-end-3" onClick={() => setShowPwd2((s) => !s)}>
                        <IconifyIcon icon={showPwd2 ? 'mdi:eye-off-outline' : 'mdi:eye-outline'} width={18} height={18} />
                      </button>
                      {errors.confirm && <div className="invalid-feedback">{errors.confirm}</div>}
                    </div>
                    {pwd && pwd2 && (
                      <small className={`fw-semibold mt-2 d-flex align-items-center gap-1 text-${pwd === pwd2 ? 'success' : 'danger'}`}>
                        <IconifyIcon icon={pwd === pwd2 ? 'mdi:check-circle' : 'mdi:close-circle'} width={14} height={14} />
                        {pwd === pwd2 ? 'Passwords match' : "Passwords don't match"}
                      </small>
                    )}
                  </Col>
                </Row>

                {/* Requirements checklist */}
                <div className="rounded-3  border-opacity-25 bg-info bg-opacity-10 p-3 mb-4">
                  <p className="small fw-bold text-primary mb-2">Password requirements:</p>
                  <Row className="g-1">
                    {[
                      [pwd.length >= 8, 'At least 8 characters'],
                      [/[A-Z]/.test(pwd), 'One uppercase letter'],
                      [/[0-9]/.test(pwd), 'One number'],
                      [/[^a-zA-Z0-9]/.test(pwd), 'One special character'],
                    ].map(([met, label]) => (
                      <Col xs={12} md={6} key={label}>
                        <div className={`d-flex align-items-center gap-1 small fw-medium ${met ? 'text-success' : 'text-muted'}`}>
                          <IconifyIcon
                            icon={met ? 'mdi:check-circle' : 'mdi:circle-outline'}
                            width={15}
                            height={15}
                            color={met ? '#198754' : '#adb5bd'}
                          />
                          {label}
                        </div>
                      </Col>
                    ))}
                  </Row>
                </div>
                <div className="justify-content-end p-2 d-flex">
                  {/* Submit */}
                  <button
                    onClick={handleChangePassword}
                    disabled={savingPassword || !pwdValid}
                    className={`btn fw-bold d-flex align-items-center gap-2 px-4 py-2 rounded-3 text-white border-0 ${!pwdValid || savingPassword ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    style={{
                      background:
                        !pwdValid || savingPassword
                          ? '#6c757d' // Fallback solid gray for disabled state
                          : 'linear-gradient(120deg, var(--primary-color) 0%, var(--secondary-color) 40%)',
                      transition: 'all 0.3s ease',
                    }}>
                    {savingPassword ? (
                      <>
                        <Spinner size="sm" animation="border" />
                        <span>Updating…</span>
                      </>
                    ) : (
                      <>
                        <IconifyIcon icon="mdi:lock-reset" width={18} height={18} />
                        <span>Update Password</span>
                      </>
                    )}
                  </button>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  )
}
