'use client'

import React, { useState, useRef, useEffect } from 'react'
import Swal from 'sweetalert2'
import { Button, Card, CardBody, CardTitle, Row, Col } from 'react-bootstrap'
import Link from 'next/link'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import axios from 'axios'
import useLogout from '@/hooks/useLogout'
import { useRefreshTokenMutation, useGetUserMutation, useUpdateUserProfileMutation } from '@/store/features/apiSlice'
const AVATAR_PLACEHOLDER = '/assets/defavatar.jpg'
export default function CreateCustomer() {
  const [customerInfo, setCustomerInfo] = useState({
    first_name: '',
    last_name: '',
    contact_number_1: '',
    email: '',
    username: '',
    status: '',
    role_name: '',
    outlet_name: '',
    avatar: AVATAR_PLACEHOLDER,
  })

  const [pwd, setPwd] = useState('')
  const [pwd2, setPwd2] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [showPwd2, setShowPwd2] = useState(false)

  const [errors, setErrors] = useState({ password: '', confirm: '' })

  const [loadingUser, setLoadingUser] = useState(true)
  const [error, setError] = useState(null)

  let userId = ''
  if (typeof window !== 'undefined') {
    userId = sessionStorage.getItem('user_id') || ''
  }

  const [getUser, { data, isLoading, isError }] = useGetUserMutation()
  const [updateUserProfile, { isLoading: saving }] = useUpdateUserProfileMutation()
  const [refreshtoken] = useRefreshTokenMutation()
  const { Logout } = useLogout()
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const fileRef = useRef(null)

  useEffect(() => {
    const fetchUserData = async () => {
      if (!userId) {
        setError('User ID not found')
        setLoadingUser(false)
        return
      }
      try {
        setLoadingUser(true)
        setError(null)
        await getUser({ user_id: userId }).unwrap()
      } catch (err) {
        console.error('Failed to fetch user data:', err)
        setError('Error fetching user data')
      } finally {
        setLoadingUser(false)
      }
    }
    fetchUserData()
  }, [userId, getUser])

  useEffect(() => {
    const u = data?.user
    if (u) {
      setCustomerInfo({
        first_name: u.first_name || '',
        last_name: u.last_name || '',
        contact_number_1: u.mobile || '',
        email: u.email || '',
        username: u.username || '',
        status: u.status || '',
        role_name: u.role_name || '',
        outlet_name: u.outlet_name || '',
        avatar: u.picture || AVATAR_PLACEHOLDER,
      })
    }
  }, [data])

  const handleChange = (e) => {
    const { name, value } = e.target
    setCustomerInfo((prev) => ({ ...prev, [name]: value }))
  }

  const validatePasswords = () => {
    let ok = true
    const next = { password: '', confirm: '' }

    if (pwd || pwd2) {
      if (pwd.length < 6) {
        next.password = 'Password must be at least 6 characters'
        ok = false
      }
      if (pwd !== pwd2) {
        next.confirm = 'Passwords do not match'
        ok = false
      }
    }
    setErrors(next)
    return ok
  }

  const pickImage = () => fileRef.current?.click()

  const onImageSelected = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    const previewURL = URL.createObjectURL(file)
    setCustomerInfo((p) => ({ ...p, avatar: previewURL }))

    const formData = new FormData()
    formData.append('files', file)
    formData.append('product_id', 'temp-brand')

    try {
      setUploading(true)
      setUploadProgress(0)

      const res = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/product-media/upload-staging`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (pe) => {
          if (!pe.total) return
          setUploadProgress(Math.round((pe.loaded * 100) / pe.total))
        },
      })

      const uploadedUrl = res?.data?.media?.[0]?.media_url
      if (!uploadedUrl) throw new Error('Upload failed')

      setCustomerInfo((p) => ({ ...p, avatar: uploadedUrl }))
    } catch (err) {
      console.error(err)
      Swal.fire({ icon: 'error', title: 'Upload Failed', text: err?.message || 'Image upload failed' })
      setCustomerInfo((p) => ({ ...p, avatar: AVATAR_PLACEHOLDER }))
    } finally {
      setUploading(false)
      setUploadProgress(0)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  //   const handleSaveProfile = async () => {
  //     setSavingProfile(true)
  //   const body = {
  //     user_id: userId,
  //     first_name: customerInfo.first_name?.trim(),
  //     last_name: customerInfo.last_name?.trim(),
  //     email: customerInfo.email?.trim(),
  //     mobile: customerInfo.contact_number_1?.trim(),
  //     picture: customerInfo.avatar || null,
  //   }

  //   try {
  //     await updateUserProfile(body).unwrap()
  //     Swal.fire('Saved', 'Profile updated successfully.', 'success')
  //     await getUser({ user_id: userId }).unwrap()
  //   } catch (err) {
  //     if (err?.status === 401) {
  //       try {
  //         await refreshtoken().unwrap()
  //         await updateUserProfile(body).unwrap()
  //         Swal.fire('Saved', 'Profile updated successfully.', 'success')
  //         await getUser({ user_id: userId }).unwrap()
  //         return
  //       } catch (e2) {
  //         Logout()
  //       }
  //     }
  //     console.error(err)
  //     Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
  //   }
  // }

  const handleSaveProfile = async () => {
    setSavingProfile(true)
    const body = {
      user_id: userId,
      first_name: customerInfo.first_name?.trim(),
      last_name: customerInfo.last_name?.trim(),
      email: customerInfo.email?.trim(),
      mobile: customerInfo.contact_number_1?.trim(),
      picture: customerInfo.avatar || null,
    }

    try {
      await updateUserProfile(body).unwrap()
      Swal.fire('Saved', 'Profile updated successfully.', 'success')
      await getUser({ user_id: userId }).unwrap()
    } catch (err) {
      if (err?.status === 401) {
        try {
          await refreshtoken().unwrap()
          await updateUserProfile(body).unwrap()
          Swal.fire('Saved', 'Profile updated successfully.', 'success')
          await getUser({ user_id: userId }).unwrap()
        } catch (e2) {
          Logout()
        }
      } else {
        console.error(err)
        Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
      }
    } finally {
      setSavingProfile(false)
    }
  }

  // const handleChangePassword = async () => {
  //   if (!validatePasswords()) return
  // setSavingPassword(true)
  //   const body = {
  //     user_id: userId,
  //     password: pwd,
  //   }

  //   try {
  //     await updateUserProfile(body).unwrap()
  //     Swal.fire('Saved', 'Password updated successfully.', 'success')
  //     setPwd('')
  //     setPwd2('')
  //   } catch (err) {
  //     if (err?.status === 401) {
  //       try {
  //         await refreshtoken().unwrap()
  //         await updateUserProfile(body).unwrap()
  //         Swal.fire('Saved', 'Password updated successfully.', 'success')
  //         setPwd('')
  //         setPwd2('')
  //         return
  //       } catch (e2) {
  //         Logout()
  //       }
  //     }
  //     console.error(err)
  //     Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
  //   }
  // }

  const handleChangePassword = async () => {
    if (!validatePasswords()) return

    setSavingPassword(true)
    const body = {
      user_id: userId,
      password: pwd,
    }

    try {
      await updateUserProfile(body).unwrap()
      Swal.fire('Saved', 'Password updated successfully.', 'success')
      setPwd('')
      setPwd2('')
    } catch (err) {
      if (err?.status === 401) {
        try {
          await refreshtoken().unwrap()
          await updateUserProfile(body).unwrap()
          Swal.fire('Saved', 'Password updated successfully.', 'success')
          setPwd('')
          setPwd2('')
        } catch (e2) {
          Logout()
        }
      } else {
        console.error(err)
        Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
      }
    } finally {
      setSavingPassword(false)
    }
  }

  const handleSave = async () => {
    if (!validatePasswords()) return

    const body = {
      user_id: userId,
      first_name: customerInfo.first_name?.trim(),
      last_name: customerInfo.last_name?.trim(),
      email: customerInfo.email?.trim(),
      mobile: customerInfo.contact_number_1?.trim(),
      picture: customerInfo.avatar || null,
      ...(pwd ? { password: pwd } : {}),
    }

    try {
      await updateUserProfile(body).unwrap()
      Swal.fire('Saved', 'Profile updated successfully.', 'success')
      setPwd('')
      setPwd2('')
      await getUser({ user_id: userId }).unwrap()
    } catch (err) {
      if (err?.status === 401) {
        try {
          await refreshtoken().unwrap()
          await updateUserProfile(body).unwrap()
          Swal.fire('Saved', 'Profile updated successfully.', 'success')
          setPwd('')
          setPwd2('')
          await getUser({ user_id: userId }).unwrap()
          return
        } catch (e2) {
          Logout()
        }
      }
      console.error(err)
      Swal.fire({ icon: 'error', title: 'Update failed', text: err?.data?.error || 'Please try again.' })
    }
  }

  if (loadingUser || isLoading) return <div>Loading user data...</div>
  if (error || isError) return <div>Error: {error || 'Failed to load user data'}</div>

  return (
    <div className="container mt-4">
      <Row className="g-4 align-items-stretch">
        <Col md={4} className="d-flex">
          <Card className="w-100 h-100 overflow-hidden rounded-4 shadow" style={{ backgroundColor: '#f8f9fa' }}>
            <div className="text-white text-center py-4 position-relative" style={{ backgroundColor: '#5f83e7' }}>
              <span
                style={{
                  backgroundColor: '#020c07ff',
                  color: 'white',
                  padding: '4px 10px',
                  borderRadius: '12px',
                  textTransform: 'capitalize',
                  fontSize: '0.55rem',
                  minWidth: '80px',
                  textAlign: 'center',
                  position: 'absolute',
                  top: '10px',
                  right: '10px',
                  zIndex: 2,
                }}>
                {customerInfo.status}
              </span>
              <div className="position-relative mx-auto mb-3" style={{ width: 120, height: 120 }}>
                <img
                  src={customerInfo.avatar}
                  alt="Profile"
                  className="rounded-circle img-fluid"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <Link
                  href=""
                  onClick={(e) => {
                    e.preventDefault()
                    pickImage()
                  }}
                  className="bg-primary text-white rounded-circle d-flex justify-content-center align-items-center position-absolute"
                  style={{ width: 36, height: 36, bottom: 0, right: 0 }}>
                  <IconifyIcon icon="bi:camera" width={15} height={15} />
                </Link>
                <input ref={fileRef} type="file" accept="image/*" onChange={onImageSelected} style={{ display: 'none' }} />
              </div>
              {uploading && <div className="small">Uploading… {uploadProgress}%</div>}
            </div>

            <CardBody className="text-center px-4">
              <h5 className="mb-0 fw-bold">
                {customerInfo.first_name} {customerInfo.last_name}
              </h5>
              <div style={{ marginTop: '8px' }} className="d-flex justify-content-center align-items-center gap-1 fw-bold">
                <IconifyIcon icon="mdi:account-cog" width={18} height={18} />
                <span>{customerInfo.role_name}</span>
              </div>
              <hr />
              <div className="d-flex flex-column align-items-center gap-2">
                <div className="d-flex align-items-center gap-1">
                  <IconifyIcon icon="mdi:email" width={18} height={18} />
                  <span>{customerInfo.email}</span>
                </div>

                <div className="d-flex align-items-center gap-1">
                  <IconifyIcon icon="mdi:store" width={18} height={18} />
                  <span>{customerInfo.outlet_name}</span>
                </div>
                <div className="d-flex align-items-center gap-1">
                  <IconifyIcon icon="mdi:phone" width={18} height={18} />
                  <span>{customerInfo.contact_number_1}</span>
                </div>
              </div>
            </CardBody>
          </Card>
        </Col>
        <Col md={8} className="d-flex">
          <Card className="w-100 h-100">
            <CardBody className="d-flex flex-column h-100">
              <CardTitle as="h5" className="mb-3">
                Edit Profile
              </CardTitle>

              <Row>
                <Col md={6} className="mb-3">
                  <label>First Name</label>
                  <input className="form-control" name="first_name" value={customerInfo.first_name} onChange={handleChange} />
                </Col>
                <Col md={6} className="mb-3">
                  <label>Last Name</label>
                  <input className="form-control" name="last_name" value={customerInfo.last_name} onChange={handleChange} />
                </Col>
              </Row>

              <Row>
                <Col md={6} className="mb-3">
                  <label>Email</label>
                  <input className="form-control" name="email" type="email" value={customerInfo.email} onChange={handleChange} />
                </Col>
                {/* <Col md={6} className="mb-3">
                  <label>Mobile Number</label>
                  <input className="form-control" name="contact_number_1" value={customerInfo.contact_number_1} onChange={handleChange} />
                </Col> */}
                <Col md={6} className="mb-3">
                  <label>Mobile Number</label>
                  <input
                    className="form-control"
                    name="contact_number_1"
                    value={customerInfo.contact_number_1}
                    onChange={(e) => {
                      let value = e.target.value

                      // Allow only digits and optional '+' at start
                      value = value.replace(/[^+\d]/g, '')

                      // Ensure only a single '+' at the start
                      if (value.indexOf('+') > 0) {
                        value = value.replace(/\+/g, '')
                      }

                      // Limit length (adjust as needed, e.g., +94770000000 -> 13)
                      if (value.length > 13) value = value.slice(0, 13)

                      setCustomerInfo((prev) => ({ ...prev, contact_number_1: value }))
                    }}
                    placeholder="+9477xxxxxxx"
                  />
                </Col>
              </Row>
              <div className="mt-auto d-flex justify-content-start gap-2">
                <Button variant="primary" onClick={handleSaveProfile} disabled={uploading || savingProfile}>
                  {savingProfile ? 'Saving…' : 'Save Profile'}
                </Button>{' '}
              </div>

              <CardTitle as="h5" className="mt-3 mb-3">
                Change Password
              </CardTitle>
              <Row>
                <Col md={4} className="mb-3">
                  <label>Password</label>
                  <div className="input-group">
                    <input
                      className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                      type={showPwd ? 'text' : 'password'}
                      value={pwd}
                      onChange={(e) => setPwd(e.target.value)}
                      placeholder="New password"
                    />
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={() => setShowPwd((s) => !s)}
                      aria-label={showPwd ? 'Hide password' : 'Show password'}>
                      <IconifyIcon icon={showPwd ? 'mdi:eye-off-outline' : 'mdi:eye-outline'} width={18} height={18} />
                    </button>
                    {errors.password && <div className="invalid-feedback">{errors.password}</div>}
                  </div>
                </Col>

                <Col md={4} className="mb-3">
                  <label>Confirm Password</label>
                  <div className="input-group">
                    <input
                      className={`form-control ${errors.confirm ? 'is-invalid' : ''}`}
                      type={showPwd2 ? 'text' : 'password'}
                      value={pwd2}
                      onChange={(e) => setPwd2(e.target.value)}
                      placeholder="Repeat new password"
                    />
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={() => setShowPwd2((s) => !s)}
                      aria-label={showPwd2 ? 'Hide confirm password' : 'Show confirm password'}>
                      <IconifyIcon icon={showPwd2 ? 'mdi:eye-off-outline' : 'mdi:eye-outline'} width={18} height={18} />
                    </button>
                    {errors.confirm && <div className="invalid-feedback">{errors.confirm}</div>}
                  </div>
                </Col>
              </Row>

              <div className="mt-auto d-flex justify-content-start gap-2">
                <Button variant="secondary" onClick={handleChangePassword} disabled={uploading || savingPassword}>
                  {savingPassword ? 'Saving…' : 'Change Password'}
                </Button>
              </div>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  )
}
