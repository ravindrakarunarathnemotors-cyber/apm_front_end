'use client'

import React, { useEffect, useRef, useState } from 'react'
import JsBarcode from 'jsbarcode'

const getFullUrl = (path) => {
  if (!path) return null
  if (path.startsWith('http')) return path
  return `https://yourdomain.com${path}`
}

const Labels4x4 = React.forwardRef(({ labelData = [] }, ref) => {
  const canvasRefs = useRef([])
  const [barcodeImages, setBarcodeImages] = useState([])

  useEffect(() => {
    const newBarcodes = []

    labelData.forEach((order, index) => {
      const canvas = canvasRefs.current[index]
      const trackingId = order?.order_details?.tracking_id

      if (canvas && trackingId) {
        try {
          JsBarcode(canvas, trackingId.toString(), {
            format: 'CODE128',
            lineColor: '#000',
            width: 2,
            height: 40,
            fontSize: 12,
            displayValue: false,
            margin: 0,
          })

          const dataURL = canvas.toDataURL('image/png', 0.7)
          newBarcodes[index] = dataURL
        } catch (err) {
          console.error(`❌ Barcode generation failed at index ${index}`, err)
          newBarcodes[index] = ''
        }
      }

      const brandLogo = getFullUrl(order?.order_details?.brand_logo)
      const partnerLogo = getFullUrl(order?.order_details?.delivery_partner_logo)

      if (brandLogo) new window.Image().src = brandLogo
      if (partnerLogo) new window.Image().src = partnerLogo
    })

    setBarcodeImages(newBarcodes)
  }, [labelData])

  return (
    <>
      <style>{`
  @page {
    size: 4in 4in;
    margin: 0;
  }

  html, body {
    margin: 0 !important;
    padding: 0 !important;
    box-sizing: border-box;
  }

  .page {
    width: 4in;
    height: 4in;
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    page-break-after: always;
  }

  .label-wrapper {
    padding-top: 12mm;
    padding-left: 12mm;
    width: 4in;
    height: 4in;
    box-sizing: border-box;
  }

  .label-4x4 {
    width: 100%;
    height: 100%;
    border: 2px solid black;
    padding: 10px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    font-size: 12px;
  }

  /* ======= Inner content styling (from A4 version) ======= */

  .top-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 10px;
  }

  .brand-logo-box {
    min-width: 90px;
    margin-top: 2mm;
    margin-left: 2mm;
    max-width: 110px;
    min-height: 45px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 12px;
  }

  .brand-logo-box img {
    max-height: 40px;
    max-width: 100%;
    object-fit: contain;
  }

  .top-details {
    display: flex;
    flex-direction: column;
    font-size: 13px;
    flex: 1;
    text-align: right;
  }

  .top-details div {
    margin-bottom: 2px;
  }

  .cod-box {
    border: 2px solid black;
    padding: 4px 8px;
    display: inline-block;
    margin-top: 4px;
    font-weight: bold;
    align-self: flex-end;
  }

  .section-divider {
    border-top: 1px solid #ccc;
    margin: 2px 0;
  }

  .address-block {
    font-size: 13px;
    line-height: 1.4;
    margin-bottom: 3px;
  }

  .address-block strong {
    font-weight: bold;
  }

  .footer-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 4px;
    margin-top: 0;
  }

  .partner-logo {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .img-logo {
    max-height: 40px;
    max-width: 100%;
    object-fit: contain;
  }

  .barcode-img {
    margin: -15px auto 2px;
    max-width: 120px;
    image-rendering: pixelated;
  }

  .barcode-value {
    font-size: 11px;
    text-align: center;
  }

  .hotline {
    text-align: center;
    font-weight: bold;
    font-size: 12px;
    margin-top: -4px;
  }

  .barcode {
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  canvas {
    display: none !important;
  }
`}</style>

      {labelData.map((order, index) => {
        const { order_details = {}, recipient_address = {}, recipient_contact_info = {}, customer_address = {} } = order
        const hasTrackingId = !!order_details.tracking_id

        return (
          <div className="page" key={index} ref={index === 0 ? ref : null}>
            <div className="label-wrapper">
              <div className="label-4x4">
                {/* Top Section */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div className="brand-logo" style={{ width: '40%' }}>
                    {order_details.brand_logo ? (
                      <img src={getFullUrl(order_details.brand_logo)} alt="Brand Logo" className="img-logo" />
                    ) : (
                      'brand_logo'
                    )}
                  </div>
                  <div style={{ width: '58%', textAlign: 'right', fontSize: '13px' }}>
                    <div>
                      <strong>Order ID:</strong> {order_details.order_id || 'N/A'}
                    </div>
                    {hasTrackingId && (
                      <div>
                        <strong>Tracking ID:</strong> {order_details.tracking_id}
                      </div>
                    )}
                    {order_details.cod === true && (
                      <div
                        style={{
                          marginTop: '4px',
                          border: '1px solid black',
                          padding: '4px 8px',
                          display: 'inline-block',
                          fontWeight: 'bold',
                          fontSize: '14px',
                        }}>
                        COD: {order_details.full_amount || '0.00'} ({order_details.currency || 'Rs.'})
                      </div>
                    )}
                  </div>
                </div>

                <div className="section-divider" />

                {/* To */}
                <div className="address-block">
                  <strong>To:</strong> {recipient_address.name || 'N/A'}
                  <br />
                  {recipient_address.address}
                  <br />
                  {recipient_address.city}, {recipient_address.country}
                  <br />
                  <strong>Contact:</strong> {recipient_contact_info.contact || 'N/A'}
                </div>

                <hr className="section-divider" />

                {/* From */}
                <div className="address-block">
                  <strong>From:</strong> {customer_address.name || 'N/A'}
                  <br />
                  {customer_address.address}
                  <br />
                  {customer_address.city}, {customer_address.country}
                </div>

                <div className="section-divider" />

                {/* Footer */}
                <div className="footer-section">
                  <div className="partner-logo">
                    {order_details.delivery_partner_logo ? (
                      <img src={getFullUrl(order_details.delivery_partner_logo)} alt="Partner Logo" className="img-logo" />
                    ) : (
                      'Delivery Partner'
                    )}
                  </div>

                  {hasTrackingId ? (
                    <div className="barcode">
                      {/* Always render canvas so JsBarcode can draw on it */}
                      <canvas ref={(el) => (canvasRefs.current[index] = el)} width={160} height={40} />
                      {barcodeImages[index] ? (
                        <>
                          <img className="barcode-img" src={barcodeImages[index]} alt="barcode" />
                          <div className="barcode-value">{order_details.tracking_id}</div>
                        </>
                      ) : (
                        <div style={{ textAlign: 'center', fontSize: '12px', color: '#555' }}>Generating…</div>
                      )}
                    </div>
                  ) : (
                    <div style={{ textAlign: 'center', fontSize: '12px', color: '#555' }}>No tracking ID found</div>
                  )}
                </div>

                <div className="hotline">Hotline: {order_details.delivery_partner_contact || '+94XXXXXXX'}</div>
              </div>
            </div>
          </div>
        )
      })}
    </>
  )
})

Labels4x4.displayName = 'Labels4x4'
export default Labels4x4
