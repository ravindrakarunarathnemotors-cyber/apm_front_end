'use client'

import React, { useEffect, useRef } from 'react'
import JsBarcode from 'jsbarcode'
import Image from 'next/image'

const LabelsA4 = React.forwardRef(({ labelData = [] }, ref) => {
  const canvasRefs = useRef([])

  useEffect(() => {
    labelData.forEach((order, index) => {
      const canvas = canvasRefs.current[index]
      const trackingId = order?.order_details?.tracking_id

      if (canvas && trackingId) {
        try {
          JsBarcode(canvas, trackingId.toString(), {
            format: 'CODE128',
            lineColor: '#000',
            width: 2,
            height: 40,
            fontSize: 12,
            displayValue: false,
            margin: 0,
          })

          const imgElem = document.getElementById(`barcode-img-${index}`)
          if (imgElem) {
            const dataURL = canvas.toDataURL('image/png', 0.7)
            imgElem.setAttribute('src', dataURL)
          }
        } catch (err) {
          console.error('Barcode generation error:', err)
        }
      }
    })
  }, [labelData])

  const groupIntoPages = (arr, size) => {
    const pages = []
    for (let i = 0; i < arr.length; i += size) {
      pages.push(arr.slice(i, i + size))
    }
    return pages
  }

  const paginatedLabels = groupIntoPages(labelData, 6)

  return (
    <>
      <style>{`
        @media print {
          @page {
            size: A4;
            margin: 0;
          }

          body {
            margin: 0;
            padding: 0;
          }

          canvas {
            display: none !important;
          }

          .barcode-img {
            display: block !important;
          }

          .page {
            width: 210mm;
            height: 297mm;
            padding: 10mm;
            box-sizing: border-box;
            display: flex;
            flex-wrap: wrap;
            gap: 5mm;
            page-break-after: always;
          }

          .shipping-label-print {
            width: calc((100% - 5mm) / 2);
            height: calc((100% - 10mm) / 3);
            border: 2px solid black;
            padding: 6px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            font-size: 13px;
            page-break-inside: avoid;
          }
        }

        @media screen {
          .page {
            width: 210mm;
            height: 297mm;
            padding: 10mm;
            box-sizing: border-box;
            display: flex;
            flex-wrap: wrap;
            gap: 5mm;
            background: #f9f9f9;
            border: 1px solid #ccc;
            margin: 20px auto;
          }

          .shipping-label-print {
            width: calc((100% - 5mm) / 2);
            height: calc((100% - 10mm) / 3);
            border: 2px solid black;
            padding: 6px;
            box-sizing: border-box;
            background: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }
        }

        .top-row {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 10px;
        }

        .brand-logo-box {
          min-width: 90px;
          margin-top: 2mm;
          margin-left: 2mm;
          max-width: 110px;
          min-height: 45px;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 12px;
        }

        .brand-logo-box img {
          max-height: 40px;
          max-width: 100%;
          object-fit: contain;
        }

        .top-details {
          display: flex;
          flex-direction: column;
          font-size: 13px;
          flex: 1;
          text-align: right;
        }

        .top-details div {
          margin-bottom: 2px;
        }

        .cod-box {
          border: 2px solid black;
          padding: 4px 8px;
          display: inline-block;
          margin-top: 4px;
          font-weight: bold;
          align-self: flex-end;
        }

        .section-divider {
          border-top: 1.5px solid #000;
          margin: 4px 0;
        }

        .soft-divider {
          border: none;
          border-top: 1px dashed #999;
          margin: 5px 0;
        }

        .address-block {
          font-size: 13px;
          line-height: 1.4;
          margin-bottom: 3px;
        }

        .address-block strong {
          font-weight: bold;
        }

        .footer-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 4px;
          border-top: 1.5px solid black;
          margin-top: 6px;
        }

        .footer-box {
          display: flex;
          justify-content: center;
          align-items: center;
          flex: 1;
        }

        .barcode-img {
          margin: -15px auto 2px;
          max-width: 120px;
          image-rendering: pixelated;
        }

        .barcode-text {
          font-size: 11px;
          text-align: center;
        }

        .hotline-center {
          font-weight: bold;
          font-size: 12px;
          text-align: center;
          margin-top: -4px;
        }
      `}</style>

      <div ref={ref}>
        {paginatedLabels.map((page, pageIndex) => (
          <div className="page" key={`page-${pageIndex}`}>
            {page.map((order, index) => {
              const { order_details = {}, recipient_address = {}, recipient_contact_info = {}, customer_address = {} } = order
              const hasTrackingId = !!order_details.tracking_id
              const globalIndex = pageIndex * 6 + index

              return (
                <div className="shipping-label-print" key={`label-${globalIndex}`}>
                  <div className="top-row">
                    <div className="brand-logo-box">
                      {order_details.brand_logo ? (
                        <img src={order_details.brand_logo} alt="Brand Logo" onError={(e) => (e.target.style.display = 'none')} />
                      ) : (
                        'Brand Logo'
                      )}
                    </div>
                    <div className="top-details">
                      <div>
                        <strong>Order ID:</strong> {order_details.order_id || 'N/A'}
                      </div>
                      {hasTrackingId && (
                        <div>
                          <strong>Tracking:</strong> {order_details.tracking_id}
                        </div>
                      )}
                      {(order_details.cod === true || order_details.payment_type === 'COD') && (
                        <div className="cod-box">
                          COD: {order_details.full_amount || '0.00'} ({order_details.currency || 'Rs.'})
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="section-divider" />

                  <div className="address-block">
                    <strong>To:</strong> {recipient_address.name || 'N/A'}
                    <br />
                    {recipient_address.address || ''}
                    <br />
                    {recipient_address.city || ''}, {recipient_address.country || ''}
                    <br />
                    <strong>Contact:</strong> {recipient_contact_info.contact || 'N/A'}
                  </div>

                  <hr className="soft-divider" />

                  <div className="address-block">
                    <strong>From:</strong> {customer_address.name || 'N/A'}
                    <br />
                    {customer_address.address || ''}
                    <br />
                    {customer_address.city || ''}, {customer_address.country || ''}
                  </div>

                  <div className="footer-row">
                    <div className="footer-box">
                      {order_details.delivery_partner_logo ? (
                        <Image src={order_details.delivery_partner_logo} alt="Partner Logo" width={60} height={30} unoptimized />
                      ) : (
                        'Partner Logo'
                      )}
                    </div>
                    <div className="footer-box" style={{ flexDirection: 'column' }}>
                      {hasTrackingId && (
                        <>
                          <canvas ref={(el) => (canvasRefs.current[globalIndex] = el)} width={160} height={40} />
                          <img id={`barcode-img-${globalIndex}`} className="barcode-img" alt="barcode" />
                          <div className="barcode-text">{order_details.tracking_id}</div>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="hotline-center">Hotline: {order_details.delivery_partner_contact || '+94XXXXXXX'}</div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    </>
  )
})

LabelsA4.displayName = 'LabelsA4'
export default LabelsA4
