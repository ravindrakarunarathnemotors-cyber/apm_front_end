'use client'

import React, { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Row, Table } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import { useGetFilteredMaterialInventoryMutation, useSearchProductVariantsQuery, useGetMaterialnameQuery, useGetActiveOutletsQuery } from '@/store/features/apiSlice'
import { Icon } from '@iconify/react'

function MaterialInventory() {
    const [productName, setProductName] = useState('')
    const [sortOrder, setSortOrder] = useState('desc')
    const [variantId, setVariantId] = useState('')
    const [variantName, setVariantName] = useState('')
    const [productId, setProductId] = useState('')
    const [searchProduct, setSearchProduct] = useState('')
    const [selectedProduct, setSelectedProduct] = useState(null)
    const [recipientName, setRecipientName] = useState('')
    const [productDate, setProductDate] = useState('')
    const [toDate, setToDate] = useState('')
    const [logs, setLogs] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)
    const logsPerPage = 10
    const [limit, setLimit] = useState(10)
    const [totalEntries, setTotalEntries] = useState(0)
    const printRef = useRef()
    const [searchRecipient, setSearchRecipient] = useState('')
    const [stockType, setStockType] = useState(null)
    const [outletId, setOutletId] = useState('')
    const [filters, setFilters] = useState({
        order_number: '',
        keyword: '',
        mobile: '',
        date: '',
    })
    const shouldSearch = searchProduct && searchProduct.trim().length >= 2

    const { data: productResults } = useSearchProductVariantsQuery(shouldSearch ? { query: searchProduct.trim() } : undefined)
    const { data, refetch: refetchOutlets } = useGetActiveOutletsQuery()
    const debouncedSearchProduct = React.useMemo(
        () =>
            debounce((value) => {
                setSearchProduct(value)
            }, 300),
        [],
    )

    useEffect(() => {
        return () => debouncedSearchProduct.cancel()
    }, [debouncedSearchProduct])

    const [fetchFilteredProducts, { isLoading }] = useGetFilteredMaterialInventoryMutation()
    const { data: RecipientResults } = useGetMaterialnameQuery(searchRecipient, {
        skip: searchRecipient.length < 2,
    })


    const outlets = data?.outlets || []

    const orderOptions =
        RecipientResults?.map((order) => ({
            label: `${order.name}`,
        })) || []

    const debouncedSearchRecipient = debounce((value) => {
        setSearchRecipient(value)
    }, 300)


    const fetchLogs = React.useCallback(
        async (page) => {
            setLoading(true);
            try {
                const res = await fetchFilteredProducts({
                    page,
                    keyword: recipientName, // ✅ this is correct
                    limit,
                    fromDate: productDate || null,
                    toDate: toDate || null,
                    material_id: selectedProduct?.value || null,
                    outlet_id: outletId || null,
                    stockType: stockType
                        ? stockType.replace("-", " ")
                        : null,
                }).unwrap();

                setLogs(res.data || []);
                setTotalPages(res.totalPages || 1);
                setCurrentPage(page);
                setTotalEntries(res.total || 0)

            } catch (err) {
                console.error("Failed to fetch inventory:", err);
            } finally {
                setLoading(false);
            }
        },
        [limit, productDate, toDate, selectedProduct, outletId, stockType, recipientName, fetchFilteredProducts] // ✅ FIXED HERE
    );

    // eslint-disable-next-line react-hooks/exhaustive-deps

    useEffect(() => {
    fetchLogs(currentPage)
}, [currentPage, limit])

    const showingFrom =
        totalEntries === 0
            ? 0
            : (currentPage - 1) * limit + 1

    const showingTo = Math.min(
        currentPage * limit,
        totalEntries
    )



    const handlePageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalPages) return
        setCurrentPage(pageNumber)
        fetchLogs(pageNumber)
    }

    const getPageWindow = (current, total, width = 5) => {
        const w = Math.max(1, width)
        const half = Math.floor(w / 2)

        let start = Math.max(1, current - half)
        let end = Math.min(total, start + w - 1)
        start = Math.max(1, end - w + 1)

        return Array.from({ length: end - start + 1 }, (_, i) => start + i)
    }

    const getPaginationRange = () => {
        const maxVisiblePages = 7
        let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
        let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(endPage - maxVisiblePages + 1, 1)
        }
        return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
    }
    const sortedLogs = [...logs].sort((a, b) => {
        return sortOrder === 'asc' ? a.inventory_id - b.inventory_id : b.inventory_id - a.inventory_id
    })
    const normalizedProducts = sortedLogs.map((p) => ({
        id: p.id,
        Material_Name: p.material_name,
        created_at: p.date,
        action: p.stock_type,
        by: p.by_name,
        module: p.module,
        outlet: p.outlet_name,
        previous_stock: p.prev_stock,
        adjust_stock: p.adjust_stock,
        new_stock: p.current_stock,

    }))

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML
        const newWindow = window.open('', '', 'width=900,height=650')
        newWindow.document.write(`
    <html>
      <head>
        <title>Inventory Report</title>
        <style>
          body { font-family: Arial; padding: 20px; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h2>Inventory Movement Report</h2>
        ${printContents}
      </body>
    </html>
  `)
        newWindow.document.close()
        newWindow.print()
    }

    // NEW: stock type options (single-select)
    const stockTypeOptions = [
        { value: 'stock-in', label: 'Stock In' },
        { value: 'stock-out', label: 'Stock Out' },
    ]

    return (
        <Row className="justify-content-center">
            <Col>
                <Card>
                    <CardHeader className="py-3 bg-light">
                        <Row className="align-items-center justify-content-between">
                            <Col>
                                <CardTitle as="h4" className="mb-0">
                                    Material Inventory
                                </CardTitle>
                            </Col>
                        </Row>
                    </CardHeader>

                    <CardBody>
                        <Form className="row g-2 mb-3">
                            <FormGroup className="col-md-2">
                                <FormLabel>Keyword</FormLabel>
                                <Select
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderRadius: '999px',
                                            borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                                            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                                        }),
                                    }}
                                    options={orderOptions}
                                    onInputChange={(value, { action }) => {
                                        if (action === 'input-change') {
                                            // Typing
                                            debouncedSearchRecipient(value)
                                            setSearchRecipient(value)
                                            setRecipientName(value)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: value,
                                            }))
                                        }
                                    }}
                                    onChange={(option) => {
                                        if (option) {
                                            const name = option.label?.split('(')[0].trim()
                                            setRecipientName(name)
                                            setSearchRecipient(name)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: name,
                                            }))
                                        } else {
                                            setRecipientName('')
                                            setSearchRecipient('')
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: '',
                                            }))
                                        }
                                    }}
                                    placeholder="ID, Raw Material Name"
                                    isClearable
                                    isSearchable
                                    value={recipientName ? { label: recipientName, value: recipientName } : null}
                                    components={{
                                        DropdownIndicator: null,
                                    }}
                                />
                            </FormGroup>
                            <FormGroup className="col-md-2">
                                <FormLabel>To Date</FormLabel>
                                <Form.Control type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />
                            </FormGroup>
                            <FormGroup className="col-md-2">
                                <FormLabel>From Date</FormLabel>
                                <Form.Control type="date" value={productDate} onChange={(e) => setProductDate(e.target.value)} />
                            </FormGroup>

                            <FormGroup className="col-md-2">
                                <FormLabel>Stock Type</FormLabel>
                                <Select
                                    options={stockTypeOptions}
                                    isClearable
                                    placeholder="All"
                                    value={stockTypeOptions.find((o) => o.value === stockType) || null}
                                    onChange={(opt) => setStockType(opt?.value ?? null)}
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderRadius: '999px',
                                            borderColor: state.isFocused ? 'var(--bs-primary)' : '#dee2e6', // same as Bootstrap input
                                            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                                        }),
                                    }}
                                />
                            </FormGroup>

                            <FormGroup className="col-md-2">
                                <FormLabel>Outlet</FormLabel>
                                <Form.Select
                                    value={outletId}
                                    onChange={(e) => setOutletId(e.target.value)}
                                >
                                    <option value="">All</option>
                                    {outlets?.map((outlet) => (
                                        <option key={outlet.outlet_id} value={outlet.outlet_id}>
                                            {outlet.name}
                                        </option>
                                    ))}
                                </Form.Select>
                            </FormGroup>

                            <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                                    Search
                                </Button>

                                <Button
                                    variant="secondary"
                                    onClick={handlePrint}
                                    style={{
                                        backgroundColor: '#6f42c1',
                                        borderColor: '#6f42c1',
                                    }}>
                                    Print
                                </Button>
                            </FormGroup>
                        </Form>

                        {isLoading || loading ? (
                            <p>Loading Inventory...</p>
                        ) : (
                            <>
                                <div ref={printRef}>
                                    <Table striped className="table mb-0">
                                        <thead className="table-light">
                                            <tr>
                                                <th>ID</th>
                                                <th>Date</th>
                                                <th>Material Name</th> {/* NEW COLUMN */}

                                                <th>Type</th>
                                                <th>By</th>
                                                <th>Module</th>
                                                <th>Outlet</th>
                                                <th className="text-end pe-2">Previous Stock</th>
                                                <th className="text-end pe-2">Adjusted Stock</th>
                                                <th className="text-end pe-2">New Stock</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {normalizedProducts.length === 0 ? (
                                                <tr>
                                                    <td colSpan="8" className="text-center">
                                                        No Inventory found.
                                                    </td>
                                                </tr>
                                            ) : (
                                                normalizedProducts.map((product) => (
                                                    <tr key={product.id}>
                                                        <td>{product.id}</td>

                                                        <td>{new Date(product.created_at).toLocaleDateString()}</td>
                                                        <td>{product.Material_Name}</td>
                                                        <td>
                                                            {product.action === 'stock in' ? (
                                                                <span className="d-inline-flex align-items-center gap-1" style={{ color: '#0d6efd' }}>
                                                                    <Icon icon="tabler:package-import" width={18} height={18} inline />
                                                                    <span>Stock In</span>
                                                                </span>
                                                            ) : product.action === 'stock out' ? (
                                                                <span className="d-inline-flex align-items-center gap-1" style={{ color: '#dc3545' }}>
                                                                    <Icon icon="tabler:package-export" width={18} height={18} inline />
                                                                    <span>Stock Out</span>
                                                                </span>
                                                            ) : (
                                                                product.action
                                                            )}
                                                        </td>
                                                        <td>{product.by}</td>
                                                        <td>{product.module}</td>
                                                        <td>{product.outlet}</td>
                                                        <td className="text-end pe-2">{product.previous_stock}</td>
                                                        <td className="text-end pe-2">{product.adjust_stock}</td>
                                                        <td className="text-end pe-2">
                                                            {product.new_stock}

                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </Table>
                                </div>

                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalEntries={totalEntries}
                                    limit={limit}
                                    showingFrom={showingFrom}
                                    showingTo={showingTo}
                                    onPageChange={(page) => {
                                        handlePageChange(page)
                                    }}
                                    onLimitChange={(newLimit) => {
                                        setLimit(newLimit)
                                        setCurrentPage(1)

                                    }}
                                />
                            </>
                        )}
                    </CardBody>
                </Card>
            </Col>
        </Row>
    )
}

export default MaterialInventory
