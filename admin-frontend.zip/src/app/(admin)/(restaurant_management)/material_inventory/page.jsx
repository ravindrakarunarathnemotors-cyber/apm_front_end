import React from 'react'
import MaterialInventory from './material_inventory'

export const metadata = {
  title: 'material_inventory',
}

const MaterialinventoryPage = () => {
  return (
    <div>
        <MaterialInventory />
    </div>
  )
}

export default MaterialinventoryPage