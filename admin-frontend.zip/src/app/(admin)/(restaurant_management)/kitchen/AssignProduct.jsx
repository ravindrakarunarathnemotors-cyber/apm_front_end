import React, { useState } from "react";
import Select from "react-select";
import axios from 'axios'
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import Swal from 'sweetalert2'
import useLogout from '@/hooks/useLogout'
import { Modal, Table, Button } from "react-bootstrap";
import axiosInstance from '@/lib/axiosInstance';

const AssignProduct = ({ open, setOpen, kitchen_id }) => {

    const [searchProducts, setSearchProducts] = useState([]);
    const [selectProduct, setSelectProduct] = useState(null);
    const [allProducts, setAllProducts] = useState([]);


    const [refreshtoken] = useRefreshTokenMutation()
    const { Logout } = useLogout()

    const handleClose = () => setOpen(false);

    if (!kitchen_id) return null;

    const getSearchResult = async (query) => {
        if (query.length < 2) return

        try {
            const response = await axiosInstance.get(
                `/restaurant/kitchen/getProductSearchkitchen?search=${query}`
            )

            if (response.status === 200) {
                const options = response.data.result.map(item => ({
                    value: item.product_id,
                    label: `${item.product_id} - ${item.name}`,
                    name: item.name
                }))
                setSearchProducts(options)
            }

        } catch (error) {
            console.error(error)
        }
    }

    const handleSelectProduct = (selected) => {

        setSelectProduct(null);

        if (!selected) return;

        const exists = allProducts.some(p => p.value === selected.value);

        if (exists) {
            Swal.fire("Already added", "", "warning");
            return;
        }

        setAllProducts(prev => [...prev, selected]);
    };

    const removeProduct = (id) => {
        setAllProducts(prev => prev.filter(p => p.value !== id));
    };

    const handleeAssign = async () => {

        if (allProducts.length === 0) {
            Swal.fire("Please add products first", "", "warning");
            return;
        }

        const product_ids = allProducts.map(p => p.value);

        try {

            const response = await axiosInstance.post(
                `/restaurant/kitchen/assignProducts`,
                {
                    kitchen_id,
                    product_ids
                },

            );

            if (response.status === 200) {

                Swal.fire("Products Assigned", "", "success");

                setAllProducts([]);
                setSelectProduct(null);
                setOpen(false);

            }

        } catch (error) {
            console.error(error)
        }
    };

    return (
        <Modal show={open} centered size="lg" backdrop="static" onHide={handleClose}>

            <Modal.Header closeButton>
                <Modal.Title>Assign Products</Modal.Title>
            </Modal.Header>

            <Modal.Body>

                <Select
                    options={searchProducts}
                    value={selectProduct}
                    onChange={handleSelectProduct}
                    onInputChange={(inputValue, actionMeta) => {
                        if (actionMeta.action === "input-change") {
                            getSearchResult(inputValue);
                        }
                    }}
                    placeholder="Search product..."
                    filterOption={() => true}
                    styles={{
                        control: (base, state) => ({
                            ...base,
                            minHeight: '38px',
                            borderRadius: '999px',
                            borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6',
                            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                        }),
                        menuPortal: (base) => ({
                            ...base,
                            zIndex: 9999,
                        }),
                        menu: (base) => ({
                            ...base,
                            zIndex: 9999,
                        }),
                    }}
                />

                <Table bordered hover className="mt-3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        {allProducts.map((p) => (
                            <tr key={p.value}>
                                <td>{p.value}</td>
                                <td>{p.name}</td>
                                <td>
                                    <Button
                                        variant="danger"
                                        size="sm"
                                        onClick={() => removeProduct(p.value)}
                                    >
                                        Remove
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>

            </Modal.Body>

            <Modal.Footer>

                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>

                <Button variant="primary" onClick={handleeAssign}>
                    Assign
                </Button>

            </Modal.Footer>

        </Modal>
    );
};

export default AssignProduct;