import React, { useEffect, useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { Modal, Table, Button } from "react-bootstrap";
import { useRefreshTokenMutation } from '@/store/features/apiSlice'
import useLogout from '@/hooks/useLogout'

const ViewProduct = ({ open, setOpen, kitchen_id }) => {

    const [products, setProducts] = useState([]);

    let token = ''
    if (typeof window !== 'undefined') {
        token = sessionStorage.getItem('access_token')
    }

    const [refreshtoken] = useRefreshTokenMutation()
    const { Logout } = useLogout()

    const handleClose = () => setOpen(false);

    useEffect(() => {
        if (open && kitchen_id) {
            fetchProducts();
        }
    }, [open]);

    const fetchProducts = async () => {

        try {

            const response = await axios.get(
                `${process.env.NEXT_PUBLIC_BASE_URL}/restaurant/kitchen/getKitchenProducts/${kitchen_id}`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );

            if (response.status === 200) {
                setProducts(response.data.result);
            }

        } catch (error) {
            if (error.response?.status === 401 || error.response?.status === 403) {
                const refreshToken = localStorage.getItem('refresh_token')
                if (refreshToken) {
                    try {
                        const response = await refreshtoken(refreshToken).unwrap()
                        sessionStorage.setItem('access_token', response.access_token)
                        token = response.access_token
                        return fetchProducts()
                    } catch (refreshError) {
                        Logout()
                    }
                } else {
                    Logout()
                }
            } else {
                console.error(error)
            }
        }

    };

    const removeProduct = async (product_id) => {

        const confirm = await Swal.fire({
            title: "Remove product?",
            icon: "warning",
            showCancelButton: true
        });

        if (!confirm.isConfirmed) return;

        try {

            const response = await axios.post(
                `${process.env.NEXT_PUBLIC_BASE_URL}/restaurant/kitchen/removeKitchenProduct`,
                {
                    kitchen_id,
                    product_id
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },

                }
            );

            if (response.status === 200) {

                Swal.fire("Removed", "", "success");

                setProducts(prev => prev.filter(p => p.product_id !== product_id));

            }

        } catch (error) {
            if (error.response?.status === 401 || error.response?.status === 403) {
                const refreshToken = localStorage.getItem('refresh_token')
                if (refreshToken) {
                    try {
                        const response = await refreshtoken(refreshToken).unwrap()
                        sessionStorage.setItem('access_token', response.access_token)
                        token = response.access_token
                        return removeProduct(product_id)
                    } catch (refreshError) {
                        Logout()
                    }
                } else {
                    Logout()
                }
            } else {
                console.error(error)
            }
        }

    };

    if (!kitchen_id) return null;

    return (
        <Modal show={open} centered size="lg" backdrop="static" onHide={handleClose}>

            <Modal.Header closeButton>
                <Modal.Title>Assigned Products</Modal.Title>
            </Modal.Header>

            <Modal.Body>

                <Table bordered hover>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product</th>
                            {/* <th>Status</th> */}
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                        {products.length === 0 && (
                            <tr>
                                <td colSpan="4" className="text-center">
                                    No products assigned
                                </td>
                            </tr>
                        )}

                        {products.map((p) => (
                            <tr key={p.product_id}>
                                <td>{p.product_id}</td>
                                <td>{p.title}</td>
                                {/* <td>{p.status}</td> */}
                                <td>
                                    <Button
                                        size="sm"
                                        variant="danger"
                                        onClick={() => removeProduct(p.product_id)}
                                    >
                                        Remove
                                    </Button>
                                </td>
                            </tr>
                        ))}

                    </tbody>
                </Table>

            </Modal.Body>

            <Modal.Footer>

                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>

            </Modal.Footer>

        </Modal>
    );
};

export default ViewProduct;