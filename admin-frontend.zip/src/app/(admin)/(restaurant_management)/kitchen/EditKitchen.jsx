'use client'

import React, { useState, useEffect } from 'react'
import { Button, Modal, Form, FormLabel, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import {
  useUpdateKitchenMutation,
  useGetActiveOutletsQuery,
  useGetActiveKotDisplayQuery,
  useGetActiveKotPrinterQuery
} from '@/store/features/apiSlice'

function EditKitchen({ show, onHide, kitchenData, onSuccess }) {
  console.log("kitchenData", kitchenData)
  const [form, setForm] = useState({
    name: '',
    display_id: '',
    kot_printer_id: '',
    outlet_id: '',
    status: 'Active',
  })

  const [updateKitchen, { isLoading }] = useUpdateKitchenMutation()

  const { data: outletData } = useGetActiveOutletsQuery()
  const { data: displayData } = useGetActiveKotDisplayQuery(
    kitchenData?.id,
    { skip: !kitchenData?.id }
  )

  const { data: printerData } = useGetActiveKotPrinterQuery(
    kitchenData?.id,
    { skip: !kitchenData?.id }
  )

  const outlets = outletData?.outlets || []
  const displays = displayData?.displays || []
  const printers = printerData?.printers || []

  /* ================= PREFILL ================= */
  // useEffect(() => {
  //   if (kitchenData && show) {
  //     setForm({
  //       name: kitchenData.name || '',
  //       display_id: kitchenData.display_id || '',
  //       kot_printer_id: kitchenData.kot_printer_id || '',
  //       outlet_id: kitchenData.outlet_id || '',
  //       status: kitchenData.status || 'Active',
  //     })
  //   }
  // }, [kitchenData, show])

  useEffect(() => {
    if (kitchenData && show) {
      setForm({
        name: kitchenData.name || '',
        display_id: kitchenData.display_id?.toString() || '',
        kot_printer_id: kitchenData.kot_printer_id?.toString() || '',
        outlet_id: kitchenData.outlet_id || '',
        status: kitchenData.status || 'Active',
      })
    }
  }, [kitchenData, show])

  /* ================= HANDLE CHANGE ================= */
  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  /* ================= SUBMIT ================= */
  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!form.name || !form.display_id || !form.outlet_id) {
      Swal.fire('Error', 'Please fill required fields', 'error')
      return
    }

    const result = await Swal.fire({
      title: 'Confirm Update',
      html: `
        <div style="text-align:left">
          <strong>Name:</strong> ${form.name}<br/>
          <strong>Outlet:</strong> ${form.outlet_id}<br/>
          <strong>KOT Display:</strong> ${form.display_id}<br/>
          <strong>KOT Printer:</strong> ${form.kot_printer_id || '-'}<br/>
          <strong>Status:</strong> ${form.status}
        </div>
      `,
      icon: 'info',
      showCancelButton: true,
      confirmButtonText: 'Update',
    })

    if (!result.isConfirmed) return

    try {
      await updateKitchen({
        id: kitchenData.id,
        ...form,
      }).unwrap()

      await Swal.fire('Success', 'Kitchen updated successfully', 'success')

      onSuccess && onSuccess()
      onHide()
    } catch (error) {
      console.error(error)
      Swal.fire('Error', 'Failed to update kitchen', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} centered backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>Edit Kitchen</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3">

            {/* NAME */}
            <Col md={6}>
              <FormLabel>Name</FormLabel>
              <Form.Control
                name="name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </Col>

            {/* OUTLET */}
            <Col md={6}>
              <FormLabel>Outlet</FormLabel>
              <Form.Select
                name="outlet_id"
                value={form.outlet_id}
                onChange={handleChange}
                required
              >
                <option value="">Select Outlet</option>
                {outlets.map((outlet) => (
                  <option key={outlet.outlet_id} value={outlet.outlet_id}>
                    {outlet.name}
                  </option>
                ))}
              </Form.Select>
            </Col>

            {/* KOT DISPLAY */}
            <Col md={6}>
              <FormLabel>KOT Display</FormLabel>
              <Form.Select
                name="display_id"
                value={form.display_id}
                onChange={handleChange}
                required
              >
                <option value="">Select KOT Display</option>
                {displays.map((display) => (
                  <option
                    key={display.device_id}
                    value={display.device_id.toString()}   // ✅ IMPORTANT
                  >
                    {display.till_name}
                  </option>
                ))}
              </Form.Select>
            </Col>

            {/* KOT PRINTER */}
            <Col md={6}>
              <FormLabel>KOT Printer</FormLabel>
              <Form.Select
                name="kot_printer_id"
                value={form.kot_printer_id}
                onChange={handleChange}
              >
                <option value="">Select KOT Printer</option>
                {printers.map((printer) => (
                  <option
                    key={printer.device_id}
                    value={printer.device_id.toString()}   // ✅ IMPORTANT
                  >
                    {printer.till_name}
                  </option>
                ))}
              </Form.Select>
            </Col>

            {/* STATUS */}
            <Col md={6}>
              <FormLabel>Status</FormLabel>
              <Form.Select
                name="status"
                value={form.status}
                onChange={handleChange}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </Form.Select>
            </Col>

          </Row>

          <div className="text-end mt-4">
            <Button variant="secondary" onClick={onHide} className="me-2">
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Updating...' : 'Update'}
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  )
}

export default EditKitchen