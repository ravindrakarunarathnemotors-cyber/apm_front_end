'use client'

import React, { useState } from 'react'
import { Button, Modal, Form, FormGroup, FormLabel, Row, Col } from 'react-bootstrap'
import Select from "react-select";
import Badge from "react-bootstrap/Badge";
import Swal from 'sweetalert2'
import { useCreateKitchenMutation, useGetActiveOutletsQuery, useGetActiveKotDisplaysQuery, useGetActiveKotPrintersQuery } from '@/store/features/apiSlice'

function AddKitchen({ show, onHide, onSuccess }) {

  const [form, setForm] = useState({
    name: '',
    display_id: '',
    outlet_id: '',
    status: 'Active',
  })

  const [createKitchen, { isLoading }] = useCreateKitchenMutation()
  const { data, refetch: refetchOutlets } = useGetActiveOutletsQuery()
  const { data: displayData, refetch: refetchDisplays } = useGetActiveKotDisplaysQuery()
  const { data: printerData, refetch: refetchPrinters } = useGetActiveKotPrintersQuery()

  const outlets = data?.outlets || []
  const displays = displayData?.displays || []
  const printers = printerData?.printers || []
  const displayOptions = displays.map((d) => ({
    value: d.device_id,
    label: d.till_name,
    status: d.usage_status,
    isDisabled: d.usage_status === "Used",
  }));
 
  const printerOptions = printers.map((p) => ({
    value: p.device_id,
    label: p.till_name,
    status: p.usage_status,
    isDisabled: p.usage_status === "Used",
  }));

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  // const handleSubmit = async (e) => {
  //   e.preventDefault()

  //   if (!form.name || !form.display_id || !form.outlet_id) {
  //     Swal.fire('Error', 'Please fill required fields', 'error')
  //     return
  //   }

  //   try {
  //     await createKitchen(form).unwrap()

  //     Swal.fire('Success', 'Kitchen created successfully', 'success')

  //     onSuccess && onSuccess()
  //     onHide()

  //     setForm({
  //       name: '',
  //       display_id: '',
  //       kot_printer_id: '',
  //       outlet_id: '',
  //       status: 'Active',
  //     })
  //   } catch (error) {
  //     Swal.fire('Error', 'Failed to create kitchen', 'error')
  //   }
  // }

  const handleSubmit = async (e) => {
  e.preventDefault()

  if (!form.name || !form.display_id || !form.outlet_id) {
    Swal.fire('Error', 'Please fill required fields', 'error')
    return
  }

  try {

    await createKitchen(form).unwrap()

    Swal.fire('Success', 'Kitchen created successfully', 'success')

    // reset form
    setForm({
      name: '',
      display_id: '',
      kot_printer_id: '',
      outlet_id: '',
      status: 'Active',
    })

    // refresh modal dropdown data
    refetchDisplays()
    refetchPrinters()
    refetchOutlets()

    // refresh parent kitchen list if needed
    onSuccess && onSuccess()

  } catch (error) {
    Swal.fire('Error', 'Failed to create kitchen', 'error')
  }
}

  return (
    <Modal show={show} onHide={onHide} centered backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>Add Kitchen</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3">

            <Col md={6}>
              <FormLabel>Name</FormLabel>
              <Form.Control
                name="name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </Col>
            <Col md={6}>
              <FormLabel>Outlet</FormLabel>
              <Form.Select
                name="outlet_id"
                value={form.outlet_id}
                onChange={handleChange}
                required
              >
                <option value="">Select Outlet</option>
                {outlets.map((outlet) => (
                  <option key={outlet.outlet_id} value={outlet.outlet_id}>
                    {outlet.name}
                  </option>
                ))}
              </Form.Select>
            </Col>

            <Col md={6}>
              <FormLabel>KOT Display</FormLabel>

              <Select
                options={displayOptions}
                placeholder="Select KOT Display"
                value={
                  displayOptions.find(
                    (option) => option.value === form.display_id
                  ) || null
                }
                onChange={(selected) =>
                  setForm((prev) => ({
                    ...prev,
                    display_id: selected?.value || "",
                  }))
                }
                formatOptionLabel={(option) => (
                  <div className="d-flex justify-content-between align-items-center w-100">
                    <span>{option.label}</span>

                    <Badge bg={option.status === "Used" ? "danger" : "success"}>
                      {option.status}
                    </Badge>
                  </div>
                )}
              />
            </Col>


            <Col md={6}>
              <FormLabel>KOT Printer</FormLabel>
              <Select
                options={printerOptions}
                placeholder="Select KOT Printer"
                value={
                  printerOptions.find(
                    (option) => option.value === form.kot_printer_id
                  ) || null
                }
                onChange={(selected) =>
                  setForm((prev) => ({
                    ...prev,
                    kot_printer_id: selected?.value || "",
                  }))
                }
                formatOptionLabel={(option) => (
                  <div className="d-flex justify-content-between align-items-center w-100">
                    <span>{option.label}</span>

                    <Badge bg={option.status === "Used" ? "danger" : "success"}>
                      {option.status}
                    </Badge>
                  </div>
                )}
              />
            </Col>


            <Col md={6}>
              <FormLabel>Status</FormLabel>
              <Form.Select
                name="status"
                value={form.status}
                onChange={handleChange}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </Form.Select>
            </Col>

          </Row>

          <div className="text-end mt-4">
            <Button variant="secondary" onClick={onHide} className="me-2">
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  )
}

export default AddKitchen