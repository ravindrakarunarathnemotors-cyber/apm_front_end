'use client'

import React, { useState, useEffect } from 'react'
import { Button, Modal, Form, FormGroup, FormLabel, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useUpdateRawMaterialMutation, useGetActiveMeasurementsQuery } from '@/store/features/apiSlice'

function EditRawMaterial({ show, onHide, rawMaterialData, onSuccess }) {
  const [form, setForm] = useState({
    name: '',
    reorder_level: '',
    measurement_unit: '',
    status: 'Active',
  })

  const [updateRawMaterial, { isLoading }] = useUpdateRawMaterialMutation()
  const { data: measurementUnits } = useGetActiveMeasurementsQuery()

  // Prefill form when modal opens or rawMaterialData changes
  useEffect(() => {
    if (rawMaterialData) {
      setForm({
        name: rawMaterialData.name || '',
        reorder_level: rawMaterialData.reorder_level || '',
        measurement_unit: rawMaterialData.measurement_unit || '',
        status: rawMaterialData.status || 'Active',
      })
    }
  }, [rawMaterialData])

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!form.name || !form.weight || !form.reorder_level || !form.measurement_unit) {
      Swal.fire('Error', 'Please fill in all required fields', 'error')
      return
    }

    try {
      await updateRawMaterial({ id: rawMaterialData.id, ...form }).unwrap()
      Swal.fire('Success', 'Raw material updated successfully', 'success')
      onSuccess && onSuccess()
      onHide()
    } catch (error) {
      console.error('Failed to update raw material:', error)
      Swal.fire('Error', 'Failed to update raw material', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} size="lg" backdrop="static" centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Raw Material</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3">
            <Col md={6}>
              <FormGroup>
                <FormLabel>Name</FormLabel>
                <Form.Control
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Enter material name"
                  required
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Reorder Level</FormLabel>
                <Form.Control
                  type="number"
                  name="reorder_level"
                  value={form.reorder_level}
                  onChange={handleChange}
                  placeholder="Enter reorder level"
                  required
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Measurement Unit</FormLabel>
                <Form.Select
                  name="measurement_unit"
                  value={form.measurement_unit}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      measurement_unit: e.target.value,
                    }))
                  }
                  required
                >
                  <option value="">Select Unit</option>
                  {measurementUnits?.map((unit) => (
                    <option
                      key={unit.measurement_id}
                      value={unit.measurement_id}
                    >
                      {unit.measurement_value}
                    </option>
                  ))}
                </Form.Select>
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Status</FormLabel>
                <Form.Select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </Form.Select>
              </FormGroup>
            </Col>
          </Row>

          <div className="mt-4 text-end">
            <Button variant="secondary" className="me-2" onClick={onHide}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={isLoading}>
              {isLoading ? 'Saving...' : 'Update'}
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  )
}

export default EditRawMaterial