'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table, Pagination } from 'react-bootstrap'
import Select from 'react-select'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import AddRawMaterial from './AddRawMaterial'
import EditRawMaterial from './EditRawMaterial'
import {
    useGetFilteredAllRawmaterialMutation,
    useToggleRawMaterialStatusMutation,
    useGetRawmaterialsnameQuery,
} from '@/store/features/apiSlice'

function RawmaterialList() {
    const [filters, setFilters] = useState({ keyword: '' })
    const [paymentStatus, setPaymentStatus] = useState('Active')
    const [date, setDate] = useState('')
    const [todate, setToDate] = useState('')
    const [logs, setLogs] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)
    const [searchRecipient, setSearchRecipient] = useState('')
    const [showAddModal, setShowAddModal] = useState(false)
    const [recipientName, setRecipientName] = useState('')
    const [showEditModal, setShowEditModal] = useState(false)
    const [selectedSupplier, setSelectedSupplier] = useState(null)
    const [showViewModal, setShowViewModal] = useState(false)
    const [selectedRawMaterial, setSelectedRawMaterial] = useState(null)


    const logsPerPage = 10
    const [fetchFilteredProducts, { isLoading }] = useGetFilteredAllRawmaterialMutation()
    const [toggleRawMaterialStatus] = useToggleRawMaterialStatusMutation()

    const { data: RecipientResults } = useGetRawmaterialsnameQuery(searchRecipient, {
        skip: searchRecipient.length < 2,
    })
    const orderOptions =
        RecipientResults?.map((order) => ({
            label: `${order.name}`,
        })) || []

    function getPageWindow(current, total, width = 5) {
        const w = Math.max(1, width)
        const half = Math.floor(w / 2)

        let start = Math.max(1, current - half)
        let end = Math.min(total, start + w - 1)
        start = Math.max(1, end - w + 1)

        return Array.from({ length: end - start + 1 }, (_, i) => start + i)
    }

    const debouncedSearchRecipient = debounce((value) => {
        setSearchRecipient(value)
    }, 300)

    const fetchLogs = async (page) => {
        setLoading(true)
        try {
            const res = await fetchFilteredProducts({
                page,
                limit: logsPerPage,
                keyword: filters.keyword,
                status: paymentStatus,
                todate: todate,
                date: date,


            }).unwrap()

            setLogs(res.raw_materials || [])
            setTotalPages(res.totalPages || 1)
            setCurrentPage(page)

        } catch (err) {
            console.error('Failed to fetch products:', err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchLogs(1)
    }, [])

    const handlePageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalPages) return
        setCurrentPage(pageNumber)
        fetchLogs(pageNumber)
    }

    const handleToggleStatus = async (id) => {
        const material = logs.find((m) => m.id === id)
        if (!material) return

        const newStatus =
            material.status === 'Active' ? 'Inactive' : 'Active'

        const result = await Swal.fire({
            title: `Confirm Status Change`,
            html: `
      Are you sure you want to 
      <strong>${newStatus}</strong> 
      the raw material <strong>${material.name}</strong>?
      <br/><br/>
    `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: `Yes, ${newStatus}`,
            cancelButtonText: 'Cancel',
            reverseButtons: true,
        })

        if (!result.isConfirmed) return

        try {
            await toggleRawMaterialStatus({
                id,
                status: newStatus,
            }).unwrap()

            Swal.fire('Success', 'Status updated successfully!', 'success')

            // Update UI instantly
            setLogs((prevLogs) =>
                prevLogs.map((m) =>
                    m.id === id
                        ? { ...m, status: newStatus }
                        : m
                )
            )
        } catch (error) {
            console.error('Failed to update status:', error)
            Swal.fire('Error', 'Failed to update status.', 'error')
        }
    }

    const getPaginationRange = () => {
        const maxVisiblePages = 7
        let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
        let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(endPage - maxVisiblePages + 1, 1)
        }
        return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
    }


    return (
        <Row className="justify-content-center">
            <Col>
                <Card>
                    <CardHeader
                        className="py-3 bg-light"
                    >
                        <Row className="align-items-center justify-content-between">
                            <Col>
                                <CardTitle as="h4" className="mb-0">
                                    Raw Material List
                                </CardTitle>
                            </Col>
                            <Col xs="auto">
                                <Button
                                    type="button"
                                    className="btn bg-primary border border-primary"
                                    onClick={() => setShowAddModal(true)}
                                >
                                    <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                                    Add Raw Material
                                </Button>


                            </Col>
                        </Row>
                    </CardHeader>
                    <CardBody>
                        <Form className="row g-3 mb-3">
                            <FormGroup className="col-md-4">
                                <FormLabel>Keyword</FormLabel>
                                <Select
                                    styles={{
                                        control: (base, state) => ({
                                            ...base,
                                            borderRadius: '999px',
                                            borderColor: state.isFocused ? 'var(--bs-primary)' : '#DEE2E6', // same as Bootstrap input
                                            boxShadow: state.isFocused ? '0 0 0 0.15rem rgba(var(--bs-primary-rgb), .25)' : 'none',
                                        }),
                                    }}
                                    options={orderOptions}
                                    onInputChange={(value, { action }) => {
                                        if (action === 'input-change') {
                                            // Typing
                                            debouncedSearchRecipient(value)
                                            setSearchRecipient(value)
                                            setRecipientName(value)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: value,
                                            }))
                                        }
                                    }}
                                    onChange={(option) => {
                                        if (option) {
                                            const name = option.label?.split('(')[0].trim()
                                            setRecipientName(name)
                                            setSearchRecipient(name)
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: name,
                                            }))
                                        } else {
                                            setRecipientName('')
                                            setSearchRecipient('')
                                            setFilters((prev) => ({
                                                ...prev,
                                                keyword: '',
                                            }))
                                        }
                                    }}
                                    placeholder="ID, Name"
                                    isClearable
                                    isSearchable
                                    value={recipientName ? { label: recipientName, value: recipientName } : null}
                                    components={{
                                        DropdownIndicator: null,
                                    }}
                                />
                            </FormGroup>
                            <FormGroup className="col-md-3">
                                <FormLabel>Status</FormLabel>
                                <Form.Select value={paymentStatus} onChange={(e) => setPaymentStatus(e.target.value)}>
                                    <option value="">All</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>

                                </Form.Select>
                            </FormGroup>
                            <FormGroup className="col-md-2 d-flex align-items-end gap-1">
                                <Button className="bg-primary border border-primary flex-grow-1" variant="primary" onClick={() => fetchLogs(1)}>
                                    Search
                                </Button>
                            </FormGroup>
                        </Form>

                        {isLoading || loading ? (
                            <p>Loading raw materials...</p>
                        ) : (
                            <>
                                <Table striped className="table mb-0">
                                    <thead className="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Reorder Level</th>
                                            <th>Measurement Unit</th>
                                            <th>Status</th>
                                            <th className="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {logs.length === 0 ? (
                                            <tr>
                                                <td colSpan="6" className="text-center">
                                                    No raw materials found.
                                                </td>
                                            </tr>
                                        ) : (
                                            logs.map((item) => (
                                                <tr key={item.id}>
                                                    <td>{item.id}</td>
                                                    <td>{item.name}</td>
                                                    <td>{item.reorder_level}</td>
                                                    <td>{item.measurement_value}</td>
                                                    <td>
                                                        <span
                                                            className={`badge ${item.status === 'Active'
                                                                ? 'bg-success'
                                                                : 'bg-danger'
                                                                }`}
                                                        >
                                                            {item.status}
                                                        </span>
                                                    </td>
                                                    <td className="text-end">
                                                        <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                                                            <Button
                                                                className="d-flex align-items-center justify-content-center"
                                                                style={{
                                                                    minWidth: 'auto',
                                                                    padding: '0.3rem 0.6rem',
                                                                    fontSize: '0.65rem',
                                                                    height: '30px',
                                                                    borderRadius: '15px',
                                                                    backgroundColor: '#fd7e14',
                                                                    borderColor: '#fd7e14',
                                                                    color: '#fff',
                                                                    flex: 1,
                                                                }}
                                                                onClick={() => {
                                                                    setSelectedRawMaterial(item)
                                                                    setShowEditModal(true)
                                                                }}
                                                            >
                                                                <IconifyIcon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                                                <span>Edit</span>
                                                            </Button>
                                                            <Button
                                                                className="d-flex align-items-center justify-content-center"
                                                                style={{
                                                                    minWidth: 'auto',
                                                                    padding: '0.3rem 0.6rem',
                                                                    fontSize: '0.65rem',
                                                                    height: '30px',
                                                                    borderRadius: '15px',
                                                                    color: '#fff',
                                                                    backgroundColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                                                    borderColor: item.status === 'active' ? '#28a745' : '#dc3545',
                                                                    flex: 1,
                                                                }}
                                                                onClick={() => handleToggleStatus(item.id)}
                                                                title={item.status === 'active' ? 'Set Inactive' : 'Set Active'}>
                                                                <IconifyIcon
                                                                    icon={item.status === 'active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                                                    style={{ fontSize: '20px', marginRight: '4px' }}
                                                                />
                                                                <span>{item.status === 'active' ? 'Active' : 'Inactive'}</span>
                                                            </Button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))
                                        )}
                                    </tbody>
                                </Table>
                                {totalPages > 1 && (
                                    <nav aria-label="Page navigation" className="mt-3 w-100">
                                        <ul className="pagination justify-content-end mb-0">
                                            <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                                                <button className="page-link" onClick={() => handlePageChange(Math.max(1, currentPage - 1))} disabled={currentPage === 1}>
                                                    Previous
                                                </button>
                                            </li>

                                            {getPageWindow(currentPage, totalPages, 5).map((page) => (
                                                <li key={page} className={`page-item ${page === currentPage ? 'active' : ''}`}>
                                                    <button className="page-link" onClick={() => handlePageChange(page)}>
                                                        {page}
                                                    </button>
                                                </li>
                                            ))}

                                            <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                                                <button
                                                    className="page-link"
                                                    onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                                                    disabled={currentPage === totalPages}>
                                                    Next
                                                </button>
                                            </li>
                                        </ul>
                                    </nav>
                                )}
                            </>
                        )}
                    </CardBody>

                    <EditRawMaterial
                        show={showEditModal}
                        onHide={() => setShowEditModal(false)}
                        rawMaterialData={selectedRawMaterial}
                        onSuccess={() => fetchLogs(currentPage)}
                    />

                    <AddRawMaterial
                        show={showAddModal}
                        onHide={() => setShowAddModal(false)}
                        onSuccess={() => fetchLogs(1)}
                    />
                </Card>
            </Col>
        </Row>
    )
}

export default RawmaterialList
