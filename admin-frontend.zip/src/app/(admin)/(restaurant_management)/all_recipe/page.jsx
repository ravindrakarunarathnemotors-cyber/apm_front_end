import React from 'react'
import AllRecipe from '@/components/RestaurantManagement/Recipe/AllRecipe'

export const metadata = {
  title: 'All Recipe',
}

const AllrecipePage = () => {
  return (
    <div>
       <AllRecipe />
    </div>
  )
}

export default AllrecipePage