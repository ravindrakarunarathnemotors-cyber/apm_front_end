import React from 'react'
import Recipe from '@/components/RestaurantManagement/Recipe/Recipe'

export const metadata = {
  title: 'Recipe',
}

const recipePage = () => {
  return (
    <div>
        <Recipe />
    </div>
  )
}

export default recipePage