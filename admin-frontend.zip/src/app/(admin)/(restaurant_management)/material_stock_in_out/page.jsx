import React from 'react'
import MaterialInventory from '@/components/RestaurantManagement/Inventory/MaterialInventory'

export const metadata = {
  title: 'material_inventory',
}

const MaterialinventoryPage = () => {
  return (
    <div>
        <MaterialInventory />
    </div>
  )
}

export default MaterialinventoryPage