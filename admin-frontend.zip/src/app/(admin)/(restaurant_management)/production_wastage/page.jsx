import React from 'react'
import ProductionWastage from '@/components/RestaurantManagement/Inventory/ProductionWastage'

const ProductionWastagePage = () => {
  return (
    <div>
        <ProductionWastage />
    </div>
  )
}

export default ProductionWastagePage