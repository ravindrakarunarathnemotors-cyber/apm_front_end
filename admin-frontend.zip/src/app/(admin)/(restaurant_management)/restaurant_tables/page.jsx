'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import { Icon } from '@iconify/react'
import IconifyIcon from '@/components/wrappers/IconifyIcon'
import EditRestaurent from './EditRestaurent'
import AddRestaurent from './AddRestaurent'
import {
    useGetFilteredAllRestauranttablesMutation,
    useToggleRestaurantStatusMutation,
    useGetRestauranttablesnamesQuery,
} from '@/store/features/apiSlice'

function RestaurantList() {
    const [filters, setFilters] = useState({ keyword: '' })
    const [paymentStatus, setPaymentStatus] = useState('Active')
    const [date, setDate] = useState('')
    const [todate, setToDate] = useState('')
    const [logs, setLogs] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)
    const [searchRecipient, setSearchRecipient] = useState('')
    const [showAddModal, setShowAddModal] = useState(false)
    const [recipientName, setRecipientName] = useState('')
    const [showEditModal, setShowEditModal] = useState(false)
    const [selectedSupplier, setSelectedSupplier] = useState(null)
    const [showViewModal, setShowViewModal] = useState(false)
    const [selectedRawMaterial, setSelectedRawMaterial] = useState(null)


    const [limit, setLimit] = useState(10)
    const [totalEntries, setTotalEntries] = useState(0)
    const [fetchFilteredProducts, { isLoading }] = useGetFilteredAllRestauranttablesMutation()
    const [toggleRawMaterialStatus] = useToggleRestaurantStatusMutation()

    const { data: RecipientResults } = useGetRestauranttablesnamesQuery(searchRecipient, {
        skip: searchRecipient.length < 2,
    })
    const orderOptions =
        RecipientResults?.map((order) => ({
            label: `${order.name}`,
        })) || []

    function getPageWindow(current, total, width = 5) {
        const w = Math.max(1, width)
        const half = Math.floor(w / 2)

        let start = Math.max(1, current - half)
        let end = Math.min(total, start + w - 1)
        start = Math.max(1, end - w + 1)

        return Array.from({ length: end - start + 1 }, (_, i) => start + i)
    }

    const debouncedSearchRecipient = debounce((value) => {
        setSearchRecipient(value)
    }, 300)

    const fetchLogs = async (page) => {
        setLoading(true)
        try {
            const res = await fetchFilteredProducts({
                page,
                limit,
                keyword: filters.keyword,
                status: paymentStatus,
                todate: todate,
                date: date,


            }).unwrap()

            setLogs(res.restaurant_tables || [])
            setTotalPages(res.totalPages || 1)
            setTotalEntries(res.total || 0)
            setCurrentPage(page)

        } catch (err) {
            console.error('Failed to fetch products:', err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchLogs(currentPage)
    }, [currentPage, limit])


    const handleLimitChange = (e) => {
        const newLimit = Number(e.target.value)

        setLimit(newLimit)
        setCurrentPage(1)

        fetchLogs(1)
    }

    const handlePageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalPages) return
        setCurrentPage(pageNumber)
        fetchLogs(pageNumber)
    }

    const handleToggleStatus = async (id) => {
        const material = logs.find((m) => m.id === id)
        if (!material) return

        const newStatus =
            material.status === 'Active' ? 'Inactive' : 'Active'

        const result = await Swal.fire({
            title: `Confirm Status Change`,
            html: `
      Are you sure you want to 
      <strong>${newStatus}</strong> 
      the restaurant name <strong>${material.name}</strong>?
      <br/><br/>
    `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: `Yes, ${newStatus}`,
            cancelButtonText: 'Cancel',
            reverseButtons: true,
        })

        if (!result.isConfirmed) return

        try {
            await toggleRawMaterialStatus({
                id,
                status: newStatus,
            }).unwrap()

            Swal.fire('Success', 'Status updated successfully!', 'success')

            // Update UI instantly
            setLogs((prevLogs) =>
                prevLogs.map((m) =>
                    m.id === id
                        ? { ...m, status: newStatus }
                        : m
                )
            )
        } catch (error) {
            console.error('Failed to update status:', error)
            Swal.fire('Error', 'Failed to update status.', 'error')
        }
    }

    const getPaginationRange = () => {
        const maxVisiblePages = 7
        let startPage = Math.max(currentPage - Math.floor(maxVisiblePages / 2), 1)
        let endPage = Math.min(startPage + maxVisiblePages - 1, totalPages)
        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(endPage - maxVisiblePages + 1, 1)
        }
        return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i)
    }


    return (
        <Row className="justify-content-center">
            <Col>
                <Card>
                    <CardHeader
                        className="py-3 bg-light"
                    >
                        <Row className="align-items-center justify-content-between">
                            <Col>
                                <CardTitle as="h4" className="mb-0">
                                    Restaurant Tables
                                </CardTitle>
                            </Col>
                            <Col xs="auto">
                                <Button
                                    type="button"
                                    className="btn bg-primary border border-primary"
                                    onClick={() => setShowAddModal(true)}
                                >
                                    <IconifyIcon icon="fa6-solid:plus" className="me-1" />
                                    Add Restaurant Tables
                                </Button>


                            </Col>
                        </Row>
                    </CardHeader>
                    <CardBody>
                        <div className="po-filter-bar mb-3">
                            <div className="row g-2 align-items-end">

                                {/* Keyword */}
                                <div className="col-12 col-sm-6 col-lg-4 col-xl-4">
                                    <div className="po-filter-label">Keyword</div>

                                    <Select
                                        styles={{
                                            control: (base, state) => ({
                                                ...base,
                                                minHeight: '36px',
                                                height: '36px',
                                                fontSize: '13px',
                                                borderRadius: '8px',
                                                borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                                                boxShadow: state.isFocused ? '0 0 0 3px rgba(13,110,253,.1)' : 'none',
                                            }),
                                            valueContainer: (b) => ({ ...b, padding: '0 10px' }),
                                            indicatorsContainer: (b) => ({ ...b, height: '36px' }),
                                            menu: (b) => ({ ...b, zIndex: 9999 }),
                                            menuPortal: (b) => ({ ...b, zIndex: 9999 }),
                                        }}
                                        options={orderOptions}
                                        onInputChange={(value, { action }) => {
                                            if (action === 'input-change') {
                                                debouncedSearchRecipient(value)
                                                setSearchRecipient(value)
                                                setRecipientName(value)
                                                setFilters((prev) => ({
                                                    ...prev,
                                                    keyword: value,
                                                }))
                                            }
                                        }}
                                        onChange={(option) => {
                                            if (option) {
                                                const name = option.label?.split('(')[0].trim()
                                                setRecipientName(name)
                                                setSearchRecipient(name)
                                                setFilters((prev) => ({
                                                    ...prev,
                                                    keyword: name,
                                                }))
                                            } else {
                                                setRecipientName('')
                                                setSearchRecipient('')
                                                setFilters((prev) => ({
                                                    ...prev,
                                                    keyword: '',
                                                }))
                                            }
                                        }}
                                        placeholder="ID, Name"
                                        isClearable
                                        isSearchable
                                        value={recipientName ? { label: recipientName, value: recipientName } : null}
                                        components={{ DropdownIndicator: null }}
                                    />
                                </div>

                                {/* Status */}
                                <div className="col-6 col-sm-3 col-lg-3 col-xl-3">
                                    <div className="po-filter-label">Status</div>

                                    <select
                                        className="form-select form-select-sm"
                                        value={paymentStatus}
                                        onChange={(e) => setPaymentStatus(e.target.value)}
                                    >
                                        <option value="">All</option>
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>

                                {/* Button */}
                                <div className="col-12 col-sm-3 col-lg-2 col-xl-2">
                                    <button
                                        className="btn btn-sm btn-dark w-100 d-flex align-items-center justify-content-center gap-2"
                                        onClick={() => fetchLogs(1)}
                                    >
                                        <Icon icon="mdi:magnify" width={16} />
                                        Search
                                    </button>
                                </div>

                            </div>
                        </div>

                        {isLoading || loading ? (
                            <p>Loading raw materials...</p>
                        ) : (
                            <>
                                <div className="table-responsive">
                                    <Table striped className="table mb-0">
                                        <thead className="table-light">
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Table Id</th>
                                                <th>Note</th>
                                                <th>Seats</th>
                                                <th>Outlet</th>
                                                <th>Status</th>
                                                <th className="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {logs.length === 0 ? (
                                                <tr>
                                                    <td colSpan="6" className="text-center">
                                                        No raw materials found.
                                                    </td>
                                                </tr>
                                            ) : (
                                                logs.map((item) => (
                                                    <tr key={item.id}>
                                                        <td>{item.id}</td>
                                                        <td>{item.name}</td>
                                                        <td>{item.table_id}</td>
                                                        <td>{item.note}</td>
                                                        <td>{item.seats}</td>
                                                        <td>{item.outlet_name}</td>
                                                        <td>
                                                            <span
                                                                className={`badge ${item.status === 'Active'
                                                                    ? 'bg-success'
                                                                    : 'bg-danger'
                                                                    }`}
                                                            >
                                                                {item.status}
                                                            </span>
                                                        </td>
                                                        <td className="text-end">
                                                            <div className="d-flex flex-row align-items-center justify-content-between gap-2">
                                                                <Button
                                                                    className="d-flex align-items-center justify-content-center"
                                                                    style={{
                                                                        minWidth: 'auto',
                                                                        padding: '0.3rem 0.6rem',
                                                                        fontSize: '0.65rem',
                                                                        height: '30px',
                                                                        borderRadius: '15px',
                                                                        backgroundColor: '#fd7e14',
                                                                        borderColor: '#fd7e14',
                                                                        color: '#fff',
                                                                        flex: 1,
                                                                    }}
                                                                    onClick={() => {
                                                                        setSelectedRawMaterial(item)
                                                                        setShowEditModal(true)
                                                                    }}
                                                                >
                                                                    <IconifyIcon icon="mdi:pencil" width={15} height={20} style={{ marginRight: '4px' }} />
                                                                    <span>Edit</span>
                                                                </Button>
                                                                <Button
                                                                    className="d-flex align-items-center justify-content-center"
                                                                    style={{
                                                                        minWidth: 'auto',
                                                                        padding: '0.3rem 0.6rem',
                                                                        fontSize: '0.65rem',
                                                                        height: '30px',
                                                                        borderRadius: '15px',
                                                                        color: '#fff',
                                                                        backgroundColor: item.status === 'Active' ? '#28a745' : '#dc3545',
                                                                        borderColor: item.status === 'Active' ? '#28a745' : '#dc3545',
                                                                        flex: 1,
                                                                    }}
                                                                    onClick={() => handleToggleStatus(item.id)}
                                                                    title={item.status === 'Active' ? 'Set Inactive' : 'Set Active'}>
                                                                    <IconifyIcon
                                                                        icon={item.status === 'Active' ? 'mdi:toggle-switch' : 'mdi:toggle-switch-off'}
                                                                        style={{ fontSize: '20px', marginRight: '4px' }}
                                                                    />
                                                                    <span>{item.status === 'Active' ? 'Active' : 'Inactive'}</span>
                                                                </Button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                        </tbody>
                                    </Table>
                                </div>
                                <Pagination
                                    currentPage={currentPage}
                                    totalPages={totalPages}
                                    totalEntries={totalEntries}
                                    limit={limit}
                                    onPageChange={(page) => handlePageChange(page)}
                                    onLimitChange={(val) => {
                                        setLimit(val)
                                        setCurrentPage(1)
                                        handleLimitChange(val)
                                    }}
                                    showingFrom={
                                        logs.length === 0 ? 0 : (currentPage - 1) * limit + 1
                                    }
                                    showingTo={
                                        logs.length === 0
                                            ? 0
                                            : (currentPage - 1) * limit + logs.length
                                    }
                                />
                            </>
                        )}
                    </CardBody>

                    <EditRestaurent
                        show={showEditModal}
                        onHide={() => setShowEditModal(false)}
                        rawMaterialData={selectedRawMaterial}
                        onSuccess={() => fetchLogs(currentPage)}
                    />

                    <AddRestaurent
                        show={showAddModal}
                        onHide={() => setShowAddModal(false)}
                        onSuccess={() => fetchLogs(1)}
                    />
                </Card>
            </Col>
        </Row>
    )
}

export default RestaurantList
