'use client'

import React, { useState } from 'react'
import { Button, Modal, Form, FormGroup, FormLabel, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { useCreateRestaurantMutation, useGetActiveOutletsQuery } from '@/store/features/apiSlice'

function AddRestaurent({ show, onHide, onSuccess }) {
    const [form, setForm] = useState({
        name: '',
        table_id: '',
        note: '',
        seats: '',
        outlet_id: '',
        status: 'Active',
    })

    const [createRestaurant, { isLoading }] = useCreateRestaurantMutation()
    const { data } = useGetActiveOutletsQuery()

    const outlets = data?.outlets || []
    const handleChange = (e) => {
        const { name, value } = e.target
        setForm((prev) => ({ ...prev, [name]: value }))
    }

    const handleSubmit = async (e) => {
        e.preventDefault()

        if (!form.name || !form.table_id || !form.seats) {
            Swal.fire('Error', 'Please fill required fields', 'error')
            return
        }

        try {
            await createRestaurant(form).unwrap()

            Swal.fire('Success', 'Restaurant table added successfully', 'success')

            onSuccess && onSuccess()
            onHide()

            setForm({
                name: '',
                table_id: '',
                note: '',
                seats: '',
                outlet_id: '',
                status: 'Active',
            })
        } catch (error) {
            console.error('Create failed:', error)
            Swal.fire('Error', 'Failed to create table', 'error')
        }
    }

    return (
        <Modal show={show} onHide={onHide} size="lg" backdrop="static" centered>
            <Modal.Header closeButton>
                <Modal.Title>Add Restaurant Table</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <Form onSubmit={handleSubmit}>
                    <Row className="g-3">

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Name</FormLabel>
                                <Form.Control
                                    type="text"
                                    name="name"
                                    value={form.name}
                                    onChange={handleChange}
                                    placeholder="Enter table name"
                                    required
                                />
                            </FormGroup>
                        </Col>

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Table ID</FormLabel>
                                <Form.Control
                                    type="text"
                                    name="table_id"
                                    value={form.table_id}
                                    onChange={handleChange}
                                    placeholder="Enter table ID"
                                    required
                                />
                            </FormGroup>
                        </Col>

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Outlet</FormLabel>
                                <Form.Select
                                    name="outlet_id"
                                    value={form.outlet_id}
                                    onChange={handleChange}
                                    required
                                >
                                    <option value="">Select Outlet</option>
                                    {outlets?.map((outlet) => (
                                        <option key={outlet.outlet_id} value={outlet.outlet_id}>
                                            {outlet.name}
                                        </option>
                                    ))}
                                </Form.Select>
                            </FormGroup>
                        </Col>

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Seats</FormLabel>
                                <Form.Control
                                    type="number"
                                    name="seats"
                                    value={form.seats}
                                    onChange={handleChange}
                                    placeholder="Enter seat count"
                                    required
                                />
                            </FormGroup>
                        </Col>

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Note</FormLabel>
                                <Form.Control
                                    type="text"
                                    name="note"
                                    value={form.note}
                                    onChange={handleChange}
                                    placeholder="Optional note"
                                />
                            </FormGroup>
                        </Col>

                        <Col md={6}>
                            <FormGroup>
                                <FormLabel>Status</FormLabel>
                                <Form.Select
                                    name="status"
                                    value={form.status}
                                    onChange={handleChange}
                                >
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </Form.Select>
                            </FormGroup>
                        </Col>

                    </Row>

                    <div className="mt-4 text-end">
                        <Button variant="secondary" className="me-2" onClick={onHide}>
                            Cancel
                        </Button>
                        <Button type="submit" variant="primary" disabled={isLoading}>
                            {isLoading ? 'Saving...' : 'Save'}
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    )
}

export default AddRestaurent