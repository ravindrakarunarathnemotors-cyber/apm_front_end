'use client'

import React, { useState, useEffect } from 'react'
import { Button, Modal, Form, FormGroup, FormLabel, Row, Col } from 'react-bootstrap'
import Swal from 'sweetalert2'
import { 
  useUpdateRestaurantMutation,
  useGetActiveOutletsQuery 
} from '@/store/features/apiSlice'

function EditRestaurent({ show, onHide, rawMaterialData, onSuccess }) {

  const [form, setForm] = useState({
    name: '',
    table_id: '',
    note: '',
    seats: '',
    outlet_id: '',
    status: 'Active',
  })

  const [updateRestaurant, { isLoading }] = useUpdateRestaurantMutation()

  // 🔥 Fetch outlets
  const { data } = useGetActiveOutletsQuery()

  // 🔥 Extract correct array from response
  const outlets = data?.outlets || []

  // ✅ Prefill when modal opens
  useEffect(() => {
    if (rawMaterialData && show) {
      setForm({
        name: rawMaterialData.name || '',
        table_id: rawMaterialData.table_id || '',
        note: rawMaterialData.note || '',
        seats: rawMaterialData.seats || '',
        outlet_id: rawMaterialData.outlet_id || '',
        status: rawMaterialData.status || 'Active',
      })
    }
  }, [rawMaterialData, show])

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!form.name || !form.table_id || !form.seats || !form.outlet_id) {
      Swal.fire('Error', 'Please fill required fields', 'error')
      return
    }

    try {
      await updateRestaurant({
        id: rawMaterialData.id,
        ...form,
      }).unwrap()

      Swal.fire('Success', 'Restaurant table updated successfully', 'success')

      onSuccess && onSuccess()
      onHide()
    } catch (error) {
      console.error('Update failed:', error)
      Swal.fire('Error', 'Failed to update table', 'error')
    }
  }

  return (
    <Modal show={show} onHide={onHide} size="lg" backdrop="static" centered>
      <Modal.Header closeButton>
        <Modal.Title>Edit Restaurant Table</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3">

            <Col md={6}>
              <FormGroup>
                <FormLabel>Name</FormLabel>
                <Form.Control
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Table ID</FormLabel>
                <Form.Control
                  type="text"
                  name="table_id"
                  value={form.table_id}
                  onChange={handleChange}
                  required
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Seats</FormLabel>
                <Form.Control
                  type="number"
                  name="seats"
                  value={form.seats}
                  onChange={handleChange}
                  required
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Outlet</FormLabel>
                <Form.Select
                  name="outlet_id"
                  value={form.outlet_id}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Outlet</option>
                  {outlets.map((outlet) => (
                    <option 
                      key={outlet.outlet_id} 
                      value={outlet.outlet_id}
                    >
                      {outlet.name}
                    </option>
                  ))}
                </Form.Select>
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Note</FormLabel>
                <Form.Control
                  type="text"
                  name="note"
                  value={form.note}
                  onChange={handleChange}
                />
              </FormGroup>
            </Col>

            <Col md={6}>
              <FormGroup>
                <FormLabel>Status</FormLabel>
                <Form.Select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </Form.Select>
              </FormGroup>
            </Col>

          </Row>

          <div className="mt-4 text-end">
            <Button variant="secondary" className="me-2" onClick={onHide}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={isLoading}>
              {isLoading ? 'Saving...' : 'Update'}
            </Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  )
}

export default EditRestaurent