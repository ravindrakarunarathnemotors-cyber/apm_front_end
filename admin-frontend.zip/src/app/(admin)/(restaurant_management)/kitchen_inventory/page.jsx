'use client'

import React, { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import { debounce } from 'lodash'
import Swal from 'sweetalert2'
import { Button, Card, CardHeader, CardBody, CardTitle, Col, Form, FormGroup, FormLabel, Image, Row, Table } from 'react-bootstrap'
import Pagination from '@/components/Pagination'
import Select from 'react-select'
import IngredientsStatus from '@/components/RestaurantManagement/product/Productdetails'
import IconifyIcon from '@/components/wrappers/IconifyIcon'

import {
    useGetFilteredAllKitcheinventoryMutation,
    useToggleKitchenStatusMutation,
    useGetModulenamesQuery,
    useGetActiveOutletsQuery,
    useGetMaterialnameQuery
} from '@/store/features/apiSlice'

import ProductListModal from '@/components/RestaurantManagement/Kitchen/ProductListModal'

function RawmaterialList() {
    const [filters, setFilters] = useState({ keyword: '' })
    const [stockStatus, setStockStatus] = useState('')
    const [date, setDate] = useState('')
    const [todate, setToDate] = useState('')
    const [productDate, setProductDate] = useState('')
    const [logs, setLogs] = useState([])
    const [loading, setLoading] = useState(false)
    const [currentPage, setCurrentPage] = useState(1)
    const [totalPages, setTotalPages] = useState(1)
    const [searchRecipient, setSearchRecipient] = useState('')
    const [recipientName, setRecipientName] = useState('')
    const [kitchen_id, setKitchen_id] = useState(null)
    const [showAssignModal, setShowAssignModal] = useState(false)
    const [viewOpen, setViewOpen] = useState(false)
    const [outletId, setOutletId] = useState("");
    const [limit, setLimit] = useState(10)
    const [totalEntries, setTotalEntries] = useState(0)
    const [fetchFilteredProducts, { isLoading }] = useGetFilteredAllKitcheinventoryMutation()
    const { data, refetch: refetchOutlets } = useGetActiveOutletsQuery()
    const [toggleRawMaterialStatus] = useToggleKitchenStatusMutation()

    const { data: RecipientResults } = useGetModulenamesQuery(searchRecipient, {
        skip: searchRecipient.length < 2,
    })
    const orderOptions =
        RecipientResults?.map((order) => ({
            label: `${order.module}`,
        })) || []

    const outlets = data?.outlets || []

    function getPageWindow(current, total, width = 5) {
        const w = Math.max(1, width)
        const half = Math.floor(w / 2)

        let start = Math.max(1, current - half)
        let end = Math.min(total, start + w - 1)
        start = Math.max(1, end - w + 1)

        return Array.from({ length: end - start + 1 }, (_, i) => start + i)
    }

    const debouncedSearchRecipient = debounce((value) => {
        setSearchRecipient(value)
    }, 300)

    const fetchLogs = async (page) => {
        setLoading(true)
        try {
            const res = await fetchFilteredProducts({
                page,
                limit,
                fromDate: productDate || null,
                toDate: todate || null,
                keyword: filters.keyword,
                stockType: stockStatus,
                outlet_id: outletId || null,



            }).unwrap()

            setLogs(res.kitchen_inventory || [])
            setTotalPages(res.totalPages || 1)
            setTotalEntries(res.total || 0)
            setCurrentPage(page)

        } catch (err) {
            console.error('Failed to fetch products:', err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchLogs(currentPage)
    }, [currentPage, limit])

    const handleLimitChange = (e) => {
        const newLimit = Number(e.target.value)

        setLimit(newLimit)
        setCurrentPage(1)

        fetchLogs(1)
    }

    const handlePageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalPages) return
        setCurrentPage(pageNumber)
        fetchLogs(pageNumber)
    }

    return (
        <>
            <Row className="justify-content-center">
                <Col>
                    <Card>
                        <CardHeader
                            className="py-3 bg-light"
                        >
                            <Row className="align-items-center justify-content-between">
                                <Col>
                                    <CardTitle as="h4" className="mb-0">
                                        Kitchen History
                                    </CardTitle>
                                </Col>
                            </Row>
                        </CardHeader>
                        <CardBody>
                            <div className="po-filter-bar mb-3">
                                <div className="row g-2 align-items-end">

                                    {/* Keyword */}
                                    <div className="col-12 col-sm-6 col-lg-4 col-xl-4">
                                        <div className="po-filter-label">Keyword</div>
                                        <Select
                                            styles={{
                                                control: (base, state) => ({
                                                    ...base,
                                                    minHeight: '36px',
                                                    height: '36px',
                                                    fontSize: '13px',
                                                    borderRadius: '8px',
                                                    borderColor: state.isFocused ? '#86b7fe' : '#dee2e6',
                                                    boxShadow: state.isFocused
                                                        ? '0 0 0 3px rgba(13,110,253,.1)'
                                                        : 'none',
                                                    background: '#fff',
                                                    transition: 'border-color .15s, box-shadow .15s',
                                                }),
                                                valueContainer: (b) => ({
                                                    ...b,
                                                    padding: '0 10px',
                                                }),
                                                indicatorsContainer: (b) => ({
                                                    ...b,
                                                    height: '36px',
                                                }),
                                                menu: (b) => ({
                                                    ...b,
                                                    zIndex: 9999,
                                                }),
                                                menuPortal: (b) => ({
                                                    ...b,
                                                    zIndex: 9999,
                                                }),
                                            }}
                                            menuPortal={typeof document !== 'undefined' ? document.body : null}
                                            menuPosition="fixed"
                                            options={orderOptions}
                                            onInputChange={(value, { action }) => {
                                                if (action === 'input-change') {
                                                    debouncedSearchRecipient(value)
                                                    setSearchRecipient(value)
                                                    setRecipientName(value)
                                                    setFilters((prev) => ({
                                                        ...prev,
                                                        keyword: value,
                                                    }))
                                                }
                                            }}
                                            onChange={(option) => {
                                                if (option) {
                                                    const name = option.label?.split('(')[0].trim()
                                                    setRecipientName(name)
                                                    setSearchRecipient(name)
                                                    setFilters((prev) => ({
                                                        ...prev,
                                                        keyword: name,
                                                    }))
                                                } else {
                                                    setRecipientName('')
                                                    setSearchRecipient('')
                                                    setFilters((prev) => ({
                                                        ...prev,
                                                        keyword: '',
                                                    }))
                                                }
                                            }}
                                            placeholder="ID, Module Name"
                                            isClearable
                                            isSearchable
                                            value={recipientName ? { label: recipientName, value: recipientName } : null}
                                            components={{ DropdownIndicator: null }}
                                        />
                                    </div>

                                    <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                                        <div className="po-filter-label">To Date</div>
                                        <input
                                            type="date"
                                            className="form-control form-control-sm"
                                            value={todate}
                                            onChange={(e) => setToDate(e.target.value)}
                                        />
                                    </div>

                                    {/* From Date */}
                                    <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                                        <div className="po-filter-label">From Date</div>
                                        <input
                                            type="date"
                                            className="form-control form-control-sm"
                                            value={productDate}
                                            onChange={(e) => setProductDate(e.target.value)}
                                        />
                                    </div>



                                    {/* Outlet */}
                                    <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                                        <div className="po-filter-label">Outlet</div>
                                        <select
                                            className="form-select form-select-sm"
                                            value={outletId}
                                            onChange={(e) => setOutletId(e.target.value)}
                                        >
                                            <option value="">All</option>
                                            {outlets?.map((outlet) => (
                                                <option key={outlet.outlet_id} value={outlet.outlet_id}>
                                                    {outlet.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>

                                    {/* Status */}
                                    <div className="col-12 col-sm-6 col-lg-3 col-xl-2">
                                        <div className="po-filter-label">Stock Type</div>
                                        <select
                                            className="form-select form-select-sm"
                                            value={stockStatus}
                                            onChange={(e) => setStockStatus(e.target.value)}
                                        >
                                            <option value="">All</option>
                                            <option value="in">Stock In</option>
                                            <option value="out">Stock Out</option>
                                        </select>
                                    </div>

                                    {/* Search Button */}
                                    <div className="col-12 col-sm-6 col-lg-2 col-xl-2">
                                        <div className="po-filter-label">&nbsp;</div>
                                        <button
                                            className="btn btn-dark btn-sm w-100 d-flex align-items-center justify-content-center gap-2"
                                            onClick={() => fetchLogs(1)}
                                        >
                                            Search
                                        </button>
                                    </div>

                                </div>
                            </div>

                            {isLoading || loading ? (
                                <p>Loading raw materials...</p>
                            ) : (
                                <>
                                    <div className="table-responsive">
                                        <Table striped className="table mb-0">
                                            <thead className="table-light">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Date</th>
                                                    <th>Material</th>
                                                    <th>Type</th>
                                                    <th>Kitchen</th>
                                                    <th>Outlet</th>
                                                    <th>Module</th>
                                                    <th>Note</th>
                                                    <th>Previous Stock</th>
                                                    <th>Adjusted Stock</th>
                                                    <th>Current Stock</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {logs.map((item) => (
                                                    <tr key={item.id}>
                                                        <td>{item.id}</td>
                                                        <td>
                                                            {new Date(item.date).toLocaleString()}
                                                        </td>
                                                        <td>{item.material_name}</td>
                                                        <td>
                                                            <span
                                                                className={`badge ${item.type === "in"
                                                                    ? "bg-success"
                                                                    : "bg-danger"
                                                                    }`}
                                                            >
                                                                {item.type.toUpperCase()}
                                                            </span>
                                                        </td>
                                                        <td>{item.kitchen_name}</td>
                                                        <td>{item.outlet_name}</td>
                                                        <td>{item.module}</td>
                                                        <td>{item.note}</td>
                                                        <td className="text-end">{item.prev_stock}</td>
                                                        <td className="text-end">{item.adjust_stock}</td>
                                                        <td className="text-end">{item.current_stock}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </Table>
                                    </div>
                                    <Pagination
                                        currentPage={currentPage}
                                        totalPages={totalPages}
                                        totalEntries={totalEntries}
                                        limit={limit}
                                        onPageChange={(page) => handlePageChange(page)}
                                        onLimitChange={(val) => {
                                            setLimit(val)
                                            setCurrentPage(1)
                                            handleLimitChange(val)
                                        }}
                                        showingFrom={
                                            logs.length === 0 ? 0 : (currentPage - 1) * limit + 1
                                        }
                                        showingTo={
                                            logs.length === 0
                                                ? 0
                                                : (currentPage - 1) * limit + logs.length
                                        }
                                    />
                                </>
                            )}
                        </CardBody>

                        


                    </Card>
                   
                </Col>
            </Row>

        </>
    )
}

export default RawmaterialList
