import React from 'react'
import IngredientsStatus from '@/components/RestaurantManagement/Inventory/IngredientsStatus'

export const metadata = {
  title: 'Ingredients Inventory',
}

const IngredientsInventory = () => {
  return (
    <div>
      <IngredientsStatus />
    </div>
  )
}

export default IngredientsInventory