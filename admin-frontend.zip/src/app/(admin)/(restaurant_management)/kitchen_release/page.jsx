import React from 'react'
import KitchenRelease from '@/components/RestaurantManagement/Kitchen/KitchenRelease'

export const metadata = {
  title: 'kitchen_release',
}

const MaterialinventoryPage = () => {
  return (
    <div>
       <KitchenRelease />
    </div>
  )
}

export default MaterialinventoryPage