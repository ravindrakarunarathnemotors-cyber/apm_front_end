const pool = require("../config/db");

//check phone validation
const formatPhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]+$/; // Ensure only numbers are allowed

  if (!phoneRegex.test(phone)) {
    return { error: "Invalid phone number. Only digits are allowed." };
  }

  if (phone.startsWith("07") && phone.length === 10) {
    return { formatted: "94" + phone.substring(1) }; // Convert 07xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("+94") && phone.length === 12) {
    return { formatted: phone.substring(1) }; // Remove "+" to make it 94xxxxxxxxxx
  } else if (phone.startsWith("7") && phone.length === 9) {
    return { formatted: "94" + phone }; // Convert 7xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("94") && phone.length === 11) {
    return { formatted: phone }; // Keep as is
  }

  return { error: "Invalid phone number format." };
};


// get outlet id
const getOutletId = async () => {
  const outletQuery = `SELECT outlet_id, merchant_id FROM sales_channel WHERE type = 'web'`

  const outletResult = await pool.query(outletQuery)

  if (outletResult.rows.length === 0) {
    throw new Error('Outlet not found')
  }

  return outletResult.rows[0]

};




const insertClientLog = async ( user_id, module, log) => {
  try {
    const query = `
      INSERT INTO logs (user_id, title, log, date) 
      VALUES ($1, $2, $3, NOW())`;
    
  const {rowCount} =  await pool.query(query, [user_id, module, log]);
  return rowCount
  
  } catch (error) {
    console.error("Error inserting user log:", error);
  }
}; 


const getCategoryIds = async (id) => {
  try {
    const allCategoryIds = [id]; // start with the given category
    const query = `SELECT category_under FROM categories WHERE category_id = $1`;

    // Step 1: get immediate parent
    const parentResult = await pool.query(query, [id]);
    if (!parentResult.rows.length || !parentResult.rows[0].category_under) {
      return allCategoryIds;
    }

    const parentId = parentResult.rows[0].category_under;
    allCategoryIds.push(parentId);

    // Step 2: get parent of parent (grandparent)
    const grandParentResult = await pool.query(query, [parentId]);
    if (!grandParentResult.rows.length || !grandParentResult.rows[0].category_under) {
      return allCategoryIds;
    }

    const grandParentId = grandParentResult.rows[0].category_under;
    allCategoryIds.push(grandParentId);

    // Step 3: (optional) stop here since you said 3 levels max
    return allCategoryIds;
  } catch (err) {
    console.error("Error fetching category hierarchy:", err);
    throw new Error("Failed to fetch category hierarchy");
  }
};

const collectionIDS = async (id) => {
  try {
    const query = `SELECT collection_id FROM product_collections WHERE product_id = $1`;
    const result = await pool.query(query, [id]);
    const collectionIds = result.rows.map((row) => row.collection_id);
    return collectionIds;
  } catch (err) {
    console.error("Error fetching collection IDs:", err);
    throw new Error("Failed to fetch collection IDs");
  }
};

const productBrandIds = async (id) => {
  try {
    const query = `SELECT brand_id FROM product_brands WHERE product_id = $1`;
    const result = await pool.query(query, [id]);
    const collectionIds = result.rows.map((row) => row.brand_id);
    return collectionIds;
  } catch (err) {
    console.error("Error fetching collection IDs:", err);
    throw new Error("Failed to fetch collection IDs");
  }
};

const checkguestDiscount = async () => {
  try {
    const query = `SELECT discount_id FROM discounts WHERE is_guest_allowed = true`;
    const result = await pool.query(query);
    return result.rows;
  } catch (err) {
    console.error("Error fetching collection IDs:", err);
    throw new Error("Failed to fetch collection IDs");
  }
};


module.exports = { formatPhoneNumber, getOutletId, insertClientLog, getCategoryIds, collectionIDS, productBrandIds, checkguestDiscount };