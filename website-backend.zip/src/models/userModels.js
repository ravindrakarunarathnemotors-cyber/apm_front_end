const pool = require("../config/db");
const bcrypt = require("bcrypt");
const saltRounds = 10;

class User {
    // Insert logs into teacher_logs table
    static async login(email, password) {
      try {
          const query = "SELECT * FROM admin_user WHERE username = $1";
          const { rows } = await pool.query(query, [email]);
  
          if (rows.length === 0) return { error: "No user found with this username" };
  
          const user = rows[0];
   
          // Verify password using bcrypt
          const isMatch = await bcrypt.compare(password, user.password);
          if (!isMatch) return { error: "Incorrect password" };
          // Remove password before returning user data
          delete user.password;
          return user;
      } catch (error) {
          throw new Error(`Login failed: ${error.message}`);
      }
  }
  
}

module.exports = User;
