const pool = require("../config/db");

const insertAdminLog = async ( user_id, module, log) => {
  try {
    const query = `
      INSERT INTO admin_log (user_id, module, log, date) 
      VALUES ($1, $2, $3, NOW())`;
    
    await pool.query(query, [user_id, module, log]);
    console.log(`User Log Added: ${module} - ${log}`);
  } catch (error) {
    console.error("Error inserting user log:", error);
  }
};

module.exports = {insertAdminLog};