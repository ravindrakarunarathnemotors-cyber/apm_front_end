const { query } = require("express-validator");
const pool = require("../config/db");
const { getOutletId, insertClientLog } = require("../models/commonQuery");
const { getCategory, productCount } = require("../common/common");
const { oneProductDiscount } = require("./DiscountController");

const getProduct = async (req, res) => {
  try {
    const {
      page,
      selectedCategoryId,
      priceValue,
      selectValue,
      status,
      collectionName,
    } = req.body;
    const pageSize = 12;

    const minPrice = priceValue[0];
    const maxPrice = priceValue[1];

    const offset = (page - 1) * pageSize;

    let params = [];

    let query = `
      WITH latest_inventory AS (
        SELECT DISTINCT ON (i.variant_id) 
              i.variant_id,
              i.new_quantity
        FROM inventory i
        ORDER BY i.variant_id, i.inventory_id DESC
      )
      SELECT 
        p.product_id,
        p.title AS product_name,
        c.category_id,
        c.name AS category_name,
        p.price,
        p.status,
        p.created_at,
        p.description,
        pm.media_url,
        COALESCE(om.other_media_urls, ARRAY[]::text[]) AS other_media_urls,
        COALESCE(SUM(COALESCE(li.new_quantity, 0)), 0) AS total_stock,
        COALESCE(BOOL_OR(pv.continue_selling_oos), FALSE) AS continue_selling_oos,
        CASE 
          WHEN EXISTS (
            SELECT 1
            FROM payment_methods pm
            WHERE pm.payment_method_id = 10
              AND pm.status = 'active'
          )
          THEN true 
          ELSE false 
        END AS koko
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN product_collections pco ON p.product_id = pco.product_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id 
          AND main = true 
          AND status = 'active' 
          AND variant_id IS NULL
        LIMIT 1
      ) pm ON true
      LEFT JOIN LATERAL (
        SELECT 
          COALESCE(
            ARRAY_AGG(pm2.media_url ORDER BY pm2.media_id),
            ARRAY[]::text[]
          ) AS other_media_urls
        FROM product_media pm2
        WHERE pm2.product_id = p.product_id
          AND pm2.status = 'active'
          AND NOT (pm2.main = true AND pm2.variant_id IS NULL)
          AND pm2.media_url <> pm.media_url
      ) om ON true
      LEFT JOIN product_variants pv 
        ON pv.product_id = p.product_id 
       AND pv.status = 'active'
      LEFT JOIN latest_inventory li 
        ON li.variant_id = pv.variant_id
      WHERE p.status = 'active' 
        AND p.publishing_online = true AND p.publish_to_web	= true
    `;

    // ✅ filter by stock status
    if (status) {
      const variantQuery = `
        SELECT variant_id
        FROM (
          SELECT DISTINCT ON (variant_id) *
          FROM inventory
          ORDER BY variant_id, last_updated DESC, inventory_id DESC
        ) t
        WHERE t.new_quantity > 0
      `;

      const varinatResult = await pool.query(variantQuery);
      const variantIds = varinatResult.rows.map((row) => row.variant_id);

      // ✅ If NO variants have stock → RETURN EMPTY
      if (variantIds.length === 0) {
        return res.status(200).json({
          message: "success",
          result: [],
          total: 0,
          allPages: 0,
        });
      }

      const productQuery = `
          SELECT product_id 
          FROM product_variants 
          WHERE variant_id = ANY($1::int[]) 
          GROUP BY product_id
        `;
      const productResult = await pool.query(productQuery, [variantIds]);
      const productIds = productResult.rows.map((row) => row.product_id);

      if (productIds.length > 0) {
        query += ` AND p.product_id = ANY($${params.length + 1}::int[])`;
        params.push(productIds);
      } else {
        // no matching products, return empty early
        return res
          .status(200)
          .json({ message: "success", result: [], total: 0, allPages: 0 });
      }
    }

    // ✅ category filter
    if (selectedCategoryId) {
      const allCategoryIds = await getCategory(selectedCategoryId);
      query += ` AND c.category_id = ANY($${params.length + 1}::int[])`;
      params.push(allCategoryIds);
    }

    // ✅ price filter
    if (maxPrice > 0) {
      query += ` AND p.price BETWEEN $${params.length + 1} AND $${params.length + 2
        }`;
      params.push(minPrice, maxPrice);
    }

    //collection
    if (collectionName) {
      query += ` AND pco.collection_id = $${params.length + 1}`;
      params.push(collectionName);
    }

    // ✅ group only by product-level fields
    query += `
      GROUP BY 
        p.product_id, 
        p.title, 
        c.category_id, 
        c.name, 
        p.price, 
        p.status, 
        p.created_at, 
        p.description, 
        pm.media_url,
        om.other_media_urls,
        koko
    `;

    // ✅ sorting
    if (selectValue) {
      switch (selectValue) {
        case "NewAdded":
          query += " ORDER BY p.created_at DESC";
          break;
        case "HightoLow":
          query += " ORDER BY p.price DESC";
          break;
        case "LowtoHigh":
          query += " ORDER BY p.price ASC";
          break;
        default:
          // query += " ORDER BY RANDOM()";
          query += " ORDER BY p.created_at DESC";
      }
    }

    // ✅ pagination
    query += ` LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(pageSize, offset);

    const [result, productCountResult] = await Promise.all([
      pool.query(query, params),
      productCount(
        selectedCategoryId,
        priceValue,
        selectValue,
        status,
        collectionName
      ),
    ]);

    const total = Number(productCountResult[0].total_count);
    const allPages = Math.ceil(total / pageSize);

    const allProducts = await Promise.all(
      result.rows.map(async (row) => {
        const discountResult = await oneProductDiscount(row);

        if (!discountResult.success) {
          // No discount available
          return {
            ...row,
            has_discount: false,
            discount_type: null,
            discount_id: null,
            discount_amount: 0,
            free_count: 0,
            buy_count: 0,
          };
        }

        // Discount FOUND
        return {
          ...row,
          has_discount: true,
          discount_type: discountResult.type,
          discount_id: discountResult.discount_id,
          discount_amount: discountResult.total_discount_value,

          // Only filled for buyxgety, otherwise 0
          free_count: discountResult.free_count ?? 0,
          buy_count: discountResult.buy_count ?? 0,
        };
      })
    );

    return res.status(200).json({
      message: "success",
      result: allProducts,
      total,
      allPages,
      allProducts,
    });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const getAllProduct = async (req, res) => {
  try {
    const { page, selectedCategoryId, priceValue, selectValue, status } =
      req.body;
    const pageSize = 12;
    const minPrice = priceValue[0];
    const maxPrice = priceValue[1];
    let params = [];

    let query = `
      WITH latest_inventory AS (
        SELECT DISTINCT ON (i.variant_id) 
              i.variant_id,
              i.new_quantity
        FROM inventory i
        ORDER BY i.variant_id, i.inventory_id DESC
      )
      SELECT 
        p.product_id,
        p.title AS product_name,
        c.category_id,
        c.name AS category_name,
        p.price,
        p.status,
        p.created_at,
        p.description,
        pm.media_url,
        COALESCE(SUM(COALESCE(li.new_quantity, 0)), 0) AS total_stock,
        COALESCE(BOOL_OR(pv.continue_selling_oos), FALSE) AS continue_selling_oos
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id 
          AND main = true 
          AND status = 'active' 
          AND variant_id IS NULL
        LIMIT 1
      ) pm ON true
      LEFT JOIN product_variants pv 
        ON pv.product_id = p.product_id 
       AND pv.status = 'active'
      LEFT JOIN latest_inventory li 
        ON li.variant_id = pv.variant_id
      WHERE p.status = 'active' 
        AND p.publishing_online = true
    `;

    // ✅ filter by stock status
    if (status) {
      const variantQuery = `
        SELECT variant_id
        FROM (
          SELECT DISTINCT ON (variant_id) *
          FROM inventory
          ORDER BY variant_id, last_updated DESC, inventory_id DESC
        ) t
        WHERE t.new_quantity > 0
      `;

      const varinatResult = await pool.query(variantQuery);
      const variantIds = varinatResult.rows.map((row) => row.variant_id);

      // ✅ If NO variants have stock → RETURN EMPTY
      if (variantIds.length === 0) {
        return res.status(200).json({
          message: "success",
          result: [],
          total: 0,
          allPages: 0,
        });
      }

      const productQuery = `
          SELECT product_id 
          FROM product_variants 
          WHERE variant_id = ANY($1::int[]) 
          GROUP BY product_id
        `;
      const productResult = await pool.query(productQuery, [variantIds]);
      const productIds = productResult.rows.map((row) => row.product_id);

      if (productIds.length > 0) {
        query += ` AND p.product_id = ANY($${params.length + 1}::int[])`;
        params.push(productIds);
      } else {
        // no matching products, return empty early
        return res
          .status(200)
          .json({ message: "success", result: [], total: 0, allPages: 0 });
      }
    }

    // ✅ category filter
    if (selectedCategoryId) {
      const allCategoryIds = await getCategory(selectedCategoryId);
      query += ` AND c.category_id = ANY($${params.length + 1}::int[])`;
      params.push(allCategoryIds);
    }

    // ✅ price filter
    if (maxPrice > 0) {
      query += ` AND p.price BETWEEN $${params.length + 1} AND $${params.length + 2
        }`;
      params.push(minPrice, maxPrice);
    }

    // ✅ group only by product-level fields
    query += `
      GROUP BY 
        p.product_id, 
        p.title, 
        c.category_id, 
        c.name, 
        p.price, 
        p.status, 
        p.created_at, 
        p.description, 
        pm.media_url
    `;

    // ✅ sorting
    if (selectValue) {
      switch (selectValue) {
        case "NewAdded":
          query += " ORDER BY p.created_at DESC";
          break;
        case "HightoLow":
          query += " ORDER BY p.price DESC";
          break;
        case "LowtoHigh":
          query += " ORDER BY p.price ASC";
          break;
        default:
          query += " ORDER BY p.created_at DESC";
      }
    }

    // ✅ pagination
    const [result, productCountResult] = await Promise.all([
      pool.query(query, params),
      productCount(selectedCategoryId, priceValue, selectValue, status),
    ]);

    const total = Number(productCountResult[0].total_count);
    const allPages = Math.ceil(total / pageSize);

    const allProducts = await Promise.all(
      result.rows.map(async (row) => {
        const discountResult = await oneProductDiscount(row);

        if (!discountResult.success) {
          // No discount available
          return {
            ...row,
            has_discount: false,
            discount_type: null,
            discount_id: null,
            discount_amount: 0,
            free_count: 0,
            buy_count: 0,
          };
        }

        // Discount FOUND
        return {
          ...row,
          has_discount: true,
          discount_type: discountResult.type,
          discount_id: discountResult.discount_id,
          discount_amount: discountResult.total_discount_value,

          // Only filled for buyxgety, otherwise 0
          free_count: discountResult.free_count ?? 0,
          buy_count: discountResult.buy_count ?? 0,
        };
      })
    );

    return res.status(200).json({
      message: "success",
      result: result.rows,
      total,
      allPages,
      allProducts,
    });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const geSearchProduct = async (req, res) => {
  try {
    const { searchText } = req.query;
    console.log(searchText);
    const query = `
      SELECT 
        p.product_id as _id,
        p.title,
        c.category_id,
        c.name AS category_name,
        p.price,
        p.status,
        p.created_at,
        p.description,
        pm.media_url as img
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN product_variants pv ON p.product_id = pv.product_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id AND main = true
        LIMIT 1
      ) pm ON true
      WHERE p.status = 'active' AND p.publishing_online = true AND p.publish_to_web	= true AND (p.title ILIKE $1 OR p.product_id::text ILIKE $1 OR pv.variant_id::text ILIKE $1)
      ORDER BY p.created_at DESC
      `;
    const result = await pool.query(query, [`%${searchText}%`]);

    return res.status(200).json({ message: "success", data: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const getProductById = async (req, res) => {
  const { product_id } = req.body;
  try {
    const query = `SELECT 
        p.product_id,
        p.title,
        p.price,
        p.status,
        p.compare_at_price,
        p.description,
        p.type,
        p.amount_per_unit,
        p.measurement_id,
        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
        m.measurement_value,
        pm.media_url,
        COALESCE(col.collection_ids, '{}'::int[]) AS collection_ids,
        pca.category_id,
        COALESCE(oi.other_images, '[]'::jsonb) AS other_images
      FROM products p
      LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.status = 'active' AND pm.variant_id IS NULL
      LEFT JOIN product_category pca ON p.product_id = pca.product_id
      LEFT JOIN measurements m ON p.measurement_id	= m.measurement_id
      LEFT JOIN LATERAL (
        SELECT ARRAY_AGG(DISTINCT collection_id) AS collection_ids
        FROM   product_collections
        WHERE  product_id = p.product_id
        ) col ON TRUE
      LEFT JOIN LATERAL (
        SELECT jsonb_agg(
                jsonb_build_object(
                    'media_id',   media_id,
                    'variant_id', variant_id,
                    'media_url',        media_url,
                    'main',      main
                )
                ORDER BY media_id
                ) AS other_images
        FROM   product_media
        WHERE  product_id = p.product_id
             AND status = 'active'
        ) oi ON TRUE
      WHERE p.product_id = $1 AND p.status = 'active'
      `;

    const result = await pool.query(query, [product_id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Product not found" });
    }
    return res.status(200).json({ message: "success", result: result.rows[0] });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const getProductVariant = async (req, res) => {
  const { product_id } = req.body;

  try {
    //first get outlet id
    const outletQuery = `SELECT outlet_id FROM sales_channel WHERE type = 'web'`;

    const outletResult = await pool.query(outletQuery);
    const outlet_id = outletResult.rows[0].outlet_id;

    const query = `
           
            SELECT
                pv.variant_type,
                pv.variant_value,
                pv.sku,
                pv.barcode,
                pv.price,
                pv.track_quantity,
                pv.shop_location_selling,
                pv.continue_selling_oos,
                pv.weight,
                pv.weight_unit,
                pv.created_at,
                pv.product_id,
                pv.variant_id,
                pv.system_barcode,
                COALESCE(inv.new_quantity,0) AS current_quantity
            FROM product_variants pv

           
            LEFT JOIN LATERAL (
                SELECT  i.new_quantity
                FROM    inventory i
                WHERE   i.variant_id = pv.variant_id
                    AND  i.outlet_id  = $2 
                    AND  i.status     = 'active'
                ORDER BY i.inventory_id	 DESC 
                LIMIT 1
            ) inv ON TRUE

            WHERE pv.product_id = $1 AND pv.status     = 'active';
            `;

    const { rows } = await pool.query(query, [product_id, outlet_id]);
    return res.status(200).json({ message: "success", result: rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

// all product category
const getProductCategory = async (req, res) => {
  try {
    const query = `SELECT c.category_id, c.name , c.category_under, c.mobile_url,c.desktop_url
        FROM categories c
        WHERE c.status = 'active' AND c.show_on_main_menu = true`;

    const result = await pool.query(query);

    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};
const getProductCollection = async (req, res) => {
  try {
    const query = `SELECT c.collection_id, c.name
        FROM collections c
        WHERE c.status = 'active'`;

    const result = await pool.query(query);

    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

// GET selected products for a section
const getFeaturesProducts = async (req, res) => {
  const { sectionId, merchantId } = req.body;

  try {
    const cfgSql = `
      SELECT config
      FROM site_section_configs
      WHERE template_section_id = $1
        AND enabled = true
        ${merchantId ? "AND merchant_id = $2" : ""}
      ORDER BY sort_order
      LIMIT 1
    `;
    const cfgParams = merchantId ? [sectionId, merchantId] : [sectionId];
    const cfgRes = await pool.query(cfgSql, cfgParams);

    if (cfgRes.rowCount === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    const config = cfgRes.rows[0].config || {};
    const ids = Array.isArray(config.selected_product_ids)
      ? config.selected_product_ids.map(Number).filter(Boolean)
      : [];

    if (ids.length === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    const limit = Number(config.limit) > 0 ? Number(config.limit) : ids.length;

    const prodSql = `
      SELECT
        p.product_id,
        p.title,
        p.price,
        p.search_engine_desc,
        COALESCE(pm.media_url, NULL) AS media_url
      FROM products p
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
          AND (status = 'active' AND variant_id IS NULL)
        ORDER BY CASE WHEN main THEN 0 ELSE 1 END, media_id
        LIMIT 1
      ) pm ON TRUE
      WHERE p.product_id = ANY($1::int[])
        AND p.publishing_online = true
      ORDER BY array_position($1::int[], p.product_id)
      LIMIT $2
    `;
    const { rows } = await pool.query(prodSql, [ids, limit]);

    return res.status(200).json({
      message: "success",
      result: rows,
      // optional: echo config if you want to use on FE
      // config,
    });
  } catch (err) {
    console.error("Error fetching featured products by section:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
};

const getBestSellingProducts = async (req, res) => {
  const { sectionId } = req.body;

  try {
    const cfgSql = `
      SELECT config
      FROM site_section_configs
      WHERE template_section_id = $1
        AND enabled = true
      ORDER BY sort_order
      LIMIT 1
    `;
    const cfgParams = [sectionId];
    const cfgRes = await pool.query(cfgSql, cfgParams);

    if (cfgRes.rowCount === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    const raw = cfgRes.rows[0].config;
    const config = typeof raw === "string" ? JSON.parse(raw) : raw || {};

    // selected IDs from config
    const ids = Array.isArray(config.selected_product_ids)
      ? config.selected_product_ids
        .map((n) => Number(n))
        .filter(Number.isFinite)
      : [];

    if (ids.length === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    // limit: use config value, clamp to 1..8 and to available ids
    const configured = Number(config.limit) || 8;
    const limit = Math.min(8, Math.max(1, configured), ids.length);

    // 2) fetch products in the same order as selected_product_ids
    const prodSql = `
      SELECT
        p.product_id,
        p.title,
        p.price,
        pm.media_url,
         c.category_id
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
          AND status = 'active'
        ORDER BY 
        CASE 
          WHEN main = true AND variant_id IS NULL THEN 0   -- product main
          WHEN main = false AND variant_id IS NULL THEN 1  -- product non-main
          WHEN main = true AND variant_id IS NOT NULL THEN 2  -- variant main
          ELSE 3  -- variant non-main
        END,
        media_id
        LIMIT 1
      ) pm ON TRUE
      WHERE p.publishing_online = true
        AND p.product_id = ANY($1::int[])
      ORDER BY array_position($1::int[], p.product_id)
      LIMIT $2
    `;
    const { rows } = await pool.query(prodSql, [ids, limit]);
    const allProducts = await Promise.all(
      rows.map(async (row) => {
        const discountResult = await oneProductDiscount(row);

        if (!discountResult.success) {
          // No discount available
          return {
            ...row,
            has_discount: false,
            discount_type: null,
            discount_id: null,
            discount_amount: 0,
            free_count: 0,
            buy_count: 0,
          };
        }

        // Discount FOUND
        return {
          ...row,
          has_discount: true,
          discount_type: discountResult.type,
          discount_id: discountResult.discount_id,
          discount_amount: discountResult.total_discount_value,

          // Only filled for buyxgety, otherwise 0
          free_count: discountResult.free_count ?? 0,
          buy_count: discountResult.buy_count ?? 0,
        };
      })
    );
    return res.status(200).json({ message: "success", result: allProducts });
  } catch (err) {
    console.error("Error fetching best selling products:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
};

const getprodcutWithcolection = async (req, res) => {
  const { sectionId } = req.body;

  console.log("sectionId", req.body);
  try {
    const cfgSql = `
      SELECT config
      FROM site_section_configs
      WHERE template_section_id = $1
        AND enabled = true
      ORDER BY sort_order
      LIMIT 1
    `;

    const cfgRes = await pool.query(cfgSql, [sectionId]);

    if (cfgRes.rowCount === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    const raw = cfgRes.rows[0].config;
    const config = typeof raw === "string" ? JSON.parse(raw) : raw || {};

    console.log(config.groups);
    const groupResult = config.groups || [];

    if (groupResult.length === 0) {
      return res.status(200).json({ message: "success", result: [] });
    }

    const allResult = await Promise.all(
      groupResult.map(async ({ collection_id, product_ids }) => {
        // 1) Get collection name
        const { rows: collRows } = await pool.query(
          `SELECT name FROM collections WHERE collection_id = $1`,
          [collection_id]
        );
        if (collRows.length === 0) {
          throw new Error(`Collection not found: ${collection_id}`);
        }

        // 2) Fetch product IDs + titles in one query
        const { rows: prodRows } = await pool.query(
          `SELECT 
            p.product_id, 
            p.title, 
            p.price, 
            pm.media_url,
            c.category_id
            FROM products p
            LEFT JOIN product_category pc ON p.product_id = pc.product_id
            LEFT JOIN categories c ON pc.category_id = c.category_id
            LEFT JOIN LATERAL (
            SELECT m.media_url
            FROM product_media m
            WHERE m.product_id = p.product_id
              AND (m.status = 'active' OR m.status IS NULL)   -- optional filter
            ORDER BY CASE WHEN m.main THEN 0 ELSE 1 END, m.media_id
            LIMIT 1
          ) pm ON TRUE
          WHERE p.product_id = ANY($1::int[])`,
          [product_ids]
        );

        const allProducts = await Promise.all(
          prodRows.map(async (row) => {
            const discountResult = await oneProductDiscount(row);

            if (!discountResult.success) {
              // No discount available
              return {
                ...row,
                has_discount: false,
                discount_type: null,
                discount_id: null,
                discount_amount: 0,
                free_count: 0,
                buy_count: 0,
              };
            }

            // Discount FOUND
            return {
              ...row,
              has_discount: true,
              discount_type: discountResult.type,
              discount_id: discountResult.discount_id,
              discount_amount: discountResult.total_discount_value,

              // Only filled for buyxgety, otherwise 0
              free_count: discountResult.free_count ?? 0,
              buy_count: discountResult.buy_count ?? 0,
            };
          })
        );
        // 4) Return same object shape with extra data
        return {
          collection_id,
          collection_name: collRows[0].name,
          products: allProducts,
        };
      })
    );

    return res.status(200).json({ message: "success", result: allResult });
  } catch (err) {
    console.error("Error fetching best selling products:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
};

//all product collection
const getallProductCollection = async (req, res) => {
  try {
    const query = `SELECT collection_id, name FROM collections WHERE status = 'active'`;
    const result = await pool.query(query);
    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const checkProductQuantity = async (req, res) => {
  const { variant_id } = req.body;
  console.log("variant_id", variant_id);

  const sales_channel = await getOutletId();
  const outlet_id = sales_channel.outlet_id;

  const query = `SELECT new_quantity FROM inventory WHERE outlet_id = $1 AND variant_id = $2 AND status = 'active' ORDER BY inventory_id DESC LIMIT 1;`;
  const result = await pool.query(query, [outlet_id, variant_id]);

  if (result.rows.length === 0) {
    return res.status(404).json({ message: "Product not found" });
  }
  return res.status(200).json({ message: "success", result: result.rows[0] });
};

//all paymenet method
const getallPaymentMethod = async (req, res) => {
  try {
    const query = `SELECT payment_method_id, method_name, logo, category, transaction_fixed_fee, transaction_fee, commission_status FROM payment_methods WHERE status = 'active' AND payment_method_id <> 5 AND web_show IS TRUE`;
    const result = await pool.query(query);
    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const geNewarrivalProduct = async (req, res) => {
  try {
    const query = `
            SELECT 
          p.product_id AS _id,
          p.title,
          c.category_id,
          c.name AS category_name,
          p.price,
          p.status,
          p.created_at,
          p.description,
          pm.media_url AS img
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      INNER JOIN product_collections po ON po.product_id = p.product_id AND po.collection_id = 24
      LEFT JOIN LATERAL (
          SELECT media_url
          FROM product_media
          WHERE product_id = p.product_id AND main = true
          LIMIT 1
      ) pm ON true
      WHERE p.status = 'active'
        AND p.publishing_online = true
      ORDER BY p.created_at DESC

      `;
    const result = await pool.query(query);

    return res.status(200).json({ message: "success", data: result.rows });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const gerealtedlProduct = async (req, res) => {
  try {
    const { product_id } = req.body;

    const query = `
            WITH src_cat AS (
        SELECT category_id
        FROM product_category
        WHERE product_id = $1
      )
      SELECT
        p.product_id AS _id,
        p.title,
        c.category_id,
        c.name AS category_name,
        p.price,
        p.status,
        p.created_at,
        p.description,
        pm.media_url AS img
      FROM src_cat sc
      JOIN product_category pc ON pc.category_id = sc.category_id
      JOIN products p           ON p.product_id = pc.product_id
      JOIN categories c         ON c.category_id = pc.category_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id AND main = TRUE
        ORDER BY media_id DESC
        LIMIT 1
      ) pm ON TRUE
      WHERE p.status = 'active'
        AND p.publishing_online = TRUE
        AND p.product_id <> $1
      ORDER BY random()
      LIMIT 5;
    
      `;

    const commonQuery = `
            SELECT 
          p.product_id AS _id,
          p.title,
          p.price,
          p.status,
          p.created_at,
          p.description,
          pc.category_id,
          SUM(l.new_quantity) AS total_quantity,
          MAX(pm.media_url) AS img   -- ✅ use aggregate
        FROM (
          SELECT DISTINCT ON (variant_id) *
          FROM inventory
          ORDER BY variant_id, inventory_id DESC
        ) l
        JOIN product_variants pv ON pv.variant_id = l.variant_id
        JOIN products p          ON p.product_id = pv.product_id
        JOIN product_category pc ON pc.product_id = p.product_id
        LEFT JOIN LATERAL (
          SELECT media_url
          FROM product_media
          WHERE product_id = p.product_id 
            AND main = TRUE 
            AND status = 'active'
          ORDER BY media_id DESC
          LIMIT 1
        ) pm ON TRUE
         WHERE p.status = 'active'
        AND p.publishing_online = TRUE
        GROUP BY p.product_id, pc.category_id
        ORDER BY total_quantity DESC
        LIMIT 5;
            `;
    const [result, commonResult] = await Promise.all([
      pool.query(query, [product_id]),
      pool.query(commonQuery),
    ]);

    const rowsToProcess =
      result.rows?.length > 0 ? result.rows : commonResult.rows;

    const allProducts = await Promise.all(
      rowsToProcess.map(async (row) => {
        const discountResult = await oneProductDiscount(row);

        if (!discountResult.success) {
          // No discount available
          return {
            ...row,
            has_discount: false,
            discount_type: null,
            discount_id: null,
            discount_amount: 0,
            free_count: 0,
            buy_count: 0,
          };
        }

        // Discount FOUND
        return {
          ...row,
          has_discount: true,
          discount_type: discountResult.type,
          discount_id: discountResult.discount_id,
          discount_amount: discountResult.total_discount_value,

          // Only filled for buyxgety, otherwise 0
          free_count: discountResult.free_count ?? 0,
          buy_count: discountResult.buy_count ?? 0,
        };
      })
    );

    return res.status(200).json({
      message: "success",
      data: allProducts,
    });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const getProductReviews = async (req, res) => {
  try {
    const { product_id } = req.body;
    console.log("product_id", product_id);
    const query = `
        SELECT * FROM product_reviews WHERE product_id = $1 AND status = 'active'
      `;
    const result = await pool.query(query, [product_id]);

    return res.status(200).json({ message: "success", data: result.rows });
  } catch (err) {
    console.error("Error fetching reviews:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const highestPrice = async (req, res) => {
  try {
    const query = `SELECT MAX(price) AS highest_price
      FROM products p
      WHERE p.status = 'active' AND p.publishing_online = true`;

    const result = await pool.query(query);
    return res.status(200).json({ message: "success", result: result.rows[0] });
  } catch (error) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const addReview = async (req, res) => {
  const { userId, productId, rating, comment } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  try {
    const query = `INSERT INTO product_reviews (product_id, customer_name, comment, review, created_at, user_id, status) VALUES ($1, $2, $3, $4, NOW(), $5, 'pending')`;

    const result = await pool.query(query, [
      productId,
      userId,
      comment,
      rating,
      user_id,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    const title = "Review";
    const log = `User: ${userId} - Product: ${productId} - Review: ${rating} - Comment: ${comment}`;
    await insertClientLog(null, title, log);
    return res
      .status(200)
      .json({ message: "Review submitted successfully. Thank you" });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error", error });
  }
};

const addReviewGuest = async (req, res) => {
  const { userId, productId, rating, comment } = req.body;
  console.log("req.body", userId, productId, rating, comment);
  try {
    const query = `INSERT INTO product_reviews (product_id, customer_name, comment, review, created_at,  status) VALUES ($1, $2, $3, $4, NOW(), 'pending')`;

    const result = await pool.query(query, [
      productId,
      userId,
      comment,
      rating,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    const title = "Review";
    const log = `User: ${userId} - Product: ${productId} - Review: ${rating} - Comment: ${comment}`;
    await insertClientLog(null, title, log);
    return res
      .status(200)
      .json({ message: "Review submitted successfully. Thank you" });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error", error });
  }
};

const oneProductReview = async (req, res) => {
  const { product_id } = req.body;

  try {
    const query = `SELECT SUM(review) AS total, COUNT(review) as count FROM product_reviews WHERE product_id = $1 AND status = 'active'`;

    const result = await pool.query(query, [product_id]);

    const total = result.rows[0].total;
    const count = result.rows[0].count;
    const average = total / count;

    return res.status(200).json({ message: "Review Count", result: average });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error", error });
  }
};

const directAddtoCart = async (req, res) => {
  const { product_id } = req.body;

  try {
    const query = `SELECT pv.product_id, pv.variant_id, pv.price, pv.continue_selling_oos, pv.weight, pm.media_url, p.title	
                   FROM product_variants pv
                   JOIN products p ON p.product_id = pv.product_id
                   LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.status = 'active' AND pm.variant_id IS NULL
                   WHERE pv.product_id = $1 AND pv.status = 'active' LIMIT 1`;

    const result = await pool.query(query, [product_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    const product = result.rows[0];
    const { continue_selling_oos, variant_id } = product;

    if (continue_selling_oos) {
      return res
        .status(200)
        .json({ message: "Product Found", result: product });
    }

    const quantityQuery = ` SELECT i.inventory_id, i.new_quantity, pv.continue_selling_oos
                    FROM inventory i
                    JOIN product_variants pv ON pv.variant_id = i.variant_id
                    WHERE i.variant_id = $1
                    AND i.status = 'active'
                    ORDER BY i.inventory_id DESC
                    LIMIT 1`;

    const quantityResult = await pool.query(quantityQuery, [variant_id]);

    if (quantityResult.rows.length === 0) {
      return res.status(404).json({ message: "Product Variant not found" });
    }

    const quantity = quantityResult.rows[0].new_quantity;

    if (1 > quantity) {
      return res.status(404).json({ message: "Product is out of stock" });
    }

    const newProduct = {
      ...product,
      available: quantity,
    };

    return res
      .status(200)
      .json({ message: "Product Found", result: newProduct });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error", error });
  }
};

const ViewCount = async (req, res) => {
  const { product_id } = req.body;

  try {
    // Increase view_count by 1
    const result = await pool.query(
      `UPDATE products
       SET view_count = view_count + 1
       WHERE 	product_id = $1`,
      [product_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.json({
      success: true,
    });
  } catch (err) {
    console.error("Error updating view_count:", err);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
};

const getProductAvailable = async (req, res) => {
  try {
    const { oneproduct_id } = req.params;

    console.log("product id:", oneproduct_id);

    const query = `
      WITH latest_inventory AS (
        SELECT DISTINCT ON (variant_id)
            variant_id,
            new_quantity
        FROM inventory
        WHERE status = 'active'
        ORDER BY variant_id, inventory_id DESC
      )
      SELECT
        pv.product_id,
        SUM(COALESCE(li.new_quantity, 0)) AS total_quantity
      FROM product_variants pv
      LEFT JOIN latest_inventory li ON pv.variant_id = li.variant_id
      WHERE pv.status = 'active'
        AND pv.product_id = $1
      GROUP BY pv.product_id;
    `;

    const result = await pool.query(query, [oneproduct_id]);

    console.log("RESULT:", result.rows);

    return res.status(200).json({
      message: "success",
      availability: result.rows[0].total_quantity
        ? result.rows[0].total_quantity
        : 0,
    });
  } catch (err) {
    console.error("Error fetching product list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

module.exports = {
  getProduct,
  getAllProduct,
  getProductReviews,
  getProductById,
  getProductVariant,
  getProductCategory,
  getallProductCollection,
  checkProductQuantity,
  getallPaymentMethod,
  geSearchProduct,
  geNewarrivalProduct,
  getFeaturesProducts,
  gerealtedlProduct,
  highestPrice,
  getBestSellingProducts,
  getprodcutWithcolection,
  addReview,
  oneProductReview,
  directAddtoCart,
  ViewCount,
  getProductCollection,
  getProductAvailable,
  addReviewGuest,
};
