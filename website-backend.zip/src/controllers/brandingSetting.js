const { json } = require("express");
const pool = require("../config/db");
const { oneProductDiscount } = require("./DiscountController");

const getBrandingSetting = async (req, res) => {
  try {
    const query = `SELECT * FROM branding_settings WHERE id = 1`;

    const result = await pool.query(query);

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Branding settings not found" });
    }

    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error("Error fetching branding settings:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch branding settings" });
  }
};

const SlideDetails = async (req, res) => {
  const { sectionId } = req.body;
  console.log(sectionId);
  try {
    const query = `SELECT * FROM site_section_configs WHERE template_section_id = $1`;
    const result = await pool.query(query, [sectionId]);
    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Slide details not found" });
    }
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error("Error fetching slide details:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch slide details" });
  }
};

const FeatureAreaDetails = async (req, res) => {
  const { sectionId } = req.body;
  try {
    const query = `
      SELECT config
      FROM site_section_configs
      WHERE template_section_id = $1 AND enabled = TRUE
      LIMIT 1
    `;
    const result = await pool.query(query, [sectionId]);

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Section not found" });
    }

    // config can be jsonb (object) or text (string) — normalize it
    const rawCfg = result.rows[0].config;
    const cfg = typeof rawCfg === "string" ? JSON.parse(rawCfg) : rawCfg || {};
    const features = Array.isArray(cfg.features) ? cfg.features : [];

    return res.json({ success: true, data: features });
  } catch (err) {
    console.error("Error fetching feature area details:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch feature area details",
    });
  }
};

const SpecialProductDetails = async (req, res) => {
  const { sectionId } = req.body;

  try {
    const cfgSql = `
      SELECT config
      FROM site_section_configs
      WHERE template_section_id = $1 AND enabled = TRUE
      LIMIT 1
    `;
    const cfgResult = await pool.query(cfgSql, [sectionId]);
    if (cfgResult.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Section not found" });
    }

    const cfgRaw = cfgResult.rows[0].config;
    const cfg = typeof cfgRaw === "string" ? JSON.parse(cfgRaw) : cfgRaw || {};

    const left_image_url = cfg.left_image_url || "";
    const right_bg_color = cfg.right_bg_color || cfg.right_panel_bg || null;

    const selected_product_ids = Array.isArray(cfg.selected_product_ids)
      ? cfg.selected_product_ids.map(Number).filter(Boolean)
      : [];

    if (selected_product_ids.length === 0) {
      return res.json({
        success: true,
        data: {
          left_image_url,
          right_bg_color,
          selected_product_ids: [],
          products: [],
        },
      });
    }

    const prodSql = `
      WITH wanted AS (
        SELECT unnest($1::int[]) AS product_id,
               generate_subscripts($1::int[], 1) AS ord
      )
      SELECT
        p.product_id,
        p.title,
        COALESCE(p.title, p.search_engine_title, p.title) AS title,
        p.price::numeric AS price,
        pm_pick.media_url,
         c.category_id
      FROM wanted w
      JOIN products p ON p.product_id = w.product_id
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN LATERAL (
        SELECT pm.media_url
        FROM product_media pm
        WHERE pm.product_id = p.product_id
          AND (pm.status = 'active' OR pm.status IS NULL)
        ORDER BY pm.main DESC NULLS LAST, pm.created_at DESC NULLS LAST, pm.media_id DESC NULLS LAST
        LIMIT 1
      ) pm_pick ON TRUE
      ORDER BY w.ord; -- preserve incoming order
    `;

    const { rows: allProducts } = await pool.query(prodSql, [
      selected_product_ids,
    ]);
    const products = await Promise.all(
      allProducts.map(async (row) => {
        const discountResult = await oneProductDiscount(row);

        if (!discountResult.success) {
          // No discount available
          return {
            ...row,
            has_discount: false,
            discount_type: null,
            discount_id: null,
            discount_amount: 0,
            free_count: 0,
            buy_count: 0,
          };
        }

        // Discount FOUND
        return {
          ...row,
          has_discount: true,
          discount_type: discountResult.type,
          discount_id: discountResult.discount_id,
          discount_amount: discountResult.total_discount_value,

          // Only filled for buyxgety, otherwise 0
          free_count: discountResult.free_count ?? 0,
          buy_count: discountResult.buy_count ?? 0,
        };
      })
    );
    return res.json({
      success: true,
      data: {
        left_image_url,
        right_bg_color,
        selected_product_ids,
        products,
      },
    });
  } catch (err) {
    console.error("Error fetching special product details:", err);
    res.status(500).json({
      success: false,
      message: "Failed to fetch special product details",
    });
  }
};

// GET banner details enriched with collection names
// const BannerDetails = async (req, res) => {
//   const { sectionId } = req.body;

//   try {
//     const { rows } = await pool.query(
//       `SELECT config
//          FROM site_section_configs
//         WHERE template_section_id = $1
//         LIMIT 1`,
//       [sectionId]
//     );
//     console.log(rows);
//     if (rows.length === 0) {
//       return res
//         .status(404)
//         .json({ success: false, message: "Slide details not found" });
//     }

//     const rawConfig = rows[0].config;
//     const config =
//       rawConfig && typeof rawConfig === "string"
//         ? JSON.parse(rawConfig)
//         : rawConfig || {};

//     const banners = Array.isArray(config?.banners) ? config.banners : [];

//     const collectionIds = [
//       ...new Set(
//         banners
//           .map((b) => Number(b?.collection_id))
//           .filter((n) => Number.isFinite(n))
//       ),
//     ];

//     let nameMap = new Map();
//     if (collectionIds.length > 0) {
//       const { rows: colRows } = await pool.query(
//         `SELECT collection_id, name
//            FROM collections
//           WHERE collection_id = ANY($1::int[])`,
//         [collectionIds]
//       );
//       nameMap = new Map(colRows.map((r) => [Number(r.collection_id), r.name]));
//     }

//     const data = banners.map((b) => ({
//       banner_url: b?.image_url ?? null, // keep your key as needed
//       collection_id: b?.collection_id ?? null,
//       name: nameMap.get(Number(b?.collection_id)) ?? null,
//     }));

//     return res.json({
//       success: true,
//       data,
//     });
//   } catch (err) {
//     console.error("Error fetching slide details:", err);
//     return res.status(500).json({
//       success: false,
//       message: "Failed to fetch slide details",
//     });
//   }
// };
const BannerDetails = async (req, res) => {
  const { sectionId } = req.body;

  try {
    const { rows } = await pool.query(
      `SELECT config
         FROM site_section_configs
        WHERE template_section_id = $1
        LIMIT 1`,
      [sectionId]
    );

    if (rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Banner details not found" });
    }

    const rawConfig = rows[0].config;
    const config =
      rawConfig && typeof rawConfig === "string"
        ? JSON.parse(rawConfig)
        : rawConfig || {};

    const banners = Array.isArray(config?.banners) ? config.banners : [];

    // collect only real collection ids (> 0) to avoid placeholder lookups
    const collectionIds = [
      ...new Set(
        banners
          .map((b) => Number(b?.collection_id))
          .filter((n) => Number.isFinite(n) && n > 0)
      ),
    ];

    let nameMap = new Map();
    if (collectionIds.length > 0) {
      const { rows: colRows } = await pool.query(
        `SELECT collection_id, name
           FROM collections
          WHERE collection_id = ANY($1::int[])`,
        [collectionIds]
      );
      nameMap = new Map(colRows.map((r) => [Number(r.collection_id), r.name]));
    }

    const data = banners.map((b) => {
      const cid = Number(b?.collection_id);
      return {
        banner_url: b?.image_url ?? null,
        collection_id: Number.isFinite(cid) ? cid : null,
        name: cid > 0 ? nameMap.get(cid) ?? null : null,
        // newly added fields
        title_color: b?.title_color ?? null,
        subtitle_color: b?.subtitle_color ?? null,
      };
    });

    return res.json({ success: true, data });
  } catch (err) {
    console.error("Error fetching banner details:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch banner details",
    });
  }
};

const CategoryDetails = async (req, res) => {
  const { sectionId } = req.body;
  try {
    const query = `SELECT id, config FROM site_section_configs WHERE template_section_id = $1`;
    const result = await pool.query(query, [sectionId]);

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Slide details not found" });
    }

    const cfg = result.rows[0].config;
    console.log("cfg", cfg);

    // Normalize inputs
    const ids = (cfg.selected_category_ids || [])
      .map(Number)
      .filter(Number.isFinite);
    const limit = Number(cfg.limit) || 20;

    if (ids.length === 0) {
      return res.json({ success: true, data: [] }); // nothing selected
    }

    //   const categoryQuery = `
    //   SELECT
    //     c.category_id,
    //     c.name,
    //     c.category_under,
    //     c.mobile_url,
    //     c.desktop_url,
    //     COUNT(pc.product_id) AS product_count
    //     -- If you can have duplicates per product, prefer COUNT(DISTINCT pc.product_id)
    //   FROM categories c
    //   LEFT JOIN product_category pc ON c.category_id = pc.category_id
    //   WHERE c.status = 'active'
    //     AND c.category_id = ANY($1::int[])
    //   GROUP BY
    //     c.category_id, c.name, c.category_under, c.mobile_url, c.desktop_url
    //   ORDER BY array_position($1::int[], c.category_id)  -- keep input order
    //   LIMIT $2::int
    // `;

    const categoryQuery = `
          
WITH RECURSIVE category_tree AS (
  -- roots
  SELECT
    c.category_id       AS root_id,
    c.category_id       AS category_id,
    c.category_under,
    0                   AS depth
  FROM categories c
  WHERE c.status = 'active'
    AND c.category_under IS NULL

  UNION ALL

  -- descendants
  SELECT
    ct.root_id,
    c.category_id,
    c.category_under,
    ct.depth + 1
  FROM categories c
  JOIN category_tree ct
    ON c.category_under = ct.category_id
  WHERE c.status = 'active'
)
SELECT 
  ct.root_id as category_id,
        r.name,
  r.mobile_url,
  r.desktop_url,   
  COUNT(DISTINCT p.product_id) AS product_count
FROM category_tree ct
LEFT JOIN product_category pc 
  ON ct.category_id = pc.category_id
  LEFT JOIN categories r
  ON r.category_id = ct.root_id
LEFT JOIN products p ON p.product_id = pc.product_id AND p.status = 'active'
WHERE ct.root_id = ANY($1::int[])
GROUP BY ct.root_id, r.name, r.mobile_url, r.desktop_url
ORDER BY ct.root_id
LIMIT $2::int;

            `;

    const categoryResult = await pool.query(categoryQuery, [ids, limit]);

    if (categoryResult.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Category not found" });
    }

    return res.json({ success: true, result: categoryResult.rows });
  } catch (err) {
    console.error("Error fetching slide details:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const webTemplateSections = async (req, res) => {
  const { templateId } = req.body;
  console.log("templateId", templateId);
  try {
    const query = `SELECT id,section_key, "order" FROM web_template_sections WHERE status = 'active' AND display = true AND template_id = $1 ORDER BY "order" ASC`;
    const result = await pool.query(query, [templateId]);
    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Slide details not found" });
    }
    return res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error("Error fetching slide details:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch slide details" });
  }
};

const getActivePlugins = async (req, res) => {
  try {
    const query = `
      SELECT *
      FROM plugins
      WHERE status = 'active'
      ORDER BY created_at DESC
    `;

    const result = await pool.query(query);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active plugins found",
      });
    }

    return res.json({
      success: true,
      data: result.rows, // ✅ all columns returned
    });
  } catch (err) {
    console.error("Error fetching active plugins:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch plugins",
    });
  }
};

module.exports = {
  getBrandingSetting,
  getActivePlugins,
  FeatureAreaDetails,
  SlideDetails,
  SpecialProductDetails,
  BannerDetails,
  CategoryDetails,
  webTemplateSections,
};
