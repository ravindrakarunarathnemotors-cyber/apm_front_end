const { systemSettings, oneCountry, actionMessage, insertNotification, checkLoyalty, updateLoyaltySuctomer, addLoyalty } = require("../common/common");
const pool = require("../config/db");
const { getOutletId } = require("../models/commonQuery");
const crypto = require('crypto')

const bcrypt = require("bcrypt");
const saltRounds = 10;

const Stripe = require("stripe");
const { encryptId, decryptId } = require("../util/orderEncrypt");
const { guestRegistration } = require("../common/emailTemplate");

// const stripe = require("stripe")("sk_test_51Rq7SQ1tDQQWe3JTiBGOUybtphvu0TGo4120wpYhAewl6b1w75NQVLxAAssQKUBefIGjkTuxxENVyFQQSYS118YD00cecuQjSL", {
//     apiVersion: "2025-06-30.basil",
// })

async function getStripeInstance() {
    const result = await pool.query(
        "SELECT api_array FROM payment_methods WHERE payment_method_id = $1",
        [2]
    );

    if (!result.rows.length || !result.rows[0].api_array) {
        throw new Error("Stripe key not found for merchant");
    }

    const merchantSecret = result.rows[0].api_array.merchantSecret

    return new Stripe(merchantSecret, {
        apiVersion: "2025-06-30.basil",
    });
}

async function getStripeFrontendKey() {
    const result = await pool.query(
        "SELECT api_array FROM payment_methods WHERE payment_method_id = $1",
        [2]
    );

    if (!result.rows.length || !result.rows[0].api_array) {
        throw new Error("Stripe key not found for merchant");
    }

    const merchantId = result.rows[0].api_array.merchant_id

    return merchantId
}

// Currencies that Stripe handles in smallest unit WITHOUT decimals (zero-decimal)
const ZERO_DECIMAL_CURRENCIES = [
    'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW',
    'MGA', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'
    // Note: LKR uses cents (non-zero-decimal), so 100 LKR = 10000 in Stripe
];

function toStripeAmount(amount, currency) {
    if (ZERO_DECIMAL_CURRENCIES.includes(currency.toUpperCase())) {
        return Math.round(amount);
    }
    return Math.round(amount * 100); // e.g. LKR 500 → 50000
}

const useMeasurementConverter = (amount, measurement_id) => {

    // Only convert when measurement is grams (id = 3)
    if (measurement_id !== 3) {
        return amount; // return original amount
    }

    // Keep as grams
    return (amount / 1000).toFixed(2)
};


const addOrder = async (req, res) => {

    const { firstName, lastName, address, contact, email, city, country, zipCode, cart, paymentMethod, subTotal, deliveryfee, orderNote, deliveryAddress, deliveryCity, deliveryContactNo, deliveryCountry, deliveryEmail, deliveryFirstName, deliveryLastName, deliveryZipCode, sameAsBilling, isGuest, contact2, deliverContact2, taxName, discountDetails, loyaltiPoints, saveDetails, lastSubTotal1, fullAmount2, transactionFee } = req.body;

    const user = req.user
    const user_id = user.user_id

    const type = discountDetails && discountDetails.type ? discountDetails.type : null


    const discount = type == 'buyx' ? 0 : parseFloat(discountDetails?.discount_value || 0)

    const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0


    try {
        // check stock
        for (const item of cart) {
            const productsInDB = await pool.query(
                `
                                    SELECT pv.variant_id,
                    pv.continue_selling_oos,
                    i.inventory_id,
                    i.new_quantity
                FROM product_variants pv
                LEFT JOIN LATERAL (
                    SELECT i.inventory_id, i.new_quantity
                    FROM inventory i
                    WHERE i.variant_id = pv.variant_id
                    AND i.status = 'active'
                    ORDER BY i.inventory_id DESC
                    LIMIT 1
                ) i ON TRUE
                WHERE pv.variant_id = $1;

                    `,
                [item.variant_id]
            );

            if (productsInDB.rows.length === 0) {
                return res.status(400).json({ message: `Sorry, "${item.title}" is not available in stock.` });
            }

            const { new_quantity: available, continue_selling_oos } = productsInDB.rows[0];

            // ✅ If continue_selling_oos is true → skip stock checks
            if (!continue_selling_oos) {
                if (!available) {
                    return res.status(400).json({ message: `Sorry, "${item.title}" is not available in stock.` });
                }

                if (item.orderQuantity > available) {
                    return res.status(400).json({
                        message: `Sorry, only ${available} units of "${item.title}" are available in stock.`,
                    });
                }
            }
        }

        // update customer Details
        if (saveDetails) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [firstName, lastName, contact, address, city, country]

            if (email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(email)
            }

            if (zipCode) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(zipCode)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(user_id)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        //admin merchant id
        const [selectedPaymentMethod, system_setting, sales_channel, sender_country, customerLoyalty] = await Promise.all([
            pool.query("SELECT payment_method_id,method_name FROM payment_methods WHERE payment_method_id = $1 AND status = 'active'", [Number(paymentMethod)]),
            systemSettings(),
            getOutletId(),
            oneCountry(country),
            checkLoyalty(user_id)
        ])

        if (selectedPaymentMethod.rows.length === 0) {
            return res.status(400).json({ message: "Payment method not found" });
        }

        if (customerLoyalty < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })

        const merchant_id = sales_channel.merchant_id

        // check COD or not
        let cod = false
        if (selectedPaymentMethod.rows[0].method_name === "COD") {
            cod = true
        }

        const totalAmount = lastSubTotal1

        const totalWeight = cart.reduce((total, item) => {
            if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
            return total + parseFloat(item.weight * item.orderQuantity)
        }, 0);

        const totalQuantity = cart.reduce((total, item) => {
            return total + item.orderQuantity;
        }, 0);

        console.log("totalAmount", totalWeight)

        const tax_percentage = parseFloat(Object.values(system_setting.tax_value)[0]) || 0;
        const tax_on_web = system_setting.tax_on_web

        const full_tax = tax_on_web ? taxName : null


        const fullAmount = fullAmount2

        //set shipping details
        let shipping_first_name = ''
        let shipping_last_name = ''
        let shipping_address = ''
        let shipping_city = ''
        let shipping_postal_code = ''
        let shipping_apartment = ''
        let shipping_country = 'Sri Lanka'
        let shipping_contact_number_1 = ''
        let shipping_contact_number_2 = ''
        let shipping_email = ''

        if (sameAsBilling) {
            shipping_first_name = firstName ? firstName + ' ' + lastName : ''
            shipping_last_name = lastName ? lastName : ''
            shipping_address = address ? address : ''
            shipping_city = city ? city : ''
            shipping_postal_code = zipCode ? zipCode : ''
            shipping_country = sender_country ? sender_country : ''
            shipping_contact_number_1 = contact ? contact : ''
            shipping_contact_number_2 = contact2 ? contact2 : ''
            shipping_email = email ? email : ''
        } else {
            const deliver_Country = await oneCountry(deliveryCountry)
            shipping_first_name = deliveryFirstName ? deliveryFirstName + ' ' + deliveryLastName : ''
            shipping_last_name = deliveryLastName ? deliveryLastName : ''
            shipping_address = deliveryAddress ? deliveryAddress : ''
            shipping_city = deliveryCity ? deliveryCity : ''
            shipping_postal_code = deliveryZipCode ? deliveryZipCode : ''
            shipping_country = deliver_Country ? deliver_Country : ''
            shipping_contact_number_1 = deliveryContactNo ? deliveryContactNo : ''
            shipping_contact_number_2 = deliverContact2 ? deliverContact2 : ''
            shipping_email = deliveryEmail ? deliveryEmail : ''
        }

        const orderQuery = `INSERT INTO orders (merchant_id	,customer_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_address, recipient_name, recipient_contact, recipient_email, recipient_address, recipient_city, recipient_postal_code, recipient_country, payment_reference, order_module, delivery_fee, discount, sender_name, sender_city, sender_phone, sender_email, sender_country, sender_phone_two,recipient_contact_two, tax_percentage, tax, full_amount, discount_type, loyalty_points_spent, transaction_fee) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36 ) RETURNING order_id`

        const OrderParms = [merchant_id, user_id, selectedPaymentMethod.rows[0].payment_method_id, 'pending', totalAmount, 0, totalQuantity, totalWeight, cod, fullAmount > 0 ? 'unpaid' : 'paid', system_setting.currency, address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, orderNote, 'client', parseFloat(deliveryfee), parseFloat(discount), firstName + ' ' + lastName, city, contact, email, sender_country, contact2 || '', shipping_contact_number_2, tax_percentage, full_tax, fullAmount, type, typeLoyaltyPoint, transactionFee]

        const orderResult = await pool.query(orderQuery, OrderParms)

        const order_id = orderResult.rows[0].order_id

        const orderItemParams = []
        const values = []

        cart.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            const baseIndex = 10 * i;

            values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

            const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            orderItemParams.push(
                order_id,
                product.product_id,
                product.variant_id,
                product.orderQuantity,
                product.price,
                product.price * product.orderQuantity,
                real_weight,
                is_free,                             // 8. is_free
                free_quantity,
                discount
            );
        });


        //add order items 
        const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`

        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id) {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

            const discountUsageResult = await pool.query(discountUsageQuery, [order_id, discountDetails.discount_id, user_id, 'order'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        const encryptedId = encryptId(order_id)

        res.status(200).json({ message: "Order added successfully", orderId: encryptedId });

        actionMessage(order_id).catch(err => {
            console.error("Notification failed:", err.response?.data || err.message);
        });

        await insertNotification(
            null,
            "Order Management",
            "New Order Placed",
            `Order # ${order_id} has been created.`,
            "Website Notification",
            "Unread"
        );

        await updateLoyaltySuctomer(user_id, loyaltiPoints, customerLoyalty)

        return

    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Server error" });
    }


}


const guestAddOrder = async (req, res) => {

    try {

        const { firstName, lastName, address, contact, email, city, country, zipCode, cart, paymentMethod, subTotal, deliveryfee, orderNote, deliveryAddress, deliveryCity, deliveryContactNo, deliveryCountry, deliveryEmail, deliveryFirstName, deliveryLastName, deliveryZipCode, sameAsBilling, isGuest, contact2, deliverContact2, taxName, discountDetails, lastSubTotal1, fullAmount2, transactionFee } = req.body;

        const type = discountDetails && discountDetails.type ? discountDetails.type : null


        const discount = type == 'buyx' ? 0 : parseFloat(discountDetails?.discount_value || 0)

        const password = 'guest123';

        //check stock
        for (const item of cart) {

            const productsInDB = await pool.query(`
                        SELECT pv.variant_id,
                            pv.continue_selling_oos,
                            i.inventory_id,
                            i.new_quantity
                        FROM product_variants pv
                        LEFT JOIN LATERAL (
                            SELECT i.inventory_id, i.new_quantity
                            FROM inventory i
                            WHERE i.variant_id = pv.variant_id
                            AND i.status = 'active'
                            ORDER BY i.inventory_id DESC
                            LIMIT 1
                        ) i ON TRUE
                        WHERE pv.variant_id = $1;
                `, [item.variant_id]);

            if (productsInDB.rows.length === 0) {
                return res.status(400).json({ message: `Sorry, "${item.title}" is not available in stock.` });
            }

            const { new_quantity: available, continue_selling_oos } = productsInDB.rows[0];

            // ✅ If continue_selling_oos is true → skip stock checks
            if (!continue_selling_oos) {
                if (!available) {
                    return res.status(400).json({ message: `Sorry, "${item.title}" is not available in stock.` });
                }

                if (item.orderQuantity > available) {
                    return res.status(400).json({
                        message: `Sorry, only ${available} units of "${item.title}" are available in stock.`,
                    });
                }
            }
        }

        if (!isGuest) return res.status(400).json({ message: "User not found." })

        let user_id = null;

        // Normalize and sanitize inputs
        const normalizedEmail = email?.trim().toLowerCase();
        const normalizedContact = contact?.trim();

        // Check if customer already exists by email or contact number
        const customerQuery = `
                SELECT customer_id, guest
                FROM customer
                WHERE LOWER(email) = $1 OR contact_number_1 = $2
                `;
        const customerResult = await pool.query(customerQuery, [normalizedEmail, normalizedContact]);

        if (customerResult.rows.length === 0) {


            const hash = await bcrypt.hash(password, saltRounds);
            // Insert new guest customer
            const insertCustomerQuery = `
                INSERT INTO customer (
                first_name, last_name, email, contact_number_1,
                address, city, country, guest, password
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING customer_id
            `;
            const insertCustomerResult = await pool.query(insertCustomerQuery, [
                firstName?.trim(),
                lastName?.trim(),
                normalizedEmail,
                normalizedContact,
                address?.trim(),
                city?.trim(),
                '162',
                true,
                hash
            ]);

            user_id = insertCustomerResult.rows[0].customer_id;

        } else {
            const { guest, customer_id } = customerResult.rows[0];

            if (!guest) {
                return res.status(400).json({
                    message: 'This email or phone number is already registered. Please log in to continue.',
                });
            }

            // Reuse existing guest account
            user_id = customer_id;
        }


        //admin merchant id
        const [selectedPaymentMethod, system_setting, sales_channel, sender_country] = await Promise.all([
            pool.query("SELECT payment_method_id,method_name FROM payment_methods WHERE payment_method_id = $1 AND status = 'active'", [Number(paymentMethod)]),
            systemSettings(),
            getOutletId(),
            oneCountry(country),
        ])

        if (selectedPaymentMethod.rows.length === 0) {
            return res.status(400).json({ message: "Payment method not found" });
        }

        const merchant_id = sales_channel.merchant_id

        // check COD or not
        let cod = false
        if (selectedPaymentMethod.rows[0].method_name === "COD") {
            cod = true
        }

        const totalAmount = lastSubTotal1

        const totalWeight = cart.reduce((total, item) => {
            if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
            return total + parseFloat(item.weight * item.orderQuantity)
        }, 0);

        const totalQuantity = cart.reduce((total, item) => {
            return total + item.orderQuantity;
        }, 0);

        const tax_percentage = parseFloat(Object.values(system_setting.tax_value)[0]) || 0;

        const tax_on_web = system_setting.tax_on_web

        const full_tax = tax_on_web ? taxName : null

        const fullAmount = fullAmount2

        //set shipping details
        let shipping_first_name = ''
        let shipping_last_name = ''
        let shipping_address = ''
        let shipping_city = ''
        let shipping_postal_code = ''
        let shipping_apartment = ''
        let shipping_country = 'Sri Lanka'
        let shipping_contact_number_1 = ''
        let shipping_contact_number_2 = ''
        let shipping_email = ''

        if (sameAsBilling) {
            shipping_first_name = firstName ? firstName + lastName : ''
            shipping_last_name = lastName ? lastName : ''
            shipping_address = address ? address : ''
            shipping_city = city ? city : ''
            shipping_postal_code = zipCode ? zipCode : ''
            shipping_country = sender_country ? sender_country : ''
            shipping_contact_number_1 = contact ? contact : ''
            shipping_contact_number_2 = contact2 ? contact2 : ''
            shipping_email = email ? email : ''
        } else {
            const deliver_Country = await oneCountry(deliveryCountry)
            shipping_first_name = deliveryFirstName ? deliveryFirstName + deliveryLastName : ''
            shipping_last_name = deliveryLastName ? deliveryLastName : ''
            shipping_address = deliveryAddress ? deliveryAddress : ''
            shipping_city = deliveryCity ? deliveryCity : ''
            shipping_postal_code = deliveryZipCode ? deliveryZipCode : ''
            shipping_country = deliver_Country ? deliver_Country : ''
            shipping_contact_number_1 = deliveryContactNo ? deliveryContactNo : ''
            shipping_contact_number_2 = deliverContact2 ? deliverContact2 : ''
            shipping_email = deliveryEmail ? deliveryEmail : ''
        }

        const orderQuery = `INSERT INTO orders (merchant_id	,customer_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_address, recipient_name, recipient_contact, recipient_email, recipient_address, recipient_city, recipient_postal_code, recipient_country, payment_reference, order_module, delivery_fee, discount, sender_name, sender_city, sender_phone, sender_email, sender_country, sender_phone_two,recipient_contact_two, tax_percentage, tax, full_amount, discount_type, transaction_fee) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35) RETURNING order_id`

        const OrderParms = [merchant_id, user_id, selectedPaymentMethod.rows[0].payment_method_id, 'pending', totalAmount, 0, totalQuantity, totalWeight, cod, 'unpaid', system_setting.currency, address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, orderNote, 'client', parseFloat(deliveryfee), parseFloat(discount), firstName + ' ' + lastName, city, contact, email, sender_country, contact2 || '', shipping_contact_number_2, tax_percentage, full_tax, fullAmount, type, transactionFee]

        const orderResult = await pool.query(orderQuery, OrderParms)

        const order_id = orderResult.rows[0].order_id


        const orderItemParams = []
        const values = []


        cart.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            const baseIndex = 10 * i;

            values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

            const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            orderItemParams.push(
                order_id,
                product.product_id,
                product.variant_id,
                product.orderQuantity,
                product.price,
                product.price * product.orderQuantity,
                real_weight,
                is_free,                             // 8. is_free
                free_quantity,
                discount
            );
        });


        //add order items 
        const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id) {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, is_guest, type) VALUES ($1, $2, $3, $4, $5)`

            const discountUsageResult = await pool.query(discountUsageQuery, [order_id, discountDetails.discount_id, user_id, true, 'order'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        const encryptedId = encryptId(order_id)

        res.status(200).json({ message: "Order added successfully", orderId: encryptedId });

        if (customerResult.rows.length === 0) {
            const full_name = firstName + ' ' + lastName
            await guestRegistration(email, password, full_name)
        }

        actionMessage(order_id).catch(err => {
            console.error("Notification failed:", err.response?.data || err.message);
        });

        return

    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Server error" });
    }

}

const oneOrder = async (req, res) => {
    const encryptId = req.params.id;
    const orderId = decryptId(encryptId)
    console.log(orderId)

    const query = `SELECT o.order_id, o.customer_id, o.payment_method_id, o.order_status, o.total_value,
  o.total_item, o.total_weight, o.cod, o.payment_status, o.currency, o.sender_address,
  o.recipient_name, o.recipient_contact, o.recipient_email, o.recipient_address, 
  o.recipient_city, o.recipient_postal_code, o.recipient_country, o.payment_reference, o.sender_name, o.sender_city, o.sender_phone, o.sender_email, o.sender_country,
  o.delivery_fee, o.discount, o.created_at, pm.method_name, pm.payment_intraduction, o.tax, o.tax_percentage, o.discount_type, o.loyalty_points_spent, o.full_amount, o.currency, o.transaction_fee,
  COALESCE(
    json_agg(
      json_build_object(
        'item_id', oi.order_item_id	,
        'order_id', oi.order_id,
        'product_id', oi.product_id,
        'variant_id', oi.variant_id,
        'quantity', oi.quantity,
        'unit_price', oi.unit_price,
        'weight', oi.item_weght,
        'price', oi.total_price,
        'is_free', oi.is_free,
        'free_quantity', oi.free_quantity,
        'product_discount', oi.discount,
        'product_name', p.title,
        'product_measurement_id', p.measurement_id,
        'product_measurement_name', m.measurement_value,
        'amount_per_unit', p.amount_per_unit,
        'variant_value', pv.variant_value
      )
    ) FILTER (WHERE oi.order_item_id IS NOT NULL), '[]'
  ) AS order_items
  FROM orders o
  LEFT JOIN order_items oi ON o.order_id = oi.order_id
  LEFT JOIN products p ON oi.product_id = p.product_id
  LEFT JOIN product_variants pv ON oi.variant_id = pv.variant_id
  LEFT JOIN payment_methods pm ON o.payment_method_id = pm.payment_method_id
  LEFT JOIN measurements m ON p.measurement_id = m.measurement_id	
  WHERE o.order_id = $1
  GROUP BY o.order_id, pm.method_name, pm.payment_intraduction
  `;

    try {
        const result = await pool.query(query, [orderId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        return res.status(200).json({ order: result.rows[0] });

    } catch (err) {
        console.error('Error fetching order:', err);
        return res.status(500).json({ message: "Server error" });
    }
}








// strip create process
const createSession = async (req, res) => {
    try {
        const { order_id } = req.body;

        const orderQuery = `SELECT full_amount, total_value, transaction_fee, currency  FROM orders WHERE order_id = $1`
        const payHereQuery = `SELECT payment_method_id,method_name,api_array, commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE 	payment_method_id = 2`

        const [payHereResult, order] = await Promise.all([
            pool.query(payHereQuery),
            pool.query(orderQuery, [order_id])
        ])

        if (payHereResult.rows.length === 0 || order.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }


        let amount = 0

        if (payHereResult.rows[0].commission_status === false) {
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee
        } else {
            const item_total = parseFloat(order.rows[0].full_amount || 0);
            const transaction_fixed_fee = parseFloat(payHereResult.rows[0].transaction_fixed_fee || 0);
            const transaction_fee = parseFloat(payHereResult.rows[0].transaction_fee || 0);

            const current_transaction_fee = (item_total * transaction_fee / 100) + transaction_fixed_fee
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee + current_transaction_fee
        }

        amount = parseFloat(amount).toFixed(2);
        const currency = order.rows[0].currency
        //........................................................................................

        const amountInCents = toStripeAmount(amount, currency)

        // Enforce Stripe minimum (~50 cents USD) ≈ LKR 160.00
        const minimumLkrAmount = 200 * 100;
        const finalAmount = Math.max(amountInCents, minimumLkrAmount);

        const [stripe, publishableKey] = await Promise.all([
            getStripeInstance(),
            getStripeFrontendKey()
        ])

        const paymentIntent = await stripe.paymentIntents.create({
            amount: finalAmount, // in cents (e.g., $10 = 1000)
            currency: currency.toLowerCase(),
            automatic_payment_methods: { enabled: true },
            metadata: { order_id },
        });

        res.send({ clientSecret: paymentIntent.client_secret, publishableKey: publishableKey });
    } catch (err) {
        console.error('Stripe Error:', err);
        res.status(500).send({ error: err.message });
    }


}

//update payment status
const updatepayment = async (req, res) => {
    try {
        console.log("first", req.body);
        const { order_id, payhere_amount, payhere_currency, merchant_id, status_code, md5sig, payment_id } = req.body;
        const payHereQuery = `SELECT payment_method_id,method_name,api_array FROM payment_methods WHERE LOWER(method_name) = 'payhere' AND status = 'active'`
        const systemSettingQuery = `SELECT loyalty_point, points_given, amount_spend FROM system_settings WHERE id = 1`

        const payHereResult = await pool.query(payHereQuery)

        if (payHereResult.rows.length === 0) {
            return res.status(404).json({ message: "Payment method not found" });
        }

        const payhere = payHereResult.rows[0].api_array

        const merchant_secret = payhere.merchantSecret

        const md5_merchant_secret = crypto
            .createHash('md5')
            .update(merchant_secret)
            .digest('hex')
            .toUpperCase();

        console.log(merchant_secret)
        console.log(merchant_id, Number(order_id), payhere_amount, payhere_currency)

        // Step 2: Concatenate as required by PayHere
        const hashString = merchant_id + Number(order_id) + payhere_amount + payhere_currency + status_code + md5_merchant_secret;

        // Step 3: Create the final hash (must be uppercase)
        const local_md5sig = crypto
            .createHash('md5')
            .update(hashString)
            .digest('hex')
            .toUpperCase();

        console.log("one", local_md5sig)
        console.log("second", md5sig)

        // Step 4: Compare md5sig to local_md5sig
        if (md5sig !== local_md5sig || status_code !== '2') {
            console.log("Invalid signature")
            return res.status(400).json({ message: "Invalid signature" });
        }

        const query = `SELECT o.order_id, o.full_amount, o.total_value, o.transaction_fee   
                              FROM orders o WHERE order_id = $1`;
        const paymentQuery = `SELECT commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE payment_method_id = 1`;

        const [order, payment] = await Promise.all([
            pool.query(query, [order_id]),
            pool.query(paymentQuery),
        ])

        if (order.rows.length === 0 || payment.rows.length === 0) {
            return res.status(404).json({ error: "Order not found" });
        }

        let amount = 0
        let current_transaction_fee = 0

        if (payment.rows[0].commission_status === false) {
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee
        } else {
            const item_total = parseFloat(order.rows[0].full_amount  || 0);
            const transaction_fixed_fee = parseFloat(payment.rows[0].transaction_fixed_fee || 0);
            const transaction_fee = parseFloat(payment.rows[0].transaction_fee || 0);

            current_transaction_fee = (item_total * transaction_fee / 100) + transaction_fixed_fee
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee + current_transaction_fee
        }


        const orderQuery = `UPDATE orders SET payment_status = 'paid', payment_method_id = $1, cod = false, payment_id = $2, amount_paid = $3, full_amount = $4, transaction_fee = $5 WHERE order_id = $6 RETURNING full_amount, customer_id`
        const orderItemsQuery = `SELECT variant_id, quantity, free_quantity FROM order_items WHERE order_id = $1`
        const updateAccount = `UPDATE accounts SET balance = balance + $1 WHERE id = 5`

        const [orderResult, orderItemsResult, systemSettingsResult, Resultaccount] = await Promise.all([
            pool.query(orderQuery, [1, payment_id, amount, amount, current_transaction_fee, Number(order_id)]),
            pool.query(orderItemsQuery, [Number(order_id)]),
            pool.query(systemSettingQuery),
            pool.query(updateAccount, [amount])
        ])


        if (orderResult.rowCount === 0 || orderItemsResult.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const system_settings = systemSettingsResult?.rows?.[0] || {};

        const fullAmount = orderResult.rows[0].full_amount;

        const customer_id = orderResult.rows[0].customer_id

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        const points_given = parseFloat(system_settings.points_given) || 0
        const amount_spend = parseFloat(system_settings.amount_spend) || 0

        if (loyalty_point) {
            const orderPerPoint = fullAmount / amount_spend
            loyalty_points_earned = orderPerPoint * points_given
        }

        const orderItems = orderItemsResult.rows;

        const orderloyaltyEarnQuery = `UPDATE orders SET loyalty_points_earned = $1 WHERE order_id = $2`
        const [orderloyaltyEarnResult, sales_channel] = await Promise.all([
            pool.query(orderloyaltyEarnQuery, [loyalty_points_earned, Number(order_id)]),
            getOutletId()
        ])

        if (loyalty_point) {
            await addLoyalty(customer_id, loyalty_points_earned)
        }
        res.status(200).json({ message: "Payment status updated successfully" });

    } catch (err) {
        console.error('Stripe Error:', err);
        res.status(500).send({ error: err.message });
    }


}


// const merchant_secret = 'MzU3MjU0NDg0Mjg3NTkxOTM4MTUwNDE4NDU1MzM5NTAyMTE0MjY='
// const merchant_id = '1231430'
const payhereHash = async (req, res) => {
    try {
        const { order_id } = req.body;

        const orderQuery = `SELECT full_amount, total_value, transaction_fee  FROM orders WHERE order_id = $1`
        const payHereQuery = `SELECT payment_method_id,method_name,api_array, commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE LOWER(method_name) = 'payhere' AND status = 'active'`
        const systemSettingQuery = `SELECT currency FROM system_settings WHERE id = 1`

        const [payHereResult, systemSettingResult, order] = await Promise.all([
            pool.query(payHereQuery),
            pool.query(systemSettingQuery),
            pool.query(orderQuery, [order_id])
        ])

        if (payHereResult.rows.length === 0 || systemSettingResult.rows.length === 0 || order.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }


        let amount = 0

        if (payHereResult.rows[0].commission_status === false) {
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee
        } else {
            const item_total = parseFloat(order.rows[0].full_amount || 0);
            const transaction_fixed_fee = parseFloat(payHereResult.rows[0].transaction_fixed_fee || 0);
            const transaction_fee = parseFloat(payHereResult.rows[0].transaction_fee || 0);

            const current_transaction_fee = (item_total * transaction_fee / 100) + transaction_fixed_fee
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee + current_transaction_fee
        }

        amount = parseFloat(amount).toFixed(2);

        const currency = systemSettingResult.rows[0].currency
        const payhere = payHereResult.rows[0].api_array

        const merchant_id = payhere.merchant_id
        const merchant_secret = payhere.merchantSecret
        const sandbox = payhere.sandbox

        console.log(systemSettingResult.rows[0])
        console.log(merchant_secret)

        // Step 1: Create md5 of merchant_secret (must be uppercase)
        const md5_merchant_secret = crypto
            .createHash('md5')
            .update(merchant_secret)
            .digest('hex')
            .toUpperCase();

        // Step 2: Concatenate as required by PayHere
        const hashString = merchant_id + order_id + amount + currency + md5_merchant_secret;

        // Step 3: Create the final hash (must be uppercase)
        const local_md5sig = crypto
            .createHash('md5')
            .update(hashString)
            .digest('hex')
            .toUpperCase();

        return res.status(200).json({
            local_md5sig,
            merchant_id,
            currency,
            sandbox,
            amount
        });
    } catch (err) {
        console.error('Stripe Error:', err);
        res.status(500).send({ error: err.message });
    }
};

const allOrder = async (req, res) => {

    const user = req.user
    const user_id = user.user_id

    const page = parseInt(req.query.page) || 1;
    const limit = 25
    const offset = (page - 1) * limit;

    try {
        const orderStatusQuery = `
            SELECT 
                COUNT(*) AS total,
                COUNT(*) FILTER (WHERE order_status = 'pending') AS pending,
                COUNT(*) FILTER (WHERE order_status = 'confirmed') AS confirmed,
                COUNT(*) FILTER (WHERE order_status = 'completed') AS completed
            FROM orders WHERE customer_id = $1;
        `;

        const orderQuesry = `SELECT
                    o.order_id,
                    o.order_status,
                    o.created_at,
                    o.full_amount
                    FROM orders o
                    WHERE o.customer_id = $1
                    ORDER BY o.created_at DESC LIMIT $2 OFFSET $3;
`
        const countQuery = `SELECT COUNT(*) FROM orders WHERE customer_id = $1`

        const [orderStatusResult, orderResult, countResult] = await Promise.all([
            pool.query(orderStatusQuery, [user_id]),
            pool.query(orderQuesry, [user_id, limit, offset]),
            pool.query(countQuery, [user_id])

        ])

        const total = Math.ceil(parseInt(countResult.rows[0].count) / limit)

        const encryptedOrders = orderResult.rows.map((order) => ({
            ...order,
            order_id: encryptId(order.order_id),
            id: order.order_id
        }));

        return res.status(200).json({ orderStatus: orderStatusResult.rows[0], order: encryptedOrders, total: total });


    } catch (error) {
        console.error('Stripe Error:', error);
        res.status(500).send({ error: error.message });
    }
}

// POST /api/orders/mark-paid
const stripePaid = async (req, res) => {
    const { order_id, payment_intent_id } = req.body;
    try {

        if (!order_id || !payment_intent_id) return res.status(400).json({ message: 'Missing params' });

        // Verify with Stripe (prevents client spoofing)
        const stripe = await getStripeInstance()

        const pi = await stripe.paymentIntents.retrieve(payment_intent_id);
        console.log(pi)
        if (pi.status !== 'succeeded') {
            return res.status(400).json({ message: 'Payment not successful' });
        }

        // Optional: cross-check PI metadata.order_id === order_id
        if (pi.metadata?.order_id && String(pi.metadata.order_id) !== String(order_id)) {
            return res.status(400).json({ message: 'Order mismatch' });
        }


        const query = `SELECT o.order_id, o.full_amount, o.total_value, o.transaction_fee   
                              FROM orders o WHERE order_id = $1`;
        const paymentQuery = `SELECT commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE payment_method_id = 2`;

        const [order, payment] = await Promise.all([
            pool.query(query, [order_id]),
            pool.query(paymentQuery),
        ])

        if (order.rows.length === 0 || payment.rows.length === 0) {
            return res.status(404).json({ error: "Order not found" });
        }

        let amount = 0
        let current_transaction_fee = 0

        if (payment.rows[0].commission_status === false) {
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee
        } else {
            const item_total = parseFloat(order.rows[0].full_amount || 0);
            const transaction_fixed_fee = parseFloat(payment.rows[0].transaction_fixed_fee || 0);
            const transaction_fee = parseFloat(payment.rows[0].transaction_fee || 0);

            current_transaction_fee = (item_total * transaction_fee / 100) + transaction_fixed_fee
            amount = order.rows[0].full_amount - order.rows[0].transaction_fee + current_transaction_fee
        }

        const orderQuery = `UPDATE orders SET payment_status = 'paid', payment_method_id = $1, cod = false, payment_id = $2, amount_paid = $3, full_amount = $4, transaction_fee = $5 WHERE order_id = $6 RETURNING full_amount, customer_id`
        const orderItemsQuery = `SELECT variant_id, quantity, free_quantity FROM order_items WHERE order_id = $1`
        const systemSettingQuery = `SELECT loyalty_point, points_given, amount_spend FROM system_settings WHERE id = 1`
        const updateAccount = `UPDATE accounts SET balance = balance + $1 WHERE id = 6`

        const [orderResult, orderItemsResult, systemSettingsResult] = await Promise.all([
            pool.query(orderQuery, [2, payment_intent_id, amount, amount, current_transaction_fee, Number(order_id)]),
            pool.query(orderItemsQuery, [Number(order_id)]),
            pool.query(systemSettingQuery),
            pool.query(updateAccount, [amount])
        ])


        if (orderResult.rowCount === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const system_settings = systemSettingsResult?.rows?.[0] || {};

        const fullAmount = orderResult.rows[0].full_amount;

        const customer_id = orderResult.rows[0].customer_id

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        const points_given = parseFloat(system_settings.points_given) || 0
        const amount_spend = parseFloat(system_settings.amount_spend) || 0

        if (loyalty_point) {
            const orderPerPoint = fullAmount / amount_spend
            loyalty_points_earned = orderPerPoint * points_given
        }

        const orderloyaltyEarnQuery = `UPDATE orders SET loyalty_points_earned = $1 WHERE order_id = $2`
        const [orderloyaltyEarnResult, sales_channel] = await Promise.all([
            pool.query(orderloyaltyEarnQuery, [loyalty_points_earned, Number(order_id)]),
            getOutletId()
        ])

        if (loyalty_point) {
            await addLoyalty(customer_id, loyalty_points_earned)
        }

        res.status(200).json({ message: "Payment status updated successfully" });

    } catch (error) {
        console.error('Stripe Error:', error);
        res.status(500).send({ error: error.message });
    }
}

module.exports = {
    addOrder, guestAddOrder, oneOrder, createSession, updatepayment, payhereHash, allOrder, stripePaid
}






