const pool = require("../../config/db");
const axios = require("axios"); // if not already globally used
const { sendEmailWithPostmark,  getemailsettings } = require("../../common/emailTemplate"); // you already have this
const { insertClientLog } = require("../../models/commonQuery");


function escapeHtml(s = "") {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function getContactEmailHtml({ branding = {}, name, email, subject, message }) {
  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;color:#222;line-height:1.5">
      <h2 style="margin:0 0 10px">New contact form message</h2>
      <p><strong>From:</strong> ${escapeHtml(name)} &lt;${escapeHtml(
    email
  )}&gt;</p>
      <p><strong>Subject:</strong> ${escapeHtml(subject)}</p>
      <hr style="border:none;border-top:1px solid #eee;margin:12px 0"/>
      <div style="white-space:pre-wrap">${escapeHtml(message)}</div>
      <hr style="border:none;border-top:1px solid #eee;margin:12px 0"/>
      <p style="color:#666;margin-top:8px">
        ${escapeHtml(branding.company_name || "")}${
    branding.hotline ? " • Hotline: " + escapeHtml(branding.hotline) : ""
  }
      </p>
    </div>
  `;
}

exports.sendContactMessage = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body || {};

    // very light validation
    if (!name || !email || !subject || !message) {
      return res
        .status(400)
        .json({ error: "name, email, subject and message are required" });
    }

    // 0) feature flag
    const globalstatus = await pool.query(
      "SELECT email_notification_status FROM system_settings LIMIT 1"
    );
    if (globalstatus.rows[0]?.email_notification_status !== "enabled") {
      return res
        .status(200)
        .json({
          ok: true,
          skipped: true,
          reason: "email notifications disabled",
        });
    }

    // 1) branding (to get support_email fallback)
    const brandingResult = await pool.query(
      "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
    );
    const branding = brandingResult.rows[0] ?? {};

    const supportEmail = branding.support_email; // who receives the message
    if (!supportEmail) {
      return res.status(500).json({ error: "support email is not configured" });
    }

    // 2) email settings (from + token)
    const settings = await getemailsettings ();
    const fromEmail = settings?.billing_email; // your verified sender
    const postmarkToken = settings?.postmark_server_token; // server token

    if (!fromEmail || !postmarkToken) {
      return res.status(500).json({ error: "email settings not configured" });
    }

    // 3) build html
    const html = getContactEmailHtml({
      branding,
      name,
      email,
      subject,
      message,
    });

    // 4) send — reply-to is the visitor, so your team can reply directly
    await sendEmailWithPostmark(
      supportEmail,
      `[Contact] ${subject}`,
      html,
      postmarkToken,
      fromEmail
    );

    // (optional) you can also send an auto-reply to the visitor. uncomment if needed:
    await sendEmailWithPostmark(
      email,
      `We received your message: ${subject}`,
      `<p>Hi ${escapeHtml(name)},</p><p>Thanks for contacting ${escapeHtml(
        branding.company_name || "us"
      )}! Our team will reply soon.</p>`,
      postmarkToken,
      fromEmail
    );

    const title = `Contact: ${subject}`;
    const log = `${name} - ${email} - ${subject} - ${message}`;
    await insertClientLog(null, title, log);
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error("sendContactMessage error:", err);
    return res.status(500).json({ error: "failed to send contact message" });
  }
};
