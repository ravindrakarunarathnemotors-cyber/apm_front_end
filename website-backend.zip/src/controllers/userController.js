const User = require("../models/userModels");
const pool = require("../config/db");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
const { formatPhoneNumber, insertClientLog } = require("../models/commonQuery");
require("dotenv").config();
const axios = require("axios");
const { generateOtp } = require("../common/common");
const { customhook } = require("../common/emailTemplate");

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const userQuery = `SELECT password,customer_id, first_name, last_name, email, contact_number_1, address, guest FROM customer WHERE email = $1`;
    const userResult = await pool.query(userQuery, [email]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    const user = userResult.rows[0];

    if (!user.password) {
      const hash = await bcrypt.hash(password, saltRounds);
      return res.status(404).json({ message: "password not found", hash });
    }

    // Verify password using bcrypt
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(401).json({ message: "Incorrect password" }); // Use 401

    // Remove password before returning user data
    delete user.password;

    const accessToken = jwt.sign(
      { user_id: user.customer_id },
      process.env.ACCESS_TOKEN_SECRET
    );

    const title = "Login (Email & Password)";
    const log = `${user.first_name} ${user.last_name} - (UserId: ${user.customer_id}) logged in successfully.`;
    await insertClientLog(user.customer_id, title, log);

    res.status(200).json({
      message: "Login Successful",
      user: user,
      accessToken: accessToken,
    });

    if (user.guest) {
      const updateGuestQuery = `UPDATE customer SET guest = $1 WHERE customer_id = $2`;
      await pool.query(updateGuestQuery, [false, user.customer_id]);
    }

  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const register = async (req, res, next) => {
  const { email, password, name, lastName, number, city, address, country } =
    req.body;

  try {
    const mobileNew = formatPhoneNumber(number);
    if (mobileNew.error) {
      return res.status(400).json({ message: mobileNew.error });
    }

    const formattedPhone = mobileNew.formatted;

    const conditions = [];
    const params = [];

    // Normalize email
    const normalizedEmail = email ? String(email).trim().toLowerCase() : null;

    // Add conditions **before building query**
    if (normalizedEmail) {
      params.push(normalizedEmail);
      conditions.push(`LOWER(TRIM(email)) = $${params.length}`);
    }
    if (formattedPhone) {
      params.push(formattedPhone);
      conditions.push(`contact_number_1 = $${params.length}`);
    }

    // Ensure at least one condition
    if (conditions.length === 0) {
      return res.status(400).json({ message: "Email or Contact number is required" });
    }

    // Build final query AFTER conditions are added
    const userCheckQuery = `SELECT * FROM customer WHERE ${conditions.join(' OR ')}`;

    // Execute
    const userCheckResult = await pool.query(userCheckQuery, params);

    if (userCheckResult.rows.length > 0) {
      return res.status(400).json({ message: "User already exists" });
    }

    console.log(formattedPhone);

    const hash = await bcrypt.hash(password, saltRounds);

    const insertQuery = `
         INSERT INTO customer (email, password, first_name, last_name, contact_number_1, address, city, country)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING customer_id
       `;
    const result = await pool.query(insertQuery, [
      email,
      hash,
      name,
      lastName,
      formattedPhone,
      address,
      city,
      country,
    ]);

    if (result.rowCount > 0) {
      const user = result.rows[0].customer_id;
      const accessToken = jwt.sign(
        { user_id: user },
        process.env.ACCESS_TOKEN_SECRET
      );

      const title = "Registration (Email & Password)";
      const log = `${name} ${lastName} - (UserId: ${user}) registered successfully.`;
      await insertClientLog(user, title, log);

      return res.status(200).json({
        message: "User registered successfully",
        accessToken: accessToken,
      });
    } else {
      return res.status(500).json({ message: "User registration failed" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: error });
  }
};

const userDetails = async (req, res) => {
  try {
    const user = req.user;
    const user_id = user.user_id;
    const userQuery = `SELECT customer_id, first_name, last_name, email, contact_number_1, address, city, postal_code, country, loyalty_point FROM customer WHERE customer_id = $1`;
    const userResult = await pool.query(userQuery, [user_id]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    return res
      .status(200)
      .json({ message: "User details", result: userResult.rows[0] });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const updateUserDetails = async (req, res) => {
  try {
    const { name, phone, email, lastName, address, city, country } = req.body;
    const user_id = req.user?.user_id;

    // 1) Validate & normalize phone
    const mobileNew = formatPhoneNumber(phone);
    if (mobileNew.error) {
      return res.status(400).json({ message: mobileNew.error });
    }
    const formattedPhone = mobileNew.formatted;

    // 2) Fetch current values to compute a diff
    const selectSql = `
      SELECT first_name, last_name, email, contact_number_1, address, city, country
      FROM customer
      WHERE customer_id = $1
      LIMIT 1
    `;
    const { rows } = await pool.query(selectSql, [user_id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }
    const current = rows[0];

    // 3) Build "after" payload (what we'll write)
    const after = {
      first_name: name,
      last_name: lastName,
      email,
      contact_number_1: formattedPhone,
      address,
      city,
      country,
    };

    // 4) Compute changes (before → after)
    const labelMap = {
      first_name: "First Name",
      last_name: "Last Name",
      email: "Email",
      contact_number_1: "Phone",
      address: "Address",
      city: "City",
      country: "Country",
    };

    const changes = Object.keys(after).reduce((acc, key) => {
      const beforeVal = (current[key] ?? "").toString().trim();
      const afterVal = (after[key] ?? "").toString().trim();
      if (beforeVal !== afterVal) {
        acc.push(`${labelMap[key]}: "${beforeVal}" → "${afterVal}"`);
      }
      return acc;
    }, []);

    // 5) Perform UPDATE (use the normalized phone!)
    const updateSql = `
      UPDATE customer
      SET first_name = $1, last_name = $2, email = $3, contact_number_1 = $4,
          address = $5, city = $6, country = $7
      WHERE customer_id = $8
    `;
    const params = [
      after.first_name,
      after.last_name,
      after.email,
      after.contact_number_1,
      after.address,
      after.city,
      after.country,
      user_id,
    ];
    const result = await pool.query(updateSql, params);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    // 6) Log with updated values
    const title = "Update User Details";
    const who = `${after.first_name || name || ""} ${after.last_name || lastName || ""
      }`.trim();
    const changeSummary = changes.length
      ? ` Changes: ${changes.join("; ")}`
      : " No field changes.";
    const log = `${who} (UserId: ${user_id}) updated their account details.${changeSummary}`;
    await insertClientLog(user_id, title, log);

    return res.status(200).json({
      message: "User details updated",
      updatedFields: changes, // optional: return what changed
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const changePassword = async (req, res) => {
  try {
    const { password, newPassword, confirmPassword } = req.body;
    const user = req.user;
    const user_id = user.user_id;

    const userQuery = `SELECT * FROM customer WHERE customer_id = $1`;
    const userResult = await pool.query(userQuery, [user_id]);

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    const userDetails = userResult.rows[0];

    // Verify password using bcrypt
    const isMatch = await bcrypt.compare(password, userDetails.password);
    if (!isMatch)
      return res.status(404).json({ message: "Incorrect password" });

    // Hash the new password before updating it
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

    const result = await pool.query(
      `UPDATE customer 
          SET password = $1 
          WHERE customer_id = $2`,
      [hashedPassword, user_id]
    );

    if (result.rowCount > 0) {

      const title = "Change Password";
      const who = `${userDetails.first_name || ""} ${userDetails.last_name || ""
        }`.trim();
      const log = `${who} (UserId: ${user_id}) changed their password.`;
      await insertClientLog(user_id, title, log);
      return res.status(200).json({ message: "Password updated successfully" });
    } else {
      return res.status(404).json({ message: "User not found" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const googleLogin = async (req, res) => {
  try {
    const { token } = req.body;

    console.log(token);
    const googleRes = await axios.get(
      `https://www.googleapis.com/oauth2/v3/tokeninfo?id_token=${token}`
    );
    const { email, name, picture, sub: googleId } = googleRes.data;
    // console.log(googleRes)

    const userQuery = `SELECT customer_id, email, first_name, last_name, contact_number_1, address FROM customer WHERE email = $1`;
    const userResult = await pool.query(userQuery, [email]);

    if (userResult.rows.length === 0) {
      const insertQuery = `INSERT INTO customer ( first_name, last_name, email, picture) VALUES ($1, $2, $3, $4) RETURNING *`;

      const result = await pool.query(insertQuery, [
        name.split(" ")[0],
        name.split(" ")[1],
        email,
        picture,
      ]);
      const user_id = result.rows[0].customer_id;

      delete result.rows[0].password;

      const accessToken = jwt.sign(
        { user_id: user_id },
        process.env.ACCESS_TOKEN_SECRET
      );

      const title = "Create & Login (Google Account)";
      const log = `Created New User ${name} - (UserId: ${user_id}) logged in successfully.`;
      await insertClientLog(user_id, title, log);

      return res.status(200).json({
        message: "Login Successful",
        user: result.rows[0],
        accessToken: accessToken,
      });
    } else {
      const user = userResult.rows[0];

      const accessToken = jwt.sign(
        { user_id: user.customer_id },
        process.env.ACCESS_TOKEN_SECRET
      );

      const title = "Login (Google Account)";
      const log = `${user.first_name} ${user.last_name} - (UserId: ${user.customer_id}) logged in successfully.`;
      await insertClientLog(user.customer_id, title, log);
      return res.status(200).json({
        message: "Login Successful",
        user: user,
        accessToken: accessToken,
      });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Server error" });
  }
};

//all web pages
const getPageContent = async (req, res) => {
  try {
    const query = `SELECT * FROM web_pages WHERE status = 'active'`;
    const result = await pool.query(query);
    console.log("result", result.rows);
    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error("Error fetching web page list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const createOtp = async (req, res) => {
  try {
    const { verifyEmail } = req.body;

    const otp = generateOtp();
    const expires = new Date(Date.now() + 5 * 60 * 1000);

    const query = `UPDATE customer SET otp = $1, expire_at = $2 WHERE email = $3 RETURNING first_name, last_name`;
    const result = await pool.query(query, [otp, expires, verifyEmail]);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "User not found" });
    }
    const name = result.rows[0].first_name + " " + result.rows[0].last_name;
    try {
      const res = await customhook(name, otp, verifyEmail);
      console.log(res);
    } catch (error) {
      console.log(error);
    }
    // console.log("result", result.rows);
    const title = "OTP Created";
    const log = `${name} - (UserId: ${result.rows[0].customer_id}) OTP created successfully.`;
    await insertClientLog(result.rows[0].customer_id, title, log);
    return res.status(200).json({
      message: "We sent a code to your email. It expires in 5 minutes.",
    });
  } catch (err) {
    console.error("Error fetching web page list:", err);
    res.status(500).json({ error: "Internal server error", err });
  }
};

const forgetpassowrd = async (req, res) => {
  const client = await pool.connect();
  try {
    const { email, otp, password } = req.body;

    if (!email || !otp || !password) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    await client.query("BEGIN");

    // 1. Get OTP record from customer table
    const otpRes = await client.query(
      `SELECT otp, expire_at FROM customer WHERE email = $1`,
      [email]
    );

    if (otpRes.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Invalid email" });
    }

    const otpRow = otpRes.rows[0];
    const now = new Date();
    const expiresAt = new Date(otpRow.expire_at);

    // 2. OTP match check
    if (otpRow.otp !== otp) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Invalid OTP" });
    }

    // 3. Expiration check
    if (now > expiresAt) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "OTP expired" });
    }

    // 4. Hash new password
    const hashedPassword = await bcrypt.hash(password, 10);

    // 5. Update password & clear OTP
    await client.query(
      `UPDATE customer 
       SET password = $1, otp = NULL, expire_at = NULL 
       WHERE email = $2`,
      [hashedPassword, email]
    );

    await client.query("COMMIT");
    const title = "Password Reset";
    const log = `${email} - (UserId: ${email}) password reset successfully.`;
    await insertClientLog(email, title, log);
    res.json({ message: "Password reset successful" });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Reset password error:", err);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    client.release();
  }
};

module.exports = {
  login,
  register,
  userDetails,
  updateUserDetails,
  changePassword,
  googleLogin,
  getPageContent,
  createOtp,
  forgetpassowrd,
};
