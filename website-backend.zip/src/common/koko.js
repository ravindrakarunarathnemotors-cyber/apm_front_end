// koko.js
// This file does all the Koko-specific work:
//   1. Builds the dataString (the exact order Koko requires)
//   2. Signs the dataString using your RSA private key
//   3. Verifies Koko's callback signature using Koko's public key

const crypto = require("crypto");
require("dotenv").config();
const pool = require("../config/db");
const { addSystemLogs } = require("./common");


// Which Koko server URL to use based on your .env KOKO_ENV setting
function getKokoBaseUrl(kokoDetails) {
  const env = kokoDetails ? kokoDetails.base_url : 'qa'
  if (env === "production") return "https://prodapi.paykoko.com";
  if (env === "qa") return "https://qaapi.paykoko.com";
  return "https://devapi.paykoko.com"; // default: dev
}

// Build the dataString
// IMPORTANT: Koko requires these fields joined together in THIS exact order
// Do NOT change the order
function buildDataString(data) {
  return (
    data.mId +
    data.amount +
    data.currency +
    data.pluginName +
    data.pluginVersion +
    data.returnUrl +
    data.cancelUrl +
    data.orderId +
    data.reference +
    data.firstName +
    data.lastName +
    data.email +
    data.description +
    data.apiKey +
    data.responseUrl
  );
}

// Sign the dataString using your RSA private key
// This proves to Koko that the request came from you
function signData(dataString, kokoDetails) {
  const privateKey = kokoDetails ? kokoDetails.private_key.replace(/\\n/g, "\n") : '';
  // console.log("kokoDetails", kokoDetails)
  const sign = crypto.createSign("SHA256");
  sign.update(dataString, "utf8");
  sign.end();
  return sign.sign(privateKey, "base64");
}

// Verify that a callback from Koko is genuine
// Koko signs: orderId + trnId + status  using their private key
// We check it using Koko's public key (which Koko gave us)
async function verifyKokoSignature(orderId, trnId, status, signature) {
  const paymentQuery = `SELECT api_array FROM payment_methods WHERE payment_method_id = 10`;
  try {

    const payment = await pool.query(paymentQuery)

    if (payment.rows.length === 0) {
      console.log("Payment method not found");
      await addSystemLogs("Payment method not found", "koko")
      return false
    }

    const kokoDetails = payment.rows[0].api_array

    const publicKey = kokoDetails ? kokoDetails.public_key.replace(/\\n/g, "\n") : ''
    const dataString = orderId + trnId + status;
    const verify = crypto.createVerify("SHA256");
    verify.update(dataString, "utf8");
    verify.end();

    return verify.verify(publicKey, signature, "base64");

  } catch (error) {
    console.log(error);
    const er = JSON.stringify(error.message)
    await addSystemLogs(er, "koko")
    return false
  }

  // const publicKey = process.env.KOKO_PUBLIC_KEY;
  // const dataString = orderId + trnId + status;
  // const verify = crypto.createVerify("SHA256");
  // verify.update(dataString, "utf8");
  // verify.end();
  // try {
  //   return verify.verify(publicKey, signature, "base64");
  // } catch (err) {
  //   // If anything goes wrong, treat as invalid
  //   return false;
  // }
}

// Build the full payload that gets sent to Koko's orderCreate endpoint
// Takes your order info, builds dataString, signs it, returns everything ready to POST
function buildKokoPayload(orderInfo) {
  const kokoDetails = orderInfo.kokoDetails
  const mId = kokoDetails ? kokoDetails.merchant_id : ''
  const apiKey = kokoDetails ? kokoDetails.api_key : ''
  const serverUrl = process.env.SERVER_URL;
  const frontendUrl = process.env.FRONTEND_URL;

  // console.log(orderInfo.kokoDetails)
  // console.log(apiKey)
  // console.log(serverUrl)

  // These are the 3 URLs Koko will call/redirect to after payment
  const returnUrl = `${serverUrl}/koko/return?orderId=${orderInfo.orderId}`;
  const cancelUrl = `${serverUrl}/koko/cancel?orderId=${orderInfo.orderId}`;
  const responseUrl = `${serverUrl}/koko/response`;

  // Build and sign the dataString
  const dataString = buildDataString({
    mId,
    amount: String(orderInfo.amount),
    currency: orderInfo.currency || "LKR",
    pluginName: "customapi",
    pluginVersion: "1.0.0",
    returnUrl,
    cancelUrl,
    orderId: String(orderInfo.orderId),
    reference: String(orderInfo.reference || orderInfo.orderId),
    firstName: orderInfo.firstName,
    lastName: orderInfo.lastName,
    email: orderInfo.email,
    description: orderInfo.description || "",
    apiKey,
    responseUrl,
  });

  const signature = signData(dataString, kokoDetails);
  // console.log("signature", signature)

  // Return the complete object ready to POST to Koko
  return {
    _mId: mId,
    api_key: apiKey,
    _returnUrl: returnUrl,
    _cancelUrl: cancelUrl,
    _responseUrl: responseUrl,
    _amount: String(orderInfo.amount),
    _currency: orderInfo.currency || "LKR",
    _reference: String(orderInfo.reference || orderInfo.orderId),
    _orderId: String(orderInfo.orderId),
    _pluginName: "customapi",
    _pluginVersion: "1.0.0",
    _description: orderInfo.description || "",
    _firstName: orderInfo.firstName,
    _lastName: orderInfo.lastName,
    _email: orderInfo.email,
    dataString,
    signature,
    _mobileNo: String(orderInfo.phone),
  };
}

module.exports = { getKokoBaseUrl, buildKokoPayload, verifyKokoSignature };