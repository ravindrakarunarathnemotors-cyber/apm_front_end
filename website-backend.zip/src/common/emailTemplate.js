const https = require("https");
const pool = require("../config/db");
const axios = require("axios");


const insertemaillog = async (email, msg, subject, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_email_temp_log (email, msg, status, date, sentdate, action,subject) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3, $4) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [email, msg, action, subject]);

        return result.rows[0]; // Return inserted row with ID
    } catch (error) {
        console.error("❌ Error inserting email log:", error);
        throw error;
    }
};



// ****************************************************************************************************************************************************
//email Function start from here

//send email
async function sendEmailWithPostmark(to, subject, message, apiToken, fromEmail) {

    if (!apiToken) {
        console.error("Error: Postmark API token is missing.");
        return "Postmark API token is not configured.";
    }

    const postData = {
        "From": fromEmail,
        "To": to,
        "Subject": subject,
        "HtmlBody": message,
        "MessageStream": "outbound" // Default message stream for transactional emails
    };

    try {
        const response = await axios.post("https://api.postmarkapp.com/email", postData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        });

        console.log("Email sent successfully:", response.data);
        return response.data; // Return full Postmark response
    } catch (error) {
        console.error("Error sending email:", error.response ? error.response.data : error.message);
        return `Error sending email: ${error.response ? JSON.stringify(error.response.data) : error.message}`;
    }
}

//email html
async function getEmailMsg(name, otpNumber) {
    try {


        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        return `
       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
    <!-- Header Section -->
    <div style="text-align: center; padding: 20px 0;">
        <img src="${branding.logo_url}" 
             alt="Logo" 
             style="max-width: 150px; margin-bottom: 10px;">
        <h2 style="color: #1a4e8a; margin: 0;">Password Reset Verification</h2>
    </div>

    <!-- Main Content -->
    <div style="
        background: #ffffff; 
        padding: 20px; 
        border-radius: 8px;  
        box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
        font-size: 16px; 
        color: #333; 
        text-align: center;
    ">
        <p style="margin-bottom: 10px;">Hello ${name},</p>
        <p style="margin-bottom: 20px;">
            We received a request to reset your password. Use the following One-Time Password (OTP) to proceed:
        </p>

        <p style="
            font-size: 24px; 
            font-weight: bold; 
            letter-spacing: 4px; 
            color: #1a4e8a; 
            background: #e6f0fb; 
            padding: 12px 24px; 
            display: inline-block; 
            border-radius: 6px;
        ">
            ${otpNumber}
        </p>

        <p style="margin-top: 20px; color: #555;">
            This OTP is valid for the next <strong>5 minutes</strong>.  
            If you did not request a password reset, please ignore this email.
        </p>
    </div>

    <!-- Contact Info -->
    <div style="margin-top: 20px; text-align: center;">
        <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>

        <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
            Hotline: ${branding.hotline || "[Your Hotline Number]"}
        </p>

        <p style="font-size: 16px;">
            Website: 
            <a href="${branding.website_url}" style="color:#1a4e8a; text-decoration: none;">
                ${branding.website_url}
            </a>
        </p>
    </div>

    <!-- Footer -->
    <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
        <p>Thank you for choosing <strong>${branding.company_name}</strong>.</p>
        <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
    </div>
</div>

        `;

    } catch (error) {
        console.error("Error generating email message:", error.message);
        return null;
    }
}



const getemailsettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                billing_email,
                postmark_server_token
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No email settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching email settings:", error);
        throw error;
    }
};




const sendemailtemp = async (name, otp, verifyEmail) => {
    try {

        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        console.log(globalstatus.rows[0])
        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 1. Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 2. Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;



        // 6. Generate HTML email body
        const emailHTML = await getEmailMsg(name, otp);


        // 8. Client Email
        if (billing_email && postmark_token) {
            try {
                const clientEmailResponse = await sendEmailWithPostmark(
                    verifyEmail,
                    "Password Reset OTP",
                    emailHTML,
                    postmark_token,
                    billing_email
                );
            } catch (err) {
                console.error(`❌ Failed to send email to client`, err);
            }
        }

        // 9. Final return
        return {
            message: "Email sent successfully",
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp:", error);
        return null;
    }
};



const customhook = async (name, otp, verifyEmail) => {
    try {

        const resemail = await sendemailtemp(name, otp, verifyEmail);

        // Optionally return results
        return {
            data: resemail
        };
    } catch (error) {
        console.error('Error in customhook:', error);
        throw error; // or handle it appropriately
    }
};


// guest registration email .......................................
const guestRegistration = async (email, password, full_name) => {
    try {
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        console.log(globalstatus.rows[0])
        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 1. Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 2. Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;



        // 6. Generate HTML email body
        const emailHTML = await getEmailGuestMail(email, password, full_name);

        console.log(email,
                    postmark_token,
                    billing_email)
        // 8. Client Email
        if (billing_email && postmark_token) {
            try {
                const clientEmailResponse = await sendEmailWithPostmark(
                    email,
                    "Account Details",
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                return {
                    message: "Email sent successfully",
                    clientEmailResponse
                };
            } catch (err) {
                console.error(`❌ Failed to send email to client`, err);
            }
        }

        // 9. Final return
        return {
            message: "Email sent successfully",
            branding
        };
    } catch (error) {
        console.error('Error in guestRegistration:', error);
        throw error; // or handle it appropriately
    }
};

async function getEmailGuestMail(email, password, full_name) {
    try {


        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        return `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
                    
                    <!-- Header Section -->
                    <div style="text-align: center; padding: 20px 0;">
                        <img src="${branding.logo_url}" 
                            alt="Logo" 
                            style="max-width: 150px; margin-bottom: 10px;">
                        <h2 style="color: #1a4e8a; margin: 0;">Welcome to ${branding.company_name}</h2>
                    </div>

                    <!-- Main Content -->
                    <div style="
                        background: #ffffff; 
                        padding: 20px; 
                        border-radius: 8px;  
                        box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                        font-size: 16px; 
                        color: #333; 
                        text-align: center;
                    ">
                        <p style="margin-bottom: 10px;">Hello <strong>${full_name}</strong>,</p>
                        <p style="margin-bottom: 20px;">
                            Your account has been successfully created on 
                            <strong>${branding.company_name}</strong>.
                        </p>

                        <p style="margin-bottom: 10px;">You can now log in using the following credentials:</p>

                        <div style="
                            background: #f4f8fc; 
                            padding: 15px; 
                            border-radius: 6px; 
                            display: inline-block; 
                            text-align: left; 
                            font-size: 15px; 
                            border: 1px solid #dce6f1;
                        ">
                            <p><strong>Username:</strong> ${email}</p>
                            <p><strong>Password:</strong> ${password}</p>
                        </div>

                        <p style="margin-top: 20px;">
                            You can access your account here:<br>
                            <a href="${branding.website_url}" 
                                style="display:inline-block; margin-top:10px; background:#1a4e8a; color:#fff; padding:10px 20px; border-radius:6px; text-decoration:none;">
                                Log in to Your Account
                            </a>
                        </p>

                        <p style="margin-top: 20px; font-size: 14px; color: #555;">
                            For your security, please change your password after your first login.
                        </p>
                    </div>

                    <!-- Contact Info -->
                    <div style="margin-top: 20px; text-align: center;">
                        <p style="color: #555; font-size: 14px;">
                            If you have any questions or need assistance, please don't hesitate to contact us:
                        </p>

                        <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
                            Hotline: ${branding.hotline || "[Your Hotline Number]"}
                        </p>

                        <p style="font-size: 16px;">
                            Website: 
                            <a href="${branding.website_url}" style="color:#1a4e8a; text-decoration: none;">
                                ${branding.website_url}
                            </a>
                        </p>
                    </div>

                    <!-- Footer -->
                    <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                        <p>Thank you for joining <strong>${branding.company_name}</strong>.</p>
                        <p>We’re excited to have you on board!</p>
                        <p>Warm regards,<br><strong>${branding.company_name} Team</strong></p>
                    </div>
                </div>
            `;


    } catch (error) {
        console.error("Error generating email message:", error.message);
        return null;
    }
}

// ..........................................................................................................



module.exports = { 
      // helpers you want to reuse elsewhere
  getemailsettings,
  sendEmailWithPostmark,
  getEmailMsg,
  insertemaillog,

  // optional higher-level flows
  sendemailtemp,
  customhook,
  guestRegistration
};
