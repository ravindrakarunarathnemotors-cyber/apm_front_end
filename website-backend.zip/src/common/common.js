const pool = require("../config/db");
const axios = require('axios');
require("dotenv").config();

//system settings
const systemSettings = async () => {
  try {
    const result = await pool.query('SELECT currency, tax_value, tax_on_web FROM system_settings WHERE id = 1');

    if (result.rows.length === 0) {
      throw new Error('System settings not found');
    }

    return result.rows[0];
  } catch (err) {
    console.error('Error fetching system settings:', err);
    throw new Error('Failed to fetch system settings');
  }
};

const allCountry = async (req, res) => {
  try {
    const result = await pool.query(`SELECT id, country_name FROM countries WHERE status = 'active'`);

    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error('Error fetching system settings:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch system settings' });
  }
};

const oneCountry = async (id) => {
  try {
    const result = await pool.query('SELECT country_name FROM countries WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      throw new Error('Country not found');
    }

    return result.rows[0].country_name;
  } catch (err) {
    console.error('Error fetching system settings:', err);
    throw new Error('Failed to fetch system settings');
  }
};

const getCategory = async (id) => {
  try {
    const allCategoryId = []

    const parentresult = await pool.query(
      `SELECT category_id, category_under FROM categories WHERE category_id = $1`,
      [id]
    );

    if (parentresult.rows.length === 0) {
      throw new Error('Category not found');
    }

    //category result 1st step
    const fisrt_st_level = parentresult.rows[0].category_under
    const first_level_id = parentresult.rows[0].category_id

    allCategoryId.push(first_level_id)
    if (!fisrt_st_level) {

      const subResult = await pool.query(
        `SELECT category_id FROM categories WHERE category_under = $1`,
        [first_level_id]
      );
      if (subResult.rows.length > 0) {
        const subCategoryId = subResult.rows.map(item => item.category_id)
        allCategoryId.push(...subCategoryId)

        // FIX: use = ANY($1::int[]) for array parameter
        const childResult = await pool.query(
          `SELECT category_id FROM categories WHERE category_under = ANY($1::int[])`,
          [subCategoryId]
        );
        if (childResult.rows.length > 0) {
          const subSubCategoryId = childResult.rows.map(item => item.category_id)
          allCategoryId.push(...subSubCategoryId)
        }
      }

      return allCategoryId
    }

    const subResult = await pool.query(
      `SELECT category_id FROM categories WHERE category_under = $1`,
      [first_level_id]
    );
    if (subResult.rows.length > 0) {
      const subCategoryId = subResult.rows.map(item => item.category_id)
      allCategoryId.push(...subCategoryId)
    }

    return allCategoryId
  } catch (err) {
    console.error('Error fetching category:', err);
    throw new Error('Failed to fetch category');
  }
};

const productCount = async (selectedCategoryId, priceValue, selectValue, status, collectionName) => {
  const minPrice = priceValue[0];
  const maxPrice = priceValue[1];

  try {
    // COUNT DISTINCT to avoid double-counting when joins create multiple rows per product
    let query = `
      SELECT COUNT(DISTINCT p.product_id) AS total_count
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      LEFT JOIN product_collections pco ON p.product_id = pco.product_id
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id AND main = true
        LIMIT 1
      ) pm ON true
      WHERE p.status = 'active' AND p.publishing_online = true AND p.publish_to_web	= true
    `;

    const params = [];

    // stock filter (status)
    if (status) {
      // find variant ids with stock > 0 (most recent inventory per variant)
      const variantQuery = `
        SELECT variant_id
        FROM (
          SELECT DISTINCT ON (variant_id) *
          FROM inventory
          ORDER BY variant_id, last_updated DESC, inventory_id DESC
        ) t
        WHERE t.new_quantity > 0
      `;
      const variantResult = await pool.query(variantQuery);
      const variantIds = variantResult.rows.map(r => r.variant_id);

      // if no variants in stock -> zero results
      if (!variantIds || variantIds.length === 0) {
        return [{ total_count: '0' }]; // match same shape as pool.query rows
      }

      // find product ids that have those variants
      const productQuery = `
        SELECT DISTINCT product_id
        FROM product_variants
        WHERE variant_id = ANY($1::int[])
      `;
      const productResult = await pool.query(productQuery, [variantIds]);
      const productIds = productResult.rows.map(r => r.product_id);

      // if no products matched -> zero results
      if (!productIds || productIds.length === 0) {
        return [{ total_count: '0' }];
      }

      // add to main count query
      query += ` AND p.product_id = ANY($${params.length + 1}::int[])`;
      params.push(productIds);
    }

    // category filter
    if (selectedCategoryId) {
      const allCategoryIds = await getCategory(selectedCategoryId);
      // if getCategory returns empty -> no results
      if (!allCategoryIds || allCategoryIds.length === 0) {
        return [{ total_count: '0' }];
      }
      query += ` AND c.category_id = ANY($${params.length + 1}::int[])`;
      params.push(allCategoryIds);
    }

    // price filter
    if (maxPrice > 0) {
      query += ` AND p.price BETWEEN $${params.length + 1} AND $${params.length + 2}`;
      params.push(minPrice, maxPrice);
    }

    // collection filter
    if (collectionName) {
      query += ` AND pco.collection_id = $${params.length + 1}`;
      params.push(collectionName);
    }

    const { rows } = await pool.query(query, params);
    return rows; // [{ total_count: '123' }]
  } catch (err) {
    console.error('Error fetching product count:', err);
    throw new Error('Failed to fetch product count');
  }
};


const actionMessage = async (order_id) => {
  try {
    const res = await axios.post(`${process.env.ADMIN_BACKEND}/common/Notification`, {
      action_id: 1,
      order_id: order_id
    });

    // return res.data;
  } catch (err) {
    console.error('Error fetching system settings:', err);
  }
};

function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000)); // 6-digit
}

const paymentMethodPay = async (req, res) => {
  try {
    const result = await pool.query(`SELECT payment_method_id, method_name, logo, commission_status, transaction_fixed_fee, transaction_fee	 FROM payment_methods WHERE status = 'active' AND payment_method_id IN (1, 2, 10)`);

    return res.status(200).json({ message: "success", result: result.rows });
  } catch (err) {
    console.error('Error fetching system settings:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch system settings' });
  }
};

const insertNotification = async (user_id, module, event_type, message_template, channel, status = 'Unread') => {
  try {
    const query = `
      INSERT INTO notifications (user_id, module, event_type, channel, message_template, status, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())`;

    await pool.query(query, [user_id, module, event_type, channel, message_template, status]);

    console.log(`Notification Added: [${module}] ${event_type} -> ${status}`);
  } catch (error) {
    console.error("Error inserting notification:", error);
  }
};

const checkLoyalty = async (id) => {
  try {
    const result = await pool.query('SELECT loyalty_point FROM customer WHERE customer_id = $1', [Number(id)]);

    if (result.rows.length === 0) {
      throw new Error('Country not found');
    }

    return result.rows[0].loyalty_point;
  } catch (err) {
    console.error('Error fetching system settings:', err);
    throw new Error('Failed to fetch system settings');
  }
};

// corrected function
const updateLoyaltySuctomer = async (id, loyaltiPoints, customerLoyalty) => {
  try {
    // skip if nothing to deduct (null/undefined/0 or negative)
    if (loyaltiPoints == null || Number(loyaltiPoints) <= 0) return null;

    const idNum = Number(id);
    const pointsToDeduct = Number(loyaltiPoints);
    const current = Number(customerLoyalty) || 0;

    // compute and clamp to zero
    const newLoyaltyPoint = Math.max(0, current - pointsToDeduct);

    const result = await pool.query(
      'UPDATE customer SET loyalty_point = $2 WHERE customer_id = $1 RETURNING 	customer_id, loyalty_point',
      [idNum, newLoyaltyPoint]
    );

    if (result.rowCount === 0) {
      throw new Error(`Customer with id ${idNum} not found`);
    }

    const comment = `Deducted ${pointsToDeduct} loyalty points from customer with id ${idNum} - web`

     await addRemoveLogs(idNum, pointsToDeduct, current, comment)

    // return updated row for clarity
    return result.rows[0];
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};

const addLoyalty = async (id, loyalty_points_earned) => {
  try {
    // skip if nothing to deduct (null/undefined/0 or negative)
    if (loyalty_points_earned == null || Number(loyalty_points_earned) <= 0) return null;

    const idNum = Number(id);
    const pointsToAdd = Number(loyalty_points_earned)

     const loyalty_result = await pool.query(
      `SELECT loyalty_point FROM customer WHERE customer_id = $1`,
      [idNum]
    );

    const current = loyalty_result.rows[0].loyalty_point || 0

    const result = await pool.query(
      `UPDATE customer
    SET loyalty_point = loyalty_point + $1
    WHERE customer_id = $2
    RETURNING loyalty_point;`,
      [pointsToAdd, idNum]
    );

    if (result.rowCount === 0) {
      throw new Error(`Customer with id ${idNum} not found`);
    }

    const comment = 'Earned loyalty points - web';

     await addPonitsLogs(id, pointsToAdd, current, comment)
    // return updated row for clarity
    return result.rows[0];
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};

const addSystemLogs = async (comment, module) => {

  const query = `INSERT INTO system_log (log, module, date, user_id) VALUES ($1, $2, NOW(), 1)`
  const result = await pool.query(query, [comment, module]);

  if (result.rowCount === 0) {
    console.error("❌ Failed to insert log into system_log table.");
  }

  return

}

const addPonitsLogs = async (id, pointsToAdd, current, comment) => {
  try {

    const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;
    const new_amount = Number(current) + Number(pointsToAdd)
    const result = await pool.query(query, [id, current, pointsToAdd, new_amount, comment]);

    if (result.rowCount === 0) {
      throw new Error(`Failed to add points log`);
    }

    return
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};

const addRemoveLogs = async (id, pointsToDeduct, current, comment) => {
  try {
  
    const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;
    const new_amount = Number(current) - Number(pointsToDeduct)
    const result = await pool.query(query, [id, current, -pointsToDeduct, new_amount, comment]);

    if (result.rowCount === 0) {
      throw new Error(`Failed to add points log`);
    }

    return 
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};

module.exports = {
  systemSettings,
  allCountry,
  oneCountry,
  getCategory,
  productCount,
  actionMessage,
  generateOtp,
  paymentMethodPay,
  insertNotification,
  checkLoyalty, updateLoyaltySuctomer, addLoyalty, addSystemLogs
};