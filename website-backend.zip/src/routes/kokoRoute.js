const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const fetch = require("node-fetch"); // run: npm install node-fetch@2
require("dotenv").config();
const pool = require("../config/db");

const router = express.Router();

const {
  getKokoBaseUrl,
  buildKokoPayload,
  verifyKokoSignature,
} = require("../common/koko");
const { encryptId } = require("../util/orderEncrypt");
const { addSystemLogs, addLoyalty } = require("../common/common");

// ─────────────────────────────────────────────────────────────
// ROUTE 1: POST /koko/initiate
// Your Next.js frontend calls this when the user clicks "Pay"
// This builds the signed payload and sends it to Koko
// Koko gives back a redirectUrl — we send that to the frontend
// ─────────────────────────────────────────────────────────────
router.post("/initiate", async (req, res) => {
  try {
    // These values come from your frontend (the checkout page)
    const { id } = req.body;

    if (!id) return res.status(400).json({ error: "Order id is required" });

    const query = `SELECT o.order_id, o.full_amount, o.sender_name, o.sender_email, o.currency, o.payment_reference, o.sender_phone, o.total_value, o.transaction_fee   
    FROM orders o
    WHERE order_id = $1`;
    const paymentQuery = `SELECT api_array,  commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE payment_method_id = 10`;

    const [order, payment] = await Promise.all([
      pool.query(query, [id]),
      pool.query(paymentQuery),
    ]);

    if (order.rows.length === 0 || payment.rows.length === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    let amount = 0;

    if (payment.rows[0].commission_status === false) {
      amount = order.rows[0].full_amount - order.rows[0].transaction_fee;
    } else {
      const item_total = parseFloat(order.rows[0].full_amount || 0);
      const transaction_fixed_fee = parseFloat(
        payment.rows[0].transaction_fixed_fee || 0,
      );
      const transaction_fee = parseFloat(payment.rows[0].transaction_fee || 0);

      const current_transaction_fee =
        (item_total * transaction_fee) / 100 + transaction_fixed_fee;
      amount =
        order.rows[0].full_amount -
        order.rows[0].transaction_fee +
        current_transaction_fee;
    }

    const kokoDetails = payment.rows[0].api_array;
    // console.log(payment.rows[0].api_array)

    const fullName = order.rows[0].sender_name || "";
    const nameParts = fullName.trim().split(" ");

    const orderId = order.rows[0].order_id;

    const firstName = nameParts[0] || "";
    const lastName = nameParts.slice(1).join(" ") || "";
    const email = order.rows[0].sender_email;
    const currency = order.rows[0].currency;
    const description = order.rows[0].payment_reference || "";
    const phone = order.rows[0].sender_phone || "";

    // Basic check: make sure required fields were sent
    if (!orderId || !amount || !firstName || !lastName || !email) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Build the full signed payload using our koko.js helper
    const payload = buildKokoPayload({
      orderId,
      amount,
      currency,
      firstName,
      lastName,
      email,
      description,
      phone,
      kokoDetails,
    });
    // console.log(payload)

    return res.json({
      actionUrl: `${getKokoBaseUrl(kokoDetails)}/api/merchants/orderCreate`,
      payload,
    });
  } catch (err) {
    console.error("Error in /koko/initiate:", err.message);
    return res.status(500).json({ error: "Server error" });
  }
});

// ─────────────────────────────────────────────────────────────
// ROUTE 2: POST /koko/response
// Koko's SERVER calls this directly after a successful payment
// This is the most secure confirmation — always trust this over the browser redirect
// Steps:
//   1. Verify the RSA signature to confirm it really came from Koko
//   2. Update your order in the database
//   3. Return 200 OK so Koko knows we received it
// ─────────────────────────────────────────────────────────────
router.post(
  "/response",
  express.urlencoded({ extended: false }),
  async (req, res) => {
    try {
      const { orderId, trnId, status, signature } = req.body;

      console.log("Koko server callback received:", {
        orderId,
        trnId,
        status,
        signature,
      });

      // Step 1: Verify the signature
      // This confirms the callback actually came from Koko
      const isValid = await verifyKokoSignature(
        orderId,
        trnId,
        status,
        signature,
      );

      if (!isValid) {
        console.error("Signature check FAILED for order:", orderId);
        // Still return 200 — if we return an error, Koko keeps retrying
        return res.status(200).json({ received: true });
      }

      if (status === "SUCCESS") {
        // TODO: Mark this order as PAID in your database
        // Example: await db.orders.update({ id: orderId }, { status: "PAID", kokoTrnId: trnId })

        const query = `SELECT o.order_id, o.full_amount, o.total_value, o.transaction_fee, o.customer_id    
                      FROM orders o WHERE order_id = $1`;
        const paymentQuery = `SELECT commission_status, transaction_fixed_fee, transaction_fee FROM payment_methods WHERE payment_method_id = 10`;
        const systemSettingQuery = `SELECT loyalty_point, points_given, amount_spend FROM system_settings WHERE id = 1`;

        const [order, payment, systemSettingsResult] = await Promise.all([
          pool.query(query, [orderId]),
          pool.query(paymentQuery),
          pool.query(systemSettingQuery),
        ]);

        if (
          order.rows.length === 0 ||
          payment.rows.length === 0 ||
          systemSettingsResult.rows.length === 0
        ) {
          return res.status(404).json({ error: "Order not found" });
        }

        let amount = 0;
        let current_transaction_fee = 0;

        const full_amount = parseFloat(order.rows[0].full_amount || 0);
        const order_transaction_fee = parseFloat(
          order.rows[0].transaction_fee || 0,
        );

        if (payment.rows[0].commission_status === false) {
          amount = full_amount - order_transaction_fee;
        } else {
          const item_total = parseFloat(order.rows[0].full_amount || 0);
          const transaction_fixed_fee = parseFloat(
            payment.rows[0].transaction_fixed_fee || 0,
          );
          const transaction_fee = parseFloat(
            payment.rows[0].transaction_fee || 0,
          );

          current_transaction_fee =
            (item_total * transaction_fee) / 100 + transaction_fixed_fee;
          amount =
            full_amount - order_transaction_fee + current_transaction_fee;
        }

        const updateQuery = `
            UPDATE orders 
            SET payment_status = 'paid', payment_id = $1, amount_paid = $2, full_amount = $3, transaction_fee = $4, payment_method_id = 10, cod = false
            WHERE order_id = $5
          `;
        const updateAccount = `UPDATE accounts SET balance = balance + $1 WHERE id = 6`;

        const [result, Resultaccount] = await Promise.all([
          pool.query(updateQuery, [
            trnId,
            amount,
            amount,
            current_transaction_fee,
            orderId,
          ]),
          pool.query(updateAccount, [amount]),
        ]);

        if (result.rowCount === 0) {
          console.log("Order not found");
          await addSystemLogs("Order not found", "koko");
          return res.status(200).json({ received: false });
        }
        if (Resultaccount.rowCount === 0) {
          console.log("Order not found");
          await addSystemLogs("account not found", "koko");
          return res.status(200).json({ received: false });
        }

        const system_settings = systemSettingsResult?.rows?.[0] || {};

        const customer_id = order.rows[0].customer_id;

        // ✅ ONLY RUN LOYALTY IF ENABLED
        if (system_settings.loyalty_point) {
          const points_given = parseFloat(system_settings.points_given) || 0;
          const amount_spend = parseFloat(system_settings.amount_spend) || 0;

          let loyalty_points_earned = 0;

          if (amount_spend > 0) {
            const orderPerPoint = amount / amount_spend;
            loyalty_points_earned = orderPerPoint * points_given;
          }

          // Update order
          await pool.query(
            `UPDATE orders SET loyalty_points_earned = $1 WHERE order_id = $2`,
            [loyalty_points_earned, orderId],
          );

          // Add to customer
          await addLoyalty(customer_id, loyalty_points_earned);
        }

        console.log(`Payment SUCCESS — order: ${orderId}, Koko txn: ${trnId}`);
        await addSystemLogs(
          `Payment SUCCESS order: ${orderId}, Koko txn: ${trnId}`,
          "koko",
        );
      }

      // Always return 200 to Koko
      return res.status(200).json({ received: true });
    } catch (err) {
      console.error("Error in /koko/response:", err.message);
      // Still 200 to prevent Koko retrying endlessly
      return res.status(200).json({ received: true });
    }
  },
);

// ─────────────────────────────────────────────────────────────
// ROUTE 3: GET /koko/return
// Koko redirects the USER'S BROWSER here after payment (success or failure)
// We read the status from the URL query params
// Then redirect the browser to the correct Next.js page
// ─────────────────────────────────────────────────────────────
router.get("/return", (req, res) => {
  const { orderId, trnId, status } = req.query;

  console.log("User browser returned from Koko:", { orderId, trnId, status });

  const frontendUrl = process.env.FRONTEND_URL;

  if (status === "SUCCESS") {
    // Redirect browser to the success page in Next.js
    console.log("succes order id", orderId);
    const encryptedId = encryptId(orderId);
    return res.redirect(`${frontendUrl}/order/${encryptedId}`);
  } else {
    // Redirect browser to the failed page in Next.js
    return res.redirect(`${frontendUrl}/payment/failed`);
  }
});

// ─────────────────────────────────────────────────────────────
// ROUTE 4: GET /koko/cancel
// Koko redirects the USER'S BROWSER here if the user clicked Cancel on Koko's page
// We redirect them to the cancelled page in Next.js
// ─────────────────────────────────────────────────────────────
router.get("/cancel", (req, res) => {
  const { orderId } = req.query;

  console.log("User cancelled payment for order:", orderId);

  const frontendUrl = process.env.FRONTEND_URL;

  // TODO: Optionally mark order as CANCELLED in your database

  return res.redirect(`${frontendUrl}/payment/cancelled`);
});

router.get("/koko_status", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        CASE 
          WHEN status = 'active' AND web_show = true 
          THEN true
          ELSE false
        END AS koko_status, transaction_fixed_fee, transaction_fee	
      FROM payment_methods
      WHERE payment_method_id = 10
    `);

    return res.status(200).json({
      received: true,
      koko_status: result.rows[0]?.koko_status || false,
      koko_fees: result.rows[0] || {},
    });

  } catch (error) {
    console.error("Error in /koko/koko_status:", error.message);
    return res.status(500).json({
      received: false,
      koko_status: false,
    });
  }
});

module.exports = router;
