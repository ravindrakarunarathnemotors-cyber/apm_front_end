const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/getalllogs", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      id,
      logname,
      description,
      log_at,
      
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

       let queryParams = [];
    let whereConditions = [];

     if (id) {
      queryParams.push(id);
      whereConditions.push(`id = $${queryParams.length}`);
    }
      if (description) {
     queryParams.push(`%${description}%`);
     whereConditions.push(`log ILIKE $${queryParams.length}`);
    }

    if (logname) {
      queryParams.push(`%${logname}%`);
      whereConditions.push(`module ILIKE $${queryParams.length}`);
    }
    if (log_at) {
      queryParams.push(log_at);
      whereConditions.push(`date::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(" AND ")}` : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM admin_log
      ${whereClause}
      ORDER BY date DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM admin_log
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/adminall", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT module,id FROM admin_log WHERE module ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});



module.exports = router;