const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const { discountCheck, autodiscountCheck, autodeliverydiscountCheck, autodpmethoddiscountCheck, autodbuyxdiscountCheck, oneProductDiscountView, checkPaymentMethodDiscount } = require("../controllers/DiscountController");
const { guestdiscountCheck, guestautodiscountCheck, guestautodeliverydiscountCheck, guestautodpmethoddiscountCheck, guestautodbuyxdiscountCheck } = require("../controllers/GuestDiscountController");
const { guestRegistration } = require("../common/emailTemplate");

const router = express.Router();

// register user ..................................
router.post("/discountcheck", authenticateToken, discountCheck)

router.post("/autodiscountcheck", authenticateToken, autodiscountCheck)

router.post("/autodeliverdiscount", authenticateToken, autodeliverydiscountCheck)

router.post("/autodpmethoddiscount", authenticateToken, autodpmethoddiscountCheck)

router.post("/autodbuyxdiscount", authenticateToken, autodbuyxdiscountCheck)

// guset user ...................................................

router.post("/guestdiscountcheck", guestdiscountCheck)

router.post("/guestautodiscountcheck", guestautodiscountCheck)

router.post("/guestautodeliverdiscount", guestautodeliverydiscountCheck)

router.post("/guestautodpmethoddiscount", guestautodpmethoddiscountCheck)

router.post("/guestautodbuyxdiscount", guestautodbuyxdiscountCheck)


router.get("/", async (req, res) => {
    const email = 'kalanaspark@gmail.com'
    const password = 'temppassword'
    const full_name = 'Kalana spark'
    const status = await guestRegistration(email, password, full_name)
    res.send(status)
})

router.post("/one-product-discount", oneProductDiscountView)

router.post("/check-payment-method-discount", checkPaymentMethodDiscount)






module.exports = router