// routes/feeds.js
const express = require('express');
const router = express.Router();

/**
 * Safe CSV escaping:
 * - convert null/undefined to empty string
 * - double any internal quotes
 * - if value contains comma, newline or quote, wrap in double-quotes
 */
function escapeCsv(value = '') {
  if (value === null || value === undefined) return '';
  const str = String(value);
  const escaped = str.replace(/"/g, '""');
  return /[",\n]/.test(escaped) ? `"${escaped}"` : escaped;
}

/**
 * Example data loader - replace with your real DB queries.
 * Important: fetch data in a memory-friendly way (stream/pagination) for large catalogs.
 */
async function getProducts() {
  // Example single-product shape. Replace with real DB call.
  return [
    {
      id: "DRS001",
      title: "Chekeera Floral Dress",
      description: "Beautiful floral dress.",
      price: 2590,
      slug: "floral-dress",
      brand: "Chekeera",
      colors: [
        {
          name: "Black",
          images: [
            "https://chekeera.com/img/dress-black-main.jpg",
            "https://chekeera.com/img/dress-black-1.jpg",
            "https://chekeera.com/img/dress-black-2.jpg"
          ],
          videos: [
            "https://chekeera.com/video/dress1.mp4"
          ],
          sizes: [
            { size: "M", stock: 5 },
            { size: "L", stock: 2 }
          ]
        }
      ]
    }
    // ...more products
  ];
}

/**
 * GET /feeds/facebook_catalog.csv
 */
router.get('/facebook_catalog.csv', async (req, res) => {
  // Set headers
  // Use inline so Facebook can HTTP GET the file; filename helps debugging
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'inline; filename="facebook_catalog.csv"');

  // Optional: let CDNs / Facebook poll frequently while not being too aggressive
  // Feel free to adjust Cache-Control as needed
  res.setHeader('Cache-Control', 'public, max-age=300'); // 5 minutes

  // Add UTF-8 BOM to help Excel/Sheets detect UTF-8 (some systems require this)
  res.write('\uFEFF');

  // CSV header (exact order you requested)
  const header = [
    'id', 'title', 'description', 'availability', 'condition', 'price', 'link',
    'image_link', 'additional_image_link', 'video_link', 'brand',
    'google_product_category', 'gender', 'age_group', 'color', 'size'
  ];
  res.write(header.join(',') + '\n');

  // Stream rows instead of building whole CSV in-memory
  try {
    // Replace getProducts() with a streaming DB cursor or paginated fetch if catalogue is large.
    const products = await getProducts();

    for (const product of products) {
      // Defensive defaults
      const productId = product.id || product.sku || `P-${Math.random().toString(36).slice(2,10)}`;
      const productTitle = product.title || '';
      const productDescription = product.description || '';
      const productPrice = (typeof product.price === 'number') ? `${product.price} LKR` : (product.price || '');
      const productUrl = product.slug ? `https://chekeera.com/shop/${product.slug}` : (product.url || `https://chekeera.com/product/${productId}`);
      const productBrand = product.brand || 'Chekeera';
      const googleCategory = product.google_product_category || 'Apparel & Accessories > Clothing';
      const gender = product.gender || 'female'; // adjust if needed
      const ageGroup = product.age_group || 'adult';

      // If a product has no colors/sizes, emit one row (simple product)
      if (!Array.isArray(product.colors) || product.colors.length === 0) {
        const row = [
          productId,
          productTitle,
          productDescription,
          'in stock', // or compute availability
          'new',
          productPrice,
          productUrl,
          '', // image_link
          '', // additional_image_link
          '', // video_link
          productBrand,
          googleCategory,
          gender,
          ageGroup,
          '', // color
          ''  // size
        ].map(escapeCsv).join(',');
        res.write(row + '\n');
        continue;
      }

      // For products with color/size variants
      for (const color of product.colors) {
        const colorName = color.name || '';
        const images = Array.isArray(color.images) ? color.images : (product.images || []);
        const mainImage = images.length ? images[0] : '';
        // For additional_image_link we join remaining images with comma.
        // They will be quoted automatically by escapeCsv when needed.
        const additionalImages = images.slice(1);
        // join by comma — CSV field will be quoted if it contains commas
        const additionalImagesField = additionalImages.join(',');

        const videoLinks = Array.isArray(color.videos) ? color.videos : [];
        const videoField = videoLinks.join(',');

        // If no sizes, treat color-only variant as single row
        if (!Array.isArray(color.sizes) || color.sizes.length === 0) {
          const variantId = `${productId}-${colorName.toUpperCase()}`;
          const row = [
            variantId,
            productTitle,
            productDescription,
            'in stock',
            'new',
            productPrice,
            productUrl,
            mainImage,
            additionalImagesField,
            videoField,
            productBrand,
            googleCategory,
            gender,
            ageGroup,
            colorName,
            '' // size
          ].map(escapeCsv).join(',');
          res.write(row + '\n');
          continue;
        }

        // Sizes present → create variant row per size
        for (const variant of color.sizes) {
          const variantSize = variant.size || '';
          const stock = Number(variant.stock) || 0;
          const availability = stock > 0 ? 'in stock' : 'out of stock';

          // create deterministic variant id (avoid spaces)
          const variantId = `${productId}-${(colorName || 'CLR').replace(/\s+/g, '_').toUpperCase()}-${variantSize}`;

          const row = [
            variantId,
            productTitle,
            productDescription,
            availability,
            'new',
            productPrice,
            productUrl,
            mainImage,
            additionalImagesField,
            videoField,
            productBrand,
            googleCategory,
            gender,
            ageGroup,
            colorName,
            variantSize
          ].map(escapeCsv).join(',');
          res.write(row + '\n');
        } // sizes
      } // colors
    } // products

    // finalize response
    res.end();
  } catch (err) {
    console.error('Error generating catalog CSV', err);
    if (!res.headersSent) {
      res.status(500).send('Internal Server Error');
    } else {
      // If headers already sent, just terminate
      res.end();
    }
  }
});

module.exports = router;
