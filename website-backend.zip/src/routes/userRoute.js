const express = require("express");
const { login , register, userDetails, updateUserDetails, changePassword, googleLogin, getPageContent, createOtp, forgetpassowrd} = require("../controllers/userController");
const authenticateToken = require("../middleware/authMiddleware");

const router = express.Router();
const jwt = require("jsonwebtoken");

router.post("/login", login);

router.post("/register", register);

router.get("/userdetails", authenticateToken, userDetails)

router.post("/updateuserdetails", authenticateToken, updateUserDetails)

router.post("/changepassword", authenticateToken, changePassword)

router.post("/googlelogin", googleLogin)

router.get("/web_pages", getPageContent);

router.post("/refresh-token", async (req, res) => {
    const { refresh_token } = req.body;

    if (!refresh_token) return res.status(401).json({ message: "Refresh token required" });

    jwt.verify(refresh_token, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: "Invalid refresh token" });

        // Generate a new access token
        const newAccessToken = jwt.sign(
            { user_id: user.user_id, role_id: user.role_id },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: "24h" }
        );

        res.json({ access_token: newAccessToken });
    });
});

router.post("/create-otp", createOtp);

router.post("/forget-password", forgetpassowrd);


module.exports = router;
