const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
require("dotenv").config();
const pool = require("../config/db");
const axios = require("axios");

const router = express.Router();

const mintpayHeaders = {
    Authorization: `Token 0af394cfb59ca9827e8fbf7b6473746d1c9cdad6`,
    "Content-Type": "application/json",
};

// ─── Step 1: Create Purchase ───────────────────────────────────────────────
router.post("/create", async (req, res) => {
    try {
        const {
            id,
            order_id,
            total_price,
            discount = "0.0000",
            customer_email,
            customer_id,
            customer_telephone,
            delivery_street,
            delivery_region,
            delivery_postcode,
            cart_created_date,
            cart_updated_date,
            products,
        } = req.body;

        // const query = `SELECT o.order_id, o.full_amount, o.recipient_email, o.customer_id, o.recipient_contact, o.recipient_address, o.recipient_city,
        //                COALESCE(
        //                     json_agg(
        //                     json_build_object(
        //                         'name', p.title,
        //                         'product_id', oi.variant_id,
        //                         'quantity', oi.quantity,
        //                         'unit_price', oi.unit_price,
        //                         'discount', '0.00',
        //                         'created_date': "2018-08-09 06:10:48",
        //                         'updated_date': "2019-10-09 09:10:55",
        //                     )
        //                     ) FILTER (WHERE oi.order_item_id IS NOT NULL), '[]'
        //                 ) AS order_items
        //                FROM orders o
        //                LEFT JOIN order_items oi ON o.order_id = oi.order_id
        //                LEFT JOIN products p ON oi.product_id = p.product_id
        //                WHERE o.order_id = $1`;

        // Get real customer IP from request
        const ip =
            req.headers["x-forwarded-for"]?.split(",")[0] ||
            req.socket.remoteAddress ||
            "";
        const x_forwarded_for = req.headers["x-forwarded-for"] || ip;

        const payload = {
            merchant_id: 'sb0001',
            order_id,
            total_price,
            discount,
            customer_email,
            customer_id,
            customer_telephone,
            ip: "172.198.1.1",
            x_forwarded_for: "192.168.1.1",
            delivery_street,
            delivery_region,
            delivery_postcode,
            cart_created_date,
            cart_updated_date,
            products,
            success_url: `${process.env.FRONTEND_URL}/checkout/success`,
            fail_url: `${process.env.FRONTEND_URL}/checkout/fail`,
        };

        try {
            
        } catch (error) {
            
        }
        const response = await axios.post(
            `https://dev.mintpay.lk/user-order/api/`,
            payload,
            { headers: mintpayHeaders }
        );

        const data = response.data;

        if (data.message === "Success") {
            return res.json({ success: true, purchase_id: data.data });
        } else {
            return res.status(400).json({ success: false, error: data.data });
        }
    } catch (error) {
        console.error("Mintpay create error:", error.message);
        return res.status(500).json({ success: false, error: error.message });
    }
});

// ─── Status Check ──────────────────────────────────────────────────────────
router.get("/status/:purchaseId", async (req, res) => {
    try {
        const { purchaseId } = req.params;

        const response = await axios.get(
            `${MINTPAY_BASE_URL}/user-order/api/status/merchantId/${MINTPAY_MERCHANT_ID}/purchaseId/${purchaseId}`,
            { headers: mintpayHeaders }
        );

        const data = response.data;

        return res.json({
            success: data.message === "Success",
            message: data.message,
            data: data.data,
        });
    } catch (error) {
        console.error("Mintpay status error:", error.message);
        return res.status(500).json({ success: false, error: error.message });
    }
});


module.exports = router;