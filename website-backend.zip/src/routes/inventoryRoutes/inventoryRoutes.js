const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid"); 

// inventory search route

router.post('/inventory-search',authenticateToken, async (req, res) => {
  const {
    id,
    product_name,
    product_id,
    outlet_name,
    page = 1,
    merchant_id = '20001'
  } = req.body;

  const productId = product_id || id;



  const pageSize = 25;
  const offset = (page - 1) * pageSize;

  // 🔍 Validate request structure
  if (!merchant_id) {
    return res.status(400).json({
      success: false,
      error: 'Merchant ID is required.'
    });
  }

  if (typeof page !== 'number' || page < 1) {
    return res.status(400).json({
      success: false,
      error: 'Page must be a positive number.'
    });
  }

  try {
    const queryParams = [merchant_id];
    const whereConditions = ['p.merchant_id = $1', `p.status = 'active'`];

   if (productId) {
      queryParams.push(productId);
      whereConditions.push(`p.product_id = $${queryParams.length}`);
    }

    

  if (outlet_name && outlet_name.trim() !== '' && outlet_name.toLowerCase() !== 'all') {
  queryParams.push(`%${outlet_name.toLowerCase()}%`);
  whereConditions.push(`LOWER(o.name) ILIKE $${queryParams.length}`);
}

    const whereClause = `WHERE ${whereConditions.join(' AND ')}`;

    const query = `
      SELECT
        p.product_id,
        p.title AS product_name,
        p.status,
        p.created_at AS product_created_at,
        COUNT(DISTINCT pv.variant_id) AS variants_count,
        COALESCE(SUM(i.new_quantity), 0) AS total_quantity,
        json_agg(DISTINCT jsonb_build_object(
          'outlet_name', o.name,
          'variants', COALESCE((
            SELECT json_agg(jsonb_build_object(
              'variant_id', pv2.variant_id,
              'variant_type', pv2.variant_type,
              'variant_value', pv2.variant_value,
              'sku', pv2.sku,
              'quantity', COALESCE(i2.new_quantity, 0),
              'last_updated', i2.last_updated
            ))
            FROM product_variants pv2
            LEFT JOIN inventory i2 
              ON i2.variant_id = pv2.variant_id 
              AND i2.outlet_id = o.outlet_id
              AND i2.status = 'active'
            WHERE pv2.product_id = p.product_id
          ), '[]'::json)
        )) AS outlet_variants
      FROM products p
      LEFT JOIN product_variants pv ON pv.product_id = p.product_id
      LEFT JOIN inventory i ON i.variant_id = pv.variant_id AND i.status = 'active'
      LEFT JOIN outlets o ON o.outlet_id = i.outlet_id
      ${whereClause}
      GROUP BY p.product_id, p.title, p.status, p.created_at
      ORDER BY p.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    queryParams.push(pageSize, offset);

    const { rows } = await pool.query(query, queryParams);

    // Fetch even without no variants or outlets linked 
   const filteredRows = rows.filter(row => row.product_id);


    if (filteredRows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No matching inventory found for product "${product_name}" in outlet "${outlet_name}". Please check both fields.`
      });
    }

    return res.json({
      success: true,
      data: filteredRows
    });

  } catch (err) {
    console.error('❌ Inventory Search Error:', err);

    if (err.code === '42601') {
      return res.status(400).json({
        success: false,
        error: 'SQL syntax error. Please check the query structure.'
      });
    }

    if (err.code === '42P01') {
      return res.status(500).json({
        success: false,
        error: 'One of the database tables does not exist. Check table names.'
      });
    }

    return res.status(500).json({
      success: false,
      error: 'Unexpected server error. Please try again later.'
    });
  }
});



// inventory products search route
router.get('/inventory-product-search',authenticateToken, async (req, res) => {
  const merchant_id = '20001'; // hardcoded for MVP
  const { q = '' } = req.query;

  if (typeof q !== 'string' || q.trim().length < 2) {
    return res.status(400).json({
      success: false,
      error: 'Search query must be at least 2 characters long.',
    });
  }

  try {
    const sql = `
      SELECT product_id, title
      FROM products
      WHERE merchant_id = $1
        AND status = 'active'
        AND LOWER(title) LIKE '%' || LOWER($2) || '%'
      ORDER BY title ASC
      LIMIT 20;
    `;

    const { rows } = await pool.query(sql, [merchant_id, q]);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No active products found matching "${q}".`,
      });
    }

    return res.json({
      success: true,
      products: rows.map(p => ({
        product_id: p.product_id,
        title: p.title,
        // example combined string if needed: `${p.title} - ${p.product_id}`
      })),
    });
  } catch (error) {
    console.error('Product search error:', error);
    return res.status(500).json({
      success: false,
      error: 'Server error while searching products.',
    });
  }
});



// get/fetch outlet names -is available true and matching merchant 

router.get('/active-outlets', async (req, res) => {
  const merchant_id = '20001';

  try {
    const query = `
      SELECT outlet_id, name
      FROM outlets
      WHERE is_active = true AND merchant_id = $1
      ORDER BY name ASC
    `;
    const { rows } = await pool.query(query, [merchant_id]);

    res.json({
      success: true,
      outlets: rows
    });
  } catch (err) {
    console.error('❌ Error fetching active outlets:', err);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch active outlets.'
    });
  }
});



module.exports = router;