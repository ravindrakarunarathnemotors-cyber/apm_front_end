const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");

const { v4: uuidv4 } = require("uuid"); 


// search products (variants/products names and id's on inventory movement )
router.get("/search-product-variants",authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query || query.trim().length < 2) {
    return res.status(400).json({ message: "Search query must be at least 2 characters." });
  }

  const merchant_id = "20001";
  const trimmedQuery = query.trim();
  const lowerQuery = trimmedQuery.toLowerCase();
  const searchTerm = `%${lowerQuery}%`;

  try {
    const searchQuery = `
      SELECT
        p.product_id,
        p.title,
        pv.variant_id,
        pv.variant_type,
        pv.variant_value
      FROM products p
      LEFT JOIN product_variants pv ON p.product_id = pv.product_id
      WHERE
        p.merchant_id = $1 AND (
          LOWER(p.title) ILIKE $2 OR
          LOWER(pv.variant_value) ILIKE $2 OR
          p.product_id::text = $3 OR
          pv.variant_id::text = $3
        )
      ORDER BY p.product_id, pv.variant_id;
    `;

    const result = await pool.query(searchQuery, [
      merchant_id,
      searchTerm,
      trimmedQuery,
    ]);

    const productsMap = {};

    for (const row of result.rows) {
      const pid = row.product_id;

      const matchedByProductId = pid.toString() === trimmedQuery;
      const matchedByTitle = row.title?.toLowerCase().includes(lowerQuery);
      const matchedByVariant = row.variant_value?.toLowerCase().includes(lowerQuery);
      const matchedByVariantId = row.variant_id?.toString() === trimmedQuery;

      if (!matchedByProductId && !matchedByTitle && !matchedByVariant && !matchedByVariantId) continue;

      if (!productsMap[pid]) {
        productsMap[pid] = {
          product_id: pid,
          title: row.title,
          variants: [],
        };
      }

      if (row.variant_id) {
        const alreadyIncluded = productsMap[pid].variants.some(v => v.variant_id === row.variant_id);
        if (!alreadyIncluded && (matchedByProductId || matchedByTitle || matchedByVariant || matchedByVariantId)) {
          productsMap[pid].variants.push({
            variant_id: row.variant_id,
            variant_type: row.variant_type,
            variant_value: row.variant_value,
          });
        }
      }
    }

    const products = Object.values(productsMap);

    if (!products.length) {
      return res.status(404).json({ message: "No matching products or variants found." });
    }

    return res.json({ results: products });
  } catch (err) {
    console.error("Error searching product variants:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});



module.exports = router;
