const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");

// GET /search-product-variants?query=blue
router.get("/search-product-variants",authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query || query.trim() === "") {
    return res.status(400).json({ message: "Search query is required." });
  }

  const merchant_id = "20001";
  const searchTerm = `%${query.trim().toLowerCase()}%`;
  const trimmedQuery = query.trim();

  try {
    // First: check if query matches a variant_id
    const variantMatchRes = await pool.query(
      `SELECT product_id FROM product_variants WHERE variant_id::text = $1`,
      [trimmedQuery]
    );

    let productCondition = "";
    let queryParams = [merchant_id];

    if (variantMatchRes.rowCount > 0) {
      const productId = variantMatchRes.rows[0].product_id;
      productCondition = `p.product_id::text = $2`;
      queryParams.push(productId);
    } else {
      // Regular title / variant_value / product_id match
      productCondition = `
        (
          LOWER(p.title) ILIKE $2 OR
          LOWER(pv.variant_value) ILIKE $2 OR
          p.product_id::text = $3
        )
      `;
      queryParams.push(searchTerm, trimmedQuery);
    }

    const searchQuery = `
      SELECT
        p.product_id,
        p.title,
        p.description,
        p.status,
        p.publishing_online,
        p.publishing_pos,
        p.price,
        pv.variant_id,
        pv.variant_value,
        pv.variant_type,
        pv.price AS variant_price,
        pv.sku,
        pv.barcode,
        pv.reorder_level,
        pv.inventory_quantity,
        pv.continue_selling_oos
      FROM products p
      LEFT JOIN product_variants pv ON p.product_id = pv.product_id
      WHERE p.merchant_id = $1 AND ${productCondition}
      ORDER BY p.product_id, pv.variant_id;
    `;

    const result = await pool.query(searchQuery, queryParams);

    // Group by product
    const productsMap = {};

    for (const row of result.rows) {
      const pid = row.product_id;

      if (!productsMap[pid]) {
        productsMap[pid] = {
          product_id: pid,
          title: row.title,
          description: row.description,
          status: row.status,
          publishing_online: row.publishing_online,
          publishing_pos: row.publishing_pos,
          price: row.price,
          variants: [],
        };
      }

      if (row.variant_id) {
        productsMap[pid].variants.push({
          variant_id: row.variant_id,
          variant_value: row.variant_value,
          variant_type: row.variant_type,
          price: row.variant_price,
          sku: row.sku,
          barcode: row.barcode,
          reorder_level: row.reorder_level,
          inventory_quantity: row.inventory_quantity,
          continue_selling: row.continue_selling_oos, // ✅ added here
        });
      }
    }

    const products = Object.values(productsMap);

    if (!products.length) {
      return res.status(404).json({ message: "No products or variants found." });
    }

    return res.json({ results: products });
  } catch (err) {
    console.error("Error searching product variants:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});



router.post("/Allpro", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      ToDate,
      created_at,
      variant_id,
      product_id,
      inventory_name,
      merchant_id = "20001",
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`i.merchant_id = $1`];

    if (variant_id) {
      queryParams.push(variant_id);
      whereConditions.push(`i.variant_id = $${queryParams.length}`);
    }

    if (product_id) {
      queryParams.push(product_id);
      whereConditions.push(`pv.product_id = $${queryParams.length}`);
    }

    let from = created_at;
    let to = ToDate;

    if (created_at && ToDate && new Date(created_at) > new Date(ToDate)) {
      from = ToDate;
      to = created_at;
    }

    if (from && to) {
      queryParams.push(from);
      queryParams.push(to);
      whereConditions.push(`i.last_updated::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const productQuery = `
      SELECT 
        i.inventory_id,
        i.previous_quantity,
        i.adjust_quantity,
        i.new_quantity,
        i.last_updated,
        i.comment,
        i.system_module,
        i.variant_id,
        pv.product_id
      FROM inventory i
      INNER JOIN product_variants pv ON i.variant_id = pv.variant_id
      ${whereClause}
      ORDER BY i.inventory_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(productQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM inventory i
      INNER JOIN product_variants pv ON i.variant_id = pv.variant_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      products: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});




module.exports = router;
