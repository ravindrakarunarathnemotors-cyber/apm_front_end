const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
// GET /api/reorder-levels/search?query=...
router.get('/search',authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query) {
    return res.status(400).json({ success: false, message: 'Query parameter is required.' });
  }

  try {
    const sql = `
      SELECT 
        rl.*,
        p.title AS product_title,
        pv.variant_value,
        o.name AS outlet_name
      FROM reorder_level rl
      JOIN products p ON rl.product_id = p.product_id
      JOIN product_variants pv ON rl.variant_id = pv.variant_id
      JOIN outlets o ON rl.outlet_id = o.outlet_id
      WHERE 
        CAST(rl.product_id AS TEXT) = $1
        OR LOWER(p.title) LIKE LOWER('%' || $1 || '%')
        OR CAST(rl.variant_id AS TEXT) = $1
        OR LOWER(pv.variant_value) LIKE LOWER('%' || $1 || '%')
      ORDER BY rl.product_id, rl.variant_id, rl.outlet_id;
    `;

    const { rows } = await pool.query(sql, [query]);

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'No matching reorder level records found.' });
    }

    res.json({ success: true, results: rows });
  } catch (error) {
    console.error('Error fetching reorder level search:', error);

    if (error.code === '42501') {
      return res.status(403).json({ success: false, message: 'Permission denied to access reorder level data.' });
    }

    if (error.code === '22P02') {
      return res.status(400).json({ success: false, message: 'Invalid query input format.' });
    }

    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});




module.exports = router;
