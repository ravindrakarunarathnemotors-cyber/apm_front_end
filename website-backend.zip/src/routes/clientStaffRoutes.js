const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const pool = require("../config/db");
const {formatPhoneNumber} = require("../models/commonQuery")
const { sendContactMessage } = require("../controllers/public/contact.controller");

const bcrypt = require("bcrypt");


const router = express.Router();

router.post("/contact", sendContactMessage);


router.get("/client-staff", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT admin_user.*, role_list.role_name
      FROM admin_user
      JOIN role_list ON admin_user.role_id = role_list.id
      ORDER BY admin_user.id DESC
    `);
      
    console.log("rowsclients",result.rows); 
   
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/adduser", authenticateToken, async (req, res) => {

  try {
    const { firstName, lastName, email, phone, password, role, username, branch, client_id } = req.body;

    // Validate required fields
    if (!firstName || !lastName || !email || !phone || !password || !role || !branch || !username) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);
    const status = "Active"; // Default status

    // Function to format phone number (Ensure it's defined elsewhere in the project)
    
    const mobileNew = formatPhoneNumber(phone);
    if (mobileNew.error) {
      return res.status(400).json({ message: mobileNew.error });
    }
    const formattedPhone = mobileNew.formatted;

    // Check if username already exists
    const userNameCheck = await pool.query(
      "SELECT id FROM admin_user WHERE username = $1",
      [username]
    );

    if (userNameCheck.rows.length > 0) {
      return res.status(409).json({ message: "Username already exists" });
    }

    // Insert the new user into the database
 const result = await pool.query(
  "INSERT INTO admin_user (first_name, last_name, username, email, mobile, password, role_id, status, branch_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *",
  [firstName, lastName, username, email, formattedPhone, hashedPassword, role, status, branch]
);

    res.status(201).json({ message: "User added successfully", user: result.rows[0] });
  } catch (error) {
    console.error("Error adding user:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/addrole", authenticateToken, async (req, res) => {
  try {
    const { roleName, privileges, dashboardAccess } = req.body;
    const user = req.user;
    const user_id = user.user_id
    console.log(user)
    console.log(req.body); 

    const status = "active";
    const createdAt = new Date();
  
   
    const result = await pool.query(
      "INSERT INTO role_list (role_name, date, status, privileges, dashboard_access,user_id) VALUES ($1, $2, $3, $4::TEXT[], $5::TEXT[],$6) RETURNING *",
      [roleName, createdAt, status, privileges, dashboardAccess,user_id] 
    );

    res.status(201).json({ message: "Role added successfully", role: result.rows[0] });
  } catch (error) {
    console.error("Error adding role:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/sidebar", authenticateToken, async (req, res) => {
  try {

    const user = req.user;
    console.log(user)
    const roleid = user.role_id
 
    const roleResult = await pool.query(
      "SELECT privileges, dashboard_access FROM role_list WHERE id = $1",
      [roleid]
    );

    if (roleResult.rows.length === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    const privileges = roleResult.rows[0].privileges; 
    const dashboardAccess = roleResult.rows[0].dashboard_access; 

 
    const menuResult = await pool.query(
      "SELECT * FROM uimenudata WHERE id = ANY($1) ORDER BY sidebar_order ASC",
      [privileges]
    );

    let menuItems = menuResult.rows;


    console.log(dashboardAccess)
    // if (dashboardAccess && dashboardAccess.length > 0) {
    //   const dashboardItems = await pool.query(
    //     "SELECT * FROM uimenudata WHERE privilege_id = ANY($1)",
    //     [dashboardAccess]
    //   );

    
    //   menuItems = [...dashboardItems.rows, ...menuItems];
    // }

    res.json(menuItems);
  } catch (error) {
    console.error("Error fetching sidebar menu:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.get("/sidebar-items", authenticateToken, async (req, res) => {
  try {

    const menuItemsResult = await pool.query(
      "SELECT id, parent_id, name, route, icon, sidebar_order FROM uimenudata ORDER BY sidebar_order ASC"
    );

    const menuItems = menuItemsResult.rows;


    const menuMap = {};
    const sidebarOptions = [];

    menuItems.forEach((item) => {
      menuMap[item.id] = { ...item, subcategories: [] };
    });

    menuItems.forEach((item) => {
      if (item.parent_id) {
        menuMap[item.parent_id]?.subcategories.push(menuMap[item.id]);
      } else {
        sidebarOptions.push(menuMap[item.id]);
      }
    });

    res.json(sidebarOptions);
  } catch (error) {
    console.error("Error fetching sidebar menu:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/get-roles", authenticateToken, async (req, res) => {
  
 

  try {
    const result = await pool.query(
      "SELECT id, role_name,status,privileges FROM role_list WHERE status ='active' ORDER BY id DESC",
    
    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching roles:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/get-branch", authenticateToken, async (req, res) => {
  const { query } = req.body;
   console.log("Received query for branch search:", query);
  try {
    const result = await pool.query(
      "SELECT branch_id, branch_name FROM branch WHERE branch_name ILIKE $1 ORDER BY branch_id DESC",
      [`%${query}%`]  // Case-insensitive search
      
    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching branchs:", error);
    res.status(500).json({ message: "Server error" });
  }
});




router.post("/get-role-table", authenticateToken, async (req, res) => {
  let { search = '', page = 1, limit = 25 } = req.body;



  const offset = (page - 1) * limit;

  try {
    let query = `SELECT id, role_name, status, privileges FROM role_list WHERE TRUE`;
    let queryParams = [];

    if (search) {
      query += ` AND (role_name ILIKE $2 OR id::text ILIKE $2)`;
      queryParams.push(`%${search}%`);
    }

    query += ` ORDER BY id DESC LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}`;
    queryParams.push(limit, offset);

    const result = await pool.query(query, queryParams);

    let countQuery = `SELECT COUNT(*) FROM role_list WHERE TRUE`;
    let countParams = [];

    if (search) {
      countQuery += ` AND (role_name ILIKE $2 OR id::text ILIKE $2)`;
      countParams.push(`%${search}%`);
    }

    const countResult = await pool.query(countQuery, countParams);
    const totalRoles = parseInt(countResult.rows[0].count, 10);

    res.json({
      roles: result.rows,
      totalRoles,
      totalPages: Math.ceil(totalRoles / limit),
      currentPage: page,
    });
  } catch (error) {
    console.error("Error fetching roles:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/check-username", async (req, res) => {
  const { username } = req.body;

  if (!username) {
      return res.status(400).json({ message: "Username is required" });
  }

  try {
      const result = await pool.query("SELECT COUNT(*) FROM admin_user WHERE username = $1", [username]);
      const usernameExists = parseInt(result.rows[0].count) > 0;

      return res.json({ exists: usernameExists });
  } catch (error) {
      console.error("Error checking username:", error);
      return res.status(500).json({ message: "Server error" });
  }
});



router.post("/update-role-status", authenticateToken, async (req, res) => {
  
  const { roleId, status } = req.body;

  try {
    const result = await pool.query(
      "UPDATE role_list SET status = $1 WHERE id = $2 RETURNING *",
      [status, roleId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    res.json({ message: "Role status updated successfully", role: result.rows[0] });
  } catch (error) {
    console.error("Error updating role status:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/update-role-privileges", authenticateToken, async (req, res) => {
  const { roleId, privileges } = req.body;

  if (!roleId || !Array.isArray(privileges) || privileges.length === 0) {
    return res.status(400).json({ message: "Invalid request data" });
  }

  try {
    // Sort privileges in ascending order (Min → Max)
    const sortedPrivileges = privileges.sort((a, b) => a - b);

    // Convert sorted array to PostgreSQL array format {3,6,7,8}
    const formattedPrivileges = `{${sortedPrivileges.join(",")}}`;

    // Update the privileges column in role_list table
    const result = await pool.query(
      "UPDATE role_list SET privileges = $1 WHERE id = $2 RETURNING *",
      [formattedPrivileges, roleId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    res.json({ message: "Role privileges updated successfully", role: result.rows[0] });
  } catch (error) {
    console.error("Error updating role privileges:", error);
    res.status(500).json({ message: "Server error" });
  }
});



router.post("/get-role-privileges", authenticateToken, async (req, res) => {
  const { roleId } = req.body;

  try {
    // Query to fetch privileges and dashboard access for the role
    const roleQuery = await pool.query(
      "SELECT privileges, dashboard_access FROM role_list WHERE id = $1",
      [roleId]
    );

    if (roleQuery.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    // Extract privileges and dashboard access from role
    const { privileges = [], dashboard_access = [] } = roleQuery.rows[0];

    console.log("Privileges IDs Array:", privileges);

    // Fetch all privilege data from uimenudata
    const privilegeQuery = await pool.query(
      `SELECT id, parent_id, name, route, icon, sidebar_order FROM uimenudata ORDER BY sidebar_order`
    );

    if (privilegeQuery.rowCount === 0) {
      return res.json({ privileges: [], dashboardAccess: dashboard_access });
    }

    // Function to build a hierarchy of privileges
    const buildHierarchy = (parentId) => {
      // Find all children (subcategories) for the given parentId
      return privilegeQuery.rows
        .filter(row => row.parent_id === parentId)
        .map(row => ({
          ...row,
          // Recursively add subcategories if any
          subcategories: buildHierarchy(row.id),
          assigned: privileges.includes(row.id.toString()) // Mark privilege as assigned if in role's privileges
        }));
    };

    // Get top-level privileges (parent components) and mark their assigned status
    const topLevelPrivileges = buildHierarchy(null);

    console.log("Structured Privileges with Subcategories:", topLevelPrivileges);

    // Return the structured data with assigned/unassigned status
    res.json({ privileges: topLevelPrivileges, dashboardAccess: dashboard_access });

  } catch (error) {
    console.error("Error fetching role privileges:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/edit-user", authenticateToken, async (req, res) => {
  const { first_name, last_name, email, mobile, selected_userId, user_id, newPassword, confirmPassword } = req.body;

  try {
    if (newPassword && confirmPassword) {
      // Case: Update Password
      if (newPassword !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }

      // Hash the new password before updating it
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      const result = await pool.query(
        `UPDATE admin_user 
         SET password = $1 
         WHERE id = $2 RETURNING *`,
        [hashedPassword, selected_userId]
      );

      if (result.rows.length > 0) {
        return res.status(200).json({ message: "Password updated successfully" });
      } else {
        return res.status(404).json({ message: "User not found" });
      }
    } else {
      const mobileNew = formatPhoneNumber(mobile);
      if (mobileNew.error) {
        return res.status(400).json({ message: mobileNew.error });
      }
      const formattedPhone = mobileNew.formatted;

      const result = await pool.query(
        `UPDATE admin_user 
         SET first_name = $1, last_name = $2, email = $3, mobile = $4
         WHERE id = $5 RETURNING *`,
        [first_name, last_name, email, formattedPhone, selected_userId]
      );

      if (result.rows.length > 0) {
        return res.status(200).json({ message: "User details updated successfully", user: result.rows[0] });
      } else {
        return res.status(404).json({ message: "User not found" });
      }
    }
  } catch (error) {
    console.error("Error updating user details:", error);
    res.status(500).json({ message: "Server error" });
  }
});



















module.exports = router;
