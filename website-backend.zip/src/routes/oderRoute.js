const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const {addOrder, guestAddOrder, oneOrder, createSession, updatepayment, payhereHash, allOrder, stripePaid} = require("../controllers/orderController");

const router = express.Router();

router.post("/addorder", authenticateToken, addOrder);

router.post("/guestaddorder", guestAddOrder);

router.get("/oneorder/:id",  oneOrder);

router.post("/create-session", createSession);

router.post("/updatepayment", updatepayment);

router.post("/payherehash", payhereHash);

router.get("/allorder", authenticateToken, allOrder);

router.post("/stripepaid", stripePaid);

module.exports = router;