const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const {getBrandingSetting, SlideDetails, CategoryDetails, webTemplateSections, BannerDetails, SpecialProductDetails, FeatureAreaDetails, getActivePlugins   } = require("../controllers/brandingSetting");
const router = express.Router();


// GET /branding/settings
router.get('/settings', getBrandingSetting)

// GET /branding/slide-details
router.post('/slide-details',  SlideDetails)


router.post('/banner-details',  BannerDetails)


router.post('/feature-area-details',  FeatureAreaDetails)


router.post('/special-product-details',  SpecialProductDetails )


// GET /branding/category-details
router.post('/get-product-category',  CategoryDetails)


// GET /branding/web-template-sections
router.post('/web-template-sections',  webTemplateSections)


// GET /branding/active_plugins
router.get('/active_plugins',  getActivePlugins)



router.get('/social-media', async (req, res) => {
    try {
        const result = await pool.query('SELECT website_url,facebook_url,twitter_url,instagram_url,linkedin_url, youtube_url FROM branding_settings WHERE id = 1');

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Social media not found' });
        }

        res.json(result.rows[0]);
    } catch (err) {
        console.error('Error fetching social media:', err);
        res.status(500).json({ error: 'Failed to fetch social media' });
    }
});



module.exports = router;
