const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const {allCountry} = require("../common/common");

const router = express.Router();


// PUT /system/settings - Update system settings
router.put('/settings',authenticateToken, async (req, res) => {
  try {
    const data = req.body;
    const id = 1;

    const fields = [
      'default_timezone',
      'date_format',
      'currency',
      'auto_logout_time',
      'sms_gateway_name',
      'sms_user_id',
      'sms_sender_id',
      'sms_api_endpoint',
      'sms_api_key',
      'sms_notification_status',
      'billing_email',
      'system_email',
      'support_email',
      'email_notification_status',
      'postmark_server_token',
      'smtp_host',
      'smtp_port',
      'smtp_username',
      'smtp_password',
      'smtp_encryption',
      'new_client_sms_status',
      'new_client_email_status',
      'new_client_activation_sms_status',
      'new_client_activation_email_status',
      'backoffice_maintenance_status',
      'backoffice_maintenance_msg',
      'webstore_maintenance_status',
      'webstore_maintenance_msg',
      'pos_maintenance_status',
      'pos_maintenance_msg',
      'full_maintenance_status',
      'full_maintenance_msg',
    ];

    const updates = fields.map((field, i) => `${field} = $${i + 1}`);
    const values = fields.map((field) => data[field]);

    const query = `
      UPDATE system_settings
      SET ${updates.join(', ')}, updated_at = NOW()
      WHERE id = $${fields.length + 1}
      RETURNING *;
    `;

    const result = await pool.query(query, [...values, id]);

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating system settings:', err);
    res.status(500).json({ success: false, message: 'Failed to update system settings' });
  }
});

// GET /system/settings - Fetch system settings
router.get('/settings', async (req, res) => {
  try {
    const id = 1;

    const result = await pool.query(
      `SELECT sell_international, tax_value, tax_on_web, currency, terms_conditions 
       FROM system_settings 
       WHERE id = $1`,
      [id]
    );

    let data = result.rows[0];

    // ✅ Parse JSON text safely
    if (data?.terms_conditions) {
      try {
        data.terms_conditions = JSON.parse(data.terms_conditions);
      } catch (e) {
        console.warn("Invalid JSON in terms_conditions");
        data.terms_conditions = null; // fallback
      }
    }

    res.json({ success: true, data });

  } catch (err) {
    console.error('Error fetching system settings:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch system settings' });
  }
});

router.get('/country', allCountry);

router.get('/gettempleteID', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT template_id FROM sales_channel WHERE id = 1`
    )
    if (rows.length === 0) return res.status(404).json({ message: "Template not found" });
    res.status(200).json({ message: "Update successful", data: rows[0].template_id });
  } catch (error) {
    console.error("Error fetching templates:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post('/get-delivery-fee', async (req, res) => {
  try {
    const {country} = req.body

    if(!country) return res.status(400).json({ message: "country not found" });
    
    const deliverQuery = `SELECT fee, additional_fee FROM delivery_fee WHERE country_id = $1`
    const defaultCountry = `SELECT fee, additional_fee FROM delivery_fee WHERE id = 1`

    const  [deliveryFee, defaultFee]  = await Promise.all([
      pool.query(deliverQuery, [parseFloat(country)]),
      pool.query(defaultCountry)
    ])

    if(defaultFee.rows.length === 0) return res.status(400).json({ message: "delivery fee not found" });

    if (deliveryFee.rows.length === 0) return res.status(200).json({ message: "delivery fee", result: defaultFee.rows[0] });

   return  res.status(200).json({ message: "Update successful", result: deliveryFee.rows[0] });
  } catch (error) {
    console.error("Error fetching templates:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});


router.get('/get-tracking-settings', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        enabled_google,
        gtm_container_id,
        ga4_measurement_id,
        enabled_meta,
        meta_pixel_id,
        enabled_google_tag
      FROM system_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Settings not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching tracking settings:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.get('/webstore_maintenance', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        webstore_maintenance_status,
        webstore_maintenance_msg
      FROM system_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Settings not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching tracking settings:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

router.get('/full_maintenance', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        full_maintenance_status,
        full_maintenance_msg	
      FROM system_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Settings not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching tracking settings:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});



module.exports = router;