const express = require('express');
const multer = require('multer');

const { S3Client, PutObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const pool = require("../../config/db");
require('dotenv').config();

const router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage });

// S3 client config
const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});



// Support single or multiple file uploads
router.post('/upload', upload.array('files', 10), async (req, res) => {
  const { product_id } = req.body;
  const files = req.files;

  if (!files || files.length === 0 || !product_id) {
    return res.status(400).json({ error: 'At least one file and product_id are required.' });
  }

  try {
    const uploadResults = [];

    for (const file of files) {
      const timestamp = Date.now();
      const originalName = file.originalname;
      const newFileName = `Product_Media/${timestamp}-${originalName}`;

      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: newFileName,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'public-read',
      };

      await s3.send(new PutObjectCommand(params));

      let mediaType = 'image';
      if (file.mimetype.startsWith('video')) {
        mediaType = 'video';
      } else if (originalName.toLowerCase().endsWith('.glb')) {
        mediaType = '3d';
      }

      const publicUrl = `${process.env.CONVERT_S3_URL}/${newFileName}`;

      const result = await pool.query(
        `INSERT INTO product_media (product_id, media_url, media_type, created_at)
         VALUES ($1, $2, $3, NOW()) RETURNING *`,
        [product_id, publicUrl, mediaType]
      );

      uploadResults.push(result.rows[0]);
    }

    return res.status(200).json({ message: 'Upload successful', media: uploadResults });
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ error: 'File upload failed' });
  }
});
// PATCH instead of DELETE for soft delete
router.patch('/:product_id/:media_id', async (req, res) => {
  const { product_id, media_id } = req.params;
  const { status } = req.body;

  if (!status || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ error: 'Invalid or missing status' });
  }

  try {
    const result = await pool.query(
      `UPDATE product_media SET status = $1 WHERE media_id = $2 AND product_id = $3 RETURNING *`,
      [status, media_id, product_id]
    )

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Media not found or not updated' })
    }

    res.status(200).json({ message: 'Media status updated', updated: result.rows[0] })
  } catch (err) {
    console.error('Error soft deleting media:', err)
    res.status(500).json({ error: 'Failed to update media status' })
  }
})


// GET product media by product_id
router.get('/:product_id', async (req, res) => {
  const { product_id } = req.params;

  if (!product_id) {
    return res.status(400).json({ error: 'Product ID is required' });
  }

  try {
    const result = await pool.query(
      `SELECT media_id, media_url, media_type, created_at
       FROM product_media
       WHERE product_id = $1 AND status = 'active'
       ORDER BY created_at ASC`,
      [product_id]
    );

    return res.status(200).json({ media: result.rows });
  } catch (err) {
    console.error('Error fetching media:', err);
    return res.status(500).json({ error: 'Failed to fetch media' });
  }
});


// staging..

// ✅ STAGING UPLOAD ROUTE – Uploads to S3 only, no DB insert
router.post('/upload-staging', upload.array('files', 10), async (req, res) => {
  const files = req.files;

  if (!files || files.length === 0) {
    return res.status(400).json({ error: 'At least one file is required.' });
  }

  try {
    const uploadResults = [];

    for (const file of files) {
      const timestamp = Date.now();
      const originalName = file.originalname;
      const newFileName = `Product_Media/${timestamp}-${originalName}`;

      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: newFileName,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'public-read',
      };

      await s3.send(new PutObjectCommand(params));

      let mediaType = 'image';
      if (file.mimetype.startsWith('video')) {
        mediaType = 'video';
      } else if (originalName.toLowerCase().endsWith('.glb')) {
        mediaType = '3d';
      }

      const publicUrl = `${process.env.CONVERT_S3_URL}/${newFileName}`;

      // ✅ Don't insert into DB — just return info
      uploadResults.push({
        media_url: publicUrl,
        media_type: mediaType,
      });
    }

    return res.status(200).json({ message: 'Staging upload successful', media: uploadResults });
  } catch (err) {
    console.error('Upload staging error:', err);
    return res.status(500).json({ error: 'Staging upload failed' });
  }
});




module.exports = router;
