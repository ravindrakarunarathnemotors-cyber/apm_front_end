const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid"); 
const { insertAdminLog } = require("../../models/userLogs");


router.get('/variants',authenticateToken, async (req, res) => {
  try {
    const query = 'SELECT id, option_name, values FROM variants';
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error('Error fetching variants:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/add-variants',authenticateToken, async (req, res) => {
  try {
    const { option_name, values } = req.body;

    // 1. Validate input
    if (!option_name || typeof option_name !== 'string') {
      return res.status(400).json({ error: 'option_name is required and must be a string' });
    }

    if (!Array.isArray(values) || values.length === 0) {
      return res.status(400).json({ error: 'values must be a non-empty array' });
    }

    // 2. Check for duplicate option_name
    const existing = await pool.query(
      'SELECT id FROM variants WHERE option_name = $1',
      [option_name]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Option name already exists' });
    }

    // 3. Insert into DB
    const insertQuery = `
      INSERT INTO variants (option_name, values)
      VALUES ($1, $2)
      RETURNING id, option_name, values
    `;

    const { rows } = await pool.query(insertQuery, [option_name, values]);
    res.status(201).json(rows[0]);

  } catch (err) {
    console.error('Error inserting variant:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ....................update variants

// PUT /variants/:id
router.put('/variants/:id',authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { option_name, values } = req.body;

  try {
    // Validate ID
    if (!id) {
      return res.status(400).json({ error: 'ID is required' });
    }

    // Build update fields dynamically
    const updates = [];
    const valuesArray = [];
    let paramIndex = 1;

    if (option_name !== undefined) {
      updates.push(`option_name = $${paramIndex++}`);
      valuesArray.push(option_name);
    }

    if (values !== undefined) {
      updates.push(`values = $${paramIndex++}`);
      valuesArray.push(values);
    }

    // If no fields provided
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    // Add ID as the final param
    valuesArray.push(id);

    // Final query
    const query = `
      UPDATE variants
      SET ${updates.join(', ')}
      WHERE id = $${paramIndex}
      RETURNING id, option_name, values
    `;

    const result = await pool.query(query, valuesArray);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Variant not found' });
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error updating variant:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});




// fetch categories parent / children categorization / lineage 
router.get('/product-category-lineage/:productId',authenticateToken, async (req, res) => {
  const client = await pool.connect();
  const { productId } = req.params;

  try {
    // Step 1: Get the category_id for this product
    const catRes = await client.query(
      `SELECT category_id FROM product_category WHERE product_id = $1 LIMIT 1`,
      [productId]
    );

    if (catRes.rows.length === 0) {
      return res.status(404).json({ error: 'No category linked to this product' });
    }

    let currentId = catRes.rows[0].category_id;
    const lineage = [];

    // Step 2: Trace up to the main category
    while (currentId) {
      const { rows } = await client.query(
        `SELECT * FROM categories WHERE category_id = $1`,
        [currentId]
      );

      if (rows.length === 0) break;

      const current = rows[0];
      lineage.push(current);

      if (!current.category_under || current.category_under === 0) break;

      currentId = current.category_under;
    }

    res.json({ category_lineage: lineage.reverse() }); // Root → Assigned
  } catch (err) {
    console.error("Error fetching category lineage:", err);
    res.status(500).json({ error: "Internal Server Error" });
  } finally {
    client.release();
  }
});


router.get('/get-categories',authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        category_id, merchant_id, name, description, created_at,
        category_under, related_ui, mobile_url, desktop_url, show_on_main_menu
      FROM categories
    `;
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error('Error fetching categories:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// add categories

router.post('/add-category', async (req, res) => {
  try {
    const {
      merchant_id,
      name,
      description,
      category_under,
      related_ui,
      mobile_url,
      desktop_url,
      show_on_main_menu,
    } = req.body;

    // Validate category name
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ error: 'Category name is required and must be a string' });
    }

    // Check for duplicate category name
    const existing = await pool.query(
      'SELECT category_id FROM categories WHERE name = $1',
      [name]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Category name already exists' });
    }

    // Insert category into DB (merchant_id must be valid or it will throw)
    const insertQuery = `
      INSERT INTO categories (
        merchant_id, name, description, category_under, related_ui,
        mobile_url, desktop_url, show_on_main_menu
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING category_id, merchant_id, name, description, category_under,
                related_ui, mobile_url, desktop_url, show_on_main_menu, created_at
    `;

    const values = [
      merchant_id, // Must be valid FK
      name,
      description || null,
      category_under || null,
      related_ui || null,
      mobile_url || null,
      desktop_url || null,
      show_on_main_menu ?? false,
    ];

    const { rows } = await pool.query(insertQuery, values);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error('Error inserting category:', err);
    if (err.code === '23503') {
      // PostgreSQL foreign key violation code
      return res.status(400).json({ error: 'Invalid merchant_id (foreign key constraint)' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});


// const MERCHANT_ID = '20001';



router.get('/get-collections',authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM collections WHERE merchant_id = $1 ORDER BY created_at DESC`,
      [MERCHANT_ID]
    );

    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching collections:', err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.post("/getallcollections", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      collectname,
      created_at,
      collect_state,
      id,
      merchant_id = "20001", 
    } = req.body;

   


    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];
    
   
    if (id) {
      queryParams.push(id);
      whereConditions.push(`collection_id = $${queryParams.length}`);
    }
    if (collectname) {
      queryParams.push(`%${collectname}%`);
      whereConditions.push(`name ILIKE $${queryParams.length}`);
    }
     if (collect_state) {
      queryParams.push(collect_state); 
      whereConditions.push(`status = $${queryParams.length}`);
    }
    if (created_at) {
      queryParams.push(created_at);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(" AND ")}` : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM collections
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM collections
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/getallcategories", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      categorystate,
      category_name,
      description,
      collectdate,
      id,
      merchant_id = "20001" 
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];
    
     if (id) {
      queryParams.push(id);
      whereConditions.push(`category_id = $${queryParams.length}`);
    } 
    if (category_name) {
      queryParams.push(`%${category_name}%`);
      whereConditions.push(`name ILIKE $${queryParams.length}`);
    }
    if (categorystate) {
      queryParams.push(categorystate); 
      whereConditions.push(`status = $${queryParams.length}`);
    }
    if (collectdate) {
      queryParams.push(collectdate);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    if (description) {
     queryParams.push(`%${description}%`);
     whereConditions.push(`description ILIKE $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    
    const categoriesQuery = `
      SELECT 
        category_id, merchant_id, name, description, created_at,status,
        category_under, related_ui, mobile_url, desktop_url, show_on_main_menu
      FROM categories
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(categoriesQuery, paginatedParams);

    
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM categories
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      categories: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/variantsall", authenticateToken, async (req, res) => {
  try {
    const {
      variantname,
      variantstate,
      id,
      page = 1,
      limit = 25
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];
    

     if (id) {
      queryParams.push(id);
      whereConditions.push(`id = $${queryParams.length}`);
    }
    if (variantname) {
      queryParams.push(`%${variantname}%`);
      whereConditions.push(`option_name ILIKE $${queryParams.length}`);
    }
    if (variantstate) {
      queryParams.push(variantstate); 
      whereConditions.push(`status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    
    const query = `
      SELECT id, option_name, values, status
      FROM variants
      ${whereClause}
      ORDER BY id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(query, paginatedParams);

   
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM variants
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      variants: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching variants:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post('/updateCategory', authenticateToken, async (req, res) => {
  try {
    const { category_id, name, description, user_id } = req.body;

    if (!category_id || !name) {
      return res.status(400).json({ error: 'category_id and name are required.' });
    }

    
    const result = await pool.query(
      'SELECT name, description FROM categories WHERE category_id = $1',
      [category_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Category not found.' });
    }

    const current = result.rows[0];

   
    const isNameChanged = current.name !== name;
    const isDescriptionChanged = current.description !== description;

    if (!isNameChanged && !isDescriptionChanged) {
      return res.status(200).json({ message: 'No changes detected.' });
    }

   
    await pool.query(
      `UPDATE categories 
       SET name = $1, description = $2
       WHERE category_id = $3`,
      [name, description, category_id]
    );

     const module = 'Category';
    const changes = [];
    if (isNameChanged) changes.push(`name: '${current.name}' → '${name}'`);
    if (isDescriptionChanged) changes.push(`description: '${current.description}' → '${description}'`);
    const logMessage = `Updated Category ${category_id}: ${changes.join(', ')}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Category updated successfully.' });
  } catch (error) {
    console.error('Error updating category:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
});

  router.post('/updateCollections', authenticateToken, async (req, res) => {
  try {
    const { collection_id, name, description, user_id } = req.body;

    if (!collection_id || !name) {
      return res.status(400).json({ error: 'collection_id and name are required.' });
    }

    
    const result = await pool.query(
      'SELECT name, description FROM collections WHERE collection_id = $1',
      [collection_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Category not found.' });
    }

    const current = result.rows[0];

   
    const isNameChanged = current.name !== name;
    const isDescriptionChanged = current.description !== description;

    if (!isNameChanged && !isDescriptionChanged) {
      return res.status(200).json({ message: 'No changes detected.' });
    }

   
    await pool.query(
      `UPDATE collections 
       SET name = $1, description = $2
       WHERE collection_id = $3`,
      [name, description, collection_id]
    );
    
    const module = 'Collection';
    let changes = [];
    if (isNameChanged) changes.push(`name: '${current.name}' → '${name}'`);
    if (isDescriptionChanged) changes.push(`description: '${current.description}' → '${description}'`);
    const logMessage = `Updated Collection ${collection_id}: ${changes.join(', ')}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Collection_id updated successfully.' });
  } catch (error) {
    console.error('Error updating collections:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
});



router.post('/updatevariant',authenticateToken, async (req, res) => {
  try {
    const { id, option_name, values, user_id } = req.body;

   console.log("id",id);
   console.log("option_name",option_name);

   console.log("values",values);

    if (!id) {
      return res.status(400).json({ error: 'Variant ID is required' });
    }

    if (!option_name || typeof option_name !== 'string') {
      return res.status(400).json({ error: 'option_name is required and must be a string' });
    }

    if (!Array.isArray(values) || values.length === 0 || values.some(v => typeof v !== 'string')) {
      return res.status(400).json({ error: 'values must be a non-empty array of strings' });
    }

   
    const existing = await pool.query(
      'SELECT option_name, values FROM variants WHERE id = $1',
      [id]
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Variant not found' });
    }

    const current = existing.rows[0];
     const module = 'Variant';
    const logMessage = `Updated Variant ${id}: option_name='${option_name}', values=${JSON.stringify(values)}`;
    await insertAdminLog(user_id, module, logMessage);
   
    const isOptionNameChanged = current.option_name !== option_name;
    const areValuesChanged =
      JSON.stringify(current.values.sort()) !== JSON.stringify(values.sort());

    if (!isOptionNameChanged && !areValuesChanged) {
      return res.status(200).json({ message: 'No changes detected' });
    }

    
    const updateQuery = `
      UPDATE variants
      SET option_name = $1,
          values = $2
      WHERE id = $3
      RETURNING id, option_name, values
    `;

    const { rows } = await pool.query(updateQuery, [option_name, values, id]);

    res.status(200).json({
      message: 'Variant updated successfully',
      variant: rows[0],
    });

  } catch (err) {
    console.error('Error updating variant:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


router.post('/collectstatus', async (req, res) => {
  const { collection_id, status, user_id } = req.body;

  if (!collection_id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Invalid input' });
  }

  try {
    const result = await pool.query(
      'UPDATE collections SET status = $1 WHERE collection_id = $2',
      [status, collection_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Collection not found' });
    }

     const module = 'Collections';
     const logMessage = `Updated collection ${collection_id} status to '${status}'`;
     await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Status updated successfully' });
  } catch (error) {
    console.error('Error updating status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});



router.post('/categorystatus',authenticateToken, async (req, res) => {
  const { category_id, status, user_id } = req.body

  if (!category_id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Invalid input' })
  }

  try {
    const result = await pool.query(
      'UPDATE categories SET status = $1 WHERE category_id = $2',
      [status, category_id]
    )

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'category not found' })
    }

    const module = 'Category';
     const logMessage = `Updated Category ${category_id} status to '${status}'`;
     await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Status updated successfully' })
  } catch (error) {
    console.error('Error updating status:', error)
    res.status(500).json({ message: 'Server error' })
  }
});

router.post('/variantsstatus',authenticateToken, async (req, res) => {
  const { id, status , user_id } = req.body

  if (!id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Invalid input' })
  }

  try {
    const result = await pool.query(
      'UPDATE variants SET status = $1 WHERE id = $2',
      [status, id]
    )

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'variant not found' })
    }

    const module = 'Variant';
     const logMessage = `Updated Variant ${id} status to '${status}'`;
     await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Status updated successfully' })
  } catch (error) {
    console.error('Error updating status:', error)
    res.status(500).json({ message: 'Server error' })
  }
});



// ......................................... Collections temporary route ..............................................

// TEMPORARY: hardcoded merchant_id (replace later with token-based value)
const MERCHANT_ID = '20001'; // Replace with real UUID

// POST /collections - Create a collection
router.post('/add-collection',authenticateToken, async (req, res) => {
  const { name, description } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Collection name is required' });
  }

  try {
    const result = await pool.query(
      `INSERT INTO collections (merchant_id, name, description)
       VALUES ($1, $2, $3) RETURNING *`,
      [MERCHANT_ID, name, description]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Error creating collection:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /collections - Get all collections for the merchant
router.get('/get-collections',authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM collections WHERE merchant_id = $1 ORDER BY created_at DESC`,
      [MERCHANT_ID]
    );

    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching collections:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

//maduu

router.post("/getallcollections", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      collectname,
      created_at,
      merchant_id = "20001", 
    } = req.body;

    console.log("collectname", collectname);
    console.log("created_at", created_at);


    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];

    if (collectname) {
      queryParams.push(`%${collectname}%`);
      whereConditions.push(`name ILIKE $${queryParams.length}`);
    }
    if (created_at) {
      queryParams.push(created_at);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(" AND ")}` : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM collections
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM collections
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/getallcategories", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      category_name,
      description,
      collectdate,
      merchant_id = "20001" 
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];

    if (category_name) {
      queryParams.push(`%${category_name}%`);
      whereConditions.push(`name ILIKE $${queryParams.length}`);
    }

    if (collectdate) {
      queryParams.push(collectdate);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    if (description) {
     queryParams.push(`%${description}%`);
     whereConditions.push(`description ILIKE $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    
    const categoriesQuery = `
      SELECT 
        category_id, merchant_id, name, description, created_at,
        category_under, related_ui, mobile_url, desktop_url, show_on_main_menu
      FROM categories
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(categoriesQuery, paginatedParams);

    
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM categories
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      categories: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/variantsall", authenticateToken, async (req, res) => {
  try {
    const {
      variantname,
      page = 1,
      limit = 25
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    if (variantname) {
      queryParams.push(`%${variantname}%`);
      whereConditions.push(`option_name ILIKE $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    
    const query = `
      SELECT id, option_name, values
      FROM variants
      ${whereClause}
      ORDER BY id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(query, paginatedParams);

   
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM variants
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      variants: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching variants:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});








module.exports = router;

























