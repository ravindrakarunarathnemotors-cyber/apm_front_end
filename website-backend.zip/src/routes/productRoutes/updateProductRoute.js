const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");


// ✅ UPDATED: Changed from "/:product_id" to "/"
router.get("/",authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    // ✅ UPDATED: Get product_id from query params
    const { product_id } = req.query;

    const productQuery = `SELECT * FROM products WHERE product_id = $1`;
    const productResult = await client.query(productQuery, [product_id]);

    if (productResult.rows.length === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    const product = productResult.rows[0];

    const variantQuery = `SELECT * FROM product_variants WHERE product_id = $1`;
    const variantResult = await client.query(variantQuery, [product_id]);

    product.variants = variantResult.rows;

    res.status(200).json({ product });
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    client.release();
  }
});









module.exports = router;