const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { insertAdminLog } = require("../../models/userLogs");
const { v4: uuidv4 } = require("uuid"); // <-- Add this import
const {getProduct, getAllProduct, getProductById, getProductVariant, getProductCategory, getallProductCollection, checkProductQuantity, getallPaymentMethod, geSearchProduct, geNewarrivalProduct, getFeaturesProducts, gerealtedlProduct, highestPrice, getBestSellingProducts, getprodcutWithcolection, getProductReviews, addReview, oneProductReview, directAddtoCart, ViewCount, getProductCollection, getProductAvailable, addReviewGuest} = require("../../controllers/productController");
const { paymentMethodPay } = require("../../common/common");


// get all products route
router.post("/get-products", getProduct);

// get all products without pagination route
router.post("/get-all-products", getAllProduct);

// GET /branding/category-details
router.post('/feature-products',  getFeaturesProducts)


router.post('/best-selling-products',  getBestSellingProducts)

// get all payment methods route
router.get("/get-payment-methods", getallPaymentMethod);


// get product by id
router.post("/get-product-id", getProductById);

router.post("/get-product-variant", getProductVariant);

router.post("/get-reviews", getProductReviews);

router.get("/get-product-category", getProductCategory);

router.get("/get-all-product-collection", getallProductCollection);

router.post("/check-product-quantity", checkProductQuantity);

router.get("/search-product", geSearchProduct);

router.get("/new-arrival-product", geNewarrivalProduct);

router.post("/related-product", gerealtedlProduct);

router.get("/highest-price", highestPrice);

router.post("/product-with-collection", getprodcutWithcolection);

router.post("/add-review", authenticateToken, addReview);

router.post("/add-review-guest", addReviewGuest);

router.post("/one-product-review", oneProductReview);

router.get("/payment-method-pay", paymentMethodPay);

router.post("/direct-add-to-cart", directAddtoCart);

router.post("/view-count", ViewCount);

router.get("/get-product-collection", getProductCollection);

router.get("/one-product-available/:oneproduct_id", getProductAvailable);




// get collection by product
router.get('/get-collections-by-product/:productId', async (req, res) => {
  const { productId } = req.params;

  try {
    const query = `
      SELECT c.collection_id, c.name
      FROM collections c
      INNER JOIN product_collections pc ON c.collection_id = pc.collection_id
      WHERE pc.product_id = $1
    `;
    const result = await pool.query(query, [productId]);

    res.status(200).json(result.rows);
  } catch (err) {
    console.error('Error fetching collections by product ID:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// tag search
router.get("/tags-search",authenticateToken, async (req, res) => {
  const { query } = req.query;

  try {
    const result = await pool.query(
      `SELECT * FROM tags WHERE name ILIKE $1 AND status = 'active' LIMIT 10`,
      [`%${query}%`]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error in /tags-search:", err);
    res.status(500).json({ error: "Failed to fetch tags" });
  }
});




const merchant_id = "20001";
router.post("/create-tag",authenticateToken, async (req, res) => {
  const client = await pool.connect();
  const { name, product_id } = req.body;

  try {
    await client.query("BEGIN");

    // 1. Check if tag already exists (case-insensitive)
    const tagResult = await client.query(
      `SELECT tag_id FROM tags WHERE merchant_id = $1 AND LOWER(name) = LOWER($2)`,
      [merchant_id, name]
    );

    let tag_id;

    if (tagResult.rows.length > 0) {
      tag_id = tagResult.rows[0].tag_id;
    } else {
      // 2. Insert tag if it doesn't exist
      const insertTagRes = await client.query(
        `INSERT INTO tags (merchant_id, name, status)
         VALUES ($1, $2, 'active')
         RETURNING tag_id`,
        [merchant_id, name]
      );
      tag_id = insertTagRes.rows[0].tag_id;
    }

    // 3. Insert into product_tags (if not already exists)
    await client.query(
      `INSERT INTO product_tags (product_id, tag_id)
       VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [product_id, tag_id]
    );

    await client.query("COMMIT");
    res
      .status(200)
      .json({ message: "Tag added and linked to product", tag_id });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error adding tag:", error);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
});
// ----  get tags

router.get("/get-active-tags-by-product/:product_id",authenticateToken, async (req, res) => {
  const { product_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT t.tag_id, t.name, t.status
       FROM tags t
       INNER JOIN product_tags pt ON pt.tag_id = t.tag_id
       WHERE pt.product_id = $1 AND t.status = 'active'`,
      [product_id]
    );

    res.status(200).json({ tags: result.rows });
  } catch (error) {
    console.error("Error fetching active tags:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

//----------------------------------------de activate tag per merchant

router.put("/deactivate-tag/:id",authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `UPDATE tags SET status = 'inactive' WHERE tag_id = $1 RETURNING *`,
      [id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Tag not found" });
    }

    res.status(200).json(result.rows[0]);
  } catch (err) {
    console.error("Error in /deactivate-tag:", err);
    res.status(500).json({ error: "Failed to deactivate tag" });
  }
});


//madu

router.get("/productse", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT title,	product_id FROM products WHERE title ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/productcey", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT name, category_id FROM categories WHERE name ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.post("/Allproduct", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      productId,
      product_state,
      product_name,
      created_at,
      category,
      merchant_id = "20001",
    } = req.body;
    console.log("product_name",product_name);
    console.log("created_at",created_at);
    console.log("category",category);
    
    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`p.merchant_id = $1`];

    if (productId) {
      queryParams.push(productId);
      whereConditions.push(`p.product_id = $${queryParams.length}`);
    }

     if (product_state) {
      queryParams.push(product_state); 
      whereConditions.push(`p.status = $${queryParams.length}`);
    }

    if (product_name) {
      queryParams.push(`%${product_name}%`);
      whereConditions.push(`p.title ILIKE $${queryParams.length}`);
    }

    if (created_at) {
      queryParams.push(created_at);
      whereConditions.push(`p.created_at::date = $${queryParams.length}`);
    }

    if (category) {
  queryParams.push(category);
  whereConditions.push(`c.category_id = $${queryParams.length}`);
}


    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    
    const productQuery = `
      SELECT 
        p.product_id,
        p.title AS product_name,
        STRING_AGG(DISTINCT c.name, ', ') AS categories,
        p.price,
        p.status,
        p.created_at
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      ${whereClause}
      GROUP BY p.product_id
      ORDER BY p.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(productQuery, paginatedParams);

    
    const countQuery = `
      SELECT COUNT(DISTINCT p.product_id) AS total
      FROM products p
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN categories c ON pc.category_id = c.category_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      products: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/productcollec", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT name,	collection_id FROM collections WHERE name ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});



router.get("/productcategory", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT name, category_id FROM categories WHERE name ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.get("/productvariants", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT option_name, id FROM variants WHERE option_name ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

//maduuu

router.get("/productse", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT title,	product_id FROM products WHERE title ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/productcey", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name, category_id FROM categories WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});



router.get("/productcollec", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name,	collection_id FROM collections WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/productcategory", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name, category_id FROM categories WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/productvariants", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT option_name, id FROM variants WHERE option_name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post('/update-status', async (req, res) => {
  const { product_id, status, user_id } = req.body;

  if (!product_id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Invalid input' });
  }

  try {
    const result = await pool.query(
      'UPDATE products SET status = $1 WHERE product_id = $2',
      [status, product_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }
    
    await pool.query(
      'UPDATE product_variants SET status = $1 WHERE product_id = $2',
      [status, product_id]
    );

   
    const module = 'Products';
    const logMessage = `Updated product ${product_id} status to '${status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Status updated successfully' });
  } catch (error) {
    console.error('Error updating product status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});













module.exports = router;
