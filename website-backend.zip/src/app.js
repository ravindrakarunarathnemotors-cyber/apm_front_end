const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const clientStaffRoutes = require("./routes/clientStaffRoutes");
const parcelTimeLine = require("./routes/parcelTimeLine");
const brandingSettings = require("./routes/brandingSettings");
const systemSettings = require("./routes/systemSettings");
const useRoute = require('./routes/userRoute')
const productRoute = require('./routes/productRoutes/productRoute')
const productSubRoute = require('./routes/productRoutes/productSubRoutes')
const productUploadRoute = require('./routes/productRoutes/productUploadRoute')
const updateProductRoute = require('./routes/productRoutes/updateProductRoute')
const inventoryRoutes = require('./routes/inventoryRoutes/inventoryRoutes')
const inventorySubRoutes = require('./routes/inventoryRoutes/inventorySubRoutes')
const inventoryMovementRoutes = require('./routes/inventoryRoutes/inventoryMovementRoutes')
const reorderLevelRoute = require('./routes/inventoryRoutes/reorderLevelRoute')
const kokoRoute = require('./routes/kokoRoute')
const mintpayRoute = require('./routes/mintpayRoute')


const dashboard = require('./routes/dashboardManagement')

const adminLog = require("./routes/adminLog");

const orderRouter = require("./routes/oderRoute");

const discountRoute = require("./routes/discountRoute");
const feedsRouter = require('./routes/feeds');


// Initialize app
const app = express();


// Middleware
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));

//parse JSON bodies for all other routes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// *** Upload route BEFORE express.json middleware ***
const uploadRoute = require("./routes/uploadRoute");
app.use("/branding", uploadRoute);



// Routes
app.use("/branding", brandingSettings);
app.use("/user", useRoute);


//product routes
app.use("/product", productRoute);



app.use("/api", clientStaffRoutes);
app.use("/parcel", parcelTimeLine);
app.use("/system", systemSettings);

app.use("/adminlog", adminLog)
app.use("/dashboard", dashboard);

app.use("/product-sub", productSubRoute);
app.use("/product-media", productUploadRoute);
app.use("/update-product", updateProductRoute);

// inventory routes
app.use("/inventory", inventoryRoutes);
app.use("/inventory-sub", inventorySubRoutes);
app.use("/inventory-movement", inventoryMovementRoutes);
app.use("/inventory-reorder", reorderLevelRoute);


//order
app.use("/order", orderRouter);

app.get("/session-status", async (req, res) => {
    const session = await stripe.checkout.sessions.retrieve(req.query.session_id, {
        expand: ["payment_intent"],
    });
    console.log(session)
    res.send({
        status: session.status,
        payment_status: session.payment_status,
        payment_intent_id: session.payment_intent.id,
        payment_intent_status: session.payment_intent.status,
    });
});


//discount
app.use("/discount", discountRoute);

app.use('/feeds', feedsRouter);


app.use("/koko", kokoRoute);
app.use("/mintpay", mintpayRoute);

module.exports = app;
