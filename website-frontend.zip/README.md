# Spark – Full Stack eCommerce Web Application

Spark is a powerful and modern full stack eCommerce web application built using Next.js, Express.js, MongoDB with Mongoose, Redux Toolkit, RTK Query, Stripe payment integration, Bootstrap 5, and Sass.

## Features Overview

- **Next.js:** Fast and scalable React framework.
- **Express.js:** Minimal and robust Node.js web application backend.
- **MongoDB:** Flexible, scalable, document-oriented database.
- **Mongoose:** Simplified schema-based MongoDB data modeling.
- **Stripe:** Secure online payment integration.
- **Nodemailer:** Easy-to-use email notifications.
- **Authentication:** Google login, registration, email verification, password recovery, and profile updates.
- **Redux Toolkit:** Simplified and efficient state management.
- **RTK Query:** Efficient data fetching and caching.
- **TypeScript + Next.js App Directory:** Enhanced code reliability.
- **Form Validation:** Ensures accurate data submissions.
- **Bootstrap 5 Framework:** Responsive, mobile-first framework.
- **Responsive Layout:** Optimized for all devices.
- **Touch-Friendly:** Designed for touch devices.

## Detailed Features

- **React JS:** Dynamic and interactive UIs.
- **Next.js:** Optimized for high performance.
- **Express.js:** Robust backend solution.
- **MongoDB & Mongoose:** Effective data management.
- **Stripe Integration:** Secure payment processing.
- **Nodemailer:** Reliable email communications.
- **Authentication:** Secure user authentication.
- **Redux Toolkit & RTK Query:** Efficient state and data management.
- **Dynamic Routes:** Enhanced navigation.
- **Bootstrap 5:** Customizable and responsive UI components.
- **Logo Slider:** Professional product showcase.
- **Sticky Header:** Improved user navigation.
- **Google Fonts & FontAwesome:** Professional typography and icons.
- **Responsive Design:** Seamless across all devices.
- **Clean and Commented Code:** Easy customization and maintenance.
- **Customizable Components:** Adaptable to your branding needs.
- **Multiple Home and Inner Pages:** Extensive layout options.
- **Flexible and Multi-Purpose:** Suitable for various eCommerce niches.

## Additional Powerful Features

- **Complete eCommerce Solution:** Full suite of essential eCommerce features.
- **Variation Swatch:** Professional product variation display.
- **Advanced Filtering:** Size, color filters, pagination.
- **Video Gallery:** Interactive product visuals.
- **Sale Countdown Timer:** Boost sales urgency.
- **Product Quick View:** Easy product browsing.
- **Quantity Selection Options:** Dropdown or manual input.
- **Secure Authentication:** Google and email-based login.
- **User Profile Management:** User-friendly profile updates.
- **Stripe Payment Gateway:** Secure, seamless checkout.

## Installation and Usage

To get started with Spark, follow these steps:

### 1. Clone the repository

```bash
git clone your-repository-url
```

### 2. Install dependencies

```bash
npm install
```

### 3. Configure environment variables

Create a `.env` file and add the required configuration variables.

### 4. Build the project

```bash
npm run build
```

### 5. Start the development server

```bash
npm run dev
```

## Sources and Credits

- Bootstrap
- Swiper Slider
- Google Fonts
- FontAwesome Icons

## Thank You for Choosing Spark

We hope Spark provides the powerful and efficient solution you need for your eCommerce platform.