/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['i.ibb.co','lh3.googleusercontent.com','res.cloudinary.com','d8y1.c2.e2-9.dev'],
  },
}

module.exports = nextConfig
