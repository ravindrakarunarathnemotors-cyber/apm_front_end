import { apiSlice } from "../api/apiSlice";

export const productApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    getAllProducts: builder.query({
      query: ({
        page = 1,
        selectedCategoryId = null,
        priceValue,
        selectValue,
        status,
        collectionName,
      } = {}) => ({
        url: "/product/get-products",
        method: "POST",
        body: {
          page,
          selectedCategoryId,
          priceValue,
          selectValue,
          status,
          collectionName,
        },
      }),

      // providesTags: ["Products"],
    }),

    getAllProductsWithoutPagination: builder.query({
      query: ({
        page = 1,
        selectedCategoryId = null,
        priceValue,
        selectValue,
        status,
      } = {}) => ({
        url: "/product/get-all-products",
        method: "POST",
        body: { page, selectedCategoryId, priceValue, selectValue, status },
      }),

      // providesTags: ["Products"],
    }),
    getAllsearchProducts: builder.query({
      query: ({ page = 1, selectedCategoryId = null, priceValue } = {}) => ({
        url: "/product/get-productss",
        method: "POST",
        body: { page, selectedCategoryId, priceValue },
      }),

      providesTags: ["Products"],
    }),
    getAllCollections: builder.query({
      query: () => "/product/get-collections",
      transformResponse: (response) => response.result, // 👈 transform result only
      providesTags: ["Collections"],
    }),
    getSearchProducts: builder.query({
      query: (searchText) => `/product/search-product?searchText=${searchText}`,
    }),
    getProductType: builder.query({
      query: ({ type, query }) =>
        `https://shofy-backend.vercel.app/api/product/${type}?${query}`,
      providesTags: ["ProductType"],
    }),
    getOfferProducts: builder.query({
      query: (type) =>
        `https://shofy-backend.vercel.app/api/product/offer?type=${type}`,
      providesTags: ["OfferProducts"],
    }),
    getPopularProductByType: builder.query({
      query: (type) =>
        `https://shofy-backend.vercel.app/api/product/popular/${type}`,
      providesTags: ["PopularProducts"],
    }),
    getTopRatedProducts: builder.query({
      query: () => `https://shofy-backend.vercel.app/api/product/top-rated`,
      providesTags: ["TopRatedProducts"],
    }),

    getNewArrivalProducts: builder.query({
      query: () => `/product/new-arrival`,
      providesTags: ["TopRatedProducts"],
    }),

    // get single product
    getProduct: builder.query({
      query: (id) =>
        `https://shofy-backend.vercel.app/api/product/single-product/${id}`,
      providesTags: (result, error, arg) => [{ type: "Product", id: arg }],
      invalidatesTags: (result, error, arg) => [
        { type: "RelatedProducts", id: arg },
      ],
    }),

    // get single product by id
    getProductId: builder.mutation({
      query: (product_id) => ({
        url: "/product/get-product-id",
        method: "POST",
        body: { product_id: product_id },
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getProductIdBody: builder.query({
      query: (product_id) => ({
        url: "/product/get-product-id",
        method: "POST",
        body: { product_id },
      }),
      transformResponse: (response) => response.result,
    }),

    getRelatedProduct: builder.mutation({
      query: (product_id) => ({
        url: "/product/related-product",
        method: "POST",
        body: { product_id: product_id },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    // get single product by id
    getProductVariant: builder.mutation({
      query: (product_id) => ({
        url: "/product/get-product-variant",
        method: "POST",
        body: { product_id: product_id },
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    incrementViewCount: builder.mutation({
      query: (product_id) => ({
        url: "/product/view-count",
        method: "POST",
        body: { product_id: product_id },
      }),
    }),

    // get reviews by product_id
    getProductReviews: builder.query({
      query: (product_id) => ({
        url: "/product/get-reviews",
        method: "POST",
        body: { product_id },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    // get related products
    getRelatedProducts: builder.query({
      query: (id) =>
        `https://shofy-backend.vercel.app/api/product/related-product/${id}`,
      providesTags: (result, error, arg) => [
        { type: "RelatedProducts", id: arg },
      ],
    }),

    getProductQuantity: builder.mutation({
      query: (variant_id) => ({
        url: "/product/check-product-quantity",
        method: "POST",
        body: { variant_id },
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getAllPaymentMethods: builder.query({
      query: () => "/product/get-payment-methods",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getAllpaymentMethodPay: builder.query({
      query: () => "/product/payment-method-pay",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getoneProductReview: builder.mutation({
      query: (product_id) => ({
        url: "/product/one-product-review",
        method: "POST",
        body: { product_id: product_id },
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),
    getoneProductDiscount: builder.mutation({
      query: (oneproduct_id) => ({
        url: "/discount/one-product-discount",
        method: "POST",
        body: { product_id: oneproduct_id },
      }),
    }),
    getoneProductAvailable: builder.query({
      query: (oneproduct_id) => ({
        url: `/product/one-product-available/${oneproduct_id}`,
      }),
    }),
  }),
});

export const {
  useGetSearchProductsQuery,
  useGetProductReviewsQuery,
  useGetAllProductsQuery,
  useGetAllProductsWithoutPaginationQuery,
  useGetAllCollectionsQuery,
  useGetProductTypeQuery,
  useGetOfferProductsQuery,
  useGetPopularProductByTypeQuery,
  useGetTopRatedProductsQuery,
  useGetNewArrivalProductsQuery,
  useGetProductQuery,
  useGetProductIdMutation,
  useGetProductIdBodyQuery,
  useGetProductVariantMutation,
  useGetRelatedProductsQuery,
  useGetProductQuantityMutation,
  useGetAllPaymentMethodsQuery,
  useGetAllpaymentMethodPayQuery,
  useGetRelatedProductMutation,
  useGetAllsearchProductsQuery,
  useGetoneProductReviewMutation,
  useIncrementViewCountMutation,
  useGetoneProductDiscountMutation,
  useGetoneProductAvailableQuery,
} = productApi;
