import { apiSlice } from "@/redux/api/apiSlice";
import { userLoggedIn } from "./authSlice";
import Cookies from "js-cookie";

export const authApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    //  registerUser: builder.mutation({
    //   query: (data) => ({
    //     url: "https://shofy-backend.vercel.app/api/user/signup",
    //     method: "POST",
    //     body: data,
    //   }),
    // }),

    registerUser: builder.mutation({
      query: (data) => ({
        url: "user/register",
        method: "POST",
        body: data,
      }),
    }),
    // signUpProvider
    signUpProvider: builder.mutation({
      query: (token) => ({
        url: `/user/googlelogin`,
        method: "POST",
        body: {
          token: token
        },
      }),

      async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        try {
          const result = await queryFulfilled;
         
          // Cookies.set(
          //   "userInfo",
          //   JSON.stringify({
          //     accessToken: result.data.data.token,
          //     user: result.data.data.user,
          //   }),
          //   { expires: 0.5 }
          // );

          localStorage.setItem("accessToken", result.data.accessToken);
          dispatch(
            userLoggedIn({
              accessToken: result.data.accessToken,
              user: result.data.user,
            })
          );
        } catch (err) {
          // do nothing
        }
      },
    }),
    // login
    loginUser: builder.mutation({
      query: (data) => ({
        url: "/user/login",
        method: "POST",
        body: data,
      }),
      async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        try {
          const result = await queryFulfilled;
          // Ensure consistent shape everywhere!
          // Cookies.set(
          //   "userInfo",
          //   JSON.stringify({
          //     accessToken: result.data.accessToken,
          //     user: result.data.user,
          //   }),
          //   { expires: 0.5 }
          // );
          localStorage.setItem("accessToken", result.data.accessToken);
          dispatch(
            userLoggedIn({
              accessToken: result.data.accessToken,
              user: result.data.user,
            })
          );
        } catch (err) {
          // Do nothing, handled in component
        }
      },
    }),


    // get user details
    getUserDetails: builder.query({
      query: () => `/user/userdetails`,
      transformResponse: (response) => response.result,
    }),
    // get me
    getUser: builder.query({
      query: () => "https://shofy-backend.vercel.app/api/user/me",

      async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        try {
          const result = await queryFulfilled;
          dispatch(
            userLoggedIn({
              user: result.data,
            })
          );
        } catch (err) {
          // do nothing
        }
      },
    }),
    // confirmEmail
    confirmEmail: builder.query({
      query: (token) => `https://shofy-backend.vercel.app/api/user/confirmEmail/${token}`,

      async onQueryStarted(arg, { queryFulfilled, dispatch }) {
        try {
          const result = await queryFulfilled;

          Cookies.set(
            "userInfo",
            JSON.stringify({
              accessToken: result.data.data.token,
              user: result.data.data.user,
            }),
            { expires: 0.5 }
          );

          dispatch(
            userLoggedIn({
              accessToken: result.data.data.token,
              user: result.data.data.user,
            })
          );
        } catch (err) {
          // do nothing
        }
      },
    }),
    // reset password
    resetPassword: builder.mutation({
      query: (data) => ({
        url: "/user/create-otp",
        method: "POST",
        body: data,
      }),
    }),
    // confirmForgotPassword
    confirmForgotPassword: builder.mutation({
      query: (data) => ({
        url: "/user/forget-password",
        method: "POST",
        body: data,
      }),
    }),
    // change password
    changePassword: builder.mutation({
      query: (data) => ({
        url: "/user/changepassword",
        method: "POST",
        body: data,
      }),
    }),
    // updateProfile password
    updateProfile: builder.mutation({
      query: ({ id, ...data }) => ({
        url: `/user/updateuserdetails`,
        method: "POST",
        body: data,
      }),

      // async onQueryStarted(arg, { queryFulfilled, dispatch }) {
      //   try {
      //     const result = await queryFulfilled;

      //     Cookies.set(
      //       "userInfo",
      //       JSON.stringify({
      //         accessToken: result.data.data.token,
      //         user: result.data.data.user,
      //       }),
      //       { expires: 0.5 }
      //     );

      //     dispatch(
      //       userLoggedIn({
      //         accessToken: result.data.data.token,
      //         user: result.data.data.user,
      //       })
      //     );
      //   } catch (err) {
      //     // do nothing
      //   }
      // },
    }),
  }),
});

export const {
  useLoginUserMutation,
  useRegisterUserMutation,
  useConfirmEmailQuery,
  useResetPasswordMutation,
  useConfirmForgotPasswordMutation,
  useChangePasswordMutation,
  useUpdateProfileMutation,
  useSignUpProviderMutation,
  useGetUserDetailsQuery,
} = authApi;
