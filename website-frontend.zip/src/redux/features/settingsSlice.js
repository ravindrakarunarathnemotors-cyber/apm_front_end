// redux/features/settingsSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialCurrency = typeof window !== "undefined"
  ? localStorage.getItem("currency") || "LKR" // default is now LKR
  : "LKR";

const initialState = {
  currency: initialCurrency,
};

const settingsSlice = createSlice({
  name: "settings",
  initialState,
  reducers: {
    setCurrency: (state, action) => {
      state.currency = action.payload;
      if (typeof window !== "undefined") {
        localStorage.setItem("currency", action.payload);
      }
    },
  },
});

export const { setCurrency } = settingsSlice.actions;
export default settingsSlice.reducer;
