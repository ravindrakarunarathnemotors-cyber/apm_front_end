import { apiSlice } from "../api/apiSlice";

export const reviewApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    addReview: builder.mutation({
      query: (data) => ({
        url: "/product/add-review",
        method: "POST",
        body: data,
      }),
      // invalidatesTags: (result, error, arg) => ["Products",{ type: "Product", id: arg.productId }],
    }),
    addGuestReview: builder.mutation({
      query: (data) => ({
        url: "/product/add-review-guest",
        method: "POST",
        body: data,
      }),
      // invalidatesTags: (result, error, arg) => ["Products",{ type: "Product", id: arg.productId }],
    }),
  }),
});

export const {useAddReviewMutation, useAddGuestReviewMutation} = reviewApi;
