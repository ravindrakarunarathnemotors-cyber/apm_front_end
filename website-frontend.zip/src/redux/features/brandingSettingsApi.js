import { apiSlice } from "../api/apiSlice";

export const brandingSettingsApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    getBrandingSettings: builder.query({
      query: () => "/branding/settings",
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getActivePlugins: builder.query({
      query: () => "/branding/active_plugins",
      transformResponse: (response) => response.data,
    }),

    // getSlideDetails: builder.query({
    //   query: () => "/branding/slide-details",
    //   transformResponse: (response) => response.data, // 👈 transform result only
    // }),
    getSlideDetails: builder.query({
      query: (sectionId) => ({
        url: "/branding/slide-details",
        method: "POST",
        body: { sectionId },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getFeatureAreaDetails: builder.query({
      query: (sectionId) => ({
        url: "/branding/feature-area-details",
        method: "POST",
        body: { sectionId },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getBannerDetails: builder.query({
      query: (sectionId) => ({
        url: "/branding/banner-details",
        method: "POST",
        body: { sectionId },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getSpecialProductDetails: builder.query({
      query: (sectionId) => ({
        url: "/branding/special-product-details",
        method: "POST",
        body: { sectionId },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getSystemSettings: builder.query({
      query: () => "/system/settings",
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getSocialLinks: builder.query({
      query: () => "/branding/social-media",
      // transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getMaintenance: builder.query({
      query: () => "/system/webstore_maintenance",
      // transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getFullMaintenance: builder.query({
      query: () => "/system/full_maintenance",
      // transformResponse: (response) => response.data, // 👈 transform result only
    }),
  }),
});

export const {
  useGetBrandingSettingsQuery,
  useGetActivePluginsQuery,
  useGetSlideDetailsQuery,
  useGetFeatureAreaDetailsQuery,
  useGetBannerDetailsQuery,
  useGetSystemSettingsQuery,
  useGetSocialLinksQuery,
  useGetMaintenanceQuery,
  useGetFullMaintenanceQuery,
  useGetSpecialProductDetailsQuery,
} = brandingSettingsApi;
