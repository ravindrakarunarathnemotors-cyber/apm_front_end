import { apiSlice } from "../api/apiSlice";

export const homeApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    getShowCategory: builder.query({
      query: () => "/product/get-product-category",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getShowCategoryTemplate: builder.query({
      query: (sectionId) => ({
        url: "/branding/get-product-category",
        method: "POST",
        body: sectionId,
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getProductTypeCategory: builder.query({
      query: (type) =>
        `https://shofy-backend.vercel.app/api/category/show/${type}`,
    }),

    getFeaturesProducts: builder.query({
      query: (sectionId) => ({
        url: "/product/feature-products",
        method: "POST",
        body: {sectionId},
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getBestSellingProducts: builder.query({
      query: (sectionId) => ({
        url: "/product/best-selling-products",
        method: "POST",
        body: {sectionId},
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getProductsWithCollection: builder.query({
      query: (sectionId) => ({
        url: "/product/product-with-collection",
        method: "POST",
        body: {sectionId},
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),
  }),
});

export const {
  useGetProductTypeCategoryQuery,
  useGetShowCategoryQuery,
  useGetBestSellingProductsQuery,
  useGetFeaturesProductsQuery,
  useGetProductsWithCollectionQuery,
  useGetShowCategoryTemplateQuery,
} = homeApi;
