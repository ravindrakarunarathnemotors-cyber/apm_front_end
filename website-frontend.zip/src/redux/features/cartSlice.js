import { createSlice } from "@reduxjs/toolkit";
import { getLocalStorage, setLocalStorage } from "@/utils/localstorage";
import { notifyError, notifySuccess } from "@/utils/toast";

const initialState = {
  cart_products: [],
  orderQuantity: 1,
  cartMiniOpen: false,
};

export const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    add_cart_product: (state, { payload }) => {
      console.log(payload)
      const isExist = state.cart_products.some((i) => i.variant_id === payload.variant_id);

      //check mesuremtn type
      if (payload.measurement_needed) {
        if (!isExist) {
          const calQuantity = payload.count / payload.amount_per_unit;
          const newItem = {
            ...payload,
            orderQuantity: calQuantity,
          };
          state.cart_products.push(newItem);
          notifySuccess(`${state.orderQuantity} ${payload.title} added to cart`);
        } else {
          const calQuantity = payload.count / payload.amount_per_unit;
          state.cart_products = state.cart_products.map((item) => {
            if (item.variant_id !== payload.variant_id) return item;

            const newQty = item.orderQuantity + (calQuantity || 1);
            const newmeasuremntQty = item.count + (payload.count || 1);

            // if continue selling OOS → always add
            if (payload.continue_selling_oos) {
               item.orderQuantity = newQty;
              item.count = newmeasuremntQty;
              notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
              return item;
            }

            // else check stock


            if (payload.available >= newmeasuremntQty) {
              item.orderQuantity = newQty;
              item.count = newmeasuremntQty;
              notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
            } else {
              notifyError("No more quantity available for this product!");
            }

            return item;
          });
        }
      } else {
        // piece add part
        if (!isExist) {
          const newItem = {
            ...payload,
            orderQuantity: state.orderQuantity,
          };
          state.cart_products.push(newItem);
          notifySuccess(`${state.orderQuantity} ${payload.title} added to cart`);
        } else {
          state.cart_products = state.cart_products.map((item) => {
            if (item.variant_id !== payload.variant_id) return item;

            // if continue selling OOS → always add
            if (payload.continue_selling_oos) {
              item.orderQuantity += state.orderQuantity || 1;
              notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
              return item;
            }

            // else check stock
            const newQty = item.orderQuantity + (state.orderQuantity || 1);
            if (payload.available >= newQty) {
              item.orderQuantity = newQty;
              notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
            } else {
              notifyError("No more quantity available for this product!");
            }

            return item;
          });
        }
      }

      setLocalStorage("cart_products", state.cart_products);
    },
    add_cart_product_mes: (state, { payload }) => {
      console.log(payload)
      const isExist = state.cart_products.some((i) => i.variant_id === payload.variant_id);

      if (!isExist) return

      state.cart_products = state.cart_products.map((item) => {
        if (item.variant_id !== payload.variant_id) return item;

        // else check stock
        const newQty = item.orderQuantity + (state.orderQuantity || 1);
        const newmeasuremntQty = item.count + (payload.amount_per_unit || 1);

        // if continue selling OOS → always add
        if (payload.continue_selling_oos) {
          item.orderQuantity = newQty;
          item.count = newmeasuremntQty;
          notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
          return item;
        }



        if (payload.available >= newmeasuremntQty) {
          item.orderQuantity = newQty;
          item.count = newmeasuremntQty;
          notifySuccess(`${state.orderQuantity} ${item.title} added to cart`);
        } else {
          notifyError("No more quantity available for this product!");
        }

        return item;
      });


      setLocalStorage("cart_products", state.cart_products);
    },
    increment: (state, { payload }) => {
      state.orderQuantity = state.orderQuantity + 1;
    },
    decrement: (state, { payload }) => {
      state.orderQuantity =
        state.orderQuantity > 1
          ? state.orderQuantity - 1
          : (state.orderQuantity = 1);
    },
    quantityDecrement: (state, { payload }) => {
      state.cart_products.map((item) => {
        if (item.variant_id === payload.variant_id) {
          if (item.orderQuantity > 1) {
            item.orderQuantity = item.orderQuantity - 1;
          }
        }
        return { ...item };
      });
      setLocalStorage("cart_products", state.cart_products);
    },
    quantityDecrementone: (state, { payload }) => {
      state.cart_products.map((item) => {
        if (item.variant_id === payload.variant_id) {
          if (item.count > item.amount_per_unit) {
            item.orderQuantity = item.orderQuantity - 1;
            item.count = item.count - item.amount_per_unit
          }
        }
        return { ...item };
      });
      setLocalStorage("cart_products", state.cart_products);
    },
    remove_product: (state, { payload }) => {
      console.log(payload)
      state.cart_products = state.cart_products.filter(
        (item) => item.variant_id !== payload.variant_id
      );
      setLocalStorage("cart_products", state.cart_products);
      notifyError(`${payload.title} Remove from cart`);
    },
    get_cart_products: (state, action) => {
      state.cart_products = getLocalStorage("cart_products");
    },
    initialOrderQuantity: (state, { payload }) => {
      state.orderQuantity = 1;
    },
    clearCart: (state) => {
      const isClearCart = window.confirm('Are you sure you want to remove all items ?');
      if (isClearCart) {
        state.cart_products = []
      }
      setLocalStorage("cart_products", state.cart_products);
    },
    openCartMini: (state, { payload }) => {
      state.cartMiniOpen = true
    },
    closeCartMini: (state, { payload }) => {
      state.cartMiniOpen = false
    },
  },
});

export const {
  add_cart_product,
  increment,
  decrement,
  get_cart_products,
  remove_product,
  quantityDecrement,
  initialOrderQuantity,
  clearCart,
  closeCartMini,
  openCartMini,
  add_cart_product_mes,
  quantityDecrementone
} = cartSlice.actions;
export default cartSlice.reducer;
