import { apiSlice } from "../api/apiSlice";

export const categoryApi = apiSlice.injectEndpoints({
  overrideExisting:true,
  endpoints: (builder) => ({
    addCategory: builder.mutation({
      query: (data) => ({
        url: "https://shofy-backend.vercel.app/api/category/add",
        method: "POST",
        body: data,
      }),
    }),
    // getShowCategory: builder.query({
    //   query: () => `https://shofy-backend.vercel.app/api/category/show`
    // }),

    getShowCategory: builder.query({
      query: () => "/product/get-product-category",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),
    getShowCollection: builder.query({
      query: () => "/product/get-product-collection",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

     getmaxPrice: builder.query({
      query: () => "/product/highest-price",
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    getShowCategoryTemplate: builder.query({
      query: (sectionId) => ({
        url: "/branding/get-product-category",
        method: "POST",
        body: sectionId,
      }),
      transformResponse: (response) => response.result, // 👈 transform result only
    }),

    //  getFeaturesProducts: builder.query({
    //   query: (sectionId) => ({
    //     url: "/product/feature-products",
    //     method: "POST",
    //     body: sectionId,
    //   }),
    //   transformResponse: (response) => response.result, // 👈 transform result only
    // }),

    getProductTypeCategory: builder.query({
      query: (type) => `https://shofy-backend.vercel.app/api/category/show/${type}`
    }),
  }),
});

export const {
 useAddCategoryMutation,
 useGetProductTypeCategoryQuery,
 useGetShowCategoryQuery,
//  useGetFeaturesProductsQuery,
 useGetShowCategoryTemplateQuery,
 useGetmaxPriceQuery,
 useGetShowCollectionQuery
} = categoryApi;
