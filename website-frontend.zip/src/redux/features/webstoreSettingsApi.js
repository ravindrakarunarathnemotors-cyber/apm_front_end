import { apiSlice } from "../api/apiSlice";

export const webstoreSettingsApi = apiSlice.injectEndpoints({
  overrideExisting: true,
  endpoints: (builder) => ({
    getWebSections: builder.mutation({
      query: (templateId) => ({
        url: "/branding/web-template-sections",
        method: "POST",
        body: { templateId },
      }),
      transformResponse: (response) => response.data, // 👈 transform result only
    }),

    getPageContent: builder.query({
      query: () => `/user/web_pages`,
    }),
  }),
});

export const { useGetPageContentQuery, useGetWebSectionsMutation } =
  webstoreSettingsApi;
