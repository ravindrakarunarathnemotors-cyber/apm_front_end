import { createContext, useContext, useState, useEffect } from "react";

const KokoContext = createContext();

export const KokoProvider = ({ children }) => {
  const [koko, setKoko] = useState(false);
  const [kokoFee, setKokoFee] = useState({
    transaction_fee: "0",
    transaction_fixed_fee: "0",
  });

  useEffect(() => {
    const fetchKoko = async () => {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/koko/koko_status`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
            },
          },
        );

        if (response.status === 200) {
          const data = await response.json();

          setKoko(data.koko_status);
          setKokoFee(data.koko_fees);
        } else {
          console.error("Failed to fetch Koko:", response.status);
        }
      } catch (error) {
        console.error("Error fetching Koko:", error.message);
      }
    };

    fetchKoko();
  }, []);
  return (
    <KokoContext.Provider value={{ koko, setKoko, kokoFee, setKokoFee }}>
      {children}
    </KokoContext.Provider>
  );
};

export const useKoko = () => useContext(KokoContext);
