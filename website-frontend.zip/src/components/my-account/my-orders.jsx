import dayjs from "dayjs";
import Link from "next/link";
import React from "react";
import { Box, DeliveryTwo, Processing, Truck } from "@/svg";
import CustomPagination from "../CustomPagination";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

const MyOrders = ({ orderData, page, allPages, setPage }) => {
  console.log(allPages)
  const order_items = orderData?.order || [];
  const { total, pending, completed, confirmed } = orderData?.orderStatus || {};

  const symbol = useCurrencySymbol();

  const onPageChange = (pageNumber) => {
    setPage(pageNumber);
  };

  return (
    <>
      <div className="profile__main-info">
        <div className="row gx-3">
          <div className="col-md-3 col-sm-6">
            <div className="profile__main-info-item">
              <div className="profile__main-info-icon">
                <span>
                  <span className="profile-icon-count profile-download">{total ? total : 0}</span>
                  <Box />
                </span>
              </div>
              <h4 className="profile__main-info-title">Total Order</h4>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="profile__main-info-item">
              <div className="profile__main-info-icon">
                <span>
                  <span className="profile-icon-count profile-order">{pending ? pending : 0}</span>
                  <Processing />
                </span>
              </div>
              <h4 className="profile__main-info-title">Pending Order</h4>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="profile__main-info-item">
              <div className="profile__main-info-icon">
                <span>
                  <span className="profile-icon-count profile-wishlist">
                    {confirmed ? confirmed : 0}
                  </span>
                  <Truck />
                </span>
              </div>
              <h4 className="profile__main-info-title">Confirm Order</h4>
            </div>
          </div>
          <div className="col-md-3 col-sm-6">
            <div className="profile__main-info-item">
              <div className="profile__main-info-icon">
                <span>
                  <span className="profile-icon-count profile-wishlist">
                    {completed ? completed : 0}
                  </span>
                  <DeliveryTwo />
                </span>
              </div>
              <h4 className="profile__main-info-title">Complete Order</h4>
            </div>
          </div>
        </div>
      </div>
      <div className="profile__ticket table-responsive mt-30">
        {!order_items ||
          (order_items?.length === 0 && (
            <div
              style={{ height: "210px" }}
              className="d-flex align-items-center justify-content-center"
            >
              <div className="text-center">
                <i
                  style={{ fontSize: "30px" }}
                  className="fa-solid fa-cart-circle-xmark"
                ></i>
                <p>You Have no order Yet!</p>
              </div>
            </div>
          ))}
        {order_items && order_items?.length > 0 && (
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Order Id</th>
                <th scope="col">Order Time</th>
                <th scope="col">Status</th>
                <th scope="col"  style={{ padding: "16px 9.6px", textAlign: "right" }}>Total ({symbol})</th>
                <th scope="col">View</th>
              </tr>
            </thead>
            <tbody>
              {order_items.map((item, i) => (
                <tr key={i} >
                  <th scope="row" style={{ padding: "0.4rem 0.6rem" }}>#{item.id}</th>
                  <td data-info="title" style={{ padding: "0.4rem 0.6rem" }}>
                    {dayjs(item.created_at).format("MMMM D, YYYY")}
                  </td>
                  <td
                    data-info={`status ${item.order_status === "pending" ? "Pending" : ""}  ${item.order_status === "confirmed" ? "Confirmed" : ""}  ${item.order_status === "completed" ? "Completed" : ""}`}
                    className={`status ${item.order_status === "pending" ? "Pending" : ""} ${item.order_status === "confirmed" ? "Confirmed" : ""}  ${item.order_status === "completed" ? "Completed" : ""} text-capitalize`}
                    style={{ padding: "0.4rem 0.6rem" }}
                  >
                    {item.order_status}
                  </td>
                  <td style={{ padding: "0.4rem 0.6rem", textAlign: "right" }}>
                    {parseFloat(item.full_amount).toFixed(2)}
                  </td>
                  <td style={{ padding: "0.4rem 0.6rem" }}>
                    <Link href={`/order/${item.order_id}`} className="border px-2 py-1 rounded-2">
                     <i class="fa-regular fa-eye"></i>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="mt-4 d-flex justify-content-end">

        <CustomPagination
          page={page}
          onPageChange={onPageChange}
          allPages={allPages}
        />
      </div>
    </>
  );
};

export default MyOrders;
