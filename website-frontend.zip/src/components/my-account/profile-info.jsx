import React, { useEffect } from 'react';
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import * as Yup from "yup";
// internal
import ErrorMsg from '../common/error-msg';
import { EmailTwo, LocationTwo, PhoneThree, UserThree } from '@/svg';
import { useUpdateProfileMutation } from '@/redux/features/auth/authApi';
import { notifyError, notifySuccess } from '@/utils/toast';
import Swal from 'sweetalert2';
import { useRouter } from 'next/router';
import { userLoggedOut } from '@/redux/features/auth/authSlice';

// yup  schema
const schema = Yup.object().shape({
  name: Yup.string().required().label("Name"),
  lastName: Yup.string().required().label("LastName"),
  email: Yup.string().required().email().label("Email"),
  phone: Yup.string().matches(/^[0-9]+$/, "Only digits 0-9 are allowed").required().min(10).label("Phone"),
  address: Yup.string().required().label("Address"),
  bio: Yup.string().min(20).label("Bio"),
});

const ProfileInfo = ({ userData }) => {
  const { user } = useSelector((state) => state.auth);

  const [updateProfile, { }] = useUpdateProfileMutation();

   const dispatch = useDispatch();
    const router = useRouter();

  // react hook form
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    setValue("name", userData?.first_name);
    setValue("lastName", userData?.last_name);
    setValue("email", userData?.email);
    setValue("phone", userData?.contact_number_1);
    setValue("address", userData?.address);
    setValue("bio", userData?.bio);
  }, [userData])

  // on submit
  const onSubmit = (data) => {
    Swal.fire({
      title: `Update User Details`,
      text: 'Are you sure you want to update the user details?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Cancel',
      confirmButtonText: 'Confirm',
    }).then(async result => {
      if (result.isConfirmed) {

        updateProfile({
          id: userData?.customer_id,
          name: data.name,
          email: data.email,
          phone: data.phone,
          address: data.address,
          lastName: data.lastName,
        }).then((result) => {
          console.log(result)
          if (result?.error) {
            if (result?.error?.status === 401 || result?.error?.status === 403) {
              dispatch(userLoggedOut());
              router.push('/login')
            }
            notifyError(result?.error?.data?.message);
          }
          else {
            notifySuccess(result?.data?.message);
          }
        })
        // reset();

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire({
          title: 'Cancelled',
          icon: 'error',
          confirmButtonColor: '#3085d6',

        })
      }
    })

  };

  return (
    <div className="profile__info mb-30">
      <h3 className="profile__info-title">Personal Details</h3>
      <div className="profile__info-content">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="row">
            <div className="col-xxl-6 col-md-6">
              <div className="profile__input-box">
                <div className="profile__input">
                  <input {...register("name", { required: `Name is required!` })} name='name' type="text" placeholder="Enter your username" defaultValue={user?.name} />
                  <span>
                    <UserThree />
                  </span>
                  <ErrorMsg msg={errors.name?.message} />
                </div>
              </div>
            </div>

            <div className="col-xxl-6 col-md-6">
              <div className="profile__input-box">
                <div className="profile__input">
                  <input {...register("lastName", { required: `Last Name is required!` })} name='lastName' type="lastName" placeholder="Enter your Last Name" defaultValue={user?.lastName} />
                  <span>
                    <UserThree />
                  </span>
                  <ErrorMsg msg={errors.lastName?.message} />
                </div>
              </div>
            </div>

            <div className="col-xxl-12">
              <div className="profile__input-box">
                <div className="profile__input">
                  <input {...register("email", { required: `Email is required!` })} name='email' type="email" placeholder="Enter your email" defaultValue={user?.email} />
                  <span>
                    <EmailTwo />
                  </span>
                  <ErrorMsg msg={errors.email?.message} />
                </div>
              </div>
            </div>

            <div className="col-xxl-12">
              <div className="profile__input-box">
                <div className="profile__input">
                  <input {...register("phone", { required: true })} name='phone' type="text" placeholder="Enter your number" defaultValue="0123 456 7889" />
                  <span>
                    <PhoneThree />
                  </span>
                  <ErrorMsg msg={errors.phone?.message} />
                </div>
              </div>
            </div>

            <div className="col-xxl-12">
              <div className="profile__input-box">
                <div className="profile__input">
                  <input {...register("address", { required: true })} name='address' type="text" placeholder="Enter your address" defaultValue="3304 Randall Drive" />
                  <span>
                    <LocationTwo />
                  </span>
                  <ErrorMsg msg={errors.address?.message} />
                </div>
              </div>
            </div>

            {/* <div className="col-xxl-12">
              <div className="profile__input-box">
                <div className="profile__input">
                  <textarea {...register("bio", { required: true })} name='bio' placeholder="Enter your bio" defaultValue="Hi there, this is my bio..." />
                  <ErrorMsg msg={errors.bio?.message} />
                </div>
              </div>
            </div> */}
            <div className="col-12 ">
              <div className="profile__btn d-flex justify-content-end">
                <button type="submit" className="tp-btn">Update Profile</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProfileInfo;