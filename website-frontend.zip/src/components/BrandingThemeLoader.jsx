// /components/BrandingThemeLoader.jsx
import { useEffect } from "react";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi"; 
// ^ adjust the hook name if yours differs

export default function BrandingThemeLoader() {
  const { data } = useGetBrandingSettingsQuery();

  useEffect(() => {
    // Some backends wrap payload as { data: {...} } – support both
    const brand = data?.data || data;
    if (!brand) return;

    const root = document.documentElement;
    const setVar = (k, v) => v && root.style.setProperty(k, v);

    setVar("--primary-color", brand.primary_color);
    setVar("--tp-theme-primary", brand.primary_color);
    setVar("--tp-theme-brown", brand.button_secondary_color);
    setVar("--swiper-theme-color", brand.primary_color);
    setVar("--secondary-color", brand.secondary_color);
    setVar("--tp-heading-primary", brand.title_color);
    setVar("--subtitle-color", brand.subtitle_color);
    setVar("--tp-text-body", brand.text_color);
    setVar("--background-color", brand.background_color);

    setVar("--button-primary-color", brand.button_primary_color);
    setVar("--btn-primary", brand.button_primary_color);
    setVar("--button-secondary-color", brand.button_secondary_color); 
    setVar("--tp-theme-secondary", brand.button_secondary_color); 
    setVar("--button-success-color", brand.button_success_color);
    setVar("--button-warning-color", brand.button_warning_color);
    setVar("--button-danger-color", brand.button_danger_color);

    // Map into Bootstrap’s theme vars too
    setVar("--bs-primary", brand.primary_color);
    setVar("--bs-secondary", brand.secondary_color);
    setVar("--bs-body-color", brand.text_color);
    setVar("--bs-link-color", brand.primary_color);


    setVar("--tp-ff-body", brand.font_family);
    setVar("--tp-ff-jost", brand.font_family);

    // Optional: persist so next load can paint instantly from localStorage
    localStorage.setItem("branding_theme", JSON.stringify(brand));
  }, [data]);

  return null;
}
