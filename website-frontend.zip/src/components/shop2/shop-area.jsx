import React, { useState } from "react";
import Pagination from "@/ui/Pagination";
import ProductItem from "../products/fashion/product-item";
import ShopListItem from "./shop-list-item";
import CategoryFilter from "./shop-filter/category-filter";
import ColorFilter from "./shop-filter/color-filter";
import PriceFilter from "./shop-filter/price-filter";
import ProductBrand from "./shop-filter/product-brand";
import StatusFilter from "./shop-filter/status-filter";
import TopRatedProducts from "./shop-filter/top-rated-products";
import ResetButton from "./shop-filter/reset-button";
import CustomPagination from "../CustomPagination";
import { Filter, GridTab, ListTab } from "@/svg";
import { useDispatch } from "react-redux";

import NiceSelect from "@/ui/nice-select";
import { handleFilterSidebarOpen } from "@/redux/features/shop-filter-slice";
import { useRouter } from "next/router";
import ProductItemDirect from "../products/fashion/product-direct-item";

const ShopArea = ({
  products,
  otherProps,
  page, setPage, allPages, setAllPages, total,
  setSelectValue, selectValue, setStatus,
  maxValue, handleFinalChange
}) => {
  // Tab state: "grid" or "list"
  const [activeTab, setActiveTab] = useState("grid");
  const { priceFilterValues } = otherProps;

  const dispatch = useDispatch()
  const router = useRouter();

  const onPageChange = (pageNumber) => {
    setPage(pageNumber)
  }

  const hanldeDropdown = (e) => {
    setSelectValue(e.target.value)
    setPage(1)

    router.push({
      pathname: '/',
      query: {
        ...router.query,
        orderby: e.target.value
      }
    });
  }
  return (
    <section className="tp-shop-area pb-120">
      <div className="container">
          {/* Sidebar Filters */}
          {/* <div className="col-12 d-none d-lg-block">
            <div className="tp-shop-sidebar mr-10 d-flex flex-row">
              <PriceFilter
                priceFilterValues={priceFilterValues}
                maxPrice={maxValue}
                handleFinalChange={handleFinalChange}

              />
              <StatusFilter setCurrPage={setPage} setStatus={setStatus} />
              <CategoryFilter setCurrPage={setPage} />
              <ColorFilter setCurrPage={setPage} />
              <TopRatedProducts />
              <ProductBrand setCurrPage={setPage} />
              <ResetButton />
            </div>
          </div> */}
          {/* Main Content */}
          <div className="col-12">
            <div className="tp-shop-main-wrapper">
              {/* Top Bar */}
              <div className="tp-shop-top mb-45">
                <div className="row ">
                  <div className="col-xl-6">
                    <div className="tp-shop-top-left d-flex align-items-center gap-3">
                      {/* Tab Buttons */}
                      <ul
                        className="nav nav-tabs"
                        id="productTab"
                        role="tablist"
                      >
                        <li className="nav-item" role="presentation">
                          <button
                            className={`nav-link ${activeTab === "grid" ? "active" : ""
                              }`}
                            id="grid-tab"
                            type="button"
                            role="tab"
                            aria-selected={activeTab === "grid"}
                            onClick={() => setActiveTab("grid")}
                          >
                            <GridTab />
                          </button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button
                            className={`nav-link ${activeTab === "list" ? "active" : ""
                              }`}
                            id="list-tab"
                            type="button"
                            role="tab"
                            aria-selected={activeTab === "list"}
                            onClick={() => setActiveTab("list")}
                          >
                            <ListTab />
                          </button>
                        </li>
                      </ul>
                      {/* Results text */}
                      <div className="tp-shop-top-result ms-3">
                        <p>
                          Showing{" "}
                          {products.length === 0 ? 0 : (page - 1) * products.length + 1}–
                          {Math.min(
                            page * products.length
                          )}{" "}
                          of {total} results
                        </p>
                      </div>
                    </div>
                  </div>
                  {/* Sort Dropdown */}
                  <div className="col-xl-6 d-flex justify-content-xl-end align-items-center mt-3 mt-lg-0 gap-3">
                    <div className="tp-shop-top-filter d-block d-lg-none ms-0">
                      <button onClick={() => dispatch(handleFilterSidebarOpen())} type="button" className="tp-filter-btn">
                        <span>
                          <Filter />
                        </span>
                        {" "}Filter
                      </button>
                    </div>
                    <div className="tp-shop-top-select">
                      <select
                        className="form-select"
                        onChange={hanldeDropdown}
                        value={selectValue || "NewAdded"}
                      >
                        <option value="LowtoHigh">Low to High</option>
                        <option value="HightoLow">High to Low</option>
                        <option value="NewAdded">New Added</option>
                      </select>
                    </div>

                  </div>
                </div>
              </div>


              {/* Grid/List Content */}
              <div className="tp-shop-items-wrapper tp-shop-item-primary">
                {products.length === 0 ? (
                  <div
                    className="d-flex justify-content-center align-items-center"
                    style={{ minHeight: 250 }}
                  >
                    <h4 className="text-danger mb-0">
                      No products found for the selected filters.
                    </h4>
                  </div>
                ) : (
                  <div className="tab-content" id="productTabContent">


                    {/* Grid View */}
                    <div
                      className={`tab-pane fade${activeTab === "grid" ? " show active" : ""
                        }`}
                      id="grid-tab-pane"
                      role="tabpanel"
                      aria-labelledby="grid-tab"
                      tabIndex="0"
                    >
                      <div className="row">
                        {products.map((item) => (
                          <div
                            key={item._id}
                            className="col-xl-3 col-md-4 col-sm-6"
                          >
                            {process.env.NEXT_PUBLIC_ONE_VARIANT === true ? (
                              <ProductItemDirect product={item} />
                            ) : (
                              <ProductItem product={item} />
                            )}

                          </div>
                        ))}
                      </div>
                    </div>



                    {/* List View */}
                    <div
                      className={`tab-pane fade${activeTab === "list" ? " show active" : ""
                        }`}
                      id="list-tab-pane"
                      role="tabpanel"
                      aria-labelledby="list-tab"
                      tabIndex="0"
                    >
                      <div className="tp-shop-list-wrapper tp-shop-item-primary mb-70">
                        <div className="row">
                          <div className="col-xl-12">
                            {products.map((item) => (
                              <ShopListItem key={item._id} product={item} />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              {/* Pagination */}
              {/* {filteredRows.length > countOfPage && (
                <div className="tp-shop-pagination mt-20">
                  <div className="tp-pagination">
                    <Pagination
                      items={filteredRows}
                      countOfPage={countOfPage}
                      paginatedData={() => { }}
                      currPage={currPage}
                      setCurrPage={setCurrPage}
                    />

                  </div>
                </div>
              )} */}
              {/* {products && products.length > 0 && (
                <CustomPagination page={page} onPageChange={onPageChange} allPages={allPages} />
              )} */}
            </div>
          </div>
        <div className="row">
        </div>
      </div>
    </section>
  );
};

export default ShopArea;
