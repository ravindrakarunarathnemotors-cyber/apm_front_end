import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import Image from "next/image";
import { Rating } from "react-simple-star-rating";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
// internal
import { Cart, CompareThree, QuickView, Wishlist } from "@/svg";
import { handleProductModal } from "@/redux/features/productModalSlice";
import { add_cart_product } from "@/redux/features/cartSlice";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import { add_to_compare } from "@/redux/features/compareSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

const ShopListItem = ({ product }) => {
  const {
    _id,
    img,
    category,
    title,
    reviews,
    price,
    discount,
    tags,
    description,
    total_stock,
    continue_selling_oos
  } = product || {};

  const symbol = useCurrencySymbol();
  const dispatch = useDispatch();
  const [ratingVal, setRatingVal] = useState(0);
  useEffect(() => {
    if (reviews && reviews.length > 0) {
      const rating =
        reviews.reduce((acc, review) => acc + review.rating, 0) /
        reviews.length;
      setRatingVal(rating);
    } else {
      setRatingVal(0);
    }
  }, [reviews]);

  const [maxWidth, setMaxWidth] = useState("100%");

  useEffect(() => {
    const updateWidth = () => {
      if (window.innerWidth >= 768) {
        setMaxWidth("300px"); // md and above
      } else if (window.innerWidth >= 576) {
        setMaxWidth("200px"); // sm and above
      } else {
        setMaxWidth("100%"); // xs
      }
    };
    updateWidth();
    window.addEventListener("resize", updateWidth);
    return () => window.removeEventListener("resize", updateWidth);
  }, []);

  // handle add product
  const handleAddProduct = (prd) => {
    dispatch(add_cart_product(prd));
  };
  // handle wishlist product
  const handleWishlistProduct = (prd) => {
    dispatch(add_to_wishlist(prd));
  };

  // handle compare product
  const handleCompareProduct = (prd) => {
    dispatch(add_to_compare(prd));
  };

  const stripHtml = (html) => {
    if (typeof window !== "undefined") {
      const doc = new DOMParser().parseFromString(html, "text/html");
      return doc.body.textContent || "";
    }
    return "";
  };

  return (
    <Link href={`/product/${slugify(title)}-${_id}`}>
      <div className="tp-product-list-item d-sm-flex border rounded overflow-hidden mb-2">
        <div className="tp-product-list-thumb p-relative fix overflow-hidden" style={{maxWidth }}>
          <Link href={`/product/${slugify(title)}-${_id}`}>
            {/* <Image
              src={img}
              alt={`${title} product image` || "product image"}
              width={280}
              height={280}
              style={{ padding: "2px" }}
            /> */}
            <Image
              src={img || "/assets/img/shop/product-default.jpg"}
              alt={`${title} product image` || "product image"}
              width={500}
              height={500}  // just a placeholder aspect ratio
              style={{ width: "100%", height: "auto", objectFit: "contain" }}
            />
            {total_stock < 1 && !continue_selling_oos && (
              <div className="tp-product-badge rounded-pill overflow-hidden">
                <span className="product-hot">SOLD OUT</span>
              </div>
            )}
          </Link>
        </div>

        <div className="tp-product-list-content w-100 border-0">
          <div className="tp-product-content-2 pt-15">
            <div className="tp-product-tag-2">
              {tags?.map((t, i) => (
                <a key={i} href="#">
                  {t}
                </a>
              ))}
            </div>
           
            <div
              style={{
                fontSize: "1rem",
                display: "-webkit-box",
                lineHeight: "1.4",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
                textOverflow: "ellipsis",
                wordBreak: "break-word",
                textTransform: "capitalize",

              }}>
                 <Link href={`/product/${slugify(title)}-${_id}`}>
                {title}
              </Link>
            </div>

            {/* <div className="tp-product-rating-icon tp-product-rating-icon-2">
              <Rating
                allowFraction
                size={16}
                initialValue={ratingVal}
                readonly={true}
              />
            </div> */}
            <div className="tp-product-price-wrapper-2">
              {discount > 0 ? (
                <>
                  <span className="tp-product-price-2 new-price">
                    {symbol}
                    {price}
                  </span>
                  <span className="tp-product-price-2 old-price">
                    {" "}
                    {symbol}
                    {(
                      Number(price) -
                      (Number(price) * Number(discount)) / 100
                    ).toFixed(2)}
                  </span>
                </>
              ) : (
                <span className="tp-product-price-3">
                  {symbol}
                  {price}
                </span>
              )}
            </div>
            <div className="tp-product-price-wrapper-2 text-break capitalize d-block d-sm-none d-md-block">
              <p>{stripHtml(description)?.substring(0, 100) + "..."}</p>
            </div>

            <div className="tp-product-list-add-to-cart">
              {/* <button
              onClick={() => handleAddProduct(product)}
              className="tp-product-list-add-to-cart-btn rounded-3"
            >
              Buy Now
            </button> */}
              <Link
                href={`/product/${slugify(title)}-${_id}`}
                className="tp-product-list-add-to-cart-btn rounded-3"
              >
                Buy Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ShopListItem;
