import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { useDispatch } from "react-redux";
import ErrorMsg from "@/components/common/error-msg";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import { handleFilterSidebarClose } from "@/redux/features/shop-filter-slice";
import ShopCategoryLoader from "@/components/loader/shop/shop-category-loader";
import { ArrowRightSm, ArrowDownSm, DotIcon } from "@/svg";
import { Icon } from "@iconify/react";

const CategoryFilter = ({ setCurrPage, shop_right = false }) => {
  const { data: categories, isLoading, isError } = useGetShowCategoryQuery();
  const router = useRouter();
  const dispatch = useDispatch();
  const [expanded, setExpanded] = useState({});
  const [allExpanded, setAllExpanded] = useState(false);
  console.log(allExpanded)
  const slugify = (str) =>
    str.toLowerCase().replace("&", "").split(" ").join("-");

  useEffect(() => {
    if (!categories || !router.query.category) return;
    const activeSlug = router.query.category;
    const matched = categories.find((cat) => slugify(cat.name) === activeSlug);
    if (matched) {
      const expandedMap = {};
      let current = matched;
      while (current) {
        expandedMap[current.category_id] = true;
        current = categories.find(
          (p) => p.category_id === current.category_under
        );
      }
      setExpanded((prev) => ({ ...prev, ...expandedMap }));
    }
  }, [categories, router.query.category]);

  const toggleExpand = (category_id) => {
    setExpanded((prev) => ({ ...prev, [category_id]: !prev[category_id] }));
  };

  const handleToggleAll = () => {
    if (!categories) return;
    const newState = {};
    categories.forEach((cat) => {
      newState[cat.category_id] = !allExpanded;
    });
    setExpanded(newState);
    setAllExpanded(!allExpanded);
  };

  const buildCategoryTree = (flatList) => {
    const map = {};
    const roots = [];
    flatList.forEach(
      (cat) => (map[cat.category_id] = { ...cat, children: [] })
    );
    flatList.forEach((cat) => {
      if (cat.category_under) {
        map[cat.category_under]?.children.push(map[cat.category_id]);
      } else {
        roots.push(map[cat.category_id]);
      }
    });
    console.log(roots)
    return roots;
  };

  const handleCategoryRoute = (title) => {
    setCurrPage(1);
    const slug = slugify(title);
    // router.push( `/shop?category=${slug}`);
    router.push({
      pathname: "/shop",
      query: {
        ...router.query, // keep existing query params
        category: slug, // update / add category
      },
    });
    dispatch(handleFilterSidebarClose());
  };

 const INDENT_PX = 16; // how much to indent per level

const renderCategory = (category, level = 0) => {
  const hasChildren = category.children?.length > 0;
  const isExpanded = expanded[category.category_id] ?? false;
  const selected = router.query.category === slugify(category.name);

  return (
    <li key={category.category_id} className="mb-1">
      <div
        className="d-flex align-items-center gap-2"
        style={{ paddingLeft: level * INDENT_PX }}
      >
        {/* --- ICON AREA --- */}
        {hasChildren ? (
          <button
            onClick={() => toggleExpand(category.category_id)}
            className="btn btn-sm p-0 border-0 bg-transparent"
            title={isExpanded ? "Collapse" : "Expand"}
            style={{ width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center" }}
          >
            {isExpanded ? (
              <Icon icon="mdi:keyboard-arrow-up" width="20" height="20" />
            ) : (
              <ArrowDownSm />
            )}
          </button>
        ) : (
          // dash icon for categories without children
          <span
            style={{
              width: 24,
              height: 24,
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <Icon icon="radix-icons:dash" width="18" height="18" className="text-muted" />
          </span>
        )}

        {/* --- CATEGORY NAME --- */}
        <a
          onClick={() => handleCategoryRoute(category.name)}
          className={`d-flex justify-content-between align-items-center w-100 py-1 px-2 rounded text-decoration-none ${
            selected ? "text-white fw-semibold" : "text-dark"
          }`}
          style={{
            cursor: "pointer",
            backgroundColor: selected ? "var(--secondary-color)" : "transparent",
          }}
        >
          {category.name}
          <span className="badge bg-light text-dark ms-2">
            {category.product_count}
          </span>
        </a>
      </div>

      {/* --- CHILDREN --- */}
      {hasChildren && (
        <div
          style={{
            overflow: "hidden",
            maxHeight: isExpanded ? "500px" : "0",
            transition: "max-height 0.3s ease",
          }}
        >
          <ul className="list-unstyled ps-0 mt-1">
            {category.children.map((child) => renderCategory(child, level + 1))}
          </ul>
        </div>
      )}
    </li>
  );
};




  let content = null;
  if (isLoading) {
    content = <ShopCategoryLoader loading={isLoading} />;
  } else if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  } else if (categories?.length === 0) {
    content = <ErrorMsg msg="No Category found!" />;
  } else {
    const tree = buildCategoryTree(categories);
    content = tree.map((cat) => renderCategory(cat));
  }

  return (
    <div className="tp-shop-widget mb-4">
      <h3 className="tp-shop-widget-title mb-3 d-flex justify-content-between align-items-center">
        Categories
        {categories?.length > 0 && (
          <button
            className="btn btn-sm btn-primary"
            style={{
              backgroundColor: "var(--primary-color)",
              borderColor: "var(--primary-color)",
            }}
            onClick={handleToggleAll}
          >
            {allExpanded ? "Collapse All" : "Expand All"}
          </button>
        )}
      </h3>
      <div className="tp-shop-widget-content">
        <ul className="list-unstyled ps-0 mb-0">{content}</ul>
      </div>
    </div>
  );
};

export default CategoryFilter;
