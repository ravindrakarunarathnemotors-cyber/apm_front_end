// components/product_seo.jsx
import Head from "next/head";
import { slugify } from "@/lib/slugify";

const stripHtml = (html) => {
  if (!html) return "";
  // Simple server-safe stripper
  return String(html).replace(/<[^>]+>/g, "");
};

export default function 
ProductSeo({
  product,
  branding,
  system,
  productAvailability,
}) {
  const availabilityRaw = productAvailability?.availability ?? 0;
  const availabilityNum = Number(availabilityRaw) || 0;

  const siteName =
    branding?.website_url ||
    process.env.NEXT_PUBLIC_SITE_URL || 
    "";
  const company_name = branding?.company_name || "Company Name";
  const currency = system?.currency || "LKR";

  const description = stripHtml(
    product?.search_engine_desc || product?.description || ""
  ).slice(0, 160);

  const productUrl = `${siteName}/product/${slugify(
    product?.title
  )}-${product?.product_id}`;
console.log('productSEO', productUrl, product?.title, product?.product_id,product?.media_url, description, branding?.website_url );
  return (
    <Head>
      <title>{product?.title}</title>

      {/* OpenGraph */}
      <meta property="og:type" content="product" />
      <meta property="og:title" content={product?.title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={productUrl} />
      {/* <meta property="og:image" content={product.media_url} /> */}
      <meta property="og:image" content={product?.media_url} />

      <meta
        property="product:price:amount"
        content={String(product?.price)}
      />
      <meta
        property="product:price:currency"
        content={currency}
      />
      <meta
        property="product:availability"
        content={availabilityNum > 0 ? "in stock" : "out of stock"}
      />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={product?.title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={product?.media_url} />

      {/* JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org/",
            "@type": "Product",
            name: product?.title,
            image: [product?.media_url],
            description,
            sku: String(product?.product_id),
            brand: {
              "@type": "Brand",
              name: company_name,
            },
            offers: {
              "@type": "Offer",
              url: productUrl,
              priceCurrency: currency,
              price: product?.price,
              availability:
                availabilityNum > 0
                  ? "https://schema.org/InStock"
                  : "https://schema.org/OutOfStock",
              itemCondition: "https://schema.org/NewCondition",
            },
          }),
        }}
      />
    </Head>
  );
}
