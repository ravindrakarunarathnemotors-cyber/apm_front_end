import { useRef, useEffect, useState } from "react";


export default function FadeInOnScroll({ children, delay = 0 }) {
  const ref = useRef(null);
  const [isVisible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // delay supports subtle staggering of sections
          const t = setTimeout(() => setVisible(true), delay * 1000);
          observer.unobserve(entry.target);
          return () => clearTimeout(t);
        }
      },
      { threshold: 0.15 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [delay]);

 return (
    <div
      ref={ref}
      className={`fade-in-section ${isVisible ? "is-visible" : ""}`}
    >
      {children}
      <style jsx>{`
        .fade-in-section {
          opacity: 0;
          transform: translateY(30px); /* Start slightly lower */
          transition: 
            opacity 1.2s cubic-bezier(0.4, 0, 0.2, 1), 
            transform 1.2s cubic-bezier(0.4, 0, 0.2, 1);
          will-change: opacity, transform;
        }

        .fade-in-section.is-visible {
          opacity: 1;
          transform: translateY(0); /* Slide up to original position */
        }
      `}</style>
    </div>
  );
}
