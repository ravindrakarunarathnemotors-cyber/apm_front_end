import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { Swiper, SwiperSlide } from "swiper/react";
import { Scrollbar, Autoplay } from "swiper";
import { useGetShowCategoryTemplateQuery } from "@/redux/features/categoryApi";

// Internal
import ErrorMsg from "../common/error-msg";
import { ArrowRightSm, ArrowRightSmTwo } from "@/svg";
import { HomeThreeCategoryLoader } from "../loader";

// Swiper Styles
import "swiper/css";
import "swiper/css/scrollbar";

const slider_setting = {
  slidesPerView: 4,
  spaceBetween: 24,
  autoplay: {
    delay: 4000,
    disableOnInteraction: false,
  },
  scrollbar: {
    el: ".tp-category-swiper-scrollbar",
    draggable: true,
  },
  breakpoints: {
    0: { slidesPerView: 1.2, spaceBetween: 16 },
    576: { slidesPerView: 2, spaceBetween: 20 },
    992: { slidesPerView: 3, spaceBetween: 24 },
    1200: { slidesPerView: 4, spaceBetween: 24 },
  },
};

const BeautyCategory = ({ sectionId, bgClass }) => {
  const {
    data: categories,
    isLoading,
    isError,
  } = useGetShowCategoryTemplateQuery({ sectionId });
  const router = useRouter();

  const handleCategoryRoute = (title) => {
    const slug = title.toLowerCase().replace("&", "").split(" ").join("-");
    router.push(`/shop?category=${slug}`);
  };

  if (isLoading) return <HomeThreeCategoryLoader loading={isLoading} />;
  if (isError) return <ErrorMsg msg="Failed to load categories" />;
  if (!categories?.length) return null;

  return (
    <section
      className={`tp-category-area pt-80 pb-80 ${bgClass} overflow-hidden`}
    >
      <div className="container">
        {/* Header Section */}
        <div className="row align-items-end mb-50">
          <div className="col-lg-7">
            <div className="tp-section-title-wrapper-3">
              <span
                className=" tp-featured-title-3"
                style={{
                  color: "var(--tp-theme-primary)",
                  fontWeight: "600",
                  letterSpacing: "1px",
                  textTransform: "uppercase",
                  fontSize: "14px",
                  marginBottom: "10px",
                  display: "block",
                }}
              >
                Curated Collections
              </span>
              <h2
                className="tp-section-title-3"
                style={{
                  fontSize: "clamp(28px, 4vw, 42px)",
                  fontWeight: "700",
                }}
              >
                Shop by Category
              </h2>
            </div>
          </div>
          <div className="col-lg-5 text-lg-end d-none d-md-block">
            <div className="tp-product-more-3 text-md-end">
              <Link
                href="/shop"
                className="tp-btn-border"         
              >
                Explore All <ArrowRightSmTwo />
              </Link>
            </div>
          </div>
        </div>

        {/* Categories Slider */}
        <div className="row">
          <div className="col-12">
            <Swiper
              {...slider_setting}
              modules={[Scrollbar, Autoplay]}
              className="tp-category-slider-active-4"
            >
              {categories.map((item) => (
                <SwiperSlide key={item.category_id}>
                  <div
                    className="category-card-modern group"
                    onClick={() => handleCategoryRoute(item.name)}
                  >
                    <div className="category-image-wrapper">
                      <div
                        className="category-bg-img"
                        style={{ backgroundImage: `url(${item.desktop_url})` }}
                      />
                      <div className="category-overlay" />
                    </div>

                    <div className="category-info">
                      <h3 className="category-name">{item.name}</h3>
                      <p className="category-count">
                        {item.product_count} Items
                      </p>
                      <span className="category-link">
                        Discover <ArrowRightSm />
                      </span>
                    </div>
                  </div>
                </SwiperSlide>
              ))}

              {/* Custom Scrollbar Styling */}
              <div className="tp-category-swiper-scrollbar mt-50"></div>
            </Swiper>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BeautyCategory;
