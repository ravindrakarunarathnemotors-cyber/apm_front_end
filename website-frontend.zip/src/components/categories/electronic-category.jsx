import React from "react";
import Image from "next/image";
import { useRouter } from "next/router";
// internal
import ErrorMsg from "../common/error-msg";
import { useGetProductTypeCategoryQuery } from "@/redux/features/categoryApi";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import HomeCateLoader from "../loader/home/home-cate-loader";
import { Swiper, SwiperSlide } from "swiper/react";
import { Scrollbar, Pagination } from "swiper";
import "swiper/css"; // Make sure Swiper's CSS is loaded!
import "swiper/css/scrollbar";

const slider_setting = {
  slidesPerView: 5,
  spaceBetween: 24,
  scrollbar: {
    el: ".tp-category-swiper-scrollbar",
    draggable: true,
  },
  breakpoints: {
    100: { slidesPerView: 1 },
    576: { slidesPerView: 2 },
    992: { slidesPerView: 4 },
    1200: { slidesPerView: 5 },
  },
};

const ElectronicCategory = () => {
  const { data: categories, isLoading, isError } = useGetShowCategoryQuery();
  const router = useRouter();

  // handle category route
  const handleCategoryRoute = (title) => {
    router.push(
      `/shop?category=${title
        .toLowerCase()
        .replace("&", "")
        .split(" ")
        .join("-")}`
    );
  };
  // decide what to render
  let content = null;

  if (isLoading) {
    content = <HomeCateLoader loading={isLoading} />;
  } else if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  } else if (
    !categories ||
    !Array.isArray(categories) ||
    categories.length === 0
  ) {
    content = <ErrorMsg msg="No Category found!" />;
  } else {
    // Show only main categories (category_under === null)
    const category_items = categories.filter(
      (item) => item.category_under === null
    );
    content = (
      <Swiper
        {...slider_setting}
        modules={[Scrollbar]}
        className="tp-category-slider-active-4 swiper-container mb-70"
      >
        {category_items.map((item) => (
          <SwiperSlide key={item.category_id}>
            <div className="tp-product-category-item text-center mb-40">
              <div className="tp-product-category-thumb fix">
                <a
                  className="cursor-pointer"
                  onClick={() => handleCategoryRoute(item.name)}
                >
                  <Image
                    src={item.desktop_url || "/images/placeholder.png"}
                    alt="product-category"
                    width={98}
                    height={98}
                  />
                </a>
              </div>
              <div className="tp-product-category-content">
                <h3 className="tp-product-category-title">
                  <a
                    className="cursor-pointer"
                    onClick={() => handleCategoryRoute(item.name)}
                  >
                    {item.name}
                  </a>
                </h3>
                <p>{item.product_count} Product</p>
              </div>
            </div>
          </SwiperSlide>
        ))}
        {/* Custom scrollbar */}
        <div className="tp-category-swiper-scrollbar tp-swiper-scrollbar"></div>
      </Swiper>
    );
  }
  return (
    <section className="tp-product-category pt-60 pb-15">
      <div className="container">
        <div className="row d-flex flex-wrap">
          <div className="col-xl-12">
            <div className="tp-category-slider-4">{content}</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ElectronicCategory;
