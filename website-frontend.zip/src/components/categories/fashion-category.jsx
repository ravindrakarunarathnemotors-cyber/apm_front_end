import React from "react";
import { useRouter } from "next/router";
import { Swiper, SwiperSlide } from "swiper/react";
import { Scrollbar } from "swiper";
// internal
import ErrorMsg from "../common/error-msg";
import { ArrowRightLong } from "@/svg";
import { HomeTwoCateLoader } from "../loader";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import { useGetProductTypeCategoryQuery, useGetShowCategoryTemplateQuery } from "@/redux/features/categoryApi";


const slider_setting = {
  slidesPerView: 3, 
  spaceBetween: 24,
  scrollbar: {
    el: ".tp-category-swiper-scrollbar",
    draggable: true,
  },
  breakpoints: {
    320: { slidesPerView: 1 },
    768: { slidesPerView: 2 },
    1200: { slidesPerView: 3 },
  },
};



const FashionCategory = (sectionId) => {
    const { data: categories, isLoading, isError } = useGetShowCategoryTemplateQuery(sectionId);
  // const { data: categories, isLoading, isError } = useGetShowCategoryQuery();
  const router = useRouter();
  console.log('firstData', categories);

  // handle category route
  const handleCategoryRoute = (title) => {
    router.push(
      `/shop?category=${title
        .toLowerCase()
        .replace("&", "")
        .split(" ")
        .join("-")}`
    );
  };

  let content = null;

  if (isLoading) {
    content = <HomeTwoCateLoader loading={isLoading} />;
  } else if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  } else if (categories?.length === 0) {
    content = <ErrorMsg msg="No Category found!" />;
  } else if (categories?.length > 0) {
    // If you only want parent categories, you can filter here:
    // const category_items = categories.result.filter(item => item.isParent);
        const category_items = categories.filter( (item) => item.category_under === null );

    content = (
      <Swiper
        {...slider_setting}
        modules={[Scrollbar]}
        className="tp-category-slider-active-4 swiper-container py-4"
      >
        {category_items.map((item) => (
          <SwiperSlide key={item.category_id}>
            <div className="tp-banner-item-2 p-relative z-index-1 grey-bg-2 mb-20 fix rounded-4">
              <div
                className="tp-banner-thumb-2 include-bg transition-3"
                style={{ backgroundImage: `url(${item.desktop_url})` }}
              ></div>
              <h3 className="tp-banner-title-2">
                <a
                  className="cursor-pointer capitalize"
                  onClick={() => handleCategoryRoute(item.name)}
                >
                  {item.name}
                </a>
              </h3>
              <div className="tp-banner-btn-2">
                <a
                  onClick={() => handleCategoryRoute(item.name)}
                  className="cursor-pointer tp-btn tp-btn-border tp-btn-border-sm rounded-5"
                >
                  Shop Now <ArrowRightLong />
                </a>
              </div>
            </div>
          </SwiperSlide>
        ))}
        {/* Custom scrollbar below */}
                <div className="tp-category-swiper-scrollbar tp-swiper-scrollbar ml-180 mr-180"></div>
      </Swiper>
    );
  }

  return (
    <>
      <section className="tp-banner-area py-4">
        <div className="container-fluid tp-gx-40">
          <div className="row tp-gx-20">
            {content}
          </div>
        </div>
      </section>
    </>
  );
};

export default FashionCategory;
