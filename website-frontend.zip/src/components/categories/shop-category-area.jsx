import React from "react";
import ErrorMsg from "../common/error-msg";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import { useRouter } from "next/router";
import { Swiper, SwiperSlide } from "swiper/react";
import { Scrollbar, Pagination } from "swiper";
import "swiper/css"; // Make sure Swiper's CSS is loaded!
import "swiper/css/scrollbar";

import ShopCategoryLoader from "../loader/shop/shop-category-loader";

const slider_setting = {
  slidesPerView: 4,
  spaceBetween: 24,
  scrollbar: {
    el: ".tp-category-swiper-scrollbar",
    draggable: true,
  },
  breakpoints: {
    320: { slidesPerView: 1 },
    576: { slidesPerView: 2 },
    992: { slidesPerView: 3 },
    1200: { slidesPerView: 4 },
  },
};

const ShopCategoryArea = () => {
  const { data: categories, isLoading, isError } = useGetShowCategoryQuery();
  const router = useRouter();

  // handle category route
  const handleCategoryRoute = (title) => {
    router.push(
      `/shop?category=${title
        .toLowerCase()
        .replace("&", "")
        .split(" ")
        .join("-")}`
    );
  };

  // decide what to render
  let content = null;

  if (isLoading) {
    content = <ShopCategoryLoader loading={isLoading} />;
  }
  if (!isLoading && isError) {
    content = <ErrorMsg msg="There was an error" />;
  }
  if (!isLoading && !isError && categories?.length === 0) {
    content = <ErrorMsg msg="No Category found!" />;
  }
  if (!isLoading && !isError && categories?.length > 0) {
    const category_items = categories.filter( (item) => item.category_under === null );
    content = (
      <Swiper
        {...slider_setting}
        modules={[Scrollbar]}
        className="tp-category-slider-active-4 swiper-container mb-70"
      >
        {category_items.map((item) => (
          <SwiperSlide key={item.category_id}>
            <div
              className="tp-category-main-box mb-25 p-relative fix"
              style={{ backgroundColor: "#F3F5F7" }}
            >
              <div className="tp-category-main-content">
                <h3
                  className="tp-category-main-title pb-1"
                  onClick={() => handleCategoryRoute(item.name)}
                >
                  <a className="cursor-pointer">{item.name}</a>
                </h3>
                <span className="tp-category-main-item">
                  {item.product_count} Products
                </span>
              </div>
            </div>
          </SwiperSlide>
        ))}

        <div className="tp-category-swiper-scrollbar tp-swiper-scrollbar"></div>
      </Swiper>
    );
  }
  return (
    <>
      {/* <section className="tp-category-area pb-120"> */}
      <section
        className="tp-category-area pt-70 pb-70 tp-category-plr-85"
        style={{ backgroundColor: `#fff` }}
      >
        <div className="container">
          {/* <div className="row">{content}</div> */}
          <div className="row">
            <div className="col-xl-12">
              <div className="tp-section-title-wrapper-4 mb-20 text-center" >
                <span className="tp-section-title-pre-4">Shop by Category</span>
              </div>
            </div>
          </div>
          <div className="row d-flex flex-wrap">
            <div className="col-xl-12">
              <div className="tp-category-slider-4">
                {content}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ShopCategoryArea;
