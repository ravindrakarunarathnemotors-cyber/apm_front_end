import React, { useState } from "react";
import Image from "next/image";
import Slider from "react-slick";
// internal
import slider_img_1 from "@assets/img/slider/4/slider-1.png";
import slider_img_2 from "@assets/img/slider/4/slider-2.png";
import slider_img_3 from "@assets/img/slider/4/slider-3.png";
import slider_img_4 from "@assets/img/slider/4/slider-4.png";
// nav icon
import nav_icon_1 from "@assets/img/slider/4/nav/icon-1.png";
import nav_icon_2 from "@assets/img/slider/4/nav/icon-2.png";
import nav_icon_3 from "@assets/img/slider/4/nav/icon-3.png";
import nav_icon_4 from "@assets/img/slider/4/nav/icon-4.png";
import { ArrowNextTwo, ArrowPrevTwo } from "@/svg";
import Link from "next/link";
import { useGetSlideDetailsQuery } from "@/redux/features/brandingSettingsApi";

const JewelryBanner = () => {
  const [slider1, setSlider1] = useState(null);
  const [slider2, setSlider2] = useState(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const { data: sliderData = [] } = useGetSlideDetailsQuery();
  console.log("SliderData", sliderData);

  if (!sliderData.length) return null;

  // const slider_data = [
  //   { subtitle: "The original", title: "Shine bright", img: slider_img_1 },
  //   { subtitle: "The original", title: "Creative Design", img: slider_img_2 },
  //   { subtitle: "The original", title: "Gold Plateted", img: slider_img_3 },
  //   { subtitle: "The original", title: "Unique shapes", img: slider_img_4 },
  // ];

  // const slider_nav_data = [
  //   {
  //     icon: nav_icon_1,
  //     title: (
  //       <>
  //         Ring <br />& Earring
  //       </>
  //     ),
  //   },
  //   {
  //     icon: nav_icon_2,
  //     title: (
  //       <>
  //         Bangles & <br />
  //         Bracelets
  //       </>
  //     ),
  //   },
  //   {
  //     icon: nav_icon_3,
  //     title: (
  //       <>
  //         Drop <br /> Necklaces
  //       </>
  //     ),
  //   },
  //   {
  //     icon: nav_icon_4,
  //     title: (
  //       <>
  //         Diamond <br /> Necklaces
  //       </>
  //     ),
  //   },
  // ];

  //  slider setting
  const main_slider_setting = {
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    centerMode: false,
    autoplay: true, // auto play images
    autoplaySpeed: 20000, // 15 seconds
    beforeChange: (oldIndex, newIndex) => setCurrentSlide(newIndex), 
  };
  // nav slider setting
  const nav_slider_setting = {
    infinite: true,
    slidesToShow: sliderData ? sliderData.length : 0,
    slidesToScroll: 1,
    vertical: true,
    dots: false,
    arrows: false,
    centerMode: false,
    focusOnSelect: true,
  };

  const sliderBgColor = sliderData[currentSlide]?.bg_color || "#f8f9fa";

  return (
    <>
      <section className="tp-slider-area p-relative z-index-1 fix">
        <Slider
          {...main_slider_setting}
          asNavFor={slider2}
          ref={(slider) => setSlider1(slider)}
          className="tp-slider-active-4 rounded-0"
          style={{
            background: sliderBgColor, // <--- set dynamic bg here!
            borderRadius: "16px",
            transition: "background 0.3s",
          }}
        >
          {sliderData.map((item, i) => (
            <div
              key={i}
              className="tp-slider-item-4 tp-slider-height-4 p-relative  d-flex align-items-center"
              style={{
                background: item.bg_color || "#f8f9fa", // fallback to light gray if no bg_color
                color: item.text_color || "#222", // fallback to dark text
                minHeight: "450px",
              }}
            >
              <div className="tp-slider-thumb-4">
                <Image
                  src={item.image}
                  width={1000}
                  height={1000}
                  className="h-auto w-100 "
                  style={{ objectFit: 'contain'}}
                  alt="slider img"
                />
                <div className="tp-slider-thumb-4-shape">
                  <span className="tp-slider-thumb-4-shape-1"></span>
                  <span className="tp-slider-thumb-4-shape-2"></span>
                </div>
              </div>
              <div className="container">
                <div className="row align-items-center">
                  <div className="col-xl-6 col-lg-6 col-md-8">
                    <div className="tp-slider-content-4 p-relative z-index-1">
                      <span>{item.sub_title}</span>
                      <h3 className="tp-slider-title-4 capitalize">{item.title}</h3>
                      <div className="tp-slider-btn-4">
                        <Link
                          href="/shop"
                          className="tp-btn tp-btn-border tp-btn-border-white"
                        >
                          Discover Now
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </Slider>

        {/* arrow start */}
        <div className="tp-slider-arrow-4">
          <button
            className="tp-slider-3-button-prev slick-arrow"
            onClick={() => slider1?.slickPrev()}
          >
            <ArrowPrevTwo />
          </button>
          <button
            className="tp-slider-3-button-next slick-arrow"
            onClick={() => slider1?.slickNext()}
          >
            <ArrowNextTwo />
          </button>
        </div>
        {/* arrow end */}

        <div className="tp-slider-nav">
          <Slider
            {...nav_slider_setting}
            asNavFor={slider1}
            ref={(slider) => setSlider2(slider)}
            className="tp-slider-nav-active"
          >
            {sliderData.map((item, i) => (
              <div
                key={i}
                className="tp-slider-nav-item d-flex align-items-center"
              >
                <div className="tp-slider-nav-icon">
                  <span>
                    <Image src={item.icon} width={30} height={30} alt="icon" />
                  </span>
                </div>
                <div className="tp-slider-nav-content">
                  <h3 className="tp-slider-nav-title">{item.icon_title}</h3>
                </div>
              </div>
            ))}
          </Slider>
        </div>
      </section>
    </>
  );
};

export default JewelryBanner;
