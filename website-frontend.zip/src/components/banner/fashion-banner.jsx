import React from "react";
import Link from "next/link";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination, EffectFade, Navigation, Autoplay } from "swiper";
import { useGetSlideDetailsQuery } from "@/redux/features/brandingSettingsApi";

// Swiper settings
const slider_setting = {
  slidesPerView: 1,
  spaceBetween: 30,
  effect: "fade",
  loop: true,
  navigation: {
    nextEl: ".tp-slider-2-button-next",
    prevEl: ".tp-slider-2-button-prev",
  },
  pagination: {
    el: ".tp-slider-2-dot",
    clickable: true,
  },
  autoplay: {
    delay: 100000,
    disableOnInteraction: false,
  },
  fadeEffect: { crossFade: true },
};


const FashionBanner = ({ sectionId }) => {
  // Fetch slide data
  // const { data, isLoading } = useGetSlideDetailsQuery();
  const { data, isLoading } = useGetSlideDetailsQuery(sectionId);

  // derive primitives with safe defaults
  const slides = Array.isArray(data?.config?.slides) ? data.config.slides : [];
  const autoplay = data?.config?.autoplay === true;
  const delay = Number(data?.config?.interval_ms) || 0;
  const title_color = data?.config?.title_color;
  const subtitle_color = data?.config?.subtitle_color;
  const icon_title_color = data?.config?.icon_title_color;
  const background_color = data?.config?.background_color;
  const slider_shape = data?.config?.slider_shape;
  const thumb_shape_1 = data?.config?.thumb_shape_1;
  const thumb_shape_2 = data?.config?.thumb_shape_2;
  const background_shape = data?.config?.background_shape;

  console.log(
    "color",
    slides,
    autoplay,
    delay,
    title_color,
    subtitle_color,
    icon_title_color
  );

  // const sliderData = data?.filter((item) => item.status === "active") || [];
  console.log("sliderData", data);

  if (isLoading) {
    return (
      <section className="tp-slider-area p-relative z-index-1">
        <div
          style={{
            minHeight: 400,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <span>Loading...</span>
        </div>
      </section>
    );
  }

  if (!slides.length) {
    return (
      <section className="tp-slider-area p-relative z-index-1">
        <div
          style={{
            minHeight: 400,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <span>No slides found</span>
        </div>
      </section>
    );
  }

  return (
    <section className="tp-slider-area p-relative z-index-1">
      <Swiper
        {...slider_setting}
        modules={[Pagination, Navigation, EffectFade, Autoplay]}
        className="tp-slider-active-2 swiper-container"
      >
        {slides.map((item) => (
          <SwiperSlide key={item.id}>
            <div
              className="tp-slider-item-2 tp-slider-height-2 p-relative d-flex align-items-end"
              style={{ backgroundColor: background_color, zIndex: 0, overflow: "hidden", minHeight: 500 }}
            >
              <div className="tp-slider-2-shape d-flex align-items-start ">
                <Image
                  className="tp-slider-2-shape-1 z-2"
                  src={slider_shape}
                  alt="slider_shape"
                  width={200}
                  height={80}
                  style={{ zIndex: 999, objectFit: "contain" }}
                />
              </div>
              <div className="container">
                <div className="row align-items-center">
                  <div
                    className="col-xl-5 col-lg-5 col-md-5 col-12"
                    style={{ zIndex: 999 }}
                  >
                    <div className="tp-slider-content-2 pt-3 pt-md-1">
                      <span style={{ color: subtitle_color }}>
                        {item.subtitle}
                      </span>
                      <h3
                        className="tp-slider-title-2 "
                        style={{ zIndex: 999, color: title_color }}
                      >
                        {item.title}
                      </h3>
                      {item.icon && (
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 10,
                            margin: "10px 0",
                          }}
                        >
                          <Image
                            src={item.icon}
                            alt={item.icon_title || "icon"}
                            width={40}
                            height={40}
                            style={{
                              objectFit: "contain",
                              borderRadius: "50%",
                            }}
                          />
                          <span
                            style={{
                              color: icon_title_color || "#000",
                              fontWeight: 500,
                              marginBottom: 0,
                            }}
                          >
                            {item.icon_title}
                          </span>
                        </div>
                      )}
                      <div className="tp-slider-btn-2 mt-4">
                        <Link
                          href="/shop"
                          className="tp-btn tp-btn-border rounded-3"
                          style={{
                            color: icon_title_color || "#000",
                            borderColor: icon_title_color || "#fff",
                          }}
                        >
                          Shop Collection
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-7 col-lg-7 col-md-7 col-12">
                    <div className="tp-slider-thumb-2-wrapper p-relative">
                      <div className="tp-slider-thumb-2-shape start-0 w-100 h z-2">
                        <Image
                          className="tp-slider-thumb-2-shape-1"
                          src={thumb_shape_1}
                          width={100}
                          height={100}
                          alt="shape"
                        />
                        <Image
                          className="tp-slider-thumb-2-shape-2"
                          src={thumb_shape_2}
                          width={100}
                          height={100}
                          alt="shape"
                        />
                        <span className=" d-md-flex  d-none ">
                          <Image
                            className="tp-slider-thumb-2-shape-3 pt-50"
                            width={700}
                            height={700}
                            src={background_shape}
                            alt="shape"
                          />
                        </span>
                      </div>
                      <div
                        className="tp-slider-thumb-2 text-end"
                        style={{
                          position: "relative",
                          height: "100%",
                          minHeight: "clamp(320px, 65vw, 800px)", 
                          overflow: "hidden",
                        }}
                      >
                        {item.background_image && (
                          <Image
                            src={item.background_image}
                            alt={item.title || "slider img"}
                            fill
                            priority
                            style={{ objectFit: "contain" }} 
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </SwiperSlide>
        ))}

        <div className="tp-swiper-dot tp-slider-2-dot"></div>
      </Swiper>
    </section>
  );
};

export default FashionBanner;
