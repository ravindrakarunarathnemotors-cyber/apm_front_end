"use client";

import React, { useMemo, useEffect, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, EffectFade, Pagination, Autoplay } from "swiper";
import { ArrowNext, ArrowPrev } from "@/svg";
import { useGetSlideDetailsQuery } from "@/redux/features/brandingSettingsApi";

/**
 * 🟢 FIX: Separate component for the image.
 * This prevents the "Rendered more hooks" error by ensuring 
 * useState is called at the top level of this sub-component, 
 * not inside the slides.map loop.
 */
function SlideImage({ desktopUrl, mobileUrl }) {
  const [imgLoaded, setImgLoaded] = useState(false);

  useEffect(() => {
    if (desktopUrl) {
      const img = new Image();
      img.src = desktopUrl;
      img.onload = () => setImgLoaded(true);
    }
  }, [desktopUrl]);

  return (
    <div
      className={`slider-image z-index-1 bg-white ${imgLoaded ? "loaded" : ""}`}
      style={{
        "--bg-desktop": `url("${desktopUrl}")`,
        "--bg-mobile": `url("${mobileUrl}")`,
        backgroundImage: `url("${desktopUrl}")`,
        transform: imgLoaded ? "scale(1)" : "scale(1.1)",
        transition: "opacity 1.5s ease, transform 2s ease-out",
      }}
      aria-hidden="true"
    />
  );
}

function FeatureItem({ iconUrl, title, color }) {
  if (!iconUrl && !title) return null;
  return (
    <div className="tp-slider-feature-item-3 d-flex mb-30 align-items-center gap-2">
      <div className="tp-slider-feature-icon-3">
        {iconUrl ? (
          <img src={iconUrl} width={38} height={38} alt={title || "feature"} />
        ) : (
          <span />
        )}
      </div>
      <div className="tp-slider-feature-content-3">
        <h3 className="tp-slider-feature-title-3 mb-0" style={{ color: color }}>
          {title}
        </h3>
      </div>
    </div>
  );
}

const BeautyBanner = ({ sectionId }) => {
  const { data: section } = useGetSlideDetailsQuery(sectionId);

  // Safeguard data
  const slides = Array.isArray(section?.config?.slides) ? section.config.slides : [];
  const autoplay = section?.config?.autoplay === true;
  const delay = Number(section?.config?.interval_ms) || 5000;
  const title_color = section?.config?.title_color;
  const subtitle_color = section?.config?.subtitle_color;
  const icon_title_color = section?.config?.icon_title_color;

  const sliderSetting = useMemo(() => {
    const base = {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: slides.length > 1,
      effect: "fade",
      navigation: {
        nextEl: ".tp-slider-3-button-next",
        prevEl: ".tp-slider-3-button-prev",
      },
      pagination: { el: ".tp-slider-3-dot", clickable: true },
    };
    return autoplay && delay > 0
      ? { ...base, autoplay: { delay, disableOnInteraction: false } }
      : base;
  }, [autoplay, delay, slides.length]);

  if (!section?.enabled || slides.length === 0) return null;

  return (
    <section className="tp-slider-area p-relative z-index-1">
      <style>{`
        .slider-image {
          width: 100%;
          aspect-ratio: 16 / 8;
          background-position: center;
          background-repeat: no-repeat;
          background-size: cover; 
          background-color: #f8f9fa; 
          opacity: 0;
        }
        .slider-image.loaded { opacity: 1; }
        @media (max-width: 767.98px) {
          .slider-image { 
             aspect-ratio: 2 / 3; 
             background-image: var(--bg-mobile) !important; 
          }
        }
      `}</style>

      <Swiper
        {...sliderSetting}
        modules={[Navigation, EffectFade, Pagination, Autoplay]}
        className="tp-slider-active-3 swiper-container"
      >
        {slides.map((item, idx) => {
          const desktopUrl = item.background_image || "";
          const mobileUrl = item.background_mobile_image || item.background_image || "";

          return (
            <SwiperSlide key={idx} className="position-relative">
              <SlideImage desktopUrl={desktopUrl} mobileUrl={mobileUrl} />
              
              <div className="container position-absolute w-100 d-flex align-items-center z-index-2" style={{ height: "100%", width: "100%", top: 0, left: 0 }}>
                <div className="row w-100 align-items-center ml-sm-30 ml-50">
                  <div className="col-xl-6 col-lg-6 col-md-8">
                    <div className="tp-slider-content-3">
                      {item.subtitle && (
                        <span className="slider-text-anim-1" style={{ color: subtitle_color }}>
                          {item.subtitle}
                        </span>
                      )}
                      {item.title && (
                        <h3 className="tp-slider-title-3 slider-text-anim-2" style={{ color: title_color }}>
                          {item.title}
                        </h3>
                      )}
                      {(item.icon || item.icon_title) && (
                        <div className="tp-slider-feature-3 d-flex flex-wrap align-items-center p-relative z-index-1 mb-15">
                          <FeatureItem 
                             iconUrl={item.icon} 
                             title={item.icon_title} 
                             color={icon_title_color} 
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          );
        })}

        {/* 🟢 NAVIGATION: Pagination Dots */}
        <div 
            className="tp-swiper-dot tp-slider-3-dot" 
            style={{
                position:'absolute', 
                bottom:'80px', 
                left:'50%', 
                flexDirection:'row', 
                justifyContent:'center', 
                transform:'translateX(-50%)', 
                gap:'5px',
                zIndex: 10
            }}
        />

        {/* 🟢 NAVIGATION: Arrows */}
        <div className="tp-slider-arrow-3">
          <button type="button" className="tp-slider-3-button-prev ms-4" style={{ color: "#fff", opacity: "1", zIndex: 11 }}>
            <ArrowPrev />
          </button>
          <button type="button" className="tp-slider-3-button-next me-4" style={{ color: "#fff", opacity: "1", zIndex: 11 }}>
            <ArrowNext />
          </button>
        </div>
      </Swiper>
    </section>
  );
};

export default BeautyBanner;