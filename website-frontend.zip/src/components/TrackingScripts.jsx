"use client";

import { useEffect, useState } from "react";
import Script from "next/script";

export default function TrackingScripts() {
  const [settings, setSettings] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTrackingSettings = async () => {
      try {
        const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
        const res = await fetch(`${baseUrl}/system/get-tracking-settings`);

        if (!res.ok) throw new Error("Failed to fetch tracking settings");

        const data = await res.json();
        setSettings(data);
      } catch (err) {
        console.error(err);
        setError(err.message);
      }
    };

    fetchTrackingSettings();
  }, []);

  if (error || !settings) return null;

  const {
    enabled_google,
    gtm_container_id,
    ga4_measurement_id,
    enabled_meta,
    meta_pixel_id,
    enabled_google_tag,
  } = settings;

  return (
    <>
      {/* Google Tag Manager */}
      {enabled_google_tag && gtm_container_id && (
        <>
          <Script id="gtm-script" strategy="afterInteractive">
            {`
              (function(w,d,s,l,i){
                w[l]=w[l]||[]; w[l].push({'gtm.start': new Date().getTime(), event:'gtm.js'});
                var f=d.getElementsByTagName(s)[0], j=d.createElement(s), dl=l!='dataLayer'?'&l='+l:'';
                j.async=true; j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;
                f.parentNode.insertBefore(j,f);
              })(window,document,'script','dataLayer','${gtm_container_id}');
            `}
          </Script>
          <noscript
            dangerouslySetInnerHTML={{
              __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=${gtm_container_id}" height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
            }}
          />
        </>
      )}

      {/* Google Analytics 4 */}
      {enabled_google && ga4_measurement_id && (
        <>
          <Script
            async
            src={`https://www.googletagmanager.com/gtag/js?id=${ga4_measurement_id}`}
          />
          <Script id="ga4-init" strategy="afterInteractive">
            {`
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${ga4_measurement_id}');
            `}
          </Script>
        </>
      )}

      {/* Meta Pixel */}
      {enabled_meta && meta_pixel_id && (
        <>
          <Script id="meta-pixel" strategy="afterInteractive">
            {`
              !function(f,b,e,v,n,t,s){
                if(f.fbq) return;
                n=f.fbq=function(){
                  n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                };
                if(!f._fbq) f._fbq=n;
                n.push=n; n.loaded=!0; n.version='2.0';
                n.queue=[];
                t=b.createElement(e); t.async=!0;
                t.src=v;
                s=b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t,s);
              }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
              fbq('init', '${meta_pixel_id}');
              fbq('track', 'PageView');
            `}
          </Script>
          <noscript
            dangerouslySetInnerHTML={{
              __html: `<img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=${meta_pixel_id}&ev=PageView&noscript=1" />`,
            }}
          />
        </>
      )}
    </>
  );
}
