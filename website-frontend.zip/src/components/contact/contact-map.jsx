import React from "react";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";

const ContactMap = () => {
  const { data: brandingData } = useGetBrandingSettingsQuery();
  console.log("BrandingData", brandingData);

  // If no branding data or geocode is null, render nothing
  if (!brandingData || brandingData.geocode === null) {
    return null;
  }

  return (
    <section className="tp-map-area pb-120">
      <div className="container">
        <div className="row">
          <div className="col-xl-12">
            <div className="tp-map-wrapper">
              <div className="tp-map-hotspot">
                <span className="tp-hotspot tp-pulse-border">
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 12 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle cx="6" cy="6" r="6" fill="#821F40" />
                  </svg>
                </span>
              </div>
              <div className="tp-map-iframe">
                <iframe
                  src={brandingData.geocode}
                  style={{ border: 0 }}
                  allowFullScreen=""
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactMap;
