import React from "react";
import Image from "next/image";
// internal
import ContactForm from "../forms/contact-form";
import contact_icon_1 from "@assets/img/contact/contact-icon-1.png";
import contact_icon_2 from "@assets/img/contact/contact-icon-2.png";
import contact_icon_3 from "@assets/img/contact/contact-icon-3.png";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";

const ContactArea = () => {
  const { data: brandingData } = useGetBrandingSettingsQuery();
  console.log("BrandingData", brandingData);
  return (
    <>
      <section className="tp-contact-area pb-100">
        <div className="container">
          <div className="tp-contact-inner">
            <div className="row">
              <div className="col-xl-9 col-lg-8">
                <div className="tp-contact-wrapper">
                  <h2 className="tp-contact-title">Sent A Message</h2>

                  <div className="tp-contact-form">
                    {/* form start */}
                    <ContactForm supportEmail={brandingData?.support_email || ""}/>
                    {/* form end */}
                    <p className="ajax-response"></p>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-lg-4">
                <div className="tp-contact-info-wrapper">
                  <div className="tp-contact-info-item">
                    <div className="tp-contact-info-icon">
                      <span>
                        <Image src={contact_icon_1} alt="contact-icon" />
                      </span>
                    </div>
                    <div className="tp-contact-info-content">
                      <p data-info="mail">
                        <a href={`mailto:${brandingData?.support_email}`}>
                          {brandingData?.support_email}
                        </a>
                      </p>
                      <p data-info="phone">
                        <a href={`tel:${brandingData?.customer_support_phone}`}>
                          {brandingData?.customer_support_phone}
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="tp-contact-info-item">
                    <div className="tp-contact-info-icon">
                      <span>
                        <Image src={contact_icon_2} alt="contact-icon" />
                      </span>
                    </div>
                    <div className="tp-contact-info-content">
                      <p>
                        <a
                          href={
                            brandingData?.geocode ? brandingData.geocode : "#"
                          }
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {brandingData?.address_1} <br />{" "}
                          {brandingData?.address_2}
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="tp-contact-info-item">
                    <div className="tp-contact-info-icon">
                      <span>
                        <Image src={contact_icon_3} alt="contact-icon" />
                      </span>
                    </div>
                    <div className="tp-contact-info-content">
                      {/* <div className="tp-contact-social-wrapper mt-5">
                        <h4 className="tp-contact-social-title">
                          Find on social media
                        </h4>

                        <div className="tp-contact-social-icon">
                          <a href="#">
                            <i className="fa-brands fa-facebook-f"></i>
                          </a>
                          <a href="#">
                            <i className="fa-brands fa-twitter"></i>
                          </a>
                          <a href="#">
                            <i className="fa-brands fa-linkedin-in"></i>
                          </a>
                        </div>
                      </div> */}
                      <div className="tp-footer-social-4 tp-footer-social">
                        <h4 className="tp-contact-social-title">
                          Find on social media
                        </h4>

                        {[
                          {
                            href: brandingData?.facebook_url,
                            icon: "fa-brands fa-facebook-f",
                            label: "Facebook",
                          },
                          {
                            href: brandingData?.twitter_url,
                            icon: "fa-brands fa-twitter",
                            label: "Twitter",
                          },
                          {
                            href: brandingData?.linkedin_url,
                            icon: "fa-brands fa-linkedin-in",
                            label: "LinkedIn",
                          },
                          {
                            href: brandingData?.instagram_url,
                            icon: "fa-brands fa-instagram",
                            label: "Instagram",
                          },
                          {
                            href: brandingData?.youtube_url,
                            icon: "fa-brands fa-youtube",
                            label: "YouTube",
                          },
                        ]
                          .filter((s) => !!s.href)
                          .map((s, idx) => {
                            const url = /^https?:\/\//i.test(s.href)
                              ? s.href
                              : `https://${s.href}`;
                            return (
                              <a
                                key={idx}
                                href={url}
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label={s.label}
                                title={s.label}
                              >
                                <i className={s.icon} />
                              </a>
                            );
                          })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactArea;
