// external
import React, { useMemo, useState } from "react";
import { Navigation, Pagination, EffectFade, Autoplay } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import Link from "next/link";
// internal
import { ArrowRightLong, SliderNextBtn, SliderPrevBtn, TextShape } from "@/svg";
import { useGetSlideDetailsQuery } from "@/redux/features/brandingSettingsApi";

// Small helper to render a positioned shape
function Shape({ src, num }) {
  if (!src) return null;
  return (
    <Image
      className={`tp-slider-shape-${num}`}
      src={src}
      alt={`slider-shape-${num}`}
      width={140}
      height={140}
      priority
      // Shapes are decorative; layout is controlled by CSS classes
      style={{ height: "auto" }}
    />
  );
}

const HomeHeroSlider = ({ sectionId }) => {
  const [active, setActive] = useState(false);
  const { data, isLoading } = useGetSlideDetailsQuery(sectionId);
  console.log("firstdata", data);

  const { slides, globalAutoplay, globalDelay } = useMemo(() => {
    const cfg = data?.config || {};

    const rawSlides = Array.isArray(cfg.slides) ? cfg.slides : [];

    const uniformDelay = Number.isFinite(cfg.interval_ms)
      ? cfg.interval_ms
      : 20000;

    const builtSlides = rawSlides.map((s, i) => {
      const bgColor = s.background_color ?? cfg.background_color ?? "#ffffff";
      return {
        id: `${data?.id || "slide"}-${i + 1}`,
        title: s.title || "",
        subtitle: s.subtitle || "",
        icon: s.icon || "",
        icon_title: s.icon_title || "",
        icon_title_color: cfg.icon_title_color ?? "#222222",
        title_color: cfg.title_color ?? "#111111",
        subtitle_color: cfg.subtitle_color ?? "#555555",
        bgColor,
        bgImage: s.background_image || "",
        shape_1: cfg.shape_1,
        shape_2: cfg.shape_2,
        shape_3: cfg.shape_3,
        shape_4: cfg.shape_4,
        is_light: bgColor.toLowerCase() === "#e3edf6",
      };
    });

    return {
      slides: builtSlides,
      globalAutoplay: typeof cfg.autoplay === "boolean" ? cfg.autoplay : true,
      globalDelay: uniformDelay,
    };
  }, [data]);

  const handleActiveIndex = (index) => {
    // if a specific slide requests "light" styling you could toggle here;
    // for simplicity, enable light class on the 3rd slide like the old code
    setActive(index === 2);
  };

  if (isLoading) {
    return (
      <section className="tp-slider-area p-relative z-index-1">
        <div className="container py-5">
          <div className="placeholder-glow">
            <div className="placeholder col-6 mb-3" />
            <div className="placeholder col-8 mb-3" />
            <div className="placeholder col-4 mb-3" />
          </div>
        </div>
      </section>
    );
  }

  if (!slides?.length) {
    return null;
  }

  return (
    <>
      <section className="tp-slider-area p-relative z-index-1">
        <Swiper
          slidesPerView={1}
          spaceBetween={30}
          loop={true}
          effect="fade"
          navigation={{
            nextEl: ".tp-slider-button-next",
            prevEl: ".tp-slider-button-prev",
          }}
          pagination={{ el: ".tp-slider-dot", clickable: true }}
          onSlideChange={(swiper) => handleActiveIndex(swiper.activeIndex)}
          modules={[Navigation, Pagination, EffectFade, Autoplay]}
          autoplay={
            globalAutoplay
              ? {
                  delay: globalDelay, // <- 20000ms
                  disableOnInteraction: false,
                  stopOnLastSlide: false, // <- keep looping
                  pauseOnMouseEnter: false, // optional
                }
              : false
          }
          className={`tp-slider-active tp-slider-variation swiper-container ${
            active ? "is-light" : ""
          }`}
        >
          {slides.map((item) => (
            <SwiperSlide
              key={item.id}
              className="tp-slider-item tp-slider-height d-flex align-items-center"
              style={{
                backgroundColor: item.bgColor,
              }}
              data-swiper-autoplay={item.delay} // <— per-slide delay takes effect
            >
              {/* shapes */}
              <div className="tp-slider-shape">
                <Shape src={item.shape_1} num="1" />
                <Shape src={item.shape_2} num="2" />
                <Shape src={item.shape_3} num="3" />
                <Shape src={item.shape_4} num="4" />
              </div>

              <div className="container">
                <div className="row align-items-center">
                  <div className="col-xl-5 col-lg-6 col-md-6">
                    <div className="tp-slider-content p-relative z-index-1 pt-80 pt-lg-0">
                      {/* Icon + icon title */}
                      {(item.icon || item.icon_title) && (
                        <span className="d-inline-flex align-items-center gap-2">
                          {item.icon && (
                            <Image
                              src={item.icon}
                              alt="icon"
                              width={28}
                              height={28}
                              style={{
                                height: "28px",
                                width: "28px",
                                objectFit: "contain",
                              }}
                              priority
                            />
                          )}
                          {item.icon_title && (
                            <b style={{ color: item.icon_title_color }}>
                              {item.icon_title}
                            </b>
                          )}
                        </span>
                      )}

                      {/* Title */}
                      {item.title && (
                        <h3
                          className="tp-slider-title mt-2"
                          style={{ color: item.title_color }}
                        >
                          {item.title}
                        </h3>
                      )}

                      {/* Subtitle with the wavy text shape */}
                      {item.subtitle && (
                        <p style={{ color: item.subtitle_color }}>
                          {item.subtitle}{" "}
                          <span>
                            <TextShape />
                          </span>
                        </p>
                      )}

                      <div className="tp-slider-btn">
                        <Link
                          href="/shop"
                          className="tp-btn tp-btn-2 tp-btn-white"
                        >
                          Shop Now <ArrowRightLong />
                        </Link>
                      </div>
                    </div>
                  </div>

                  <div className="col-xl-7 col-lg-6 col-md-6">
                    <div className="tp-slider-thumb text-end">
                      {/* background image on the right */}
                      {item.bgImage && (
                        <Image
                          src={item.bgImage}
                          alt="slider-visual"
                          width={500}
                          height={500}
                          style={{ height: "auto", maxWidth: "100%" }}
                          priority
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          ))}

          {/* arrows */}
          <div className="tp-slider-arrow tp-swiper-arrow">
            <button type="button" className="tp-slider-button-prev">
              <SliderPrevBtn />
            </button>
            <button type="button" className="tp-slider-button-next">
              <SliderNextBtn />
            </button>
          </div>

          {/* dots */}
          <div className="tp-slider-dot tp-swiper-dot"></div>
        </Swiper>
      </section>
    </>
  );
};

export default HomeHeroSlider;
