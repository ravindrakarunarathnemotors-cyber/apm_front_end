"use client";

import { useGetSocialLinksQuery } from "@/redux/features/brandingSettingsApi";
import { useEffect, useRef, useState } from "react";

export default function MovingBlurBackground({ maintenance }) {
  const { data: socialLinks } = useGetSocialLinksQuery();
  console.log("first", socialLinks);
  console.log("second", maintenance);
  const maintanceparse = JSON.parse(maintenance?.webstore_maintenance_msg);
  console.log(maintanceparse)
  const containerRef = useRef(null);
  const [dims, setDims] = useState({ w: 0, h: 0 });

  const [blobs, setBlobs] = useState([
    {
      id: "b1",
      size: 400,
      bg: "linear-gradient(135deg, rgba(147,51,234,0.8), rgba(59,130,246,0.8), rgba(45,212,191,0.8))",
      x: -80,
      y: -80,
    },
    {
      id: "b2",
      size: 400,
      bg: "linear-gradient(135deg, rgba(147,51,234,0.8), rgba(59,130,246,0.8), rgba(45,212,191,0.8))",
      x: -80,
      y: 200,
    },
    {
      id: "b3",
      size: 500,
      bg: "linear-gradient(45deg, rgba(99,102,241,0.7), rgba(217,70,239,0.7), rgba(236,72,153,0.7))",
      x: 300,
      y: 300,
    },
  ]);

  const randomPos = (size) => {
    const pad = 120;
    const maxX = Math.max(0, (dims.w || window.innerWidth) - size + pad);
    const maxY = Math.max(0, (dims.h || window.innerHeight) - size + pad);
    const min = -pad;
    const x = Math.floor(Math.random() * (maxX - min + 1)) + min;
    const y = Math.floor(Math.random() * (maxY - min + 1)) + min;
    return { x, y };
  };

  useEffect(() => {
    const measure = () => {
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      setDims({ w: rect.width, h: rect.height });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  useEffect(() => {
    const t0 = setTimeout(() => {
      setBlobs((prev) =>
        prev.map((b) => {
          const { x, y } = randomPos(b.size);
          return { ...b, x, y };
        })
      );
    }, 250);

    const interval = setInterval(() => {
      setBlobs((prev) =>
        prev.map((b) => {
          const { x, y } = randomPos(b.size);
          return { ...b, x, y };
        })
      );
    }, 10000 + Math.floor(Math.random() * 3000));

    return () => {
      clearTimeout(t0);
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dims.w, dims.h]);

  return (
    <div
      ref={containerRef}
      className="position-relative overflow-hidden"
      style={{ backgroundColor: "#000", height: "100vh" }}
    >
      {/* Moving blur blobs */}
      {blobs.map((b) => (
        <div
          key={b.id}
          className="position-absolute rounded-circle"
          style={{
            width: b.size,
            height: b.size,
            background: b.bg,
            filter: "blur(60px)",
            opacity: 0.8,
            borderRadius: "50%",
            transform: `translate(${b.x}px, ${b.y}px)`,
            transition: "transform 11s ease-in-out",
            pointerEvents: "none",
            zIndex: 0,
          }}
          aria-hidden="true"
        />
      ))}

      {/* Center content */}
      <div
        className="position-absolute top-50 start-50 translate-middle text-center text-white"
        style={{ zIndex: 2, userSelect: "none" }}
      >
        <div
          className="fw-bold"
          style={{
            fontSize: "72px",
            lineHeight: 1,
            letterSpacing: "2px",
            textShadow: "0 2px 20px rgba(255,255,255,0.12)",
          }}
        >
          {(maintenance &&
            maintanceparse &&
            maintanceparse.title) ||
            "Under Maintenance"}
        </div>

        {/* DevHub under the icons */}
        <div className="mt-3" style={{ fontSize: "28px", opacity: 0.9 }}>
          <pre className="h-100 p-2 text-wrap">
            {(maintenance &&
              maintanceparse &&
              maintanceparse.message) ||
              "We are currently improving our website to serve you better. Please check back soon. Thank you for your patience!"}
          </pre>
        </div>

        {/* === Lavinia Social Buttons (inline CSS only) === */}
      </div>
      <div
        className="d-flex justify-content-center flex-wrap gap-3 mt-3  w-100 py-5"
        style={{ position: "absolute", bottom: 0 }}
      >
        {/* <SocialIcon label="f" href="#" />
        <SocialIcon label="tw" href="#" />
        <SocialIcon label="g+" href="#" />
        <SocialIcon label="dr" href="#" />
        <SocialIcon label="vi" href="#" />
        <SocialIcon label="p" href="#" />
        <SocialIcon label="ig" href="#" />
        <SocialIcon label="in" href="#" /> */}
        {[
          {
            href: socialLinks?.facebook_url,
            icon: "fa-brands fa-facebook-f",
            label: "Facebook",
          },
          {
            href: socialLinks?.twitter_url,
            icon: "fa-brands fa-twitter",
            label: "Twitter",
          },
          {
            href: socialLinks?.linkedin_url,
            icon: "fa-brands fa-linkedin-in",
            label: "LinkedIn",
          },
          {
            href: socialLinks?.instagram_url,
            icon: "fa-brands fa-instagram",
            label: "Instagram",
          },
          {
            href: socialLinks?.youtube_url,
            icon: "fa-brands fa-youtube",
            label: "YouTube",
          },
        ]
          .filter((s) => !!s.href)
          .map((s, idx) => {
            const url = /^https?:\/\//i.test(s.href)
              ? s.href
              : `https://${s.href}`;
            return (
              <SocialIcon
                key={idx}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                icon={s.icon}
                title={s.label}
              />
              // <SocialIcon label="in" href="#" />
            );
          })}
      </div>


    </div>
  );
}

/** Single button with the “Lavinia” effect (no pseudo-elements; span duplicates :after) */
function SocialIcon({ label, href, icon }) {
  const [hover, setHover] = useState(false);

  return (
    <a
      href={href}
      className="d-inline-flex align-items-center justify-content-center position-relative"
      style={{
        width: 50,
        height: 50,
        borderRadius: "50%",
        fontSize: 22,
        textDecoration: "none",
        color: "#fff",
        border: "2px solid #fff",
        overflow: "visible",
        transition:
          "border-top-color .2s linear 0s, border-right-color .2s linear .1s, border-bottom-color .2s linear .2s, border-left-color .2s linear .3s",
        borderColor: hover ? "rgba(255,255,255,0)" : "#fff",
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      title={label}
    >
      {/* dashed border layer (replaces ::after) */}
      <span
        className="position-absolute"
        aria-hidden="true"
        style={{
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          border: "2px dashed #fff",
          borderRadius: "50%",
          pointerEvents: "none",
        }}
      />
      {/* “icon” — using text so we don’t need an icon lib */}
      <span style={{ position: "relative", zIndex: 3, fontWeight: 700 }}>
        <i className={icon} />
      </span>
    </a>
  );
}
