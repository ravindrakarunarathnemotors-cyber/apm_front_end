import React from 'react'

const getPagination = (page, totalPages) => {
  const pagination = []
  if (totalPages <= 7) {
    for (let i = 1; i <= totalPages; i++) pagination.push(i)
  } else {
    if (page <= 4) {
      pagination.push(1, 2, 3, 4, 5, '...', totalPages)
    } else if (page >= totalPages - 3) {
      pagination.push(1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages)
    } else {
      pagination.push(1, '...', page - 1, page, page + 1, '...', totalPages)
    }
  }
  return pagination
}

const CustomPagination = ({ onPageChange, page, allPages }) => {
  const totalPages = allPages
  const pagination = getPagination(page, totalPages)

  const activeStyle = {
    backgroundColor: 'var(--primary-color)',
    borderColor: 'var(--primary-color)',
    color: '#fff',
  }

  return (
    <nav>
      <ul className="pagination">
        <li className={`page-item${page === 1 ? ' disabled' : ''}`}>
          <button className="page-link m-1 rounded-circle border-0" tabIndex="-1" onClick={() => page > 1 && onPageChange(page - 1)}>
            <i className="fa-solid fa-chevron-left"></i>
          </button>
        </li>

        {pagination.map((item, idx) =>
          item === '...' ? (
            <li key={`ellipsis-${idx}`} className="page-item disabled">
              <span className="page-link mx-1 mt-1 border-0  rounded-3">…</span>
            </li>
          ) : (
            <li key={item} className={`page-item${item === page ? ' active' : ''} `} >
              <button
                className="page-link m-1 rounded-3"
                onClick={() => onPageChange(item)}
                style={item === page ? activeStyle : undefined}
              >
                {item}
              </button>
            </li>
          )
        )}

        <li className={`page-item${page === totalPages ? ' disabled' : ''}`}>
          <button className="page-link m-1 rounded-circles border-0" tabIndex="-1" onClick={() => page < totalPages && onPageChange(page + 1)}>
            <i className="fa-solid fa-chevron-right"></i>
          </button>
        </li>
      </ul>
    </nav>
  )
}

export default CustomPagination
