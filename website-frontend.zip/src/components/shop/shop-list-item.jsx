"use client";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
import { add_cart_product } from "@/redux/features/cartSlice";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import { add_to_compare } from "@/redux/features/compareSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import MediaThumb from "@/components/common/MediaThumb";
import { useKoko } from "@/context/KokoContext";

const VIDEO_EXTS = /\.(mp4|m4v|webm|ogg|ogv|mov|mkv)(\?.*)?$/i;
const isVideoUrl = (u) => typeof u === "string" && VIDEO_EXTS.test(u || "");

const ShopListItem = ({ product }) => {
  const {
    _id,
    img,
    category,
    title,
    reviews,
    price,
    discount,
    tags,
    description,
    total_stock,
    continue_selling_oos,
    discount_amount,
    compare_price,
    has_discount,
    discount_type,
    free_count,
    buy_count,
  } = product || {};

  const symbol = useCurrencySymbol();
  const dispatch = useDispatch();
  const [ratingVal, setRatingVal] = useState(0);
  const [maxWidth, setMaxWidth] = useState("100%");
  const { koko, kokoFee } = useKoko();

  useEffect(() => {
    if (reviews?.length) {
      const rating =
        reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length;
      setRatingVal(rating);
    } else setRatingVal(0);
  }, [reviews]);

  useEffect(() => {
    const updateWidth = () => {
      if (window.innerWidth >= 768) setMaxWidth("300px");
      else if (window.innerWidth >= 576) setMaxWidth("200px");
      else setMaxWidth("100%");
    };
    updateWidth();
    window.addEventListener("resize", updateWidth);
    return () => window.removeEventListener("resize", updateWidth);
  }, []);

  const handleAddProduct = (prd) => dispatch(add_cart_product(prd));
  const handleWishlistProduct = (prd) => dispatch(add_to_wishlist(prd));
  const handleCompareProduct = (prd) => dispatch(add_to_compare(prd));

  const stripHtml = (html) => {
    if (!html) return "";
    if (typeof window !== "undefined") {
      const doc = new DOMParser().parseFromString(html, "text/html");
      return doc.body.textContent || "";
    }
    return "";
  };

  const videoBadge = isVideoUrl(img);

  return (
    <Link href={`/product/${slugify(title)}-${_id}`}>
      <div
        className="tp-product-list-item d-sm-flex rounded overflow-hidden mb-2"
        style={{ boxShadow: "0px 0px 5px #e2e2e2" }}
      >
        {/* Thumb */}
        <div
          className="tp-product-list-thumb p-relative fix overflow-hidden m-2 rounded-3"
          style={{ maxWidth }}
        >
          <Link href={`/product/${slugify(title)}-${_id}`}>
            <MediaThumb
              src={img || "/assets/img/shop/product-default.jpg"}
              alt={`${title} product image` || "product image"}
              width={1000}
              height={1000}
              style={{
                width: "100%",
                height: "300px",
                objectFit: "contain",
                borderRadius: 0,
              }}
            />

            {videoBadge && (
              <span
                className="position-absolute top-0 start-0 m-2 px-2 py-1 rounded-pill fw-semibold"
                style={{
                  background: "rgba(37,99,235,.1)",
                  color: "#2563eb",
                  fontSize: 12,
                }}
              >
                video
              </span>
            )}

            {total_stock < 1 && !continue_selling_oos && (
              <div className="tp-product-badge rounded-pill overflow-hidden">
                <span className="product-hot">SOLD OUT</span>
              </div>
            )}
          </Link>
        </div>

        {/* Content */}
        <div className="tp-product-list-content w-100 border-0">
          <div className="tp-product-content-2 pt-15">
            <div className="tp-product-tag-2">
              {tags?.map((t, i) => (
                <a key={i} href="#">
                  {t}
                </a>
              ))}
            </div>

            <div
              style={{
                fontSize: "1rem",
                display: "-webkit-box",
                lineHeight: "1.4",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
                textOverflow: "ellipsis",
                wordBreak: "break-word",
                textTransform: "capitalize",
              }}
            >
              <Link href={`/product/${slugify(title)}-${_id}`}>{title}</Link>
            </div>

            <div className="tp-product-price-wrapper-2 mb-0">
              <span
                className="tp-product-price-3"
                style={{ marginLeft: "2px" }}
              >
                {symbol}
              </span>
              {has_discount && discount_type == "product" && (
                <span className="tp-product-price-3">
                  {parseFloat(compare_price).toFixed(2)}
                </span>
              )}
              {(!has_discount ||
                (has_discount && discount_type == "buyxgety")) && (
                <span className="tp-product-price-3">
                  {parseFloat(price).toFixed(2)}
                </span>
              )}

              {has_discount && discount_type == "product" && (
                <span
                  className="ms-1 text-decoration-line-through"
                  style={{ fontSize: "12px" }}
                >
                  {parseFloat(price).toFixed(2)}
                </span>
              )}
            </div>

            {/* Koko Installment Section */}
            {koko === true && kokoFee && (
              <div
                className="mt-0 pb-2 d-flex align-items-center"
                style={{ gap: "5px", fontSize: "13px" }}
              >
                <span style={{ color: "#777" }}>pay in 3 x</span>
                <span className="fw-semibold" style={{ color: "#000" }}>
                  {symbol}{" "}
                  {(() => {
                    const basePrice =
                      (parseFloat(price) || 0) -
                      (parseFloat(discount_amount) || 0);
                    const fixedFee =
                      parseFloat(kokoFee.transaction_fixed_fee) || 0;
                    const percentFee = parseFloat(kokoFee.transaction_fee) || 0;
                    const totalPercentAmount = (basePrice * percentFee) / 100;
                    const grandTotal =
                      basePrice + fixedFee + totalPercentAmount;
                    return (grandTotal / 3).toFixed(2);
                  })()}
                </span>
                <span style={{ color: "#777" }}>with</span>

                <img
                  src="/assets/img/koko.png" // Fixed path (removed the dot if using Next.js public folder)
                  alt="Koko"
                  style={{
                    height: "18px",
                    marginLeft: "2px",
                    verticalAlign: "middle",
                  }}
                />
              </div>
            )}

            {has_discount && discount_type == "buyxgety" && (
              <div
                className="badge rounded-pill text-bg-success align-items-center px-2 py-1"
                style={{ fontSize: "10px" }}
              >
                <i class="fa-solid fa-tags fa-fade me-1"></i>
                BUY {buy_count} GET {free_count} FREE !
              </div>
            )}
            {has_discount && discount_type == "product" && (
              <div
                className="badge rounded-pill text-bg-danger align-items-center px-2 py-1"
                style={{ fontSize: "10px" }}
              >
                {/* <i class="fa-light fa-tags me-1"></i> */}
                <i class="fa-regular fa-fire fa-fade me-1"></i>
                Save {symbol} {parseFloat(discount_amount).toFixed(2)}
              </div>
            )}

            <div className="tp-product-price-wrapper-2 text-break capitalize d-block d-sm-none d-md-block mt-2">
              <p>
                {stripHtml(description)?.length > 100
                  ? stripHtml(description).substring(0, 100) + "..."
                  : stripHtml(description)}
              </p>
            </div>

            <div className="tp-product-list-add-to-cart">
              <Link
                href={`/product/${slugify(title)}-${_id}`}
                className="tp-product-list-add-to-cart-btn rounded-3"
              >
                Buy Now
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ShopListItem;
