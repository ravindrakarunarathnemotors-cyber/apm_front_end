import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useRouter } from "next/router";

import ProductItem from "../products/fashion/product-item";
import ProductItemDirect from "../products/fashion/product-direct-item";
import ShopListItem from "./shop-list-item";

import PriceFilter from "./shop-filter/price-filter";
import StatusFilter from "./shop-filter/status-filter";
import CategoryFilter from "./shop-filter/category-filter";
import ResetButton from "./shop-filter/reset-button";
import CustomPagination from "../CustomPagination";
import { Filter, GridTab, ListTab } from "@/svg";
import { handleFilterSidebarOpen } from "@/redux/features/shop-filter-slice";

import ShopLoader from "@/components/loader/shop/shop-loader";
import CollectionFilter from "./shop-filter/collection-filter";
import ResetLink from "./shop-filter/reset-link";

const ShopArea = ({
  loading = false, // NEW: pass your fetching state from parent
  products = [],
  otherProps,
  page,
  setPage,
  allPages,
  setAllPages,
  total,
  setSelectValue,
  selectValue,
  setStatus,
  maxValue,
  handleFinalChange,
  collections,
  categoryLabel = "",
  collectionLabel = "",
}) => {
  const [activeTab, setActiveTab] = useState("grid");
  const { priceFilterValues } = otherProps || {};
  const dispatch = useDispatch();
  const router = useRouter();

  const onPageChange = (pageNumber) => setPage(pageNumber);

  const hanldeDropdown = (e) => {
    setSelectValue(e.target.value);
    setPage(1);
    router.push({
      pathname: "/shop",
      query: { ...router.query, orderby: e.target.value },
    });
  };

  // 🔹 Clear only the category filter from URL
  const handleClearCategory = () => {
    const { category, ...rest } = router.query;
    router.push({
      pathname: "/shop",
      query: rest,
    });
  };

  // 🔹 Clear only the collection filter from URL
  const handleClearCollection = () => {
    const { collection, ...rest } = router.query;
    router.push({
      pathname: "/shop",
      query: rest,
    });
  };
  // While loading → render the matching skeleton (grid or list)
  if (loading) {
    return <ShopLoader mode={activeTab} cards={9} />;
  }

  const hasAnyFilterBadge = !!categoryLabel || !!collectionLabel;

  console.log(products);
  return (
    <section className="tp-shop-area pb-120">
      <div className="container fade-up-once">
        <div className="row">
          {/* Sidebar Filters */}
          <div className="col-xl-3 col-lg-4 d-none d-lg-block">
            <div
              className="position-sticky align-self-start rounded"
              style={{
                top: "96px",
                zIndex: 2,
                boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.1)",
              }}
            >
              <div className="p-4  rounded bg-white ">
                <h2 style={{ fontSize: "25px" }}>Filter Products</h2>
                {/* 🔹 Filter badges row */}
                {hasAnyFilterBadge && (
                  <>
                    <div
                      className="d-flex border-bottom  align-items-center justify-content-between"
                      style={{ maxWidth: "100%" }}
                    >
                      <span className="">Active Filters</span>
                      <ResetLink />
                    </div>
                    <div className="d-flex flex-wrap align-items-center gx-1 gy-1 mt-2">
                      {categoryLabel && (
                        <div
                          className="holo-badge-wrap"
                          onClick={handleClearCategory}
                        >
                          <div className="holo-badge">
                            <span>{categoryLabel}</span>
                            <span className="holo-close">×</span>
                          </div>
                        </div>
                      )}

                      {collectionLabel && (
                        <div
                          className="holo-badge-wrap"
                          onClick={handleClearCollection}
                        >
                          <div className="holo-badge">
                            <span>{collectionLabel}</span>
                            <span className="holo-close">×</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                )}
                <div className="tp-shop-sidebar m-2 pt-25 ">
                  <PriceFilter
                    priceFilterValues={priceFilterValues}
                    maxPrice={maxValue}
                    handleFinalChange={handleFinalChange}
                  />
                  <StatusFilter setCurrPage={setPage} setStatus={setStatus} />
                  <CategoryFilter setCurrPage={setPage} />
                  <CollectionFilter
                    setCurrPage={setPage}
                    collections={collections}
                  />
                  <ResetButton />
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="col-xl-9 col-lg-8 ">
            <div className="tp-shop-main-wrapper">
              {/* Top Bar */}
              <div className="tp-shop-top mb-45 ">
                <div className="row ">
                  <div className="col-xl-6 h-100 align-items-start">
                    {/* Main title always "Showcase" */}
                    {/* <p className="pt-0 mt-0 pb-0 mb-0" style={{ fontSize: "11px" }}>
                      Showing Result of{" "}
                    </p> */}
                    {/* 🔹 Filter badges row */}
                    {hasAnyFilterBadge ? (
                      <div className="d-flex flex-wrap align-items-center gap-2 pt-4 mt-0">
                        {categoryLabel && (
                          <h3
                            className="pt-0 mt-0 mb-1"
                            style={{ fontSize: "22px" }}
                          >
                            {categoryLabel}
                          </h3>
                        )}{" "}
                       
                        {collectionLabel && (
                          <h3
                            className="pt-0 mt-0 mb-1"
                            style={{ fontSize: "22px" }}
                          >
                             {collectionLabel}
                          </h3>
                        )}
                      </div>
                    ) : (
                      <h3
                        className="pt-4 mt-0 mb-1"
                        style={{ fontSize: "25px" }}
                      >
                        Showcase
                      </h3>
                    )}
                  </div>
                  {/* Sort */}
                  <div className="col-xl-6 d-flex justify-content-xl-end align-items-center mt-3 mt-lg-0 gap-3">
                    <div className="tp-shop-top-filter d-block d-lg-none ms-0">
                      <button
                        onClick={() => dispatch(handleFilterSidebarOpen())}
                        type="button"
                        className="tp-filter-btn rounded-2"
                      >
                        <span>
                          <Filter />
                        </span>{" "}
                        Filter
                      </button>
                    </div>
                    <div className="tp-shop-top-select">
                      <select
                        className="form-select border-1 rounded-3 px-5 py-2"
                        onChange={hanldeDropdown}
                        value={selectValue || "default"}
                      >
                        <option value="LowtoHigh">Low to High</option>
                        <option value="HightoLow">High to Low</option>
                        <option value="NewAdded">New Added</option>
                        <option value="default">Default</option>
                      </select>
                    </div>
                    <div className="tp-shop-top-left d-none d-md-flex align-items-center gap-3 ">
                      {/* Tabs */}
                      <ul
                        className="nav nav-tabs border-0"
                        id="productTab"
                        role="tablist"
                      >
                        <li className="nav-item " role="presentation">
                          <button
                            className={`nav-link ${
                              activeTab === "grid" ? "active" : ""
                            } py-2 px-3 m-0 `}
                            id="grid-tab"
                            type="button"
                            role="tab"
                            aria-selected={activeTab === "grid"}
                            onClick={() => setActiveTab("grid")}
                          >
                            <GridTab />
                          </button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button
                            className={`nav-link ${
                              activeTab === "list" ? "active" : ""
                            } py-2 px-3 m-0 `}
                            id="list-tab"
                            type="button"
                            role="tab"
                            aria-selected={activeTab === "list"}
                            onClick={() => setActiveTab("list")}
                          >
                            <ListTab />
                          </button>
                        </li>
                      </ul>

                      {/* Results */}
                      {/* <div className="tp-shop-top-result ms-3">
                        <p className="mb-0">
                          Showing{" "}
                          {products.length === 0 ? 0 : (page - 1) * products.length + 1}
                          –
                          {Math.min(page * products.length, total)} of {total} results
                        </p>
                      </div> */}
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid/List */}
              <div className="tp-shop-items-wrapper tp-shop-item-primary">
                {products.length === 0 ? (
                  <div
                    className="d-flex justify-content-center align-items-center flex-column sticky-top"
                    style={{ minHeight: 550, height: "100%" }}
                  >
                    <img
                      src="assets/animation/EmptyState.gif"
                      alt="No Products"
                      style={{ width: 300, marginBottom: 16 }}
                    />

                    <h4
                      className="text-muted mt-2 mb-0"
                      style={{ fontSize: "15px" }}
                    >
                      No products found for the
                      {categoryLabel && <span> {categoryLabel} </span>} ,
                      {collectionLabel && <span> {collectionLabel} </span>}{" "}
                      filters.
                    </h4>
                  </div>
                ) : ( 
                  <div className="tab-content" id="productTabContent">
                    {/* Grid */}
                    <div
                      className={`tab-pane fade${
                        activeTab === "grid" ? " show active" : ""
                      }`}
                      id="grid-tab-pane"
                      role="tabpanel"
                      aria-labelledby="grid-tab"
                      tabIndex="0"
                    >
                      <div className="row">
                        {products.map((item) => (
                          <div
                            key={item._id}
                            className="col-xl-4 col-md-6 col-sm-6"
                          >
                            {process.env.NEXT_PUBLIC_ONE_VARIANT === true ? (
                              <ProductItemDirect product={item} />
                            ) : (
                              <ProductItem product={item} />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* List */}
                    <div
                      className={`tab-pane fade${
                        activeTab === "list" ? " show active" : ""
                      }`}
                      id="list-tab-pane"
                      role="tabpanel"
                      aria-labelledby="list-tab"
                      tabIndex="0"
                    >
                      <div className="tp-shop-list-wrapper tp-shop-item-primary mb-70">
                        <div className="row">
                          <div className="col-xl-12">
                            {products.map((item) => (
                              <ShopListItem key={item._id} product={item} />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Pagination */}
              {products && products.length > 0 && (
                <div
                  className="d-flex align-items-center rounded-3 py-2 px-2"
                  style={{
                    boxShadow: "rgb(200 200 200 / 20%) 0px 0px 5px 1px",
                  }}
                >
                  <div className="tp-shop-top-result ms-2 d-none d-md-block flex-grow-1">
                    <p className="mb-0" style={{ fontSize: "14px" }}>
                      Showing{" "}
                      {products.length === 0
                        ? 0
                        : (page - 1) * products.length + 1}
                      –{Math.min(page * products.length, total)} of {total}{" "}
                      results
                    </p>
                  </div>
                  <CustomPagination
                    page={page}
                    onPageChange={onPageChange}
                    allPages={allPages}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ShopArea;
