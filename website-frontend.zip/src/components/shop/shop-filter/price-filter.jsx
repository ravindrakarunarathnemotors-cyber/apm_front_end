import { useEffect, useState } from "react";
import InputRange from "@/ui/input-range";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { useGetmaxPriceQuery } from "@/redux/features/categoryApi";

const PriceFilter = ({ priceFilterValues, maxPrice, handleFinalChange }) => {
  const { priceValue, handleChanges } = priceFilterValues;
  const symbol = useCurrencySymbol();
  
  return (
    <>
      <div className="tp-shop-widget mb-35">
        <h3 className="tp-shop-widget-title mb-3 ">Price Filter</h3>

        <div className="tp-shop-widget-content ps-1">
          <div className="tp-shop-widget-filter">
            <div id="slider-range" className="mb-10">
              <InputRange
                STEP={1}
                MIN={0}
                MAX={maxPrice ? parseFloat(maxPrice?.highest_price) : 999999999999999}  
                values={priceValue}
                handleChanges={handleChanges}
                handleFinalChange={handleFinalChange}
              />
            </div>
            <div className="tp-shop-widget-filter-info d-flex align-items-center justify-content-between">
              <span className="input-range">
                {symbol}{priceValue[0]} - {symbol}{priceValue[1]}
              </span>
              {/* <button className="tp-shop-widget-filter-btn btn-primary rounded" type="button">
                Filter
              </button> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PriceFilter;
