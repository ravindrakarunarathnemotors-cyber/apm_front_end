import { useRouter } from "next/router";
import React from "react";

const ResetLink = ({ shop_right = false }) => {
  const router = useRouter();
  return (
    <div className="tp-shop-widget badge bg-light shadow-sm">
      {/* <h3 className="tp-shop-widget-title">Reset Filter</h3> */}
      <button
        onClick={() =>
          router.push(`/${shop_right ? "shop-right-sidebar" : "shop"}`)
        }
        className="" style={{ color: "var(--secondary-color)" }}
      >
        Reset
      </button>
    </div>
  );
};

export default ResetLink;
