import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import ErrorMsg from "@/components/common/error-msg";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import ShopCategoryLoader from "@/components/loader/shop/shop-category-loader";



const CollectionFilter = ({ setCurrPage, collections }) => {
    const { data: categories, isLoading, isError } = useGetShowCategoryQuery();
    const router = useRouter();


    const [selectedCollection, setSelectedCollection] = useState(null);
    const [isExpanded, setIsExpanded] = useState(true);
    console.log("router.query", router.query)

    const slugify = (str) =>
        str.toLowerCase().replace("&", "").split(" ").join("-");

    useEffect(() => {
        // If collections are not loaded yet, do nothing
        if (!collections) return;

        const activeSlug = router.query.collection;

        // If query is cleared → reset selected collection
        if (!activeSlug) {
            setSelectedCollection(null);
            return;
        }

        // Match slug
        const matched = collections.find(
            (cat) => slugify(cat.name) === activeSlug
        );

        if (matched) {
            setSelectedCollection(matched.name);
        } else {
            setSelectedCollection(null);
        }
    }, [collections, router.query.collection]);



    const handleCollectionClick = (name) => {
        setCurrPage(1);
        const slug = slugify(name);

        router.push({
            pathname: "/shop",
            query: {
                ...router.query,
                collection: slug,
            },
        });

        setSelectedCollection(selectedCollection === name ? null : name);
    };

    let content = null;
    if (isLoading) {
        content = <ShopCategoryLoader loading={isLoading} />;
    } else if (isError) {
        content = <ErrorMsg msg="There was an error" />;
    } else if (collections?.length === 0) {
        content = <ErrorMsg msg="No Collection found!" />;
    } else {
        content = (
            <div className="border-bottom pb-4 mb-4">

                {isExpanded && (
                    <div className="list-unstyled">
                        {collections.map((collection) => (
                            <div
                                key={collection.collection_id}
                                className={`px-3 py-2 mb-1 rounded ${selectedCollection === collection.name
                                    ? 'bg-dark text-white'
                                    : 'bg-light'
                                    }`}
                                style={{ cursor: 'pointer' }}
                                onClick={() => handleCollectionClick(collection.name)}
                            >
                                <small className="d-flex align-items-center gap-2">
                                    <span
                                        className="rounded-circle d-inline-block"
                                        style={{
                                            width: '6px',
                                            height: '6px',
                                            backgroundColor: 'currentColor'
                                        }}
                                    ></span>
                                    {collection.name}
                                </small>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        )
    }

    return (
        <div className="tp-shop-widget mb-35">
            <div className="tp-shop-widget-filter-info d-flex align-items-end justify-content-between mb-2 pb-2 ">
                <h3 className="tp-shop-widget-title mb-0 no-border d-flex justify-content-between align-items-center">
                    Collections
                </h3>
                {collections?.length > 0 && (
                    <button
                        className="tp-shop-widget-filter-btn btn-primary rounded-pill "
                        style={{
                            fontWeight: '500', fontSize: ' 11px', padding: '0px 15px'
                        }}
                        onClick={() => setIsExpanded(!isExpanded)}
                    >
                        {isExpanded ? "Collapse All" : "Expand All"}
                    </button>
                )}
            </div>

            <div className="tp-shop-widget-content align-items-center ps-0 mb-0">
                {content}
            </div>
        </div>
    );
};

export default CollectionFilter;
