import React from "react";
import { useRouter } from "next/router";
import { useDispatch } from "react-redux";
import { handleFilterSidebarClose } from "@/redux/features/shop-filter-slice";

const slug = (s) => s.toLowerCase().replace("&", "").split(" ").join("-");

const StatusFilter = ({ setCurrPage, setStatus, shop_right = false }) => {
  const router = useRouter();
  const dispatch = useDispatch();
  const options = ["In Stock"];

  const onToggle = (s, nextChecked) => {
    setCurrPage(1);

    // update local state (if you keep one)
    setStatus(nextChecked ? s : "");

    // build next query
    const { status: _ignore, ...rest } = router.query;
    const nextQuery = nextChecked ? { ...rest, status: slug(s) } : rest;

    router.push(
      { pathname: "/shop", query: nextQuery },
      undefined
    );

    dispatch(handleFilterSidebarClose());
  };

  return (
    <div className="tp-shop-widget mb-35">
      <h3 className="tp-shop-widget-title mb-2">Product Status</h3>
      <div className="tp-shop-widget-content">
        <div className="">
          <ul className="filter-items filter-checkbox">
            {options.map((s) => {
              const checked = router.query.status === slug(s);
              return (
                <li key={s} className="filter-item checkbox d-flex align-items-center ps-1">
                  <input
                    id={s}
                    style={{display:'block', width:'16px' , height:'16px'}}
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => onToggle(s, e.target.checked)}
                  />
                  {/* label toggles the checkbox automatically via htmlFor */}
                  <label htmlFor={s} className="status-label ps-2">
                    {s}
                  </label>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default StatusFilter;
