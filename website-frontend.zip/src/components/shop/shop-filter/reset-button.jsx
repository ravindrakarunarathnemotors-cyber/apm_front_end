import { useRouter } from "next/router";
import React from "react";

const ResetButton = ({ shop_right = false }) => {
  const router = useRouter();
  return (
    <div className="tp-shop-widget mb-50">
      {/* <h3 className="tp-shop-widget-title">Reset Filter</h3> */}
      <button
        onClick={() =>
          router.push(`/${shop_right ? "shop-right-sidebar" : "shop"}`)
        }
        className="btn btn-sm btn-primary rounded w-100" style={{ backgroundColor: "var(--secondary-color)", borderColor: "var(--secondary-color)" }}
      >
        Reset Filter
      </button>
    </div>
  );
};

export default ResetButton;
