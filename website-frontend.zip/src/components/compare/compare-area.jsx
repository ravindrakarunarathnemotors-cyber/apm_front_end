import React from "react";
import Image from "next/image";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import { Rating } from "react-simple-star-rating";
// internal
import { add_cart_product } from "@/redux/features/cartSlice";
import { remove_compare_product } from "@/redux/features/compareSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { useRouter } from "next/router";

const CompareArea = () => {
  const { compareItems } = useSelector((state) => state.compare);
  const dispatch = useDispatch();
  const symbol = useCurrencySymbol();

  const router = useRouter();

  // handle add product
  const handleAddProduct = (prd) => {
    // dispatch(add_cart_product(prd));
    router.push(`product-details/${prd.product_id}`);
  };
  // handle add product
  const handleRemoveComparePrd = (prd) => {
    dispatch(remove_compare_product(prd));
  };

  return (
    <>
      <section className="tp-compare-area pb-120">
        <div className="container">
          <div className="row">
            <div className="col-xl-12">
              {compareItems.length === 0 && (
                <div className="text-center pt-50">
                  <h3>No Compare Items Found</h3>
                  <Link href="/shop" className="tp-cart-checkout-btn mt-20">
                    Continue Shopping
                  </Link>
                </div>
              )}
              {compareItems.length > 0 && (
                <div className="tp-compare-table table-responsive text-center">
                  <table className="table">
                    <tbody>
                      <tr>
                        <th className="text-start" style={{ verticalAlign: "top" }}>Product</th>
                        {compareItems.map((item) => (
                          <td key={item._id} className="">
                            <div className="tp-compare-thumb">
                              <Image
                                src={
                                  item.media_url ||
                                  item.img ||
                                  "/assets/img/shop/product-default.jpg"
                                }
                                alt={item.title}
                                width={400}
                                height={400}
                                style={{
                                  height: "auto",
                                  width: "150px",
                                  borderRadius: "10px",
                                  boxShadow: "0px 1px 5px rgba(1, 15, 28, 0.1)",
                                }}
                              />
                            </div>
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <th className="text-start" style={{ verticalAlign: "top" }}>Product</th>
                        {compareItems.map((item) => (
                          <td
                            key={item._id}
                            className=""
                            style={{ verticalAlign: "top" }}
                          >
                            <div className="text-start ">
                              <h4 className="tp-compare-product-title">
                                <Link
                                  href={`/product-details/${item.product_id}`}
                                >
                                  {item.title}
                                </Link>
                              </h4>
                            </div>
                          </td>
                        ))}
                      </tr>
                      {/* Description */}
                      <tr>
                        <th className="text-start" style={{ verticalAlign: "top" }}>Description</th>
                        {compareItems.map((item) => (
                          <td
                            key={item._id}
                            style={{ verticalAlign: " top" }}
                          >
                            <div className="tp-compare-desc text-start">
                              {item.description ? (
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html: item.description,
                                  }}
                                />
                              ) : (
                                <p>No description available.</p>
                              )}
                              {/* <p>{item.description}</p> */}
                            </div>
                          </td>
                        ))}
                      </tr>
                      {/* Price */}
                      <tr>
                        <th className="text-start" style={{ verticalAlign: "top" }}>Price</th>
                        {compareItems.map((item) => (
                          <td key={item._id}>
                            <div className="tp-compare-price text-start">
                              <span>
                                {symbol}
                                {parseFloat(item.price).toFixed(2)}
                              </span>
                            </div>
                          </td>
                        ))}
                      </tr>
                      {/* Add to cart*/}
                      <tr>
                        <th className="text-start" style={{ verticalAlign: "top" }}>Action</th>
                        {compareItems.map((item) => (
                          <td key={item._id}>
                            <div className="d-flex align-items-center gap-3 justify-content-start ">
                              <div className="tp-compare-add-to-cart ">
                                <button
                                  onClick={() => handleAddProduct(item)}
                                  type="button"
                                  className="tp-btn rounded"
                                >
                                  Buy Now
                                </button>
                              </div>
                              <div className="tp-compare-remove">
                                <button
                                  onClick={() => handleRemoveComparePrd(item)}
                                >
                                  <i className="fal fa-trash-alt"></i>
                                </button>
                              </div>
                            </div>
                          </td>
                        ))}
                      </tr>
                      {/* Rating */}
                      {/* <tr>
                        <th>Rating</th>
                        {compareItems.map(item => (
                          <td key={item._id}>
                            <div className="tp-compare-rating">
                              <Rating
                                allowFraction
                                size={16}
                                // initialValue={item.reviews.length > 0 ? item.reviews.reduce((acc, review) => acc + review.rating, 0) / item.reviews.length : 0}
                                readonly={true}
                              />
                            </div>
                          </td>
                        ))}
                      </tr> */}
                     
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default CompareArea;
