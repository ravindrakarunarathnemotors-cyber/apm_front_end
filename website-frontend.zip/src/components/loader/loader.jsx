import React from "react";
import { SkelLine } from "./_shared/Skeletons";

const Loader = ({ loading, height = 8, width = 120 }) => {
  if (!loading) return null;
  return <div className="text-center"><SkelLine h={height} style={{ width }} /></div>;
};

export default Loader;



// import React from "react";
// import { FadeLoader, BarLoader } from "react-spinners";

// const Loader = ({ loading, spinner = "scale",color="var(--primary-color)" }) => {
//   return (
//     <div className="text-center">
//       {spinner === "scale" && (
//         <BarLoader
//           color={`#${color}`}
//           loading={loading}
//           height={8}
//           width={100}
//           margin={2}
//         />
//       )}
//       {spinner === "fade" && <FadeLoader loading={loading} color="var(--primary-color) " />}
//     </div>
//   );
// };

// export default Loader;
