import React from "react";
import { Skel, SkelLine, SkelCircle } from "./_shared/Skeletons";

const PrdDetailsLoader = ({ loading }) => {
  if (!loading) return null;
  return (
    <div className="container py-4" aria-busy="true">
      <div className="row g-4">
        <div className="col-lg-6">
          <div className="bg-white rounded-3 shadow-sm p-3">
            <div className="ratio ratio-1x1 mb-3"><Skel className="w-100 h-100 rounded-3" /></div>
            <div className="d-flex gap-2">{[...Array(5)].map((_,i)=>
              <Skel key={i} className="rounded-3" style={{ width:64, height:64 }} />
            )}</div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="bg-white rounded-3 shadow-sm p-4">
            <SkelLine w="80%" className="mb-2" />
            <SkelLine w="45%" className="mb-3" />
            <SkelLine w="30%" h={20} className="mb-4" />
            <div className="mb-4">
              <SkelLine w="25%" className="mb-2" />
              <div className="d-flex gap-2">{[...Array(4)].map((_,i)=><SkelCircle key={i} size={36} />)}</div>
            </div>
            <div className="d-flex gap-3 mb-4">
              <Skel className="rounded-2" style={{ width:120, height:40 }} />
              <Skel className="rounded-2" style={{ width:140, height:40 }} />
            </div>
            <SkelLine w="90%" className="mb-2" />
            <SkelLine w="85%" className="mb-2" />
            <SkelLine w="70%" />
          </div>
        </div>
      </div>
    </div>
  );
};
export default PrdDetailsLoader;


// import Loader from "./loader";

// // single loader
// function PrdDetailsLoader({ loading }) {
//   return (
//     <div
//       className="d-flex align-items-center justify-content-center"
//       style={{ height: "700px" }}
//     >
//       <Loader loading={loading} />
//     </div>
//   );
// }

// export default PrdDetailsLoader;