import React, { useEffect, useState } from "react";

/**
 * Crossfades skeleton and content, then unmounts the skeleton.
 * - loading: boolean
 * - skeleton: ReactNode
 * - children: ReactNode (real UI)
 * - minMs: minimum time to show the skeleton (avoid 1-frame flicker)
 * - fadeMs: duration of the cross-fade
 * - mountChildrenWhileLoading: render children while loading to avoid layout shift
 */
const LoaderSwitch = ({
  loading,
  skeleton,
  children,
  minMs = 180,
  fadeMs = 260,
  mountChildrenWhileLoading = true,
}) => {
  // Keep the skeleton mounted long enough to fade it out cleanly
  const [keepSkelMounted, setKeepSkelMounted] = useState(loading);
  const [skelPhase, setSkelPhase] = useState(loading ? "visible" : "hidden"); // 'visible' | 'fading' | 'hidden'

  useEffect(() => {
    let t1, t2;
    if (loading) {
      setKeepSkelMounted(true);
      setSkelPhase("visible");
    } else {
      // give the skeleton a minimum time, then fade it, then unmount
      t1 = setTimeout(() => {
        setSkelPhase("fading");
        t2 = setTimeout(() => {
          setSkelPhase("hidden");
          setKeepSkelMounted(false);
        }, fadeMs);
      }, minMs);
    }
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [loading, minMs, fadeMs]);

  const skelStyle = {
    opacity: skelPhase === "visible" ? 1 : 0,
    transition: `opacity ${fadeMs}ms ease`,
    pointerEvents: skelPhase === "hidden" ? "none" : "auto",
  };

  const contentStyle = {
    opacity: loading ? 0 : 1,
    transition: `opacity ${fadeMs}ms ease ${loading ? "0ms" : "40ms"}`, // tiny delay feels smoother
  };

  // Always render children by default to reserve layout (no jump).
  // If your children truly can't render without data, set mountChildrenWhileLoading={false}.
  const shouldRenderChildren = mountChildrenWhileLoading || !loading;

  return (
    <div className="loader-switch">
      {keepSkelMounted && (
        <div className="loader-switch__skeleton" style={skelStyle} aria-hidden="true">
          {skeleton}
        </div>
      )}
      {shouldRenderChildren && (
        <div
          className="loader-switch__content"
          style={contentStyle}
          aria-busy={loading || undefined}
        >
          {children}
        </div>
      )}
    </div>
  );
};

export default LoaderSwitch;
