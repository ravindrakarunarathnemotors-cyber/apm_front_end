// loader/_shared/Skeletons.jsx
import React from "react";

/* ------------------ BASE ------------------ */
export const Skel = ({
  className = "",
  style,
  rounded,
  "aria-label": ariaLabel,
  role = "presentation",
}) => {
  const radius =
    typeof rounded === "number" ? `${rounded}px` : rounded || undefined;
  return (
    <div
      className={`skel ${className}`}
      style={{ borderRadius: radius, ...style }}
      aria-hidden={ariaLabel ? undefined : true}
      aria-label={ariaLabel}
      role={role}
    />
  );
};

const toSize = (v, fallback) =>
  v === undefined ? fallback : typeof v === "number" ? `${v}px` : v;

export const SkelLine = ({ w = "100%", h = 14, className = "", rounded = 6 }) => (
  <Skel
    className={`rounded-2 ${className}`}
    rounded={rounded}
    style={{ width: toSize(w, "100%"), height: toSize(h, 14) }}
  />
);

export const SkelCircle = ({ size = 40, className = "" }) => (
  <Skel
    className={`rounded-circle ${className}`}
    style={{ width: toSize(size, 40), height: toSize(size, 40) }}
  />
);

/* ------------------ UTILITIES ------------------ */
export const SkelBox = ({ w = "100%", h = 44, className = "", rounded = 8 }) => (
  <Skel className={className} rounded={rounded} style={{ width: toSize(w, "100%"), height: toSize(h, 44) }} />
);
export const SkelInput = ({ className = "", w = "100%", h = 44 }) => (
  <SkelBox className={`rounded-2 ${className}`} w={w} h={h} />
);
export const SkelButton = ({ className = "", w = "100%", h = 40, rounded = 6 }) => (
  <SkelBox className={className} w={w} h={h} rounded={rounded} />
);
export const SkelLines = ({ count = 3, gap = 10, className = "", lineProps = {} }) => (
  <div className={className} style={{ display: "grid", gap }}>
    {Array.from({ length: count }).map((_, i) => (
      <SkelLine key={i} {...lineProps} />
    ))}
  </div>
);

/* ------------------ BLOCKS ------------------ */
export const ProductCardSkeleton = () => (
  <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 mt-4 ">
    <div className="bg-white rounded-3 shadow-sm mb-4 overflow-hidden">
      <div className="ratio ratio-1x1">
        <Skel className="w-100 h-100" />
      </div>
      <div className="p-3">
        <SkelLine w="80%" className="mb-2" />
        <SkelLine w="55%" className="mb-3" />
        <div className="d-flex align-items-center justify-content-between">
          <SkelLine w="32%" h={16} />
          <SkelBox w="48%" h={36} rounded={6} />
        </div>
      </div>
    </div>
  </div>
);

export const MiniMediaSkeleton = () => (
  <div className="d-flex align-items-center gap-3 mb-3">
    <SkelBox w={60} h={60} rounded={8} />
    <div className="flex-grow-1">
      <SkelLine w="70%" className="mb-2" />
      <SkelLine w="40%" />
    </div>
  </div>
);

export const CategoryTileSkeleton = () => (
  <div className="col-lg-3 col-sm-6">
    <div
      className="bg-white rounded-3 shadow-sm d-flex flex-column align-items-center justify-content-center mb-4"
      style={{ height: 300 }}
    >
      <SkelCircle size={64} className="mb-3" />
      <SkelLine w="70%" className="mb-2" />
      <SkelLine w="40%" />
    </div>
  </div>
);

export const HeroWideSkeleton = ({ height = 250 }) => (
  <div className="bg-white rounded-3 shadow-sm overflow-hidden mb-4">
    <div style={{ height }}>
      <Skel className="w-100 h-100" />
    </div>
  </div>
);
