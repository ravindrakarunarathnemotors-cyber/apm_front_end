import React from "react";
import { HeroWideSkeleton } from "../_shared/Skeletons";

const HomeThreeTrendingPrdLoader = ({ loading, height = 250 }) => {
  if (!loading) return null;
  return <HeroWideSkeleton height={height} />;
};

export default HomeThreeTrendingPrdLoader;




// import React from "react";
// import Loader from "../loader";

// function SingleLoader({ loading }) {
//   return (
//     <div className="d-flex align-items-center justify-content-center" style={{ height: "250px" }}>
//       <Loader loading={loading} color="BD844C" />
//     </div>
//   );
// }

// const HomeThreeTrendingPrdLoader = ({ loading }) => {
//   return <SingleLoader loading={loading} />;
// };

// export default HomeThreeTrendingPrdLoader;
