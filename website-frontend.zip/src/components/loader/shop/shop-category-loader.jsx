import React from "react";
import { SkelLine } from "../_shared/Skeletons";

const ShopCategoryLoader = ({ loading, count = 8 }) => {
  if (!loading) return null;
  return (
    <div aria-busy="true">
      {Array.from({ length: count }).map((_, i) => (
        <div className="d-flex align-items-center gap-2 mb-2" key={i}>
          <SkelLine w="10%" h={12} className="rounded-circle" />
          <SkelLine w="70%" h={14} />
        </div>
      ))}
    </div>
  );
};
export default ShopCategoryLoader;



// import React from "react";
// import Loader from "../loader";

// function SingleLoader({ loading }) {
//   return (
//     <div
//       className="col-xl-3 col-lg-3 col-sm-6 d-flex align-items-center"
//       style={{ height: "50px" }}
//     >
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const ShopCategoryLoader = ({ loading }) => {
//   return (
//     <>
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//     </>
//   );
// };

// export default ShopCategoryLoader;
