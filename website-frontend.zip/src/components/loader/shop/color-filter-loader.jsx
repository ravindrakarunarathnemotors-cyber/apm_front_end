import React from "react";
import { SkelCircle, SkelLine } from "../_shared/Skeletons";

const ColorFilterLoader = ({ loading, count = 7 }) => {
  if (!loading) return null;
  return (
    <div aria-busy="true">
      <SkelLine w="35%" className="mb-3" />
      <div className="d-flex flex-wrap gap-2">
        {Array.from({ length: count }).map((_, i) => <SkelCircle key={i} size={28} />)}
      </div>
    </div>
  );
};
export default ColorFilterLoader;



// import React from "react";
// import Loader from "../loader";

// function SingleLoader({ loading }) {
//   return (
//     <div style={{ height: "30px" }}>
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const ShopColorLoader = ({ loading }) => {
//   return (
//     <>
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//     </>
//   );
// };

// export default ShopColorLoader;
 