import React from "react";
import { MiniMediaSkeleton } from "../_shared/Skeletons";

const TopRatedPrdLoader = ({ loading, count = 3 }) => {
  if (!loading) return null;
  return <div aria-busy="true">{Array.from({ length: count }).map((_,i)=><MiniMediaSkeleton key={i} />)}</div>;
};
export default TopRatedPrdLoader;


// import React from "react";
// import Loader from "../loader";

// function SingleLoader({ loading }) {
//   return (
//     <div style={{ height: "70px" }}>
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const ShopTopRatedLoader = ({ loading }) => {
//   return (
//     <>
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//     </>
//   );
// };

// export default ShopTopRatedLoader;
