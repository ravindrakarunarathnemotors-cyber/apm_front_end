import React from "react";
import { SkelLine, SkelBox, SkelButton, ProductCardSkeleton } from "@/components/loader/_shared";

/** List-row skeleton */
const ShopListItemSkeleton = () => (
  <div className="tp-product-list-item d-sm-flex border rounded overflow-hidden mb-2">
    <div className="tp-product-list-thumb p-relative fix overflow-hidden" style={{ maxWidth: 300 }}>
      <div className="bg-white">
        <SkelBox h={220} />
      </div>
    </div>
    <div className="tp-product-list-content w-100 border-0">
      <div className="tp-product-content-2 pt-15 px-3 px-sm-4">
        <SkelLine w="20%" className="mb-2" />
        <SkelLine w="70%" className="mb-2" />
        <SkelLine w="55%" className="mb-3" />
        <SkelLine w="30%" className="mb-2" />
        <SkelLine w="95%" className="mb-2 d-none d-sm-block" />
        <SkelLine w="85%" className="mb-3 d-none d-sm-block" />
        <SkelButton w={130} h={40} />
      </div>
    </div>
  </div>
);

/** Full shop skeleton: sidebar + topbar + grid/list area */
const ShopLoader = ({ mode = "grid", cards = 9 }) => {
  return (
    <section className="tp-shop-area pt-40 pb-120" style={{ background: "#fff" }}>
      <div className="container">
        <div className="row">
          {/* Sidebar */}
          <div className="col-xl-3 col-lg-4 d-none d-lg-block">
            <div className="position-sticky align-self-start" style={{ top: "96px", zIndex: 2 }}>
              <div className="p-4 shadow-sm rounded bg-white">
                <div className="mb-4">
                  <SkelLine w="40%" className="mb-3" />
                  <SkelLine w="100%" className="mb-2" />
                  <SkelLine w="100%" className="mb-2" />
                  <SkelLine w="85%" />
                </div>
                <div className="mb-4">
                  <SkelLine w="35%" className="mb-3" />
                  <div className="d-grid" style={{ gap: 10 }}>
                    <SkelLine w="80%" />
                    <SkelLine w="60%" />
                    <SkelLine w="70%" />
                    <SkelLine w="50%" />
                  </div>
                </div>
                <div className="mb-2">
                  <SkelButton h={40} />
                </div>
              </div>
            </div>
          </div>

          {/* Main */}
          <div className="col-xl-9 col-lg-8">
            <div className="tp-shop-main-wrapper">
              {/* Top bar */}
              <div className="tp-shop-top mb-45">
                <div className="row">
                  <div className="col-xl-6">
                    <div className="d-flex align-items-center gap-3">
                      <SkelBox w={44} h={36} />
                      <SkelBox w={44} h={36} />
                      <SkelLine w="45%" />
                    </div>
                  </div>
                  <div className="col-xl-6 d-flex justify-content-xl-end align-items-center mt-3 mt-lg-0 gap-3">
                    <SkelButton w={110} h={36} className="d-block d-lg-none" />
                    <SkelBox w={180} h={40} />
                  </div>
                </div>
              </div>

              {/* Items */}
              {mode === "grid" ? (
                <div className="row">
                  {Array.from({ length: cards }).map((_, i) => (
                    <ProductCardSkeleton key={i} />
                  ))}
                </div>
              ) : (
                <div className="tp-shop-list-wrapper tp-shop-item-primary mb-70">
                  <div className="row">
                    <div className="col-xl-12">
                      {Array.from({ length: Math.ceil(cards / 2) }).map((_, i) => (
                        <ShopListItemSkeleton key={i} />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Pagination */}
              <div className="d-flex justify-content-center mt-20">
                <SkelBox w={320} h={40} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ShopLoader;
