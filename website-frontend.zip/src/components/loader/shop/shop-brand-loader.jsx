import React from "react";
import { Skel } from "../_shared/Skeletons";

const ShopBrandLoader = ({ loading, count = 8 }) => {
  if (!loading) return null;
  return (
    <div className="row g-3" aria-busy="true">
      {Array.from({ length: count }).map((_, i) => (
        <div className="col-6 col-md-4 col-lg-3" key={i}>
          <div className="bg-white rounded-3 shadow-sm p-3 d-flex align-items-center justify-content-center">
            <Skel className="rounded-2" style={{ width: "100%", height: 56 }} />
          </div>
        </div>
      ))}
    </div>
  );
};
export default ShopBrandLoader;



// import React from "react";
// import Loader from "../loader";

// function SingleLoader({ loading }) {
//   return (
//     <div className="col-md-6 col-6" style={{ height: "50px" }}>
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const ShopBrandLoader = ({ loading }) => {
//   return (
//     <div className="row">
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//       <SingleLoader loading={loading} />
//     </div>
//   );
// };

// export default ShopBrandLoader;
