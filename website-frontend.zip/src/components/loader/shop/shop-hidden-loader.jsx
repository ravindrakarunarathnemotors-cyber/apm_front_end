import React from "react";
import { ProductCardSkeleton } from "../_shared/Skeletons";

const ShopHiddenLoader = ({ loading, count = 12 }) => {
  if (!loading) return null;
  return (
    <div className="row" aria-busy="true">
      {Array.from({ length: count }).map((_, i) => <ProductCardSkeleton key={i} />)}
    </div>
  );
};
export default ShopHiddenLoader;


// import React from "react";
// import Loader from "../loader";

// function PrdItemLoader({ loading }) {
//   return (
//     <div
//       className="col-xl-3 col-lg-4 col-md-6 col-sm-6"
//       style={{ height: "350px" }}
//     >
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const ShopHiddenLoader = ({ loading }) => {
//   return (
//     <div className="row">
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//       <PrdItemLoader loading={loading} />
//     </div>
//   );
// };

// export default ShopHiddenLoader;
