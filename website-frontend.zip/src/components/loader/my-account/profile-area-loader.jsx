import React from "react";
import { SkelLine, SkelBox, SkelCircle } from "@/components/loader/_shared";

/** Full-page loader that roughly matches a common profile layout */
const ProfileAreaLoader = () => {
  return (
    <section className="pt-70 pb-140" style={{ background: "#fff", minHeight: "70vh" }}>
      <div className="container">
        <div className="row g-4">
          {/* Sidebar */}
          <div className="col-lg-3">
            <div className="bg-white rounded-3 shadow-sm p-4">
              <div className="d-flex flex-column align-items-center text-center">
                <SkelCircle size={72} className="mb-3" />
                <SkelLine w="60%" className="mb-1" />
                <SkelLine w="40%" className="mb-3" />
              </div>
              <div className="d-grid" style={{ gap: 12 }}>
                <SkelBox h={44} />
                <SkelBox h={44} />
                <SkelBox h={44} />
                <SkelBox h={44} />
              </div>
            </div>
          </div>

          {/* Main */}
          <div className="col-lg-9">
            <div className="bg-white rounded-3 shadow-sm p-4 mb-4">
              <SkelLine w="30%" className="mb-3" />
              <div className="row g-3">
                <div className="col-md-6">
                  <SkelLine w="40%" className="mb-2" />
                  <SkelBox h={44} />
                </div>
                <div className="col-md-6">
                  <SkelLine w="40%" className="mb-2" />
                  <SkelBox h={44} />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3 shadow-sm p-4">
              <SkelLine w="25%" className="mb-3" />
              {/* table-ish rows */}
              <div className="d-grid" style={{ gap: 12 }}>
                <SkelBox h={48} />
                <SkelBox h={48} />
                <SkelBox h={48} />
                <SkelBox h={48} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProfileAreaLoader;
