import React from "react";
import { ProductCardSkeleton } from "./_shared/Skeletons";

const SearchPrdLoader = ({ loading, count = 8 }) => {
  if (!loading) return null;
  return (
    <div className="container" aria-busy="true">
      <div className="row">
        {Array.from({ length: count }).map((_, i) => <ProductCardSkeleton key={i} />)}
      </div>
    </div>
  );
};
export default SearchPrdLoader;


// import React from 'react';
// import Loader from './loader';

// function SingleLoader({ loading }) {
//   return (
//     <div
//       className="col-xl-3 col-lg-3 col-sm-6 d-flex align-items-center"
//       style={{ height: "300px" }}
//     >
//       <Loader loading={loading} />
//     </div>
//   );
// }

// const SearchPrdLoader = ({ loading }) => {
//   return (
//     <div className='container'>
//       <div className="row">
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//         <SingleLoader loading={loading} />
//       </div>
//     </div>
//   );
// };

// export default SearchPrdLoader;