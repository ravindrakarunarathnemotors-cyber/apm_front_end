import React from "react";
import { SkelLine, SkelBox, SkelButton } from "@/components/loader/_shared";

/** Pure skeleton that mirrors the final layout */
const LoginAreaLoader = () => {
  return (
    <section
      className="tp-login-area pt-70 pb-140 p-relative z-index-1 fix"
      style={{ background: "#fff", minHeight: 480 }}
    >
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12">
            <div
              className="tp-login-wrapper p-5"
              style={{
                borderRadius: 16,
                background: "rgba(255,255,255,.92)",
                boxShadow:
                  "0 30px 60px rgba(0,0,0,.06), 0 2px 10px rgba(0,0,0,.04)",
              }}
            >
              <div className="tp-login-option d-flex flex-column flex-md-row justify-content-between align-items-stretch">
                {/* REGISTER */}
                <div className="col-12 col-md-6 order-3 order-md-1">
                  <SkelLine w={160} h={22} className="mb-4" />
                  <div className="d-grid" style={{ gap: 12 }}>
                    <SkelBox h={44} />
                    <SkelBox h={44} />
                    <SkelBox h={44} />
                    <SkelButton h={44} className="mt-1" />
                  </div>
                </div>

                {/* Divider */}
                <div
                  className="d-none d-md-block order-md-2"
                  style={{
                    width: 1,
                    background: "#E3E6EA",
                    margin: "0 16px",
                    minHeight: 260,
                    alignSelf: "stretch",
                    borderRadius: 2,
                    opacity: 0.8,
                  }}
                />
                <div
                  className="d-block d-md-none order-2"
                  style={{
                    minWidth: 240,
                    background: "#E3E6EA",
                    margin: "24px 0",
                    minHeight: 1,
                    alignSelf: "stretch",
                    borderRadius: 2,
                    opacity: 0.8,
                  }}
                />

                {/* LOGIN */}
                <div className="col-12 col-md-5 d-flex flex-column order-1 order-md-3">
                  <SkelLine w={120} h={22} className="mb-4" />
                  <div className="d-flex flex-wrap gap-2 mb-3">
                    <SkelButton h={40} className="flex-grow-1" />
                    <SkelButton h={40} className="flex-grow-1" />
                  </div>

                  <div className="d-flex align-items-center my-3 border-top pt-3" style={{ gap: 10 }}>
                    <SkelBox w={24} h={20} rounded={4} />
                    <SkelLine w={220} />
                  </div>

                  <div className="d-grid" style={{ gap: 12 }}>
                    <SkelBox h={44} />
                    <SkelBox h={44} />
                    <SkelButton h={44} />
                  </div>
                </div>
                {/* /LOGIN */}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoginAreaLoader;
