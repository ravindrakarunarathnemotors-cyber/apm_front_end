import React, { useMemo, useState, useEffect } from "react";
import { CardElement } from "@stripe/react-stripe-js";
import { useSelector } from "react-redux";
// internal
import useCartInfo from "@/hooks/use-cart-info";
import ErrorMsg from "../common/error-msg";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { useGetAllPaymentMethodsQuery } from "@/redux/features/productApi";
import Image from "next/image";
import { useRouter } from "next/router";
import Swal from "sweetalert2";
import { measurementConverter } from "@/hooks/useMeasurementConverter ";

const CheckoutOrderArea = ({
  checkoutData,
  register,
  errors,
  watch,
  orderLoading,
  systemData,
  deliverFee,
  setDeliverFee,
  setTaxName,
  isGuest,
  setDiscountDetails,
  loyaltiPoints,
  setLoyaltiPoints,
  selectClient,
  setLastSubTotal1,
  setfullAmount2,
  setSelectedMethod,
  selectedMethod,
  setTransactionFee,
}) => {
  const { cartTotal = 0 } = checkoutData;

  const [taxFields, setTaxFields] = useState({ key: "", value: "" });
  const [taxEnabled, setTaxEnabled] = useState(false);
  const [weight, setWeight] = useState(0);

  //discount
  const [discountCode, setDiscountCode] = useState("");
  const [appliedCode, setAppliedCode] = useState(false);
  const [finalDiscount, setFinalDiscount] = useState(null);
  const [loading, setLoading] = useState(false);
  const [discountType, setDiscountType] = useState("none");
  const [orderDiscount, setOrderDiscount] = useState(null);
  const [productDiscount, setProductDiscount] = useState(null);

  const [deliveryDiscount, setDeliveryDiscount] = useState(null);
  const [paymentMethodDiscount, setPaymentMethodDiscount] = useState(null);
  const [paymentMethodLoading, setPaymentMethodLoading] = useState(false);
  const [buyxDiscont, setBuyxDiscont] = useState(null);

  const { cart_products } = useSelector((state) => state.cart);
  const { data: paymentData } = useGetAllPaymentMethodsQuery();
  const { total } = useCartInfo();
  const symbol = useCurrencySymbol();

  let token = "";
  if (typeof window !== "undefined") {
    token = localStorage.getItem("accessToken");
  }

  const router = useRouter();
  console.log(total, cartTotal, "cart total");
  const totalWeight = useMemo(() => {
    return cart_products.reduce((total, item) => {
      const qty = parseFloat(item.orderQuantity) || 0;

      // measurement_id === 3 → grams → kg
      if (item.measurement_id === 3) {
        const amountPerUnit = parseFloat(item.amount_per_unit) || 0;
        return total + (amountPerUnit / 1000) * qty;
      }

      // measurement_id === 4 → ml (no divide)
      if (item.measurement_id === 2) {
        const amountPerUnit = parseFloat(item.amount_per_unit) || 0;
        return total + amountPerUnit * qty;
      }

      // default → weight * quantity
      const weight = parseFloat(item.weight) || 0;
      return total + weight * qty;
    }, 0);
  }, [cart_products]);

  useEffect(() => {
    if (!systemData) return;

    const tax_on_web = systemData?.tax_on_web;
    const tax_value = systemData?.tax_value;
    console.log(tax_on_web);
    setTaxEnabled(tax_on_web);
    const key = Object.keys(tax_value)[0];
    const value = tax_value[key];
    setTaxFields({ key, value });
  }, [systemData]);

  useEffect(() => {
    const fetchDeliveryFee = async () => {
      const sameAsBilling = watch("sameAsBilling");
      const country = watch("country");
      const deliveryCountry = watch("deliveryCountry");

      let delCountry = sameAsBilling ? country : deliveryCountry;

      if (!delCountry) return;

      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/system/get-delivery-fee`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ country: delCountry }),
        },
      );

      const data = await response.json();

      if (response.status === 200) {
        const fee = parseFloat(data.result.fee);
        const additional_fee = parseFloat(data.result.additional_fee);
        const roundedWeight = Math.ceil(parseFloat(totalWeight));
        console.log(typeof fee, additional_fee, roundedWeight);
        if (roundedWeight > 1) {
          setDeliverFee(
            parseFloat(fee) + parseFloat(additional_fee) * (roundedWeight - 1),
          );
        } else {
          setDeliverFee(parseFloat(fee));
        }
      }
    };

    fetchDeliveryFee();
  }, [
    watch("sameAsBilling"),
    watch("country"),
    watch("deliveryCountry"),
    totalWeight,
  ]);

  const totalDiscount = useMemo(() => {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };

    const orderValue = num(orderDiscount?.discount_value);
    const paymentValue = num(paymentMethodDiscount?.discount_value);
    const deliveryValue = num(deliveryDiscount?.discount_value);
    const productValue = num(productDiscount?.total_discount_value);
    const buyxValue = num(buyxDiscont?.total_discount_value);
    const orderCodeValue = num(finalDiscount?.discount_value);

    // If appliedCode is true, only use finalDiscount, but still keep object shape
    if (appliedCode) {
      const discountValue = num(orderCodeValue);
      return {
        discountValue,
        orderValue: 0,
        paymentValue: 0,
        deliveryValue: 0,
        productValue: 0,
        buyxValue: 0,
      };
    }

    const discountValue = Math.max(
      orderValue,
      paymentValue,
      deliveryValue,
      productValue,
      buyxValue,
      0,
    );

    return {
      discountValue,
      orderValue,
      paymentValue,
      deliveryValue,
      productValue,
      buyxValue,
    };
  }, [
    appliedCode,
    finalDiscount,
    orderDiscount,
    productDiscount,
    paymentMethodDiscount,
    deliveryDiscount,
    buyxDiscont,
  ]);

  useEffect(() => {
    const {
      discountValue,
      orderValue,
      paymentValue,
      deliveryValue,
      productValue,
      buyxValue,
    } = totalDiscount;

    if (discountValue === 0) {
      setDiscountType("none");
      return;
    }

    switch (discountValue) {
      case orderValue:
        setDiscountType("order");
        break;
      case paymentValue:
        setDiscountType("payment_method");
        break;
      case deliveryValue:
        setDiscountType("shipping");
        break;
      case productValue:
        setDiscountType("product");
        break;
      case buyxValue:
        setDiscountType("buyx");
        break;
      default:
        setDiscountType("none");
    }
  }, [totalDiscount, discountType]);

  useEffect(() => {
    if (!appliedCode && discountType == "none") return;

    if (appliedCode) {
      setDiscountDetails({
        discount_id: finalDiscount.discount_id,
        discount_value: finalDiscount.discount_value,
        type: "code",
      });
    } else if (discountType == "order") {
      setDiscountDetails({
        discount_id: orderDiscount.discount_id,
        discount_value: orderDiscount.discount_value,
        type: "order",
      });
    } else if (discountType == "payment_method") {
      setDiscountDetails({
        discount_id: paymentMethodDiscount.discount_id,
        discount_value: paymentMethodDiscount.discount_value,
        type: "payment_method",
      });
    } else if (discountType == "shipping") {
      setDiscountDetails({
        discount_id: deliveryDiscount.discount_id,
        discount_value: deliveryDiscount.discount_value,
        type: "shipping",
      });
    } else if (discountType == "product") {
      setDiscountDetails({
        discount_id: productDiscount.discount_id,
        discount_value: productDiscount.total_discount_value,
        type: "product",
        discont_product: productDiscount.applicableProducts,
      });
    } else if (discountType == "buyx") {
      setDiscountDetails({
        discount_id: buyxDiscont.discount_id,
        discount_value: buyxDiscont.applicableProducts,
        type: "buyx",
      });
    }
  }, [discountType, appliedCode]);

  const lastSubTotal = useMemo(() => {
    const totalValue = parseFloat(total) || 0;
    const discountValue = parseFloat(totalDiscount?.discountValue) || 0;

    return discountType == "product" ? totalValue - discountValue : totalValue;
  }, [discountType, total, totalDiscount?.discountValue]);

  const totalTax = useMemo(() => {
    const Discount =
      discountType == "buyx"
        ? 0
        : parseFloat(totalDiscount?.discountValue) || 0;
    const beforeTaxTotal =
      parseFloat(total) - Discount + parseFloat(deliverFee);
    const taxPercent = parseFloat(taxFields.value) || 0;
    const tax = beforeTaxTotal * (taxPercent / 100);
    setTaxName({ name: taxFields.key, value: tax });
    return tax;
  }, [
    lastSubTotal,
    taxFields.value,
    total,
    totalDiscount?.discountValue,
    discountType,
    deliverFee,
  ]);

  //calculate all transaction for full amount
  const fullAmountTransaction = useMemo(() => {
    const parsedTotaltax = parseFloat(totalTax) || 0;
    const parsedDeliveryFee = parseFloat(deliverFee) || 0;
    const discountValue =
      discountType != "buyx" ? parseFloat(totalDiscount?.discountValue) : 0;
    const points = loyaltiPoints ? parseFloat(loyaltiPoints) : 0;

    if (taxEnabled) {
      return (
        parseFloat(cartTotal) +
        parsedDeliveryFee +
        parsedTotaltax -
        discountValue -
        points
      );
    } else {
      return parseFloat(cartTotal) + parsedDeliveryFee - discountValue - points;
    }
  }, [
    cartTotal,
    totalTax,
    deliverFee,
    totalDiscount,
    discountType,
    loyaltiPoints,
  ]);

  const transactionFee = useMemo(() => {
    if (!selectedMethod?.commission_status) return 0;

    const commission = Number(selectedMethod.transaction_fee) || 0;
    const fixed = Number(selectedMethod.transaction_fixed_fee) || 0;

    return (fullAmountTransaction * commission) / 100 + fixed;
  }, [fullAmountTransaction, selectedMethod]);

  const fullAmounttwo = useMemo(() => {
    const parsedTotaltax = parseFloat(totalTax) || 0;
    const parsedDeliveryFee = parseFloat(deliverFee) || 0;
    const discountValue =
      discountType == "buyx" || discountType == "product"
        ? 0
        : parseFloat(totalDiscount?.discountValue) || 0;

    if (taxEnabled) {
      return (
        parseFloat(lastSubTotal) +
        parsedDeliveryFee +
        parsedTotaltax -
        discountValue +
        transactionFee
      );
    } else {
      return (
        parseFloat(lastSubTotal) +
        parsedDeliveryFee -
        discountValue +
        transactionFee
      );
    }
  }, [
    lastSubTotal,
    totalTax,
    deliverFee,
    totalDiscount,
    discountType,
    transactionFee,
  ]);

  //full amount calculate
  const fullAmount = useMemo(() => {
    const parsedTotaltax = parseFloat(totalTax) || 0;
    const parsedDeliveryFee = parseFloat(deliverFee) || 0;
    const discountValue =
      discountType != "buyx" ? parseFloat(totalDiscount?.discountValue) : 0;
    const points = loyaltiPoints ? parseFloat(loyaltiPoints) : 0;

    if (taxEnabled) {
      return (
        parseFloat(cartTotal) +
        parsedDeliveryFee +
        parsedTotaltax -
        discountValue -
        points +
        transactionFee
      );
    } else {
      return (
        parseFloat(cartTotal) +
        parsedDeliveryFee -
        discountValue -
        points +
        transactionFee
      );
    }
  }, [
    cartTotal,
    totalTax,
    deliverFee,
    totalDiscount,
    discountType,
    loyaltiPoints,
    transactionFee,
  ]);

  //..............................................................

  useEffect(() => {
    setLastSubTotal1(lastSubTotal);
  }, [lastSubTotal]);

  useEffect(() => {
    setfullAmount2(fullAmount);
  }, [fullAmount]);

  useEffect(() => {
    setTransactionFee(transactionFee);
  }, [transactionFee]);

  useEffect(() => {
    if (cart_products.length === 0) return;

    const timer = setTimeout(() => {
      autoDiscount();
      autoBuyxDiscount();
    }, 1000); // 10 seconds

    return () => clearTimeout(timer); // cancel previous timer before setting a new one
  }, [cart_products]);

  useEffect(() => {
    if (cart_products.length === 0 || deliverFee === 0) return;
    autoDeliveryDiscount();
  }, [cart_products, deliverFee]);

  const autoDeliveryDiscount = async () => {
    try {
      if (!isGuest) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodeliverdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
              deliverFee: deliverFee,
            }),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setDeliveryDiscount(data.data ? data.data : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodeliverdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
              deliverFee: deliverFee,
            }),
          },
        );

        const data = await response.json();

        if (response.status === 200) {
          setDeliveryDiscount(data.data ? data.data : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const autoPaymentMethodDiscount = async (id) => {
    try {
      if (!isGuest) {
        setPaymentMethodLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodpmethoddiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
              id: id,
            }),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setPaymentMethodDiscount(data.data ? data.data : null);
          setPaymentMethodLoading(false);
        }
      } else {
        setPaymentMethodLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodpmethoddiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
              id: id,
            }),
          },
        );

        const data = await response.json();

        if (response.status === 200) {
          setPaymentMethodDiscount(data.data ? data.data : null);
          setPaymentMethodLoading(false);
        }
      }
    } catch (error) {
      console.log(error);
      setPaymentMethodLoading(false);
    }
  };
  const autoDiscount = async () => {
    try {
      if (!isGuest) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(data.data.order ? data.data.order : null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          },
        );

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(data.data.order ? data.data.order : null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };
  const autoBuyxDiscount = async () => {
    try {
      if (!isGuest) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          },
        );

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const checkDiscount = async () => {
    try {
      if (!isGuest) {
        setLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/discountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              discountCode: discountCode,
              cart_products: cart_products,
            }),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setFinalDiscount(data.data);
          setAppliedCode(true);
        } else {
          Swal.fire({
            icon: "error",
            title: "Error",
            text: data.message,
          });
        }
        setLoading(false);
      } else {
        setLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestdiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              discountCode: discountCode,
              cart_products: cart_products,
            }),
          },
        );

        const data = await response.json();

        if (response.status === 200) {
          setFinalDiscount(data.data);
          setAppliedCode(true);
        } else {
          Swal.fire({
            icon: "error",
            text: data.message,
          });
        }
        setLoading(false);
      }
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const handleRemoveCode = () => {
    setFinalDiscount(null);
    setAppliedCode(false);
    setDiscountCode("");
  };

  const handleChange = (e) => {
    let value = e.target.value;
    const max = parseFloat(selectClient?.loyalty_point) || 0;

    // Allow empty value
    if (value === "") {
      setLoyaltiPoints("");
      return;
    }

    // Allow only: digits + optional single decimal point
    if (!/^\d*\.?\d*$/.test(value)) {
      return;
    }

    // If value is only "." → treat as "0."
    if (value === ".") {
      setLoyaltiPoints("0.");
      return;
    }

    // Convert to number for comparison
    const numericValue = Number(value);

    if (numericValue > fullAmounttwo) {
      return;
    }

    // If exceeds max → block update
    if (numericValue > max) {
      return;
    }

    setLoyaltiPoints(value);
  };

  const hasCardPayment = useMemo(() => {
    return paymentData?.some((method) => method.category === "Card");
  }, [paymentData]);

  const calculateFinalAmount = (method) => {
    const baseAmount = fullAmountTransaction;

    const transactionFee = parseFloat(method.transaction_fee ?? 0);
    const fixedFee = parseFloat(method.transaction_fixed_fee ?? 0);

    // Case 1: commission_status = true
    if (method.commission_status) {
      const percentageFee = (fullAmountTransaction * transactionFee) / 100;
      return (baseAmount + percentageFee + fixedFee).toFixed(2);
    }

    // Default: no extra fee
    return baseAmount.toFixed(2);
  };

  console.log("buyxDiscont", discountType);
  return (
    <div
      className="tp-checkout-place white-bg rounded-4 pt-4 pb-4 h-100 shadow-sm"
      style={{ padding: "20px 40px" }}
    >
      <h3 className="tp-checkout-place-title my-2">Your Order</h3>

      <div className="tp-order-info-list mt-4">
        <ul>
          {/*  header */}
          <li className="tp-order-info-list-header mb-3 border-0 py-2">
            <h4>Product</h4>
            <h4>
              Total{" "}
              <span style={{ fontSize: "15px", fontWeight: "semibold" }}>
                ({symbol})
              </span>
            </h4>
          </li>

          {/*  item list */}
          {cart_products.map((item, index) => {
            // --- Find matching discounts ---
            const matchingProductDiscount =
              discountType === "product"
                ? productDiscount?.applicableProducts.find(
                    (d) => d.variant_id === item.variant_id,
                  )
                : null;

            const matchingBuyxDiscount =
              discountType === "buyx"
                ? buyxDiscont?.applicableProducts.find(
                    (d) => d.variant_id === item.variant_id,
                  )
                : null;

            // --- Calculate totals ---
            const originalTotal = item.price * item.orderQuantity;
            const discountAmount = matchingProductDiscount?.discount_value || 0;

            const finalTotal =
              parseFloat(originalTotal - discountAmount) < 0
                ? 0
                : parseFloat(originalTotal - discountAmount);

            return (
              <React.Fragment key={index}>
                {/* ✅ Normal product row */}
                <div
                  className=" gap-3 "
                  style={{ fontSize: "15px", marginBottom: "20px" }}
                >
                  <div className="d-flex justify-content-between gap-3 ">
                    <div>
                      {item.measurement_needed ? (
                        <p
                          style={{
                            fontSize: "15px",
                            margin: "0px 0px 2px 2px",
                            maxWidth: "260px",
                            lineHeight: "18px",
                          }}
                        >
                          {item.title}{" "}
                          <span>
                            (
                            {measurementConverter(
                              Number(item.amount_per_unit),
                              Number(item.measurement_id),
                            )}{" "}
                            <span
                              className="rounded-pill px-2"
                              style={{
                                fontSize: "12px",
                                backgroundColor: "#f0f0f0",
                              }}
                            >
                              × Qty {item.orderQuantity}
                            </span>
                            )
                          </span>
                        </p>
                      ) : (
                        <p
                          style={{
                            fontSize: "15px",
                            margin: "0px 0px 2px 2px",
                            maxWidth: "260px",
                            lineHeight: "18px",
                          }}
                        >
                          {item.title}{" "}
                          <span
                            className="rounded-pill px-2"
                            style={{
                              fontSize: "12px",
                              backgroundColor: "#f0f0f0",
                            }}
                          >
                            × Qty {item.orderQuantity}
                          </span>
                        </p>
                      )}

                      {/* Product discount line */}
                      {matchingProductDiscount && (
                        <p
                          className="badge bg-light shadow-sm rounded-pill px-2 text-success mb-2 capitalize"
                          style={{ fontSize: "13px" }}
                        >
                          {symbol}{" "}
                          {Number(originalTotal - discountAmount || 0) < 0
                            ? parseFloat(originalTotal).toFixed(2)
                            : parseFloat(discountAmount).toFixed(2)}{" "}
                          discount applied !
                        </p>
                      )}
                    </div>

                    <div className="text-end">
                      {matchingProductDiscount ? (
                        <>
                          <span
                            style={{
                              color: "#6c757d",
                              textDecoration: "line-through",
                              fontSize: "16px",
                              display: "block",
                              lineHeight: "18px",
                            }}
                          >
                            {originalTotal.toFixed(2)}
                          </span>
                          <span
                            className="fw-semibold"
                            style={{ color: "#010f1c" }}
                          >
                            {finalTotal.toFixed(2)}
                          </span>
                        </>
                      ) : (
                        <span
                          className="fw-semibold"
                          style={{ color: "#010f1c" }}
                        >
                          {originalTotal.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                  {/* ✅ Free item row (for BuyX discount) */}
                  {matchingBuyxDiscount && (
                    <div
                      className="d-flex justify-content-between gap-2 mb-1"
                      style={{
                        fontSize: "14px",
                        color: "#28a745",
                        margin: "0px 0px 18px 2px",
                      }}
                    >
                      <div>
                        <p className="mb-0" style={{ lineHeight: "15px" }}>
                          {item.title}{" "}
                          <span
                            className="rounded-pill px-2"
                            style={{
                              fontSize: "12px",
                              backgroundColor: "#f0f0f0",
                            }}
                          >
                            {item.measurement_needed ? (
                              <>
                                {item.amount_per_unit}
                                {item.measurement_value} ×{" "}
                                {Number(matchingBuyxDiscount?.free_count) || 1}
                              </>
                            ) : (
                              <>× Qty {freeQty}</>
                            )}
                          </span>{" "}
                        </p>
                      </div>

                      <div className="text-end">
                        <span className="badge bg-success text-white ms-2">
                          FREE
                        </span>
                      </div>
                    </div>
                  )}
                  <hr
                    style={{
                      width: "100%",
                      height: "1px",
                      color: "#cecece",
                      margin: "5px 2px",
                    }}
                  />
                </div>
              </React.Fragment>
            );
          })}

          {/* Promo Code*/}
          <div className="my-4 bg-light p-1 rounded">
            <p
              className="text-muted mb-1"
              style={{
                fontSize: "11px",
                marginLeft: "7px",
                marginTop: "5px",
                lineHeight: "12px",
              }}
            >
              Please enter a valid discount note.
            </p>
            <div className="d-flex gap-2 w-100">
              <div className="w-100">
                <input
                  type="text"
                  placeholder="Discount Code"
                  className="w-100 rounded-pill"
                  style={{ height: "35px" }}
                  value={discountCode}
                  onChange={(e) => setDiscountCode(e.target.value)}
                  disabled={loading || !!appliedCode}
                />
              </div>
              <div>
                {!appliedCode ? (
                  <button
                    type="button"
                    className="btn btn-lg btn-secondary rounded-pill fs-6 py-0"
                    onClick={checkDiscount}
                    disabled={loading}
                    style={{ height: "35px" }}
                  >
                    Apply
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn btn-lg btn-danger rounded-pill fs-6 py-0"
                    onClick={handleRemoveCode}
                    style={{ height: "35px" }}
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>
            <p
              className="text-danger"
              style={{
                fontSize: "11px",
                marginLeft: "5px",
                marginTop: "5px",
                lineHeight: "12px",
              }}
            >
              Applying this discount code will automatically remove any existing
              discounts.
            </p>
          </div>

          {/*  subtotal */}
          <li className="tp-order-info-list-subtotal">
            <span>Subtotal</span>
            <span>{lastSubTotal.toFixed(2)}</span>
          </li>

          {(discountType == "order" || discountType == "payment_method") &&
            !appliedCode && (
              <li className="tp-order-info-list-subtotal">
                <span>
                  {" "}
                  {
                    {
                      order: "Order Discount",
                      product: "Product Discount",
                      payment_method: "Payment Method Discount",
                    }[discountType]
                  }
                </span>
                <span>
                  ({parseFloat(totalDiscount?.discountValue).toFixed(2)})
                </span>
              </li>
            )}
          {appliedCode && (
            <li className="tp-order-info-list-subtotal">
              <span>Promo Code Discount</span>
              <span>
                -{parseFloat(totalDiscount?.discountValue).toFixed(2)}
              </span>
            </li>
          )}

          {/*  Deliver Fee */}
          <li className="tp-order-info-list-subtotal">
            <span>
              Deliver Fee {totalWeight > 0 && `(${totalWeight.toFixed(2)} kg)`}
            </span>
            <span>{parseFloat(deliverFee).toFixed(2)}</span>
          </li>
          {discountType == "shipping" && !appliedCode && (
            <li className="tp-order-info-list-subtotal">
              <span>Deliver Fee Discount</span>
              <span>
                -{parseFloat(totalDiscount?.discountValue).toFixed(2)}
              </span>
            </li>
          )}
          {/* tax */}
          {taxEnabled && (
            <li className="tp-order-info-list-subtotal">
              <span>
                {taxFields.key} ({taxFields.value}%)
              </span>
              <span>{parseFloat(totalTax).toFixed(2)}</span>
            </li>
          )}
          {selectedMethod?.commission_status && selectedMethod && (
            <li className="tp-order-info-list-subtotal">
              <span>Transaction Fee</span>
              <span>{transactionFee.toFixed(2)}</span>
            </li>
          )}

          {selectClient && selectClient?.loyalty_point > 0 && (
            <li className="tp-order-info-list-subtotal">
              <span>Loyalty Points ({selectClient?.loyalty_point})</span>
              <span style={{ maxWidth: "150px", marginLeft: "10px" }}>
                <input
                  type="text"
                  placeholder="Loyalty Points"
                  className="w-100 rounded-pill"
                  style={{ height: "35px" }}
                  value={loyaltiPoints}
                  onChange={handleChange}
                />
              </span>
            </li>
          )}

          {/* total */}
          <li className="tp-order-info-list-total mb-4">
            <span>Total</span>
            <span>{parseFloat(fullAmount).toFixed(2)}</span>
          </li>
        </ul>
      </div>

      <div className="tp-checkout-payment">
        <h6
          className="mb-4 mt-1"
          style={{ fontSize: "14px", fontWeight: "700" }}
        >
          Select Your Payment Method
        </h6>

        <div className="payment-methods-grid">
          {paymentData?.length > 0 &&
            paymentData.map((method) => {
              const isSelected = selectedMethod?.payment_method_id === method.payment_method_id;

              return (
                <div
                  key={method.payment_method_id}
                  className={`payment-item-wrapper ${isSelected ? "selected" : ""}`}
                >
                  <label
                    className="payment-card d-flex align-items-center justify-content-between w-100 mb-0"
                    htmlFor={`payment_${method.payment_method_id}`}
                  >
                    <div className="d-flex align-items-center">
                      {/* Custom Radio Circle */}
                      <div
                        className={`custom-radio-circle me-3 ${isSelected ? "active" : ""}`}
                      >
                        <div className="inner-dot"></div>
                        <input
                          {...register("payment", {
                            required: "Payment Option is required!",
                          })}
                          className="d-none" // Hide actual radio
                          type="radio"
                          name="payment"
                          id={`payment_${method.payment_method_id}`}
                          value={method.payment_method_id}
                          onClick={() => {
                            autoPaymentMethodDiscount(method.payment_method_id);
                            setSelectedMethod(method);
                          }}
                        />
                      </div>

                      {/* Logo Container */}
                      <div className="payment-logo-container me-3">
                        <Image
                          src={method.logo || ""}
                          width={32}
                          height={32}
                          alt={method.method_name}
                          style={{
                            objectFit: "contain",
                          }}
                        />
                      </div>

                      {/* Name */}
                      <span className="payment-name">
                        {method.category === "Card"
                          ? "Credit / Debit Card"
                          : method.category === "COD"
                            ? "Cash on Delivery"
                            : method.category === "Bank Transfer"
                              ? "Bank Transfer"
                              : method.method_name.charAt(0).toUpperCase() +
                                method.method_name.slice(1)}
                      </span>
                    </div>

                    {/* Amount Box */}
                    <div className="payment-amount-box text-end">
                      <span className="final-price">
                        {calculateFinalAmount(method)}
                      </span>
                      <span className="price-label">Total with fees</span>
                    </div>
                  </label>
                </div>
              );
            })}
        </div>

        <div className="mt-2">
          <ErrorMsg msg={errors?.payment?.message} />
        </div>
      </div>

      <div className="tp-checkout-btn-wrapper">
        <button
          type="submit"
          disabled={orderLoading || paymentMethodLoading}
          className="tp-checkout-btn w-100 rounded"
        >
          Place Order
        </button>

        {hasCardPayment && (
          <>
            {/* Desktop */}
            <div className="mb-3 d-none d-xl-flex align-items-center gap-2 my-2 justify-content-start">
              <a href="https://www.payhere.lk" target="_blank" rel="noreferrer">
                <img
                  src="https://www.payhere.lk/downloads/images/payhere_long_banner.png"
                  alt="PayHere"
                  width="400"
                  style={{ maxWidth: "100%" }}
                />
              </a>
            </div>

            {/* Mobile */}
            <div className="mb-3 d-flex d-xl-none align-items-center gap-2 my-2 justify-content-start">
              <a href="https://www.payhere.lk" target="_blank" rel="noreferrer">
                <img
                  src="https://www.payhere.lk/downloads/images/payhere_short_banner.png"
                  alt="PayHere"
                  width="250"
                  style={{ maxWidth: "100%" }}
                />
              </a>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CheckoutOrderArea;
