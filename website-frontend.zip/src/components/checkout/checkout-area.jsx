import React from "react";
import Link from "next/link";
// internal
import CheckoutBillingArea from "./checkout-billing-area";
import CheckoutCoupon from "./checkout-coupon";
import CheckoutLogin from "./checkout-login";
import CheckoutOrderArea from "./checkout-order-area";
import useCheckoutSubmit from "@/hooks/use-checkout-submit";

import * as dayjs from "dayjs";
import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CardElement, useElements, useStripe } from "@stripe/react-stripe-js";
import { useForm } from "react-hook-form";
import { useRouter } from "next/router";
import Cookies from "js-cookie";
//internal import
import { set_shipping } from "@/redux/features/order/orderSlice";
import { set_coupon } from "@/redux/features/coupon/couponSlice";
import { notifyError, notifySuccess } from "@/utils/toast";
import { useGetOfferCouponsQuery } from "@/redux/features/coupon/couponApi";
import useCartInfo from "@/hooks/use-cart-info";
import { useGetUserDetailsQuery } from "@/redux/features/auth/authApi";
import Swal from "sweetalert2";
import { clearCart } from "@/redux/features/cartSlice";
import { useGetSystemSettingsQuery } from "@/redux/features/brandingSettingsApi";
import { useGetAllCountryQuery } from "@/redux/features/order/orderApi";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import InfoCircle from "@/svg/info-circle";

const CheckoutArea = ({ isGuest }) => {
  //cartTotal
  const [cartTotal, setCartTotal] = useState("");

  // shippingCost
  const [deliverFee, setDeliverFee] = useState(0);

  const [taxName, setTaxName] = useState({
    name: "",
    value: 0,
  });

  const [orderLoading, setorderLoading] = useState(false);
  const [discountDetails, setDiscountDetails] = useState(null);
  const [loyaltiPoints, setLoyaltiPoints] = useState("");
  const [paymentDiscount, setPaymentDiscount] = useState(null);
  const [lastSubTotal1, setLastSubTotal1] = useState(0);
  const [fullAmount2, setfullAmount2] = useState(0);
  const [showDiscountInfo, setShowDiscountInfo] = useState(false);
  const [saveDetails, setSaveDetails] = useState(false);
  //transaction section
  const [selectedMethod, setSelectedMethod] = useState(null);
  const [transactionFee, setTransactionFee] = useState(0);
  const [isMounted, setIsMounted] = useState(false);

  const { data: systemData, isLoading: systemLoading } = useGetSystemSettingsQuery();
  const { data: countries } = useGetAllCountryQuery();

  const checkoutData = useCheckoutSubmit();
  const dispatch = useDispatch();
  const stripe = useStripe();
  const { cart_products } = useSelector((state) => state.cart);
  const { total } = useCartInfo();
  const router = useRouter();
  const symbol = useCurrencySymbol();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    setError,
    clearErrors,
    formState: { errors },
  } = useForm({
    defaultValues: {
      deliveryCountry: "162",
      country: "162",
      sameAsBilling: true,
    },
  });

  useEffect(() => {
    setIsMounted(true);
  }, []);

  let token = "";
  if (typeof window !== "undefined") {
    token = localStorage.getItem("accessToken");
  }

  const {
    data: userData,
    isLoading: userLoading,
    error,
    isError,
  } = useGetUserDetailsQuery(token, {
    skip: !token,
  });

  useEffect(() => {
    setValue("sameAsBilling", true);
  }, []);
  useEffect(() => {
    autoPaymentMethodDiscount();
  }, [cart_products]);

  useEffect(() => {
    if (userData) {
      const fields = [
        "firstName",
        "lastName",
        "country",
        "address",
        "city",
        "zipCode",
        "contactNo",
        "email",
      ];
      const dataMap = {
        firstName: userData.first_name,
        lastName: userData.last_name,
        country: userData.country ?? "162",
        address: userData.address,
        city: userData.city,
        zipCode: userData.postal_code,
        contactNo: userData.contact_number_1,
        email: userData.email,
      };
      fields.forEach((field) => setValue(field, dataMap[field]));
      setValue("deliveryCountry", userData.country ?? "162");
    }
  }, [userData, setValue]);

  useEffect(() => {
    setValue("country", userData?.country ?? 162);
    setValue("deliveryCountry", userData?.country ?? 162);
  }, [userData, countries]);

  useEffect(() => {
    const taxAmount = parseFloat(taxName?.value) || 0;
    const subTotal = parseFloat(
      (total + parseFloat(deliverFee) + taxAmount).toFixed(2),
    );
    setCartTotal(subTotal);
  }, [total, deliverFee, taxName]);

  const submitHandler = async (data) => {
    setorderLoading(true);
    if (!token && !isGuest) {
      router.push("/login");
    }

    console.log('checkoutdata', data)
    let orderInfo = {
      firstName: `${data.firstName}`,
      lastName: data.lastName,
      address: data.address,
      contact: data.contactNo,
      contact2: data.contactTwo,
      email: data.email,
      city: data.city,
      country: data.country,
      zipCode: data.zipCode ?? "",
      cart: cart_products,
      paymentMethod: data.payment,
      subTotal: total,
      deliveryfee: deliverFee,
      discount: 0,
      totalAmount: cartTotal,
      orderNote: data.orderNote,
      deliveryAddress: data.deliveryAddress,
      deliveryCity: data.deliveryCity,
      deliveryContactNo: data.deliveryContactNo,
      deliverContact2: data.deliveryContacttwo,
      deliveryCountry: data.deliveryCountry,
      deliveryEmail: data.deliveryEmail,
      deliveryFirstName: data.deliveryFirstName,
      deliveryLastName: data.deliveryLastName,
      deliveryZipCode: data.deliveryZipCode,
      sameAsBilling: data.sameAsBilling,
      isGuest: isGuest,
      taxName: taxName,
      discountDetails: discountDetails,
      loyaltiPoints: loyaltiPoints,
      saveDetails: saveDetails,
      fullAmount2: fullAmount2,
      lastSubTotal1: lastSubTotal1,
      transactionFee: transactionFee,
    };

    console.log(orderInfo);
    setorderLoading(true);
    try {
      if (token && !isGuest) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/order/addorder`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify(orderInfo),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }
        const data = await response.json();
        if (response.status === 200) {
          notifySuccess("Order placed successfully");
          dispatch(set_shipping(data));
          localStorage.setItem("cart_products", JSON.stringify([]));
          reset();
          router.push(`/order/${data.orderId}?notify=true`);
        } else {
          Swal.fire({
            icon: "error",
            title: "Order Failed",
            text: data.message,
          });
        }
        setorderLoading(false);
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/order/guestaddorder`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify(orderInfo),
          },
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }
        const data = await response.json();
        if (response.status === 200) {
          notifySuccess("Order placed successfully");
          dispatch(set_shipping(data));
          localStorage.setItem("cart_products", JSON.stringify([]));
          router.push(`/order/${data.orderId}?notify=true`);
        } else {
          Swal.fire({
            icon: "error",
            title: "Order Failed",
            text: data.message,
          });
        }
        setorderLoading(false);
      }
    } catch (error) {
      console.log(error);
      setorderLoading(false);
    }
  };

  const autoPaymentMethodDiscount = async (id) => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/discount/check-payment-method-discount`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            cart_products: cart_products,
          }),
        },
      );

      const data = await response.json();

      if (response.status === 200) {
        setPaymentDiscount(data.bestPaymentMethodDiscount);
      }
    } catch (error) {
      console.log(error);
    }
  };

  console.log("cart_products", watch("sameAsBilling"));

  if (!isMounted) return null;

  return (
    <>
      <section
        className={`tp-checkout-area pb-120 pt-40 transition-fade ${!userLoading && !systemLoading ? "is-visible" : ""}`}
        style={{ backgroundColor: "#EFF1F5", minHeight: "80vh" }}
      >
        <div className="container">
          {/* <h3
            className="breadcrumb__title mb-4 py-2"
            style={{ fontSize: "35px" }}
          >
            Checkout
          </h3> */}
          {cart_products.length === 0 && (
            <div className="text-center pt-50">
              <h3 className="py-2">No items found in cart to checkout</h3>
              <Link href="/shop" className="tp-checkout-btn rounded">
                Return to shop
              </Link>
            </div>
          )}

          {paymentDiscount?.isApplicable && (
            <div className="row fade-in-down">
              <div className="col-xl-12">
                <div
                  className="invoice_msg mb-40 alert alert-success d-flex align-items-center justify-content-between gap-3 shadow-md"
                  style={{ backgroundColor: "#12B89A" }}
                >
                  {/* LEFT CONTENT */}
                  <div className="d-flex align-items-center gap-2">
                    {/* ICON */}
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="22"
                      height="22"
                      viewBox="0 0 24 24"
                    >
                      <path
                        fill="#ffffff"
                        d="M12 22q-.6 0-1.15-.225t-.975-.65q-.725-.725-1.25-.95T7.05 19.95q-1.25 0-2.125-.875T4.05 16.95q0-1.05-.225-1.575t-.95-1.25q-.425-.425-.65-.975T2 12t.225-1.15t.65-.975q.725-.725.95-1.25T4.05 7.05q0-1.25.875-2.125T7.05 4.05q1.05 0 1.575-.225t1.25-.95q.425-.425.975-.65T12 2t1.15.225t.975.65q.725.725 1.25.95t1.575.225q1.25 0 2.125.875t.875 2.125q0 1.05.225 1.575t.95 1.25q.425.425.65.975T22 12t-.225 1.15t-.65.975q-.725.725-.95 1.25t-.225 1.575q0 1.25-.875 2.125t-2.125.875q-1.05 0-1.575.225t-1.25.95q-.425.425-.975.65T12 22"
                      />
                    </svg>

                    {/* TEXT */}
                    <div>
                      <p className="text-white mb-0 fw-semibold">
                        Save {symbol}{" "}
                        {paymentDiscount.paymentMethodDiscountAmount} Today!
                      </p>
                      <small className="text-white opacity-90">
                        Use {paymentDiscount.paymentMethodName}
                      </small>
                    </div>
                  </div>

                  {/* RIGHT ACTION */}
                  <div className="d-flex align-items-center gap-2">
                    <span className="badge bg-white text-success fw-bold px-3 py-2">
                      -{paymentDiscount.paymentMethodDiscountAmount} {symbol}
                    </span>

                    <div
                      className="position-relative d-inline-block"
                      onMouseEnter={() => setShowDiscountInfo(true)}
                      onMouseLeave={() => setShowDiscountInfo(false)}
                    >
                      {/* INFO ICON */}
                      <button className="btn btn-link p-0 border-0">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                        >
                          <path
                            fill="#dfe6ecff"
                            d="M11 9h2V7h-2m1 13c-4.41 0-8-3.59-8-8s3.59-8 8-8s8 3.59 8 8s-3.59 8-8 8m0-18A10 10 0 0 0 2 12a10 10 0 0 0 10 10a10 10 0 0 0 10-10A10 10 0 0 0 12 2m-1 15h2v-6h-2z"
                          />
                        </svg>
                      </button>

                      {/* HOVER DROPDOWN */}
                      {showDiscountInfo && paymentDiscount?.isApplicable && (
                        <ul
                          className="dropdown-menu show p-2 shadow-sm"
                          style={{
                            position: "absolute",
                            top: "100%",
                            right: 0,
                            minWidth: 280,
                            zIndex: 1000,
                            fontSize: "12px",
                            lineHeight: "1.4",
                          }}
                        >
                          <li className="fw-semibold mb-1">Offer Details</li>

                          <li className="small">
                            • Available for{" "}
                            <strong>
                              {paymentDiscount.customer_eligibility === "all"
                                ? "all customers"
                                : paymentDiscount.customer_eligibility}
                            </strong>
                          </li>

                          <li className="small">
                            •{" "}
                            {paymentDiscount.is_guest_allowed
                              ? "Guests can use this offer"
                              : "Login required to use this offer"}
                          </li>

                          <li className="small">
                            •{" "}
                            {paymentDiscount.unlimited_usage
                              ? "No usage limit"
                              : `Can be used up to ${paymentDiscount.usage_limit_per_account} time(s)`}
                          </li>

                          {paymentDiscount.min_purchase_amount && (
                            <li className="small">
                              • Minimum order value:{" "}
                              <strong>
                                LKR {paymentDiscount.min_purchase_amount}
                              </strong>
                            </li>
                          )}

                          {paymentDiscount.max_discount_amount && (
                            <li className="small">
                              • Maximum savings:{" "}
                              <strong>
                                LKR {paymentDiscount.max_discount_amount}
                              </strong>
                            </li>
                          )}

                          <li className="small">
                            •
                            {paymentDiscount.end_date
                              ? `Valid until ${new Date(paymentDiscount.end_date).toLocaleDateString()}`
                              : "No expiry date"}
                          </li>
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {cart_products.length > 0 && (
            <div className="row">
              {/* <div className="col-xl-7 col-lg-7">
                <div className="tp-checkout-verify">
                  <CheckoutLogin />
                  <CheckoutCoupon
                    handleCouponCode={handleCouponCode}
                    couponRef={couponRef}
                    couponApplyMsg={couponApplyMsg}
                  />
                </div>
              </div> */}
              <form onSubmit={handleSubmit(submitHandler)}>
                <div className="row align-items-stretch">
                  <div className="col-lg-7 ">
                    <CheckoutBillingArea
                      register={register}
                      errors={errors}
                      watch={watch}
                      setError={setError}
                      setValue={setValue}
                      clearErrors={clearErrors}
                      systemData={systemData}
                      saveDetails={saveDetails}
                      setSaveDetails={setSaveDetails}
                      countries={countries}
                    />
                  </div>
                  <div className="col-lg-5 fade-in-right">
                  <div className="sticky-top-card">
                    <CheckoutOrderArea
                      checkoutData={checkoutData}
                      register={register}
                      errors={errors}
                      watch={watch}
                      orderLoading={orderLoading}
                      systemData={systemData}
                      setDeliverFee={setDeliverFee}
                      deliverFee={deliverFee}
                      setTaxName={setTaxName}
                      isGuest={isGuest}
                      setDiscountDetails={setDiscountDetails}
                      loyaltiPoints={loyaltiPoints}
                      setLoyaltiPoints={setLoyaltiPoints}
                      selectClient={userData}
                      setfullAmount2={setfullAmount2}
                      setLastSubTotal1={setLastSubTotal1}
                      setSelectedMethod={setSelectedMethod}
                      selectedMethod={selectedMethod}
                      setTransactionFee={setTransactionFee}
                    />
                  </div>
                  </div>
                </div>
              </form>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default CheckoutArea;
