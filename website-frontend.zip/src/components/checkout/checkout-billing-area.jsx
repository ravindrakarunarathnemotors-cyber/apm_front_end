import React, { useEffect } from "react";
import ErrorMsg from "../common/error-msg";
import { useSelector } from "react-redux";
import { useGetAllCountryQuery } from "@/redux/features/order/orderApi";


const CheckoutBillingArea = ({ register, errors, watch, setError, setValue, clearErrors, systemData , saveDetails, setSaveDetails, countries }) => {
  const { user } = useSelector((state) => state.auth);

  const sameAsBilling = watch("sameAsBilling");

  useEffect(() => {
    if (!systemData) return;

    const sell_international = systemData?.sell_international;
    const country = watch("country");
    const deliveryCountry = watch("deliveryCountry");
    console.log(country)
    console.log(deliveryCountry)

    if (!sell_international) {

      if (sameAsBilling && country && country != "162") {
        setValue("sameAsBilling", false);
        setError("deliveryCountry", {
          type: "manual",
          message: "Please select Sri Lanka as the delivery country."
        });
      } else if (!sameAsBilling && deliveryCountry && deliveryCountry != "162") {
        setError("deliveryCountry", {
          type: "manual",
          message: "Please select Sri Lanka as the delivery country."
        });
      } else {
        clearErrors("deliveryCountry")
      }
    }

  }, [systemData, sameAsBilling, watch("country"), watch("deliveryCountry")]);



  return (
    <div className="tp-checkout-bill-area rounded-4 shadow-sm pt-4 pb-4">
      <h3 className="tp-checkout-bill-title my-2">Billing Details</h3>

      <div className="tp-checkout-bill-form mt-4">
        <div className="tp-checkout-bill-inner">
          <div className="row">
            <div className="col-md-6">
              <div className="tp-checkout-input">
                <label>
                  First Name <span>*</span>
                </label>
                <input
                  {...register("firstName", {
                    required: `firstName is required!`,
                  })}
                  name="firstName"
                  id="firstName"
                  type="text"
                  placeholder="First Name"
                  defaultValue={user?.firstName}
                />
                <ErrorMsg msg={errors?.firstName?.message} />
              </div>
            </div>
            <div className="col-md-6">
              <div className="tp-checkout-input">
                <label>
                  Last Name <span>*</span>
                </label>
                <input
                  {...register("lastName", {
                    required: `lastName is required!`,
                  })}
                  name="lastName"
                  id="lastName"
                  type="text"
                  placeholder="Last Name"
                />
                <ErrorMsg msg={errors?.lastName?.message} />
              </div>
            </div>
            <div className="col-md-12">
              <div className="tp-checkout-input">
                <label>Street address <span>*</span></label>
                <input
                  {...register("address", { required: `Address is required!` })}
                  name="address"
                  id="address"
                  type="text"
                  placeholder="House number and street name"
                />
                <ErrorMsg msg={errors?.address?.message} />
              </div>
            </div>

            <div className="col-md-4">
              <div className="tp-checkout-input">
                <label>Town / City <span>*</span></label>
                <input
                  {...register("city", { required: `City is required!` })}
                  name="city"
                  id="city"
                  type="text"
                  placeholder="City"
                />
                <ErrorMsg msg={errors?.city?.message} />
              </div>
            </div>
            <div className="col-md-4">
              <div className="tp-checkout-input">
                <label>Postcode ZIP</label>
                <input
                  {...register("zipCode", { required: false })}
                  name="zipCode"
                  id="zipCode"
                  type="text"
                  placeholder="Postcode ZIP"
                />
                <ErrorMsg msg={errors?.zipCode?.message} />
              </div>


            </div>
            <div className="col-md-4">
              <div className="tp-checkout-input">
                <label>
                  Country <span>*</span>
                </label>
                {/* <input
                  {...register("country", { required: `country is required!` })}
                  name="country"
                  id="country"
                  type="text"
                  placeholder="United States (US)"
                /> */}
                <select
                  className="form-select"
                  style={{ height: "50px", borderRadius: '10px' }}
                  aria-label="Default select example"
                  {...register("country", { required: "Country is required!" })}
                >
                  <option value="" className="text-muted">Select Country</option>
                  {countries?.map((country) => (
                    <option key={country.id} value={country.id}>
                      {country.country_name}
                    </option>
                  ))}
                </select>


                <ErrorMsg msg={errors?.country?.message} />
              </div>

            </div>

            <div className="col-md-6">
              <div className="tp-checkout-input">
                <label>
                  Mobile Number <span>*</span>
                </label>
                <input
                  {...register("contactNo", {
                    required: `ContactNumber is required!`,
                  })}
                  name="contactNo"
                  id="contactNo"
                  type="text"
                  placeholder="Phone"
                />
                <ErrorMsg msg={errors?.contactNo?.message} />
              </div>
            </div>
            <div className="col-md-6">
              <div className="tp-checkout-input">
                <label>
                  Contact Number
                </label>
                <input
                  {...register("contactTwo", { required: false })}
                  name="contactTwo"
                  id="contactTwo"
                  type="text"
                  placeholder="Phone"
                />
                <ErrorMsg msg={errors?.contactTwo?.message} />
              </div>
            </div>
            <div className="col-md-12">
              <div className="tp-checkout-input">
                <label>
                  Email address <span>*</span>
                </label>
                <input
                  {...register("email", { required: `Email is required!` })}
                  name="email"
                  id="email"
                  type="email"
                  placeholder="Email"
                  defaultValue={user?.email}
                />
                <ErrorMsg msg={errors?.email?.message} />
              </div>
            </div>
            <div className="col-md-12">
              <div className="tp-checkout-input">
                <label>Order notes (optional)</label>
                <textarea
                  {...register("orderNote", { required: false })}
                  name="orderNote"
                  id="orderNote"
                  placeholder="Notes about your order, e.g. special notes for delivery."
                  style={{ height: "100px" }}
                />
              </div>
            </div>

            <div className="d-flex align-items-center gap-2">
                <input
                  type="checkbox"
                  className=""
                  id="savecustomer"
                  value={saveDetails}
                  onChange={(e) => setSaveDetails(e.target.checked)}
                />
                <label className="form-check-label" htmlFor="savecustomer" style={{ fontSize: "16px", fontWeight: "500" }}>
                  Save this information for next time
                </label>
              </div>

          </div>
          <div className=" mt-4">
            <h3 className="tp-checkout-bill-title">Delivery Details</h3>

            <>
              {/* Checkbox */}
              <div className=" mb-3 d-flex align-items-center gap-2">
                <input
                  type="checkbox"
                  className=""
                  id="sameAsBilling"
                  {...register("sameAsBilling")}
                />
                <label className="form-check-label" htmlFor="sameAsBilling" style={{ fontSize: "16px", fontWeight: "500" }}>
                  Same as Billing Details
                </label>
              </div>

              {/* Delivery Section - only if unchecked */}
              {!sameAsBilling && (
                <div className="row">
                  <div className="col-md-6">
                    <div className="tp-checkout-input">
                      <label>First Name <span>*</span></label>
                      <input
                        {...register("deliveryFirstName", { required: "First Name is required!" })}
                        type="text"
                        placeholder="First Name"
                      />
                      <ErrorMsg msg={errors?.deliveryFirstName?.message} />
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="tp-checkout-input">
                      <label>Last Name <span>*</span></label>
                      <input
                        {...register("deliveryLastName", { required: "Last Name is required!" })}
                        type="text"
                        placeholder="Last Name"
                      />
                      <ErrorMsg msg={errors?.deliveryLastName?.message} />
                    </div>
                  </div>

                  <div className="col-md-12">
                    <div className="tp-checkout-input">
                      <label>Street address</label>
                      <input
                        {...register("deliveryAddress", { required: "Address is required!" })}
                        type="text"
                        placeholder="House number and street name"
                      />
                      <ErrorMsg msg={errors?.deliveryAddress?.message} />
                    </div>
                  </div>



                  <div className="col-md-4">
                    <div className="tp-checkout-input">
                      <label>Town / City</label>
                      <input
                        {...register("deliveryCity", { required: "City is required!" })}
                        type="text"
                        placeholder="City"
                      />
                      <ErrorMsg msg={errors?.deliveryCity?.message} />
                    </div>
                  </div>

                  <div className="col-md-4">
                    <div className="tp-checkout-input">
                      <label>Postcode ZIP</label>
                      <input
                        {...register("deliveryZipCode", { required: false })}
                        type="text"
                        placeholder="ZIP Code"
                      />
                      <ErrorMsg msg={errors?.deliveryZipCode?.message} />
                    </div>
                  </div>


                  <div className="col-md-4">
                    <div className="tp-checkout-input">
                      <label>Country <span>*</span></label>
                      {/* <input
                        {...register("deliveryCountry", { required: "Country is required!" })}
                        type="text"
                        placeholder="Country"
                      /> */}
                      <select
                        className="form-select form-select-lg"
                        aria-label="Default select example"
                        style={{ height: "50px", borderRadius: '10px' }}
                        defaultValue=""
                        {...register("deliveryCountry", { required: "Country is required!" })}
                      >
                        <option value="">Select Country</option>
                        {countries?.map((country) => (
                          <option key={country.id} value={country.id}>
                            {country.country_name}
                          </option>
                        ))}
                      </select>

                      <ErrorMsg msg={errors?.deliveryCountry?.message} />
                    </div>
                  </div>


                  <div className="col-md-6">
                    <div className="tp-checkout-input">
                      <label>Mobile Number <span>*</span></label>
                      <input
                        {...register("deliveryContactNo", { required: "Phone is required!" })}
                        type="text"
                        placeholder="Phone"
                      />
                      <ErrorMsg msg={errors?.deliveryContactNo?.message} />
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="tp-checkout-input">
                      <label>Contact Number</label>
                      <input
                        {...register("deliveryContacttwo", { required: false })}
                        type="text"
                        placeholder="Phone"
                      />
                      <ErrorMsg msg={errors?.deliveryContacttwo?.message} />
                    </div>
                  </div>

                  <div className="col-md-12">
                    <div className="tp-checkout-input">
                      <label>Email <span></span></label>
                      <input
                        {...register("deliveryEmail", { required: false })}
                        type="email"
                        placeholder="Email"
                      />
                      <ErrorMsg msg={errors?.deliveryEmail?.message} />
                    </div>
                  </div>
                </div>
              )}
            </>


          </div>

        </div>
      </div>
    </div>
  );
};

export default CheckoutBillingArea;
