import WhatsappShare from "@/lib/whatsapp-share";
import React, { useEffect } from "react";

function WhatsappShareCom({ whatsappNumber }) {
  useEffect(() => {
    WhatsappShare(".whatsapp-floating", whatsappNumber); // <-- your number
  }, []);

  return (
    <div className="whatsapp-floating" >
      <a className="whatsapp-floating-button">
        <i className="fa-brands fa-whatsapp"></i>
      </a>
    </div>
  );
}

export default WhatsappShareCom;
