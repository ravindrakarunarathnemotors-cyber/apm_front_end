"use client";

import { useRouter } from "next/navigation";
import { Icon } from "@iconify/react";

export default function ProductNotFound() {
  const router = useRouter();

  return (
    <div
      className="d-flex flex-column align-items-center justify-content-center text-center"
      style={{ minHeight: "60vh" }}
    >
      <img
        src="/assets/animation/EmptyState.gif"
        alt="No Products"
        style={{ width: 300, marginBottom: 16 }}
      />

      <h4 className="fw-semibold mb-1">Product not available</h4>

      <p className="text-muted mb-4" style={{ maxWidth: 360 }}>
        This product is currently unavailable or no longer exists.
      </p>

      <div className="d-flex gap-2">
        <button
          type="button"
          class="btn btn-primary"
          onClick={() => router.push("/shop")}
        >
          Continue Shopping
        </button>
      </div>
    </div>
  );
}
