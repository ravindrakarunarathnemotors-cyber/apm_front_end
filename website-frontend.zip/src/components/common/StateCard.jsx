export default function StateCard({ title, subtitle, actionLabel, onAction, tone = "neutral" }) {
  return (
    <>
      <div className={`state-card ${tone}`}>
        <div className="content">
          <h3>{title}</h3>
          <p>{subtitle}</p>
          {actionLabel && (
            <button className="action-btn" onClick={onAction} aria-label={actionLabel}>
              {actionLabel}
            </button>
          )}
        </div>
      </div>
      <style jsx>{`
        .state-card {
          width: min(980px, 92vw);
          margin: 32px auto 40px;
          padding: 28px 24px;
          border-radius: 16px;
          border: 1px solid rgba(0,0,0,0.08);
          background: #fff;
          box-shadow: 0 6px 28px rgba(0,0,0,0.06);
        }
        .state-card.danger { border-color: #fecaca; background: #fff1f2; }
        .content h3 { margin: 0 0 6px; font-size: clamp(18px,2.4vw,22px); font-weight: 600; }
        .content p { margin: 0 0 16px; color: rgba(0,0,0,0.6); }
        .action-btn {
          padding: 10px 16px; border: 0; border-radius: 12px; font-weight: 600; cursor: pointer;
          background: linear-gradient(90deg, #7c3aed, #22d3ee); color: #fff;
          transition: transform .15s ease, box-shadow .15s ease;
        }
        .action-btn:hover { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(124,58,237,.25); }
      `}</style>
    </>
  );
}
