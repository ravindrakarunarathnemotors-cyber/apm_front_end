'use client'

import { useEffect, useState } from 'react'

const TawkTo = ({ embedUrl, enabled }) => {
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    /* =============================
       🔴 HARD DISABLE (WHEN OFF)
    ============================== */
    if (!enabled) {
      setLoaded(false)

      // Hide widget
      if (window.Tawk_API?.hideWidget) {
        window.Tawk_API.hideWidget()
      }

      // Remove iframe if exists
      const iframe = document.querySelector('iframe[src*="tawk.to"]')
      if (iframe) iframe.remove()

      // Remove script
      const script = document.querySelector(
        'script[src*="embed.tawk.to"]'
      )
      if (script) script.remove()

      // Kill API completely
      delete window.Tawk_API
      delete window.Tawk_LoadStart

      return
    }

    /* =============================
       🟢 ENABLE & LOAD
    ============================== */

    window.Tawk_API = window.Tawk_API || {}
    window.Tawk_LoadStart = new Date()

    window.Tawk_API.onLoad = function () {
      window.Tawk_API.hideWidget()

      setTimeout(() => {
        setLoaded(true)
        window.Tawk_API.showWidget()
      }, 200)
    }

    // Already loaded
    if (document.querySelector('script[src*="embed.tawk.to"]')) {
      setLoaded(true)
      window.Tawk_API.showWidget()
      return
    }

    // Load script
    const script = document.createElement('script')
    script.async = true
    script.src = embedUrl
    script.charset = 'UTF-8'
    script.setAttribute('crossorigin', '*')

    document.body.appendChild(script)
  }, [enabled, embedUrl])

  /* =============================
     🟡 SKELETON 
  ============================== */
  if (!enabled) return null

  return (
    <div className={`tawk-skeleton ${loaded ? 'hide' : ''}`} />
  )
}

export default TawkTo
