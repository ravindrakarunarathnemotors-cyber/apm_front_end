import BackToTop from "@/lib/back-to-top";
import React, { useEffect } from "react";

function BackToTopCom() {
  useEffect(() => {
    BackToTop(".back-to-top-wrapper");
  }, []);

  return (
    <div className="back-to-top-wrapper" >
      <button id="back_to_top" type="button" className="back-to-top-btn">
        <i className="fa-solid fa-angle-up"></i>
      </button>
    </div>
  );
}

export default BackToTopCom;
