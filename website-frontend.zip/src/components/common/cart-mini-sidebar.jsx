import React, { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import { useRouter } from "next/router";
// internal
import useCartInfo from "@/hooks/use-cart-info";
import RenderCartProgress from "./render-cart-progress";
import empty_cart_img from "@assets/img/product/cartmini/empty-cart.png";
import { closeCartMini, remove_product } from "@/redux/features/cartSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { slugify } from "@/lib/slugify";

const CartMiniSidebar = () => {
  const [discountType, setDiscountType] = useState("none");
  const [orderDiscount, setOrderDiscount] = useState(null);
  const [productDiscount, setProductDiscount] = useState(null);
  const [buyxDiscont, setBuyxDiscont] = useState(null);

  const { cart_products, cartMiniOpen } = useSelector((state) => state.cart);
  const { total } = useCartInfo();
  let token = "";
  if (typeof window !== "undefined") {
    token = localStorage.getItem("accessToken");
  }

  const dispatch = useDispatch();
  const router = useRouter();

  const symbol = useCurrencySymbol();

  // handle remove product
  const handleRemovePrd = (prd) => {
    dispatch(remove_product(prd));
  };

  // handle close cart mini
  const handleCloseCartMini = () => {
    dispatch(closeCartMini());
  };

  useEffect(() => {
    if (cart_products.length === 0) return;

    const timer = setTimeout(() => {
      autoDiscount();
      autoBuyxDiscount();
    }, 1000); // 10 seconds

    return () => clearTimeout(timer); // cancel previous timer before setting a new one
  }, [cart_products]);

  const totalDiscount = useMemo(() => {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };

    const orderValue = num(orderDiscount?.discount_value);
    const buyxValue = num(buyxDiscont?.total_discount_value);
    const productValue = num(productDiscount?.total_discount_value);

    const discountValue = Math.max(orderValue, buyxValue, productValue, 0);

    return {
      discountValue,
      productValue,
      buyxValue,
    };
  }, [orderDiscount, productDiscount, buyxDiscont]);

  useEffect(() => {
    const { discountValue, orderValue, productValue, buyxValue } =
      totalDiscount;

    if (discountValue === 0) {
      setDiscountType("none");
      return;
    }

    if (discountValue === productValue) return setDiscountType("product");
    if (discountValue === buyxValue) return setDiscountType("buyx");
  }, [totalDiscount, discountType]);

  const autoDiscount = async () => {
    try {
      if (token) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };
  const autoBuyxDiscount = async () => {
    try {
      if (token) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const cartTotal = useMemo(() => {
    const totalValue = parseFloat(total) || 0;
    const discountValue =
      parseFloat(productDiscount?.total_discount_value) || 0;

    return discountType === "product" ? totalValue - discountValue : totalValue;
  }, [discountType, total, productDiscount?.total_discount_value]);

  return (
    <>
      <div
        className={`cartmini__area tp-all-font-roboto ${cartMiniOpen ? "cartmini-opened" : ""
          }`}
      >
        <div className="cartmini__wrapper d-flex justify-content-between flex-column">
          <div className="cartmini__top-wrapper">
            <div className="cartmini__top p-relative">
              <div className="cartmini__top-title">
                <h4>Shopping cart</h4>
              </div>
              <div className="cartmini__close">
                <button
                  onClick={() => dispatch(closeCartMini())}
                  type="button"
                  className="cartmini__close-btn cartmini-close-btn"
                >
                  <i className="fal fa-times"></i>
                </button>
              </div>
            </div>
            <div className="cartmini__shipping">
              <RenderCartProgress />
            </div>
            {cart_products.length > 0 && (
              <div className="cartmini__widget">
                {cart_products.map((item, index) => {
                  // --- Find matching discounts ---
                  const matchingProductDiscount =
                    discountType === "product"
                      ? productDiscount?.applicableProducts?.find(
                        (d) => d.variant_id == item.variant_id
                      )
                      : null;

                  const matchingBuyxDiscount =
                    discountType === "buyx"
                      ? buyxDiscont?.applicableProducts?.find(
                        (d) => d.variant_id == item.variant_id
                      )
                      : null;

                  const hasDiscount = !!(
                    matchingProductDiscount || matchingBuyxDiscount
                  );

                  // --- Calculate totals ---
                  const originalTotal =
                    parseFloat(item.price) * item.orderQuantity;
                  const discountAmount =
                    matchingProductDiscount?.discount_value || 0;
                  const finalTotal = parseFloat(originalTotal - discountAmount) < 0 ? 0 : parseFloat(originalTotal - discountAmount);
                  return (
                    <div
                      key={index}
                      style={{
                        padding: "20px 0",
                        borderBottom: "1px solid rgba(129,129,129,0.2)",
                      }}
                    >
                      <div className="cartmini__widget-item px-1">
                        <div className="cartmini__thumb border-0">
                          <Link
                            href={`/product/${slugify(item.title)}-${item.product_id
                              }`}
                          >
                            <Image
                              src={
                                item.media_url ||
                                "/assets/img/shop/product-default.jpg"
                              }
                              width={70}
                              height={60}
                              alt="product img"
                              className="cartmini__img shadow-sm rounded-3"
                            />
                          </Link>
                        </div>
                        <div className=" d-flex gap-1 w-100">
                          <div className="flex-grow-1">
                            {/* title & delete btn */}
                            <div className="d-flex align-items-start justify-content-between mb-1 gap-1">
                              <h5
                                className="cartmini__title"
                                style={{
                                  marginBottom: "1px",
                                  fontSize: "14px",
                                }}
                              >
                                <Link
                                  href={`/product/${slugify(item.title)}-${item.product_id
                                    }`}
                                >
                                  {item.title}
                                </Link>
                              </h5>
                              <a
                                onClick={() => handleRemovePrd(item)}
                                className="cursor-pointer"
                              >
                                <i
                                  class="fa-solid fa-trash-can"
                                  style={{ color: "#ff3d3d" }}
                                ></i>
                              </a>
                            </div>

                            {/* variant  */}
                            {item.variant_value !== "Default" && (
                              <div
                                style={{
                                  marginBottom: "1px",
                                  margin: "0px",
                                  padding: "0px",
                                  fontSize: "13px",
                                }}
                              >
                                {item.variant_value}
                              </div>
                            )}

                            {/* messurement */}
                            {item.measurement_needed ? (
                              <div className="d-flex align-items-end justify-content-between">
                                <div className="lh-0">
                                  <div
                                    className="cartmini__quantity pb-0 "
                                    style={{ lineHeight: "15px" }}
                                  >
                                    <span style={{ paddingRight: "2px" }}>
                                      {item.amount_per_unit}
                                    </span>
                                    {item.measurement_value} x{" "}
                                    {item.orderQuantity}
                                  </div>
                                  <div
                                    className="cartmini__quantity pb-0 mb-0 lh-0"
                                    style={{ lineHeight: "15px" }}
                                  >
                                    {item.price}
                                  </div>
                                </div>
                                <div
                                  className="cartmini__price-wrapper d-flex justify-content-between "
                                  style={{
                                    marginTop: "0px",
                                    paddingBottom: "0px",
                                    lineHeight: "2px",
                                  }}
                                >
                                  {/* {item.discount > 0 ? <span className="cartmini__price">${(Number(item.price) - (Number(item.price) * Number(item.discount)) / 100).toFixed(2)}</span> : <span className="cartmini__price">${item.price.toFixed(2)}</span>} */}

                                  <div
                                    className="cartmini__quantity"
                                    style={{ fontSize: "15px" }}
                                  >
                                    <div>
                                      {matchingProductDiscount ? (
                                        <>
                                          <img
                                            src="/assets/img/discount.png"
                                            alt="offer-icon"
                                            style={{
                                              width: "70px",
                                              position: "absolute",
                                              top: "-8px",
                                              left: "-4px",
                                            }}
                                          />
                                          <div
                                            className="d-flex flex-column gap-2 justify-content-end text-end pb-0"
                                            style={{ lineHeight: "5px" }}
                                          >
                                            <span
                                              style={{
                                                fontSize: "11px",
                                                color: "#6c757d",
                                                marginBottom: "2px",
                                                textDecoration: "line-through",
                                              }}
                                            >
                                              {originalTotal.toFixed(2)}
                                            </span>
                                            <div className="d-flex align-items-end gap-1">
                                              <span
                                                style={{ fontSize: "10px" }}
                                              >
                                                {symbol}
                                              </span>
                                              <span>{finalTotal.toFixed(2)}{" "}</span>
                                            </div>
                                          </div>
                                        </>
                                      ) : (
                                        <div>
                                          <span style={{ fontSize: "10px" }}>
                                            {symbol}{" "}
                                          </span>
                                          {originalTotal.toFixed(2)}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div className="cartmini__price-wrapper d-flex justify-content-between">
                                {/* {item.discount > 0 ? <span className="cartmini__price">${(Number(item.price) - (Number(item.price) * Number(item.discount)) / 100).toFixed(2)}</span> : <span className="cartmini__price">${item.price.toFixed(2)}</span>} */}
                                <span className="cartmini__quantity gap-2">
                                  {item.price} x {item.orderQuantity}
                                </span>
                                <span
                                  className="cartmini__quantity gap-1"
                                  style={{ fontSize: "15px" }}
                                >
                                  <div>


                                    {matchingProductDiscount ? (
                                      <>
                                        {/* <img
                                          src="/assets/img/discount.png"
                                          alt="offer-icon"
                                          style={{
                                            width: "70px",
                                            position: "absolute",
                                            top: "-8px",
                                            left: "-4px",
                                          }}
                                        /> */}
                                        <div
                                          className="d-flex flex-column gap-2 justify-content-end text-end pb-0"
                                          style={{ lineHeight: "5px" }}
                                        >
                                          <span
                                            style={{
                                              fontSize: "11px",
                                              color: "#6c757d",
                                              marginBottom: "2px",
                                              textDecoration: "line-through",
                                            }}
                                          >
                                            {originalTotal.toFixed(2)}
                                          </span>
                                          <div className="d-flex align-items-end gap-1">
                                            <span
                                              style={{ fontSize: "10px" }}
                                            >
                                              {symbol}
                                            </span>
                                            <span>{finalTotal.toFixed(2)}{" "}</span>
                                          </div>
                                        </div>
                                      </>
                                    ) : (
                                      <div>
                                        <span style={{ fontSize: "10px" }}>
                                          {symbol}{" "}
                                        </span>
                                        {originalTotal.toFixed(2)}
                                      </div>
                                    )}
                                  </div>
                                </span>
                              </div>
                            )}
                            {hasDiscount && (
                              <img
                                src="/assets/img/discount.png"
                                alt="offer-icon"
                                style={{
                                  width: "70px",
                                  position: "absolute",
                                  top: "-8px",
                                  left: "-4px",
                                }}
                              />
                            )}
                          </div>
                        </div>
                      </div>
                      {/* {matchingProductDiscount && (
                        <p
                          className="text-success mt-2 mb-0 bg-light rounded-pill ps-2 capitalize"
                          style={{ fontSize: "11px" }}
                        >
                          −{symbol}
                          {discountAmount.toFixed(2)} discount applied
                        </p>
                      )} */}
                      {matchingBuyxDiscount && (
                        <div
                          className="text-success"
                          style={{ paddingTop: "4px" }}
                        >
                          <small>
                            🎁 You get{" "}
                            <strong>
                              {matchingBuyxDiscount.free_count || 1}
                            </strong>{" "}
                            free item(s) of
                            <strong> {item.title}</strong> with this offer.
                          </small>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {/* if no item in cart */}
            {cart_products.length === 0 && (
              <div className="cartmini__empty text-center">
                <Image src={empty_cart_img} alt="empty-cart-img" />
                <p>Your Cart is empty</p>
                <Link href="/shop" className="tp-btn rounded">
                  Go to Shop
                </Link>
              </div>
            )}
          </div>
          <div className="cartmini__checkout">
            <div className="cartmini__checkout-title mb-30">
              <h4>Subtotal:</h4>
              <span>
                {symbol}
                {cartTotal.toFixed(2)}
              </span>
            </div>
            <div className="cartmini__checkout-btn">
              <Link
                href="/cart"
                onClick={handleCloseCartMini}
                className="tp-btn mb-10 w-100"
              >
                {" "}
                view cart
              </Link>
              <Link
                href="/checkout"
                onClick={handleCloseCartMini}
                className="tp-btn tp-btn-border w-100"
              >
                {" "}
                checkout
              </Link>
            </div>
          </div>
        </div>
      </div>
      {/* overlay start */}
      <div
        onClick={handleCloseCartMini}
        className={`body-overlay ${cartMiniOpen ? "opened" : ""}`}
      ></div>
      {/* overlay end */}
    </>
  );
};

export default CartMiniSidebar;
