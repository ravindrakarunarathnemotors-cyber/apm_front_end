"use client";
import Image from "next/image";
import React, { useMemo } from "react";

const VIDEO_EXTS = /\.(mp4|m4v|webm|ogg|ogv|mov|mkv)(\?.*)?$/i;
const isVideoUrl = (u) => typeof u === "string" && VIDEO_EXTS.test(u || "");

const mimeFromUrl = (u = "") => {
  const ext = (u.split("?")[0] || "").split(".").pop()?.toLowerCase();
  switch (ext) {
    case "mp4":
    case "m4v": return "video/mp4";
    case "webm": return "video/webm";
    case "ogg":
    case "ogv":  return "video/ogg";
    case "mov":  return "video/quicktime";
    case "mkv":  return "video/x-matroska";
    default:     return undefined;
  }
};

/**
 * MediaThumb – drop-in replacement for <Image> in cards/lists.
 * If `src` looks like a video, renders <video> with autoplay/muted/loop.
 */
const MediaThumb = ({
  src,
  alt = "",
  width = 300,
  height = 300,
  className,
  style,
  // Optional: keep animating poster or not for video thumbs
  autoplay = true,
  poster, // optional static poster frame
}) => {
  const isVideo = isVideoUrl(src);
  const commonStyle = useMemo(
    () => ({
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block",
      borderRadius: "12px",
      ...style,
    }),
    [style]
  );

  if (isVideo) {
    const type = mimeFromUrl(src);
    return (
      <video
        className={className}
        style={commonStyle}
        muted
        playsInline
        loop
        autoPlay={autoplay}
        controls={false}
        preload="metadata"
        // don’t set crossOrigin unless your host sends CORS headers
        poster={poster}
        onError={() => {/* ignore thumbnail errors */}}
      >
        <source src={src} type={type} />
      </video>
    );
  }

  return (
    <Image
      src={src || "/assets/img/shop/product-default.jpg"}
      alt={alt}
      width={width}
      height={height}
      className={className}
      style={commonStyle}
    />
  );
};

export default MediaThumb;
