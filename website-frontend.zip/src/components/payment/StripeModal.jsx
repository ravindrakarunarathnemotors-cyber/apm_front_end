'use client'

import React, { useEffect, useState } from 'react'
import Modal from 'react-modal'
import {
    useStripe,
    useElements,
    PaymentElement,
    Elements,
} from '@stripe/react-stripe-js'
import { useCreatePaymentIntentMutation } from '@/redux/features/order/orderApi'
import { loadStripe } from '@stripe/stripe-js'
import Swal from "sweetalert2";
import { notifySuccess } from "@/utils/toast";

// const stripePromise = loadStripe("pk_test_51Rq7SQ1tDQQWe3JTCeWi9Vx0SiHSCTZEHYczj9EcD4ayTrc2HaQ9V5td7d9x8JYpPVpO3mfCfGnZibskFQp8WySH00DPJzE6NJ")

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        height: 'auto',
        maxWidth: '400px',
        width: '100%',
    },
}

const CheckoutForm = ({ clientSecret, onClose, order_id }) => {
    const stripe = useStripe()
    const elements = useElements()

    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)
    const [success, setSuccess] = useState(false)


    let token = ''
    if (typeof window !== 'undefined') {
        token = localStorage.getItem('accessToken')
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!stripe || !elements) return

        setLoading(true)
        const result = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: window.location.origin, // not used for modal, but required
            },
            redirect: 'if_required',
        })
        console.log(result)
        const pi = result.paymentIntent;
        if (result.error) {
            setError(result.error.message)
        } else if (pi?.status === 'succeeded') {
            console.log(result)
            handlePaidinvoice(pi?.id)
            setSuccess(result)
            setError(null)
            setTimeout(() => {
                onClose()
            }, 2000)
        }

        setLoading(false)
    }

    const handlePaidinvoice = async (id) => {
        try {

            const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/order/stripepaid`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    order_id: order_id,
                    payment_intent_id: id,
                }),
            });

            if (response.status === 401 || response.status === 403) {
                localStorage.removeItem('accessToken');
                router.push('/login');
            }
            const data = await response.json();
            if (response.status === 200) {
                notifySuccess("Payment successful");
                setTimeout(() => {
                    window.location.reload()
                }, 2000)
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Payment Failed",
                    text: "Payment failed. Please contact support.",
                })
            }
        } catch (error) {
            console.log(error)
        }
    }

    return (
        <form onSubmit={handleSubmit}>
            <PaymentElement />
            {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
            {success && <p style={{ color: 'green', marginTop: '10px' }}>✅ Payment Successful</p>}
            <button
                type="submit"
                disabled={loading || !stripe}
                style={{
                    marginTop: '1rem',
                    padding: '10px 20px',
                    backgroundColor: '#6772e5',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '4px',
                    width: '100%',
                }}
            >
                {loading ? 'Processing...' : 'Pay Now'}
            </button>
        </form>
    )
}

const StripeModal = ({ show, onClose, amount, order_id }) => {
    const [clientSecret, setClientSecret] = useState(null)
    const [stripePromise, setStripePromise] = useState(null);
    const [createPaymentIntent] = useCreatePaymentIntentMutation()

    useEffect(() => {
        if (show) {
            createPaymentIntent({
                amount: parseInt(amount),
                order_id: order_id
            })
                .then((res) => {
                    const secret = res?.data?.clientSecret
                    const publishableKey = res?.data?.publishableKey
                    setClientSecret(secret)
                    setStripePromise(loadStripe(publishableKey))
                })
                .catch((err) => {
                    console.error('Stripe error:', err)
                })
        }
    }, [show])

    return (
        <Modal
            isOpen={show}
            onRequestClose={onClose}
            contentLabel="Stripe Payment"
            style={customStyles}
        >
            <h3 style={{ marginBottom: '1rem' }}>Pay with Card</h3>

            {clientSecret ? (
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <CheckoutForm clientSecret={clientSecret} onClose={onClose} order_id={order_id} />
                </Elements>
            ) : (
                <p>Loading payment form...</p>
            )}

            <button
                onClick={onClose}
                style={{
                    marginTop: '1rem',
                    padding: '6px 12px',
                    backgroundColor: '#ccc',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    width: '100%',
                }}
            >
                Cancel
            </button>
        </Modal>
    )
}

export default StripeModal
