'use client'

import React, { useEffect, useState } from 'react'
import Modal from 'react-modal'

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        height: 'auto',
        maxWidth: '400px',
        width: '100%',
        padding: '0px',
        borderRadius: "6px",
    },
}
const BankDetails = ({ show, onClose, details }) => {

    const [bankDetails, setBankDetails] = useState({})

    useEffect(() => {
        if (!details) {
            setBankDetails({});
            return;
        }
        const cleaned = details.replace(/[{}"]/g, '');
        const pairs = cleaned.split(',');
        const detailsObj = {};
        pairs.forEach(pair => {
            const [key, value] = pair.split(':');
            if (key && value) {
                detailsObj[key.trim()] = value.trim();
            }
        });
        setBankDetails(detailsObj);
    }, [details]);

    console.log(bankDetails)
    return (
        <Modal
            isOpen={show}
            onRequestClose={onClose}
            contentLabel="Bank Details"
            style={customStyles}
            
        >
            <div style={{ padding: "0px", padding: "0",  }}>
                {/* Title with background */}
                <h4
                    className="mb-0"
                    style={{
                        fontWeight: "600",
                        color: "#fff",
                        backgroundColor: "#4a90e2", // soft blue (you can change to match theme)
                        padding: "0.5rem 1rem",
                        borderTopLeftRadius: "6px",
                        borderTopRightRadius: "6px",
                    }}
                >
                    Bank Details
                </h4>

                <div
                    style={{
                        
                        padding: "1rem 1.5rem",
                        backgroundColor: "#f9f9f9",
                        fontSize: "15px",
                        lineHeight: "1.6",
                    }}
                >
                    {/* Details (single line) */}
                    <div style={{ whiteSpace: "pre-line", marginBottom: "0.75rem"  }}>
                        <strong>{bankDetails.details}</strong>
                    </div>

                    {/* Notes (multi-line) */}
                    <div style={{ whiteSpace: "pre-line" }}>
                        {bankDetails.notes}
                    </div>
                </div>
            </div>
        </Modal>


    )
}

export default BankDetails