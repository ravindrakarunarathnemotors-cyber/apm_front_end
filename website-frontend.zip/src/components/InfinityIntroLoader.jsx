'use client';
import React, { useEffect, useState } from 'react';

const InfinityIntroLoader = ({ show = true }) => {
  const [isChrome, setIsChrome] = useState(false);

  useEffect(() => {
    if (typeof navigator !== 'undefined') {
      const chrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
      setIsChrome(chrome);
    }
  }, []);

  return (
    <>
      <div className={`intro-loader ${show ? 'show' : 'hide'}`} aria-hidden={!show}>
        {/* Chrome path-based version */}
        <div className="infinityChrome" style={{ display: isChrome ? 'block' : 'none' }}>
          <div></div><div></div><div></div>
        </div>

        {/* Fallback for Safari/others */}
        <div className="infinity" style={{ display: isChrome ? 'none' : 'block' }}>
          <div><span></span></div>
          <div><span></span></div>
          <div><span></span></div>
        </div>

        {/* SVG filter (goo) */}
        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" style={{ display: 'none' }}>
          <defs>
            <filter id="goo">
              <feGaussianBlur in="SourceGraphic" stdDeviation="6" result="blur" />
              <feColorMatrix in="blur" mode="matrix"
                values="
                  1 0 0 0 0
                  0 1 0 0 0
                  0 0 1 0 0
                  0 0 0 18 -7" result="goo" />
              <feBlend in="SourceGraphic" in2="goo" />
            </filter>
          </defs>
        </svg>
      </div>

      <style jsx global>{`
        :root {
          --c: #8C6FF0;
          --cr: #5628EE;
          --cl: #23C4F8;
        }

        /* Overlay */
        .intro-loader {
          position: fixed;
          inset: 0;
          background: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9998; /* keep your top-progress at 9999 */
          opacity: 0;
          pointer-events: none;
          width: 100%;
          height: 100%;
          overflow: hidden;
          transition: opacity .45s ease;
        }
        .intro-loader.show { opacity: 1; pointer-events: all; }
        .intro-loader.hide { opacity: 0; pointer-events: none; }

        /* Fallback infinity (no offset-path) */
        .infinity {
          width: 120px; height: 60px; position: relative;
        }
        .infinity div, .infinity span { position: absolute; }
        .infinity div {
          top: 0; left: 50%; width: 60px; height: 60px;
          animation: rotate 6.9s linear infinite;
        }
        .infinity div span {
          left: -8px; top: 50%; margin: -8px 0 0 0;
          width: 16px; height: 16px; display: block; background: var(--c);
          box-shadow: 2px 2px 8px rgba(140,111,240,0.09);
          border-radius: 50%; transform: rotate(90deg);
          animation: move 6.9s linear infinite;
        }
        .infinity div span:before, .infinity div span:after {
          content: ''; position: absolute; display: block; border-radius: 50%;
          width: 14px; height: 14px; background: inherit; top: 50%; left: 50%;
          margin: -7px 0 0 -7px; box-shadow: inherit;
        }
        .infinity div span:before { animation: drop1 .8s linear infinite; }
        .infinity div span:after  { animation: drop2 .8s linear infinite .4s; }
        .infinity div:nth-child(2) { animation-delay: -2.3s; }
        .infinity div:nth-child(2) span { animation-delay: -2.3s; }
        .infinity div:nth-child(3) { animation-delay: -4.6s; }
        .infinity div:nth-child(3) span { animation-delay: -4.6s; }

        /* Chrome path-based version */
        .infinityChrome { width: 128px; height: 60px; position: relative; }
        .infinityChrome > div {
          position: absolute; width: 16px; height: 16px; background: var(--c);
          box-shadow: 2px 2px 8px rgba(140,111,240,0.09);
          border-radius: 50%; animation: moveSvg 6.9s linear infinite;
          -webkit-filter: url(#goo); filter: url(#goo);
          transform: scaleX(-1);
          offset-path: path("M64.3636364,29.4064278 C77.8909091,43.5203348 84.4363636,56 98.5454545,56 C112.654545,56 124,44.4117395 124,30.0006975 C124,15.5896556 112.654545,3.85282763 98.5454545,4.00139508 C84.4363636,4.14996252 79.2,14.6982509 66.4,29.4064278 C53.4545455,42.4803627 43.5636364,56 29.4545455,56 C15.3454545,56 4,44.4117395 4,30.0006975 C4,15.5896556 15.3454545,4.00139508 29.4545455,4.00139508 C43.5636364,4.00139508 53.1636364,17.8181672 64.3636364,29.4064278 Z");
        }
        .infinityChrome > div:before, .infinityChrome > div:after {
          content: ''; position: absolute; display: block; border-radius: 50%;
          width: 14px; height: 14px; background: inherit; top: 50%; left: 50%;
          margin: -7px 0 0 -7px; box-shadow: inherit;
        }
        .infinityChrome > div:before { animation: drop1 .8s linear infinite; }
        .infinityChrome > div:after  { animation: drop2 .8s linear infinite .4s; }
        .infinityChrome > div:nth-child(2) { animation-delay: -2.3s; }
        .infinityChrome > div:nth-child(3) { animation-delay: -4.6s; }

        @keyframes moveSvg {
          0% { offset-distance: 0%; }
          25% { background: var(--cr); }
          75% { background: var(--cl); }
          100% { offset-distance: 100%; }
        }
        @keyframes rotate {
          50% { transform: rotate(360deg); margin-left: 0; }
          50.0001%, 100% { margin-left: -60px; }
        }
        @keyframes move {
          0%,50% { left: -8px; }
          25% { background: var(--cr); }
          75% { background: var(--cl); }
          50.0001%,100% { left: auto; right: -8px; }
        }
        @keyframes drop1 { 100% { transform: translate(32px, 8px) scale(0); } }
        @keyframes drop2 {
          0% { transform: translate(0, 0) scale(.9); }
          100% { transform: translate(32px, -8px) scale(0); }
        }
      `}</style>
    </>
  );
};

export default InfinityIntroLoader;
