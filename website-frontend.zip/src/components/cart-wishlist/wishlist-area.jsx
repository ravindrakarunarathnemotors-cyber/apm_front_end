import React from "react";
import Link from "next/link";
import { useSelector } from "react-redux";
import WishlistItem from "./wishlist-item";

const WishlistArea = () => {
  const { wishlist } = useSelector((state) => state.wishlist);
  console.log("first", wishlist);
  return (
    <>
      <section className="tp-cart-area pb-120">
        <div className="container">
          {wishlist.length === 0 && (
            <div className="text-center pt-50">
              <h3>No Wishlist Items Found</h3>
              <Link href="/shop" className="tp-cart-checkout-btn mt-20">
                Continue Shopping
              </Link>
            </div>
          )}
          {wishlist.length > 0 && (
            <div className="row">
              <div className="col-xl-12">
                <div className="tp-cart-list mb-45 mr-30">
                  <div className="d-none d-lg-flex">
                    <table className="table">
                      <thead className="rounded-3 overflow-hidden">
                        <tr>
                          <th colSpan="8" className="tp-cart-header-product">
                            Product
                          </th>
                          <th colSpan="2" className="tp-cart-header-price text-center">
                            Price
                          </th>
                          {/* <th className="tp-cart-header-quantity">Quantity</th> */}
                          <th colSpan="2" className="tp-cart-header-price text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {wishlist.map((item, i) => (
                          <WishlistItem key={i} product={item} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="d-flex flex-column d-lg-none">
                    {wishlist.map((item, i) => (
                      <WishlistItem key={i} product={item} />
                    ))}
                  </div>
                </div>
                {/* <div className="tp-cart-bottom">
                  <div className="row align-items-end">
                    <div className="col-xl-6 col-md-4">
                      <div className="tp-cart-update">
                        <Link href="/cart" className="tp-cart-update-btn">Go To Cart</Link>
                      </div>
                    </div>
                  </div>
                </div> */}
              </div>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default WishlistArea;
