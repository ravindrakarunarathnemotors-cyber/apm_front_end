import React from "react";
import Image from "next/image";
import { useDispatch } from "react-redux";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
// internal
import { Close, Minus, Plus } from "@/svg";
import {
  add_cart_product,
  add_cart_product_mes,
  quantityDecrement,
  quantityDecrementone,
  remove_product,
} from "@/redux/features/cartSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

const CartItem = ({ product, discountType, productDiscount, buyxDiscount }) => {
  const {
    product_id,
    media_url,
    title,
    price,
    orderQuantity = 0,
    measurement_needed,
    measurement_value,
    count,
    variant_id,
  } = product || {};
  const symbol = useCurrencySymbol();
  const dispatch = useDispatch();

  console.log(product);

  // --- Find matching discounts ---
  const matchingProductDiscount =
    discountType === "product"
      ? productDiscount?.applicableProducts?.find(
          (d) => d.variant_id == variant_id
        )
      : null;

  const matchingBuyxDiscount =
    discountType === "buyx"
      ? buyxDiscount?.applicableProducts?.find(
          (d) => d.variant_id == variant_id
        )
      : null;

  // --- Calculate totals ---
  const originalTotal = parseFloat(price) * orderQuantity;
  const discountAmount = matchingProductDiscount?.discount_value || 0;
  const finalTotal = parseFloat(originalTotal - discountAmount) < 0 ? 0 : parseFloat(originalTotal - discountAmount);

  // cart actions
  const handleAddProduct = (prd) => dispatch(add_cart_product(prd));
  const handleDecrement = (prd) => dispatch(quantityDecrement(prd));
  const handleRemovePrd = (prd) => dispatch(remove_product(prd));

  const handleAddProductone = (prd) => dispatch(add_cart_product_mes(prd));
  const hanldeDecrementone = (prd) => dispatch(quantityDecrementone(prd));

  return (
    <>
      {/* Normal Cart Row */}
      <tr
        className="d-none d-lg-table-row"
        style={{ verticalAlign: "top", maxWidth: "100%" }}
      >
        {/* img */}
        <td
          colSpan={1}
          className="tp-cart-img py-2 my-0"
          style={{ verticalAlign: "top" }}
        >
          <Link href={`/product/${slugify(title)}-${product_id}`}>
            <div style={{ position: "relative", width: "70px" }}>
              {/* Product image */}
              <Image
                src={media_url || "/assets/img/shop/product-default.jpg"}
                alt={`${title} product image`}
                width={70}
                height={100}
                style={{ width: "70px", height: "auto" }}
              />

              {/* Discount badge */}
              {matchingProductDiscount && (
                <Image
                  src="/assets/img/discount.png"
                  alt="discount badge"
                  width={400}
                  height={400}
                  style={{
                    position: "absolute",
                    top: "-3px",
                    left: "-3px",
                    zIndex: 2,
                  }}
                />
              )}
              {matchingBuyxDiscount && (
                <Image
                  src="/assets/img/discount.png"
                  alt="discount badge"
                  width={400}
                  height={400}
                  style={{
                    position: "absolute",
                    top: "-3px",
                    left: "-3px",
                    zIndex: 2,
                  }}
                />
              )}
            </div>
          </Link>
        </td>

        {/* title */}
        <td
          colSpan={3}
          className="tp-cart-title ps-3"
          style={{ verticalAlign: "top" }}
        >
          <Link href={`/product/${slugify(title)}-${product_id}`}>{title}</Link>

          {/* variant  */}
          {product.variant_value !== "Default" && (
            <div style={{ fontSize: "13px", lineHeight: "15px" }}>
              {product.variant_value}
            </div>
          )}

          {/* Free item row (BuyX Discount) */}
          {matchingBuyxDiscount && (
            <tr>
              <td
                colSpan="6"
                className="text-success"
                style={{ paddingTop: "4px", verticalAlign: "top" }}
              >
                <small>
                  🎁 You get{" "}
                  <strong>{matchingBuyxDiscount.free_count || 1}</strong> free
                  item(s) of
                  <strong> {title}</strong> with this offer.
                </small>
              </td>
            </tr>
          )}

          {/* Product discount line */}
          {matchingProductDiscount && (
            <div>
              <p
                className="text-success mt-1 mb-0 capitalize d-block bg-light px-3 rounded-pill w-auto"
                style={{ fontSize: "11px" }}
              >
                {symbol}
                {Number(originalTotal - discountAmount || 0) < 0 ? parseFloat(originalTotal).toFixed(2) : parseFloat(discountAmount).toFixed(2)}  discount applied ! 
              </p>            
            </div>
          )}
        </td>

        {/* price (Single unit price) */}
        <td
          colSpan={2}
          className="tp-cart-price text-end"
          style={{ verticalAlign: "top" }}
        >
          <span>{parseFloat(price).toFixed(2)}</span>
        </td>

        {/* quantity */}
        {measurement_needed ? (
          <td
            colSpan={2}
            className="tp-cart-quantity px-1 text-end"
            style={{  verticalAlign: "top" }}
          >
            <div className="d-flex align-items-center gap-1 justify-content-end" >
              <div className="tp-product-quantity my-10 " style={{ maxWidth: "150px"}}>
                <span
                  onClick={() => hanldeDecrementone(product)}
                  className="tp-cart-minus"
                >
                  <Minus />
                </span>
                <input
                  className="tp-cart-input"
                  type="text"
                  value={count}
                  readOnly
                />
                <span
                  onClick={() => handleAddProductone(product)}
                  className="tp-cart-plus"
                >
                  <Plus />
                </span>
              </div>
              <span className="text-start ms-1" style={{ width: "40px" }}>
                {measurement_value}
              </span>
            </div>
          </td>
        ) : (
          <td
            colSpan={2}
            className="tp-cart-quantity px-1 text-end"
            style={{ verticalAlign: "top" }}
          >
            <div className="d-flex align-items-center gap-1 justify-content-end" >
              <div className="tp-product-quantity my-10" style={{ maxWidth: "150px"}}>
                <span
                  onClick={() => handleDecrement(product)}
                  className="tp-cart-minus"
                >
                  <Minus />
                </span>
                <input
                  className="tp-cart-input"
                  type="text"
                  value={orderQuantity}
                  readOnly
                />
                <span
                  onClick={() => handleAddProduct(product)}
                  className="tp-cart-plus"
                >
                  <Plus />
                </span>
              </div>
              <span className="text-start ms-1" style={{ width: "40px" }}>
                pc(s)
              </span>
            </div>
          </td>
        )}

        {/* total price */}
        <td
          colSpan={3}
          className="tp-cart-price text-end"
          style={{ verticalAlign: "top" }}
        >
          {matchingProductDiscount ? (
            <div style={{ lineHeight: "15px" }}>
              <span className="fw-semibold" style={{ color: "#010f1c" }}>
                {finalTotal.toFixed(2)}
              </span>
              <span
                style={{
                  color: "#6c757d",
                  textDecoration: "line-through",
                  display: "block",
                  fontSize: "13px",
                }}
              >
                {originalTotal.toFixed(2)}
              </span>
            </div>
          ) : (
            <span className="fw-semibold" style={{ color: "#010f1c" }}>
              {originalTotal.toFixed(2)}
            </span>
          )}
        </td>

        <td
          colSpan={1}
          className="tp-cart-action text-end px-2"
          style={{ width: "50px", verticalAlign: "top" }}
        >
          <button
            onClick={() => handleRemovePrd(product)}
            className="tp-cart-action-btn"
          >
            <i class="fa-solid fa-trash-can" style={{ color: "#ff3d3d" }}></i>
            {/* <span> Remove</span> */}
          </button>
        </td>
      </tr>

      <div className="d-flex d-lg-none justify-content-start w-100 gap-2 pt-2  border-bottom pb-4">
        {/* image */}

        <div
          className="overflow-hidden "
          style={{
            width: "80px",
            height: "auto",
            minWidth: "70px",
            maxWidth: "80px",
          }}
        >
          {" "}
          <Link href={`/product/${slugify(title)}-${product_id}`}>
            <div style={{ position: "relative", width: "70px" }}>
              {/* Product image */}
              <Image
                src={media_url || "/assets/img/shop/product-default.jpg"}
                alt={`${title} product image`}
                width={600}
                height={600}
                className="rounded-3 shadow-sm"
                style={{ width: "70px", height: "auto" }}
              />
              {/* Discount badge */}
              {matchingProductDiscount && (
                <Image
                  src="/assets/img/discount.png"
                  alt="discount badge"
                  width={400}
                  height={400}
                  style={{
                    position: "absolute",
                    top: "-3px",
                    left: "-3px",
                    zIndex: 2,
                    width: "60px",
                    height: "auto",
                  }}
                />
              )}
              {matchingBuyxDiscount && (
                <Image
                  src="/assets/img/discount.png"
                  alt="discount badge"
                  width={400}
                  height={400}
                  style={{
                    position: "absolute",
                    top: "-3px",
                    left: "-3px",
                    width: "60px",
                    height: "auto",
                    zIndex: 2,
                  }}
                />
              )}
            </div>
          </Link>
        </div>

        {/* body */}
        <div className="d-flex flex-column w-100">
          <div
            className="d-flex justify-content-between  align-items-start fw-semibold mb-2"
            style={{ lineHeight: "18px" }}
          >
            <Link href={`/product/${slugify(title)}-${product_id}`}>
              <span className="flex-grow-1">{title}</span>
            </Link>
            <button
              onClick={() => handleRemovePrd(product)}
              className="tp-cart-action-btn "
            >
              <i
                class="fa-solid fa-trash-can"
                style={{ color: "#ff3d3d", marginTop: "4px" }}
              ></i>
              {/* <span> Remove</span> */}
            </button>
          </div>
          <div className="d-flex justify-content-between align-items-end">
            <div>
              {/* variant  */}
              {product.variant_value !== "Default" && (
                <div
                  className="bg-light px-1 rounded-pill p-1"
                  style={{
                    width: "auto",
                    fontSize: "13px",
                    lineHeight: "15px",
                  }}
                >
                  {product.variant_value}
                </div>
              )}
              <div className="mt-2">
                {/* quantity */}
                {measurement_needed ? (
                  <div className="d-flex align-items-center ">
                    <div className="tp-product-quantity border-0 ">
                      <span
                        onClick={() => hanldeDecrementone(product)}
                        className="tp-cart-minus"
                      >
                        <Minus />
                      </span>
                      <input
                        className="tp-cart-input"
                        type="text"
                        value={count}
                        readOnly
                      />
                      <span
                        onClick={() => handleAddProductone(product)}
                        className="tp-cart-plus"
                      >
                        <Plus />
                      </span>
                    </div>
                    <span className="text-end" style={{ width: "30px" }}>
                      {measurement_value}
                    </span>
                  </div>
                ) : (
                  <div className="d-flex align-items-center gap-1">
                    <div className="tp-product-quantity ">
                      <span
                        onClick={() => handleDecrement(product)}
                        className="tp-cart-minus"
                      >
                        <Minus />
                      </span>
                      <input
                        className="tp-cart-input"
                        type="text"
                        value={orderQuantity}
                        readOnly
                      />
                      <span
                        onClick={() => handleAddProduct(product)}
                        className="tp-cart-plus"
                      >
                        <Plus />
                      </span>
                    </div>
                    <span className="text-end" style={{ width: "40px" }}>
                      pc(s)
                    </span>
                  </div>
                )}
                <span>Unit Price :{parseFloat(price).toFixed(2)}</span>
              </div>
            </div>
            <div className="pb-2">
              {matchingProductDiscount ? (
                <div style={{ lineHeight: "15px" }}>
                  <span className="fw-semibold" style={{ color: "#010f1c" }}>
                    {finalTotal.toFixed(2)}
                  </span>
                  <span
                    style={{
                      color: "#6c757d",
                      textDecoration: "line-through",
                      display: "block",
                      fontSize: "13px",
                    }}
                  >
                    {originalTotal.toFixed(2)}
                  </span>
                </div>
              ) : (
                <span className="fw-semibold" style={{ color: "#010f1c" }}>
                  {originalTotal.toFixed(2)}
                </span>
              )}
            </div>
          </div>
          {/* Free item row (BuyX Discount) */}
          {matchingBuyxDiscount && (
            <tr>
              <td
                colSpan="6"
                className="text-success"
                style={{ paddingTop: "4px", verticalAlign: "top" }}
              >
                <small>
                  🎁 You get{" "}
                  <strong>{matchingBuyxDiscount.free_count || 1}</strong> free
                  item(s) of
                  <strong> {title}</strong> with this offer.
                </small>
              </td>
            </tr>
          )}

          {/* Product discount line */}
          {matchingProductDiscount && (
            <p
              className="text-success mt-1 mb-0 capitalize bg-light px-2 rounded-pill"
              style={{ fontSize: "13px" }}
            >
              −{symbol}
              {discountAmount.toFixed(2)} discount applied
            </p>
          )}
        </div>
      </div>
    </>
  );
};

export default CartItem;
