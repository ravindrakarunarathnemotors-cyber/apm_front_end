import React from "react";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
// internal
import { Close, Minus, Plus } from "@/svg";
import {
  add_cart_product,
  quantityDecrement,
} from "@/redux/features/cartSlice";
import { remove_wishlist_product } from "@/redux/features/wishlist-slice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

const WishlistItem = ({ product }) => {
  const { product_id, media_url, title, price, img } = product || {};
  const { cart_products } = useSelector((state) => state.cart);
  const isAddToCart = cart_products.find(
    (item) => item.product_id === product_id
  );
  const symbol = useCurrencySymbol();
  const dispatch = useDispatch();
  // handle add product
  const handleAddProduct = (prd) => {
    dispatch(add_cart_product(prd));
  };
  // handle decrement product
  const handleDecrement = (prd) => {
    dispatch(quantityDecrement(prd));
  };

  // handle remove product
  const handleRemovePrd = (prd) => {
    dispatch(remove_wishlist_product(prd));
  };
  return (
    <>
      <tr
        className="d-none d-lg-table-row"
        style={{ verticalAlign: "top", maxWidth: "100vw" }}
      >
        <td colSpan="8" className="tp-cart-img">
          <Link
            className="bg-white border-0 d-flex align-items-start fw-semibold fs-6"
            href={`/product-details/${product_id}`}
          >
            <Image
              src={media_url || img || "/assets/img/shop/product-default.jpg"}
              alt={`${title} product image` || "product image"}
              className="rounded"
              width={100}
              height={100}
            />
            <span className="tp-cart-title ps-3">{title}</span>
          </Link>
        </td>

        <td
          colSpan="2"
          className="tp-cart-price text-end pe-3"
          style={{ verticalAlign: "top" }}
        >
          <span>
            {symbol}
            {parseFloat(price).toFixed(2)}
          </span>
        </td>
        {/* <td className="tp-cart-quantity">
        <div className="tp-product-quantity mt-10 mb-10">
          <span
            onClick={() => handleDecrement(product)}
            className="tp-cart-minus"
          >
            <Minus />
          </span>
          <input
            className="tp-cart-input"
            type="text"
            value={isAddToCart ? isAddToCart?.orderQuantity : 0}
            readOnly
          />
          <span
            onClick={() => handleAddProduct(product)}
            className="tp-cart-plus"
          >
            <Plus />
          </span>
        </div>
      </td> */}

        <td
          colSpan="1"
          className="tp-cart-add-to-cart"
          style={{ verticalAlign: "top" }}
        >
          <div className="justify-content-end d-flex gap-3 pe-3 h-100">
            <Link href={`/product-details/${product_id}`}>
              <button
                // onClick={() => handleAddProduct(product)}
                type="button"
                className="tp-btn tp-btn-2 tp-btn-blue rounded"
              >
                Buy Now
              </button>
            </Link>

            <button
              onClick={() => handleRemovePrd(product)}
              className="tp-cart-action-btn"
            >
              <i class="fa-solid fa-trash-can" style={{ color: "#ff3d3d" }}></i>
            </button>
          </div>
        </td>
      </tr>
      <div className="d-flex d-lg-none justify-content-start w-100 gap-2 pt-3  border-bottom pb-4">
        <div>
          <Link
            className="bg-white border-0 d-flex align-items-start fw-semibold fs-6"
            href={`/product-details/${product_id}`}
          >
            <Image
              src={media_url || img || "/assets/img/shop/product-default.jpg"}
              alt={`${title} product image` || "product image"}
              className="rounded-3 shadow-sm"
              style={{ width: "70px", height: "auto" }}
              width={600}
              height={600}
            />
          </Link>
        </div>
        <div className="d-flex flex-column w-100 ps-2 gap-3">
          <div
            className="d-flex justify-content-between  align-items-start fw-semibold mb-2"
            style={{ lineHeight: "18px" }}
          >
            <Link href={`/product-details/${product_id}`}>
              <span className=" flex-grow-1">{title}</span>
            </Link>
            <button
              onClick={() => handleRemovePrd(product)}
              className="tp-cart-action-btn"
            >
              <i class="fa-solid fa-trash-can" style={{ color: "#ff3d3d" }}></i>
            </button>
          </div>

          <div
            className="d-flex justify-content-between text-start pe-0 me-0 "
            style={{ verticalAlign: "top" }}
          >
            <span>
              {symbol}
              {parseFloat(price).toFixed(2)}
            </span>
             <Link href={`/product-details/${product_id}`}>
              <button
                // onClick={() => handleAddProduct(product)}
                type="button"
                className="tp-btn tp-btn-2 tp-btn-blue rounded"
              >
                Buy Now
              </button>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default WishlistItem;
