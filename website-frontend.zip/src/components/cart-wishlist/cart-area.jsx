import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
// internal
import { clearCart } from "@/redux/features/cartSlice";
import CartCheckout from "./cart-checkout";
import CartItem from "./cart-item";
import RenderCartProgress from "../common/render-cart-progress";
import { useRouter } from "next/router";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

const CartArea = () => {
  const [discountType, setDiscountType] = useState("none");
  const [orderDiscount, setOrderDiscount] = useState(null);
  const [productDiscount, setProductDiscount] = useState(null);
  const [buyxDiscont, setBuyxDiscont] = useState(null);

  const { cart_products } = useSelector((state) => state.cart);
  const symbol = useCurrencySymbol();
  console.log("product", cart_products);
  console.log("buyxDiscont", buyxDiscont);

  let token = "";
  if (typeof window !== "undefined") {
    token = localStorage.getItem("accessToken");
  }

  const dispatch = useDispatch();
  const router = useRouter();

  useEffect(() => {
    if (cart_products.length === 0) return;

    const timer = setTimeout(() => {
      autoDiscount();
      autoBuyxDiscount();
    }, 1000); // 10 seconds

    return () => clearTimeout(timer); // cancel previous timer before setting a new one
  }, [cart_products]);

  const totalDiscount = useMemo(() => {
    const num = (v) => {
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };

    const orderValue = num(orderDiscount?.discount_value);
    const buyxValue = num(buyxDiscont?.total_discount_value);
    const productValue = num(productDiscount?.total_discount_value);

    const discountValue = Math.max(orderValue, buyxValue, productValue, 0);

    return {
      discountValue,
      productValue,
      buyxValue,
    };
  }, [orderDiscount, productDiscount, buyxDiscont]);

  useEffect(() => {
    const { discountValue, orderValue, productValue, buyxValue } =
      totalDiscount;

    if (discountValue === 0) {
      setDiscountType("none");
      return;
    }

    switch (discountValue) {
      case orderValue:
        setDiscountType("order");
        break;
      case productValue:
        setDiscountType("product");
        break;
      case buyxValue:
        setDiscountType("buyx");
        break;
      default:
        setDiscountType("none");
    }
  }, [totalDiscount, discountType]);

  const autoDiscount = async () => {
    try {
      if (token) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(data.data.order ? data.data.order : null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodiscountcheck`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        const data = await response.json();

        if (response.status === 200) {
          setDiscountType(data.final);
          setOrderDiscount(data.data.order ? data.data.order : null);
          setProductDiscount(data.data.product ? data.data.product : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };
  const autoBuyxDiscount = async () => {
    try {
      if (token) {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/autodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        if (response.status === 401 || response.status === 403) {
          localStorage.removeItem("accessToken");
          router.push("/login");
        }

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      } else {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL}/discount/guestautodbuyxdiscount`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              cart_products: cart_products,
            }),
          }
        );

        const data = await response.json();

        if (response.status === 200) {
          setBuyxDiscont(data.data ? data.data : null);
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <section className="tp-cart-area pb-40 pt-lg-30 pt-10">
        <div className="container py-lg-3 py-1">
          {cart_products.length === 0 && (
            <div className="text-center pt-50">
              <h3>No Cart Items Found</h3>
              <Link href="/shop" className="tp-cart-checkout-btn mt-20">
                Continue Shopping
              </Link>
            </div>
          )}
          {cart_products.length > 0 && (
            <div className="row">
              <div className="col-xl-12 col-lg-12 mb-10">
                <div className="tp-cart-checkout-wrapper mx-0 py-lg-1 py-0 my-0">
                  <h3
                    className="tp-footer-social-title-2 py-2 mb-0 mt-2"
                    style={{ fontSize: "30px" }}
                  >
                    Shopping Cart
                  </h3>
                  <div className="tp-cart-list mb-25 ">
                    <div className="cartmini__shipping">
                      <RenderCartProgress />
                    </div>
                    <div className="d-none d-lg-flex w-100">

                      <table className="table w-100">
                        <thead className="rounded-3 overflow-hidden">
                          <tr className="">
                            <th
                              colSpan={4}
                              className="tp-cart-header-product"
                            >
                              Product
                            </th>
                            <th
                              colSpan={2}
                              className="tp-cart-header-price text-end"
                            >
                              Price ({symbol})
                            </th>
                            <th
                              colSpan={2}
                              className="tp-cart-header-quantity text-end px-1"
                            >
                              Quantity
                            </th>
                            <th
                              colSpan={3}
                              className="tp-cart-header-total text-end"
                            >
                              Total ({symbol})
                            </th>
                            <th colSpan={1}></th>
                          </tr>
                        </thead>

                        <tbody>
                          {cart_products.map((item, i) => (
                            <CartItem
                              key={i}
                              product={item}
                              discountType={discountType}
                              productDiscount={productDiscount}
                              buyxDiscount={buyxDiscont}
                            />
                          ))}
                        </tbody>
                      </table>

                    </div>
                    <div className="d-flex flex-column d-lg-none">
                      {cart_products.map((item, i) => (
                        <CartItem
                          key={i}
                          product={item}
                          discountType={discountType}
                          productDiscount={productDiscount}
                          buyxDiscount={buyxDiscont}
                        />
                      ))}
                    </div>
                  </div>
                  <div className="tp-cart-bottom">
                    <div className="row align-items-end">
                      <div className="tp-cart-update mr-30 my-2 pb-3 d-flex justify-content-end gap-1">
                        <button
                          onClick={() => dispatch(clearCart())}
                          type="button"
                          className="tp-cart-update-btn rounded-3"
                        >
                          Clear Cart
                        </button>
                        <div className="tp-cart-checkout-proceed ms-2">
                          <Link
                            href="/checkout"
                            className="tp-cart-checkout-btn w-100"
                          >
                            Proceed to Checkout
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* <div className="col-xl-3 col-lg-4 col-md-6 mb-10">
                <CartCheckout />
              </div> */}
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default CartArea;
