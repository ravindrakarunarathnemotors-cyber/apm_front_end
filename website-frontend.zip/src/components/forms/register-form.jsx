import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { useRouter } from "next/router";
// internal
import { CloseEye, OpenEye } from "@/svg";
import ErrorMsg from "../common/error-msg";
import { notifyError, notifySuccess } from "@/utils/toast";
import { useRegisterUserMutation } from "@/redux/features/auth/authApi";
import { useGetSystemSettingsQuery } from "@/redux/features/brandingSettingsApi";
import { useGetAllCountryQuery } from "@/redux/features/order/orderApi";
import { useSelector } from "react-redux";

// schema
const schema = Yup.object().shape({
  name: Yup.string().required().label("Name"),
  lastName: Yup.string().required().label("LastName"),
  number: Yup.string()
    .matches(/^[0-9]+$/, "Only digits 0-9 are allowed")
    .required()
    .label("Number"),
  email: Yup.string().required().email().label("Email"),
  address: Yup.string().required().label("Address"),
  city: Yup.string().required().label("City"),
  password: Yup.string().required().min(6).label("Password"),
  remember: Yup.bool()
    .oneOf([true], "You must agree to the terms and conditions to proceed.")
    .label("Terms and Conditions"),
  country: Yup.string().label("Country"),
});

const RegisterForm = () => {
  const [showPass, setShowPass] = useState(false);
  const [sellInternational, setSellInternational] = useState(false);
  const [registerUser, { }] = useRegisterUserMutation();
  const { cart_products } = useSelector((state) => state.cart);

  const { data: systemData } = useGetSystemSettingsQuery();
  const { data } = useGetAllCountryQuery();

  const router = useRouter();
  const { redirect } = router.query;
  // react hook form
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setError,
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    setSellInternational(systemData?.sell_international);
  }, [systemData]);

  // on submit
  const onSubmit = async (form) => {
    // Require a country only when selling internationally
    if (sellInternational && !form.country) {
      setError("country", {
        type: "manual",
        message: "Please select a country.",
      });
      return;
    }

    try {
      const payload = {
        name: form.name,
        lastName: form.lastName,
        number: form.number,
        email: form.email,
        address: form.address,
        city: form.city,
        password: form.password,
        country: sellInternational ? form.country : "162",
      };

      const res = await registerUser(payload).unwrap();
      notifySuccess(res?.message);

      // store token if provided
      if (res?.accessToken)
        localStorage.setItem("accessToken", res.accessToken);

      const count = Array.isArray(cart_products) ? cart_products.length : 0;
      router.push(count === 0 ? "/shop" : redirect || "/checkout");

      reset();
    } catch (err) {
      notifyError(err?.data?.message || "Registration failed");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="tp-login-input-wrapper mt-2">
        <div className="row g-4">
          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("name", { required: `Name is required!` })}
                id="name"
                name="name"
                type="text"
                placeholder="Jhon"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="name">First Name</label>
            </div>
            <ErrorMsg msg={errors.name?.message} />
          </div>

          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("lastName", {
                  required: `Last Name is required!`,
                })}
                id="lastName"
                name="lastName"
                type="text"
                placeholder="Doe"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="lastName">Last Name</label>
            </div>
            <ErrorMsg msg={errors.lastName?.message} />
          </div>

          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("email", { required: `Email is required!` })}
                id="email"
                name="email"
                type="email"
                placeholder="sample@mail.com"
                autoComplete="off"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="email">Your Email</label>
            </div>
            <ErrorMsg msg={errors.email?.message} />
          </div>

          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("number", { required: `Number is required!` })}
                id="number"
                name="number"
                type="text"
                placeholder="07XXXXXXXX"
                autoComplete="off"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="number">Mobile Number</label>
            </div>
            <ErrorMsg msg={errors.number?.message} />
          </div>

          <div className="col-12 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("address", { required: `Address is required!` })}
                id="address"
                name="address"
                type="text"
                placeholder="No.10, Main Street"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="address">Address</label>
            </div>
            <ErrorMsg msg={errors.address?.message} />
          </div>

          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              <input
                {...register("city", {
                  required: `City is required!`,
                })}
                id="city"
                name="city"
                type="text"
                placeholder="Colombo 03"
                autoComplete="off"
              />
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="city">City</label>
            </div>
            <ErrorMsg msg={errors.city?.message} />
          </div>

          <div className="col-12 col-sm-6 tp-login-input-box mb-0">
            <div className="tp-login-input">
              {sellInternational ? (
                <select
                  className="form-select form-select-lg"
                  style={{ height: "56px" }}
                  aria-label="Default select example"
                  {...register("country", { required: "Country is required!" })}
                >
                  <option value="">Select Country</option>
                  {data?.map((country) => (
                    <option key={country?.id} value={country?.id}>
                      {country?.country_name}
                    </option>
                  ))}
                </select>
              ) : (
                <>
                  <input id="country" type="text" value="Sri Lanka" disabled />
                </>
              )}
            </div>
            <div className="tp-login-input-title">
              <label htmlFor="address">Country</label>
            </div>
            <ErrorMsg msg={errors.country?.message} />
          </div>


          <div className="col-12 tp-login-input-box mb-0">
            <div className="p-relative">
              <div className="tp-login-input">
                <input
                  {...register("password", { required: `Password is required!` })}
                  id="password"
                  name="password"
                  type={showPass ? "text" : "password"}
                  placeholder="Set your password with a minimum of 6 characters"
                  autoComplete="off"

                />
              </div>
              <div className="tp-login-input-eye" id="password-show-toggle">
                <span className="open-eye" onClick={() => setShowPass(!showPass)}>
                  {showPass ? <CloseEye /> : <OpenEye />}
                </span>
              </div>

            </div>
            <div className="tp-login-input-title">
              <label htmlFor="password">Password</label>
            </div>
            <ErrorMsg msg={errors.password?.message} />
          </div>

        </div>






      </div>

      <div className="tp-login-suggetions d-sm-flex align-items-center justify-content-between mb-20">
        <div className="tp-login-remeber">
          <input
            {...register("remember", {
              required: `Terms and Conditions is required!`,
            })}
            id="remember"
            name="remember"
            type="checkbox"
          />
          <label htmlFor="remember">
            I accept the terms of the Service & <a href="#">Privacy Policy</a>.
          </label>
          <ErrorMsg msg={errors.remember?.message} />
        </div>
      </div>
      <div className="tp-login-bottom">
        <button type="submit" className="tp-login-btn w-100">
          Sign Up
        </button>
      </div>
    </form>
  );
};

export default RegisterForm;
