import React, { useState, useEffect } from "react";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { Rating } from "react-simple-star-rating";
import * as Yup from "yup";
// internal
import ErrorMsg from "../common/error-msg";
import { useAddGuestReviewMutation, useAddReviewMutation } from "@/redux/features/reviewApi";
import { notifyError, notifySuccess } from "@/utils/toast";
import { useGetUserDetailsQuery } from "@/redux/features/auth/authApi";
import Swal from "sweetalert2";

// schema
const schema = Yup.object().shape({
  name: Yup.string().required().label("Name"),
  email: Yup.string().email().label("Email"),
  comment: Yup.string().required().label("Comment"),
});

const ReviewForm = ({ productId, refetch }) => {
  const { user } = useSelector((state) => state.auth);
  const [rating, setRating] = useState(0);

  let token = ''
  if (typeof window !== 'undefined') {
    token = localStorage.getItem('accessToken')
  }

  const [addReview, { }] = useAddReviewMutation();
  const [addGuestReview, { }] = useAddGuestReviewMutation();
  const { data: userData, isLoading: userLoading, error, isError } = useGetUserDetailsQuery(undefined, {
    skip: !token,
  })

  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    setValue("name", userData?.first_name ? userData?.first_name + " " + userData?.last_name : "");
    setValue("email", userData?.email ?? "");
  }, [userData]);

  // Catch Rating value
  const handleRating = (rate) => {
    setRating(rate)
  }

  // react hook form
  // on submit
  const onSubmit = (data) => {
    if (rating == 0) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Please select a rating!',

      })
      return;
    }
    if(token) {
      addReview({
        userId: data.name,
        productId: productId,
        rating: rating,
        comment: data.comment,
      }).then((result) => {
        if (result?.error) {
          notifyError(result?.error?.data?.message);
        } else {
          refetch();
          notifySuccess(result?.data?.message);
        }
      })
    } else {
      addGuestReview({
        userId: data.name,
        productId: productId,
        rating: rating,
        comment: data.comment,
      }).then((result) => {
        if (result?.error) {
          notifyError(result?.error?.data?.message);
        } else {
          refetch();
          notifySuccess(result?.data?.message);
        }
      })
    }
    setValue("comment", "");
    setRating(0)
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="tp-product-details-review-form-rating d-flex align-items-center">
        <p>Your Rating :</p>
        <div className="tp-product-details-review-form-rating-icon d-flex align-items-center">
          <Rating onClick={handleRating} allowFraction size={16} initialValue={rating} />
        </div>
      </div>
      <div className="tp-product-details-review-input-wrapper">
        <div className="tp-product-details-review-input-box">
          <div className="tp-product-details-review-input">
            <textarea
              {...register("comment", { required: `Comment is required!` })}
              id="comment"
              name="comment"
              placeholder="Write your review here..."
            />
          </div>
          <div className="tp-product-details-review-input-title">
            <label htmlFor="msg">Your Review</label>
          </div>
          <ErrorMsg msg={errors.name?.comment} />
        </div>
        <div className="tp-product-details-review-input-box">
          <div className="tp-product-details-review-input">
            <input
              {...register("name", { required: `Name is required!` })}
              name="name"
              id="name"
              type="text"
              placeholder="John Doe"
            />
          </div>
          <div className="tp-product-details-review-input-title">
            <label htmlFor="name">Your Name</label>
          </div>
          <ErrorMsg msg={errors.name?.name} />
        </div>
        {/* <div className="tp-product-details-review-input-box">
          <div className="tp-product-details-review-input">
            <input
              {...register("email", { required: `Name is required!` })}
              name="email"
              id="email"
              type="email"
              placeholder="john@mail.com"
            />
          </div>
          <div className="tp-product-details-review-input-title">
            <label htmlFor="email">Your Email</label>
          </div>
          <ErrorMsg msg={errors.name?.email} />
        </div> */}
      </div>
      <div className="tp-product-details-review-btn-wrapper d-flex justify-content-end">
        <button type="submit" className="tp-product-details-review-btn">Submit</button>
      </div>
    </form>
  );
};

export default ReviewForm;
