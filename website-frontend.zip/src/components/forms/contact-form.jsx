// contact-form.jsx
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import ErrorMsg from "../common/error-msg";
import { notifyError, notifySuccess } from "@/utils/toast";

const schema = Yup.object().shape({
  name: Yup.string().required().label("Name"),
  email: Yup.string().required().email().label("Email"),
  subject: Yup.string().required().label("Subject"),
  message: Yup.string().required().label("Message"),
  // remember: Yup.bool().oneOf([true], "You must agree...").label("Terms and Conditions"),
});

const ContactForm = ({ supportEmail = "" }) => {
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({ resolver: yupResolver(schema) });

const API_BASE = (process.env.NEXT_PUBLIC_BASE_URL || "").replace(/\/$/, "");
const onSubmit = async (data) => {
  setSubmitting(true);
  try {
    if (!API_BASE) throw new Error("Missing NEXT_PUBLIC_BASE_URL");

    const res = await fetch(`${API_BASE}/api/contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: data.name,
        email: data.email,
        subject: data.subject,
        message: data.message,
      }),
    });

    const ct = res.headers.get("content-type") || "";
    const payload = ct.includes("application/json") ? await res.json() : { raw: await res.text() };

    if (!res.ok) throw new Error(payload?.error || payload?.raw || `Request failed (${res.status})`);

    notifySuccess("Message sent successfully!");
    reset();
  } catch (err) {
    notifyError(err.message || "Failed to send message.");
  } finally {
    setSubmitting(false);
  }
};

  return (
    <form onSubmit={handleSubmit(onSubmit)} id="contact-form">
      <div className="tp-contact-input-wrapper">
        <div className="tp-contact-input-box">
          <div className="tp-contact-input">
            <input
              {...register("name")}
              id="name"
              type="text"
              placeholder="Jhon Doe"
              disabled={submitting}
            />
          </div>
          <div className="tp-contact-input-title">
            <label htmlFor="name">Your Name</label>
          </div>
          <ErrorMsg msg={errors.name?.message} />
        </div>

        <div className="tp-contact-input-box">
          <div className="tp-contact-input">
            <input
              {...register("email")}
              id="email"
              type="email"
              placeholder="jhon@mail.com"
              disabled={submitting}
            />
          </div>
          <div className="tp-contact-input-title">
            <label htmlFor="email">Your Email</label>
          </div>
          <ErrorMsg msg={errors.email?.message} />
        </div>

        <div className="tp-contact-input-box">
          <div className="tp-contact-input">
            <input
              {...register("subject")}
              id="subject"
              type="text"
              placeholder="Write your subject"
              disabled={submitting}
            />
          </div>
          <div className="tp-contact-input-title">
            <label htmlFor="subject">Subject</label>
          </div>
          <ErrorMsg msg={errors.subject?.message} />
        </div>

        <div className="tp-contact-input-box">
          <div className="tp-contact-input">
            <textarea
              {...register("message")}
              id="message"
              placeholder="Write your message here..."
              disabled={submitting}
            />
          </div>
          <div className="tp-contact-input-title">
            <label htmlFor="message">Your Message</label>
          </div>
          <ErrorMsg msg={errors.message?.message} />
        </div>
      </div>

      <div className="tp-contact-btn" style={{ backgroundColor: "var(--primary-color)" }}>
        <button type="submit" disabled={submitting}>
          {submitting ? "Sending..." : "Send Message"}
        </button>
      </div>
    </form>
  );
};

export default ContactForm;
