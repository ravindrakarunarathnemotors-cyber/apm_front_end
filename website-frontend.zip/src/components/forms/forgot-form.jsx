import React from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
// internal
import ErrorMsg from "../common/error-msg";
import { useResetPasswordMutation } from "@/redux/features/auth/authApi";
import { notifyError, notifySuccess } from "@/utils/toast";
import { useRouter } from "next/router";

// schema
const schema = Yup.object().shape({
  email: Yup.string().required().email().label("Email"),
});

const ForgotForm = () => {
  const [resetPassword, {}] = useResetPasswordMutation();

  const router =  useRouter()
    // react hook form
    const {register,handleSubmit,formState: { errors },reset, watch} = useForm({
      resolver: yupResolver(schema), 
    });
    // onSubmit
    const onSubmit = (data) => {
      resetPassword({
        verifyEmail: data.email,
      }).then((result) => {
        console.log(result);
        if(result?.error){
          notifyError(result?.error?.data?.message)
        }
        else {
          notifySuccess(result.data?.message);
          router.push(`/forget-password/${watch("email")}`) 
          reset();
        }
      });
      
    };
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="tp-login-input-wrapper">
        <div className="tp-login-input-box">
          <div className="tp-login-input">
            <input
              {...register("email", { required: `Email is required!` })}
              name="email"
              id="email"
              type="email"
              placeholder="sample@mail.com"
            />
          </div>
          <div className="tp-login-input-title">
            <label htmlFor="email">Your Email</label>
          </div>
          <ErrorMsg msg={errors.email?.message} />
        </div>
      </div>
      <div className="tp-login-bottom mb-15">
        <button type="submit" className="tp-login-btn w-100">
          Send Mail
        </button>
      </div>
    </form>
  );
};

export default ForgotForm;
