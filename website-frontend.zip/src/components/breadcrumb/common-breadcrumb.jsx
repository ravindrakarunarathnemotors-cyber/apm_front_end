import React from "react";
import Link from "next/link";

const CommonBreadcrumb = ({
  title,
  subtitle,
  center = false,
  bg_clr = false,
}) => {
  return (
    <section
      className={`breadcrumb__area ${
        center ? "text-center" : ""
      } include-bg pt-40 pb-30`}
      style={{ backgroundColor: bg_clr && `#EFF1F5` }}
    >
      <div className="container">
        <div className="row">
          <div className="col-xxl-12">
            <div className="breadcrumb__content p-relative z-index-1">
              <h3 className="tp-footer-social-title-2" style={{fontSize:'30px'}}>{title}</h3>
              <div className="breadcrumb__list ms-1">
                <span>
                                <Link href="/">Home</Link>

                </span>
                <span>{subtitle}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CommonBreadcrumb;
