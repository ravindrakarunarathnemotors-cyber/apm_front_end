import React from 'react';
import { SmDot } from '@/svg';
import Link from "next/link";

// const ProductDetailsBreadcrumb = ({category,title}) => {
const ProductDetailsBreadcrumb = ({title}) => {
  return (
    <section className="breadcrumb__area breadcrumb__style-2 include-bg pt-50 pb-20">
    <div className="container">
       <div className="row">
          <div className="col-xxl-12">
             <div className="breadcrumb__content p-relative z-index-1">
                <div className="breadcrumb__list has-icon">
                   <span className="breadcrumb-icon">
                      <SmDot/>{" "}
                   </span>
                   <span><Link href="/">Home</Link></span>
                   <span><Link href="/shop">Shop</Link></span>
                   {/* <span><a href="#">{category}</a></span> */}
                   <span>{title}</span>
                </div>
             </div>
          </div>
       </div>
    </div>
 </section>
  );
};

export default ProductDetailsBreadcrumb;