"use client";
import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
import { Wishlist } from "@/svg";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import MediaThumb from "@/components/common/MediaThumb";
import { useKoko } from "@/context/KokoContext";

const VIDEO_EXTS = /\.(mp4|m4v|webm|ogg|ogv|mov|mkv)(\?.*)?$/i;
const isVideoUrl = (u) => typeof u === "string" && VIDEO_EXTS.test(u || "");

const ProductItem = ({ product, prdCenter = false, primary_style = false }) => {
  const {
    _id,
    img,
    title,
    reviews,
    price,
    status,
    total_stock,
    continue_selling_oos,
    discount_amount,
    compare_price,
    has_discount,
    discount_type,
    free_count,
    buy_count,
  } = product || {};

  const [ratingVal, setRatingVal] = useState(0);
  const dispatch = useDispatch();
  const { cart_products } = useSelector((state) => state.cart);
  const { wishlist } = useSelector((state) => state.wishlist);
  const isAddedToCart = cart_products.some((prd) => prd.product_id === _id);
  const isAddedToWishlist = wishlist.some((prd) => prd._id === _id);
  const symbol = useCurrencySymbol();
  const { koko, kokoFee } = useKoko();
  console.log("koko", kokoFee);

  useEffect(() => {
    if (reviews && reviews.length > 0) {
      const rating =
        reviews.reduce((acc, review) => acc + review.rating, 0) /
        reviews.length;
      setRatingVal(rating);
    } else {
      setRatingVal(0);
    }
  }, [reviews]);

  const handleWishlistProduct = (prd) => {
    const payload = { ...prd, media_url: img, product_id: _id };
    dispatch(add_to_wishlist(payload));
  };

  const isVideo = useMemo(() => isVideoUrl(img), [img]);

  return (
    <div
      className={`tp-product-item-3 mb-50 ${
        primary_style ? "tp-product-style-primary" : ""
      } ${prdCenter ? "text-center" : ""}`}
    >
      <div className="tp-product-thumb-3 mb-15 fix p-relative z-index-1 rounded  shadow-sm">
        <Link href={`/product/${slugify(title)}-${_id}`}>
          <div className="bg-white">
            {/* 👇 Image OR Video (auto) */}
            <MediaThumb
              src={img || "/assets/img/shop/product-default.jpg"}
              alt={`${title} product image` || "product image"}
              width={1000}
              height={1000}
              style={{
                width: "100%",
                height: "auto",
                objectFit: "contain",
                borderRadius: 0,
              }}
            />
          </div>

          {/* Small "video" badge (optional) */}
          {isVideo && (
            <span
              className="position-absolute top-0 start-0 m-2 px-2 py-1 rounded-pill fw-semibold"
              style={{
                background: "rgba(37,99,235,.1)",
                color: "#2563eb",
                fontSize: 12,
              }}
            >
              video
            </span>
          )}

          {total_stock < 1 && !continue_selling_oos && (
            <div className="tp-product-badge overflow-hidden">
              <span
                className="product-hot rounded-pill px-2"
                style={{ fontSize: "11px" }}
              >
                OUT OF STOCK
              </span>
            </div>
          )}
        </Link>

        {/* product action */}
        <div className="tp-product-action-3 tp-product-action-blackStyle">
          <div className="tp-product-action-item-3 d-flex flex-column">
            <button
              disabled={status === "out-of-stock"}
              onClick={() => handleWishlistProduct(product)}
              className={`tp-product-action-btn-3 ${
                isAddedToWishlist ? "active" : ""
              } tp-product-add-to-wishlist-btn`}
            >
              <Wishlist />
              <span className="tp-product-tooltip">Add To Wishlist</span>
            </button>
          </div>
        </div>

        <div className="tp-product-add-cart-btn-large-wrapper">
          {isAddedToCart ? (
            <Link
              href="/cart"
              className="tp-product-add-cart-btn-large text-center"
            >
              View To Cart
            </Link>
          ) : (
            <Link href={`/product/${slugify(title)}-${_id}`}>
              <button
                type="button"
                className="tp-product-add-cart-btn-large"
                disabled={status === "out-of-stock"}
              >
                Buy Now
              </button>
            </Link>
          )}
        </div>
      </div>

      <Link href={`/product/${slugify(title)}-${_id}`}>
        <div className="tp-product-content-3">
          <div
            style={{
              fontSize: "1rem",
              display: "-webkit-box",
              lineHeight: "1.4",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              textOverflow: "ellipsis",
              wordBreak: "break-word",
              textTransform: "capitalize",
            }}
          >
            {title}
          </div>

          <div
            className="tp-product-price-wrapper-3 mt-1"
            style={{ lineHeight: "1" }}
          >
            <span
              className="tp-product-price-3"
              style={{ marginLeft: "2px", lineHeight: "1" }}
            >
              {symbol}
            </span>
            {has_discount && discount_type == "product" && (
              <span className="tp-product-price-3">
                {Math.max(0, Number(compare_price || 0)).toFixed(2)}
              </span>
            )}
            {(!has_discount ||
              (has_discount && discount_type == "buyxgety")) && (
              <span className="tp-product-price-3">
                {parseFloat(price).toFixed(2)}
              </span>
            )}

            {has_discount && discount_type == "product" && (
              <span
                className="ms-1 text-decoration-line-through"
                style={{ fontSize: "12px" }}
              >
                {parseFloat(price).toFixed(2)}
              </span>
            )}
          </div>

          {/* Koko Installment Section */}
          {/* Koko Installment Section */}
          {koko === true && kokoFee && (
            <div
              className="mt-0 pb-2 d-flex flex-wrap align-items-center"
              style={{ gap: "5px", fontSize: "13px" }}
            >
              <span style={{ color: "#777" }}>pay in 3 x</span>
              <span className="fw-semibold" style={{ color: "#000" }}>
                {symbol}{" "}
                {(() => {
                  const basePrice = (parseFloat(price) || 0)- (parseFloat(discount_amount) || 0);
                  const fixedFee =
                    parseFloat(kokoFee.transaction_fixed_fee) || 0;
                  const percentFee = parseFloat(kokoFee.transaction_fee) || 0;
                  const totalPercentAmount = (basePrice * percentFee) / 100;
                  const grandTotal = basePrice + fixedFee + totalPercentAmount;
                  return (grandTotal / 3).toFixed(2);
                })()}
              </span>
              <span style={{ color: "#777" }}>with</span>

              <img
                src="/assets/img/koko.png" // Fixed path (removed the dot if using Next.js public folder)
                alt="Koko"
                style={{
                  height: "18px",
                  marginLeft: "2px",
                  verticalAlign: "middle",
                }}
              />
            </div>
          )}

          {has_discount && discount_type == "buyxgety" && (
            <div
              className="badge rounded-pill text-bg-success align-items-center px-2 py-1"
              style={{ fontSize: "10px" }}
            >
              <i class="fa-solid fa-tags fa-fade me-1"></i>
              BUY {buy_count} GET {free_count} FREE !
            </div>
          )}
          {has_discount && discount_type == "product" && (
            <div
              className="badge rounded-pill text-bg-danger align-items-center px-2 py-1"
              style={{ fontSize: "10px" }}
            >
              {/* <i class="fa-light fa-tags me-1"></i> */}
              <i class="fa-regular fa-fire fa-fade me-1"></i>
              Save {symbol}{" "}
              {Number(compare_price || 0) < 0
                ? parseFloat(price).toFixed(2)
                : parseFloat(discount_amount).toFixed(2)}
            </div>
          )}
        </div>
      </Link>
    </div>
  );
};

export default ProductItem;
