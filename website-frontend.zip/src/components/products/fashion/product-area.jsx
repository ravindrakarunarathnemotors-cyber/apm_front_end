import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useCallback,
} from "react";
import Link from "next/link";
import { TextShapeLine } from "@/svg";
import ProductItem from "./product-item";
import ErrorMsg from "@/components/common/error-msg";
import { HomeThreePrdTwoLoader } from "@/components/loader";
import { useGetProductsWithCollectionQuery } from "@/redux/features/homeApi";
import { useRouter } from "next/router";

const ProductAreaB = ({ sectionId }) => {
  const {
    data: collections = [],
    isLoading,
    isError,
  } = useGetProductsWithCollectionQuery(sectionId);

  const router = useRouter();
  const [activeTab, setActiveTab] = useState(null);
  const tabBarRef = useRef(null);
  const activeBtnRef = useRef(null);
  const markerRef = useRef(null);

  // helpers
  const slugify = useCallback(
    (s) =>
      s
        ?.toString()
        .toLowerCase()
        .trim()
        .replace(/&/g, "and")
        .replace(/\s+/g, "-"),
    []
  );

  // set default active tab from URL (?collection=slug) or first collection
  useEffect(() => {
    if (!collections.length) return;
    const fromUrl = router.query.collection;
    const match = fromUrl
      ? collections.find((c) => slugify(c.collection_name) === fromUrl)
      : null;
    setActiveTab((prev) =>
      prev == null ? match?.collection_id ?? collections[0].collection_id : prev
    );
  }, [collections, router.query.collection, slugify]);

  // move underline marker under active button
  const moveMarker = useCallback((btnEl) => {
    const marker = markerRef.current;
    if (!btnEl || !marker) return;
    marker.style.transform = `translateX(${btnEl.offsetLeft}px)`;
    marker.style.width = `${btnEl.offsetWidth}px`;
  }, []);

  useEffect(() => {
    if (activeBtnRef.current) moveMarker(activeBtnRef.current);
  }, [activeTab, collections, moveMarker]);

  // change tab + persist in URL (shallow)
  const handleActive = (e, tabId, name) => {
    setActiveTab(tabId);
    moveMarker(e.currentTarget);
    router.replace(
      { query: { ...router.query, collection: slugify(name) } },
      undefined,
      { shallow: true }
    );
    // scroll tab into view on mobile
    e.currentTarget?.scrollIntoView({
      behavior: "smooth",
      inline: "center",
      block: "nearest",
    });
  };

  // keyboard nav for tabs
  const onTabKeyDown = (e) => {
    if (!tabBarRef.current) return;
    const focusables = Array.from(
      tabBarRef.current.querySelectorAll('button[role="tab"]')
    );
    const idx = focusables.indexOf(document.activeElement);
    if (idx === -1) return;
    if (e.key === "ArrowRight") {
      e.preventDefault();
      const next = focusables[(idx + 1) % focusables.length];
      next?.focus();
      next?.click();
    }
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      const prev =
        focusables[(idx - 1 + focusables.length) % focusables.length];
      prev?.focus();
      prev?.click();
    }
  };

  // active collection + normalize for ProductItem
  const activeCollection = useMemo(
    () => collections.find((c) => c.collection_id === activeTab),
    [collections, activeTab]
  );

  const items = useMemo(() => {
    const list = activeCollection?.products ?? [];
    return list.map((p) => ({
      _id: p.product_id,
      img: p.media_url || "/assets/img/shop/product-default.jpg",
      title: p.title,
      price: p.price,
      status: "active",
    }));
  }, [activeCollection]);

  // content
  let content = null;
  if (isLoading) {
    content = <HomeThreePrdTwoLoader loading />;
  } else if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  } else if (!collections.length) {
    content = <ErrorMsg msg="No Products found!" />;
  } else {
    content = (
      <>
        {/* Header + Tabs */}
        <div className="row align-items-end">
          <div className="col-xl-6 col-lg-6">
            <div className="tp-section-title-wrapper-3 mb-45 text-center text-lg-start">
              <h2 className="tp-section-title-3">Enjoy the best quality</h2>
              {activeCollection && (
                <p className="text-muted m-0 small">
                  Showing {items.length} item{items.length !== 1 ? "s" : ""}{" "}
                  from <strong>{activeCollection.collection_name}</strong>
                </p>
              )}
            </div>
          </div>
          <div className="col-xl-6 col-lg-6">
            <div className="tp-product-tab-2 tp-product-tab-3 tp-tab mb-50 text-center">
              <div className="tp-product-tab-inner-3 d-flex align-items-center justify-content-center justify-content-lg-end">
                <nav>
                  <div
                    ref={tabBarRef}
                    className="nav nav-tabs tp-product-tab tp-tab-menu p-relative gap-2 "
                    role="tablist"
                    aria-label="Product collections"
                    onKeyDown={onTabKeyDown}
                    style={{ whiteSpace: "nowrap" }}
                  >
                    {collections.map((tab) => {
                      const isActive = activeTab === tab.collection_id;
                      return (
                        <button
                          key={tab.collection_id}
                          ref={isActive ? activeBtnRef : null}
                          onClick={(e) =>
                            handleActive(
                              e,
                              tab.collection_id,
                              tab.collection_name
                            )
                          }
                          role="tab"
                          aria-selected={isActive}
                          className={`nav-link text-capitalize ${
                            isActive ? "active" : ""
                          }`}
                          style={{
                            backgroundColor: isActive
                              ? "var(--backgroundcolor-color)"
                              : "transparent",
                          }}
                          title={`${tab.collection_name} (${
                            tab.products?.length || 0
                          })`}
                        >
                          {tab.collection_name.split("-").join(" ")}
                          <span className="tp-product-tab-tooltip">
                            {tab.products?.length || 0}
                          </span>
                        </button>
                      );
                    })}
                    {/* animated underline */}
                    <span
                      ref={markerRef}
                      className="tp-tab-line d-none d-sm-inline-block"
                    />
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>

        {/* Grid */}
        {items.length === 0 ? (
          <ErrorMsg msg="No Products found for this collection!" />
        ) : (
          <div className="row g-3">
            {items.slice(0, 8).map((prd) => (
              <div key={prd._id} className="col-6 col-md-4 col-lg-3">
                <ProductItem product={prd} />
              </div>
            ))}
            {/* View All card when more than 8 */}
            {items.length > 8 && activeCollection && (
              <div className="col-6 col-md-4 col-lg-3">
                <Link
                  className="d-flex align-items-center justify-content-center border rounded-3 w-100 h-100 text-decoration-none fw-semibold view-all-card"
                  href={{
                    pathname: "/shop",
                    query: {
                      collection: slugify(activeCollection.collection_name),
                    },
                  }}
                  title={`View all in ${activeCollection.collection_name}`}
                >
                  View all {activeCollection.collection_name}
                </Link>
              </div>
            )}
          </div>
        )}
      </>
    );
  }

  return (
    <section
      className="tp-best-area pb-60 pt-90"
      style={{ backgroundColor: "var(--background-color)" }}
    >
      <section className="tp-product-area pb-90">
        <div className="container">
          <div className="row">
            <div className="col-xl-12">
              {/* <div className="tp-section-title-wrapper-2 text-center mb-35">
                <span className="tp-section-title-pre-2">
                  All Product Shop
                  <TextShapeLine />
                </span>
                <h3 className="tp-section-title-2">Customer Favorite Style Product</h3>
              </div> */}
            </div>
          </div>
          {/* {content} */}
          <div className="container">{content}</div>

          {/* micro UI polish */}
          <style jsx>{`
            .no-scrollbar::-webkit-scrollbar {
              display: none;
            }
            .no-scrollbar {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .tp-tab-line {
              position: absolute;
              bottom: -6px;
              height: 2px;
              background: var(--bs-primary);
              transition: transform 240ms ease, width 240ms ease;
            }
            .nav-link {
              border: 0;
              padding: 8px 14px;
              border-radius: 999px;
            }
            .nav-link.active {
              background: var(--primary-color);
              color: var(--bs-primary);
            }
            .nav-link:not(.active):hover {
              background: rgba(var(--primary-color), 0.06);
            }
            .view-all-card {
              min-height: 320px;
              color: var(--bs-primary);
              background: rgba(var(--bs-primary-rgb), 0.06);
              transition: transform 160ms ease, background 160ms ease;
            }
            .view-all-card:hover {
              transform: translateY(-2px);
              background: rgba(var(--bs-primary-rgb), 0.1);
            }
          `}</style>
        </div>
      </section>
    </section>
  );
};

export default ProductAreaB;

// import React, { useState } from 'react';
// import ErrorMsg from '@/components/common/error-msg';
// import { useGetProductTypeQuery } from '@/redux/features/productApi';
// import { TextShapeLine } from '@/svg';
// import ProductItem from './product-item';
// import { HomeTwoPrdLoader } from '@/components/loader';

// // tabs
// const tabs = ["All Collection", "Shoes", "Clothing", "Bags"];

// const ProductAreaB = () => {
//   const [activeTab, setActiveTab] = useState(tabs[0]);
//   const { data: products, isError, isLoading } =
//     useGetProductTypeQuery({ type: 'fashion' });
//   // handleActiveTab
//   const handleActiveTab = (tab) => {
//     setActiveTab(tab);
//   };

//   // decide what to render
//   let content = null;

//   if (isLoading) {
//     content = (
//       <HomeTwoPrdLoader loading={isLoading} />
//     );
//   }
//   if (!isLoading && isError) {
//     content = <ErrorMsg msg="There was an error" />;
//   }
//   if (!isLoading && !isError && products?.data?.length === 0) {
//     content = <ErrorMsg msg="No Products found!" />;
//   }
//   if (!isLoading && !isError && products?.data?.length > 0) {
//     let product_items = products.data;
//     console.log('consoleData', product_items)
//     if (activeTab === 'All Collection') {
//       product_items = products.data

//     }
//     else if (activeTab === 'Shoes') {
//       product_items = products.data.filter(p => p.category.name === 'Shoes')
//     } else if (activeTab === 'Clothing') {
//       product_items = products.data.filter(p => p.category.name === 'Clothing')
//     } else if (activeTab === 'Bags') {
//       product_items = products.data.filter(p => p.category.name === 'Bags')
//     } else {
//       product_items = products.data;
//     }
//     content = <>
//       <div className="row">
//         <div className="col-xl-12">
//           <div className="tp-product-tab-2 tp-tab mb-50 text-center">
//             <nav>
//               <div className="nav nav-tabs justify-content-center">
//                 {tabs.map((tab, i) => (
//                   <button
//                     key={i}
//                     onClick={() => handleActiveTab(tab)}
//                     className={`nav-link text-capitalize ${activeTab === tab ? "active" : ""}`}
//                   >
//                     {tab.split("-").join(" ")}
//                     <span className="tp-product-tab-tooltip">{product_items.length}</span>
//                   </button>
//                 ))}
//               </div>
//             </nav>
//           </div>
//         </div>
//       </div>
//       <div className="row">
//         {product_items.map((prd) => (
//           <div key={prd._id} className="col-xl-3 col-lg-4 col-md-6 col-sm-6">
//             <ProductItem product={prd} />
//           </div>
//         ))}
//       </div>
//     </>
//   }
//   return (
//     <>
//       <section className="tp-product-area pb-90">
//         <div className="container">
//           <div className="row">
//             <div className="col-xl-12">
//               <div className="tp-section-title-wrapper-2 text-center mb-35">
//                 <span className="tp-section-title-pre-2">
//                   All Product Shop
//                   <TextShapeLine />
//                 </span>
//                 <h3 className="tp-section-title-2">Customer Favorite Style Product</h3>
//               </div>
//             </div>
//           </div>
//           {content}
//         </div>
//       </section>
//     </>
//   );
// };

// export default ProductAreaB;
