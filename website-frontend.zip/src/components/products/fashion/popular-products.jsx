// external
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Scrollbar } from "swiper";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
// internal
import { TextShapeLine } from "@/svg";
import { slugify } from "@/lib/slugify";
import ErrorMsg from "@/components/common/error-msg";
import { useGetPopularProductByTypeQuery } from "@/redux/features/productApi";
import { add_cart_product } from "@/redux/features/cartSlice";
import { HomeTwoPopularPrdLoader } from "@/components/loader";
import { notifyError } from "@/utils/toast";
import { useGetBestSellingProductsQuery } from "@/redux/features/homeApi";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

// slider setting
const slider_setting = {
  slidesPerView: 5,
  spaceBetween: 30,
  loop: false,
  centeredSlides: false,
  scrollbar: {
    el: ".swiper-scrollbar",
    draggable: true,
    dragClass: "tp-swiper-scrollbar-drag",
    snapOnRelease: true,
  },
  breakpoints: {
    1200: {
      slidesPerView: 5,
    },
    992: {
      slidesPerView: 4,
    },
    768: {
      slidesPerView: 3,
    },
    576: {
      slidesPerView: 2,
    },
    0: {
      slidesPerView: 1,
    },
  },
};

const PopularProductsOne = ({ sectionId }) => {
  const symbol = useCurrencySymbol();
  const {
    data: products,
    isError,
    isLoading,
  } = useGetBestSellingProductsQuery(sectionId);
  console.log("products", products);
  // const {data: products,isError,isLoading} = useGetPopularProductByTypeQuery("fashion");
  const { cart_products } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  // handle add product
  const handleAddProduct = (prd) => {
    if (prd.status === "out-of-stock") {
      notifyError(`This product out-of-stock`);
    } else {
      dispatch(add_cart_product(prd));
    }
  };
  // decide what to render
  let content = null;

  if (isLoading) {
    content = <HomeTwoPopularPrdLoader loading={isLoading} />;
  }
  if (!isLoading && isError) {
    content = <ErrorMsg msg="There was an error" />;
  }
  if (!isLoading && !isError && products?.length === 0) {
    content = <ErrorMsg msg="No Products found!" />;
  }
  if (!isLoading && !isError && products?.length > 0) {
    const product_items = products;

    content = (
      <Swiper
        {...slider_setting}
        modules={[Scrollbar]}
        className="tp-category-slider-active-2 swiper-container mb-50"
      >
        {product_items.map((item) => (
          <SwiperSlide
            key={item.product_id}
            className="tp-category-item-2 p-relative z-index-1 text-center d-flex flex-column"
          >
            <div className="tp-category-thumb-2 ">
              <Link href={`/product/${slugify(item.title)}-${item.product_id}`}>
                <div className="bg-white">
                  <Image
                    src={
                      item.media_url || "/assets/img/shop/product-default.jpg"
                    }
                    alt={`${item.title} product image` || "product image"}
                    width={500}
                    height={300} // just a placeholder aspect ratio
                    style={{
                      width: "100%",
                      height: "auto",
                      objectFit: "contain",
                    }}
                  />
                </div>
              </Link>
              {/* <Link href={`/product/${slugify(item.title)}-${item.product_id}`}>
                <div className="ratio ratio-1x1  bg-white border shadow-sm rounded overflow-hidden ">
                  <Image
                    src={
                      item.media_url || "/assets/img/shop/product-default.jpg"
                    }
                    alt={`${item.title} product image` || "product image"}
                    width={260}
                    height={260}
                    style={{
                      objectFit: "contain",
                      width: "100%",
                      height: "100%",
                    }}
                  />
                </div>
              </Link> */}
            </div>

            <Link href={`/product/${slugify(item.title)}-${item.product_id}`}>
              <div className="tp-product-content-3">
                <div
                  style={{
                    fontSize: "1rem",
                    display: "-webkit-box",
                    lineHeight: "1.4",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    wordBreak: "break-word",
                    textTransform: "capitalize",
                  }}
                >
                  {item.title}
                </div>
                {/* <div className="tp-product-tag-3"><span>{tags[1]}</span></div> */}

                <div className="tp-product-price-wrapper-3 mt-1">
                  <span className="tp-product-price-3">
                    {symbol}
                    {parseFloat(item.price).toFixed(2)}
                  </span>
                </div>
              </div>
            </Link>
            {/* <Link href={`/product/${slugify(item.title)}-${item.product_id}`}>
              <div className="tp-product-content-3 d-flex flex-column justify-content-between pt-2">
                <div className="tp-product-tag-wrapper-3 flex-grow-1">
                  <div className="tp-product-tag-3">
                  </div>
                  <h2
                    className="tp-product-title-3 text-break"
                    style={{
                      fontWeight: "500",
                      display: "-webkit-box",
                      lineHeight: "1.4",
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: "vertical",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      wordBreak: "break-word",
                      fontSize: "16px",
                      textAlign: "start",
                      minHeight: "2.8em",
                    }}
                  >
                    {item.title}
                  </h2>
                </div>

                <div className="tp-product-price-wrapper-3 text-start ">
                  <span className="tp-product-price-3">
                    {symbol}
                    {parseFloat(item.price).toFixed(2)}
                  </span>
                </div>
              </div>
            </Link> */}
          </SwiperSlide>
        ))}
      </Swiper>
    );
  }
  return (
    <>
      <section className="tp-category-area pb-95 pt-40">
        <div className="container">
          <div className="row">
            <div className="col-xl-12">
              <div className="tp-section-title-wrapper-2 text-center mb-50">
                <span className="tp-section-title-pre-2">
                  Shop by Popular
                  <TextShapeLine />
                </span>
                <h3 className="tp-section-title-2">
                  Popular on the Shofy store.
                </h3>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-xl-12">
              <div className="tp-category-slider-2 p-relative">
                {content}
                <div className="swiper-scrollbar tp-swiper-scrollbar tp-swiper-scrollbar-drag"></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default PopularProductsOne;
