import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper";
import { Rating } from "react-simple-star-rating";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
// internal
import { useGetProductTypeQuery } from "@/redux/features/productApi";
import { ArrowRightLong, NextLongArr, PrevLongArr, TextShapeLine } from "@/svg";
import ErrorMsg from "@/components/common/error-msg";
import { HomeTwoFeaturedPrdLoader } from "@/components/loader";
import { useGetFeaturesProductsQuery } from "@/redux/features/homeApi";

// slider setting
const slider_setting = {
  slidesPerView: '2',
  spaceBetween: 10,
  navigation: {
    nextEl: ".tp-featured-slider-button-next",
    prevEl: ".tp-featured-slider-button-prev",
  },
  breakpoints: {
    1200: {
      slidesPerView: 2, // still keep ~2 on desktop
    },
    992: {
      slidesPerView: 2,
    },
    768: {
      slidesPerView: 2,
    },
    576: {
      slidesPerView: 1,
    },
    0: {
      slidesPerView: 1,
    },
  },
  watchOverflow: true,              // disables nav if only few slides
  centerInsufficientSlides: true,   // centers if less than perView
};


const WeeksFeatured = ({ sectionId }) => {
  const {
    data: products,
    isLoading,
    isError,
  } = useGetFeaturesProductsQuery(sectionId);

  // = () => {
  //   const { data: products, isError, isLoading } =
  //     useGetProductTypeQuery({ type: 'fashion', query: `featured=true` });

  // decide what to render
  let content = null;

  if (isLoading) {
    content = <HomeTwoFeaturedPrdLoader loading={isLoading} />;
  }
  if (!isLoading && isError) {
    content = <ErrorMsg msg="There was an error" />;
  }
  if (!isLoading && !isError && products?.length === 0) {
    content = <ErrorMsg msg="No Products found!" />;
  }
  if (!isLoading && !isError && products?.length > 0) {
    const product_items = products;
    console.log("product_items", product_items);
    content = (
      <Swiper
        {...slider_setting}
        modules={[Navigation]}
        className="tp-featured-slider-active swiper-container"
      >
        {product_items.map((item) => (
          <SwiperSlide
            key={item.product_id}
            className="tp-featured-item white-bg p-relative z-index-1 rounded overflow-hidden"
          >
            <div
              className="tp-featured-thumb include-bg"
              style={{
                backgroundImage: `url(${item.media_url})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                width: "100%",
                paddingTop: "75%", 
              }}
              data-background={item.media_url}
            ></div>

            <div className="tp-featured-content pt-4">
              <h3 className="tp-featured-title-3">
                <Link
                  href={`/product/${slugify(item.title)}-${item.product_id}`}
                >
                  {item.title}
                </Link>
              </h3>

              <div className="tp-featured-price-wrapper">
                <span className="tp-featured-price new-price">
                  Rs. {Number(item.price).toLocaleString()}
                </span>
              </div>

              <p className="tp-featured-desc">
                {item.search_engine_desc?.slice(0, 80)}...
              </p>

              <div className="tp-featured-btn">
                <Link
                  href={`/product/${slugify(item.title)}-${item.product_id}`}
                  className="tp-btn tp-btn-border tp-btn-border-sm rounded"
                >
                  Shop Now <ArrowRightLong />
                </Link>
              </div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    );
  }
  return (
    <section className="tp-featured-slider-area grey-bg-6 fix pt-95 pb-120">
      <div className="container">
        <div className="row">
          <div className="col-xl-12">
            <div className="tp-section-title-wrapper-2 mb-50">
              <span className="tp-section-title-pre-2">
                Shop by Featured
                <TextShapeLine />
              </span>
              <h3 className="tp-section-title-2">This {"Week's"} Featured</h3>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-xl-12">
            <div className="tp-featured-slider w-100">
              {content}
              <div className="tp-featured-slider-arrow mt-45">
                <button className="tp-featured-slider-button-prev">
                  <PrevLongArr />
                </button>
                <button className="tp-featured-slider-button-next">
                  <NextLongArr />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WeeksFeatured;
