import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper";
// internal
import { ArrowRightLong, TextShapeLine } from "@/svg";
import { useGetProductTypeQuery } from "@/redux/features/productApi";
import ProductItem from "./product-item";
import ErrorMsg from "@/components/common/error-msg";
import trending_banner from "@assets/img/product/trending/banner/trending-banner.jpg";
import { HomeTwoNewPrdPrdLoader } from "@/components/loader";
import { useGetSpecialProductDetailsQuery } from "@/redux/features/brandingSettingsApi";
import Link from "next/link";

// slider setting
const slider_setting = {
  slidesPerView: 2,
  spaceBetween: 24,
  pagination: {
    el: ".tp-trending-slider-dot",
    clickable: true,
  },
  breakpoints: {
    1200: {
      slidesPerView: 2,
    },
    768: {
      slidesPerView: 2,
    },
    576: {
      slidesPerView: 2,
    },
    0: {
      slidesPerView: 1,
    },
  },
};

const TrendingProducts = ({ sectionId }) => {
  // const {
  //   data: products,
  //   isError,
  //   isLoading,
  // } = useGetProductTypeQuery({ type: "fashion", query: `new=true` });

  const {
    data: raw,
    isError,
    isLoading,
  } = useGetSpecialProductDetailsQuery(sectionId);
  console.log("first", raw);

  // Normalize: some APIs return { success, data }
  const specialData = raw?.data ?? raw ?? {};
  const products = Array.isArray(specialData.products)
    ? specialData.products
    : [];

  // Adapt to ProductItem shape
  const adapted = products.map((p) => ({
    _id: p.product_id, // ProductItem uses _id for links/cart keys
    img: p.media_url,
    title: p.title,
    price: p.price, // string or number OK
    status: p.status || "in-stock", // optional
  }));


  // decide what to render
  let content = null;

  if (isLoading) {
    content = <HomeTwoNewPrdPrdLoader loading={isLoading} />;
  }
  if (!isLoading && isError) {
    content = <ErrorMsg msg="There was an error" />;
  }
  if (!isLoading && !isError && adapted.length === 0) {
    content = <ErrorMsg msg="No Products found!" />;
  }
  if (!isLoading && !isError && adapted.length > 0) {
    // const product_items = products.data.slice(0, 5);
    content = (
      <Swiper
        {...slider_setting}
        modules={[Pagination]}
        className="tp-trending-slider-active swiper-container"
      >
        {adapted.map((item) => {
          return (
            <SwiperSlide key={item._id} className="tp-trending-item"  >
              <ProductItem product={item} style_2={true} />
            </SwiperSlide>
          );
        })}
      </Swiper>
    );
  }
  return (
    <>
      <section className="tp-trending-area pt-80 pb-80" style={{ backgroundColor: specialData.right_bg_color || 'var(--background-color)'  }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-xl-7 col-lg-7 ">
              <div className="tp-trending-wrapper" >
                <div className="tp-section-title-wrapper-2 mb-50">
                  <span className="tp-section-title-pre-2">
                    More to Discover
                    <TextShapeLine />
                  </span>
                  <h3 className="tp-section-title-2">Trending Arrivals</h3>
                </div>
                <div className="tp-trending-slider">
                  {content}
                  <div className="tp-trending-slider-dot tp-swiper-dot text-center mt-45"></div>
                </div>
              </div>
            </div>
            <div className="col-xl-5 col-lg-5 col-sm-12">
              <div className="tp-trending-banner p-relative ml-35 rounded overflow-hidden">
                <div
                  className="tp-trending-banner-thumb w-img include-bg"
                  style={{ backgroundImage: `url(${specialData.left_image_url ||  trending_banner.src})` }}
                ></div>
                <div className="tp-trending-banner-content">
                  <h3 className="tp-trending-banner-title">
                    <Link href="/shop">
                      Short Sleeve Tunic <br /> Tops Casual Swing
                    </Link>
                  </h3>
                  <div className="tp-trending-banner-btn">
                    <Link
                      href="/shop"
                      className="tp-btn tp-btn-border tp-btn-border-white tp-btn-border-white-sm rounded"
                    >
                      Explore More
                      <ArrowRightLong />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default TrendingProducts;
