import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Image from "next/image";
import Link from "next/link";
import { slugify } from "@/lib/slugify";
import { Rating } from "react-simple-star-rating";
import { Cart, CompareThree, QuickView, Wishlist } from "@/svg";
import { handleProductModal } from "@/redux/features/productModalSlice";
import { add_cart_product } from "@/redux/features/cartSlice";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import { add_to_compare } from "@/redux/features/compareSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { useRouter } from "next/router";
import { notifyError, notifySuccess } from "@/utils/toast";

const ProductItemDirect = ({ product, prdCenter = false, primary_style = false }) => {
    const {
        _id,
        img,
        category_id,
        category_name,
        title,
        reviews,
        price,
        discount,
        tags,
        status,
        description,
        total_stock,
        continue_selling_oos
    } = product || {};

    const [ratingVal, setRatingVal] = useState(0);
    const dispatch = useDispatch();
    const { cart_products } = useSelector((state) => state.cart);
    const { wishlist } = useSelector((state) => state.wishlist);
    const isAddedToCart = cart_products.some((prd) => prd.product_id === _id);
    const isAddedToWishlist = wishlist.some((prd) => prd._id === _id);
    // console.log(product)
    const symbol = useCurrencySymbol();
    const router = useRouter();

    useEffect(() => {
        if (reviews && reviews.length > 0) {
            const rating =
                reviews.reduce((acc, review) => acc + review.rating, 0) /
                reviews.length;
            setRatingVal(rating);
        } else {
            setRatingVal(0);
        }
    }, [reviews]);

    // handle wishlist product
    const handleWishlistProduct = (prd) => {
        console.log(prd)
        dispatch(add_to_wishlist(prd));
    };

    // Strip HTML tags from the description (server-safe)
    const stripHtml = (html) => {
        if (!html) return "";
        if (typeof window !== "undefined") {
            const doc = new DOMParser().parseFromString(html, "text/html");
            return doc.body.textContent || "";
        }
        return html.replace(/<[^>]+>/g, "");
    };

    const handleAddProduct = async (product) => {
        if (isAddedToCart) {
            router.push('/cart')
            return
        }

        console.log(product)

        try {
            const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/product/direct-add-to-cart`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    product_id: product._id
                })
            })
            const data = await res.json()
            if (res.status === 200) {
                // notifySuccess("Product added to cart successfully");
                dispatch(add_cart_product(data.result));
            } else {
                notifyError(data.message)
            }
        } catch (err) {
            console.log(err)
        }

    }

    return (
        <div
            className={`tp-product-item-3 mb-50 ${primary_style ? "tp-product-style-primary" : ""
                } ${prdCenter ? "text-center" : ""}`}
        >
            <div className="tp-product-thumb-3 mb-15 fix p-relative z-index-1 rounded shadow-sm">
                <Link href={`/product/${slugify(title)}-${_id}`}>
                    <div className="bg-white">
                        <Image
                            src={img || "/assets/img/shop/product-default.jpg"}
                            alt={`${title} product image` || "product image"}
                            width={500}
                            height={300}  // just a placeholder aspect ratio
                            style={{ width: "100%", height: "auto", objectFit: "contain" }}
                        />
                    </div>

                    {total_stock < 1 && !continue_selling_oos && (
                        <div className="tp-product-badge rounded-pill overflow-hidden">
                            <span className="product-hot">SOLD OUT</span>
                        </div>
                    )}
                </Link>


                {/* product action */}
                <div className="tp-product-action-3 tp-product-action-blackStyle">
                    <div className="tp-product-action-item-3 d-flex flex-column">
                        <button
                            disabled={status === "out-of-stock"}
                            onClick={() => handleWishlistProduct(product)}
                            className={`tp-product-action-btn-3 
                                        ${isAddedToWishlist ? "active" : ""
                                } tp-product-add-to-wishlist-btn`}
                        >
                            <Wishlist />
                            <span className="tp-product-tooltip">Add To Wishlist</span>
                        </button>
                        <button
                            onClick={() => handleAddProduct(product)}
                            type="button"
                            className={`tp-product-action-btn ${isAddedToCart ? 'active' : ''} tp-product-add-cart-btn`}
                            disabled={total_stock < 1 && !continue_selling_oos}
                            style={{ cursor: total_stock < 1 && !continue_selling_oos? 'not-allowed' : 'pointer' }}
                        >
                            <Cart />

                            <span className="tp-product-tooltip">{isAddedToCart ? 'View Cart' : 'Add to Cart'}</span>
                        </button>
                    </div>
                </div>

                <div className="tp-product-add-cart-btn-large-wrapper">
                    <button
                        onClick={() => handleAddProduct(product)}
                        type="button"
                        className="tp-product-add-cart-btn-large"
                        disabled={total_stock < 1 && !continue_selling_oos}
                        style={{ cursor: total_stock < 1 && !continue_selling_oos ? 'not-allowed' : 'pointer' }}
                    >
                        {isAddedToCart ? 'View Cart' : 'Add to Cart'}
                    </button>
                </div>
            </div>

            <Link href={`/product/${slugify(title)}-${_id}`}>

                <div className="tp-product-content-3">
                    <div
                        style={{
                            fontSize: "1rem",
                            display: "-webkit-box",
                            lineHeight: "1.4",
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: "vertical",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            wordBreak: "break-word",
                            textTransform: "capitalize",

                        }}>
                        {title}
                    </div>
                    {/* <div className="tp-product-tag-3"><span>{tags[1]}</span></div> */}

                    <div className="tp-product-price-wrapper-3 mt-1">
                        <span className="tp-product-price-3">
                            {symbol}
                            {parseFloat(price).toFixed(2)}
                        </span>
                    </div>
                </div>
            </Link>
        </div>
    );
};

export default ProductItemDirect;
