import React, { useEffect, useMemo, useRef, useState, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import ProductItem from "./product-item";
import ErrorMsg from "@/components/common/error-msg";
import { HomeThreePrdTwoLoader } from "@/components/loader";
import { useGetProductsWithCollectionQuery } from "@/redux/features/homeApi";

const ProductAreaTwo = ({ sectionId, bgClass }) => {
  const { data: collections = [], isLoading, isError } = useGetProductsWithCollectionQuery(sectionId);
  const router = useRouter();
  
  const [activeTab, setActiveTab] = useState(null);
  const [isChanging, setIsChanging] = useState(false);

  const slugify = useCallback((s) => 
    s?.toString().toLowerCase().trim().replace(/&/g, "and").replace(/\s+/g, "-"), []
  );

  /** * AUTO-SELECT LOGIC: 
   * Runs as soon as collections are fetched.
   */
  useEffect(() => {
    if (collections.length > 0 && activeTab === null) {
      const fromUrl = router.query.collection;
      const match = fromUrl 
        ? collections.find((c) => slugify(c.collection_name) === fromUrl) 
        : null;

      // Priority: 1. URL Query, 2. First Collection in Array
      const initialTab = match?.collection_id || collections[0]?.collection_id;
      setActiveTab(initialTab);
    }
  }, [collections, router.query.collection, slugify, activeTab]);

  const handleActive = (tabId, name) => {
    if (tabId === activeTab) return;
    setIsChanging(true);
    setActiveTab(tabId);
    
    router.replace(
      { query: { ...router.query, collection: slugify(name) } }, 
      undefined, 
      { shallow: true }
    );
    
    setTimeout(() => setIsChanging(false), 50);
  };

  const activeCollection = useMemo(() => 
    collections.find((c) => c.collection_id === activeTab), 
    [collections, activeTab]
  );

  const items = useMemo(() => {
    const list = activeCollection?.products ?? [];
    return list.map((p) => ({
      _id: p.product_id,
      img: p.media_url || "/assets/img/shop/product-default.jpg",
      title: p.title,
      price: p.price,
      status: "active",
      has_discount: p.has_discount || false,
      discount_amount: p.discount_amount,
      compare_price: p.has_discount ? parseFloat(p.price) - parseFloat(p.discount_amount) : 0,
    }));
  }, [activeCollection]);

  // Handle loading state with high-quality skeletons
  if (isLoading) return <div className="container py-100"><HomeThreePrdTwoLoader loading /></div>;
  if (isError || (collections.length === 0 && !isLoading)) return <ErrorMsg msg="No Collections Found" />;

  return (
    <section className={`tp-product-area-two pt-100 pb-100 ${bgClass || "bg-white"}`}>
      <div className="container">
        <div className="row align-items-center mb-50">
          <div className="col-lg-6">
            <div className="tp-section-title-wrapper-3 text-center text-lg-start">
              <span className="tp-section-title-pre-3" style={{ color: 'var(--tp-theme-primary)', fontWeight: '600', textTransform: 'uppercase', fontSize: '13px', letterSpacing: '1px' }}>
                Customer Favorites
              </span>
              <h2 className="tp-section-title-3 mt-5">Best Selling Products</h2>
            </div>
          </div>
          
          <div className="col-lg-6 d-flex justify-content-end">
            <div className="tp-segmented-control-wrapper mt-30 mt-lg-0">
              <nav className="tp-segmented-nav">
                {collections.map((tab) => {
                  const isActive = activeTab === tab.collection_id;
                  return (
                    <button
                      key={tab.collection_id}
                      onClick={() => handleActive(tab.collection_id, tab.collection_name)}
                      className={`segmented-item ${isActive ? "active" : ""}`}
                    >
                      {tab.collection_name.replace(/-/g, " ")}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>
        </div>

        {/* Content renders only when activeTab is set */}
        {activeTab && (
          <div className={`row g-4 transition-grid ${isChanging ? "switching" : ""}`}>
            {items.slice(0, 8).map((prd, idx) => (
              <div key={prd._id} className="col-6 col-md-4 col-lg-3 fade-in-up" style={{ "--delay": `${idx * 0.05}s` }}>
                <ProductItem product={prd} />
              </div>
            ))}

            {items.length > 8 && (
              <div className="col-6 col-md-4 col-lg-3 fade-in-up" style={{ "--delay": '0.4s' }}>
                <Link
                  href={`/shop?collection=${slugify(activeCollection.collection_name)}`}
                  className="modern-view-all-card"
                >
                  <span>View All Items</span>
                  <i className="fal fa-long-arrow-right"></i>
                </Link>
              </div>
            )}
          </div>
        )}
      </div>

      <style jsx>{`

      `}</style>
    </section>
  );
};

export default ProductAreaTwo;