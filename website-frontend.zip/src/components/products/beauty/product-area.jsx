import React, { useMemo } from "react";
import Link from "next/link";
import { ArrowRightSmTwo } from "@/svg";
import ProductItem from "./product-item"; // Assuming this is where individual cards are styled
import ErrorMsg from "@/components/common/error-msg";
import { useGetBestSellingProductsQuery } from "@/redux/features/homeApi";
import { HomeThreePrdLoader } from "@/components/loader";

const ProductAreaD = ({ sectionId, bgClass }) => {
  const { data, isError, isLoading } =
    useGetBestSellingProductsQuery(sectionId);

  // Normalize data with useMemo to prevent re-mapping on every render
  const items = useMemo(() => {
    if (!data) return [];
    // Handle different backend response shapes
    const rows = Array.isArray(data) ? data : data?.result || data?.data || [];

    return rows.map((r) => ({
      _id: r._id ?? r.product_id,
      img: r.img ?? r.media_url ?? "/images/placeholder.png", // Use placeholder if img missing
      title: r.title || r.name, // Handle common variation in field name
      price: r.price,
      status: "active",
      has_discount: r.has_discount || false,
      discount_type: r.discount_type || "",
      free_count: r.free_count || 0,
      buy_count: r.buy_count || 0,
      discount_amount: r.discount_amount,
      compare_price: r.has_discount
        ? parseFloat(r.price) - parseFloat(r.discount_amount) || 0
        : 0,
    }));
  }, [data]);

  // Handle conditional rendering in a separate function to keep the return clean
const renderContent = () => {
    if (isLoading) {
      return (
        /* Create a row that matches your product grid spacing */
        <div className="row g-4 pt-10">
          {[...Array(1)].map((_, i) => (
            <div key={i} className="row">
              {/* Ensure this loader doesn't have its own internal row/container */}
              <HomeThreePrdLoader loading={true} />
            </div>
          ))}
        </div>
      );
    } 
    
    if (isError) return <div className="py-5"><ErrorMsg msg="Unable to load products." /></div>;
    if (items.length === 0) return <div className="text-center py-5"><p className="text-muted fs-6">No products available.</p></div>;

    return (
      <div className="row d-flex g-4 pt-10"> 
        {items.slice(0, 8).map((prd) => (
          <div key={prd._id} className="col-lg-3 col-md-4 col-sm-6">
            <ProductItem product={prd} />
          </div>
        ))}
      </div>
    );
  };

  return (
    <section className={`tp-product-area pt-90 pb-90 ${bgClass || "bg-white"}`}>
      <div className="container">
        {/* Modernized Header Section */}
        <div className="row align-items-end mb-40">
          <div className="col-lg-7">
            <div className="tp-section-title-wrapper-3">
              {/* Refined subtitle/pre-title consistent with Category section */}
              <span
                className="tp-section-title-pre-3"
                style={{
                  color: "var(--tp-theme-primary)",
                  fontWeight: "600",
                  textTransform: "uppercase",
                  fontSize: "13px",
                  letterSpacing: "1px",
                }}
              >
                Customer Favorites
              </span>
              <h2
                className="tp-section-title-3 text-capitalize"
                style={{
                  fontSize: "clamp(26px, 3.5vw, 38px)",
                  fontWeight: "700",
                }}
              >
                Best Selling Products
              </h2>
            </div>
          </div>
          <div className="col-lg-5 text-lg-end d-none d-md-block">
            {/* Refined, ghost-style action button */}
            <div className="tp-product-more-3">
              <Link
                href="/shop"
                className="tp-btn-border"
                style={{
                  padding: "10px 24px",
                  borderRadius: "50px",
                  fontSize: "14px",
                  transition: "all 0.3s",
                }}
              >
                View All Items <ArrowRightSmTwo />
              </Link>
            </div>
          </div>
        </div>

        {/* Dynamic Products Grid */}
        {renderContent()}
      </div>
    </section>
  );
};

export default ProductAreaD;
