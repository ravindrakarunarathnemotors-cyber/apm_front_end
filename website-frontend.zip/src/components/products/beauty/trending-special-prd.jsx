import React, { useMemo } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation, Autoplay, EffectFade } from 'swiper';
import Image from 'next/image';
import { ArrowNextSm, ArrowPrevSm } from '@/svg';
import ErrorMsg from '@/components/common/error-msg';
import ProductItem from './product-item';
import { HomeThreeTrendingPrdLoader } from '@/components/loader';
import { useGetSpecialProductDetailsQuery } from '@/redux/features/brandingSettingsApi';

const sliderSetting = {
  slidesPerView: 1,
  spaceBetween: 0,
  loop: true,
  effect: 'fade',
  autoplay: { delay: 5000, disableOnInteraction: false },
  pagination: { el: '.tp-special-pagination-progress', type: 'progressbar' },
  navigation: { nextEl: '.special-next', prevEl: '.special-prev' },
};

const TrendingSpecialPrd = ({ sectionId, bgClass }) => {
  const { data: raw, isError, isLoading } = useGetSpecialProductDetailsQuery(sectionId);

  const specialData = useMemo(() => raw?.data ?? raw ?? {}, [raw]);
  const products = useMemo(() => Array.isArray(specialData.products) ? specialData.products : [], [specialData]);

  const adapted = useMemo(() => products.map((p) => ({
    _id: p.product_id,
    img: p.media_url,
    title: p.title,
    price: p.price,
    status: p.status || 'in-stock',
    has_discount: p.has_discount || false,
    discount_amount: p.discount_amount,
    compare_price: p.has_discount ? parseFloat(p.price) - parseFloat(p.discount_amount) : 0,
  })), [products]);

  if (isLoading) return <div className="py-80"><HomeThreeTrendingPrdLoader loading /></div>;
  if (isError || adapted.length === 0) return <ErrorMsg msg="Special Products currently unavailable" />;

  return (
    <section className={`tp-special-area-modern pt-80 pb-80 ${bgClass}`}>
      <div className="container">
        <div className="special-glass-container">
          <div className="row g-3 align-items-stretch">
            
            {/* Left Image Section - High Impact */}
            <div className="col-xl-7 col-lg-6 p-0 rounded-3">
              <div className="special-main-thumb">
                <Image
                  src={specialData.left_image_url || "/assets/img/placeholder.jpg"}
                  width={1000}
                  height={1000}
                  alt="Trending Lifestyle"
                  priority
                  className="zoom-effect"
                  style={{ width:'100%', height:'100%', objectFit: 'cover' , objectPosition: 'center' }}
                />
                <div className="image-overlay-gradient"></div>
              </div>
            </div>

            {/* Right Product Section - Clean & Interactive */}
            <div className="col-xl-5 col-lg-6 d-flex align-items-center rounded-3">
              <div 
                className="special-content-panel w-100 px-2"
                style={{ '--panel-bg': specialData.right_bg_color || '#ffffff' }}
              >
                <div className="tp-section-title-wrapper-3 mb-30 text-center text-md-start px-4 d-flex flex-column justify-content-center">
                  <span className="tp-section-title-pre-3 text-center" style={{ color: 'var(--tp-theme-primary)', fontWeight: '600', textTransform: 'uppercase', fontSize: '13px', letterSpacing: '1px' }}>
                    Handpicked Selection
                  </span>
                  <h2 className="tp-section-title-3 h1 text-center">Special Finds</h2>
                </div>

                <div className="special-slider-wrapper">
                  <Swiper
                    {...sliderSetting}
                    modules={[Pagination, Navigation, EffectFade, Autoplay]}
                    className="special-swiper-active"
                  >
                    {adapted.map((item) => (
                      <SwiperSlide key={item._id} >
                        <div className="px-5 pb-20"  style={{ backgroundColor: specialData.right_bg_color || '#ffffff' }} >
                           <ProductItem product={item} />
                        </div>
                      </SwiperSlide>
                    ))}
                  </Swiper>

                  {/* Modern Navigation Controls */}
                  <div className="special-controls-footer">
                    <div className="tp-special-pagination-progress"></div>
                    <div className="special-nav-btns">
                      <button className="special-prev"><ArrowPrevSm /></button>
                      <button className="special-next"><ArrowNextSm /></button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>

    </section>
  );
};

export default TrendingSpecialPrd;