"use client";
import React from "react";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
// internal
import { Wishlist } from "@/svg";
import { slugify } from "@/lib/slugify";
import { add_cart_product } from "@/redux/features/cartSlice";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import { useKoko } from "@/context/KokoContext";

const VIDEO_EXTS = /\.(mp4|m4v|webm|ogg|ogv|mov|mkv)(\?.*)?$/i;
const isVideoUrl = (u) => typeof u === "string" && VIDEO_EXTS.test(u || "");

const ProductItem = ({ product, prdCenter = false, primary_style = false }) => {
  const {
    _id,
    img,
    title,
    discount,
    price,
    tags,
    status,
    discount_amount,
    compare_price,
    has_discount,
    discount_type,
    free_count,
    buy_count,
  } = product || {};
  const { cart_products } = useSelector((state) => state.cart);
  const { wishlist } = useSelector((state) => state.wishlist);
  const isAddedToCart = cart_products.some((prd) => prd.product_id === _id);
  const isAddedToWishlist = wishlist.some((prd) => prd._id === _id);
  const dispatch = useDispatch();
  const { koko, kokoFee } = useKoko();
  console.log("dataofDiscount", koko, kokoFee);

  const symbol = useCurrencySymbol();

  // handle add product
  const handleAddProduct = (prd) => {
    dispatch(add_cart_product(prd));
  };
  // handle wishlist product
  const handleWishlistProduct = (prd) => {
    const payload = { ...prd, media_url: img, product_id: _id };
    dispatch(add_to_wishlist(payload));
  };

  const thumb = img || "/assets/img/shop/product-default.jpg";
  const isVideo = isVideoUrl(thumb);

  return (
    <div
      className={`tp-product-item-3 mb-50 ${
        primary_style ? "tp-product-style-primary" : ""
      } ${prdCenter ? "text-center" : ""}`}
    >
      <div className="tp-product-thumb-3 mb-15 fix p-relative z-index-1 rounded shadow-sm">
        <Link href={`/product/${slugify(title)}-${_id}`}>
          <div className="bg-white position-relative">
            {/* Image OR Video (auto) */}
            {isVideo ? (
              <video
                src={thumb}
                muted
                playsInline
                autoPlay
                loop
                controls={false}
                preload="metadata"
                style={{
                  width: "100%",
                  height: "100%",
                  maxHeight: 500,
                  objectFit: "contain",
                  borderRadius: 0,
                  display: "block",
                  background: "#fff",
                }}
              />
            ) : (
              <Image
                src={thumb}
                alt={`${title} product image` || "product image"}
                width={500}
                height={500} // preserve aspect feel
                style={{ width: "100%", height: "auto", objectFit: "contain" }}
                priority={false}
              />
            )}

            {/* Optional small "video" badge if it's a video */}
            {isVideo && (
              <span
                className="position-absolute top-0 start-0 m-2 px-2 py-1 rounded-pill fw-semibold"
                style={{
                  background: "rgba(37,99,235,.1)",
                  color: "#2563eb",
                  fontSize: 12,
                }}
              >
                video
              </span>
            )}
          </div>
        </Link>

        {/* product action */}
        <div className="tp-product-action-3 tp-product-action-blackStyle">
          <div className="tp-product-action-item-3 d-flex flex-column">
            <button
              disabled={status === "out-of-stock"}
              onClick={() => handleWishlistProduct(product)}
              className={`tp-product-action-btn-3 ${
                isAddedToWishlist ? "active" : ""
              } tp-product-add-to-wishlist-btn`}
            >
              <Wishlist />
              <span className="tp-product-tooltip">Add To Wishlist</span>
            </button>
          </div>
        </div>

        <div className="tp-product-add-cart-btn-large-wrapper">
          {isAddedToCart ? (
            <Link
              href="/cart"
              className="tp-product-add-cart-btn-large text-center"
            >
              View To Cart
            </Link>
          ) : (
            <Link href={`/product/${slugify(title)}-${_id}`}>
              <button
                type="button"
                className="tp-product-add-cart-btn-large"
                disabled={status === "out-of-stock"}
              >
                Buy Now
              </button>
            </Link>
          )}
        </div>
      </div>

      <Link href={`/product/${slugify(title)}-${_id}`}>
        <div className="tp-product-content-3">
          <div
            style={{
              fontSize: "1rem",
              display: "-webkit-box",
              lineHeight: "1.4",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              textOverflow: "ellipsis",
              wordBreak: "break-word",
              textTransform: "capitalize",
            }}
          >
            {title}
          </div>

          <div className="tp-product-price-wrapper-3 mt-1">
            <span
              className="tp-product-price-3"
              style={{ marginLeft: "2px", lineHeight: "1" }}
            >
              {symbol}
            </span>

            {has_discount && discount_type == "product" && (
              <span className="tp-product-price-3">
                {parseFloat(compare_price).toFixed(2)}
              </span>
            )}

            {(!has_discount ||
              (has_discount && discount_type == "buyxgety")) && (
              <span className="tp-product-price-3">
                {parseFloat(price).toFixed(2)}
              </span>
            )}

            {has_discount && discount_type == "product" && (
              <span
                className="ms-1 text-decoration-line-through"
                style={{ fontSize: "12px" }}
              >
                {parseFloat(price).toFixed(2)}
              </span>
            )}
          </div>

          {/* Koko Installment Section */}
          {koko === true && kokoFee && (
            <div
              className= "mt-0 pb-2 d-flex flex-wrap align-items-center"
              style={{ gap: "5px", fontSize: "13px" }}
              
            >
              <span style={{ color: "#777" }}>pay in 3 x</span>
              <span className="fw-semibold" style={{ color: "#000" }}>
                {symbol}{" "}
                {(() => {
                  const basePrice = (parseFloat(price) || 0)- (parseFloat(discount_amount) || 0);
                  const fixedFee =
                    parseFloat(kokoFee.transaction_fixed_fee) || 0;
                  const percentFee = parseFloat(kokoFee.koko_percent_fee) || 0;
                  const totalPercentAmount = (basePrice * percentFee) / 100;
                  const grandTotal = basePrice + fixedFee + totalPercentAmount;
                  return (grandTotal / 3).toFixed(2);
                })()}
              </span>
              <span style={{ color: "#777" }}>with</span>

              <img
                src="/assets/img/koko.png" // Fixed path (removed the dot if using Next.js public folder)
                alt="Koko"
                style={{
                  height: "18px",
                  marginLeft: "2px",
                  verticalAlign: "middle",
                }}
              />
            </div>
          )}

          {has_discount && discount_type == "buyxgety" && (
            <div
              className="badge rounded-pill text-bg-success align-items-center px-2 py-1"
              style={{ fontSize: "10px" }}
            >
              <i class="fa-solid fa-tags fa-fade me-1"></i>
              BUY {buy_count} GET {free_count} FREE !
            </div>
          )}
          {has_discount && discount_type == "product" && (
            <div
              className="badge rounded-pill text-bg-danger align-items-center px-2 py-1"
              style={{ fontSize: "10px" }}
            >
              {/* <i class="fa-light fa-tags me-1"></i> */}
              <i class="fa-regular fa-fire fa-fade me-1"></i>
              Save {symbol} {parseFloat(discount_amount).toFixed(2)}
            </div>
          )}
        </div>
      </Link>
    </div>
  );
};

export default ProductItem;
