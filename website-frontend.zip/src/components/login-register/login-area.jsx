import React, { useState, useEffect } from "react";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";
import LoginAreaLoader from "@/components/loader/login-register/login-area-loader";
import LoginAreaBody from "./login-area-body";

const LoginArea = () => {
  const { isFetching, isLoading } = useGetBrandingSettingsQuery();
  const [showContent, setShowContent] = useState(false);

  const loading = isFetching || isLoading;

  // Add a slight delay before showing content to let CSS transitions catch up
  useEffect(() => {
    if (!loading) {
      const timer = setTimeout(() => setShowContent(true), 100);
      return () => clearTimeout(timer);
    }
  }, [loading]);

  return (
    <div className="login-area-wrapper">
      {loading ? (
        <div className="fade-in">
          <LoginAreaLoader />
        </div>
      ) : (
        <div className={`transition-content ${showContent ? 'is-visible' : ''}`}>
          <LoginAreaBody />
        </div>
      )}
    </div>
  );
};

export default LoginArea;