import React from "react";
import LoginForm from "../forms/login-form";
import RegisterForm from "../forms/register-form";
import LoginShapes from "./login-shapes";
import GoogleSignUp from "./google-sign-up";
import { Icon } from "@iconify/react";
import { useRouter } from "next/router";

/** Pure UI — no loading logic */
const LoginAreaBody = () => {
  const router = useRouter();

  return (
    <section className="tp-login-area pt-70 pb-140 p-relative z-index-1 fix">
      <LoginShapes />
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12">
            <div className="tp-login-wrapper p-5">
              <div className="tp-login-option d-flex flex-column flex-md-row justify-content-between align-items-stretch">

                {/* REGISTER */}
                <div className="col-12 col-md-6 order-3 order-md-1">
                  <h3 className="breadcrumb__caption mb-4">REGISTER</h3>
                  <RegisterForm />
                </div>

                {/* Divider */}
                <div
                  className="login-divider d-none d-md-block order-md-2"
                  style={{
                    width: "1px",
                    background: "#939393",
                    margin: "0 10px",
                    minHeight: "240px",
                    alignSelf: "stretch",
                    borderRadius: "2px",
                  }}
                />
                <div
                  className="login-divider d-block d-md-none order-2"
                  style={{
                    minWidth: "240px",
                    background: "#939393",
                    margin: "25px 0px",
                    minHeight: "1px",
                    alignSelf: "stretch",
                    borderRadius: "2px",
                  }}
                />

                {/* LOGIN */}
                <div className="col-12 col-md-5 d-flex flex-column order-1 order-md-3">
                  <h3 className="breadcrumb__caption mb-4">LOGIN</h3>
                  <div className="align-items-start">
                    <div className="tp-login-social mb-10 d-flex flex-wrap gap-2 align-items-start mb-2">
                      <div className="tp-login-option-item has-google">
                        <GoogleSignUp className="w-100 rounded-5" />
                      </div>
                      <button
                        className="btn btn-primary px-5 rounded-1 flex-grow-1"
                        onClick={() => router.push("/checkout?guest=true")}
                      >
                        Guest
                      </button>
                    </div>
                  </div>

                  <div className="d-flex align-items-center my-3 border-top pt-3">
                    <Icon
                      icon="streamline-freehand:move-rectangle-left"
                      width="24"
                      height="20"
                      style={{ color: "#8e8e8e" }}
                    />
                    <p className="mb-0">Or Login Using Email & Password</p>
                  </div>

                  <LoginForm />
                </div>
                {/* /LOGIN */}

              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LoginAreaBody;
