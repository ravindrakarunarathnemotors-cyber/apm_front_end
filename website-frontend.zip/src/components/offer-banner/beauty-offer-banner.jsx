import React, { useMemo } from "react";
import { ArrowRightSmTwo } from "@/svg";
import Link from "next/link";
import { useGetBannerDetailsQuery } from "@/redux/features/brandingSettingsApi";

const slugify = (str) =>
  str ? str.toLowerCase().replace(/&/g, "").split(" ").join("-") : "collection";

const BeautyOfferBanner = ({ sectionId, bgClass }) => {
  const { data: raw, isLoading } = useGetBannerDetailsQuery(sectionId);

  const banner_details = useMemo(() => {
    const d = raw?.data ?? raw;
    return Array.isArray(d) ? d : d ? [d] : [];
  }, [raw]);
  const left = banner_details?.[0] ?? {};
  const right = banner_details?.[1] ?? {};
  if (isLoading) return null; // Or a shimmer loader

  return (
    <section className={`tp-offer-banner-area pt-80 pb-80 ${bgClass || ""}`}>
      <div className="container">
        <div className="row g-4">
          {/* LEFT BANNER - The Hero */}
          <div className="col-xl-7 col-lg-7 col-md-12">
            <div className="offer-banner-item">
              <Link href={`/shop?collection=${slugify(left.name)}`}>
                <div className="banner-inner">
                  <div
                    className="banner-bg-img"
                    style={{ backgroundImage: `url("${left.banner_url}")` }}
                  />
                  <div className="banner-gradient-overlay" />
                  <div className="banner-content-top">
                    <span className="banner-label">New Arrival</span>
                    <h3 className="banner-title-big">
                      {left.name || "Summer Beachwear"}
                    </h3>
                    <div className="banner-btn-wrapper">
                      <span className="tp-btn-white-sm">
                        Discover Now <ArrowRightSmTwo />
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>

          {/* RIGHT BANNER - The Feature */}
          <div className="col-xl-5 col-lg-5 col-md-12">
            <div className="offer-banner-item">
              <Link href={`/shop?collection=${slugify(right.name)}`}>
                <div className="banner-inner">
                  <div
                    className="banner-bg-img"
                    style={{ backgroundImage: `url("${right.banner_url}")` }}
                  />
                  <div className="banner-gradient-overlay" />
                  <div className="banner-content-bottom">
                    <h3 className="banner-title-big">
                      {right.name || "Featured Style"}
                    </h3>
                    <div className="banner-link-text">
                      Shop Collection <ArrowRightSmTwo />
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        
      `}</style>
    </section>
  );
};

export default BeautyOfferBanner;
