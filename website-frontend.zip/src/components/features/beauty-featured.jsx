import React from "react";
import Image from "next/image";
import Link from "next/link";
import { useGetFeaturesProductsQuery } from "@/redux/features/homeApi";
import { slugify } from "@/lib/slugify";

/** ---------- Shimmer Skeleton for modern UX ---------- */
const FeatureSkeleton = () => (
  <div className="skeleton-card-wrap">
    <div className="skeleton-card">
      <div className="skeleton-img pulse"></div>
      <div className="skeleton-line pulse mt-4"></div>
      <div className="skeleton-line pulset mt-2 sm"></div>
      <div className="skeleton-line pulse mt-4 xs"></div>
    </div>
    <style jsx>{`
      .skeleton-card-wrap { padding: 0 15px; margin-bottom: 30px; }
      .skeleton-card { background: #fff; border-radius: 20px; padding: 40px; border: 1px solid #f1f5f9; }
      .skeleton-img { width: 100%; aspect-ratio: 1/1; background: #f8fafc; border-radius: 12px; }
      .skeleton-line { height: 16px; background: #f8fafc; border-radius: 4px; }
      .skeleton-line.sm { width: 60%; }
      .skeleton-line.xs { width: 40%; }
      .pulse { animation: pulse 1.5s infinite ease-in-out; }
      @keyframes pulse { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } }
    `}</style>
  </div>
);

const BeautyFeatured = ({ sectionId, bgClass }) => {
  const { data: featured, isLoading, isError } = useGetFeaturesProductsQuery(sectionId);

  if (!sectionId) return null;

  return (
    <section className={`tp-featured-area pt-110 pb-110 ${bgClass || "bg-white"} overflow-hidden`}>
      <div className="container">
        {/* Modernized Header */}
        <div className="row justify-content-center mb-60">
          <div className="col-xl-8 col-lg-10 text-center">
            <div className="tp-section-title-wrapper-3">
              <span className="tp-section-title-pre-3" style={{ color: '#0984e3', fontWeight: '600', letterSpacing: '1px', textTransform: 'uppercase', fontSize: '12px' }}>
                Handpicked for You
              </span>
              <h2 className="tp-section-title-3 capitalize mt-10" style={{ fontSize: 'clamp(32px, 4.5vw, 48px)', fontWeight: '800' }}>
                Trending Highlights
              </h2>
            </div>
          </div>
        </div>

        {/* Dynamic Features Grid */}
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-5">
          {isLoading ? (
            <>
              <FeatureSkeleton />
              <FeatureSkeleton />
              <FeatureSkeleton />
            </>
          ) : isError ? (
            <div className="col-12 text-center py-5">
              <p className="text-muted fs-6">Unable to load features. Please check back later.</p>
            </div>
          ) : (
            featured?.slice(0, 3).map((item, idx) => {
              const title = item.title || item.product_name || item.name || "Product";
              const href = `/product/${slugify(title)}-${item.product_id}`;
              const imgSrc = item.media_url || "/assets/img/shop/product-default.jpg";
              const desc = item.search_engine_desc || "";

              return (
                <div key={item.product_id} className="col">
                  <div className="feature-card-premium" style={{ "--delay": `${idx * 0.15}s` }}>
                    <Link href={href} className="feature-card-link">
                      {/* Image Container with Float Effect */}
                      <div className="feature-img-wrapper">
                        <div className="feature-img-box">
                          <Image
                            src={imgSrc}
                            width={400}
                            height={400}
                            alt={title}
                            priority={idx < 3}
                            className="feature-img"
                            style={{ objectFit: "contain" }}
                          />
                        </div>
                        {/* Translucent Modern Tag */}
                      </div>
                        <span className="feature-status-tag">
                          New Trend
                        </span>

                      {/* Content Area */}
                      <div className="feature-content-modern mt-35">
                        <h3 className="feature-card-title">{title}</h3>
                        <p className="feature-card-desc">{desc}</p>
                        
                        {/* Interactive Explore Link */}
                        <div className="feature-action-modern">
                          <span className="explore-txt">Explore Product</span>
                          <span className="explore-line"></span>
                        </div>
                      </div>
                    </Link>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </section>
  );
};

export default BeautyFeatured;