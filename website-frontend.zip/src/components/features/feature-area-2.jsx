import React, { useMemo } from 'react';
import { useGetFeatureAreaDetailsQuery } from '@/redux/features/brandingSettingsApi';

const FeatureAreaTwo = ({ sectionId, bgClass }) => {
  const { data, isLoading, isError } = useGetFeatureAreaDetailsQuery(sectionId);

  // Memoize normalization to prevent unnecessary re-renders during scroll
  const features = useMemo(() => {
    const rawData = data?.data ?? data;
    return Array.isArray(rawData) ? rawData : [];
  }, [data]);

  // Loading Skeleton for better UX
  if (isLoading) {
    return (
      <div className={`py-60 ${bgClass}`}>
        <div className="container">
          <div className="row g-4">
            {features.map((i) => (
              <div key={i} className="col-lg-3 col-md-6">
                <div className="feature-skeleton" />
              </div>
            ))}
          </div>
        </div>
        <style jsx>{`
          .feature-skeleton {
            height: 100px;
            background: linear-gradient(90deg, #f0f0f0 25%, #f8f8f8 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: loading 1.5s infinite;
            border-radius: 16px;
          }
          @keyframes loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
          }
        `}</style>
      </div>
    );
  }

  if (isError || features.length === 0) return null;

  return (
    <section className={`tp-feature-area-modern py-60 ${bgClass || 'bg-white'}`}>
      <div className="container">
        <div className="row g-4 justify-content-center">
          {features.map((item, i) => (
            <div 
              key={i} 
              className="col-xl-3 col-lg-3 col-md-6 col-sm-6"
            >
              <div className="feature-card-modern">
                <div className="icon-wrapper">
                  <div className="icon-halo" />
                  <img
                    src={item.icon_url || '/assets/img/icon/default-feature.png'}
                    alt={item.title}
                    loading="lazy"
                  />
                </div>
                <div className="feature-text">
                  <h3 className="feature-title">{item.title}</h3>
                  {item.description && <p className="feature-desc">{item.description}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureAreaTwo;