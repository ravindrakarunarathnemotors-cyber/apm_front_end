import React, { useEffect, useRef, useState } from "react";
import { Rating } from "react-simple-star-rating";
import { useDispatch } from "react-redux";
import { AskQuestion, CompareTwo, WishlistTwo } from "@/svg";
import ProductDetailsCountdown from "./product-details-countdown";
import ProductQuantity from "./product-quantity";
import { add_cart_product } from "@/redux/features/cartSlice";
import { add_to_wishlist } from "@/redux/features/wishlist-slice";
import { add_to_compare } from "@/redux/features/compareSlice";
import { handleModalClose } from "@/redux/features/productModalSlice";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import {
  useGetoneProductDiscountMutation,
  useGetProductQuantityMutation,
} from "@/redux/features/productApi";
import { notifyError } from "@/utils/toast";
import Link from "next/link";
import InfoCircle from "@/svg/info-circle";
import DiscountTooltip from "./DiscountTooltip";
import ProductMeasurementQyantity from "./product-measurement-quantity";
import { useKoko } from "@/context/KokoContext";

/** ✅ Robustly resolve a variant-specific image URL */
const getVariantImageUrl = (v, productItem) => {
  if (!v) return null;

  // direct fields on variant
  if (v.media_url) return v.media_url;
  if (v.image_url) return v.image_url;
  if (v.imageURL) return v.imageURL;

  // mapping object, if your API provides { [variant_id]: { media_url } }
  if (productItem?.variant_media && v.variant_id) {
    const maybe = productItem.variant_media[v.variant_id];
    if (maybe?.media_url) return maybe.media_url;
  }

  // 🔥 look up from other_images by variant_id (prefers main: true)
  if (Array.isArray(productItem?.other_images) && v.variant_id) {
    const matches = productItem.other_images.filter(
      (img) => img?.variant_id === v.variant_id && img?.media_url,
    );
    if (matches.length) {
      const mainOne = matches.find((m) => m?.main === true);
      return (mainOne || matches[0]).media_url;
    }
  }

  return null;
};

const getFallbackProductImage = (productItem) => {
  if (productItem?.media_url) return productItem.media_url;
  if (productItem?.other_images?.[0]?.media_url)
    return productItem.other_images[0].media_url;
  return "/assets/img/shop/product-default.jpg";
};

const DetailsWrapper = ({
  productItem,
  variant,
  handleImageActive,
  activeImg,
  detailsBottom = false,
  oneReview,
  oneproduct_id,
}) => {
  const {
    sku,
    product_id,
    title,
    description,
    discount,
    price,
    status,
    reviews,
    tags,
    offerDate,
    measurement_needed,
    measurement_value,
    amount_per_unit,
  } = productItem || {};

  const [ratingVal, setRatingVal] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [checkingStock, setCheckingStock] = useState(false);
  const [stockError, setStockError] = useState("");
  const [showTerms, setShowTerms] = useState(false);
  const [count, setCount] = useState(0);
  const { koko, kokoFee } = useKoko();
  const dispatch = useDispatch();
  const symbol = useCurrencySymbol();
  const [getProductQuantity] = useGetProductQuantityMutation();
  const descriptionRef = useRef(null);

  const [getoneProductDiscount, { data: discounts }] =
    useGetoneProductDiscountMutation();

  const {
    has_discount = false,
    discount_amount = 0,
    discount_type = null,
    free_count = 0,
    buy_count = 0,
    discount_details = {},
  } = discounts ?? {};

  const compare_price = has_discount
    ? parseFloat(price) - parseFloat(discount_amount) || 0
    : 0;

  useEffect(() => {
    if (oneReview > 0) {
      setRatingVal(oneReview);
    }
  }, [oneReview]);

  useEffect(() => {
    if (oneproduct_id) {
      getoneProductDiscount(oneproduct_id);
    }
  }, [oneproduct_id]);

  useEffect(() => {
    if (!variant || variant.length === 0) return;

    if (variant.length === 1) {
      const onlyVariant = variant[0];
      setSelectedVariant(onlyVariant);

      // ✅ also populate selectedOptions automatically
      const types = onlyVariant.variant_type?.split(" / ") || [];
      const values = onlyVariant.variant_value?.split(" / ") || [];
      const opts = {};
      types.forEach((t, i) => {
        if (t && values[i]) opts[t] = values[i];
      });
      setSelectedOptions(opts);

      // ✅ show image immediately
      const url = getVariantImageUrl(onlyVariant, productItem);
      const fallback = getFallbackProductImage(productItem);
      handleImageActive({ img: url || fallback });
    }
  }, [variant, productItem]);

  useEffect(() => {
    setCount(amount_per_unit);
  }, [amount_per_unit]);

  // Extract options from variants
  const extractVariantOptions = (variants) => {
    const optionsMap = {};
    variants?.forEach((v) => {
      const types = v.variant_type?.split(" / ") || [];
      const values = v.variant_value?.split(" / ") || [];
      types.forEach((type, index) => {
        if (!optionsMap[type]) optionsMap[type] = new Set();
        if (values[index]) optionsMap[type].add(values[index]);
      });
    });
    const finalOptions = {};
    for (const key in optionsMap) {
      finalOptions[key] = Array.from(optionsMap[key]);
    }
    return finalOptions;
  };
  const variantOptions = extractVariantOptions(variant || []);

  // Find the matching variant based on current selections
  const matchVariant = (options) => {
    if (!variant) return;
    const matched = variant.find((v) => {
      const types = v.variant_type.split(" / ");
      const values = v.variant_value.split(" / ");
      return types.every((type, idx) => options[type] === values[idx]);
    });

    setSelectedVariant(matched || null);
    setStockError("");
    setQuantity(1);

    // ✅ When a variant is selected, switch to that variant's image
    if (matched) {
      const url = getVariantImageUrl(matched, productItem);
      const fallback = getFallbackProductImage(productItem);
      handleImageActive({ img: url || fallback });
    }
  };

  // helper: given a partial selection, find the first compatible variant
  const findCompatibleVariant = (partialOptions) => {
    if (!variant) return null;

    return variant.find((v) => {
      const types = v.variant_type?.split(" / ") || [];
      const values = v.variant_value?.split(" / ") || [];

      // must match all keys that are already selected
      return Object.entries(partialOptions).every(([key, val]) => {
        const idx = types.indexOf(key);
        if (idx === -1) return false;
        return values[idx] === val;
      });
    });
  };

  // When any dropdown changes
  const handleOptionSelect = (type, value) => {
    setSelectedOptions((prev) => {
      // 1) update the changed option
      const partial = { ...prev, [type]: value };

      // 2) find a variant that matches the currently selected options
      const candidate = findCompatibleVariant(partial);

      // 3) if we found one, auto-fill any missing options from that variant
      let completed = partial;
      if (candidate) {
        const types = candidate.variant_type?.split(" / ") || [];
        const values = candidate.variant_value?.split(" / ") || [];

        completed = { ...partial };
        types.forEach((t, i) => {
          if (!completed[t]) {
            completed[t] = values[i]; // auto-select this value
          }
        });
      }

      // 4) use the completed selection to pick the variant & image
      matchVariant(completed);

      return completed;
    });
  };

  // For quantity plus/minus buttons
  const allowOOS = selectedVariant?.continue_selling_oos === true;
  const maxQty = allowOOS
    ? 999
    : Number(selectedVariant?.current_quantity) || 0;

  const disableAddButton =
    !selectedVariant ||
    (!selectedVariant.continue_selling_oos &&
      selectedVariant.current_quantity <= 0);

  const handleQuantityChange = (val) => {
    if (!selectedVariant) {
      setQuantity(1);
      return;
    }
    const maxQtyCalc = allowOOS
      ? 999
      : Number(selectedVariant?.current_quantity) || 0;
    if (!allowOOS && val > maxQtyCalc) {
      setQuantity(maxQtyCalc);
      setStockError(`You can only buy up to ${maxQtyCalc} in stock.`);
    } else if (val < 1) {
      setQuantity(1);
      setStockError("");
    } else {
      setQuantity(val);
      setStockError("");
    }
  };

  // Add to Cart
  const handleAddProduct = async () => {
    setStockError("");
    if (!allOptionsSelected || !selectedVariant) {
      notifyError("Please select all options");
      if (missingKeys.length > 0) {
        setStockError("Please select these: " + missingKeys.join(", "));
      }
      return;
    }
    if (quantity < 1) {
      setStockError("Please select at least 1 item.");
      return;
    }

    if (selectedVariant?.continue_selling_oos) {
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available: Number(selectedVariant.current_quantity) || 0,
        }),
      );
      setStockError("");
      return;
    }

    setCheckingStock(true);
    try {
      const res = await getProductQuantity(selectedVariant.variant_id).unwrap();
      const available = Number(res.new_quantity) || 0;

      if (available == 0) {
        setStockError(`Not available right now!`);
        notifyError(`Not available right now!`);
        setCheckingStock(false);
        return;
      }
      if (quantity > available) {
        setStockError(
          `Oops! We’re running low on this item. Only ${available} left.`,
        );
        setCheckingStock(false);
        return;
      }
      console.log("productItem", productItem);
      console.log("selectedVariant", selectedVariant);
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available,
        }),
      );
      setStockError("");
    } catch (err) {
      setStockError("Not available right now!");
      notifyError("Not available right now!");
    }
    setCheckingStock(false);
  };

  const handleAddProductmes = async () => {
    setStockError("");
    if (!allOptionsSelected || !selectedVariant) {
      notifyError("Please select all options");
      if (missingKeys.length > 0) {
        setStockError("Please select these: " + missingKeys.join(", "));
      }
      return;
    }

    console.log("check add product");

    if (selectedVariant?.continue_selling_oos) {
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available: Number(selectedVariant.current_quantity) || 0,
          count,
        }),
      );
      setStockError("");
      return;
    }

    setCheckingStock(true);
    try {
      const res = await getProductQuantity(selectedVariant.variant_id).unwrap();
      const available = Number(res.new_quantity) || 0;

      if (available == 0) {
        setStockError(`Not available right now!`);
        notifyError(`Not available right now!`);
        setCheckingStock(false);
        return;
      }
      if (count > available) {
        setStockError(
          `Oops! We’re running low on this item. Only ${available}${measurement_value} left.`,
        );
        setCheckingStock(false);
        return;
      }
      console.log("productItem", productItem);
      console.log("selectedVariant", selectedVariant);
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available,
          count,
        }),
      );
      setStockError("");
    } catch (err) {
      setStockError("Not available right now!");
      notifyError("Not available right now!");
    }
    setCheckingStock(false);
  };

  // Buy Now
  const handleBuyNow = async (e) => {
    e.preventDefault();
    setStockError("");

    if (!allOptionsSelected || !selectedVariant) {
      notifyError("Please select all options");
      if (missingKeys.length > 0) {
        setStockError("Please select these: " + missingKeys.join(", "));
      }
      return;
    }

    if (quantity < 1) {
      setStockError("Please select at least 1 item.");
      return;
    }

    if (selectedVariant?.continue_selling_oos) {
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          quantity,
          available: Number(selectedVariant.current_quantity) || 0,
        }),
      );
      dispatch(handleModalClose());
      window.location.href = "/cart";
      return;
    }

    setCheckingStock(true);
    try {
      const res = await getProductQuantity(selectedVariant.variant_id).unwrap();
      const available = Number(res.new_quantity) || 0;

      if (available == 0) {
        setStockError(`Not available right now!`);
        notifyError(`Not available right now!`);
        setCheckingStock(false);
        return;
      }
      if (quantity > available) {
        setStockError(
          `Oops! We’re running low on this item. Only ${available} left.`,
        );
        notifyError(
          `Oops! We’re running low on this item. Only ${available} left.`,
        );
        setCheckingStock(false);
        return;
      }
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          quantity,
          available,
        }),
      );
      dispatch(handleModalClose());
      window.location.href = "/cart";
    } catch (err) {
      setStockError("Not available right now!");
      notifyError("Not available right now!");
    }
    setCheckingStock(false);
  };
  const handleBuyNowMes = async (e) => {
    e.preventDefault();
    setStockError("");

    if (!allOptionsSelected || !selectedVariant) {
      notifyError("Please select all options");
      if (missingKeys.length > 0) {
        setStockError("Please select these: " + missingKeys.join(", "));
      }
      return;
    }

    if (selectedVariant?.continue_selling_oos) {
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available: Number(selectedVariant.current_quantity) || 0,
          count,
        }),
      );
      dispatch(handleModalClose());
      window.location.href = "/cart";
      return;
    }

    setCheckingStock(true);
    try {
      const res = await getProductQuantity(selectedVariant.variant_id).unwrap();
      const available = Number(res.new_quantity) || 0;

      if (available == 0) {
        setStockError(`Not available right now!`);
        notifyError(`Not available right now!`);
        setCheckingStock(false);
        return;
      }
      if (count > available) {
        setStockError(
          `Oops! We’re running low on this item. Only ${available}${measurement_value} left.`,
        );
        notifyError(
          `Oops! We’re running low on this item. Only ${available}${measurement_value} left.`,
        );
        setCheckingStock(false);
        return;
      }
      dispatch(
        add_cart_product({
          ...productItem,
          ...selectedVariant,
          ...discounts,
          quantity,
          available,
          count,
        }),
      );
      dispatch(handleModalClose());
      window.location.href = "/cart";
    } catch (err) {
      setStockError("Not available right now!");
      notifyError("Not available right now!");
    }
    setCheckingStock(false);
  };

  // Wishlist & Compare
  const handleWishlistProduct = (prd) => dispatch(add_to_wishlist(prd));
  const handleCompareProduct = (prd) => dispatch(add_to_compare(prd));

  // Strip HTML
  const stripHtml = (html) => {
    if (typeof window !== "undefined") {
      const doc = new DOMParser().parseFromString(html, "text/html");
      return doc.body.textContent || "";
    }
    return "";
  };

  // See More
  const handleSeeMoreClick = (e) => {
    e.preventDefault();
    if (typeof window === "undefined") return;
    const tabBtn = document.getElementById("nav-desc-tab");
    if (tabBtn) tabBtn.click();
    const target = document.getElementById("nav-desc");
    if (target) {
      const headerOffset = 180;
      const y =
        target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
      window.scrollTo({ top: y, behavior: "smooth" });
    }
  };

  // Preview
  const descriptionPreview = stripHtml(description || "");
  const preview =
    descriptionPreview.length > 100
      ? descriptionPreview.slice(0, 100) + "..."
      : descriptionPreview;

  // Disable logic
  const allOptionsSelected =
    Object.keys(variantOptions).length > 0 &&
    Object.keys(selectedOptions).length === Object.keys(variantOptions).length;

  const isOutOfStock =
    !(selectedVariant?.continue_selling_oos === true) &&
    selectedVariant &&
    Number(selectedVariant.current_quantity) <= 0;

  const missingKeys = Object.keys(variantOptions).filter(
    (key) => !(key in selectedOptions),
  );

  return (
    <div className="tp-product-details-wrapper word-break">
      <div className="tp-product-details-category"></div>
      <div className="d-none d-lg-block">
        <h3 className="tp-product-details-title capitalize">{title}</h3>
        <h6
          style={{
            fontSize: "10px",
            color: "#c1c0c0",
            fontWeight: 500,
            fontWeight: 500,
            textTransform: "uppercase",
            display: "flex",
            gap: "5px",
            alignItem: "flex-end",
          }}
        >
          <span
            className=" px-2 rounded-3 "
            style={{
              backgroundColor: "#b8b8b8",
              padding: "1px 10px",
              color: "white",
            }}
          >
            Product Id - {product_id}
          </span>{" "}
        </h6>
      </div>

      {/* Description Preview */}
      <div
        style={{
          fontSize: 15,
          marginBottom: 4,
          wordBreak: "break-word",
          overflowWrap: "break-word",
          whiteSpace: "normal",
        }}
      >
        {preview}
        {descriptionPreview.length > 100 && (
          <>
            {" "}
            <a
              href="#nav-desc"
              style={{ color: "#007bff", cursor: "pointer", fontWeight: 500 }}
              onClick={handleSeeMoreClick}
            >
              See more
            </a>
          </>
        )}
      </div>

      {/* price */}
      <div className="tp-product-details-price-wrapper mb-1 mt-3 d-flex align-items-center">
        {selectedVariant ? (
          <>
            {has_discount && discount_type == "product" && (
              <span
                className="tp-product-details-price old-price me-2 ms-0"
                style={{ fontSize: "24px" }}
              >
                {symbol} {parseFloat(selectedVariant.price).toFixed(2)}
              </span>
            )}
            <span className="tp-product-details-price new-price me-2 ms-0">
              {symbol}
            </span>
            {has_discount && discount_type == "product" && (
              <span className="tp-product-details-price new-price">
                {(
                  parseFloat(selectedVariant.price) -
                  parseFloat(discount_amount)
                ).toFixed(2)}
              </span>
            )}
            {(!has_discount ||
              (has_discount && discount_type == "buyxgety")) && (
              <span className="tp-product-details-price new-price">
                {parseFloat(selectedVariant.price).toFixed(2)}
              </span>
            )}
          </>
        ) : (
          <>
            {has_discount && discount_type == "product" && (
              <span
                className="tp-product-details-price old-price me-2"
                style={{}}
              >
                {symbol} {parseFloat(price).toFixed(2)}
              </span>
            )}
            <span className="tp-product-details-price new-price me-2">
              {symbol}
            </span>
            {/* <span className="tp-product-details-price new-price">
              {parseFloat(price).toFixed(2)}c
            </span> */}
            {has_discount && discount_type == "product" && (
              <span className="tp-product-details-price new-price">
                {parseFloat(compare_price).toFixed(2)}
              </span>
            )}
            {(!has_discount ||
              (has_discount && discount_type == "buyxgety")) && (
              <span className="tp-product-details-price new-price">
                {parseFloat(price).toFixed(2)}
              </span>
            )}
          </>
        )}
      </div>
      {/* Koko Installment Section */}
      {/* Koko Installment Section */}
      {koko === true && kokoFee && (
        <div
          className="mt-0 pb-2 mb-3 d-flex align-items-center"
          style={{ gap: "5px", fontSize: "13px" }}
        >
          <span style={{ color: "#777" }}>pay in 3 x</span>
          <span className="fw-semibold" style={{ color: "#000" }}>
            {symbol}{" "}
            {(() => {
              // Use selectedVariant price if available, otherwise fallback to base product price
              const currentPrice = selectedVariant
                ? parseFloat(selectedVariant.price)
                : parseFloat(price);

              const basePrice =
                (currentPrice || 0) - (parseFloat(discount_amount) || 0);

              const fixedFee = parseFloat(kokoFee.transaction_fixed_fee) || 0;

              // Ensure this key matches your context (you used transaction_fee here but koko_percent_fee earlier)
              const percentFee =
                parseFloat(
                  kokoFee.transaction_fee || kokoFee.koko_percent_fee,
                ) || 0;

              const totalPercentAmount = (basePrice * percentFee) / 100;
              const grandTotal = basePrice + fixedFee + totalPercentAmount;

              return (grandTotal / 3).toFixed(2);
            })()}
          </span>
          <span style={{ color: "#777" }}>with</span>

          <img
            src="/assets/img/koko.png"
            alt="Koko"
            style={{
              height: "18px",
              marginLeft: "2px",
              verticalAlign: "middle",
            }}
          />
        </div>
      )}
      {has_discount && discount_type == "buyxgety" && (
        <div className="mb-3 d-flex align-items-center gap-2">
          <div
            className="badge rounded-pill text-bg-success align-items-center px-2 py-1"
            style={{ fontSize: "10px" }}
          >
            <i class="fa-solid fa-tags fa-fade me-1"></i>
            BUY {buy_count} GET {free_count} FREE !
          </div>

          <DiscountTooltip discount_details={discount_details} />
        </div>
      )}
      {has_discount && discount_type == "product" && (
        <div className="mb-3 d-flex align-items-center gap-2">
          <div
            className="badge rounded-pill text-bg-danger align-items-center px-2 py-1 "
            style={{ fontSize: "10px" }}
          >
            {/* <i class="fa-light fa-tags me-1"></i> */}
            <i class="fa-regular fa-fire fa-fade me-1"></i>
            Save {symbol} {parseFloat(discount_amount).toFixed(2)}
          </div>
          <DiscountTooltip discount_details={discount_details} />
        </div>
      )}

      {/* variations - dropdown style */}
      {variant && variant?.length > 1 && (
        <>
          {Object.keys(variantOptions).map((type) => (
            <div key={type} className="tp-product-details-variation mb-2">
              <div className="tp-product-details-variation-item d-flex gap-2 align-items-center">
                <label
                  className="tp-product-details-variation-title capitalize mb-1 "
                  style={{ width: "100px" }}
                  htmlFor={`variant-select-${type}`}
                >
                  {type}:
                </label>
                <select
                  id={`variant-select-${type}`}
                  className="form-select form-select-sm w-auto d-inline-block rounded-4 w-100"
                  value={selectedOptions[type] || ""}
                  onChange={(e) => handleOptionSelect(type, e.target.value)}
                >
                  <option value="" disabled>
                    Select {type}
                  </option>
                  {variantOptions[type].map((value) => (
                    <option key={value} value={value}>
                      {value}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </>
      )}

      {selectedVariant &&
        (() => {
          if (selectedVariant.continue_selling_oos) return null;

          const inStock = Number(selectedVariant.current_quantity) > 0;

          return (
            <div className="mb-4 p-2 bg-light rounded-3 shadow-sm my-1">
              {inStock ? "Available" : "⛔ Out of stock"}
            </div>
          );
        })()}

      {/* Countdown */}
      {offerDate?.endDate && (
        <ProductDetailsCountdown offerExpiryTime={offerDate?.endDate} />
      )}

      {/* Actions */}
      <div className="tp-product-details-action-wrapper">
        <h3 className="tp-product-details-action-title mt-4">
          {measurement_needed
            ? `Per  ${amount_per_unit || 0}${measurement_value} `
            : "Quantity"}
        </h3>

        {measurement_needed ? (
          <div className="tp-product-details-action-item-wrapper d-sm-flex align-items-center">
            <ProductMeasurementQyantity
              value={amount_per_unit}
              setCount={setCount}
              count={count}
              min={parseFloat(amount_per_unit)}
            />
            <div className="tp-product-details-add-to-cart mb-15 w-100">
              <button
                onClick={handleAddProductmes}
                disabled={checkingStock || disableAddButton}
                className="tp-product-details-add-to-cart-btn w-100"
              >
                {checkingStock ? "Checking..." : "Add To Cart"}
              </button>
            </div>
          </div>
        ) : (
          <div className="tp-product-details-action-item-wrapper d-sm-flex align-items-center">
            <ProductQuantity
              value={quantity}
              setValue={handleQuantityChange}
              min={1}
              max={maxQty}
              disabled={!selectedVariant || isOutOfStock}
            />
            <div className="tp-product-details-add-to-cart mb-15 w-100">
              <button
                onClick={handleAddProduct}
                disabled={checkingStock || quantity === 0}
                className="tp-product-details-add-to-cart-btn w-100"
              >
                {checkingStock ? "Checking..." : "Add To Cart"}
              </button>
            </div>
          </div>
        )}

        {measurement_needed ? (
          <button
            className="tp-product-details-buy-now-btn w-100"
            disabled={checkingStock || isOutOfStock}
            onClick={handleBuyNowMes}
          >
            {checkingStock ? "Checking..." : "Buy Now"}
          </button>
        ) : (
          <button
            className="tp-product-details-buy-now-btn w-100"
            disabled={checkingStock || quantity === 0}
            onClick={handleBuyNow}
          >
            {checkingStock ? "Checking..." : "Buy Now"}
          </button>
        )}

        {stockError && (
          <div className="alert alert-danger mt-2">{stockError}</div>
        )}
      </div>

      {/* product-details-action-sm */}
      <div className="tp-product-details-action-sm d-flex flex-wrap align-items-end">
        <div className="tp-product-details-rating">
          <Rating
            allowFraction
            size={20}
            initialValue={ratingVal}
            readonly={true}
          />
        </div>
        <button
          disabled={status === "out-of-stock"}
          onClick={() => handleCompareProduct(productItem)}
          type="button"
          className="tp-product-details-action-sm-btn mb-0"
        >
          <CompareTwo />
          Compare
        </button>
        <button
          disabled={status === "out-of-stock"}
          onClick={() => handleWishlistProduct(productItem)}
          type="button"
          className="tp-product-details-action-sm-btn mb-0"
        >
          <WishlistTwo />
          Add Wishlist
        </button>
        <Link href="/contact">
          <button
            type="button"
            className="tp-product-details-action-sm-btn mb-0"
          >
            <AskQuestion />
            Ask a question
          </button>
        </Link>
      </div>
    </div>
  );
};

export default DetailsWrapper;
