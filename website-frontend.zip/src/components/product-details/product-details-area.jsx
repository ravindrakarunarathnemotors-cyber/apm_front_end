import React, { useState, useEffect, useCallback } from "react";
import DetailsThumbWrapper from "./details-thumb-wrapper";
import DetailsWrapper from "./details-wrapper";
import { useDispatch } from "react-redux";
import DetailsTabNav from "./details-tab-nav";
import RelatedProducts from "./related-products";

function getMainImage(productItem) {
  // Prefer product-level main; else first other image; else default
  if (productItem?.media_url) return productItem.media_url;
  if (productItem?.other_images?.[0]?.media_url)
    return productItem.other_images[0].media_url;
  return "/assets/img/shop/product-default.jpg";
}

const ProductDetailsArea = ({ productItem, variant, product_id, oneReview }) => {
  const { imageURLs, videoId, status } = productItem || {};
  const [activeImg, setActiveImg] = useState(getMainImage(productItem));
  const dispatch = useDispatch();

  // Reset main image when product changes
  useEffect(() => {
    setActiveImg(getMainImage(productItem));
  }, [productItem]);

  // Centralized image setter (thumbnails & variant changes both call this)
  const handleImageActive = useCallback((item) => {
    if (item?.img) setActiveImg(item.img);
  }, []);

  return (
    <section className="tp-product-details-area">
      <div className="tp-product-details-top pb-115">
        <div className="container">
          <div className="row">
            <div className="col-xl-7 col-lg-6">
              {/* product-details-thumb-wrapper */}
              <DetailsThumbWrapper
                activeImg={activeImg}
                productItem={productItem}
                handleImageActive={handleImageActive}
                imageURLs={imageURLs}
                imgWidth={580}
                imgHeight={580}
                videoId={videoId}
                status={status}
              />
            </div>
            <div className="col-xl-5 col-lg-6">
              {/* product-details-wrapper */}
              <DetailsWrapper
                productItem={productItem}
                variant={variant}
                handleImageActive={handleImageActive}
                activeImg={activeImg}
                detailsBottom={true}
                oneReview={oneReview}
                oneproduct_id={product_id}
              />
            </div>
          </div>
        </div>
      </div>

      {/* product details description */}
      <div className="tp-product-details-bottom pb-140">
        <div className="container">
          <div className="row">
            <div className="col-xl-12">
              <DetailsTabNav product={productItem} />
            </div>
          </div>
        </div>
      </div>

      {/* related products */}
      <section className="tp-related-product pt-95 pb-50">
        <div className="container">
          <div className="row">
            <div className="tp-section-title-wrapper-6 text-center mb-40">
              <h3 className="tp-section-title-6 mb-2">Related Products</h3>
            </div>
          </div>
          <div className="row">
            <RelatedProducts id={product_id} />
          </div>
        </div>
      </section>
    </section>
  );
};

export default ProductDetailsArea;











// import React, { useState, useEffect, useCallback } from "react";
// import DetailsThumbWrapper from "./details-thumb-wrapper";
// import DetailsWrapper from "./details-wrapper";
// import { useDispatch } from "react-redux";
// import DetailsTabNav from "./details-tab-nav";
// import RelatedProducts from "./related-products";

// function getMainImage(productItem) {
//   if (productItem?.media_url) return productItem.media_url;
//   if (productItem?.other_images?.[0]?.media_url)
//     return productItem.other_images[0].media_url;
//   return "/assets/img/shop/product-default.jpg";
// }

// const ProductDetailsArea = ({ productItem, variant, product_id }) => {
//   const { imageURLs, videoId, status } = productItem || {};
//   const [activeImg, setActiveImg] = useState(getMainImage(productItem));

//   const dispatch = useDispatch();

//   // Reset main image when product changes
//   useEffect(() => {
//     setActiveImg(getMainImage(productItem));
//   }, [productItem]);

//   // Centralized image setter (thumbnails & variant changes both call this)
//   const handleImageActive = useCallback((item) => {
//     // item should be { img: <url> }
//     if (item?.img) setActiveImg(item.img);
//   }, []);

//   return (
//     <section className="tp-product-details-area">
//       <div className="tp-product-details-top pb-115">
//         <div className="container">
//           <div className="row">
//             <div className="col-xl-7 col-lg-6">
//               {/* product-details-thumb-wrapper start */}
//               <DetailsThumbWrapper
//                 activeImg={activeImg}
//                 productItem={productItem}
//                 handleImageActive={handleImageActive}
//                 imageURLs={imageURLs}
//                 imgWidth={580}
//                 imgHeight={580}
//                 videoId={videoId}
//                 status={status}
//               />
//               {/* product-details-thumb-wrapper end */}
//             </div>
//             <div className="col-xl-5 col-lg-6">
//               {/* product-details-wrapper start */}
//               <DetailsWrapper
//                 productItem={productItem}
//                 variant={variant}
//                 handleImageActive={handleImageActive}
//                 activeImg={activeImg}
//                 detailsBottom={true}
//               />
//               {/* product-details-wrapper end */}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* product details description */}
//       <div className="tp-product-details-bottom pb-140">
//         <div className="container">
//           <div className="row">
//             <div className="col-xl-12">
//               <DetailsTabNav product={productItem} />
//             </div>
//           </div>
//         </div>
//       </div>
//       {/* product details description */}

//       {/* related products start */}
//       <section className="tp-related-product pt-95 pb-50">
//         <div className="container">
//           <div className="row">
//             <div className="tp-section-title-wrapper-6 text-center mb-40">
//               <span className="tp-section-title-pre-6">Next day Products</span>
//               <h3 className="tp-section-title-6">Related Products</h3>
//             </div>
//           </div>
//           <div className="row">
//             <RelatedProducts id={product_id} />
//           </div>
//         </div>
//       </section>
//       {/* related products end */}
//     </section>
//   );
// };

// export default ProductDetailsArea;




