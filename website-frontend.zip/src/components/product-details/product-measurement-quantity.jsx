import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// internal
import { Minus, Plus } from '@/svg';
import { decrement, increment } from '@/redux/features/cartSlice';

const ProductMeasurementQyantity = ({ value, min, count, setCount }) => {
   
    const [orderQuantity, setOrderQuantity] = useState(1)

    const dispatch = useDispatch();

    // handleIncrease
    const handleIncrease = () => {
        setCount((prev) => prev + value)
    };
    // handleDecrease
    const handleDecrease = () => {
        if (count > value) {
            setCount((prev) => prev - value)
        }
    };

   
    return (
        <div className="tp-product-details-quantity">
            <div className="tp-product-quantity-two mb-15 mr-15 rounded-3 overflow-hidden">
                <span className="tp-cart-minus" onClick={handleDecrease}>
                    <Minus />
                </span>
                <input className="tp-cart-input-mes" type="text" readOnly value={count} />
                <span className="tp-cart-plus" onClick={handleIncrease}>
                    <Plus />
                </span>
            </div>
        </div>
    )
}

export default ProductMeasurementQyantity