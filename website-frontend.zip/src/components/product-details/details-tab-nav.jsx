import React, { useRef, useEffect } from "react";
import ReviewForm from "../forms/review-form";
import ReviewItem from "./review-item";
import { useGetProductReviewsQuery } from "@/redux/features/productApi";

const DetailsTabNav = ({ product }) => {
  const { description = "" } = product || {};
  const activeRef = useRef(null);
  const marker = useRef(null);

  // ✅ Fetch reviews once here
  const {
    data: reviews = [],
    isLoading: isLoadingReviews,
    isError,
    refetch,
  } = useGetProductReviewsQuery(product?.product_id, {
    skip: !product?.product_id,
  });

  const reviewCount = isLoadingReviews ? null : reviews.length;
  const reviewTitle = `Review${
    reviewCount !== null ? ` (${reviewCount})` : ""
  }`;

  const prepareDescriptionHtml = (html) => {
    if (!html) return "";

    // Parse HTML using browser DOMParser
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    // Modify all <img> tags
    doc.querySelectorAll("img").forEach((img) => {
      // Set width and height (adjust to your requirements)
      img.style.maxWidth = "100%";
      img.style.width = "600px"; // 👈 your desired width
      img.style.height = "auto"; // keep aspect ratio
      img.loading = "lazy"; // better performance
      img.style.objectFit = "contain";
      img.style.display = "block";
      img.style.border = "1px solid #ddd";
      img.style.borderRadius = "10px";

      img.style.margin = "15px 0";
    });

    // return cleaned HTML string
    return doc.body.innerHTML;
  };

  const moveMarkerTo = (el) => {
    if (!el || !marker.current) return;
    marker.current.style.left = el.offsetLeft + "px";
    marker.current.style.width = el.offsetWidth + "px";
  };

  const handleActive = (e) => {
    // move immediately on click
    moveMarkerTo(e.currentTarget);
  };

  useEffect(() => {
    if (activeRef.current) {
      moveMarkerTo(activeRef.current);
    }
  }, []);

  function NavItem({ active = false, id, title, linkRef }) {
    return (
      <button
        ref={linkRef}
        className={`nav-link ${active ? "active" : ""}`}
        id={`nav-${id}-tab`}
        data-bs-toggle="tab"
        data-bs-target={`#nav-${id}`}
        type="button"
        role="tab"
        aria-controls={`nav-${id}`}
        aria-selected={active ? "true" : "false"}
        tabIndex={-1}
        onClick={handleActive}
      >
        {title}
      </button>
    );
  }

  return (
    <div className="tp-product-details-tab-nav tp-tab">
      <nav>
        <div
          className="nav nav-tabs justify-content-center p-relative tp-product-tab"
          id="navPresentationTab"
          role="tablist"
        >
          <NavItem active linkRef={activeRef} id="desc" title="Description" />
          <NavItem id="review" title={reviewTitle} />
          <span
            ref={marker}
            id="productTabMarker"
            className="tp-product-details-tab-line"
          />
        </div>
      </nav>

      <div className="tab-content" id="navPresentationTabContent">
        {/* Description */}
        <div
          className="tab-pane fade show active"
          id="nav-desc"
          role="tabpanel"
          aria-labelledby="nav-desc-tab"
          tabIndex={-1}
        >
          <div className="tp-product-details-desc-wrapper pt-60">
            <div className="row">
              <div className="col-xl-12">
                <div className="tp-product-details-desc-item">
                  <div className="row align-items-center">
                    <div className="col-lg-12">
                      <div
                        className="tp-product-details-desc-content"
                        style={{
                          wordBreak: "break-word",
                          overflowWrap: "break-word",
                          whiteSpace: "normal",
                        }}
                      >
                        {description ? (
                          <div
                            dangerouslySetInnerHTML={{
                              __html: prepareDescriptionHtml(description),
                            }}
                          />
                        ) : (
                          <p>No description available.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Review */}
        <div
          className="tab-pane fade"
          id="nav-review"
          role="tabpanel"
          aria-labelledby="nav-review-tab"
          tabIndex={-1}
        >
          <div className="tp-product-details-desc-wrapper pt-60">
            <div className="row g-4">
              <div className="col-lg-8">
                {/* ✅ Pass the already-fetched reviews */}
                <ReviewItem
                  productId={product.product_id}
                  reviews={reviews}
                  isError={isError}
                  isLoadingReviews={isLoadingReviews}
                />
              </div>
              <div className="col-lg-4">
                <div className="tp-product-details-review-form">
                  <ReviewForm
                    productId={product.product_id}
                    refetch={refetch}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailsTabNav;
