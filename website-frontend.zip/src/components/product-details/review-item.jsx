import dayjs from "dayjs";
import React from "react";
import { Rating } from "react-simple-star-rating";
import { useGetProductReviewsQuery } from "@/redux/features/productApi";

const ReviewItem = ({ productId, reviews, isLoadingReviews, isError }) => {
  // Skip fetching if parent already provided reviews
  // const skipFetch = Array.isArray(passedReviews);
  // const { data: fetched = [], isLoading, isError } =
  //   useGetProductReviewsQuery(productId, { skip: skipFetch || !productId });

  // const reviews = passedReviews ?? fetched;

  if (isLoadingReviews) return <p>Loading reviews…</p>;
  if (isError) return <p>Failed to load reviews.</p>;
  if (!reviews.length) return <p>No reviews yet.</p>;

  return (
    <div className="tp-product-details-review-list">
      {reviews.map((r) => (
        <div key={r.review_id} className="tp-product-details-review-avater d-flex align-items-start mb-4">
          <div className="tp-product-details-review-avater-thumb">
            <h5 className="review-name">{(r.customer_name || "U")[0]}</h5>
          </div>

          <div className="tp-product-details-review-avater-content">
            <h3 className="tp-product-details-review-avater-title">{r.customer_name}</h3>
            <span className="tp-product-details-review-avater-meta">
              {dayjs(r.updated_at || r.created_at).format("MMMM D, YYYY")}
            </span>
            <div className="tp-product-details-review-avater-rating d-flex align-items-center">
              <Rating allowFraction size={16} initialValue={Number(r.review) || 0} readonly />
            </div>
            <div className="tp-product-details-review-avater-comment">
              <p>&quot; {r.comment} &quot;</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ReviewItem;
