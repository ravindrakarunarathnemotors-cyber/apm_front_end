import React, { useState } from 'react'
import { Icon } from '@iconify/react'
import InfoCircle from "@/svg/info-circle"

// const DiscountTooltip = ({ discount_details }) => {
//     const [showTerms, setShowTerms] = useState(false);
//     return (
//         <div className="position-relative d-inline-block">

//             {/* Info icon (Bootstrap icons or text) */}
//             <span
//                 className="text-primary d-flex align-items-center"
//                 style={{ cursor: "pointer" }}
//                 onMouseEnter={() => setShowTerms(true)}
//                 onMouseLeave={() => setShowTerms(false)}
//             >
//                 <InfoCircle /> 
//             </span>

//             {/* Tooltip box */}
//             {showTerms && (
//                 <div
//                     className="position-absolute bg-white border rounded shadow p-2 small"
//                     style={{
//                         top: "-50px",
//                         left: "0",
//                         width: "220px",
//                         zIndex: 10
//                     }}
//                 >
//                     {/* Minimum purchase */}
//                     {discount_details.min_purchase_amount > 0 && (
//                         <div className="lh-sm">
//                             You must spend at least <strong>{discount_details.min_purchase_amount}</strong> to apply this discount.
//                         </div>
//                     )}

//                     {/* Maximum discount */}
//                     {discount_details.max_discount_amount > 0 && (
//                         <div className="mt-1 lh-sm">
//                             Maximum discount allowed is <strong>{discount_details.max_discount_amount}</strong>.
//                         </div>
//                     )}

//                     {/* Eligibility */}
//                     {(discount_details.customer_eligibility && discount_details.customer_eligibility !== 'asll') && (
//                         <div className="mt-1 lh-sm">
//                             This offer is available for <strong>{discount_details.customer_eligibility}</strong> users.
//                         </div>
//                     )}

//                     {/* If no special rules */}
//                     {!(discount_details.min_purchase_amount > 0) &&
//                         !(discount_details.max_discount_amount > 0) &&
//                         !(discount_details.customer_eligibility) && (
//                             <div className="lh-sm">No special conditions apply to this discount.</div>
//                         )}
//                 </div>

//             )}
//         </div>
//     )
// }

// export default DiscountTooltip

const DiscountTooltip = ({ discount_details }) => {
    const [showDiscountInfo, setShowDiscountInfo] = useState(false);

   
    return (
        <div
            className="position-relative d-inline-block"
            onMouseEnter={() => setShowDiscountInfo(true)}
            onMouseLeave={() => setShowDiscountInfo(false)}
        >
            {/* INFO ICON */}
            <button className="btn btn-link p-0 border-0 d-flex ">
               
                <Icon icon="si:info-line" width="20" height="20"  style={{color: '#9e9e9eff'}} />
            </button>

            {/* HOVER DROPDOWN */}
            {showDiscountInfo && (
                <ul
                    className="dropdown-menu show p-2 shadow-sm"
                    style={{
                        position: "absolute",
                        top: "100%",
                        right: 0,
                        minWidth: 280,
                        zIndex: 1000,
                        fontSize: "12px",
                        lineHeight: "1.4"
                    }}
                >
                    <li className="fw-semibold mb-1">Offer Details</li>

                    <li className="small">
                        • This offer is available for <strong>{discount_details.customer_eligibility}</strong> users.
                    </li>

                    <li className="small">
                        •{" "}
                        {discount_details.is_guest_allowed
                            ? "Guests can use this offer"
                            : "Login required to use this offer"}
                    </li>

                    <li className="small">
                        •{" "}
                        {discount_details.unlimited_usage
                            ? "No usage limit"
                            : `Can be used up to ${discount_details.usage_limit_per_account} time(s)`}
                    </li>

                    {discount_details.min_purchase_amount && (
                        <li className="small">
                            • You must spend at least <strong>{discount_details.min_purchase_amount}</strong> to apply this discount.
                        </li>
                    )}

                    {discount_details.max_discount_amount && (
                        <li className="small">
                            • Maximum discount allowed is <strong>{discount_details.max_discount_amount}</strong>.
                        </li>
                    )}

                    <li className="small">
                        •{" "}
                        {discount_details.end_date
                            ? `Valid until ${new Date(
                                discount_details.end_date
                            ).toLocaleDateString()}`
                            : "No expiry date"}
                    </li>
                </ul>
            )}
        </div>
    );
};

export default DiscountTooltip;