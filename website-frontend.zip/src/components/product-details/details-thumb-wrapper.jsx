"use client";
import Image from "next/image";
import { useEffect, useMemo, useRef, useState } from "react";

const VIDEO_EXTS = /\.(mp4|m4v|webm|ogg|ogv|mov|mkv)(\?.*)?$/i;
const isVideoUrl = (u) => typeof u === "string" && VIDEO_EXTS.test(u || "");

const DetailsThumbWrapper = ({
  handleImageActive,
  productItem,
  activeImg,
  imgWidth = 600,
  imgHeight = 700,
  status,
}) => {
  const [index, setIndex] = useState(0);
  const [isChanging, setIsChanging] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const thumbRefs = useRef({});
  const thumbsNavRef = useRef(null);

  // ---------- Media Logic ----------
  const baseList = useMemo(() => {
    const otherImages = productItem?.other_images || [];
    const primary =
      productItem?.media_url ||
      otherImages?.media_url ||
      "/assets/img/product-placeholder.jpg";

    const items = [
      { url: primary, type: isVideoUrl(primary) ? "video" : "image" },
      ...otherImages
        .filter((o) => o?.media_url && o.media_url !== primary)
        .map((o) => ({
          url: o.media_url,
          type: isVideoUrl(o.media_url) ? "video" : "image",
        })),
    ];
    const seen = new Set();
    return items.filter(({ url }) =>
      seen.has(url) ? false : (seen.add(url), true),
    );
  }, [productItem]);

  // Sync index when variant changes (e.g., clicking a color swatch)
  useEffect(() => {
    if (activeImg) {
      const i = baseList.findIndex((x) => x.url === activeImg);
      if (i !== -1) handleSelect(i);
    }
  }, [activeImg, baseList]);

  const handleSelect = (idx) => {
    if (idx === index) return;

    setIsChanging(true); // Start fade-out

    setTimeout(() => {
      setIndex(idx);
      setIsLoaded(false);
      handleImageActive?.(baseList[idx].url);

      // Auto-scroll the thumbnail into view
      const el = thumbRefs.current[baseList[idx].url];
      if (el) {
        el.scrollIntoView({
          behavior: "smooth",
          block: "nearest",
          inline: "center",
        });
      }
      setIsChanging(false); // Start fade-in
    }, 150);
  };

  const currentMedia = baseList[index];

  return (
    <div className="product-media-main-container container-fluid p-0">
      <div className="row g-3">
        {/* THUMBNAILS: col-md-2 for vertical desktop rail */}
        <div className="col-12 col-md-2 order-2 order-md-1">
          <div className="thumb-rail-container">
            <nav
              ref={thumbsNavRef}
              className="thumb-vertical-rail custom-scrollbar"
            >
              {baseList.map((item, i) => (
                <button
                  key={item.url}
                  ref={(el) => (thumbRefs.current[item.url] = el)}
                  className={`thumb-item-btn ${i === index ? "active" : ""}`}
                  onClick={() => handleSelect(i)}
                  aria-label={`View media ${i + 1}`}
                >
                  <div className="thumb-ratio-box">
                    {item.type === "video" ? (
                      <video
                        src={item.url}
                        muted
                        className="thumb-img-content"
                      />
                    ) : (
                      <img
                        src={item.url}
                        alt="thumb"
                        className="thumb-img-content"
                      />
                    )}
                    {item.type === "video" && (
                      <span className="video-play-indicator">▶</span>
                    )}
                  </div>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* MAIN DISPLAY: col-md-10 for the large image */}
        <div className="col-12 col-md-10 order-1 order-md-2">
          <div className="main-viewport-container rounded-4 shadow-sm">
            {/* The actual Media Container with hardware-accelerated transitions */}
            <div
              className={`media-canvas-layer ${isChanging ? "is-switching" : "is-active"} ${isLoaded ? "is-ready" : "is-loading"}`}
            >
              {currentMedia.type === "video" ? (
                <video
                  src={currentMedia.url}
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="main-media-asset"
                  onLoadedData={() => setIsLoaded(true)}
                />
              ) : (
                <img
                  src={currentMedia.url}
                  alt={productItem?.title || "Product Image"}
                  className="main-media-asset"
                  onLoad={() => setIsLoaded(true)}
                />
              )}
            </div>

            {/* Optimized Loading Shimmer (Hardware Accelerated) */}
            {!isLoaded && <div className="modern-shimmer-overlay" />}

            {/* Status Badges */}
            {status === "out-of-stock" && (
              <span className="out-of-stock-badge">Out of Stock</span>
            )}

            {/* Navigation Arrows (Only if more than 1 image) */}
            {baseList.length > 1 && (
              <div className="viewport-nav-controls">
                <button
                  className="nav-control-btn prev"
                  onClick={() =>
                    handleSelect(
                      (index - 1 + baseList.length) % baseList.length,
                    )
                  }
                >
                  ‹
                </button>
                <button
                  className="nav-control-btn next"
                  onClick={() => handleSelect((index + 1) % baseList.length)}
                >
                  ›
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        /* 1. Viewport Setup */
        .main-viewport-container {
          position: relative;
          aspect-ratio: 4 / 5;
          width: 100%;
          background: #f8fafc;
          overflow: hidden;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .media-canvas-layer {
          width: 100%;
          height: 100%;
          transition:
            opacity 0.25s ease-in-out,
            transform 0.4s cubic-bezier(0.165, 0.84, 0.44, 1),
            filter 0.4s ease;
          will-change: opacity, transform, filter;
        }

        /* 2. Transition States */
        .is-switching {
          opacity: 0;
          transform: scale(0.97) translateZ(0);
        }
        .is-loading {
          filter: blur(15px);
        }
        .is-ready {
          filter: blur(0);
          opacity: 1;
          transform: scale(1) translateZ(0);
        }

        .main-media-asset {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .thumb-rail-container {
          position: relative;
          height: 100%;
          max-height: calc(100vw * 10/12 * 5/4); /* Fallback for desktop: matches 4:5 ratio */
        }

        /* 3. Thumbnails Rail */
        .thumb-vertical-rail {
          display: flex;
          flex-direction: column;
          gap: 12px;
          overflow-y: auto;
          overflow-x: hidden;
          padding: 5px;
          scroll-behavior: smooth;
          scroll-snap-type: y mandatory;
          -webkit-overflow-scrolling: touch;
        }

        /* hide scrollbar */
        .thumb-vertical-rail::-webkit-scrollbar {
          display: none;
        }
        .thumb-vertical-rail {
          scrollbar-width: none;
        }

        .thumb-item-btn {
          position: relative;
          background: rgba(255, 255, 255, 0.96);
          border: 2px solid #eef2f7;
          border-radius: 14px;
          padding: 3px;
          cursor: pointer;
          transition:
            transform 0.25s ease,
            box-shadow 0.25s ease,
            border-color 0.25s ease;
          flex-shrink: 0;
          scroll-snap-align: center;
          will-change: transform;
        }

        .thumb-item-btn:hover {
          border-color: #dbeafe;
          transform: scale(1.02);
        }

        .thumb-item-btn.active {
          border-color: #2563eb;
          transform: scale(1.03);
          box-shadow: 0 8px 22px rgba(37, 99, 235, 0.16);
        }

        /* Active blue line */
        .thumb-item-btn.active::before {
          content: "";
          position: absolute;
          left: -8px;
          top: 15%;
          height: 70%;
          width: 4px;
          border-radius: 10px;
          background: linear-gradient(180deg, #2563eb, #60a5fa);
        }

        .thumb-ratio-box {
          aspect-ratio: 1;
          position: relative;
          width: 100%;
          border-radius: 10px;
          overflow: hidden;
        }

        .thumb-img-content {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .video-play-indicator {
          position: absolute;
          bottom: 5px;
          right: 5px;
          background: rgba(0, 0, 0, 0.6);
          color: #fff;
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 4px;
        }

        /* 4. Loading & Overlays */
        .modern-shimmer-overlay {
          position: absolute;
          inset: 0;
          background: #f1f5f9
            linear-gradient(90deg, #f1f5f9 0%, #e2e8f0 50%, #f1f5f9 100%);
          background-size: 200% 100%;
          animation: shimmer-effect 1.5s infinite linear;
          z-index: 1;
        }

        @keyframes shimmer-effect {
          to {
            background-position: -200% 0;
          }
        }

        .out-of-stock-badge {
          position: absolute;
          top: 15px;
          left: 15px;
          background: #ef4444;
          color: white;
          padding: 5px 14px;
          border-radius: 6px;
          font-size: 12px;
          font-weight: 700;
          z-index: 2;
        }

        .nav-control-btn {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.9);
          border: none;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
          font-size: 24px;
          transition: 0.2s;
          pointer-events: auto;
        }
        .nav-control-btn:hover {
          background: #fff;
          transform: scale(1.1);
          color: #2563eb;
        }

        .viewport-nav-controls {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 100%;
          display: flex;
          justify-content: space-between;
          padding: 0 10px;
          pointer-events: none;
          z-index: 3;
        }

        /* 5. Custom Scrollbar for the Rail */
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }

        @media (min-width: 768px) {
          .thumb-rail-container {
             /* This ensures the rail is exactly as tall as the main viewport */
             height: 0;
             min-height: 100%; 
             position: sticky;
             top: 20px;
          }
          
          .thumb-vertical-rail {
            position: absolute;
            top: 0; bottom: 0; left: 0; right: 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
            overflow-y: auto;
            padding-right: 8px; /* Space for scrollbar */
          }
        }

        /* 2. Premium Scrollbar UI */
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
          transition: background 0.2s;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }

        /* 3. Button & Interaction Improvements */
        .thumb-item-btn {
          width: 100%; /* Fill the column width */
          background: #fff;
          border: 2px solid #f1f5f9;
          border-radius: 12px;
          padding: 2px;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .thumb-item-btn.active {
          border-color: #2563eb;
          box-shadow: 0 4px 12px rgba(37, 99, 235, 0.1);
        }

        /* 4. Mobile Responsiveness (Horizontal Rail) */
        @media (max-width: 767px) {
          .thumb-rail-container {
            height: auto;
            max-height: none;
          }
          .thumb-vertical-rail {
            flex-direction: row;
            overflow-x: auto;
            overflow-y: hidden;
            padding: 10px 0;
            gap: 10px;
            scroll-snap-type: x mandatory;
          }
          .thumb-item-btn {
            width: 70px;
            flex-shrink: 0;
          }
        }

        /* Mobile Optimized Rail */
        @media (max-width: 767px) {
          .thumb-vertical-rail {
            flex-direction: row;
            align-items: center;
            gap: 10px;
            max-height: unset;
            overflow-x: auto;
            overflow-y: hidden;
            margin-top: 12px;
            padding: 4px 2px 8px;
            scroll-snap-type: x mandatory;
            -webkit-overflow-scrolling: touch;
          }

          .thumb-vertical-rail::-webkit-scrollbar {
            display: none;
          }

          .thumb-item-btn {
            min-width: 68px;
            width: 68px;
            scroll-snap-align: center;
            border-radius: 12px;
          }

          .thumb-item-btn.active {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 16px rgba(37, 99, 235, 0.18);
          }

          .main-viewport-container {
            aspect-ratio: 1 / 1.1;
            border-radius: 18px;
          }

          .viewport-nav-controls {
            padding: 0 6px;
          }

          .nav-control-btn {
            width: 36px;
            height: 36px;
            font-size: 20px;
          }
        }
      `}</style>
    </div>
  );
};

export default DetailsThumbWrapper;
