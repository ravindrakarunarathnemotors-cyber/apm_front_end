import { useGetSystemSettingsQuery } from "@/redux/features/brandingSettingsApi";
import { useSelector } from "react-redux";

// const currencySymbols = {
//   LKR: "Rs.",
// };

const currencySymbols = 'LKR '

export default function useCurrencySymbol() {
  const { currency } = useSelector((state) => state.settings);

  const {data, isFetching, isError} = useGetSystemSettingsQuery()
  
  return data ? data?.currency + ' ' : currencySymbols;
}