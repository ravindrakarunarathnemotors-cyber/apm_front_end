// utils/measurementConverter.js
export const measurementConverter = (amount, measurement_id) => {
  if (amount === null || amount === undefined) return ''

  if (measurement_id === 1) return `${amount}pcs`
  if (measurement_id === 2) return `${amount}kg`
  if (measurement_id === 5) return `${amount}l`

  if (measurement_id === 3) {
    return amount >= 1000
      ? `${(amount / 1000)}kg`
      : `${amount}g`
  }

  if (measurement_id === 4) {
    return amount >= 1000
      ? `${(amount / 1000)}l`
      : `${amount}ml`
  }

  return `${amount}`
}
