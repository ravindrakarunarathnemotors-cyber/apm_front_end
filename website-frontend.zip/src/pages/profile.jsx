import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { useDispatch } from "react-redux";

// layout
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";

// feature components
import ProfileArea from "@/components/my-account/profile-area";

// redux
import { useGetUserOrdersQuery } from "@/redux/features/order/orderApi";
import { useGetUserDetailsQuery } from "@/redux/features/auth/authApi";
import { userLoggedOut } from "@/redux/features/auth/authSlice";

// skeleton loader
import ProfileAreaLoader from "@/components/loader/my-account/profile-area-loader";

/**
 * Smooth login/profile flow:
 * - Shows skeleton while verifying token and loading data
 * - Redirects to /login if not authenticated
 * - Fades real content in when ready
 */
const ProfilePage = () => {
  const router = useRouter();
  const dispatch = useDispatch();

  const [token, setToken] = useState(null);
  const [checkingToken, setCheckingToken] = useState(true);
  const [page, setPage] = useState(1)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const t = localStorage.getItem("accessToken");
      setToken(t);
      setCheckingToken(false);

      if (!t) {
        // No token: push to login but keep loader up
        router.replace("/login");
      }
    }
  }, [router]);

  const skipData = checkingToken || !token;

  const {
    data: orderData,
    isLoading: ordersLoading,
    isFetching: ordersFetching,
  } = useGetUserOrdersQuery( { page }, { skip: skipData });

  const allPages = orderData ? orderData?.total : 0

  const {
    data: userData,
    isLoading: userLoading,
    isFetching: userFetching,
    error,
    isError,
  } = useGetUserDetailsQuery(token, { skip: skipData });

  // Handle invalid/expired token
  useEffect(() => {
    if (error && (error.status === 401 || error.status === 403)) {
      dispatch(userLoggedOut());
      router.replace("/login");
    }
  }, [isError, error, dispatch, router]);

  // skeleton while checking token or loading data
  const loading =
    checkingToken ||
    userLoading ||
    userFetching;

  if (loading) {
    return <ProfileAreaLoader />;
  }

  // If still no token after check, just keep skeleton until redirect
  if (!token) {
    return <ProfileAreaLoader />;
  }

  return (
    <Wrapper>
      <SEO pageTitle="Profile" />
      <HeaderTwo style_2={true} />

      {/* Fade + slide animation for content */}
      <div className="fade-up-once">
        <ProfileArea orderData={orderData} userData={userData} page={page} allPages={allPages} setPage={setPage}/>
      </div>

      <Footer style_2={true} />
    </Wrapper>
  );
};

export default ProfilePage;

