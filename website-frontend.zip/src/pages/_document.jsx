import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html>
      <Head>
        <link
          rel="preload"
          href="/_next/static/media/fa-solid-900.dd5b7b2e.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        /> 
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
