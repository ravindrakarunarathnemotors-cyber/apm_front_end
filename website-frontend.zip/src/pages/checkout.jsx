import React, { useEffect, useState } from "react";
import Cookies from "js-cookie";
import { useRouter } from "next/router";
// internal
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";
import CommonBreadcrumb from "@/components/breadcrumb/common-breadcrumb";
import CheckoutArea from "@/components/checkout/checkout-area";

const CheckoutPage = () => {
  const [isGuest, setIsGuest] = useState(false);
  const [authenticating, setAuthenticating] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (!router.isReady) return;

    const token =
      typeof window !== "undefined" ? localStorage.getItem("accessToken") : "";
    const guestParam = router.query.guest;
    const isGuestUser = guestParam === "true";

    if (!token && !isGuestUser) {
      // Use router.replace instead of push to prevent back-button loops
      router.replace("/login");
    } else {
      setIsGuest(isGuestUser);
      setAuthenticating(false); // Only stop loading if we have access
    }
  }, [router]);

  if (authenticating) {
    return (
      <Wrapper>
        <div className="d-flex align-items-center justify-content-center" style={{ height: '100vh' }}>
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </Wrapper>
    );
  }

  return (
    <Wrapper>
      <SEO pageTitle="Checkout" />
      <HeaderTwo style_2={true} />
      {/* <CommonBreadcrumb title="Checkout" subtitle="Checkout" bg_clr={true} /> */}
      <CheckoutArea isGuest={isGuest} />
      <Footer style_2={true} />
    </Wrapper>
  );
};

export default CheckoutPage;
