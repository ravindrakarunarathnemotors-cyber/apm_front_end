import { Button } from '@mui/material'
import Script from 'next/script';
import React, { useState } from 'react'

const TestPay = () => {

    // const [hash, setHash] = useState('')
    const handlePayment = async () => {

        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/test_pay`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    order_id: '112',
                    amount: '1000.00',
                    currency: 'LKR'
                })
            });
            if (response.ok) {
                const data = await response.json();

                if (data && data.pay) {
                    // console.log(data.pay);

                    

                    payhere.onCompleted = function onCompleted(orderId) {
                        // console.log("Payment completed. OrderID:" + orderId);

                        // Note: validate the payment and show success or failure page to the customer
                    };

                    // Payment window closed
                    payhere.onDismissed = function onDismissed() {
                        // Note: Prompt user to pay again or show an error page
                        // console.log("Payment dismissed");
                    };

                    // Error occurred
                    payhere.onError = function onError(error) {
                        // Note: show an error page
                        console.log("Error:" + error);
                    };

                    // Put the payment variables here
                    var payment = {
                        "sandbox": true,
                        "merchant_id": "1225322",    // Replace your Merchant ID
                        "return_url": 'http://localhost:3000/test-pay/',     // Important
                        "cancel_url": 'http://localhost:3000/test-pay/',     // Important
                        "notify_url": "https://external-api.sparksender.com/backendAdmin/test_payhere.php",
                        "order_id": "112",
                        "items": "Door bell wireles",
                        "amount": "1000.00",
                        "currency": "LKR",
                        "hash": data.pay.hash, // *Replace with generated hash retrieved from backend
                        "first_name": "Saman",
                        "last_name": "Perera",
                        "email": "samanp@gmail.com",
                        "phone": "0771234567",
                        "address": "No.1, Galle Road",
                        "city": "Colombo",
                        "country": "Sri Lanka",
                        "delivery_address": "No. 46, Galle road, Kalutara South",
                        "delivery_city": "Kalutara",
                        "delivery_country": "Sri Lanka",
                        "custom_1": "",
                        "custom_2": ""
                    };

                    payhere.startPayment(payment);

                }
            }
        } catch (error) {
            console.error('Error:', error);

        }


    }

    const handleCheck = async () => {
        try {
            const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/low_balance_crow.php`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                },
               
            });
        } catch (error) {
            console.error('Error:', error);

        }
        
    }

    return (
        <div>
            <>
                <Script src="https://www.payhere.lk/lib/payhere.js"></Script>
            </>
            <Button variant='contained' onClick={handlePayment}>check payment</Button>

            <Button variant='contained' onClick={handleCheck}>check backend</Button>

        </div>
    )
}

export default TestPay