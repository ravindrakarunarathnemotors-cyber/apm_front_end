import React from "react";
import SEO from "@/components/seo";
import HeaderTwo from "@/layout/headers/header-2";
import Wrapper from "@/layout/wrapper";
import { useEffect, useState, useMemo } from "react";
import FashionBanner from "@/components/banner/fashion-banner";
import FashionCategory from "@/components/categories/fashion-category";
import PopularProducts from "@/components/products/fashion/popular-products";
import ProductArea from "@/components/products/fashion/product-area";
import WeeksFeatured from "@/components/products/fashion/weeks-featured";
import TrendingProducts from "@/components/products/fashion/trending-products";
import BestSellerProducts from "@/components/products/fashion/best-seller-products";
import FashionTestimonial from "@/components/testimonial/fashion-testimonial";
import BlogArea from "@/components/blog/fashion/blog-area";
import FeatureAreaTwo from "@/components/features/feature-area-2";
import InstagramAreaTwo from "@/components/instagram/instagram-area-2";
import Footer from "@/layout/footers/footer";
import { useGetWebSectionsMutation } from "@/redux/features/webstoreSettingsApi";
import dynamic from "next/dynamic";

export const SECTIONS = {
  FashionBanner: dynamic(() => import("@/components/banner/fashion-banner")),
  FashionCategory: dynamic(() =>
    import("@/components/categories/fashion-category")
  ),
  PopularProducts: dynamic(() =>
    import("@/components/products/fashion/popular-products")
  ),
  ProductArea: dynamic(() =>
    import("@/components/products/fashion/product-area")
  ),
  WeeksFeatured: dynamic(() =>
    import("@/components/products/fashion/weeks-featured")
  ),
  TrendingProducts: dynamic(() =>
    import("@/components/products/fashion/trending-products")
  ),
  BestSellerProducts: dynamic(() =>
    import("@/components/products/fashion/best-seller-products")
  ),
  FashionTestimonial: dynamic(() =>
    import("@/components/testimonial/fashion-testimonial")
  ),
  BlogArea: dynamic(() => import("@/components/blog/fashion/blog-area")),
  FeatureAreaTwo: dynamic(() => import("@/components/features/feature-area-2")),
  InstagramAreaTwo: dynamic(() =>
    import("@/components/instagram/instagram-area-2")
  ),
};
const HomeTwo = () => {
  const [getWebSections, { data: sectionData, isLoading, isError }] =
    useGetWebSectionsMutation();

  useEffect(() => {
    // Call the mutation when component mounts
    getWebSections(2);
  }, [getWebSections]);
  console.log("sectionData", sectionData);

  const ordered = useMemo(() => {
    return [...(sectionData || [])]
      .filter((s) => typeof s.order === "number" && s.section_key)
      .sort((a, b) => a.order - b.order);
  }, [sectionData]);

  return (
    <Wrapper>
      <SEO pageTitle="Home" />
      <HeaderTwo />
      
      {ordered.map(({ id,section_key }, idx) => {
        const Comp = SECTIONS[section_key];
        if (!Comp) return null; // unknown keys are skipped safely
        return <Comp sectionId={id} key={`${section_key}-${idx}`} />;
      })}
      <Footer style_2={true} />
    </Wrapper>
  );
};

export default HomeTwo;
