
import { Icon } from "@iconify/react"; // Assuming you are using Iconify as per your tech stack
import { useRouter } from 'next/router';

export default function PaymentFailedPage() {

  const router = useRouter();
  return (
    <div style={{ 
      minHeight: "100vh", 
      display: "flex", 
      alignItems: "center", 
      justifyContent: "center", 
      backgroundColor: "#f9fafb",
      padding: "20px"
    }}>
      <div style={{ 
        maxWidth: "440px", 
        width: "100%", 
        backgroundColor: "#ffffff", 
        padding: "40px", 
        borderRadius: "12px", 
        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
        textAlign: "center" 
      }}>
        
        {/* Status Icon */}
        <div style={{ 
          display: "flex", 
          justifyContent: "center", 
          marginBottom: "24px" 
        }}>
          <div style={{ 
            backgroundColor: "#fee2e2", 
            borderRadius: "50%", 
            padding: "16px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}>
            <Icon icon="heroicons:x-circle-20-solid" width="48" height="48" style={{ color: "#ef4444" }} />
          </div>
        </div>

        <h1 style={{ 
          fontSize: "24px", 
          fontWeight: "600", 
          color: "#111827", 
          marginBottom: "8px",
          fontFamily: "Inter, sans-serif" 
        }}>
          Payment Declined
        </h1>
        
        <p style={{ 
          fontSize: "15px", 
          color: "#6b7280", 
          lineHeight: "1.5", 
          marginBottom: "32px" 
        }}>
          We couldn&apos;t process your transaction. This might be due to insufficient funds, an expired card, or a temporary connection issue with Koko.
        </p>

        {/* Action Buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
          <button 
            onClick={() => router.push("/profile")}
            style={{ 
              backgroundColor: "#111827", 
              color: "#ffffff", 
              padding: "12px 24px", 
              borderRadius: "8px", 
              fontWeight: "500", 
              border: "none", 
              cursor: "pointer",
              fontSize: "15px",
              transition: "background-color 0.2s"
            }}
          >
            Try Another Payment Method
          </button>

        </div>

        {/* Help Links */}
        <div style={{ marginTop: "32px", paddingTop: "24px", borderTop: "1px solid #f3f4f6" }}>
          <p style={{ fontSize: "14px", color: "#9ca3af" }}>
            Need help? <a href="#" style={{ color: "#4f46e5", textDecoration: "none" }}>Contact Support</a>
          </p>
        </div>

      </div>
    </div>
  );
}