import { useRouter } from "next/router";
import { Icon } from "@iconify/react";
import Link from "next/link";

export default function PaymentCancelledPage() {
  const router = useRouter();

  const containerStyle = {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F3F4F6", // Light gray background
    padding: "20px",
    fontFamily: "'Inter', system-ui, sans-serif"
  };

  const cardStyle = {
    maxWidth: "400px",
    width: "100%",
    backgroundColor: "#FFFFFF",
    padding: "40px 32px",
    borderRadius: "16px",
    boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05)",
    textAlign: "center"
  };

  const iconContainerStyle = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: "64px",
    height: "64px",
    backgroundColor: "#FEE2E2", // Soft red/orange tint
    borderRadius: "50%",
    marginBottom: "24px"
  };

  const primaryBtnStyle = {
    display: "block",
    width: "100%",
    padding: "12px",
    backgroundColor: "#111827",
    color: "#FFFFFF",
    borderRadius: "8px",
    textDecoration: "none",
    fontWeight: "500",
    fontSize: "15px",
    marginBottom: "12px",
    transition: "background 0.2s"
  };

  const secondaryBtnStyle = {
    display: "block",
    width: "100%",
    padding: "12px",
    backgroundColor: "#FFFFFF",
    color: "#374151",
    borderRadius: "8px",
    textDecoration: "none",
    fontWeight: "500",
    fontSize: "15px",
    border: "1px solid #D1D5DB"
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <div style={iconContainerStyle}>
          <Icon 
            icon="solar:cart-cross-bold-duotone" 
            width="36" 
            height="36" 
            style={{ color: "#EF4444" }} 
          />
        </div>

        <h1 style={{ fontSize: "22px", fontWeight: "700", color: "#111827", marginBottom: "12px" }}>
          Payment Cancelled
        </h1>

        <p style={{ fontSize: "15px", color: "#6B7280", lineHeight: "1.6", marginBottom: "32px" }}>
          Your transaction was cancelled and your card was not charged. If you had an issue with the payment method, you can try again or update your cart.
        </p>

        <div style={{ marginTop: "24px" }}>
          <Link href="/checkout" style={primaryBtnStyle}>
            Continue to Checkout
          </Link>
         
          {/* <a href="/cart" style={secondaryBtnStyle}>
            Modify Your Order
          </a> */}
        </div>

        <p style={{ marginTop: "32px", fontSize: "13px", color: "#9CA3AF" }}>
          Changed your mind? <Link href="/" style={{ color: "#4F46E5", textDecoration: "none" }}>Back to Home</Link>
        </p>
      </div>
    </div>
  );
}