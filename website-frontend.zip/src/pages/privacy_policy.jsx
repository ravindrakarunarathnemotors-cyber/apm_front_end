'use client';

import { useMemo } from "react";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderFour from "@/layout/headers/header-4";
import HeaderTwo from "@/layout/headers/header-2";
import { useGetPageContentQuery } from "@/redux/features/webstoreSettingsApi";
import Footer from "@/layout/footers/footer";

export default function PrivacyPolicy() {
  const { data, isLoading, isError } = useGetPageContentQuery();

  const privacy = useMemo(() => {
    const arr = Array.isArray(data?.result) ? data.result : [];
    return arr.find(r => r?.slug === "privacy-policy") || null;
  }, [data]);

  return (
    <>
      <SEO pageTitle={privacy?.title || "Privacy Policy"} />
      <Wrapper>
        <HeaderTwo />

        <main className="container py-5">
          {isLoading && <p>Loading…</p>}
          {isError && <p>Failed to load content.</p>}
          {!isLoading && !isError && (
            <>
              <h1 className="mb-4 text-center">{privacy?.title || "Privacy Policy"}</h1>
              {privacy?.content_html ? (
                <div
                  className="rich-content"
                  dangerouslySetInnerHTML={{ __html: privacy.content_html }}
                />
              ) : (
                <p>No privacy policy content found.</p>
              )}
            </>
          )}
        </main>

        <Footer style_3/>
      </Wrapper>

      {/* must be GLOBAL to affect injected HTML */}
      <style jsx global>{`
        .rich-content img {
          width: 100% !important;   /* w-100 */
          max-width: 100% !important;
          height: auto !important;
          display: block;
        }
        .rich-content figure,
        .rich-content p {
          margin: 0 0 1rem;
        }
        .rich-content ol,
        .rich-content ul {
          padding-left: 2rem;
        }
        .rich-content blockquote {
          padding: 0.5rem 1rem;
          margin-left: 0;
          color: #555;
          border-left: 0.25rem solid #e5e5e5;
        }
        .rich-content blockquote p:last-child {
          margin-bottom: 0;
        }
        .rich-content h1,
        .rich-content h2,
        .rich-content h3,
        .rich-content h4,
        .rich-content h5,
        .rich-content h6 {
          margin-top: 1.5rem;
          margin-bottom: 0.5rem;
          font-weight: 500;
          line-height: 1.2;
        }
        .rich-content h1 { font-size: 2.5rem; }
        .rich-content h2 { font-size: 2rem; }
        .rich-content h3 { font-size: 1.75rem; }
        .rich-content h4 { font-size: 1.5rem; }
        .rich-content h5 { font-size: 1.25rem; }
        .rich-content h6 { font-size: 1rem; }
      `}</style>
    </>
  );
}
