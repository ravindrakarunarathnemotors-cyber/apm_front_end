import store from "@/redux/store";
import { Provider, useDispatch } from "react-redux";
import ReactModal from "react-modal";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import "../styles/index.scss";
import { GoogleOAuthProvider } from "@react-oauth/google";
import NextApp from "next/app";
import { Jost, Roboto, Charm, Oregano } from "next/font/google";
import Script from "next/script";
import { KokoProvider } from "@/context/KokoContext";

import TrackingScripts from "@/components/TrackingScripts";
import BrandingThemeLoader from "@/components/BrandingThemeLoader";
import Head from "next/head";
// 👉 NEW: maintenance hook + UI
import MovingBlurBackground from "@/components/Manitenance";

if (typeof window !== "undefined") {
  require("bootstrap/dist/js/bootstrap");
  ReactModal.setAppElement("body");
}

const stripePromise = loadStripe(
  "pk_test_51NYXCFGndYsQkAEFifIbJH64sZFMDpF7DcLYvUUN2az3VdK1M7qVPo7Z2j9rhunf3Pd0C3aFLENIxFriJWwx1P6a00lQFqaoc66",
);

const jost = Jost({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-jost",
  display: "swap",
});
const roboto = Roboto({
  subsets: ["latin"],
  weight: ["300", "400", "500", "700", "900"],
  variable: "--font-roboto",
  display: "swap",
});
const charm = Charm({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-charm",
  display: "swap",
});
const oregano = Oregano({
  subsets: ["latin"],
  weight: ["400"],
  variable: "--font-oregano",
  display: "swap",
});

function BrandFavicons({ brandingData }) {
  const faviconUrl = brandingData?.favicon_url;
  const appleIcon = brandingData?.app_icon_ios;
  const androidIcon = brandingData?.app_icon_android;
  const title = brandingData?.seo_meta_title || "";
  const description = brandingData?.seo_meta_description || "";
  const image = brandingData?.seo_image || "";

  return (
    <Head>
      {/* Use keys so Next/Head de-dupes and updates properly */}
      {faviconUrl && <link rel="icon" href={faviconUrl} key="favicon" />}
      {appleIcon && (
        <link rel="apple-touch-icon" href={appleIcon} key="apple-icon" />
      )}
      {androidIcon && (
        <link
          rel="icon"
          type="image/png"
          sizes="192x192"
          href={androidIcon}
          key="android-icon"
        />
      )}
      {/* OpenGraph */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
    </Head>
  );
} 

function GoogleAuthWrapper({ children, brandingData }) {
  const googleClientId =
    brandingData?.google_clientid ||
    `${process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID}`;

  // If client ID exists, wrap in GoogleOAuthProvider
  if (googleClientId) {
    return (
      <GoogleOAuthProvider clientId={googleClientId}>
        {children}
      </GoogleOAuthProvider>
    );
  }

  // If no client ID, just render children normally
  return <>{children}</>;
}

function MaintenanceGate({ children, maintenanceData, fullMaintenance }) {
  // Some APIs might return a different key; prefer webstore_maintenance_status if same schema
  const fullStatus =
    maintenanceData?.webstore_maintenance_status ??
    maintenanceData?.full_maintenance_status;
  const fullEnabled = fullStatus === "enabled";

  const enabled = fullMaintenance?.webstore_maintenance_status === "enabled";

  // Prefer FULL maintenance screen if it’s on; otherwise fallback to normal maintenance
  if (fullEnabled || enabled) {
    const chosen = fullEnabled ? maintenanceData : fullMaintenance;

    // Parse message if needed
    let msg = { title: "", message: "" };
    try {
      if (typeof chosen?.webstore_maintenance_msg === "string") {
        msg = JSON.parse(chosen.webstore_maintenance_msg || "{}");
      } else if (chosen?.webstore_maintenance_msg) {
        msg = chosen.webstore_maintenance_msg;
      }
    } catch {
      // ignore parsing error
    }

    return <MovingBlurBackground maintenance={chosen} />;
  }

  // Both disabled → render site
  return children;
}

function App({
  Component,
  pageProps,
  brandingData,
  maintenanceData,
  fullMaintenance,
}) {
  return (
    <Provider store={store}>
      <div
        className={`${jost.variable} ${roboto.variable} ${charm.variable} ${oregano.variable} font-sans`}
      >
        <GoogleAuthWrapper brandingData={brandingData}>
          <Elements stripe={stripePromise}>
            <BrandingThemeLoader />
            <TrackingScripts />

            <BrandFavicons brandingData={brandingData} />
            <div id="root">
              {/* 👇 Everything is gated here */}
              <MaintenanceGate
                maintenanceData={maintenanceData}
                fullMaintenance={fullMaintenance}
              >
                <KokoProvider>
                  <Component {...pageProps} />
                </KokoProvider>
              </MaintenanceGate>
            </div>
          </Elements>
        </GoogleAuthWrapper>
        <script
          async
          src="https://embed.tawk.to/XXXXXXXX/default"
          crossOrigin="*"
        />
      </div>
    </Provider>
  );
}

// 1. Define getInitialProps on the MyApp component
App.getInitialProps = async (appContext) => {
  // 2. Call the default getInitialProps from App to ensure
  //    all required initial props for the page are gathered.
  const appProps = await NextApp.getInitialProps(appContext);

  const base = process.env.NEXT_PUBLIC_BASE_URL || "";
  async function fetchJSON(path) {
    try {
      const res = await fetch(`${base}${path}`, {
        headers: { accept: "application/json" },
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (e) {
      return null;
    }
  }

  const [brandingDataAll, maintenanceData, fullMaintenance] = await Promise.all(
    [
      fetchJSON("/branding/settings"),
      fetchJSON("/system/webstore_maintenance"),
      fetchJSON("/system/full_maintenance"),
    ],
  );
  const brandingData = brandingDataAll?.data || null;

  return {
    ...appProps,
    brandingData,
    maintenanceData,
    fullMaintenance,
  };
};

export default App;
