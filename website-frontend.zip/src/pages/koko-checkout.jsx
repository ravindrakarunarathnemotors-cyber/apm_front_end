// pages/checkout.jsx
// This is your checkout page
// It has a simple "Pay with Koko" button
// When clicked, it calls your Node.js server to start the payment
// Then redirects the user to Koko's payment page

import { useState } from "react";

// Your Node.js server URL
// In development this is localhost:4000
// In production replace with your real server URL
const NODE_SERVER = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:5004";

export default function CheckoutPage() {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    async function handlePayNow() {
        setLoading(true);
        setError(null);

        try {
            const response = await fetch(`${NODE_SERVER}/mintpay/create`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    id: 772,
                    order_id: "ORDER_" + Date.now(),
                    total_price: "4880.0000",
                    discount: "0.0000",
                    customer_email: "customer@gmail.com",
                    customer_id: "2",
                    customer_telephone: "0772345678",
                    delivery_street: "8, Chatham St, Colombo-2",
                    delivery_region: "Colombo",
                    delivery_postcode: "00600",
                    cart_created_date: new Date()
                        .toISOString()
                        .slice(0, 19)
                        .replace("T", " "),
                    cart_updated_date: new Date()
                        .toISOString()
                        .slice(0, 19)
                        .replace("T", " "),
                    products: [
                        {
                            name: "Yellow & Blue detailed dress",
                            product_id: "39869",
                            sku: "small",
                            quantity: "1",
                            unit_price: "2090.0000",
                            discount: "0.0000",
                            
                        },
                        {
                            name: "White sleeveless dress",
                            product_id: "33468",
                            sku: "medium",
                            quantity: "1",
                            unit_price: "2790.0000",
                            discount: "0.0000",
                           
                        },
                    ],

                }),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "Failed to initiate payment");
            }
            return
            console.log(data)
            // return
            // ✅ Create form dynamically
            const form = document.createElement("form");
            form.method = "POST";
            form.action = 'https://dev.mintpay.lk/user-order/login/'

            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "purchase_id";
            input.value = data.purchase_id;

            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();

        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div style={{ padding: "40px", maxWidth: "480px", margin: "0 auto" }}>
            <h1>Checkout</h1>

            <div style={{ marginBottom: "24px" }}>
                <p>Order #ORDER_123</p>
                <p>Total: Rs. 1,500.00</p>
            </div>

            {/* Show error if something went wrong */}
            {error && (
                <p style={{ color: "red", marginBottom: "16px" }}>
                    Error: {error}
                </p>
            )}

            <button
                onClick={handlePayNow}
                disabled={loading}
                style={{
                    padding: "12px 32px",
                    fontSize: "16px",
                    backgroundColor: loading ? "#ccc" : "#1a1a2e",
                    color: "#fff",
                    border: "none",
                    borderRadius: "8px",
                    cursor: loading ? "not-allowed" : "pointer",
                }}
            >
                {loading ? "Redirecting to Koko..." : "Pay with Koko"}
            </button>
        </div>
    );
}