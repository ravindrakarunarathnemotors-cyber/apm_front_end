"use client";
import React, { useState, useMemo, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import { useGetAllProductsQuery } from "@/redux/features/productApi";
import {
  useGetmaxPriceQuery,
  useGetShowCategoryQuery,
  useGetShowCollectionQuery,
} from "@/redux/features/categoryApi";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import ShopBreadcrumb from "@/components/breadcrumb/shop-breadcrumb";
import ShopArea from "@/components/shop/shop-area";
import ErrorMsg from "@/components/common/error-msg";
import Footer from "@/layout/footers/footer";
import ShopFilterOffCanvas from "@/components/common/shop-filter-offcanvas";
import ShopLoader from "@/components/loader/shop/shop-loader";
import { useDispatch } from "react-redux";
import { handleFilterSidebarClose } from "@/redux/features/shop-filter-slice";
import WhatsappShareCom from "@/components/common/whatsapp-share";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";

// Helper: Find all descendant category IDs for filtering
const getAllDescendantCategoryIds = (catId, categories) => {
  let ids = [catId];
  categories.forEach((cat) => {
    if (cat.category_under === catId) {
      ids = ids.concat(
        getAllDescendantCategoryIds(cat.category_id, categories)
      );
    }
  });
  return ids;
};

// Helper to create a slug
const slugify = (str = "") =>
  str.toLowerCase().replace("&", "").split(" ").join("-");

const ShopPage = () => {
  // UI state
  const [priceValue, setPriceValue] = useState([0, 0]);
  const [uiPrice, setUiPrice] = useState([0, 0]);
  const [selectValue, setSelectValue] = useState("default");
  const [currPage, setCurrPage] = useState(1);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [page, setPage] = useState(1);
  const [allPages, setAllPages] = useState(0);
  const [total, setTotal] = useState(0);
  const [productsData, setproductsData] = useState([]);
  const [status, setStatus] = useState("");
  const [collectionName, setCollectionName] = useState("");
  const [categoryLabel, setCategoryLabel] = useState("");
  const [collectionLabel, setCollectionLabel] = useState("");

  const dispatch = useDispatch();
  const router = useRouter();

  const debounceTimerRef = useRef(null);
  const lastRangeRef = useRef([0, 0]);
  const didInitRef = useRef(false);

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  const { data, isLoading, isError, isFetching } = useGetAllProductsQuery({
    page,
    selectedCategoryId,
    priceValue: uiPrice,
    selectValue,
    status,
    collectionName,
  });

  // Fetch products and categories

  const { data: categoriesData } = useGetShowCategoryQuery();

  const { data: collections = [] } = useGetShowCollectionQuery();

  const { data: maxValue } = useGetmaxPriceQuery();

  useEffect(() => {

    if (maxValue?.highest_price) {

      setPriceValue([0, parseFloat(maxValue.highest_price) || 0]);
    }
  }, [maxValue]);

  // --- Effect: sync selectedCategoryId with URL slug ---
  useEffect(() => {
    if (!categoriesData) return;

    const queries = router.query;
    const hasQueries = Object.keys(queries).length > 0;

    if (!didInitRef.current && !hasQueries) {
      didInitRef.current = true;
      return;
    }

    // ✅ Reset everything if no query params
    if (!hasQueries) {
      setSelectValue("NewAdded");
      setSelectedCategoryId(null);
      setPriceValue([0, 0]);
      setUiPrice([0, 0]);
      setStatus(null);
      setCollectionName("");
      setCategoryLabel("");
      setCollectionLabel("");
      return;
    }

    // ✅ Category filter
    if (queries.category) {
      const parts = queries.category.split("-");
      const matchedId = parts[parts.length - 1];

      const idNum = matchedId ? parseFloat(matchedId) : null;
      setSelectedCategoryId(idNum);

      // Find category object to get clean name (no id, no hyphens)
      const categoryObj = categoriesData?.find(
        (cat) => String(cat.category_id) === String(idNum)
      );
      setCategoryLabel(categoryObj?.name || "");
    } else {
      setSelectedCategoryId(null);
      setCategoryLabel("");
    }

    // ✅ Order by filter
    if (queries.orderby) {
      setSelectValue(queries.orderby);
    }

    // ✅ Price filter
    if (queries.minPrice && queries.maxPrice) {
      const min = parseFloat(queries.minPrice);
      const max = parseFloat(queries.maxPrice);
      if (!isNaN(min) && !isNaN(max)) {
        setPriceValue([min, max]);
        setUiPrice([min, max]);
      }
    }

    // ✅ Status filter
    if (queries.status) {
      const formatted = queries.status
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
      setStatus(formatted);
    }

    // ✅ Collection filter
    if (queries.collection) {
      const matched = collections.find(
        (col) => slugify(col.name) === queries.collection
      );

      if (matched) {
        // this is still the id for backend
        setCollectionName(matched.collection_id);
        // this is the pretty name for UI
        setCollectionLabel(matched.name);
      } else {
        setCollectionName(null);
        setCollectionLabel("");
      }
    } else {
      setCollectionName("");
      setCollectionLabel("");
    }
  }, [categoriesData, collections, router.query]);

  // console.log(status)

  useEffect(() => {
    if (data) {
      setAllPages(data.allPages || 0);
      setTotal(data.total || 0);
      setproductsData(data.result || []);
    }
  }, [data]);

  const categories = categoriesData;
  const all_products = Array.isArray(productsData) ? productsData : [];

  const mapToFrontendProduct = (p) => ({
    _id: p.product_id,
    title: p.product_name,
    category_id: p.category_id,
    category_name: p.category_name,
    description: p.description,
    price: parseFloat(p.price),
    discount: p.discount || 0,
    status: p.status === "active" ? "in-stock" : "out-of-stock",
    img: p.media_url ? p.media_url : "/assets/img/shop/product-default.jpg",
    reviews: [],
    tags: [],
    parent: p.parent || "",
    children: p.children || "",
    brand: p.brand || {},
    imageURLs: p.imageURLs || [],
    createdAt: p.createdAt || "",
    total_stock: parseFloat(p.total_stock) || 0,
    continue_selling_oos: p.continue_selling_oos || false,
    has_discount: p.has_discount || false,
    discount_type: p.discount_type || "",
    free_count: p.free_count || 0,
    buy_count: p.buy_count || 0,
    discount_amount: p.discount_amount,
    compare_price: p.has_discount
      ? parseFloat(p.price) - parseFloat(p.discount_amount) || 0
      : 0,
  });

  // ---- Filtering ----
  const filteredRows = all_products.map(mapToFrontendProduct);

  // Handlers for filters
  const handlePriceChange = (val) => {
    console.log(val)
    if (!Array.isArray(val) || val.length !== 2) return;

    let [min, max] = val;

    // ⛔ ignore invalid ranges
    if (min > max) {
      [min, max] = [max, min]; // auto-fix
    }

    setPriceValue([min, max]);
  };

  const handleFinalChange = (val) => {
    setPage(1);
    const [minPrice, maxPrice] = val;

    // Create new query object
    const newQuery = {
      ...router.query,
      minPrice: minPrice.toString(),
      maxPrice: maxPrice.toString(),
    };

    router.push({
      pathname: "/shop",
      query: newQuery,
    });
    dispatch(handleFilterSidebarClose());
  };
  const selectHandleFilter = (e) => setSelectValue(e.value);

  const otherProps = {
    priceFilterValues: { priceValue, handleChanges: handlePriceChange },
    selectHandleFilter,
    page,
    setPage,
    productsPerPage: 12,
    totalResults: filteredRows.length,
    categories,
  };

  // --- Data normalization ---
  if (isLoading || isFetching || !categoriesData) return;
  <Wrapper>
    <HeaderTwo style_2={true} />
    <ShopLoader loading />
  </Wrapper>;

  if (isError)
    return (
      <Wrapper>
        <SEO pageTitle="Shop" />
        <HeaderTwo style_2={true} />
        <ShopBreadcrumb title="Shop Grid" subtitle="Shop Grid" />
        <div className="pb-80 text-center">
          <ErrorMsg msg="There was an error" />
        </div>
        <Footer primary_style={true} />
      </Wrapper>
    );

  return (
    <Wrapper>
      <SEO pageTitle="Shop" />
      <HeaderTwo style_2={true} />
      <div className="mt-50 mb-4"></div>
      <ShopArea
        products={filteredRows}
        otherProps={otherProps}
        page={page}
        setPage={setPage}
        allPages={allPages}
        setAllPages={setAllPages}
        total={total}
        selectValue={selectValue}
        setSelectValue={setSelectValue}
        setStatus={setStatus}
        maxValue={maxValue}
        handleFinalChange={handleFinalChange}
        collections={collections}
        categoryLabel={categoryLabel}
        collectionLabel={collectionLabel}
      />
      <ShopFilterOffCanvas
        all_products={filteredRows}
        otherProps={otherProps}
        maxValue={maxValue}
        handleFinalChange={handleFinalChange}
        setStatus={setStatus}
        setPage={setPage}
      />
      <Footer primary_style={true} />
    </Wrapper>
  );
};

export default ShopPage;
