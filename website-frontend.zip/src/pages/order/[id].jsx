import { useRouter } from "next/router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import dayjs from "dayjs";
import ReactToPrint from "react-to-print";
// internal
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";
import logo from "@assets/img/logo/logo.svg";
import ErrorMsg from "@/components/common/error-msg";
import { useGetUserOrderByIdQuery } from "@/redux/features/order/orderApi";
import PrdDetailsLoader from "@/components/loader/prd-details-loader";
import {
  useGetBrandingSettingsQuery,
  useGetSystemSettingsQuery,
} from "@/redux/features/brandingSettingsApi";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";
import StripeModal from "@/components/payment/StripeModal";
import Script from "next/script";
import Swal from "sweetalert2";
import BankDetails from "@/components/payment/BankDetails";
import { useGetAllpaymentMethodPayQuery } from "@/redux/features/productApi";
import { measurementConverter } from "@/hooks/useMeasurementConverter ";

const SingleOrder = ({ params, query }) => {
  const [showModal, setShowModal] = useState(false);
  const [StripeModalOpen, setStripeModalOpen] = useState(false);
  const [amount, setAmount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const orderId = params.id;
  const notify = query.notify == "true";

  const printRef = useRef();
  const { data: order, isError, isLoading } = useGetUserOrderByIdQuery(orderId);
  const { data: brandingData } = useGetBrandingSettingsQuery();
  const { data: paymentMethods = [] } = useGetAllpaymentMethodPayQuery();
  const { data: systemData } = useGetSystemSettingsQuery();

  const terms_conditions = systemData?.terms_conditions || [];

  const symbol = useCurrencySymbol();
  let content = null;

  if (isLoading) {
    content = <PrdDetailsLoader loading={isLoading} />;
  }
  if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  }

  useEffect(() => {
    if (order?.order) {
      const orderDetails = order?.order;
      if (
        orderDetails.payment_method_id === 1 &&
        order?.order?.payment_status == "unpaid"
      ) {
        handlePayment();
      } else if (
        orderDetails.payment_method_id === 4 &&
        order?.order?.payment_status == "unpaid"
      ) {
        setShowModal(true);
      }
    }
  }, [order, order?.order]);

  const [bankDetails, setBankDetails] = useState({});

  useEffect(() => {
    if (!order?.order?.payment_intraduction) {
      setBankDetails({});
      return;
    }
    const cleaned = order?.order?.payment_intraduction.replace(/[{}"]/g, "");
    const pairs = cleaned.split(",");
    const detailsObj = {};
    pairs.forEach((pair) => {
      const [key, value] = pair.split(":");
      if (key && value) {
        detailsObj[key.trim()] = value.trim();
      }
    });
    setBankDetails(detailsObj);
  }, [order?.order?.payment_intraduction]);

  const orderItems = order?.order?.order_items || [];

  const hasProductDiscount = useMemo(() => {
    return orderItems.some((item) => Number(item.product_discount || 0) > 0);
  }, [orderItems]);

  const calculateFinalAmount = (method) => {
    const { full_amount, transaction_fee } = order.order;
    const baseAmount = parseFloat(full_amount ?? 0);
    const order_transaction_fee = parseFloat(transaction_fee ?? 0);

    const transactionFee = parseFloat(method.transaction_fee ?? 0);
    const fixedFee = parseFloat(method.transaction_fixed_fee ?? 0);

    // Case 1: commission_status = true
    if (method.commission_status) {
      const percentageFee = (full_amount * transactionFee) / 100;
      return (
        baseAmount -
        order_transaction_fee +
        percentageFee +
        fixedFee
      ).toFixed(2);
    }

    // Default: no extra fee
    return (baseAmount - order_transaction_fee).toFixed(2);
  };

  if (!isLoading && !isError) {
    const {
      name,
      country,
      city,
      contact,
      order_id,
      created_at,
      order_items,
      delivery_fee,
      discount,
      method_name,
      first_name,
      last_name,
      contact_number_1,
      payment_status,
      sender_name,
      sender_city,
      sender_phone,
      sender_email,
      sender_country,
      sender_address,
      recipient_name,
      recipient_contact,
      recipient_email,
      recipient_address,
      recipient_city,
      recipient_country,
      payment_method_id,
      tax,
      tax_percentage,
      total_value,
      discount_type,
      full_amount,
      loyalty_points_spent,
      currency,
      transaction_fee,
    } = order.order;
    content = (
      <>
        <section className="invoice__area pt-60 pb-60">
          <div className="container">
            <div className="invoice__msg-wrapper">
              <div className="row">
                <div className="col-xl-12">
                  {notify && (
                    <div className="invoice_msg mb-40 alert alert-success d-flex align-items-center gap-2 shadow-md">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="36"
                        height="36"
                        viewBox="0 0 48 48"
                      >
                        <circle cx="24" cy="24" r="21" fill="#4caf50" />
                        <path
                          fill="#ccff90"
                          d="M34.6 14.6L21 28.2l-5.6-5.6l-2.8 2.8l8.4 8.4l16.4-16.4z"
                        />
                      </svg>

                      <p className="text-black fs-6 mb-0">
                        Thank you <strong>{name}</strong> Your order has been
                        received!{" "}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div
              ref={printRef}
              className="invoice__wrapper grey-bg-2 p-3 p-sm-4 tp-invoice-print-wrapper rounded-4 shadow-sm"
            >
              <div className="invoice__header-wrapper border-2 border-bottom border-white mb-40 ">
                <div className="row">
                  <div className="col-xl-12">
                    <div className="invoice__header pb-20 ">
                      <div className="row align-items-end">
                        <div className="col-md-4 col-sm-6">
                          <div className="invoice__left">
                            <Image
                              src={brandingData?.logo_url_white}
                              width={100}
                              height={40}
                              alt="logo"
                              style={{ width: "120px", height: "auto" }}
                            />
                            <p className="mb-0 lh-base mt-2">
                              {brandingData?.company_name}
                            </p>
                            <p className="mb-0 lh-base">
                              {brandingData?.address_1}
                            </p>
                            <p className="mb-0 lh-base">
                              {brandingData?.address_2}{" "}
                            </p>
                          </div>
                        </div>
                        <div className="col-md-8 col-sm-6">
                          <div className="invoice__right mt-15 mt-sm-0 text-sm-end pb-0">
                            <h3 className="text-uppercase font-70 mb-5">
                              Invoice
                            </h3>
                            <div className="invoice__details mb-0 text-md-end">
                              <p className="mb-0 lh-base">
                                <strong>Invoice ID:</strong> #{order_id}
                              </p>
                              <p className="mb-0 lh-base">
                                {/* <strong>Date:</strong>{" "} */}
                                {dayjs(created_at).format("MMMM D, YYYY")}
                              </p>
                              <p className="mb-0">
                                {payment_status === "paid" && (
                                  <span className="badge text-bg-success fs-6 mt-1 ">
                                    Paid
                                  </span>
                                )}
                                {payment_status === "unpaid" && (
                                  <span className="badge text-bg-warning fs-6 mt-1 mb-0">
                                    Unpaid
                                  </span>
                                )}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Billing & Delivery Details */}
              <div className="invoice__customer mb-30">
                <div className="row">
                  {/* Billing Details */}
                  <div className="col-md-6 col-sm-8">
                    <div className="invoice__customer-details">
                      <p className="text-uppercase mb-2 fw-bold">
                        Billing Details
                      </p>
                      <h6 className="mb-5 text-uppercase fw-normal">
                        {sender_name}
                      </h6>
                      <p className="mb-0 text-capitalize lh-base">
                        {sender_address},
                      </p>
                      <p className="mb-0 text-capitalize lh-base">
                        {sender_city},
                      </p>
                      <p className="mb-0 text-capitalize lh-base">
                        {sender_country},
                      </p>
                      <p className="mb-0 lh-base">{sender_phone}</p>
                    </div>
                  </div>
                  {/* Delivery Details */}
                  <div className="col-md-6 col-sm-4">
                    <div className="invoice__details mt-md-0 mt-20 text-md-end">
                      <p className="text-uppercase mb-2 fw-bold ">
                        Delivery Details
                      </p>
                      <h6 className="mb-5 text-uppercase fw-normal">
                        {recipient_name}
                      </h6>
                      <p className="mb-0 text-capitalize lh-base">
                        {recipient_address},
                      </p>
                      <p className="mb-0 text-capitalize lh-base">
                        {recipient_city},
                      </p>
                      <p className="mb-0 text-capitalize lh-base">
                        {recipient_country},
                      </p>
                      <p className="mb-0 lh-sm">{recipient_contact}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mobile Card View - Hidden on desktop */}
              <div className="d-md-none d-print-none">
                <div>
                  {/* Order Items Card */}
                  <div className="card shadow-sm mb-3">
                    <div className="card-body p-3">
                      <h6 className="fw-semibold mb-2">Order Items</h6>

                      <ul className="list-group list-group-flush">
                        {order_items.map((item, i) => {
                          const unitTotal =
                            Number(item.unit_price) * Number(item.quantity);

                          const discount = Number(item.product_discount || 0);

                          const finalTotal = unitTotal - discount;
                          return (
                            <li key={i} className="list-group-item px-0">
                              {/* Top: name + variant + id */}
                              <div className="d-flex flex-column">
                                <p className="mb-1 small fw-semibold">
                                  {item.product_name}{" "}
                                  <span className="badge text-bg-light border text-muted">
                                    ID: {item.variant_id}
                                  </span>
                                </p>

                                {item.variant_value && (
                                  <span className="badge text-bg-secondary align-self-start mb-1">
                                    {item.variant_value}
                                  </span>
                                )}
                                <small className="text-muted">
                                  ID: {item.variant_id}
                                </small>
                              </div>

                              {/* Separator before amount block */}
                              <div className="mt-2">
                                <div className="d-flex align-items-baseline gap-2">
                                  <p className="mb-0 small fw-medium">
                                    {currency}{" "}
                                    {Number(item.unit_price).toFixed(2)} ×
                                  </p>
                                  <p className="mb-0 small fw-medium">
                                    {item.product_measurement_id == 1
                                      ? item.quantity
                                      : `(${item.amount_per_unit}${item.product_measurement_name} *${item.quantity})`}
                                  </p>
                                  {item.free_quantity > 0 && (
                                    <span className="text-success fw-semibold">
                                      {" + "}
                                      {item.product_measurement_id !== 1
                                        ? `${
                                            Number(item.amount_per_unit) *
                                            Number(item.free_quantity)
                                          }${item.product_measurement_name}`
                                        : item.free_quantity}
                                      {" FREE"}
                                    </span>
                                  )}
                                </div>
                                <p className="mb-0 small fw-semibold">
                                  {currency}{" "}
                                  {discount > 0 ? (
                                    <>
                                      <span
                                        style={{
                                          textDecoration: "line-through",
                                          textDecorationColor: "#bbb",
                                          marginRight: "6px",
                                          fontWeight: 400,
                                        }}
                                      >
                                        {unitTotal.toFixed(2)}
                                      </span>

                                      <span>{finalTotal.toFixed(2)}</span>
                                    </>
                                  ) : (
                                    <span>{unitTotal.toFixed(2)}</span>
                                  )}
                                </p>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>

                  {/* Order Summary Card */}
                  <div className="card shadow-sm border rounded-3 bg-light">
                    <div className="card-body p-3">
                      <h6 className="fw-semibold mb-3">Order Summary</h6>

                      <div className="d-flex justify-content-between small mb-2 fw-semibold">
                        <span className="">Subtotal</span>
                        <span className="fw-medium">
                          {currency} {parseFloat(total_value ?? 0).toFixed(2)}
                        </span>
                      </div>
                      {parseFloat(discount) > 0 &&
                        discount_type !== "product" &&
                        discount_type !== "shipping" && (
                          <div className="border-top pt-2 mt-2 d-flex justify-content-between small fw-semibold">
                            <span>
                              {{
                                order: "Order Discount",
                                payment_method: "Payment Method Discount",
                                shipping: "Delivery Fee Discount",
                                buyxgety: "BuyXGetY Discount",
                                code: "Promo Code Discount",
                              }[discount_type] || "Discount"}
                            </span>
                            <span>
                              {currency} -{" "}
                              {Number.parseFloat(discount ?? 0).toFixed(2)}
                            </span>
                          </div>
                        )}

                      <div className="d-flex justify-content-between small mb-2 border-top pt-2 mt-2">
                        <span className="">Delivery Fee</span>
                        <span className="fw-medium">
                          {currency}{" "}
                          {Number.parseFloat(delivery_fee).toFixed(2)}
                        </span>
                      </div>
                      {parseFloat(discount) > 0 &&
                        discount_type == "shipping" && (
                          <div className="d-flex justify-content-between small mb-2 ">
                            <span>
                              {{
                                order: "Order Discount",
                                payment_method: "Payment Method Discount",
                                shipping: "Delivery Fee Discount",
                                buyxgety: "BuyXGetY Discount",
                                code: "Promo Code Discount",
                              }[discount_type] || "Discount"}
                            </span>
                            <span>
                              {currency} -{" "}
                              {Number.parseFloat(discount ?? 0).toFixed(2)}
                            </span>
                          </div>
                        )}

                      {tax && (
                        <div className="d-flex justify-content-between small mb-2 border-top pt-2">
                          <span className="text-muted">
                            {tax.name} ({tax_percentage}%)
                          </span>
                          <span className="fw-medium">
                            {currency} {Number.parseFloat(tax.value).toFixed(2)}
                          </span>
                        </div>
                      )}

                      {Number(order?.order?.transaction_fee) > 0 && (
                        <div className="d-flex justify-content-between small mb-2 border-top pt-2">
                          <span className="text-muted">Transaction Fee</span>
                          <span className="fw-medium">
                            {currency}{" "}
                            {Number(order?.order?.transaction_fee).toFixed(2)}
                          </span>
                        </div>
                      )}

                      <div className="border-top pt-2 mt-2 d-flex justify-content-between small fw-semibold">
                        <span>Total</span>
                        <span>
                          {currency}{" "}
                          {(
                            parseFloat(full_amount ?? 0) +
                            parseFloat(loyalty_points_spent)
                          ).toFixed(2)}
                        </span>
                      </div>

                      {parseFloat(loyalty_points_spent) > 0 && (
                        <>
                          <div className="d-flex justify-content-between small ">
                            <span>Loyalty Points</span>
                            <span>
                              {currency}{" "}
                              {parseFloat(loyalty_points_spent ?? 0).toFixed(2)}
                            </span>
                          </div>
                          <div className="d-flex justify-content-between small mb-2 fw-semibold">
                            <span>Balance</span>
                            <span>
                              {currency}{" "}
                              {parseFloat(full_amount ?? 0).toFixed(2)}
                            </span>
                          </div>
                        </>
                      )}

                      <div className="border-top pt-2 mt-2 d-flex justify-content-between small">
                        <span className="text-muted">Payment Method</span>
                        <span className="fw-medium">{method_name}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {order?.order.payment_method_id === 4 && (
                  <div className="bg-white p-3 mt-2">
                    {Object.entries(bankDetails).map(([key, value]) => (
                      <pre
                        style={{
                          whiteSpace: "pre-wrap",
                          wordWrap: "break-word",
                          fontSize: "16px",
                        }}
                        key={key}
                      >
                        {value}
                      </pre>
                    ))}
                  </div>
                )}
              </div>

              <div className="invoice__order-table p-4 bg-white mb-30 d-none d-md-block d-print-block">
                <div className="table-responsive ">
                  <table className="table">
                    <thead className="table-light">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col" style={{ maxWidth: "300px" }}>
                          Product Details
                        </th>
                        <th className="text-end " scope="col">
                          Quantity
                        </th>
                        <th className="text-end " scope="col">
                          Item Price ({currency})
                        </th>
                        {hasProductDiscount && (
                          <th className="text-end" scope="col">
                            Discount ({currency})
                          </th>
                        )}

                        <th className="text-end " scope="col">
                          Amount ({currency})
                        </th>
                      </tr>
                    </thead>
                    <tbody className="table-group-divider">
                      {order_items.map((item, i) => {
                        const unitTotal =
                          Number(item.unit_price) * Number(item.quantity);

                        const discount = Number(item.product_discount || 0);

                        const finalTotal = unitTotal - discount;
                        return (
                          <tr key={i}>
                            <td>{item.variant_id}</td>
                            <td style={{ maxWidth: "300px" }}>
                              <span className="fw-semibold">
                                {item.product_name}{" "}
                              </span>
                              {item.variant_value !== "Default" && (
                                <span
                                  className="text-muted bg-light rounded-pill px-2 capitalize"
                                  style={{
                                    maxWidth: "150px",
                                    fontSize: "11px",
                                  }}
                                >
                                  {item.variant_value}
                                </span>
                              )}

                              {item.product_measurement_id !== 1 && (
                                <span
                                  className="text-muted bg-light rounded-pill px-2 capitalize"
                                  style={{
                                    maxWidth: "150px",
                                    fontSize: "11px",
                                  }}
                                >
                                  {item.quantity} x {item.amount_per_unit}
                                  {item.product_measurement_name} per unit
                                </span>
                              )}
                            </td>
                            <td className="text-end">
                              <div>
                                {item.product_measurement_id !== 1 ? (
                                  <>
                                    {/* Aggregated paid quantity */}
                                    {measurementConverter(
                                      Number(item.quantity) *
                                        Number(item.amount_per_unit),
                                      Number(item.product_measurement_id),
                                    )}

                                    {/* FREE quantity */}
                                    {item.free_quantity > 0 && (
                                      <span className="text-success fw-semibold">
                                        {" + ("}
                                        {measurementConverter(
                                          Number(item.free_quantity) *
                                            Number(item.amount_per_unit),
                                          Number(item.product_measurement_id),
                                        )}{" "}
                                        FREE
                                        {")"}
                                      </span>
                                    )}
                                  </>
                                ) : (
                                  <>
                                    {/* Quantity only (no measurement) */}
                                    {item.quantity}

                                    {/* FREE quantity */}
                                    {item.free_quantity > 0 && (
                                      <span className="text-success fw-semibold">
                                        {" + ("}
                                        {item.free_quantity} FREE
                                        {")"}
                                      </span>
                                    )}
                                  </>
                                )}
                              </div>
                            </td>

                            {/* <td className="text-center ">
                            {item.product_measurement_id == 1 ? 'piece(s)' : `${item.amount_per_unit}${item.product_measurement_name}`}
                          </td> */}
                            <td className="text-end ">
                              {parseFloat(item.unit_price).toFixed(2)}
                            </td>
                            {hasProductDiscount && (
                              <td className="text-end">
                                {discount > 0 ? (
                                  <div className="d-flex flex-column">
                                    {discount.toFixed(2)}
                                  </div>
                                ) : (
                                  <div className="fw-semibold">-</div>
                                )}
                              </td>
                            )}

                            <td className="text-end">
                              {discount > 0 ? (
                                <div
                                  className="d-flex flex-column "
                                  style={{ lineHeight: "15px" }}
                                >
                                  <div
                                    style={{
                                      textDecoration: "line-through",
                                      fontSize: "11px",
                                      color: "#888",
                                    }}
                                  >
                                    {unitTotal.toFixed(2)}
                                  </div>

                                  <div className="fw-semibold">
                                    {finalTotal.toFixed(2)}
                                  </div>
                                </div>
                              ) : (
                                <div className="fw-semibold">
                                  {unitTotal.toFixed(2)}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                      <tr className="fw-semibold bg-light">
                        <td></td>
                        <td></td>
                        <td></td>
                        {hasProductDiscount && (
                          <td className="text-center "></td>
                        )}
                        <td className="text-end ">Subtotal</td>
                        <td className="text-end ">
                          {parseFloat(total_value ?? 0).toFixed(2)}
                        </td>
                      </tr>
                      {parseFloat(discount) > 0 &&
                        discount_type !== "product" &&
                        discount_type !== "shipping" && (
                          <tr>
                            <td></td>
                            <td></td>

                            <td></td>
                            {hasProductDiscount && (
                              <td className="text-center "></td>
                            )}
                            <td className="text-end ">
                              {" "}
                              {{
                                order: "Order Discount",
                                payment_method: "Payment Method Discount",
                                shipping: "Delivery Fee Discount",
                                buyxgety: "BuyXGetY Discount",
                                code: "Promo Code Discount",
                              }[discount_type] || "Discount"}
                            </td>
                            <td className="text-end ">
                              - {parseFloat(discount).toFixed(2)}
                            </td>
                          </tr>
                        )}

                      <tr>
                        <td></td>
                        <td></td>

                        <td></td>
                        {hasProductDiscount && (
                          <td className="text-center "></td>
                        )}
                        <td className="text-end ">Delivery Fee</td>
                        <td className="text-end ">
                          {parseFloat(delivery_fee).toFixed(2)}
                        </td>
                      </tr>
                      {parseFloat(discount) > 0 &&
                        discount_type == "shipping" && (
                          <tr>
                            <td></td>
                            <td></td>

                            <td></td>
                            {hasProductDiscount && (
                              <td className="text-center "></td>
                            )}
                            <td className="text-end ">
                              {" "}
                              {{
                                order: "Order Discount",
                                payment_method: "Payment Method Discount",
                                shipping: "Delivery Fee Discount",
                                buyxgety: "BuyXGetY Discount",
                                code: "Promo Code Discount",
                              }[discount_type] || "Discount"}
                            </td>
                            <td className="text-end ">
                              - {parseFloat(discount).toFixed(2)}
                            </td>
                          </tr>
                        )}
                      {tax ? (
                        <tr>
                          <td></td>
                          <td></td>

                          <td></td>
                          {hasProductDiscount && (
                            <td className="text-center "></td>
                          )}
                          <td className="text-end ">
                            {tax.name} ({tax_percentage}%)
                          </td>
                          <td className="text-end ">
                            {parseFloat(tax.value).toFixed(2)}
                          </td>
                        </tr>
                      ) : null}
                      {Number(order?.order?.transaction_fee) > 0 ? (
                        <tr>
                          <td></td>
                          <td></td>

                          <td></td>
                          {hasProductDiscount && (
                            <td className="text-center "></td>
                          )}
                          <td className="text-end ">Transaction Fee</td>
                          <td className="text-end ">
                            {parseFloat(
                              order?.order?.transaction_fee ?? 0,
                            ).toFixed(2)}
                          </td>
                        </tr>
                      ) : null}

                      <tr className="fw-semibold bg-light">
                        <td></td>
                        <td></td>

                        <td></td>
                        {hasProductDiscount && (
                          <td className="text-center "></td>
                        )}
                        <td className="text-end ">Total</td>
                        <td className="text-end ">
                          {(
                            parseFloat(full_amount ?? 0) +
                            parseFloat(loyalty_points_spent)
                          ).toFixed(2)}
                        </td>
                      </tr>
                      {parseFloat(loyalty_points_spent) > 0 ? (
                        <tr>
                          <td></td>
                          <td></td>

                          <td></td>
                          {hasProductDiscount && (
                            <td className="text-center "></td>
                          )}
                          <td className="text-end ">Loyalty Points</td>
                          <td className="text-end ">
                            {parseFloat(loyalty_points_spent ?? 0).toFixed(2)}
                          </td>
                        </tr>
                      ) : null}
                      {parseFloat(loyalty_points_spent) > 0 ? (
                        <tr>
                          <td></td>
                          <td></td>

                          <td></td>
                          {hasProductDiscount && (
                            <td className="text-center "></td>
                          )}
                          <td className="text-end fw-semibold">Balance</td>
                          <td className="text-end fw-semibold">
                            {parseFloat(full_amount ?? 0).toFixed(2)}
                          </td>
                        </tr>
                      ) : null}

                      <tr>
                        <td></td>
                        <td></td>

                        <td></td>
                        {hasProductDiscount && (
                          <td className="text-center "></td>
                        )}
                        <td className="text-end ">Payment Method</td>
                        <td className="text-end ">{method_name}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {order?.order.payment_method_id === 4 && (
                  <div className="bg-light p-3 rounded-4">
                    <h5 style={{ marginBottom: "1rem" }}>Bank Details</h5>
                    {Object.entries(bankDetails).map(([key, value]) => (
                      <p
                        style={{
                          whiteSpace: "pre-wrap",
                          wordWrap: "break-word",
                          fontSize: "15px",
                        }}
                        key={key}
                      >
                        {value}
                      </p>
                    ))}
                  </div>
                )}

                <div
                  style={{ fontSize: "12px", color: "#000", marginTop: "10px" }}
                >
                  <strong>Terms And Condition :</strong>
                  <ul style={{ marginTop: "5px", paddingLeft: "18px" }}>
                    {terms_conditions?.map((item, index) => (
                      <li key={index} style={{ marginBottom: "4px" }}>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
            <div className="invoice__actions-wrapper mt-4 p-4 bg-light rounded-4 border">
              <div className="d-flex flex-column flex-md-row align-items-center justify-content-between gap-3">
                {/* Payment Section */}
                {/* Secondary Actions Section */}
                <div className="invoice__secondary-actions ps-md-3">
                  <ReactToPrint
                    trigger={() => (
                      <button
                        type="button"
                        className="btn btn-link text-dark text-decoration-none d-flex align-items-center gap-2 fw-bold"
                        style={{ fontSize: "15px" }}
                      >
                        <i className="fa-light fa-print"></i>
                        Print Invoice
                      </button>
                    )}
                    content={() => printRef.current}
                    documentTitle="Invoice"
                  />
                </div>
                <div className="invoice__payment-options d-flex flex-wrap align-items-center gap-2  border-start ps-3">
                  {payment_status === "unpaid" &&
                    paymentMethods.map((method) => {
                      // Shared styles for payment buttons
                      const btnStyle = {
                        transition: "all 0.3s ease",
                        fontWeight: "600",
                        fontSize: "14px",
                        letterSpacing: "0.3px",
                        border: "1px solid transparent",
                      };

                      if (method.payment_method_id === 1) {
                        return (
                          <button
                            key={method.payment_method_id}
                            type="button"
                            className="btn border-primary px-4 py-2 rounded-pill d-flex align-items-center gap-2 shadow-sm cursor-pointer"
                            style={btnStyle}
                            onClick={() => handlePayment()}
                          >
                            <img
                              src={method.logo}
                              alt=""
                              style={{
                                height: 20,
                                // filter: "brightness(0) invert(1)",
                              }}
                            />
                            <span>
                              Pay Now ({currency} {calculateFinalAmount(method)}
                              )
                            </span>
                          </button>
                        );
                      }

                      if (method.payment_method_id === 2) {
                        return (
                          <button
                            key={method.payment_method_id}
                            type="button"
                            className="btn border-primary px-4 py-2 rounded-pill d-flex align-items-center gap-2 shadow-sm cursor-pointer"
                            style={btnStyle}
                            onClick={() => setStripeModalOpen(true)}
                          >
                            <img
                              src={method.logo}
                              alt=""
                              style={{
                                height: 20,
                                // filter: "brightness(0) invert(1)",
                              }}
                            />
                            <span>
                              Pay Now ({currency} {calculateFinalAmount(method)}
                              )
                            </span>
                          </button>
                        );
                      }

                      if (method.payment_method_id === 10) {
                        return (
                          <button
                            key={method.payment_method_id}
                            disabled={loading}
                            type="button"
                            className="btn btn-outline-primary px-4 py-2 rounded-pill d-flex align-items-center gap-2 shadow-sm bg-white cursor-pointer"
                            style={{
                              ...btnStyle,
                              cursor: loading ? "not-allowed" : "pointer",
                              color: "#6e41e2",
                              borderColor: "#6e41e2",
                            }}
                            onClick={() => handlePayNow()}
                          >
                            <img
                              src={method.logo}
                              alt=""
                              style={{ height: 20 }}
                            />
                            <span>
                              {loading ? "Redirecting..." : "Pay with Koko"}
                              <small className="ms-1 opacity-75">
                                ({currency} {calculateFinalAmount(method)})
                              </small>
                            </span>
                          </button>
                        );
                      }
                      return null;
                    })}
                </div>
              </div>
            </div>
          </div>
        </section>
      </>
    );
  }

  const handlePayment = async () => {
    const {
      name,
      country,
      city,
      order_id,
      created_at,
      order_items,
      first_name,
      last_name,
      contact_number_1,
      email,
      address,
      count,
      contact,
      delivery_fee,
      discount,
      method_name,
      payment_status,
      sender_name,
      sender_city,
      sender_phone,
      sender_email,
      sender_country,
      sender_address,
      recipient_name,
      recipient_contact,
      recipient_email,
      recipient_address,
      recipient_city,
      recipient_country,
      payment_method_id,
      tax,
      tax_percentage,
      loyalty_points_spent,
      full_amount,
    } = order.order;

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/order/payherehash`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            order_id: order_id,
            amount: parseFloat(full_amount).toFixed(2),
          }),
        },
      );
      if (response.ok) {
        const data = await response.json();

        if (data) {
          console.log(data);
          console.log(data.merchant_id);

          payhere.onCompleted = function onCompleted(orderId) {
            console.log("Payment completed. OrderID:" + orderId);

            Swal.fire({
              title: "Payment Successful!",
              text: `Your payment was completed. Order ID: ${orderId}`,
              icon: "success",
              confirmButtonText: "OK",
            });

            window.location.reload();
            // Note: validate the payment and show success or failure page to the customer
          };

          // Payment window closed
          payhere.onDismissed = function onDismissed() {
            // Note: Prompt user to pay again or show an error page
            console.log("Payment dismissed");
          };

          // Error occurred
          payhere.onError = function onError(error) {
            // Note: show an error page
            console.log("Error:" + error);
          };

          // Put the payment variables here
          var payment = {
            sandbox: data.sandbox,
            merchant_id: data.merchant_id, // Replace your Merchant ID
            return_url: process.env.NEXT_PUBLIC_RETURN_URL, // Important
            cancel_url: process.env.NEXT_PUBLIC_CANCEL_URL, // Important
            notify_url: process.env.NEXT_PUBLIC_NOTIFY_URL, // Important
            order_id: order_id,
            items: order_id,
            amount: parseFloat(data.amount).toFixed(2),
            currency: data.currency,
            hash: data.local_md5sig, // *Replace with generated hash retrieved from backend
            first_name: sender_name,
            last_name: "",
            email: sender_email,
            phone: sender_phone,
            address: sender_address,
            city: sender_city,
            country: sender_country || "Sri Lanka",
            delivery_address: recipient_address,
            delivery_city: recipient_city,
            delivery_country: recipient_country,
            custom_1: "",
            custom_2: "",
          };

          payhere.startPayment(payment);
        }
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  async function handlePayNow() {
    const { order_id } = order.order;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/koko/initiate`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            id: order_id,
          }),
        },
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Failed to initiate payment");
      }
      // console.log(data)
      // return
      // ✅ Create form dynamically
      const form = document.createElement("form");
      form.method = "POST";
      form.action = data.actionUrl;

      // ✅ Add all payload fields as hidden inputs
      Object.entries(data.payload).forEach(([key, value]) => {
        const input = document.createElement("input");
        input.type = "hidden";
        input.name = key;
        input.value = value;
        form.appendChild(input);
      });

      document.body.appendChild(form);

      // ✅ Submit form → redirects to Koko
      form.submit();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <>
        <Script src="https://www.payhere.lk/lib/payhere.js"></Script>
      </>
      <Wrapper>
        <SEO pageTitle={"Order Details"} />
        <HeaderTwo style_2={true} />
        {/* content */}
        {content}
        {/* content */}
        {/* footer start */}
        <Footer primary_style={true} />
        {/* footer end */}
      </Wrapper>

      <StripeModal
        show={StripeModalOpen}
        onClose={() => setStripeModalOpen(false)}
        amount={order?.order?.full_amount}
        order_id={order?.order?.order_id}
      />

      <BankDetails
        show={showModal}
        onClose={() => setShowModal(false)}
        details={order?.order?.payment_intraduction}
      />
    </>
  );
};

export const getServerSideProps = async ({ params, query }) => {
  return {
    props: { params, query },
  };
};

export default SingleOrder;
