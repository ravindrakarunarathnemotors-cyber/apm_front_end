// pages/product/components/slugId_body.jsx
"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import ProductDetailsBreadcrumb from "@/components/breadcrumb/product-details-breadcrumb";
import ProductDetailsArea from "@/components/product-details/product-details-area";
import { slugify } from "@/lib/slugify";
import {
  useGetProductIdMutation,
  useGetProductVariantMutation,
  useGetoneProductReviewMutation,
  useIncrementViewCountMutation,
} from "@/redux/features/productApi";

export default function SlugIdBody({ product, slugId, productId }) {
  const router = useRouter();

  const [getProductVariant] = useGetProductVariantMutation();
  const [variant, setVariant] = useState(null);
  const [getProductId] = useGetProductIdMutation();
  const [getoneProductReview, { data: oneReview }] =
    useGetoneProductReviewMutation();
  const [incrementViewCount] = useIncrementViewCountMutation();

  useEffect(() => {
    if (!productId) return;

    getoneProductReview(productId);
    getProductId(productId);
    incrementViewCount(productId);
    getProductVariant(productId)
      .unwrap()
      .then(setVariant)
      .catch(() => setVariant(null));
  }, [productId]);

  // Normalize URL on client
  useEffect(() => {
    if (!product || !productId) return;

    const desired = `/product/${slugify(
      product.product_name || product.title || "product"
    )}-${productId}`;

    const current = router.asPath.split("?")[0];

    if (desired !== current) {
      const qs = router.asPath.includes("?")
        ? router.asPath.slice(router.asPath.indexOf("?"))
        : "";
      router.replace(`${desired}${qs}`, undefined, { shallow: true });
    }
  }, [product, productId, router]);

  const title = product.product_name || product.title || "Product";
  console.log('TEST', product)

  return (
    <>
      <ProductDetailsBreadcrumb title={title} />
      <ProductDetailsArea
        productItem={product.__raw}
        variant={variant}
        product_id={productId}
        oneReview={oneReview}
      />
    </>
  );
}
