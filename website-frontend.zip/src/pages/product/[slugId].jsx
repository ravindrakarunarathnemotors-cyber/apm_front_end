// pages/product/[slugId].jsx
import React from "react";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";
import ErrorMsg from "@/components/common/error-msg";
import PrdDetailsLoader from "@/components/loader/prd-details-loader";
import ProductSeo from "@/components/product_seo";
import dynamic from "next/dynamic";
import ProductNotFound from "@/components/common/product-not-found";


const SlugIdBody = dynamic(() => import("./components/slugId_body"), {
  ssr: false,
});

export default function ProductPrettyUrlPage({
  product,
  slugId,
  productId,
  hasError,
  branding,
  systemSettings,
  availability,
}) {
  if (hasError) {
    return (
      <>
        <ProductSeo
          product={product}
          branding={branding}
          system={systemSettings}
          productAvailability={availability}
        />
        <Wrapper>
          <HeaderTwo style_2 />
          <div className="container py-5 text-center">
            <ProductNotFound />
            {/* <ErrorMsg msg="Product not found." /> */}
          </div>
          <Footer primary_style />
        </Wrapper>
      </>
    );
  }

  if (!product) {
    return <PrdDetailsLoader loading />;
  }

  return (
    <>
      <ProductSeo
        product={product}
        branding={branding}
        system={systemSettings}
        productAvailability={availability}
      />
      <Wrapper>
        <HeaderTwo style_2 />
        <SlugIdBody product={product} slugId={slugId} productId={productId} />
        <Footer primary_style />
      </Wrapper>
    </>
  );
}

export async function getServerSideProps({ params }) {
  const { slugId } = params;
  if (!slugId) return { notFound: true };

  const s = Array.isArray(slugId) ? slugId[0] : slugId;
  const match = s.match(/-(\d+)$/);
  const productId = match ? Number(match[1]) : null;
  if (!productId) return { notFound: true };

  try {
    const base = process.env.NEXT_PUBLIC_BASE_URL || "";
    // Fetch in parallel
    const [productRes, brandingRes, systemRes, availabilityRes] =
      await Promise.all([
        fetch(`${base}/product/get-product-id`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ product_id: productId }),
        }),
        fetch(`${base}/branding/settings`),
        fetch(`${base}/system/settings`),
        fetch(`${base}/product/one-product-available/${productId}`),
      ]);

    // Fail fast if product API failed
    if (!productRes.ok) {
      const text = await productRes.text().catch(() => "");
      console.error("productRes failed", productRes.status, text);
      return {
        props: { product: null, slugId: s, productId, hasError: true },
      };
    }

    // Parse JSON (fallback to {})
    const [productJson, brandingJson, systemJson, availabilityJson] =
      await Promise.all([
        productRes.json().catch(() => ({})),
        brandingRes.ok ? brandingRes.json().catch(() => ({})) : {},
        systemRes.ok ? systemRes.json().catch(() => ({})) : {},
        availabilityRes.ok ? availabilityRes.json().catch(() => ({})) : {},
      ]);

    // raw product object (adapt if your API shape is different)
    const raw = productJson.result ?? productJson.data ?? productJson ?? null;
    // console.log(
    //   "SSR raw product for id",
    //   productId,
    //   raw ? Object.keys(raw) : "NULL"
    // );

    if (!raw) {
      return {
        props: { product: null, slugId: s, productId, hasError: true },
      };
    }

    // Normalize product shape (keeps both product_id and id)
    const product = {
      product_id: raw.product_id ?? raw.id ?? productId,
      id: raw.id ?? raw.product_id ?? productId,
      title: raw.title ?? raw.product_name ?? raw.name ?? "",
      price: raw.price ?? raw.sell_price ?? 0,
      // prefer media_url, else other_images[0], else raw.image
      media_url:
        raw.media_url && String(raw.media_url).trim()
          ? String(raw.media_url)
          : Array.isArray(raw.other_images) && raw.other_images[0]
          ? raw.other_images[0]
          : raw.image ?? "",
      // SEO description: prefer explicit search_engine_desc, then description
      search_engine_desc:
        raw.search_engine_desc ?? raw.meta_description ?? raw.description ?? "",
      description: raw.description ?? "",
      // include full raw for debugging if needed
      __raw: raw,
    };

    // Build absolute URL for media if necessary
    const siteUrl =
      brandingJson.data?.website_url ||
      process.env.NEXT_PUBLIC_SITE_URL ||
      base ||
      "";
    if (product.media_url && !product.media_url.startsWith("http")) {
      const trimmedSite = siteUrl.replace(/\/$/, "");
      product.media_url = product.media_url.startsWith("/")
        ? `${trimmedSite}${product.media_url}`
        : `${trimmedSite}/${product.media_url}`;
    }

    // console.log("SSR product normalized:", {
    //   product_id: product.product_id,
    //   title: product.title,
    //   media_url: product.media_url,
    //   desc: String(product.search_engine_desc).slice(0, 120),
    // });

    const branding = brandingJson.data ?? brandingJson ?? null;
    const systemSettings = systemJson.data ?? systemJson ?? null;
    const availability = availabilityJson ?? null;

    return {
      props: {
        product,
        slugId: s,
        productId,
        branding,
        systemSettings,
        availability,
        hasError: false,
      },
    };
  } catch (err) {
    console.error("SSR getServerSideProps error:", err);
    return {
      props: {
        product: null,
        slugId: s,
        productId,
        hasError: true,
      },
    };
  }
}
