// pages/product-details/[id].jsx
import { slugify } from "@/lib/slugify";

export default function LegacyProductDetailsRedirect() {
  // Never renders because we redirect in GSSP
  return null;
}

export async function getServerSideProps({ params }) {
  const { id } = params;

  // Try to fetch product name to build the slug.
  // Change the URL below to YOUR API that returns one product by id.
  // Fallback to "product" if fetching fails.
  let name = "";
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE_URL}/products/${id}`
    );
    if (res.ok) {
      const product = await res.json();
      name = product?.product_name || product?.title || "";
    }
  } catch (_) {}

  const slug = slugify(name) || "product";

  return {
    redirect: {
      destination: `/product/${slug}-${id}`,
      permanent: true, // 308 under the hood
    },
  };
}
