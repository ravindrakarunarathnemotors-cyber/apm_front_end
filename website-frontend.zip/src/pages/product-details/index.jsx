import React from "react";
import SEO from "@/components/seo";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";
import Wrapper from "@/layout/wrapper";
import ProductDetailsBreadcrumb from "@/components/breadcrumb/product-details-breadcrumb";
import ProductDetailsArea from "@/components/product-details/product-details-area";

const ProductDetailsPage = () => {
  const product = {
    _id: "product123",
    sku: "SKU-00123",
    img: "/images/products/main-product.jpg",
    title: "Stylish Cotton T-Shirt",
    imageURLs: [
      {
        img: "/images/products/tshirt-red.jpg",
        color: {
          name: "Red",
          clrCode: "#FF0000",
        },
      },
      {
        img: "/images/products/tshirt-blue.jpg",
        color: {
          name: "Blue",
          clrCode: "#0000FF",
        },
      },
      {
        img: "/images/products/tshirt-green.jpg",
        color: {
          name: "Green",
          clrCode: "#00FF00",
        },
      },
    ],
    category: { name: "T-Shirts" },
    sizes: ["S", "M", "L", "XL"],
    description:
      "<p>This is a soft and durable cotton t-shirt available in multiple colors.</p>",
    discount: 10,
    price: "2500",
    status: "in-stock",
    reviews: [
      { rating: 4 },
      { rating: 5 },
      { rating: 3.5 },
    ],
    tags: ["cotton", "casual", "tshirt"],
    offerDate: {
      endDate: "2025-07-10T23:59:59Z",
    },
  };

  return (
    <Wrapper>
      <SEO pageTitle="Product Details" />
      <HeaderTwo style_2={true} />
      <ProductDetailsBreadcrumb
        category={product.category.name}
        title={product.title}
      />
      <ProductDetailsArea productItem={product} />
      <Footer primary_style={true} />
    </Wrapper>
  );
};

export default ProductDetailsPage;
