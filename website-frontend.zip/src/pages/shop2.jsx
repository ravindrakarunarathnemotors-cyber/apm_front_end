"use client";
import React, { useState, useMemo, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import { useGetAllProductsWithoutPaginationQuery } from "@/redux/features/productApi";
import {
  useGetmaxPriceQuery,
  useGetShowCollectionQuery,
  useGetShowCategoryQuery,
} from "@/redux/features/categoryApi";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import ShopBreadcrumb from "@/components/breadcrumb/shop-breadcrumb";
import ShopArea from "@/components/shop2/shop-area";
import ErrorMsg from "@/components/common/error-msg";
import Footer from "@/layout/footers/footer";
import ShopFilterOffCanvas from "@/components/common/shop-filter-offcanvas";
import ShopLoader from "@/components/loader/shop/shop-loader";
import { useDispatch } from "react-redux";
import { handleFilterSidebarClose } from "@/redux/features/shop-filter-slice";

// Helper: Find all descendant category IDs for filtering
const getAllDescendantCategoryIds = (catId, categories) => {
  let ids = [catId];
  categories.forEach((cat) => {
    if (cat.category_under === catId) {
      ids = ids.concat(
        getAllDescendantCategoryIds(cat.category_id, categories)
      );
    }
  });
  return ids;
};

// Helper to create a slug
const slugify = (str = "") =>
  str.toLowerCase().replace("&", "").split(" ").join("-");

const ShopPage = () => {
  const router = useRouter();
  const debounceTimerRef = useRef(null);
  const lastRangeRef = useRef([0, 0]);

  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    };
  }, []);

  // Fetch products and categories

  const { data: categoriesData } = useGetShowCategoryQuery();

  // UI state
  const [priceValue, setPriceValue] = useState([0, 0]);
  const [uiPrice, setUiPrice] = useState([0, 0]);
  const [selectValue, setSelectValue] = useState("NewAdded");
  const [currPage, setCurrPage] = useState(1);
  const [selectedCategoryId, setSelectedCategoryId] = useState(null);
  const [page, setPage] = useState(1);
  const [allPages, setAllPages] = useState(0);
  const [total, setTotal] = useState(0);
  const [productsData, setproductsData] = useState([]);
  const [status, setStatus] = useState("");

  const dispatch = useDispatch();

  const { data, isLoading, isError, isFetching } =
    useGetAllProductsWithoutPaginationQuery({
      page,
      selectedCategoryId,
      priceValue: uiPrice,
      selectValue,
      status,
    });

  const { data: maxValue } = useGetmaxPriceQuery();

    const { data: collections = [] } = useGetShowCollectionQuery()

  useEffect(() => {
    if (maxValue?.highest_price) {
      setPriceValue([0, parseFloat(maxValue.highest_price) || 0]);
    }
  }, [maxValue]);

  // --- Effect: sync selectedCategoryId with URL slug ---
  useEffect(() => {
    if (!categoriesData) return;

    const queries = router.query;
    const hasQueries = Object.keys(queries).length > 0;

    // ✅ Reset orderby if no query params at all
    if (!hasQueries) {
      setSelectValue("NewAdded");
      setSelectedCategoryId(null);
      setPriceValue([0, 0]);
      setUiPrice([0, 0]);
      setStatus(null);
      return;
    }

    // ✅ Category filter
    if (queries.category) {
      const matched = categoriesData.find(
        (cat) => slugify(cat.name) === queries.category
      );
      setSelectedCategoryId(matched ? matched.category_id : null);
    } else {
      setSelectedCategoryId(null);
    }

    // ✅ Order by filter
    if (queries.orderby) {
      setSelectValue(queries.orderby);
    }

    // ✅ Price filter
    if (queries.minPrice && queries.maxPrice) {
      const min = parseFloat(queries.minPrice);
      const max = parseFloat(queries.maxPrice);
      if (!isNaN(min) && !isNaN(max)) {
        setPriceValue([min, max]);
        setUiPrice([min, max]);
      }
    }

    // ✅ Status filter
    if (queries.status) {
      const formatted = queries.status
        .split("-")
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
      setStatus(formatted);
    }
  }, [categoriesData, router.query]);

  // console.log(status)

  useEffect(() => {
    if (data) {
      setAllPages(data.allPages || 0);
      setTotal(data.total || 0);
      setproductsData(data.result || []);
    }
  }, [data]);

  const categories = categoriesData;
  const all_products = Array.isArray(productsData) ? productsData : [];

  const mapToFrontendProduct = (p) => ({
    _id: p.product_id,
    title: p.product_name,
    category_id: p.category_id,
    category_name: p.category_name,
    description: p.description,
    price: parseFloat(p.price),
    discount: p.discount || 0,
    status: p.status === "active" ? "in-stock" : "out-of-stock",
    img: p.media_url ? p.media_url : "/assets/img/shop/product-default.jpg",
    reviews: [],
    tags: [],
    parent: p.parent || "",
    children: p.children || "",
    brand: p.brand || {},
    imageURLs: p.imageURLs || [],
    createdAt: p.createdAt || "",
    total_stock: parseFloat(p.total_stock) || 0,
    continue_selling_oos: p.continue_selling_oos || false,
    has_discount: p.has_discount || false,
    discount_type: p.discount_type || "",
    free_count: p.free_count || 0,
    buy_count: p.buy_count || 0,
    discount_amount: p.discount_amount,
    compare_price: p.has_discount
      ? parseFloat(p.price) - parseFloat(p.discount_amount) || 0
      : 0,
  });

  // ---- Filtering ----
  const filteredRows = all_products.map(mapToFrontendProduct);

  // Handlers for filters
  const handlePriceChange = (val) => {
    setPriceValue(val);
  };

  const handleFinalChange = (val) => {
    setPage(1);
    const [minPrice, maxPrice] = val;

    // Create new query object
    const newQuery = {
      ...router.query,
      minPrice: minPrice.toString(),
      maxPrice: maxPrice.toString(),
    };

    router.push({
      pathname: "/shop",
      query: newQuery,
    });
    dispatch(handleFilterSidebarClose());
  };
  const selectHandleFilter = (e) => setSelectValue(e.value);

  const otherProps = {
    priceFilterValues: { priceValue, handleChanges: handlePriceChange },
    selectHandleFilter,
    page,
    setPage,
    productsPerPage: 12,
    totalResults: filteredRows.length,
    categories,
  };

  // --- Data normalization ---
  if (isLoading || isFetching || !categoriesData) return <ShopLoader loading />;
  if (isError)
    return (
      <Wrapper>
        <SEO pageTitle="Shop" />
        {/* <HeaderTwo style_2={true} /> */}
        <ShopBreadcrumb title="Shop Grid" subtitle="Shop Grid" />
        <div className="pb-80 text-center">
          <ErrorMsg msg="There was an error" />
        </div>
        {/* <Footer primary_style={true} /> */}
      </Wrapper>
    );

  return (
    <Wrapper>
      <SEO pageTitle="Shop" />
      {/* <HeaderTwo style_2={true} /> */}
      <div className="mt-4 mb-4"></div>
      <ShopArea
        products={filteredRows}
        otherProps={otherProps}
        page={page}
        setPage={setPage}
        allPages={allPages}
        setAllPages={setAllPages}
        total={total}
        selectValue={selectValue}
        setSelectValue={setSelectValue}
        setStatus={setStatus}
        maxValue={maxValue}
        handleFinalChange={handleFinalChange}
        collections={collections}
      />
      <ShopFilterOffCanvas
        all_products={filteredRows}
        otherProps={otherProps}
        maxValue={maxValue}
        handleFinalChange={handleFinalChange}
        setStatus={setStatus}
        setPage={setPage}
      />
      {/* <Footer primary_style={true} /> */}
    </Wrapper>
  );
};

export default ShopPage;
