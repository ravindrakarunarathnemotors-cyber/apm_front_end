import { useEffect, useState, useMemo } from "react";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderFour from "@/layout/headers/header-4";
import FooterTwo from "@/layout/footers/footer-2";
import { useGetWebSectionsMutation } from "@/redux/features/webstoreSettingsApi";
import dynamic from "next/dynamic";
import MovingBlurBackground from "@/components/Manitenance";

const Home2 = dynamic(() => import("./home-2"));
const Home3 = dynamic(() => import("./home-3"));
const Home4 = dynamic(() => import("./home-4"));
const Home5 = dynamic(() => import("./home-5"));

export const SECTIONS = {
  JewelryBanner: dynamic(() => import("@/components/banner/jewelry-banner")),
  FeatureAreaThree: dynamic(
    () => import("@/components/features/feature-area-3"),
  ),
  PopularProducts: dynamic(
    () => import("@/components/products/jewelry/popular-products"),
  ),
  JewelryAbout: dynamic(() => import("@/components/about/jewelry-about")),
  ProductArea: dynamic(
    () => import("@/components/products/jewelry/product-area"),
  ),
  JewelryCollectionBanner: dynamic(
    () => import("@/components/shop-banner/jewelry-collection-banner"),
  ),
  BestSellerPrd: dynamic(
    () => import("@/components/products/jewelry/best-seller-prd"),
  ),
  JewelryBrands: dynamic(() => import("@/components/brand/jewelry-brands")),
  TrendingProduct: dynamic(
    () => import("@/components/shop-banner/jewelry-shop-banner"),
  ),
};

function DefaultTemplate() {
  const [getWebSections, { data: sectionData, isLoading, isError }] =
    useGetWebSectionsMutation();

  useEffect(() => {
    // Call the mutation when component mounts
    getWebSections(1);
  }, [getWebSections]);
  console.log("sectionData", sectionData);

  const ordered = useMemo(() => {
    return [...(sectionData || [])]
      .filter((s) => typeof s.order === "number" && s.section_key)
      .sort((a, b) => a.order - b.order);
  }, [sectionData]);

  return (
    <Wrapper>
      <SEO pageTitle="Home" />
      <HeaderFour />
      {ordered.map(({ section_key }, idx) => {
        const Comp = SECTIONS[section_key];
        if (!Comp) return null; // unknown keys are skipped safely
        return <Comp key={`${section_key}-${idx}`} />;
      })}
      <FooterTwo />
    </Wrapper>
  );
}

export default function Home({ templateStyle }) {
  // const [Component, setComponent] = useState(null);
  // const [templateStyle, setTemplateStyle] = useState(4);

  if (templateStyle === 2) return <Home2 />;
  if (templateStyle === 3) return <Home3 />;
  if (templateStyle === 4) return <Home4 />;
  if (templateStyle === 5) return <Home5 />;

  // ⬇️ Show your spinner while Component is still null
  if (!Component) {
    return (
      <div
        className="d-flex align-items-center justify-content-center"
        style={{ height: "93vh", width: "97vw" }}
      >
        <span className="spinnerHome"></span>

        <style jsx>{`
          .spinnerHome {
            position: relative;
            width: 100px;
            height: 100px;
          }

          .spinnerHome:before {
            content: "";
            border-radius: 50%;
            position: absolute;
            inset: 1;
            box-shadow: 0 0 8px 2px var(--secondary-color) inset;
          }

          .spinnerHome:after {
            content: "";
            border-radius: 50%;
            position: absolute;
            inset: 0;
            box-shadow: 0 3px 0 var(--primary-color) inset;
            animation: rotate 2s linear infinite;
          }

          @keyframes rotate {
            0% {
              transform: rotate(0);
            }
            100% {
              transform: rotate(360deg);
            }
          }
        `}</style>
      </div>
    );
  }

  // ⬇️ Once loaded, render the chosen template
  return <DefaultTemplate />;
}

export async function getServerSideProps() {
  try {
    const base = process.env.NEXT_PUBLIC_BASE_URL;

    // 1. Ask the server: "Which template should I show?"
    const response = await fetch(`${base}/system/gettempleteID`);
    const data = await response.json();
    const style = data?.data || 1; // Default to 1 if it fails

    // 2. Send that number (style) into the page immediately
    return {
      props: {
        templateStyle: style,
      },
    };
  } catch (err) {
    console.error("Fetch error:", err);
    return { props: { templateStyle: 1 } };
  }
}
