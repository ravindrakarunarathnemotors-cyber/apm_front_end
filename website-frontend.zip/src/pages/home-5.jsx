import React from "react";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import { useEffect, useState, useMemo } from "react";
import Header from "@/layout/headers/header";
import ElectronicCategory from "@/components/categories/electronic-category";
import HomeHeroSlider from "@/components/hero-banner/home-hero-slider";
import FeatureArea from "@/components/features/feature-area";
import ProductArea from "@/components/products/electronics/product-area";
import BannerArea from "@/components/banner/banner-area";
import OfferProducts from "@/components/products/electronics/offer-products";
import ProductGadgetArea from "@/components/products/electronics/product-gadget-area";
import ProductBanner from "@/components/products/electronics/product-banner";
import ProductSmArea from "@/components/products/electronics/product-sm-area";
import NewArrivals from "@/components/products/electronics/new-arrivals";
import BlogArea from "@/components/blog/electronic/blog-area";
import InstagramArea from "@/components/instagram/instagram-area";
import CtaArea from "@/components/cta/cta-area";
import Footer from "@/layout/footers/footer";
import { useGetWebSectionsMutation } from "@/redux/features/webstoreSettingsApi";
import ShopArea from "@/components/shop/shop-area";
import ShopFilterOffCanvas from "@/components/common/shop-filter-offcanvas";
import ShopLoader from "@/components/loader/shop/shop-loader";
import dynamic from "next/dynamic";
import ShopPage from "./shop2";
import HeaderTwo from "@/layout/headers/header-2";

export const SECTIONS = {
  // ElectronicCategory: dynamic(() =>
  //   import("@/components/categories/electronic-category")
  // ),
  HomeHeroSlider: dynamic(() =>
    import("@/components/hero-banner/home-hero-slider2")
  ),
  // ShopArea: dynamic(() => import("@/components/shop/shop-area")),
  // // import ShopArea from "@/components/shop/shop-area";
  // ProductArea: dynamic(() =>
  //   import("@/components/products/electronics/product-area")
  // ),
  // BannerArea: dynamic(() => import("@/components/banner/banner-area")),
  // OfferProducts: dynamic(() =>
  //   import("@/components/products/electronics/offer-products")
  // ),
  // ProductGadgetArea: dynamic(() =>
  //   import("@/components/products/electronics/product-gadget-area")
  // ),
  // ProductBanner: dynamic(() =>
  //   import("@/components/products/electronics/product-banner")
  // ),
  // ProductSmArea: dynamic(() =>
  //   import("@/components/products/electronics/product-sm-area")
  // ),
  // NewArrivals: dynamic(() =>
  //   import("@/components/products/electronics/new-arrivals")
  // ),
  // BlogArea: dynamic(() => import("@/components/blog/electronic/blog-area")),
  // InstagramArea: dynamic(() => import("@/components/instagram/instagram-area")),
  // CtaArea: dynamic(() => import("@/components/cta/cta-area")),
};

const HomeFive = () => {
  const [getWebSections, { data: sectionData, isLoading, isError }] =
    useGetWebSectionsMutation();

  useEffect(() => {
    // Call the mutation when component mounts
    getWebSections(5);
  }, [getWebSections]);
  console.log("sectionData", sectionData);

  const ordered = useMemo(() => {
    return [...(sectionData || [])]
      .filter((s) => typeof s.order === "number" && s.section_key)
      .sort((a, b) => a.order - b.order);
  }, [sectionData]);

  return (
    <Wrapper>
      <SEO pageTitle="Home" />
      <HeaderTwo style_2={true} />
      {/* <Header /> */}
      {ordered.map(({ id,section_key }, idx) => {
        const Comp = SECTIONS[section_key];
        if (!Comp) return null; // unknown keys are skipped safely
        return <Comp sectionId={id} key={`${section_key}-${idx}`} />;
      })}
      <ShopPage />
      <Footer />
    </Wrapper>
  );
};

export default HomeFive;
