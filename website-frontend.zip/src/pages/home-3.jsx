import React, { useEffect, useMemo, useCallback } from "react";
import dynamic from "next/dynamic";
import SEO from "@/components/seo";
import Wrapper from "@/layout/wrapper";
import HeaderTwo from "@/layout/headers/header-2";
import Footer from "@/layout/footers/footer";
import { useGetWebSectionsMutation } from "@/redux/features/webstoreSettingsApi";
import FadeInOnScroll from "@/components/FadeInOnScroll";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";

import BeautyBanner from "@/components/banner/beauty-banner";

/** ---------- Top Progress (light only) ---------- */
const TopProgress = ({ active }) => (
  <>
    <div className={`top-progress ${active ? "active" : ""}`} aria-hidden />
    <style jsx>{`
      .top-progress {
        position: fixed;
        top: 0;
        left: 0;
        height: 3px;
        width: 0%;
        z-index: 9999;
        transform: translateZ(0);
        background: linear-gradient(90deg, #e9d5ff, #a5f3fc, #e0e7ff);
        box-shadow: 0 0 10px rgba(165, 243, 252, 0.5);
      }
      .top-progress.active {
        animation: grow 1.2s ease-in-out infinite;
      }
      @keyframes grow {
        0% {
          width: 0%;
          opacity: 0.95;
        }
        55% {
          width: 65%;
          opacity: 1;
        }
        100% {
          width: 100%;
          opacity: 1;
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .top-progress.active {
          animation: none;
          width: 100%;
        }
      }
    `}</style>
  </>
);

/** ---------- Modern Section Skeleton (light palette only) ---------- */
const SectionSkeleton = ({
  variant = "block",
  lines = 0,
  showHeader = false,
}) => {
  const styleMap = {
    banner: { height: 600, radius: 22 },
    grid: { height: 500, radius: 18 },
    carousel: { height: 400, radius: 18 },
    testimonial: { height: 340, radius: 18 },
    block: { height: 420, radius: 18 },
  };
  const box = styleMap[variant] || styleMap.block;

  return (
    <>
      <div className="section-shell" role="status" aria-busy="true">
        <div
          className="skel-wrap"
          style={{ "--h": `${box.height}px`, "--r": `${box.radius}px` }}
        >
          {showHeader && (
            <div className="skel-header">
              <span className="skel-header-pill" />
            </div>
          )}

          <div className="skel-card">
            {/* base subtle vignette / fade around edges */}
            <div className="skel-vignette" aria-hidden />

            {/* shimmer */}
            <div className="skel-shimmer" aria-hidden />

            {/* main content layout */}
            <div className="skel-body">
              <div className="skel-block skel-block-main" />
              <div className="skel-block-group">
                <span className="skel-block skel-block-sm" />
                <span className="skel-block skel-block-sm" />
                <span className="skel-block skel-block-sm" />
              </div>
            </div>

            {lines > 0 && (
              <div className="skel-lines">
                {Array.from({ length: lines }).map((_, i) => (
                  <span
                    key={i}
                    className="skel-line"
                    style={{ width: `${85 - i * 8}%` }}
                  />
                ))}
              </div>
            )}

            {/* smooth bottom fade-out */}
            <div className="skel-fade-bottom" aria-hidden />
          </div>
        </div>
      </div>

    </>
  );
};

/** ---------- Map each section key to a skeleton shape ---------- */
const SKELETON_BY_KEY = {
  BeautyBanner: "banner",
  BeautyCategory: "grid",
  BeautyFeatured: "grid",
  ProductArea: "grid",
  BeautyOfferBanner: "banner",
  ProductAreaTwo: "grid",
  TrendingSpecialPrd: "carousel",
  BeautyTestimonial: "testimonial",
  FeatureAreaTwo: "grid",
  InstagramAreaThree: "carousel",
};

/** ---------- Dynamic imports with skeleton fallbacks ---------- */
export const SECTIONS = {
  // BeautyBanner: dynamic(() => import("@/components/banner/beauty-banner"), {
  //   loading: () => (
  //     <SectionSkeleton variant={SKELETON_BY_KEY.BeautyBanner} showHeader />
  //   ),
  //   ssr: false,
  // }),
  BeautyCategory: dynamic(
    () => import("@/components/categories/beauty-category"),
    {
      loading: () => (
        <SectionSkeleton variant={SKELETON_BY_KEY.BeautyCategory} lines={3} />
      ),
      ssr: false,
    },
  ),
  BeautyFeatured: dynamic(
    () => import("@/components/features/beauty-featured"),
    {
      loading: () => (
        <SectionSkeleton variant={SKELETON_BY_KEY.BeautyFeatured} lines={3} />
      ),
      ssr: false,
    },
  ),
  ProductArea: dynamic(
    () => import("@/components/products/beauty/product-area"),
    {
      loading: () => (
        <SectionSkeleton variant={SKELETON_BY_KEY.ProductArea} lines={1} />
      ),
      ssr: false,
    },
  ),
  BeautyOfferBanner: dynamic(
    () => import("@/components/offer-banner/beauty-offer-banner"),
    {
      loading: () => (
        <SectionSkeleton
          variant={SKELETON_BY_KEY.BeautyOfferBanner}
          showHeader
        />
      ),
      ssr: false,
    },
  ),
  ProductAreaTwo: dynamic(
    () => import("@/components/products/beauty/product-area-2"),
    {
      loading: () => (
        <SectionSkeleton variant={SKELETON_BY_KEY.ProductAreaTwo} lines={2} />
      ),
      ssr: false,
    },
  ),
  TrendingSpecialPrd: dynamic(
    () => import("@/components/products/beauty/trending-special-prd"),
    {
      loading: () => (
        <SectionSkeleton
          variant={SKELETON_BY_KEY.TrendingSpecialPrd}
          lines={2}
          showHeader
        />
      ),
      ssr: false,
    },
  ),
  BeautyTestimonial: dynamic(
    () => import("@/components/testimonial/beauty-testimonial"),
    {
      loading: () => (
        <SectionSkeleton
          variant={SKELETON_BY_KEY.BeautyTestimonial}
          lines={2}
        />
      ),
      ssr: false,
    },
  ),
  FeatureAreaTwo: dynamic(
    () => import("@/components/features/feature-area-2"),
    {
      loading: () => (
        <SectionSkeleton variant={SKELETON_BY_KEY.FeatureAreaTwo} lines={3} />
      ),
      ssr: false,
    },
  ),
  InstagramAreaThree: dynamic(
    () => import("@/components/instagram/instagram-area-3"),
    {
      loading: () => (
        <SectionSkeleton
          variant={SKELETON_BY_KEY.InstagramAreaThree}
          lines={2}
          showHeader
        />
      ),
      ssr: false,
    },
  ),
};

/** ---------- Empty / Error State Card (light only) ---------- */
const StateCard = ({
  title,
  subtitle,
  actionLabel,
  onAction,
  tone = "neutral",
}) => (
  <>
    <div className={`state-card ${tone} container`}>
      <div className="content">
        <h3 className="mb-1">{title}</h3>
        <p className="mb-3">{subtitle}</p>
        {actionLabel && (
          <button
            className="action-btn btn"
            onClick={onAction}
            aria-label={actionLabel}
          >
            {actionLabel}
          </button>
        )}
      </div>
    </div>
    <style jsx>{`
      .state-card {
        width: min(980px, 100%);
        margin: 32px auto 40px;
        padding: 24px 20px;
        border-radius: 14px;
        border: none;

        background: linear-gradient(180deg, #ffffff, #fbfdff);
        box-shadow: 0 8px 28px rgba(199, 210, 254, 0.45);
      }
      .state-card.danger {
        border-color: rgba(254, 202, 202, 0.9);
        background: linear-gradient(180deg, #fff8f8, #fff1f2);
        box-shadow: 0 8px 28px rgba(254, 202, 202, 0.45);
      }
      .content h3 {
        font-size: clamp(18px, 2.2vw, 22px);
        font-weight: 600;
        color: #6b7280; /* soft gray text for headings only */
      }
      .content p {
        margin: 0 0 12px;
        color: #94a3b8; /* soft muted text */
      }
      .action-btn {
        border-radius: 12px;
        background: linear-gradient(90deg, #e9d5ff, #a5f3fc);
        border: none;
        color: #334155;
        font-weight: 600;
        padding: 10px 16px;
        transition:
          transform 0.15s ease,
          box-shadow 0.15s ease,
          opacity 0.15s ease;
      }
      .action-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 8px 18px rgba(165, 243, 252, 0.6);
        opacity: 0.98;
      }
    `}</style>
  </>
);

/** ---------- Page ---------- */
const HomeThree = () => {
  const [getWebSections, { data: sectionData, isLoading, isError }] = useGetWebSectionsMutation();
  useGetBrandingSettingsQuery();
  const fetch = useCallback(() => getWebSections(3), [getWebSections]);

  useEffect(() => {
    fetch();
  }, [fetch]);

  // handle both array and {data:[...]} shapes
  const raw = useMemo(
    () => (Array.isArray(sectionData) ? sectionData : sectionData?.data || []),
    [sectionData],
  );

  const ordered = useMemo(() => {
    return [...raw]
      .filter((s) => typeof s?.order === "number" && s?.section_key)
      .sort((a, b) => a.order - b.order);
  }, [raw]);

  const showEmpty = !isLoading && !isError && ordered.length === 0;

  return (
    <Wrapper>
      <SEO pageTitle="Home" />
      <TopProgress active={isLoading} />
      <HeaderTwo />

      {/* Error state */}
      {isError && (
        <StateCard
          title="Couldn’t load your page layout"
          subtitle="Please check your connection or try again."
          actionLabel="Retry"
          onAction={fetch}
          tone="danger"
        />
      )}

      {/* Page-level skeletons while we don't even know which sections to show */}
      {isLoading && ordered.length === 0 && (
        <>
          <SectionSkeleton variant="banner" showHeader />
          <SectionSkeleton variant="grid" lines={3} />
          <SectionSkeleton variant="carousel" lines={2} showHeader />
          <SectionSkeleton variant="grid" lines={3} />
          <SectionSkeleton variant="testimonial" lines={2} />
        </>
      )}

      {/* Render actual sections; each one fades in when it scrolls into view */}
      {ordered.map(({ id, section_key }, idx) => {
        // 1. If it's the Banner, use our fast-loaded version
        if (section_key === "BeautyBanner") {
          return (
            <FadeInOnScroll key={`${section_key}-${id}`} delay={0}>
              <BeautyBanner sectionId={id} bgClass="bg-white" />
            </FadeInOnScroll>
          );
        }

        // 2. Otherwise, use the other dynamic sections
        const Comp = SECTIONS[section_key];
        if (!Comp) return null;

        const bgClass = (idx + 1) % 2 === 0 ? "bg-white" : "bg-light";
        return (
          <FadeInOnScroll key={`${section_key}-${id}`} delay={idx * 0.08}>
            <Comp sectionId={id} bgClass={bgClass} />
          </FadeInOnScroll>
        );
      })}
      {/* Empty state */}
      {showEmpty && (
        <StateCard
          title="No sections configured yet"
          subtitle="Use your Page Builder to add sections to Template 3 and set their order."
          actionLabel="Open Builder"
          onAction={() =>
            (window.location.href = "/admin/page-builder?template=3")
          }
          tone="neutral"
        />
      )}
      <Footer style_3 />
    </Wrapper>
  );
};

export default HomeThree;
