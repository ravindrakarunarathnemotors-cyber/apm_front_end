import { useState, useMemo } from "react";
import Image from "next/image";
import { useRouter } from "next/router";
// internal
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";
import ErrorMsg from "@/components/common/error-msg";
import Loader from "@/components/loader/loader";

const slugify = (str) =>
    str.toLowerCase().replace("&", "").split(" ").join("-");

const MobileCategory = ({ isCategoryActive, setIsCanvasOpen }) => {
  const { data: categories, isError, isLoading } = useGetShowCategoryQuery();
  const [activeParentId, setActiveParentId] = useState(null);
  const router = useRouter();

  // Build parents (category_under === null) and map their direct subs (one level only)
  const parentsWithSubs = useMemo(() => {
    if (!Array.isArray(categories)) return [];
    const parents = categories.filter((c) => c.category_under === null);

    return parents.map((parent) => ({
      parent,
      subs: categories.filter((c) => c.category_under === parent.category_id),
    }));
  }, [categories]);

  const toggleSubmenu = (parentId) => {
    setActiveParentId((prev) => (prev === parentId ? null : parentId));
  };

  const goParent = (name) => {
    router.push(`/shop?category=${slugify(name)}`);
    setIsCanvasOpen(false)
  };

  const goSub = (name) => {
    router.push(`/shop?subCategory=${slugify(name)}`);
  };

  // Decide what to render
  let content = null;

  if (isLoading) {
    content = (
      <div className="py-5">
        <Loader loading />
      </div>
    );
  } else if (isError) {
    content = <ErrorMsg msg="There was an error" />;
  } else if (!parentsWithSubs.length) {
    content = <ErrorMsg msg="No Category found!" />;
  } else {
    content = parentsWithSubs.map(({ parent, subs }) => (
      <li className="has-dropdown" key={parent.category_id}>
        <div className="flex align-items-center justify-content-between w-100">
          <a
            className="cursor-pointer d-flex align-items-center justify-content-between "
            
          >
            <div className="d-flex align-items-center gap-2" onClick={() => goParent(parent.name)}>
              {parent.mobile_url && (
                <span className="inline-block">
                  <Image
                    src={parent.mobile_url}
                    alt={`${parent.name} icon`}
                    width={40}
                    height={40}
                    className="rounded border border-gray-100"
                  />
                </span>
              )}
              <span className="">{parent.name}</span>
            </div>
            {subs.length > 0 && (
              <button
                type="button"
                onClick={() => toggleSubmenu(parent.category_id)}
                className="dropdown-toggle-btn border border-gray-100 px-3 py-1 rounded"
                aria-expanded={activeParentId === parent.category_id}
                aria-label={`Toggle ${parent.name} submenu`}
              >
                <i className="fa-regular fa-angle-right"></i>
              </button>
            )}
          </a>
        </div>

        {subs.length > 0 && (
          <ul
            className={`tp-submenu ${
              activeParentId === parent.category_id ? "active" : ""
            } mb-2`}
          >
            {subs.map((sub) => (
              <li key={sub.category_id} onClick={() => goParent(sub.name)}>
                <a className="cursor-pointer ps-4">{sub.name}</a>
              </li>
            ))}
          </ul>
        )}
      </li>
    ));
  }

  return <ul className={isCategoryActive ? "active" : ""}>{content}</ul>;
};

export default MobileCategory;
