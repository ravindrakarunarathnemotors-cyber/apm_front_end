"use client";

import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useCallback,
} from "react";
import Link from "next/link";
import Image from "next/image";
import { useGetShowCategoryQuery } from "@/redux/features/categoryApi";

/* tiny inline icons */
const ChevronDown = (props) => (
  <svg
    width="12"
    height="12"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6z" />
  </svg>
);
const ChevronRight = (props) => (
  <svg
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path d="M10 17l5-5-5-5v10z" />
  </svg>
);

/* helpers */
const slugify = (str) =>
  str.toLowerCase().replace("&", "").split(" ").join("-");

function buildMaps(list = []) {
  const byParent = new Map(); // parentId -> children[]
  list.forEach((c) => {
    if (c.category_under == null) return;
    if (!byParent.has(c.category_under)) byParent.set(c.category_under, []);
    byParent.get(c.category_under).push(c);
  });
  byParent.forEach((arr) => arr.sort((a, b) => a.name.localeCompare(b.name)));
  const mains = list
    .filter((c) => c.category_under == null)
    .sort((a, b) => a.name.localeCompare(b.name));
  return { mains, byParent };
}

const Menus = () => {
  const {
    data: categories = [],
    isLoading,
    isError,
  } = useGetShowCategoryQuery();

  const { mains, byParent } = useMemo(
    () => buildMaps(categories),
    [categories]
  );

  // dropdown + hover state
  const [open, setOpen] = useState(false);
  const [activeMain, setActiveMain] = useState(null); // only set on hover
  const [activeSub, setActiveSub] = useState(null); // only set on hover
  const closeTimer = useRef(null);

  const openNow = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(true);
  };
  const closeSoon = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => {
      setOpen(false);
      setActiveMain(null); // reset so nothing shows by default next time
      setActiveSub(null);
    }, 120);
  };
  const closeNow = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(false);
    setActiveMain(null);
    setActiveSub(null);
  };

  // ESC closes & resets
  const onKeyDown = useCallback((e) => {
    if (e.key === "Escape") closeNow();
  }, []);
  useEffect(() => {
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [onKeyDown]);

  // compute panels only when hovered
  const subs = activeMain ? byParent.get(activeMain) || [] : [];
  const childSubs = activeSub ? byParent.get(activeSub) || [] : [];

  // grid columns: rail always; +1 if subs exist; +1 if child-subs exist
  const colCount = 1 + (subs.length ? 1 : 0) + (childSubs.length ? 1 : 0);

  const getMaincategoryName = (id) => {
    const main = mains.find((c) => c.category_id === id);
    return main ? main.name : "Unknown";
  };

  const getSubCategoryName = (id) => {
    const sub = subs.find((c) => c.category_id === id);
    return sub ? sub.name : "Unknown";
  };

  return (
    <>
      <nav className="main-menu" role="navigation" aria-label="Primary">
        <ul className="menu-root" role="menubar" style={{ fontSize: "16px" }}>
          <li className="menu-item" role="none">
            <Link className="menu-link" href="/" role="menuitem">
              Home
            </Link>
          </li>
          <li className="menu-item" role="none">
            <Link className="menu-link" href="/shop" role="menuitem">
              Shop
            </Link>
          </li>

          {/* Categories dropdown */}
          <li
            className={`menu-item has-mega ${open ? "open" : ""}`}
            role="none"
            onMouseEnter={openNow}
            onMouseLeave={closeSoon}
          >
            <button
              type="button"
              className="menu-link as-button"
              aria-haspopup="true"
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
              title="Browse categories"
            >
              Categories <ChevronDown style={{ marginLeft: 2 }} />
            </button>

            <div
              className="mega-layer"
              role="menu"
              aria-label="Categories"
              onMouseEnter={openNow}
              onMouseLeave={closeSoon}
            >
              <div className={`mega-wrap cols-${colCount}`}>
                {/* LEFT RAIL — mains only (always visible inside dropdown) */}
                <div className="rail">
                  {isLoading && <div className="rail-skeleton" aria-hidden />}
                  {isError && !isLoading && (
                    <div className="rail-error">Failed to load categories</div>
                  )}
                  {!isLoading &&
                    !isError &&
                    mains.map((m) => {
                      const hasChildren = byParent.has(m.category_id);
                      const active = activeMain === m.category_id;
                      return (
                        <button
                          key={m.category_id}
                          className={`rail-item ${active ? "active" : ""}`}
                          style={{ minWidth: "180px", width: "auto", maxHeight: "40px", alignItems: "top" }}
                          onMouseEnter={() => {
                            setActiveMain(hasChildren ? m.category_id : null);
                            setActiveSub(null);
                          }}
                          onFocus={() => {
                            setActiveMain(hasChildren ? m.category_id : null);
                            setActiveSub(null);
                          }}
                          title={m.name}
                        >
                          <div
                            className=" d-flex align-items-center"
                            style={{
                              minWidth: "180px",
                              maxHeight: "30px",
                              width: "auto",
                              gap: "8px",
                            }}
                            onClick={() => {
                              window.location.href = `/shop?category=${slugify(
                                m.name
                              )}-${m.category_id}`;
                            }}
                          >
                            <span className="thumb">
                              {m.desktop_url ? (
                                <Image
                                  src={m.desktop_url}
                                  alt={m.name}
                                  width={22}
                                  height={22}
                                  className="img rounded-3  shdow-sm"
                                />
                              ) : (
                                <span className="placeholder" />
                              )}
                            </span>
                            <span
                              className="rail-text capitalize"
                              style={{ minWidth: "150px", width: "auto" }}
                            >
                              {m.name}
                            {hasChildren && (
                              <ChevronRight
                                className="rail-caret"
                                style={{ width: "25px", height: "25px", padding: "5px" }}
                                onClick={() => {
                                  setActiveMain(
                                    hasChildren ? m.category_id : null
                                  );
                                  setActiveSub(null);
                                }}
                              />
                            )}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                </div>

                {/* MIDDLE PANEL — only render when hovered main HAS subs */}
                {subs.length > 0 && (
                  <div className="panel">
                    <div className="panel-head">
                      <span className="panel-title" style={{ fontSize: "16px" }}>{getMaincategoryName(activeMain)}</span>
                    </div>
                    <ul className="panel-list ms-2" style={{ fontSize: "14px" }}>
                      {subs.map((s) => {
                        const hasChildren = byParent.has(s.category_id);
                        const active = activeSub === s.category_id;
                        return (
                          <li key={s.category_id}>
                            <Link
                              href={`/shop?category=${slugify(s.name)}-${
                                s.category_id
                              }`}
                              className={`panel-link ${active ? "active" : ""}`}
                              onMouseEnter={() =>
                                setActiveSub(hasChildren ? s.category_id : null)
                              }
                              onFocus={() =>
                                setActiveSub(hasChildren ? s.category_id : null)
                              }
                              title={s.name}
                            >
                              <span className="truncate capitalize">
                                {s.name}
                              </span>
                              {hasChildren && (
                                <ChevronRight className="right-caret" />
                              )}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}

                {/* RIGHT PANEL — only render when hovered sub HAS child-subs */}
                {childSubs.length > 0 && (
                  <div className="panel">
                    <div className="panel-head">
                      <span className="panel-title">{getSubCategoryName(activeSub)} </span>
                    </div>
                    <ul className="panel-list ms-1">
                      {childSubs.map((c) => (
                        <li key={c.category_id}>
                          <Link
                            href={`/shop?category=${slugify(c.name)}-${
                              c.category_id
                            }`}
                            className="panel-link"
                            title={c.name}
                          >
                            <span className="truncate">{c.name}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </li>

          <li className="menu-item" role="none">
            <Link className="menu-link" href="/contact" role="menuitem">
              Contact
            </Link>
          </li>
        </ul>
      </nav>

      <style jsx>{`
        .main-menu {
          position: relative;
        }
        .menu-root {
          display: flex;
          gap: 18px;
          list-style: none;
          margin: 0;
          padding: 0;
          align-items: center;
        }
        .menu-item {
          position: relative;
        }
        .menu-link {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 10px 12px;
          border-radius: 10px;
          text-decoration: none;
          color: inherit;
          transition: background 0.18s ease, color 0.18s ease,
            transform 0.18s ease;
        }
        .menu-link:hover {
          background: rgba(var(--bs-primary-rgb, 98, 0, 238), 0.08);
          color: var(--bs-primary, #6200ee);
        }
        .menu-link.as-button {
          background: transparent;
          border: 0;
          cursor: pointer;
        }

        .has-mega {
          position: static;
        }
        .mega-layer {
          position: absolute;
          left: 0;
          right: 0;
          top: calc(100% + 8px);
          opacity: 0;
          visibility: hidden;
          transform: translateY(6px);
          transition: opacity 0.18s ease, transform 0.18s ease,
            visibility 0s linear 0.18s;
          z-index: 50;
          min-width: 500px;
          width: auto;
        }
        .has-mega.open .mega-layer,
        .has-mega:focus-within .mega-layer {
          opacity: 1;
          visibility: visible;
          transform: translateY(0);
          transition-delay: 0s;
        }

        .mega-wrap {
          background: #fff;
          border-radius: 14px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.12);
          padding: 0;
          min-width: 500px;
          display: grid;
          overflow: hidden;
        }
        .mega-wrap.cols-1 {
          grid-template-columns: 200px; 
        }
        .mega-wrap.cols-2 {
          grid-template-columns: 200px 1fr;
        }
        .mega-wrap.cols-3 {
          grid-template-columns: 200px 1fr 1fr;
        }

        .rail {
          background: #f9fafb;
          padding: 10px;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          max-height: 64vh;
        }
        .rail-skeleton {
          height: 200px;
          border-radius: 12px;
          background: linear-gradient(
            100deg,
            rgba(0, 0, 0, 0.06) 20%,
            rgba(0, 0, 0, 0.12) 30%,
            rgba(0, 0, 0, 0.06) 40%
          );
          background-size: 200% 100%;
          animation: shimmer 1.2s ease-in-out infinite;
        }
        @keyframes shimmer {
          0% {
            background-position: 200% 0;
          }
          100% {
            background-position: -200% 0;
          }
        }
        .rail-error {
          color: #b91c1c;
          font-weight: 600;
          padding: 10px;
        }

        .rail-item {
          display: grid;
          grid-template-columns: 26px 1fr 14px;
          align-items: top;
          gap: 10px;
          width: 100%;
          text-align: left;
          border: 0;
          background: transparent;
          border-radius: 10px;
          padding: 8px 10px;
          cursor: pointer;
          color: #111827;
          transition: background 0.15s ease, color 0.15s ease;
        }
        .rail-item:hover,
        .rail-item.active {
          background: #eef2ff;
          color: #3730a3;
          align-items: top;
        }
        .thumb {
          width: 22px;
          height: 22px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }
        .thumb .img {
          border-radius: 4px;
          object-fit: cover;
        }
        .placeholder {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #e5e7eb;
          display: inline-block;
        }
        .rail-text {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .rail-caret {
          opacity: 0.6;
        }

        .panel {
          padding: 14px 14px 16px;
          max-height: 64vh;
          overflow-y: auto;
        }
        .panel + .panel {
          border-left: 1px solid #f3f4f6;
        }
        .panel-head {
          padding: 4px 6px 10px;
        }
        .panel-title {
          font-weight: 700;
          font-size: 13px;
          color: #111827;
        }
        .panel-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: grid;
          gap: 4px;
        }
        .panel-link {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 10px;
          border-radius: 10px;
          color: #374151;
          text-decoration: none;
          transition: background 0.15s ease, color 0.15s ease,
            transform 0.15s ease;
        }
        .panel-link:hover,
        .panel-link.active {
          background: rgba(var(--bs-primary-rgb, 98, 0, 238), 0.06);
          color: var(--bs-primary, #6200ee);
          transform: translateX(2px);
        }
        .right-caret {
          margin-left: 10px;
          opacity: 0.6;
        }
        .truncate {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        @media (max-width: 991.98px) {
          .mega-wrap {
            grid-template-columns: 1fr !important;
            border-radius: 0;
          }
          .rail,
          .panel {
            max-height: none;
          }
        }
      `}</style>
    </>
  );
};

export default Menus;
