import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
// internal
import { CartTwo, Menu, Search, User, Wishlist } from "@/svg";
import Menus from "./header-com/menus";
import logo_white from "@assets/img/logo/logo-white.png";
import logo_dark from "@assets/img/logo/logo.png";
import useSticky from "@/hooks/use-sticky";
import SearchBar from "./header-com/search-bar";
import OffCanvas from "@/components/common/off-canvas";
import useCartInfo from "@/hooks/use-cart-info";
import CartMiniSidebar from "@/components/common/cart-mini-sidebar";
import { openCartMini } from "@/redux/features/cartSlice";
import useSearchFormSubmit from "@/hooks/use-search-form-submit";
import HeaderTopRight from "./header-com/header-top-right";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";

const HeaderFour = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isOffCanvasOpen, setIsCanvasOpen] = useState(false);
  const { wishlist } = useSelector((state) => state.wishlist);
  const { quantity } = useCartInfo();
  const { sticky } = useSticky();
  const dispatch = useDispatch();
  const { setSearchText, setCategory, handleSubmit, searchText } =
    useSearchFormSubmit();
  const { data: brandingData } = useGetBrandingSettingsQuery();
  console.log("BrandingData", brandingData);

  // selectHandle
  const handleCategory = (value) => {
    setCategory(value);
  };

  return (
    <>
      <header>
        <div
          id="header-sticky"
          className={`tp-header-area  tp-header-sticky  has-dark-logo tp-header-height ${sticky ? "header-sticky" : ""
            }`}
          style={{
            background: sticky ? "#ffffff" : "#ffffff",
            transition: "background 0.3s",
          }}
        >
          <div className="tp-header-bottom-3 pl-85 pr-85">
            <div className="container-fluid">
              <div className="row align-items-center">
                <div className="col-xl-2 col-lg-2 col-5">
                  <div className="logo" style={{ width: "130px", height: "40px" }}>
                    <Link href="/">
                      <Image
                        className="logo-light"
                        src={brandingData?.logo_url_white}
                        width={150}
                        height={40}
                        alt="logo"
                        style={{ width: "100%", height: "auto" }}
                      />
                      <Image
                        className="logo-dark"
                        src={brandingData?.logo_url_white}
                        width={150}
                        height={40}
                        alt="logo"
                        style={{ width: "100%", height: "auto" }}
                      />
                    </Link>
                  </div>
                </div>

                <div className="col-xl-5 col-lg-5 d-none d-lg-block">
                  <div className="main-menu menu-style-1  p-relative">
                    <nav className="tp-main-menu-content">
                      <Menus />
                    </nav>
                  </div>
                </div>

                <div className="col-xl-5 col-lg-5 col-7">
                  <div className="tp-header-action d-flex align-items-center justify-content-end ml-50 ">
                    <div
                      className="tp-header-action-item d-none d-sm-block"
                      style={{ width: "100%" }}
                    >
                      <form onSubmit={handleSubmit}>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "flex-start",
                            width: "100%",
                            backgroundColor: "#fff",
                            margin: "10px",
                            borderRadius: "45px",
                            overflow: "hidden",
                            border: "1px solid #919191",
                          }}
                        >
                          <input
                            onChange={(e) => setSearchText(e.target.value)}
                            value={searchText}
                            type="text"
                            placeholder="Search for product..."
                            className="form-control py-0"
                            style={{
                              boxShadow: "none",
                              outline: "none",
                              border: "none",
                            }}
                          />
                          <button type="submit" style={{ width: "50px" }}>
                            <i
                              className="flaticon-search-1"
                              style={{ fontSize: "25px" }}
                            ></i>
                          </button>
                        </div>
                      </form>
                      {/* <button
                        onClick={() => setIsSearchOpen(true)}
                        type="button"
                        className="tp-header-action-btn tp-search-open-btn"
                      >
                        <Search />
                      </button> */}
                    </div>
                    <div className="tp-header-action-item d-none d-sm-block" style={{marginLeft:'30px'}}>
                      <Link
                        href="/profile"
                        className="tp-header-action-btn"
                      >
                        <User />
                      </Link>
                    </div>
                    <div className="tp-header-action-item d-none d-sm-block">
                      <Link href="/wishlist" className="tp-header-action-btn">
                        <Wishlist />
                        <span className="tp-header-action-badge">
                          {wishlist.length}
                        </span>
                      </Link>
                    </div>
                    <div className="tp-header-action-item d-none d-sm-block">
                      <button
                        onClick={() => dispatch(openCartMini())}
                        type="button"
                        className="tp-header-action-btn cartmini-open-btn"
                      >
                        <CartTwo />
                        <span className="tp-header-action-badge">
                          {quantity}
                        </span>
                      </button>
                    </div>
                    <div className="tp-header-action-item d-lg-none">
                      <button
                        onClick={() => setIsCanvasOpen(true)}
                        type="button"
                        className="tp-offcanvas-open-btn"
                      >
                        <Menu />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* search bar start */}
      {/* <SearchBar
        isSearchOpen={isSearchOpen}
        setIsSearchOpen={setIsSearchOpen}
      /> */}
      {/* search bar end */}

      {/* cart mini sidebar start */}
      <CartMiniSidebar />
      {/* cart mini sidebar end */}

      {/* off canvas start */}
      <OffCanvas
        isOffCanvasOpen={isOffCanvasOpen}
        setIsCanvasOpen={setIsCanvasOpen}
        categoryType="jewelry"
      />
      {/* off canvas end */}
    </>
  );
};

export default HeaderFour;
