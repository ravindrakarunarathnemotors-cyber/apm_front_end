import React, { useState, useMemo, useRef, useEffect } from "react";
import Image from "next/image";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
// internal
import Menus from "./header-com/menus";
import logo from "@assets/img/logo/logo.svg";
import useSticky from "@/hooks/use-sticky";
import useCartInfo from "@/hooks/use-cart-info";
import { openCartMini } from "@/redux/features/cartSlice";
import HeaderTopRight from "./header-com/header-top-right";
import CartMiniSidebar from "@/components/common/cart-mini-sidebar";
import {
  CartTwo,
  Compare,
  User,
  Facebook,
  Menu,
  PhoneTwo,
  Wishlist,
  Search,
} from "@/svg";
import useSearchFormSubmit from "@/hooks/use-search-form-submit";
import OffCanvas from "@/components/common/off-canvas";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";
import { constant, debounce } from "lodash";
import { useGetSearchProductsQuery } from "@/redux/features/productApi";
import { slugify } from "@/lib/slugify";
import useCurrencySymbol from "@/hooks/useCurrencySymbol";

import { userLoggedOut } from "@/redux/features/auth/authSlice";
import { useRouter } from "next/router";

const HeaderTwo = ({ style_2 = false }) => {
  const [open, setOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false)

  const blurTimeout = useRef(null);
  const symbol = useCurrencySymbol();
  const { wishlist } = useSelector((state) => state.wishlist);
  const [isOffCanvasOpen, setIsCanvasOpen] = useState(false);
  const { setSearchText, handleSubmit, searchText } = useSearchFormSubmit();
  const { quantity } = useCartInfo();
  const { sticky } = useSticky();

  let token = ''
  if (typeof window !== 'undefined') {
    token = localStorage.getItem('accessToken')
  }

  const dispatch = useDispatch();
  const router = useRouter();
  // handle logout
  const handleLogout = () => {
    dispatch(userLoggedOut());
    router.push("/");
    setProfileOpen(false)
  };

  const { data: brandingData } = useGetBrandingSettingsQuery();

  const [debouncedSearch, setDebouncedSearch] = useState("");

  // debounce input changes
  const debouncedChangeHandler = useMemo(
    () =>
      debounce((val) => {
        setDebouncedSearch(val);
      }, 300),
    []
  );

  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchText(value);
    debouncedChangeHandler(value);
  };

  // call RTK query with debounced value
  const {
    data: products,
    isLoading,
    isError,
  } = useGetSearchProductsQuery(debouncedSearch, {
    skip: !debouncedSearch, // don’t call when empty
  });

  const all_products = products?.data || [];
  const hasResults = all_products && all_products.length > 0;

  const dropdownRef = useRef(null);

  // Close when clicking outside
  useEffect(() => {
    if (!profileOpen) return;
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener("pointerdown", handler);
    return () => document.removeEventListener("pointerdown", handler);
  }, [profileOpen]);

  return (
    <>
      <header>
        <div
          className={`tp-header-area tp-header-style-${style_2 ? "primary" : "darkRed"
            } tp-header-height`}
        >
          {/* <div className="tp-header-top-2 p-relative z-index-11 tp-header-top-border d-none d-md-block">
            <div className="container">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <div className="tp-header-info d-flex align-items-center">
                    <div className="tp-header-info-item">
                      <a href="#">
                        <span>
                          <Facebook />
                        </span>{" "}
                        7500k Followers
                      </a>
                    </div>
                    <div className="tp-header-info-item">
                      <a href={`tel:${brandingData?.customer_support_phone}`}>
                        <span>
                          <PhoneTwo />
                        </span>{" "}
                        {brandingData?.customer_support_phone}
                      </a>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="tp-header-top-right tp-header-top-black d-flex align-items-center justify-content-end">
                    <HeaderTopRight />
                  </div>
                </div>
              </div>
            </div>
          </div> */}

          <div
            id="header-sticky"
            className={`tp-header-bottom-2 tp-header-sticky py-3 ${sticky ? "header-sticky" : ""
              }`}
          >
            <div className="container">
              <div className="tp-mega-menu-wrapper p-relative">
                <div className="row align-items-center ">
                  <div className="col-xl-2 col-lg-5 col-md-5 col-sm-4 col-6">
                    <div
                      className="logo "
                      style={{ width: "100%", maxWidth: "100%", height: "auto", minHeight: "45px" , maxHeight: "55px"  }}
                    >
                      
                      <Link href="/">
                        <Image
                          src={brandingData?.logo_url_white}
                          width={250}
                          height={45}
                          alt="logo"
                          priority
                          style={{ maxWidth: "100%",width: "auto", height: "auto", minHeight: "45px", maxHeight: "55px" }}
                        />
                      </Link>
                    </div>
                  </div>
                  <div className="col-xl-5 d-none d-xl-block ps-4">
                    <div className="main-menu menu-style-2 ps-3">
                      <nav className="tp-main-menu-content">
                        <Menus />
                      </nav>
                    </div>
                  </div>
                  <div className="col-xl-5 col-lg-7 col-md-7 col-sm-8 col-6">
                    <div className="tp-header-bottom-right d-flex align-items-center justify-content-end pl-30">
                      <div className="tp-header-search-2 d-none d-sm-block position-relative">
                        <form
                          onSubmit={handleSubmit}
                          className="d-flex dropdown"
                          onKeyDown={(e) =>
                            e.key === "Escape" && setOpen(false)
                          }
                        >
                          <input
                            onChange={(e) => {
                              handleInputChange(e);
                              setOpen(true);
                            }}
                            onFocus={() => setOpen(true)}
                            onBlur={() => {
                              blurTimeout.current = setTimeout(
                                () => setOpen(false),
                                120
                              );
                            }}
                            value={searchText}
                            type="text"
                            placeholder="Search for Products..."
                            className="form-control tp-header-search-input rounded-5"
                            autoComplete="off"
                          />
                          <button type="submit">
                            <Search />
                          </button>

                          {/* Dropdown results */}
                          <div
                            className={`dropdown-menu w-100 mt-50 shadow-sm p-0 rounded overflow-hidden ${open && hasResults ? "show" : ""
                              }`}
                            onMouseDown={(e) => e.preventDefault()} // keep input from blurring before click
                            onClick={() => {
                              clearTimeout(blurTimeout.current);
                              setOpen(false);
                            }}
                          >
                            {/* Scrollable container */}
                            <div
                              style={{ maxHeight: "50vh", overflowY: "auto" }}
                            >
                              {all_products.map((item) => (
                                <Link
                                  key={item._id}
                                  href={`/product/${slugify(item.title)}-${item._id
                                    }`}
                                  className="dropdown-item d-flex gap-2 align-items-center py-2 "
                                  title={item.title}
                                >
                                  <div className="d-flex align-items-start overflow-hidden gap-2 border-bottom w-100 pb-2">
                                    <Image
                                      src={
                                        item.img ||
                                        "/assets/img/shop/product-default.jpg"
                                      }
                                      alt={item.title || "product_img"}
                                      width={50}
                                      height={50}
                                      className="img-fluid rounded m-1"
                                      priority
                                    />
                                    <div className="w-100">
                                      <div className="flex-grow-1 text-truncate text-capitalize text-wrap font-semibold">
                                        {item.title}
                                      </div>
                                      <div className="flex-grow-1 text-truncate">
                                        {symbol}
                                        {item.price
                                          ? parseFloat(item.price).toFixed(2)
                                          : "0.00"}
                                      </div>
                                    </div>
                                  </div>
                                </Link>
                              ))}
                            </div>
                          </div>
                        </form>
                      </div>
                      <div className="tp-header-action d-flex align-items-center ml-30">
                        <div className="tp-header-action-item d-none d-lg-block">
                          <Link
                            href="/compare"
                            className="tp-header-action-btn"
                          >
                            <Compare />
                          </Link>
                        </div>



                        <div
                          ref={dropdownRef}
                          style={{
                            float: "right",
                            position: "relative",
                            display: "inline-block",
                            marginLeft: "20px",
                          }}
                        >
                          {/* Trigger button */}
                          <button
                            style={{
                              background: "none",
                              border: "none",
                              cursor: "pointer",
                            }}
                            onClick={() => setProfileOpen((prev) => !prev)}
                          >
                            <User />
                          </button>

                          {/* Dropdown */}
                          {profileOpen && (
                            <div
                              style={{
                                position: "absolute",
                                top: "155%",
                                right: 0,
                                left: "auto",
                                backgroundColor: "#fff",
                                minWidth: "160px",
                                border: "1px solid #ddd",
                                borderRadius: "6px",
                                boxShadow: "0px 8px 16px rgba(0,0,0,0.15)",
                                zIndex: 1000,
                              }}
                            >
                              <Link
                                href="/profile"
                                onClick={() => setProfileOpen(false)}
                                style={{
                                  display: "block",
                                  padding: "10px 15px",
                                  textDecoration: "none",
                                  color: "#333",
                                  fontSize: "14px",
                                }}
                              >
                                Profile
                              </Link>

                              {token && (
                                <button
                                  onClick={handleLogout}
                                  style={{
                                    display: "block",
                                    width: "100%",
                                    padding: "10px 15px",
                                    textAlign: "left",
                                    border: "none",
                                    background: "transparent",
                                    fontSize: "14px",
                                    color: "#333",
                                    cursor: "pointer",
                                  }}
                                >
                                  Logout
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        <div className="tp-header-action-item d-none d-lg-block">
                          <Link
                            href="/wishlist"
                            className="tp-header-action-btn"
                          >
                            <Wishlist />
                            <span className="tp-header-action-badge">
                              {wishlist.length}
                            </span>
                          </Link>
                        </div>
                        <div className="tp-header-action-item">
                          <button
                            onClick={() => dispatch(openCartMini())}
                            className="tp-header-action-btn cartmini-open-btn"
                          >
                            <CartTwo />
                            <span className="tp-header-action-badge">
                              {quantity}
                            </span>
                          </button>
                        </div>

                        <div className="tp-header-action-item tp-header-hamburger mr-20 d-xl-none">
                          <button
                            onClick={() => setIsCanvasOpen(true)}
                            type="button"
                            className="tp-offcanvas-open-btn"
                          >
                            <Menu />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* cart mini sidebar start */}
      <CartMiniSidebar />
      {/* cart mini sidebar end */}

      {/* off canvas start */}
      <OffCanvas
        isOffCanvasOpen={isOffCanvasOpen}
        setIsCanvasOpen={setIsCanvasOpen}
        categoryType="fashion"
        brandingData={brandingData}
      />
      {/* off canvas end */}
    </>
  );
};

export default HeaderTwo;
