"use client";

import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer } from "react-toastify";
import BackToTopCom from "@/components/common/back-to-top";
import WhatsappShareCom from "@/components/common/whatsapp-share";
import {
  useGetBrandingSettingsQuery,
  useGetActivePluginsQuery,
} from "@/redux/features/brandingSettingsApi";
import ProductModal from "@/components/common/product-modal";
import {
  get_cart_products,
  initialOrderQuantity,
} from "@/redux/features/cartSlice";
import { get_wishlist_products } from "@/redux/features/wishlist-slice";
import { get_compare_products } from "@/redux/features/compareSlice";
import useAuthCheck from "@/hooks/use-auth-check";
import Loader from "@/components/loader/loader";
import TawkTo from "@/components/common/TawkTo";

const Wrapper = ({ children }) => {
  const { productItem } = useSelector((state) => state.productModal);
  const dispatch = useDispatch();
  const authChecked = useAuthCheck();

  const { data: brandingData } = useGetBrandingSettingsQuery();
  const { data: pluginRows = [] } = useGetActivePluginsQuery();

  const activePlugins = pluginRows.reduce((acc, p) => {
    const key = p.plugin_name.toLowerCase().replace(".", "");
    acc[key] = p;
    return acc;
  }, {});

  console.log("activepluggins", activePlugins);

  const tawkPlugin = activePlugins.tawkto;
  const isTawkEnabled = Boolean(tawkPlugin?.information);

  const whatsappPlugin = activePlugins.whatsapp;

  const whatsappNumber = whatsappPlugin?.information || brandingData?.hotline;

  useEffect(() => {
    dispatch(get_cart_products());
    dispatch(get_wishlist_products());
    dispatch(get_compare_products());
    dispatch(initialOrderQuantity());
  }, [dispatch]);

  if (!authChecked) {
    return (
      <div
        className="d-flex align-items-center justify-content-center"
        style={{ height: "100vh" }}
      >
        <Loader spinner="fade" loading />
      </div>
    );
  }

  return (
    <div id="wrapper">
      {children}
      <div
        className="d-flex flex-column justify-content-between"
        style={{
          position: "fixed",
          bottom: isTawkEnabled ? "90px" : "30px",
          right: "30px",
          zIndex: "9999",
          gap: "10px",
        }}
      >
        <BackToTopCom />

        <div className="d-flex flex-row gap-1 ">
          {/* 🔌 WhatsApp Plugin */}
          {whatsappPlugin && whatsappNumber && (
            <WhatsappShareCom whatsappNumber={whatsappNumber} />
          )}
        </div>
      </div>
      <TawkTo enabled={isTawkEnabled} embedUrl={tawkPlugin?.information} />

      <ToastContainer />

      {productItem && <ProductModal />}
    </div>
  );
};

export default Wrapper;
