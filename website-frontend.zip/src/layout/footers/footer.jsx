import React from "react";
import Image from "next/image";
import Link from "next/link";
// internal
import logo from "@assets/img/logo/logo.svg";
import pay from "@assets/img/footer/footer-pay.png";
import social_data from "@/data/social-data";
import { Email, Location, Phone } from "@/svg";
import { useGetBrandingSettingsQuery } from "@/redux/features/brandingSettingsApi";
import { Icon } from "@iconify/react";
import { max } from "lodash";

const Footer = ({
  style_2 = false,
  style_3 = false,
  primary_style = false,
}) => {
  const { data: brandingData } = useGetBrandingSettingsQuery();
  // console.log("BrandingData", brandingData);
  return (
    <footer>
      <div
        className={`tp-footer-area ${
          primary_style
            ? "tp-footer-style-2 tp-footer-style-primary tp-footer-style-6"
            : ""
        } ${
          style_2
            ? "tp-footer-style-2"
            : style_3
            ? "tp-footer-style-2 tp-footer-style-3"
            : ""
        }`}
        data-bg-color={`${style_2 ? "footer-bg-white" : "footer-bg-grey"}`}
      >
        <div className="tp-footer-top pt-60 pb-40">
          <div className="container">
            <div className="row">
              <div className="col-xl-4 col-lg-3 col-md-4 col-sm-6">
                <div className="tp-footer-widget footer-col-1 mb-50">
                  <div className="tp-footer-widget-content">
                    <div
                      className="tp-footer-logo"
                      style={{ width: "auto", minHeight: "60px", maxHeight: "80px" }}
                    >
                      <Link href="/">
                        <Image
                          src={brandingData?.logo_url_white}
                          width={200}
                          height={200}
                          alt="logo"
                          style={{ width: "auto", maxWidth: "100%", height: "auto", minHeight: "60px", maxHeight: "80px" }}
                        />
                      </Link>
                    </div>
                    <p className="tp-footer-desc text-muted">
                      {brandingData?.footer_text ||
                        "We are a dynamic team of full stack developers and designers crafting high-quality web applications"}
                    </p>
                    {/* <div className="tp-footer-social">
                      {social_data.map((s) => (
                        <a href={s.link} key={s.id} target="_blank">
                          <i className={s.icon}></i>
                        </a>
                      ))}
                    </div> */}
                    <div className="tp-footer-social-4 tp-footer-social">
                      <h3 className="tp-footer-social-title-2" style={{fontSize:'24px'}}>Follow Us On</h3>

                      {[
                        {
                          href: brandingData?.facebook_url,
                          icon: "fa-brands fa-facebook-f",
                          label: "Facebook",
                        },
                        {
                          href: brandingData?.twitter_url,
                          icon: "fa-brands fa-twitter",
                          label: "Twitter",
                        },
                        {
                          href: brandingData?.linkedin_url,
                          icon: "fa-brands fa-linkedin-in",
                          label: "LinkedIn",
                        },
                        {
                          href: brandingData?.instagram_url,
                          icon: "fa-brands fa-instagram",
                          label: "Instagram",
                        },
                        {
                          href: brandingData?.youtube_url,
                          icon: "fa-brands fa-youtube",
                          label: "YouTube",
                        },
                        {
                          href: brandingData?.tiktok_url,
                          icon: "fa-brands fa-tiktok",
                          label: "TikTok",
                        },
                      ]
                        .filter((s) => !!s.href)
                        .map((s, idx) => {
                          const url = /^https?:\/\//i.test(s.href)
                            ? s.href
                            : `https://${s.href}`;
                          return (
                            <a
                              key={idx}
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              aria-label={s.label}
                              title={s.label}
                              className="rounded-3 border-0 shadow-sm"
                            >
                              <i className={s.icon} />
                            </a>
                          );
                        })}
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                {/* <div className="tp-footer-widget footer-col-4-2 mb-50">
                  <h4 className="tp-footer-widget-title">My Account</h4>
                  <div className="tp-footer-widget-content">
                    <ul>
                      <li>
                        <a href="#">Track Orders</a>
                      </li>
                      <li>
                        <a href="#">Shipping</a>
                      </li>
                      <li>
                        <a href="#">Wishlist</a>
                      </li>
                      <li>
                        <a href="#">My Account</a>
                      </li>
                      <li>
                        <a href="#">Order History</a>
                      </li>
                      <li>
                        <a href="#">Returns</a>
                      </li>
                    </ul>
                  </div>
                </div> */}
                <div className="tp-footer-widget footer-col-4-2 mb-50">
                  <h3 className="tp-footer-social-title-2" style={{fontSize:'24px'}}>Quick Links</h3>
                  <div className="tp-footer-widget-content">
                    <ul className="tp-footer-quick-link lh-base">
                      <li>
                        <Link href="/">Home</Link>
                      </li>
                      <li>
                        <Link href="/shop">Shop</Link>
                      </li>
                      <li>
                        <Link href="/cart">Cart</Link>
                      </li>
                      <li>
                        <Link href="/wishlist">Wishlist</Link>
                      </li>
                      <li>
                        <Link href="/profile">My Account</Link>
                      </li>
                      {/* <li>
                          <a href="#">Order History</a>
                        </li> */}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="col-xl-3 col-lg-3 col-md-4 col-sm-6">
                <div className="tp-footer-widget footer-col-3 mb-50">
                  <h3 className="tp-footer-social-title-2" style={{fontSize:'24px'}}>Infomation</h3>
                  <div className="tp-footer-widget-content">
                    <ul className="tp-footer-quick-link lh-basem">
                      {/* <li>
                          <a href="#">Our Story</a>
                        </li>
                        <li>
                          <a href="#">Careers</a>
                        </li> */}
                      <li>
                        <Link href="/privacy_policy">Privacy Policy</Link>
                      </li>
                      <li>
                        <Link href="/terms_and_conditions">
                          Terms & Conditions
                        </Link>
                      </li>
                      {/* <li>
                          <a href="#">Latest News</a>
                        </li> */}
                      <li>
                        <Link href="/contact">Contact Us</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                <div className="tp-footer-widget footer-col-4 mb-50">
                  <h3 className="tp-footer-social-title-2" style={{fontSize:'24px'}}>Talk To Us</h3>
                  <div className="tp-footer-widget-content">
                    <div className="tp-footer-talk mb-20">
                      <span>Got Questions? Call us</span>
                      <div className="d-flex align-items-center">
                        <div className="tp-footer-contact-icon">
                          <span>
                            <Phone />
                          </span>
                        </div>
                        <h4 style={{fontSize:'18px', wordBreak:'break-word'}}>
                          <a
                            href={`tel:${brandingData?.customer_support_phone}`}
                          >
                            {brandingData?.customer_support_phone}
                          </a>
                        </h4>
                      </div>
                    </div>
                    <div className="tp-footer-contact">
                      <div className="tp-footer-contact-item d-flex align-items-start">
                        <div className="tp-footer-contact-icon">
                          <span>
                            <Email />
                          </span>
                        </div>
                        <div className="tp-footer-contact-content">
                          <p style={{fontSize:'15px', wordBreak:'break-word'}}>
                            <a href={`mailto:${brandingData?.support_email}`}>
                              {brandingData?.support_email}
                            </a>
                          </p>
                        </div>
                      </div>
                      <div className="tp-footer-contact-item d-flex align-items-start">
                        <div className="tp-footer-contact-icon">
                          <span>
                            <Location />
                          </span>
                        </div>
                        <div className="tp-footer-contact-content">
                          <p>
                            {brandingData?.address_1} <br />{" "}
                            {brandingData?.address_2}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="tp-footer-bottom">
          <div
            className="tp-footer-bottom-wrapper"
            style={{ padding: "20px 0" }}
          >
            <div className="container">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <div className="tp-footer-copyright">
                    <p style={{fontSize:"14px"}}>
                      {brandingData?.white_label ? (
                        <span  style={{fontSize:"14px"}}>
                          <Link
                            href={
                              brandingData?.copyright_link
                                ? copyright_link
                                : "#"
                            }
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            {" "}
                            {brandingData?.copyright_text}
                          </Link>
                        </span>
                      ) : (
                        <Link
                          href="#"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="d-inline-flex align-items-center gap-1 text-decoration-none"
                          style={{fontSize:"14px"}}
                        >
                          <span style={{fontSize:"14px"}}>Made in</span>

                          <Icon
                            icon="twemoji:flag-sri-lanka"
                            width="18"
                            height="18"
                          />
                          <span style={{fontSize:"14px"}}>with</span>
                          <span aria-hidden="true" style={{fontSize:"14px"}}>
                            ❤️ | Powered by Spark Global Solutions
                          </span>
                        </Link>
                      )}{" "}
                      | © {new Date().getFullYear()} All Rights Reserved
                    </p>
                  </div>
                </div>
                <div className="col-md-6 pe-0">
                  <div className="tp-footer-payment text-md-end ">
                    <p>{/* <Image src={pay} alt="pay" /> */}</p>
                    <Link className="me-3" href="/privacy_policy">
                      Privacy Policy
                    </Link>

                    <Link href="/terms_and_conditions">Terms & Conditions</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
