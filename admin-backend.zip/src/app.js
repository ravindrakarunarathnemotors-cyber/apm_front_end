const express = require("express");
require('dotenv').config();

const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require('cookie-parser')


const authRoutes = require("./routes/authRoutes");
const clientStaffRoutes = require("./routes/clientStaffRoutes");
const parcelTimeLine = require("./routes/parcelTimeLine");
const brandingSettings = require("./routes/brandingSettings");
const systemSettings = require("./routes/systemSettings");
const useRoute = require('./routes/userRoute')
const productRoute = require('./routes/productRoutes/productRoute')
const productSubRoute = require('./routes/productRoutes/productSubRoutes')
const brandRoute = require('./routes/productRoutes/brandRoute')
const productUploadRoute = require('./routes/productRoutes/productUploadRoute')
const updateProductRoute = require('./routes/productRoutes/updateProductRoute')
const inventoryRoutes = require('./routes/inventoryRoutes/inventoryRoutes')
const inventorySubRoutes = require('./routes/inventoryRoutes/inventorySubRoutes')
const inventoryMovementRoutes = require('./routes/inventoryRoutes/inventoryMovementRoutes')
const reorderLevelRoute = require('./routes/inventoryRoutes/reorderLevelRoute')
const orderManage = require('./routes/orderRoutes/orderManage')
const dashboard = require('./routes/dashboardManagement')
const templateRoutes = require('./routes/webRoutes/templateRoutes')
const ordersSubRoutes = require('./routes/orderRoutes/ordersSubRoutes')
const deliverypart = require('./routes/orderRoutes/deliverypart')
const adminLog = require("./routes/adminLog");
const clientLog = require("./routes/clientLog");
const updateOrder = require('./routes/orderRoutes/updateOrder')
const orderRoute = require("./routes/orderRoute");
const commonRoute = require("./routes/commonRoute");
const deliveryManagement = require('./routes/deliveryRoutes/deliveryRoutes')
const deliveryManagementSub = require('./routes/deliveryRoutes/deliverySubRoutes')
const webpage = require('./routes/webRoutes/web_page')
const client = require('./routes/clientRoutes/clientRoutes')
const systemSearch = require('./routes/systemRoutes/systemSearch')
const productView = require('./routes/productRoutes/viewProduct')
const siteSectionConfigsRoutes = require('./routes/webRoutes/siteSectionConfigs');
const DashboardRoutes = require('./routes/dashboardRoutes/dashboardRoutes');
const webMediaUploader = require('./routes/webRoutes/webMediaUploader');
const clientSubRoutes = require('./routes/clientRoutes/clientSubRoutes');
const authChecker = require('./middleware/authChecker');
const systemLogs = require('./routes/systemRoutes/systemLogs');
const reportRoutes = require('./routes/reportsRoutes/reportsRoutes');
const productDiscountRoute = require('./routes/discountModule/productDiscountsRoute');
const productInvoiceRoute = require('./routes/invoice/productInvoiceRoute');
const discountRoute = require("./routes/discountRoute");
const invoiceDiscountRoute = require('./routes/invoiceDiscountRouter')
const quotationRote = require("./routes/quotationRoutes/QuotationsRoute");

const batchManagementRoutes = require('./routes/inventoryRoutes/batchManagementRoutes')
const posSubRoutes = require('./routes/posRoutes/posSubRoutes')
const posRoute = require("./routes/posRoutes/index");
const salesRoutes = require('./routes/salesManagerRoutes/voucherRoutes')
const PurchaseOrderRoutes = require('./routes/PurchaseManagerRoutes/purchaseOrderRoutes')
const GRNRoutes = require('./routes/PurchaseManagerRoutes/grnRoutes')
const restaurantRoute = require('./routes/restaurantRoute')
const SupplierRoutes = require('./routes/PurchaseManagerRoutes/supplierRoutes')
const PRNRoutes = require('./routes/PurchaseManagerRoutes/prnRoutes')
const SupplierPayments = require('./routes/PurchaseManagerRoutes/supplierPayments')
const restaurantrawmaterial = require('./routes/restaurantManageRoute/restaurantManageRoute')

// ems routes
const emspRoutes = require('./routes/emsRoutes/emspRoutes');
const emsRoutes = require('./routes/emsRoutes/emsRoutes'); 
const emsUpload = require('./routes/emsRoutes/emsUpload'); 

const AccountsRoutes = require('./routes/accountsRoutes/accountsRoutes')
const AccountsTransactionRoutes = require('./routes/accountsRoutes/transactionsRoutes')
const AccountsSubRoutes =  require ('./routes/accountsRoutes/accountsSubRoutes')

const BillingRoute =  require ('./routes/billingRoute')


const SettingsGloblFetch =  require ('./routes/SystemSettingsGlobal/fetchSettings')
const DeliveryPatnerRoutes = require ('./routes/deliveryPatnerRoutes/deliverypatner')
const serviceRoutes = require('./routes/serviceRoutes/serviceRoutes');
const apidocumentsRoutes = require('./routes/apidocumentsRoutes/apidocumentsRoutes');


// Initialize app
const app = express();

// Middleware
app.use(cors({
  origin: [
    'http://localhost:3001',
    process.env.FRONTEND_URL
  ],
  credentials: true
}));

app.use(helmet());
app.use(morgan("dev"));
app.use(cookieParser())


// *** Upload route BEFORE express.json middleware ***
const uploadRoute = require("./routes/uploadRoute");
app.use("/branding", uploadRoute);

//parse JSON bodies for all other routes
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ limit: '20mb', extended: true }));

// Routes
app.use("/auth", authRoutes);
app.use("/api/user", useRoute);
app.use("/api", clientStaffRoutes);
app.use("/parcel", parcelTimeLine);
app.use("/branding", brandingSettings);
app.use("/system", systemSettings);

app.use("/adminlog", adminLog)
app.use("/clientlog", clientLog)
app.use("/dashboard", dashboard);

//product routes
app.use("/product", productRoute);
app.use("/product-sub", productSubRoute);
app.use("/product-media", productUploadRoute);
app.use("/update-product", updateProductRoute);
app.use("/brand", brandRoute);
app.use("/product-view", productView);
// inventory routes
app.use("/inventory", inventoryRoutes);
app.use("/inventory-sub", inventorySubRoutes);
app.use("/inventory-movement", inventoryMovementRoutes);
app.use("/inventory-reorder", reorderLevelRoute);


app.use("/deliverypart", deliverypart);


app.use("/order", orderRoute);

//order routes 
app.use("/common", commonRoute)
app.use("/ordersmange", orderManage);
app.use("/orders-sub", ordersSubRoutes)
app.use("/update-order", updateOrder)



// delivery management routes
app.use("/delivery-management", deliveryManagement)
app.use("/delivery-management-sub", deliveryManagementSub)


//client routes

app.use("/client-sub-routes", clientSubRoutes)

// system routes
app.use("/system-route", systemSearch)


app.use("/web", templateRoutes);
app.use("/webpage", webpage);
app.use("/client", client);
app.use("/web-media", webMediaUploader);


app.use('/site-section-configs', siteSectionConfigsRoutes);


// dashboard section routes
app.use("/dashboard-view", DashboardRoutes);

//logs
app.use("/system-info", systemLogs)


// auth guard
app.use("/auth-checker", authChecker)

//report management routes
app.use("/reports-management", reportRoutes)
app.use("/discount-module", productDiscountRoute)
app.use("/invoice", productInvoiceRoute)
app.use("/quotation", quotationRote)

//discount routes
app.use("/discount", discountRoute)
app.use('/invoice-discount', invoiceDiscountRoute)



app.use("/batch-routes", batchManagementRoutes)

app.use("/pos", posRoute)
app.use("/pos-sub", posSubRoutes)

// sales manager routes

app.use("/salesroutes", salesRoutes)

//purchase manager routes

app.use("/po-routes", PurchaseOrderRoutes)
app.use("/grn-routes", GRNRoutes)
app.use("/supplier-routes", SupplierRoutes)
app.use("/prn-routes", PRNRoutes)
app.use("/supplier-payments", SupplierPayments)
app.use("/ems", emsRoutes);


app.use("/emsp", emspRoutes);
app.use("/emsUpload", emsUpload);




app.use("/restaurant", restaurantRoute)
app.use("/rawmaterial",restaurantrawmaterial)


// accounts management routes

app.use("/acc-routes", AccountsRoutes)
app.use("/acc-transaction-routes", AccountsTransactionRoutes)
app.use("/acc-sub-routes", AccountsSubRoutes)

//Billing Route
app.use("/billing-routes", BillingRoute)


// system settings fetch - global

app.use("/system-settings-fetch", SettingsGloblFetch)

// system settings fetch - global

app.use("/system-settings-fetch", SettingsGloblFetch)
app.use("/two_way", DeliveryPatnerRoutes)
app.use("/service", serviceRoutes);
app.use("/apidocuments", apidocumentsRoutes);







module.exports = app;



