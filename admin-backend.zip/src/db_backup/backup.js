const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const { getDbUploadEmail, getSmsSettings, sendEmailWithPostmark } = require("../models/smsAndemail");
const pool = require("../config/db");
const { spawn } = require('child_process');
const fs = require('fs');
const zlib = require('zlib');
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const axios = require('axios');


const getCompanyName = async () => {
  try {
    const result = await pool.query(`
            SELECT 
                company_name
            FROM branding_settings
            LIMIT 1
        `);

    if (result.rows.length === 0) {
      console.log("⚠️ No company name found in branding_settings table.");
      return { company_name: 'default' };
    }

    return result.rows[0];
  } catch (error) {
    console.error("❌ Error fetching company name:", error);
    throw error;
  }
};

const getservisedetails = async () => {
  try {
    const result = await pool.query(`
            SELECT 
                billing_client_id,
                billing_servise_id
            FROM system_settings
            LIMIT 1
        `);

    if (result.rows.length === 0) {
      console.log("⚠️ No service details found in system_settings table.");
      return { billing_client_id: null, billing_servise_id: null };
    }

    return result.rows[0];
  } catch (error) {
    console.error("❌ Error fetching service details:", error);
    throw error;
  }
};

// === Setup Backup Directory ===
const backupDir = path.join(__dirname, 'backups');

// Create backups folder if it doesn't exist
if (!fs.existsSync(backupDir)) {
  console.log(`📁 Creating backups directory: ${backupDir}`);
  fs.mkdirSync(backupDir, { recursive: true });
  console.log("✅ Backups directory created successfully");
} else {
  console.log(`📁 Backups directory exists: ${backupDir}`);
}

// === Config ===
const dbName = process.env.DB_NAME;
const dbUser = process.env.DB_USER;
const dbPassword = process.env.DB_PASSWORD;
const dbHost = process.env.DB_HOST || 'localhost';
const dbPort = process.env.DB_PORT || '5432';

// === Initialize S3 Client ===
const s3 = new S3Client({
  region: process.env.DB_BACKUP_S3_REGION,
  endpoint: `https://${process.env.DB_BACKUP_S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.DB_BACKUP_S3_ACCESS_KEY,
    secretAccessKey: process.env.DB_BACKUP_S3_SECRET_KEY,
  },
  forcePathStyle: true,
});

// === Timestamps ===
const now = new Date();
const startTime = new Date();
console.log("🕒 Backup started at:", startTime.toLocaleString('en-GB', { timeZone: 'Asia/Colombo' }));

const timestampDisplay = now.toLocaleString('en-GB', {
  timeZone: 'Asia/Colombo',
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
}).replace(',', '');

const timestampForFilename = timestampDisplay.replace(/:/g, '-').replace(/ /g, '_');
const fileName = `backup-${timestampForFilename}.sql.gz`;
const filePath = path.join(backupDir, fileName);

console.log(`📄 Backup file will be created at: ${filePath}`);

// === Function to upload file to S3 ===
async function uploadToS3(filePath, companyName) {
  try {
    console.log(`📤 Preparing to upload ${filePath} to S3...`);
    const fileContent = fs.readFileSync(filePath);

    const sanitizedCompanyName = companyName.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
    const folderName = `client_backup/${sanitizedCompanyName}`;
    const key = `${folderName}/${fileName}`;

    const params = {
      Bucket: process.env.DB_BACKUP_S3_BUCKET_NAME,
      Key: key,
      Body: fileContent,
      ContentType: "application/gzip",
      ACL: "public-read",
    };

    console.log(`🚀 Uploading to S3: ${key}`);
    const command = new PutObjectCommand(params);
    const result = await s3.send(command);

    console.log(`✅ S3 upload successful! ETag: ${result.ETag}`);

    const customBase = process.env.DB_BACKUP_CONVERT_S3_URL;
    const finalUrl = `${customBase}/${key}`;
    console.log(`🔗 File URL: ${finalUrl}`);

    return finalUrl;
  } catch (error) {
    console.error("❌ S3 upload failed:", error);
    throw error;
  }
}

// === Function to delete old backups ===
function deleteOldBackups(currentFileName) {
  console.log(`🗑️ Cleaning old backups in: ${backupDir}`);
  const files = fs.readdirSync(backupDir);
  let deletedCount = 0;

  files.forEach(file => {
    const fullPath = path.join(backupDir, file);
    if (file !== currentFileName) {
      try {
        fs.unlinkSync(fullPath);
        console.log(`🗑️ Deleted old backup: ${file}`);
        deletedCount++;
      } catch (err) {
        console.error(`❌ Failed to delete ${file}: ${err.message}`);
      }
    }
  });

  if (deletedCount === 0) {
    console.log("📁 No old backups to delete");
  } else {
    console.log(`✅ Deleted ${deletedCount} old backup(s)`);
  }
}

// === Find pg_dump path ===
function findPgDump() {
  const possiblePaths = [
    '/usr/bin/pg_dump',
    '/usr/local/bin/pg_dump',
    '/usr/lib/postgresql/14/bin/pg_dump',
    '/usr/lib/postgresql/13/bin/pg_dump',
    '/usr/lib/postgresql/12/bin/pg_dump',
    '/opt/bitnami/postgresql/bin/pg_dump'
  ];

  for (const testPath of possiblePaths) {
    if (fs.existsSync(testPath)) {
      console.log(`✅ Found pg_dump at: ${testPath}`);
      return testPath;
    }
  }

  console.error("❌ Could not find pg_dump. Please install postgresql-client");
  console.error("Run: sudo apt-get install postgresql-client-14");
  return null;
}

// === Function to send data to billing endpoint ===
async function sendToBillingEndpoint(data) {
const baseUrl = process.env.BILLING_BACK_URL;
  const billingUrl = `${baseUrl}/db_backup`;

  console.log("📤 Sending data to billing endpoint:", JSON.stringify(data, null, 2));
  console.log ("ssssssssssssssssssss",billingUrl)
  try {
    const response = await axios.post(billingUrl, data, {
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    console.log("✅ Data sent to billing endpoint successfully");
    console.log("Response status:", response.status);
    return true;
  } catch (error) {
    if (error.response) {
      console.error("❌ Billing API responded with error:", error.response.status, error.response.statusText);
      console.error("Response data:", error.response.data);
    } else if (error.request) {
      console.error("❌ No response received from billing API:", error.message);
    } else {
      console.error("❌ Failed to send data to billing endpoint:", error.message);
    }
    return false;
  }
}

// === Main backup process ===
async function performBackup() {
  let dumpProcess = null;
  let timeoutId = null;
  
  // Variables to track backup status
  let backupSuccess = false;
  let backupError = null;
  let backupUrl = null;
  let fileSizeMB = null;
  let duration = null;
  let companyName = null;
  let serviceDetails = null;

  try {
    // Find pg_dump
    const pgDumpPath = findPgDump();
    if (!pgDumpPath) {
      throw new Error("pg_dump not found");
    }

    // Verify backup directory exists
    if (!fs.existsSync(backupDir)) {
      console.log(`📁 Creating backups directory: ${backupDir}`);
      fs.mkdirSync(backupDir, { recursive: true });
    }

    // Get company name for folder structure
    const companyInfo = await getCompanyName();
    companyName = companyInfo.company_name || 'default_company';

    // Get service details
    serviceDetails = await getservisedetails();
    console.log("📋 Service details retrieved:", serviceDetails);

    console.log(`📁 Backing up database: ${dbName}`);
    console.log(`🏢 Company: ${companyName}`);
    console.log(`🔧 Using pg_dump from: ${pgDumpPath}`);
    console.log(`💾 Backup location: ${filePath}`);
    console.log(`🔐 Database host: ${dbHost}:${dbPort}`);
    console.log(`👤 Database user: ${dbUser}`);

    // Run pg_dump with proper error handling and skip permissions issues
    // Add --no-owner to avoid owner issues, and --no-privileges to skip permission errors
    dumpProcess = spawn(pgDumpPath, [
      '-h', dbHost,
      '-p', dbPort,
      '-U', dbUser,
      '-F', 'p',
      '-d', dbName,
      '--no-owner',           // Don't output owner commands
      '--no-privileges',      // Skip permission grants
      '--no-acl'              // Skip access privilege comments
    ], {
      env: { ...process.env, PGPASSWORD: dbPassword }
    });

    const outStream = fs.createWriteStream(filePath);
    const gzip = zlib.createGzip();

    // Pipe the output through gzip
    dumpProcess.stdout.pipe(gzip).pipe(outStream);

    let errorOutput = '';

    // Handle stderr (errors and progress)
    dumpProcess.stderr.on('data', (data) => {
      const message = data.toString();
      errorOutput += message;

      // Filter out permission errors (they're not fatal with --no-privileges)
      if (message.includes('permission denied')) {
        console.log(`⚠️ Permission warning (non-fatal): ${message.trim()}`);
      } else if (message.includes('error') || message.includes('ERROR')) {
        console.error(`❌ pg_dump error: ${message.trim()}`);
      } else if (message.includes('password')) {
        console.error(`❌ Authentication failed: ${message.trim()}`);
      } else if (message.includes('connection')) {
        console.error(`❌ Connection failed: ${message.trim()}`);
      } else if (process.env.DEBUG === 'true') {
        console.log(`🔍 pg_dump: ${message.trim()}`);
      }
    });

    // Handle dump process errors
    dumpProcess.on('error', (error) => {
      console.error(`❌ Failed to start pg_dump: ${error.message}`);
      if (timeoutId) clearTimeout(timeoutId);
    });

    // Set timeout for the entire backup (30 minutes max)
    timeoutId = setTimeout(() => {
      console.error("❌ Backup timeout after 30 minutes");
      if (dumpProcess && !dumpProcess.killed) {
        dumpProcess.kill('SIGTERM');
      }
    }, 30 * 60 * 1000);

    // Wait for dump process to complete
    const dumpExitCode = await new Promise((resolve) => {
      dumpProcess.on('close', resolve);
    });

    clearTimeout(timeoutId);

    if (dumpExitCode !== 0) {
      console.error(`❌ pg_dump exited with code ${dumpExitCode}`);
      if (errorOutput) {
        console.error(`Last error: ${errorOutput.substring(0, 500)}`);
      }
      throw new Error(`pg_dump failed with code ${dumpExitCode}`);
    }

    console.log(`✅ Database dump completed successfully`);

    // Wait for gzip to finish writing
    await new Promise((resolve) => {
      outStream.on('finish', resolve);
    });

    console.log('📂 Backup file compressed with gzip');

    // Verify the backup file exists and has content
    if (!fs.existsSync(filePath)) {
      throw new Error(`Backup file not found: ${filePath}`);
    }

    const fileStats = fs.statSync(filePath);
    if (fileStats.size === 0) {
      throw new Error('Backup file is empty!');
    }

    fileSizeMB = (fileStats.size / (1024 * 1024)).toFixed(2);
    console.log(`📊 Backup size: ${fileSizeMB} MB`);

    // Upload to S3 with company folder
    backupUrl = await uploadToS3(filePath, companyName);

    const endTime = new Date();
    console.log("✅ Backup finished at:", endTime.toLocaleString('en-GB', { timeZone: 'Asia/Colombo' }));

    duration = ((endTime - startTime) / 1000).toFixed(2);
    console.log(`⏱️ Total time taken: ${duration} seconds`);

    // Insert into system_log with dynamic column handling
    const logComment = `Database backup for ${companyName} completed in ${duration} seconds\nSize: ${fileSizeMB} MB\nURL: ${backupUrl}`;
    // await insertSystemLog(logComment, 'DB_BACKUP');

    // Delete old backups
    deleteOldBackups(fileName);

    backupSuccess = true;
    console.log("🎉 Backup completed successfully!");

  } catch (error) {
    console.error("❌ Backup failed:", error.message);
    console.error(error.stack);
    
    backupSuccess = false;
    backupError = error.message;

    // Log failure to database
    const errorMessage = `Backup failed: ${error.message}`;
    // await insertSystemLog(errorMessage, 'DB_BACKUP_ERROR');

    process.exit(1);
  } finally {
    // Prepare data for billing endpoint with all details
    const billingData = {
      status: backupSuccess ? 'success' : 'failed',
      company_name: companyName,
      timestamp: timestampDisplay,
      backup_file: fileName,
      backup_size_mb: fileSizeMB,
      duration_seconds: duration,
      backup_url: backupUrl,
      error_message: backupError,
      database_name: dbName,
      database_host: dbHost,
      database_port: dbPort,
      service_details: {
        billing_client_id: serviceDetails?.billing_client_id || null,
        billing_servise_id: serviceDetails?.billing_servise_id || null
      },
      s3_location: {
        bucket: process.env.DB_BACKUP_S3_BUCKET_NAME,
        region: process.env.DB_BACKUP_S3_REGION,
        endpoint: process.env.DB_BACKUP_S3_ENDPOINT
      },
      backup_metadata: {
        start_time: startTime.toISOString(),
        file_path: filePath,
        file_name: fileName
      }
    };
    
    // Send all data to billing endpoint
    await sendToBillingEndpoint(billingData);
  }
}

// Execute backup with unhandled rejection handling
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

performBackup();