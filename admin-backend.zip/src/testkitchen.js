const pool = require('../db');

/**
 * Calculate delta quantities for all items in an invoice.
 * Delta = total ordered qty - already sent qty to kitchen.
 * Filters strictly by invoice_id + invoice_item_id to prevent
 * cross-invoice contamination of the same product.
 *
 * Returns only items where delta > 0 (items that need to be sent).
 */
async function calculateDelta(invoiceId, client = pool) {
  const query = `
    SELECT
      i.id                                      AS invoice_item_id,
      i.invoice_id,
      i.product_id,
      COALESCE(kp.kitchen_id, 1)                AS kitchen_id,
      i.qty                                      AS total_qty,
      COALESCE(SUM(k.qty), 0)::int              AS already_sent,
      (i.qty - COALESCE(SUM(k.qty), 0))::int    AS delta
    FROM invoice_details i
    LEFT JOIN kitchen_products kp
      ON  kp.product_id = i.product_id
      AND kp.status     = 'Active'
    LEFT JOIN kitchen_order_lines k
      ON  k.invoice_item_id = i.id
      AND k.invoice_id      = i.invoice_id
      AND k.is_reprint      = false
    WHERE i.invoice_id = $1
    GROUP BY i.id, i.invoice_id, i.product_id, kp.kitchen_id, i.qty
    HAVING (i.qty - COALESCE(SUM(k.qty), 0)) > 0
    ORDER BY COALESCE(kp.kitchen_id, 1), i.product_id
  `;

  const { rows } = await client.query(query, [invoiceId]);
  return rows;
}

/**
 * Group delta rows by kitchen_id so we can send one
 * print job per kitchen instead of per item.
 */
function groupByKitchen(deltaRows) {
  return deltaRows.reduce((acc, row) => {
    const kid = row.kitchen_id;
    if (!acc[kid]) acc[kid] = [];
    acc[kid].push(row);
    return acc;
  }, {});
}

/**
 * Send items to kitchen:
 * 1. Calculate delta for the invoice.
 * 2. If nothing to send, return early.
 * 3. Insert one kitchen_order_lines row per item per kitchen.
 * 4. Return grouped result so the caller can trigger printing.
 *
 * Wrapped in a transaction — if the DB insert fails, nothing
 * is saved and the kitchen never receives a print job.
 */
async function sendToKitchen(invoiceId, sentBy = null) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const deltaRows = await calculateDelta(invoiceId, client);

    if (deltaRows.length === 0) {
      await client.query('ROLLBACK');
      return { sent: false, reason: 'No new items to send', groups: {} };
    }

    // Build bulk insert values
    const values = [];
    const params = [];
    let i = 1;

    for (const row of deltaRows) {
      values.push(`($${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, NOW(), false)`);
      params.push(
        row.invoice_id,
        row.invoice_item_id,
        row.kitchen_id,
        row.product_id,
        row.delta,
        sentBy
      );
    }

    const insertQuery = `
      INSERT INTO kitchen_order_lines
        (invoice_id, invoice_item_id, kitchen_id, product_id, qty, sent_by, sent_at, is_reprint)
      VALUES ${values.join(', ')}
      RETURNING *
    `;

    const { rows: inserted } = await client.query(insertQuery, params);

    await client.query('COMMIT');

    const grouped = groupByKitchen(deltaRows);
    return { sent: true, groups: grouped, insertedRows: inserted };

  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Reprint kitchen ticket for a specific invoice + kitchen.
 * Reads the last send's lines and inserts new rows flagged is_reprint = true.
 * Does NOT affect delta calculation (reprint rows are excluded from SUM).
 */
async function reprintKitchenTicket(invoiceId, kitchenId, reprintedBy = null) {
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Fetch the original sent lines for this invoice + kitchen
    const { rows: original } = await client.query(
      `SELECT * FROM kitchen_order_lines
       WHERE invoice_id = $1
         AND kitchen_id = $2
         AND is_reprint = false
       ORDER BY sent_at DESC`,
      [invoiceId, kitchenId]
    );

    if (original.length === 0) {
      await client.query('ROLLBACK');
      return { reprinted: false, reason: 'No original send found for this invoice and kitchen' };
    }

    // Insert reprint copies
    const values = [];
    const params = [];
    let i = 1;

    for (const row of original) {
      values.push(`($${i++}, $${i++}, $${i++}, $${i++}, $${i++}, $${i++}, NOW(), true)`);
      params.push(
        row.invoice_id,
        row.invoice_item_id,
        row.kitchen_id,
        row.product_id,
        row.qty,
        reprintedBy
      );
    }

    const { rows: reprinted } = await client.query(
      `INSERT INTO kitchen_order_lines
         (invoice_id, invoice_item_id, kitchen_id, product_id, qty, sent_by, sent_at, is_reprint)
       VALUES ${values.join(', ')}
       RETURNING *`,
      params
    );

    await client.query('COMMIT');

    return { reprinted: true, lines: reprinted };

  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Fetch all kitchen_order_lines for an invoice grouped by kitchen.
 * Useful for audit/history view.
 */
async function getKitchenHistory(invoiceId) {
  const { rows } = await pool.query(
    `SELECT
       k.*,
       p.name AS product_name,
       ki.name AS kitchen_name
     FROM kitchen_order_lines k
     LEFT JOIN products p  ON p.id = k.product_id
     LEFT JOIN kitchens ki ON ki.id = k.kitchen_id
     WHERE k.invoice_id = $1
     ORDER BY k.sent_at DESC`,
    [invoiceId]
  );
  return rows;
}

module.exports = { calculateDelta, sendToKitchen, reprintKitchenTicket, getKitchenHistory };