const pool = require("./config/db");
require('dotenv').config();

const app = require("./app");
const http = require("http");
const { Server } = require("socket.io");
const { initSocket } = require("./socket");

const PORT = process.env.PORT || 5008;


const server = http.createServer(app);

initSocket(server); 

pool.connect()
  .then(() => {
    console.log("Connected to PostgreSQL");
    server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch(err => console.error("Database connection error:", err));
