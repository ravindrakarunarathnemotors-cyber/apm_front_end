// src/validators/emsValidators.js
const Joi = require('joi');

// ─── Employee ────────────────────────────────────────────────────────────────
const createEmployeeSchema = Joi.object({
  first_name:                     Joi.string().min(1).max(80).required(),
  middle_name:                    Joi.string().max(80).allow('', null),
  last_name:                      Joi.string().min(1).max(80).required(),
  nic:                            Joi.string().min(5).max(20).required(),
  email:                          Joi.string().email().required(),
  contact_no:                     Joi.string().max(20).allow('', null),
  mobile_number:                  Joi.string().max(20).allow('', null),
  date_of_birth:                  Joi.date().iso().allow(null),
  gender:                         Joi.string().valid('Male', 'Female', 'Other', 'MALE', 'FEMALE', 'OTHER').allow('', null),
  marital_status:                 Joi.string().allow('', null),
  nationality:                    Joi.string().max(60).allow('', null),
  address:                        Joi.string().max(255).allow('', null),
  city:                           Joi.string().max(80).allow('', null),
  country:                        Joi.string().max(80).allow('', null),
  passport_number:                Joi.string().max(30).allow('', null),
  bank_account_no:                Joi.string().max(40).allow('', null),
  account_type:                   Joi.string().max(40).allow('', null),
  account_holder_name:            Joi.string().max(120).allow('', null),
  bank_branch:                    Joi.string().max(120).allow('', null),
  joined_date:                    Joi.date().iso().required(),
  employment_status:              Joi.string().max(40).allow('', null),
  job_specification:              Joi.string().max(255).allow('', null),
  job_category:                   Joi.string().max(80).allow('', null),
  probation_start_date:           Joi.date().iso().allow(null),
  probation_end_date:             Joi.date().iso().allow(null),
  date_of_permanency:             Joi.date().iso().allow(null),
  contract_start_date:            Joi.date().iso().allow(null),
  contract_end_date:              Joi.date().iso().allow(null),
  comments:                       Joi.string().allow('', null),
  special_note:                   Joi.string().allow('', null),
  designation_id:                 Joi.number().integer().positive().required(),
  shift_id:                       Joi.number().integer().positive().allow(null),
  payroll_template_id:            Joi.number().integer().positive().required(),
  department_id:                  Joi.number().integer().positive().required(),
  outlet_id:                      Joi.number().integer().positive().allow(null),
  emergency_contact_full_name:    Joi.string().max(120).allow('', null),
  emergency_contact_relationship: Joi.string().max(60).allow('', null),
  emergency_contact_mobile_no:    Joi.string().max(20).allow('', null),
  emergency_contact_address:      Joi.string().max(255).allow('', null),
  net_salary_effective_date:      Joi.date().iso().allow(null),
  salary_start_day:               Joi.number().integer().min(1).max(31).allow(null),
  salary_start_date:              Joi.date().iso().allow(null),
  first_salary_strategy:          Joi.string().valid('CURRENT_MONTH', 'NEXT_MONTH').default('CURRENT_MONTH'),
  salary_generation_type:         Joi.string().valid('AUTO', 'MANUAL').default('MANUAL'),
  create_user_account: Joi.boolean().default(false),
  username: Joi.string().min(3).max(60).when('create_user_account', {
    is: true,
    then: Joi.required(),
    otherwise: Joi.optional().allow(null, ''),
  }),
  role_id: Joi.number().integer().positive().when('create_user_account', {
    is: true,
    then: Joi.required(),
    otherwise: Joi.optional().allow(null),
  }),
  password: Joi.string().min(8).when('create_user_account', {
    is: true,
    then: Joi.required(),
    otherwise: Joi.optional().allow(null, ''),
  }),
});

const updateEmployeeSchema = Joi.object({
  first_name:                Joi.string().min(1).max(80),
  middle_name:               Joi.string().max(80).allow('', null),
  last_name:                 Joi.string().min(1).max(80),
  contact_no:                Joi.string().max(20).allow('', null),
  email:                     Joi.string().email(),
  employment_status:         Joi.string().max(40).allow('', null),
  designation_id:            Joi.number().integer().positive(),
  shift_id:                  Joi.number().integer().positive().allow(null),
  payroll_template_id:       Joi.number().integer().positive(),
  department_id:             Joi.number().integer().positive(),
  mobile_number:             Joi.string().max(20).allow('', null),
  passport_number:           Joi.string().max(30).allow('', null),
  account_type:              Joi.string().max(40).allow('', null),
  account_holder_name:       Joi.string().max(120).allow('', null),
  bank_branch:               Joi.string().max(120).allow('', null),
  special_note:              Joi.string().allow('', null),
  net_salary_effective_date: Joi.date().iso().allow(null),
  salary_start_day:          Joi.number().integer().min(1).max(31).allow(null),
  salary_start_date:         Joi.date().iso().allow(null),
  first_salary_strategy:     Joi.string().valid('CURRENT_MONTH', 'NEXT_MONTH'),
  salary_generation_type:    Joi.string().valid('AUTO', 'MANUAL'),
});

// ─── Leave ───────────────────────────────────────────────────────────────────
const createLeaveSchema = Joi.object({
  employee_id:   Joi.number().integer().positive().required(),
  leave_type_id: Joi.number().integer().positive().required(),
  duration_type: Joi.string()
    .valid('full_day', 'first_half', 'second_half', 'multiple')
    .required(),
  from_date: Joi.date().iso().required(),
  to_date:   Joi.date().iso().min(Joi.ref('from_date')).when('duration_type', {
    is:        'multiple',
    then:      Joi.required(),
    otherwise: Joi.optional().allow(null),
  }),
  reason: Joi.string().min(3).max(500).required(),
});

const updateLeaveStatusSchema = Joi.object({
  status:      Joi.string().valid('Approved', 'Rejected').required(),
  admin_note:  Joi.string().max(500).allow('', null),
  paid_status: Joi.string().valid('paid', 'unpaid').default('paid'),
});

// ─── Designation ─────────────────────────────────────────────────────────────
const createDesignationSchema = Joi.object({
  designation_name: Joi.string().min(1).max(120).required(),
  department_name:  Joi.string().min(1).max(120).required(),
   status:           Joi.string().valid('Active', 'Inactive', 'active', 'inactive').default('Active'),
  sick_leave:       Joi.number().min(0).default(0),
  casual_leave:     Joi.number().min(0).default(0),
  annual_leave:     Joi.number().min(0).default(0),
  maternity_leave:  Joi.number().min(0).default(0),
  paternity_leave:  Joi.number().min(0).default(0),
});

// ─── Shift ───────────────────────────────────────────────────────────────────
const createShiftSchema = Joi.object({
  shift_name: Joi.string().min(1).max(80).required(),
  weekday:    Joi.string().max(255).allow('', null),
  days:       Joi.array().items(
    Joi.object({
      weekday: Joi.string().required(),
      inTime:  Joi.string().required(),
      outTime: Joi.string().required(),
    })
  ).allow(null),
  shift_in_time:        Joi.string().allow('', null),
  shift_out_time:       Joi.string().allow('', null),
  grace_period_minutes: Joi.number().integer().min(0).default(0),
  early_ot_minutes:     Joi.number().integer().min(0).default(0),
  after_ot_minutes:     Joi.number().integer().min(0).default(0),
  max_ot_minutes:       Joi.number().integer().min(0).default(0),
  holiday_ot_minutes:   Joi.number().integer().min(0).default(0),
});

// ─── Department ──────────────────────────────────────────────────────────────
const createDepartmentSchema = Joi.object({
  department_name: Joi.string().min(1).max(120).required(),
  status:          Joi.string().valid('Active', 'Inactive').default('Active'),
});

// ─── Attendance ──────────────────────────────────────────────────────────────
const createAttendanceSchema = Joi.object({
  employee_id:     Joi.number().integer().positive().required(),
  name:            Joi.string().max(160).allow('', null),
  check_in_date:   Joi.date().iso().required(),
  clock_in_time:   Joi.string().required(),
  check_out_date:  Joi.date().iso().required(),
  clock_out_time:  Joi.string().required(),
  log_source:      Joi.string().max(60).allow('', null),
  shift_id:        Joi.number().integer().positive().required(),
  roster_id:       Joi.number().integer().positive().allow(null),
  attendance_note: Joi.string().max(255).allow('', null),
  day_off:         Joi.boolean().default(false),
});

// ─── Earning / Deduction ─────────────────────────────────────────────────────
const createEarningDeductionSchema = Joi.object({
  name:             Joi.string().min(1).max(120).required(),
  type:             Joi.string().valid('EARNINGS', 'DEDUCTIONS').required(),
  calculation_type: Joi.string().valid('AMOUNT', 'PERCENTAGE').required(),
  status:           Joi.string().valid('ACTIVE', 'INACTIVE').default('ACTIVE'),
  created_by:       Joi.number().integer().positive().required(),
});

// ─── Paysheet ────────────────────────────────────────────────────────────────
const generatePaysheetSchema = Joi.object({
  employee_id:        Joi.number().integer().positive().required(),
  payroll_month:      Joi.number().integer().min(1).max(12).required(),
  payroll_year:       Joi.number().integer().min(2000).max(2100).required(),
  salary_range_start: Joi.date().iso().required(),
  salary_range_end:   Joi.date().iso().min(Joi.ref('salary_range_start')).required(),
  line_items: Joi.array().items(
    Joi.object({
      earning_deduction_id: Joi.number().integer().allow(null),
      type:   Joi.string().valid('EARNING', 'EARNINGS', 'DEDUCTION', 'DEDUCTIONS').required(),
      amount: Joi.number().min(0).required(),
      name:   Joi.string().allow('', null),
    })
  ).default([]),
  total_earnings:   Joi.number().min(0).allow(null),
  total_deductions: Joi.number().min(0).allow(null),
  net_salary:       Joi.number().allow(null),
  generation_type:  Joi.string().valid('MANUAL', 'AUTO').default('MANUAL'),
});

// ─── Shift Roster ────────────────────────────────────────────────────────────
const createShiftRosterSchema = Joi.object({
  employee_ids: Joi.array().items(Joi.number().integer().positive()).min(1).required(),
  shift_id:     Joi.number().integer().positive().required(),
  roster_date:  Joi.date().iso().required(),
  remarks:      Joi.string().max(255).allow('', null),
});

// ─── Holiday ─────────────────────────────────────────────────────────────────
const createHolidaySchema = Joi.object({
  holiday_date:      Joi.date().iso().required(),
  holiday_name:      Joi.string().min(1).max(120).required(),
  holiday_type:      Joi.string().max(60).allow('', null),
  occasion:          Joi.string().max(255).allow('', null),
  employment_status: Joi.string().max(60).allow('', null),
  department_ids:    Joi.array().items(Joi.number().integer()).default([]),
  designation_ids:   Joi.array().items(Joi.number().integer()).default([]),
});

// ─── Employee Remark ─────────────────────────────────────────────────────────
const createEmployeeRemarkSchema = Joi.object({
  employee_id: Joi.number().integer().positive().required(),
  remark:      Joi.string().min(1).max(1000).required(),
  remark_date: Joi.date().iso().allow(null),
  remark_type: Joi.string()
    .valid('GENERAL', 'WARNING', 'APPRECIATION', 'DISCIPLINARY')
    .default('GENERAL'),
});

module.exports = {
  createEmployeeSchema,
  updateEmployeeSchema,
  createLeaveSchema,
  updateLeaveStatusSchema,
  createDesignationSchema,
  createShiftSchema,
  createDepartmentSchema,
  createAttendanceSchema,
  createEarningDeductionSchema,
  generatePaysheetSchema,
  createShiftRosterSchema,
  createHolidaySchema,
  createEmployeeRemarkSchema,
};