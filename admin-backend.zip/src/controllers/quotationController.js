const pool = require("../config/db");
const { formatPhoneNumber } = require("../models/authModels");
const { adminUserDeatils, systemSettings, brandingSettings, getDeliveryFee, oneCountry, updateLoyaltySuctomer, checkLoyalty, addLoyalty } = require("../models/commonModels");
const { insertNotification } = require("../models/notificationsUpdater");
const { customhook } = require("../models/smsnotificationmodel");
const { insertAdminLog } = require("../models/userLogs");
const bcrypt = require("bcrypt");
const saltRounds = 10;

const createQuotation = async (req, res) => {
    const {
        products,
        client,
        clientDetails,
        taxManualEnable,
        discountvalue,
        taxValue,
        totalTax,
        discountDetails,
        timePeriod,
        note,
        recipient_note,
        lastSubTotal,
        fastAmount,
        quotationDate
    } = req.body
    console.log("products", products)
    const user = req.user
    const user_id = user.user_id


    try {

        const type = discountDetails && discountDetails.type ? discountDetails.type : null
        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

        //admin merchant id
        const [adminDetails, system_settings] = await Promise.all([
            adminUserDeatils(user_id),
            systemSettings()
        ])

        const merchant_id = adminDetails.merchant_id

        const totalAmount = lastSubTotal

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  taxManualEnable - tax add on off
        let grandtax = null;
        if (system_settings.tax && taxManualEnable) {
            grandtax = totalTax;
        }

        const fullAmount = fastAmount

        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let discount_id_have = null
        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            discount_id_have = discountDetails.discount_id
        }

        const orderQuery = `INSERT INTO quotation_header (user_id, customer_id, merchant_id, status, total_value,  total_item, total_weight, currency, sender_name, sender_phone, sender_email, sender_address, sender_city, sender_country,  discount, tax_percentage, tax,  full_amount,  discount_type,note,time_period,recipent_note,quotation_date, discount_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24) RETURNING id`

        const OrderParms = [user_id, client.value, merchant_id, 'pending', totalAmount, totalQuantity, 0, system_settings.currency, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.contact_number_1, clientDetails.email, clientDetails.address, clientDetails.city, clientDetails.country_name, totalDiscount, taxValue, grandtax, fullAmount, type, note, timePeriod, recipient_note, quotationDate, discount_id_have]

        const orderResult = await pool.query(orderQuery, OrderParms)

        if (orderResult.rowCount === 0) return res.status(400).json({ message: "order not created" })


        const orderItemParams = []
        const values = []

        products.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            if (type === 'manual_product' && product.discount) {
                const productDiscount = product.discountType === 'fixed' ? product.discount : (Number(product.price) * Number(product.selectedQty) * Number(product.discount)) / 100
                if (productDiscount) {
                    discount = productDiscount
                }
            }

            const baseIndex = 15 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8},
                $${baseIndex + 9}, $${baseIndex + 10}, $${baseIndex + 11}, $${baseIndex + 12},
                $${baseIndex + 13}, $${baseIndex + 14}, $${baseIndex + 15})`
            );


            orderItemParams.push(
                orderResult.rows[0].id,
                product.is_custom ? null : product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                0,
                is_free,                             // 8. is_free
                free_quantity,
                product.title || null,             // name
                product.description || null,       // description
                product.is_custom === true,         // is_custom
                product.amount_per_unit || null,   // amount_per_unit
                product.measurement_id || null,
                discount
            );
        });


        //add order items 
        const orderItemQuery = `INSERT INTO quotation_details (quotation_id, product_id, variant_id, quantity, unit_price, total_price, item_weight, is_free, free_quantity, name, description, is_custom, amount_per_unit, unit_type, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        // if (discountDetails && discountDetails?.discount_id && type != 'manual') {
        //     //discount useage table
        //     const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id) VALUES ($1, $2, $3)`

        //     const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].id, discountDetails.discount_id, client.value])

        //     if (discountUsageResult.rowCount === 0) {
        //         return res.status(400).json({ message: "Discount usage not added" })
        //     }
        // }

        const module = "Quotation";
        const logMessage = `New Quotation #${orderResult.rows[0].id} has been placed by user ${user_id}`;


        const [notification] = await Promise.all([
            insertNotification(user_id, 'Quotation Management', 'New Quotation Created', `New Quotation #${orderResult.rows[0].id} has been placed for ${clientDetails.first_name} ${clientDetails.last_name}.`, 'admin', 'Unread'),
            insertAdminLog(user_id, module, logMessage),


        ])



        return res.status(200).json({ message: "success" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({ message: "Internal server error" })
    }
}

const oneQuotationUpdateDetails = async (req, res) => {
    const { order_id } = req.params;

    if (!order_id) {
        return res.status(400).json({ message: "order_id is required" });
    }

    const query = `
    SELECT
      o.id,
      o.status,
      o.customer_id,
      o.sender_name,
      o.sender_city,	
      o.sender_phone,
      o.sender_email,	
      o.note,
      o.recipent_note,
      o.sender_address,
      sender_co.id AS sender_country_id,
      sender_country AS sender_country_name,
      cu.loyalty_point,
      o.discount,
      o.discount_type,
      json_agg(
        json_build_object(
          'variant_id', oi.variant_id,
          'variant_value', v.variant_value,
          'count', CASE WHEN oi.amount_per_unit IS NULL THEN NULL ELSE oi.quantity * oi.amount_per_unit END,
          'product_id', oi.product_id,
          'selectedQty', oi.quantity,
          'unit_price', oi.unit_price,
          'price', oi.unit_price,
          'total_price', oi.total_price,
          'measurement_needed', CASE WHEN oi.unit_type::integer  = 1 THEN false ELSE true END,
          'measurement_id', oi.unit_type,
          'measurement_value', m.measurement_value,
          'amount_per_unit', oi.amount_per_unit,
          'main_img', pm.media_url,
          'first_extra_img', pmd_first.media_url,
          'title', oi.name,
          'description', oi.description
        )
        ORDER BY oi.id
      ) AS variants
    FROM quotation_header o
    INNER JOIN quotation_details oi ON oi.quotation_id = o.id
    LEFT JOIN products p ON p.product_id = oi.product_id
    LEFT JOIN product_variants v ON v.variant_id = oi.variant_id
    INNER JOIN customer cu ON cu.customer_id = o.customer_id
    LEFT JOIN measurements m ON oi.unit_type::integer = m.measurement_id
    LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
    LEFT JOIN countries sender_co ON LOWER(sender_co.country_name) = LOWER(o.sender_country)
    LEFT JOIN LATERAL (
      SELECT media_url
      FROM product_media
      WHERE product_id = p.product_id AND main = true AND variant_id IS NOT NULL
      ORDER BY created_at ASC
      LIMIT 1
    ) pmd_first ON true
    WHERE o.id = $1
    GROUP BY o.id, sender_co.id, cu.loyalty_point
  `;

    try {
        const result = await pool.query(query, [order_id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }
        return res.status(200).json({ message: "success", result: result.rows[0] });
    } catch (err) {
        console.error("Error fetching products by order ID:", err);
        return res.status(500).json({ message: "Server error", error: err.message });
    }
}

const updateQuotation = async (req, res) => {
    try {
        const { order_id } = req.params;
        const { products,
            client,
            clientDetails,
            taxManualEnable,
            selectedPaymentMethod,
            discountvalue,
            taxValue,
            totalTax,
            discountDetails,
            amount,
            lastSubTotal,
            fastAmount,
            recipient_note,
            note

        } = req.body

        // ✅ take from token instead of hardcoding
        const user = req.user
        const user_id = user.user_id
        const merchant_id = req.user?.merchant_id;
        const branch_id = req.user?.outlet_id || 1;
        console.log("products", products)
        console.log("discountDetails", discountDetails)
        console.log("discountvalue", discountvalue)


        const orderDetailsQuery = `SELECT id, customer_id, status FROM quotation_header WHERE id = $1`;

        const [system_settings, orderDetails] = await Promise.all([
            systemSettings(),
            pool.query(orderDetailsQuery, [order_id])
        ]);

        if (orderDetails.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const order = orderDetails.rows[0];

        const type = discountDetails && discountDetails.type ? discountDetails.type : null

        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

        const convertAmount = amount ? parseFloat(amount) : 0

        // check COD or not
        let cod = false
        if (selectedPaymentMethod == 3) {
            cod = true
        }

        const totalAmount = lastSubTotal

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  taxManualEnable - tax add on off
        let grandtax = null;
        if (system_settings.tax && taxManualEnable) {
            grandtax = totalTax;
        }

        console.log(system_settings)

        const fullAmount = fastAmount

        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let discount_id_have = null
        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            discount_id_have = discountDetails.discount_id
        }

        const orderQuery = `
         UPDATE quotation_header
                SET 
                user_id = $1,
                customer_id = $2,
                merchant_id = $3,
                total_value = $4,
                total_item = $5,
                currency = $6,
                sender_name = $7,
                sender_city = $8,
                sender_phone = $9,
                sender_email = $10,
                sender_country = $11,
                sender_address = $12,
                discount = $13,
                tax_percentage = $14,
                tax = $15,
                full_amount = $16,
                discount_type = $17,
                note = $18,
                recipent_note = $19,
                discount_id = $20
                WHERE id = $21
                RETURNING id;

        `;


        const OrderParms = [
            user_id,
            client.value,
            merchant_id,
            totalAmount,
            totalQuantity,
            system_settings.currency,
            clientDetails.first_name + ' ' + clientDetails.last_name,
            clientDetails.city,
            clientDetails.contact_number_1,
            clientDetails.email,
            clientDetails.country_name,
            clientDetails.address,
            parseFloat(totalDiscount ? totalDiscount : 0) || 0,
            taxValue,
            grandtax,
            fullAmount,
            type,
            note,
            recipient_note,
            discount_id_have,
            order_id]

        const orderResult = await pool.query(orderQuery, OrderParms);

        if (orderResult.rowCount === 0) {
            return res.status(400).json({ message: "Order not found" });
        }

        const deleteItemsQuery = pool.query(
            `DELETE FROM quotation_details WHERE quotation_id = $1`,
            [order_id]
        );

        const [deleteItemsResult] = await Promise.all([
            deleteItemsQuery
        ]);

        if (deleteItemsResult.rowCount === 0) {
            return res.status(400).json({ message: "Order not found" });
        }

        const orderItemParams = []
        const values = []

        products.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            if (type === 'manual_product' && product.discount) {
                const productDiscount = product.discountType === 'fixed' ? product.discount : (Number(product.price) * Number(product.selectedQty) * Number(product.discount)) / 100
                if (productDiscount) {
                    discount = productDiscount
                }
            }

            const baseIndex = 15 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8},
                $${baseIndex + 9}, $${baseIndex + 10}, $${baseIndex + 11}, $${baseIndex + 12},
                $${baseIndex + 13}, $${baseIndex + 14}, $${baseIndex + 15})`
            );


            orderItemParams.push(
                orderResult.rows[0].id,
                product.is_custom ? null : product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                0,
                is_free,                             // 8. is_free
                free_quantity,
                product.title || null,             // name
                product.description || null,       // description
                product.is_custom === true,         // is_custom
                product.amount_per_unit || null,   // amount_per_unit
                product.measurement_id || null,
                discount
            );
        });

        //add order items 
        const orderItemQuery = `INSERT INTO quotation_details (quotation_id, product_id, variant_id, quantity, unit_price, total_price, item_weight, is_free, free_quantity, name, description, is_custom, amount_per_unit, unit_type, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        // if (discountDetails && discountDetails?.discount_id && type != 'manual') {
        //     //discount useage table
        //     const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id) VALUES ($1, $2, $3)`

        //     const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value])

        //     if (discountUsageResult.rowCount === 0) {
        //         return res.status(400).json({ message: "Discount usage not added" })
        //     }
        // }

        const module = "Quotation";
        const logMessage = `Quotation #${order_id} has been updated by user ${user_id}.`;

        const [notification] = await Promise.all([
            insertNotification(user_id, 'Quotation Management', 'Update Quotation', `Order #${order_id} has been updated by user ${user_id}.`, 'admin', 'Unread'),
            insertAdminLog(user_id, module, logMessage),

        ])



        return res.status(200).json({
            message: "Order updated successfully",
        });

    } catch (err) {
        console.error('Error updating order:', err);
        return res.status(500).json({ message: "Server error", error: err.message });
    }
}




const createCustomerQuo = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id;

    const {
        first_name,
        last_name,
        email,
        contact_number_1,
        contact_number_2,
        address,
        apartment,
        city,
        postal_code,
        country,
        company,
        company_name,
        picture,
    } = req.body;

    const password = "guest123";

    try {
        /* -------------------- BASIC VALIDATIONS -------------------- */
        if (!first_name || !last_name || !address || !city) {
            return res.status(400).json({ message: "All fields are required" });
        }

        if (!email && !contact_number_1) {
            return res.status(400).json({
                message: "Email or Contact number is required",
            });
        }

        /* -------------------- FORMAT PHONE -------------------- */
        let formattedNumber = null;

        if (contact_number_1) {
            const mobileNew = formatPhoneNumber(contact_number_1);
            if (mobileNew.error) {
                return res.status(400).json({ message: mobileNew.error });
            }
            formattedNumber = mobileNew.formatted;
        }

        /* -------------------- DUPLICATE CHECK -------------------- */
        const conditions = [];
        const params = [];

        const normalizedEmail = email ? String(email).trim().toLowerCase() : null;

        if (normalizedEmail) {
            params.push(normalizedEmail);
            conditions.push(`LOWER(TRIM(email)) = $${params.length}`);
        }

        if (formattedNumber) {
            params.push(formattedNumber);
            conditions.push(`contact_number_1 = $${params.length}`);
        }

        if (conditions.length === 0) {
            return res.status(400).json({
                message: "Email or Contact number is required",
            });
        }

        const userCheckQuery = `
      SELECT customer_id
      FROM customer
      WHERE ${conditions.join(" OR ")}
    `;

        const userCheckResult = await pool.query(userCheckQuery, params);

        if (userCheckResult.rows.length > 0) {
            return res.status(400).json({ message: "User already exists" });
        }

        /* -------------------- CREATE CUSTOMER -------------------- */
        const hash = await bcrypt.hash(password, saltRounds);

        const insertQuery = `
      INSERT INTO customer (
        first_name,
        last_name,
        email,
        contact_number_1,
        contact_number_2,
        address,
        apartment,
        city,
        postal_code,
        country,
        company_name,
        picture,
        password
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
      RETURNING customer_id
    `;

        const insertResult = await pool.query(insertQuery, [
            first_name,
            last_name,
            normalizedEmail,
            formattedNumber,
            contact_number_2 || "",
            address,
            apartment || "",
            city,
            postal_code || "",
            country,
            company || company_name || "",
            picture || null,
            hash,
        ]);

        if (insertResult.rowCount === 0) {
            return res.status(400).json({ message: "Customer not created" });
        }

        const customerId = insertResult.rows[0].customer_id;

        /* -------------------- FETCH CREATED CUSTOMER -------------------- */
        const customerResult = await pool.query(
            `
      SELECT
        customer_id,
        first_name,
        last_name,
        email,
        contact_number_1,
        address,
        apartment,
        city,
        postal_code,
        country
      FROM customer
      WHERE customer_id = $1
      `,
            [customerId]
        );

        const customer = customerResult.rows[0];

        /* -------------------- ADMIN LOG -------------------- */
        const module = "Customer";
        const logMessage = `New customer #${customerId} has been created by user ${user_id}`;
        await insertAdminLog(user_id, module, logMessage);

        await customhook(8, customerId);

        /* -------------------- FINAL RESPONSE -------------------- */
        return res.status(201).json({
            message: "success",
            result: {
                value: customer.customer_id, // 🔥 react-select compatible
                first_name: customer.first_name,
                last_name: customer.last_name,
                email: customer.email,
                contact_number_1: customer.contact_number_1,
                address: customer.address,
                apartment: customer.apartment,
                city: customer.city,
                postal_code: customer.postal_code,
                country: customer.country,
            },
        });
    } catch (error) {
        console.error("Create Customer Error:", error);
        return res.status(500).json({ message: "Internal server error" });
    }
};





module.exports = {
    createQuotation, updateQuotation, oneQuotationUpdateDetails, createCustomerQuo
}