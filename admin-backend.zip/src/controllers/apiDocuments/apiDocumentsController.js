const pool = require("../../config/db");
const crypto = require("crypto");

// ── Helper: generate a secure API key ─────────────────────────────────────────
const generateApiKey = () => {
  return "sk_live_" + crypto.randomBytes(32).toString("hex");
};


function normalizePhoneNumber(mobile = '') {
  const cleaned = mobile.replace(/\D/g, '');
  if (cleaned.startsWith('94')) return cleaned;
  if (cleaned.startsWith('0'))  return `94${cleaned.slice(1)}`;
  if (cleaned.startsWith('7'))  return `94${cleaned}`;
  return cleaned;
}


// ── Action number mapping ──────────────────────────────────────────────────────
const ACTION_MAP = {
  AWARD:   1,
  REDEEM:  2,
  CHECK:   3,
  BALANCE: 3,
  REVERSE: 4,
};

// ── Reverse map: number → action string ───────────────────────────────────────
const ACTION_REVERSE_MAP = {
  1: 'AWARD',
  2: 'REDEEM',
  3: 'CHECK',
  4: 'REVERSE',
};

// // ── GET API Details ────────────────────────────────────────────────────────────
// const getApiDetails = async (req, res) => {
//   try {
//     const { rows } = await pool.query(
//       `SELECT id, client_id, api_key, is_active, created_at, updated_at
//        FROM apidocuments
//        ORDER BY id ASC
//        LIMIT 1`
//     );

//     return res.status(200).json({
//       success: true,
//       data: rows,
//     });
//   } catch (err) {
//     console.error("[getApiDetails]", err);
//     return res.status(500).json({
//       success: false,
//       message: "Internal server error.",
//     });
//   }
// };

// ── TOGGLE API Status (activate / deactivate) ──────────────────────────────────
// ── TOGGLE API Status (activate / deactivate) ──────────────────────────────────
const toggleApiStatus = async (req, res) => {
  try {
    const { is_active } = req.body;

    // ✅ FIX: Also accept 1/0 or "true"/"false" strings from some clients
    const activeValue =
      is_active === true || is_active === 'true' || is_active === 1
        ? true
        : is_active === false || is_active === 'false' || is_active === 0
        ? false
        : null;

    if (activeValue === null) {
      return res.status(400).json({
        success: false,
        message: 'is_active must be a boolean value.',
      });
    }

    const existing = await pool.query(
      `SELECT id FROM apidocuments ORDER BY id ASC LIMIT 1`
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'API document record not found.',
      });
    }

    const id = existing.rows[0].id;

    const { rows } = await pool.query(
      `UPDATE apidocuments
       SET is_active  = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, client_id, api_key, is_active, created_at, updated_at`,
      [activeValue, id]   // ✅ FIX: use activeValue not is_active
    );

    // ✅ FIX: Return data as array to match getApiDetails shape
    return res.status(200).json({
      success: true,
      message: `API ${activeValue ? 'activated' : 'deactivated'} successfully.`,
      data: rows,  // ← was rows[0], now rows (array)
    });
  } catch (err) {
    console.error('[toggleApiStatus]', err);
    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
};

// ── REGENERATE API Key ─────────────────────────────────────────────────────────
const regenerateApiKey = async (req, res) => {
  try {
    const existing = await pool.query(
      `SELECT id FROM apidocuments ORDER BY id ASC LIMIT 1`
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "API document record not found.",
      });
    }

    const id = existing.rows[0].id;
    const newKey = generateApiKey();

    const { rows } = await pool.query(
      `UPDATE apidocuments
       SET api_key   = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, client_id, api_key, is_active, created_at, updated_at`,
      [newKey, id]
    );

    return res.status(200).json({
      success: true,
      message: "API key regenerated successfully.",
      data: rows[0],
    });
  } catch (err) {
    console.error("[regenerateApiKey]", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error.",
    });
  }
};

// ── UPDATE Client ID ───────────────────────────────────────────────────────────
const updateClientId = async (req, res) => {
  try {
    const { client_id } = req.body;

    if (!client_id || !client_id.trim()) {
      return res.status(400).json({
        success: false,
        message: "client_id is required.",
      });
    }

    const existing = await pool.query(
      `SELECT id FROM apidocuments ORDER BY id ASC LIMIT 1`
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "API document record not found.",
      });
    }

    const id = existing.rows[0].id;

    const { rows } = await pool.query(
      `UPDATE apidocuments
       SET client_id  = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, client_id, api_key, is_active, created_at, updated_at`,
      [client_id.trim(), id]
    );

    return res.status(200).json({
      success: true,
      message: "Client ID updated successfully.",
      data: rows[0],
    });
  } catch (err) {
    console.error("[updateClientId]", err);

    // Unique constraint violation
    if (err.code === "23505") {
      return res.status(409).json({
        success: false,
        message: "This Client ID is already in use.",
      });
    }

    return res.status(500).json({
      success: false,
      message: "Internal server error.",
    });
  }
};

// ── GET API Logs ───────────────────────────────────────────────────────────────
const getApiLogs = async (req, res) => {
  try {
    const {
      keyword,
      action,
      status_code,
      from_date,
      to_date,
      page = 1,
      limit = 20,
    } = req.query;

    const parsedPage  = parseInt(page, 10);
    const parsedLimit = parseInt(limit, 10);
    const offset      = (parsedPage - 1) * parsedLimit;

    let queryParams     = [];
    let whereConditions = [];

    // Keyword: search by order_id, customer_mobile, customer_email
      if (keyword && keyword.trim()) {
      queryParams.push(`%${keyword.trim()}%`);
      const n = queryParams.length;
      whereConditions.push(
        `(customer_mobile ILIKE $${n} OR customer_email ILIKE $${n} OR order_id ILIKE $${n})`
      );
    }

    // Filter by action
   if (action && action.trim()) {
  const actionValue = ACTION_MAP[action.trim().toUpperCase()] ?? parseInt(action.trim(), 10);
  if (!isNaN(actionValue)) {
    queryParams.push(actionValue);
    whereConditions.push(`action = $${queryParams.length}`);
  }
}

    // Filter by status_code
    if (status_code) {
      queryParams.push(parseInt(status_code, 10));
      whereConditions.push(`status_code = $${queryParams.length}`);
    }

    // Date range
    if (from_date) {
      queryParams.push(from_date);
      whereConditions.push(`created_at::date >= $${queryParams.length}`);
    }
    if (to_date) {
      queryParams.push(to_date);
      whereConditions.push(`created_at::date <= $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // Total count
    const countResult = await pool.query(
      `SELECT COUNT(*) AS total FROM api_logs ${whereClause}`,
      queryParams
    );
    const total = parseInt(countResult.rows[0].total, 10);

    // Data query
    const dataParams = [...queryParams, parsedLimit, offset];
    const dataResult = await pool.query(
      `SELECT
          id,
          client_id,
          customer_id,
          customer_mobile,
          customer_email,
          order_id,
          order_value,
          action,
          prev_points,
          adjust_points,
          new_points,
          status_code,
          message,
          request_body,
          created_at
       FROM api_logs
       ${whereClause}
       ORDER BY created_at DESC
       LIMIT $${dataParams.length - 1}
       OFFSET $${dataParams.length}`,
      dataParams
    );

    return res.status(200).json({
      success: true,
      data: dataResult.rows,
      total,
      page: parsedPage,
      per_page: parsedLimit,
      total_pages: Math.ceil(total / parsedLimit),
    });
  } catch (err) {
    console.error("[getApiLogs]", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error.",
    });
  }
};

// ── VALIDATE incoming loyalty point request (used by external e-commerce) ──────
const loyaltyPointRequest = async (req, res) => {
  try {
    const {
      client_id,
      api_key,
      order_id,
      order_value,
      customer_mobile,
      customer_email,
      customer_name,
    } = req.body;

    // ── 1. Auth check ─────────────────────────────────────────────────────
    if (!client_id || !api_key) {
      return res.status(400).json({ status: 400, message: "client_id and api_key are required." });
    }

    const docResult = await pool.query(
      `SELECT id, is_active FROM apidocuments
       WHERE client_id = $1 AND api_key = $2`,
      [client_id, api_key]
    );

    if (docResult.rows.length === 0) {
      await _insertLog({
         client_id,  
         order_id, 
         order_value, 
         customer_mobile, 
         customer_email, 
         action: ACTION_MAP["CHECK"],   // → 4, 
         status_code: 401, 
         message: "Invalid client_id or api_key.", req });
      return res.status(401).json({ status: 401, message: "Unauthorized. Invalid client_id or api_key." });
    }

    if (!docResult.rows[0].is_active) {
      await _insertLog({ 
        client_id,  
        order_id, 
        order_value, 
        customer_mobile, 
        customer_email, 
        action: ACTION_MAP["CHECK"],   // → 4
        status_code: 403, 
        message: "API access is not activated.", req });
      return res.status(403).json({ status: 403, message: "Forbidden. API access is not activated for this account." });
    }

    // ── 2. Parameter validation ───────────────────────────────────────────
   
    if (!order_id)        return _validationError(res, 400, "order_id is required.");
    if (!customer_mobile) return _validationError(res, 214, "Customer mobile number is required.");
    if (!customer_email)  return _validationError(res, 216, "Customer email address is required.");

    // Validate mobile format (basic)
    if (!/^\d{10,15}$/.test(customer_mobile)) {
      return _validationError(res, 215, "Customer mobile number format is invalid.");
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer_email)) {
      return _validationError(res, 217, "Customer email address format is invalid.");
    }

    // Validate order_value
    const parsedOrderValue = parseFloat(order_value);
    if (isNaN(parsedOrderValue) || parsedOrderValue <= 0) {
      return _validationError(res, 210, "Order value must be a positive number greater than 0.");
    }

    // ── 3. Duplicate order check ──────────────────────────────────────────
    const dupCheck = await pool.query(
      `SELECT id FROM api_logs
       WHERE client_id = $1 AND order_id = $2 AND status_code = 201`,
      [client_id, order_id]
    );

    if (dupCheck.rows.length > 0) {
      await _insertLog({ 
        client_id,  
        order_id, 
        order_value: parsedOrderValue, 
        customer_mobile, customer_email, 
        action: ACTION_MAP["CHECK"],   // → 4
        status_code: 211, 
        message: "Duplicate order_id.", req });
      return res.status(200).json({ status: 211, message: "Loyalty points already awarded for this order_id." });
    }

    // ── 4. Get or create customer loyalty account ─────────────────────────
    let customerResult = await pool.query(
      `SELECT id, loyalty_points FROM loyalty_customers
       WHERE mobile = $1 OR email = $2
       LIMIT 1`,
      [customer_mobile, customer_email]
    );

    let customerId   = null;
    let prevPoints   = 0;

    if (customerResult.rows.length > 0) {
      customerId = customerResult.rows[0].id;
      prevPoints = parseFloat(customerResult.rows[0].loyalty_points) || 0;
    } else {
      // First-time registration — customer_name required
      if (!customer_name || !customer_name.trim()) {
        return _validationError(res, 218, "Customer name is required for first-time loyalty registration.");
      }

      const newCustomer = await pool.query(
        `INSERT INTO loyalty_customers (name, mobile, email, loyalty_points)
         VALUES ($1, $2, $3, 0)
         RETURNING id, loyalty_points`,
        [customer_name.trim(), customer_mobile, customer_email]
      );

      customerId = newCustomer.rows[0].id;
      prevPoints = 0;
    }

    // ── 5. Calculate points (1 point per 100 LKR — adjust as needed) ─────
    const POINTS_PER_100 = 1;
    const pointsEarned   = Math.floor(parsedOrderValue / 100) * POINTS_PER_100;
    const newPoints      = prevPoints + pointsEarned;

    // ── 6. Update customer balance ────────────────────────────────────────
    await pool.query(
      `UPDATE loyalty_customers
       SET loyalty_points = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [newPoints, customerId]
    );

    // ── 7. Insert log ─────────────────────────────────────────────────────
    await _insertLog({
      client_id,
      customer_id: customerId,
      order_id,
      order_value: parsedOrderValue,
      customer_mobile,
      customer_email,
      action: ACTION_MAP["AWARD"],   // → 1
      prev_points: prevPoints,
      adjust_points: pointsEarned,
      new_points: newPoints,
      status_code: 201,
      message: "Loyalty points awarded successfully.",
      req,
    });

    return res.status(200).json({
      status:        201,
      order_id:      order_id,
      points_earned: pointsEarned,
      total_points:  newPoints,
    });

  } catch (err) {
    console.error("[loyaltyPointRequest]", err);
    return res.status(500).json({ status: 500, message: "Internal server error. Please try again later." });
  }
};

// ── Private helper: insert an API log row ─────────────────────────────────────
async function _insertLog({
  client_id,
  customer_id     = null,
  order_id        = null,   // ✏️ CHANGED: was order_no
  order_value     = null,
  customer_mobile = null,
  customer_email  = null,
  action,
  prev_points     = null,
  adjust_points   = null,
  new_points      = null,
  status_code,
  message,
  req,
}) {
  try {
    await pool.query(
      `INSERT INTO api_logs
       (client_id, customer_id, customer_mobile, customer_email,
        order_id, order_value, action,
        prev_points, adjust_points, new_points,
        status_code, message, request_body)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      // ✏️ CHANGED: 14 params → 13 params (order_no removed)
      [
        client_id, customer_id, customer_mobile, customer_email,
        order_id, order_value, action,
        prev_points, adjust_points, new_points,
        status_code, message,
        req?.body ? JSON.stringify(req.body) : null,
      ]
    );
  } catch (logErr) {
    console.error("[_insertLog]", logErr);
  }
}


// ── Private helper: validation error response ─────────────────────────────────
function _validationError(res, code, message) {
  return res.status(200).json({ status: code, message });
}

const insertPointLog = async ({
  customer_id,
  comment,
  prev_amount,
  adjust_amount,
  new_amount
}) => {
  try {
    await pool.query(
      `
      INSERT INTO points_logs
      (
        comment,
        prev_amount,
        adjust_amount,
        new_amount,
        customer_id
      )
      VALUES ($1,$2,$3,$4,$5)
      `,
      [
        comment,
        prev_amount,
        adjust_amount,
        new_amount,
        customer_id
      ]
    );
  } catch (err) {
    console.error("[insertPointLog]", err);
  }
};
// const checkCustomerByEmailOrMobile = async (req, res) => {
//   try {
//     const { email, mobile_number , loyalty_point } = req.body;

//     // Validation
//     if (!email && !mobile_number) {
//       return res.status(400).json({
//         success: false,
//         message: "Please provide email or mobile_number.",
//       });
//     }

//     let query = `
//       SELECT loyalty_point, customer_id, first_name, last_name, email,
//              contact_number_1, contact_number_2, status, created_at
//       FROM customer
//       WHERE
//     `;

//     let conditions = [];
//     let values = [];

//     // If email passed
//     if (email) {
//       values.push(email);
//       conditions.push(`email = $${values.length}`);
//     }

//     // If mobile passed
//     if (mobile_number) {
//       values.push(mobile_number);
//       conditions.push(`
//         (
//           contact_number_1 = $${values.length}
//           OR contact_number_2 = $${values.length}
//         )
//       `);
//     }

//     // OR condition = any one match
//     query += conditions.join(" OR ");
//     query += " LIMIT 1";

//     const { rows } = await pool.query(query, values);

//     // User not found
//     if (rows.length === 0) {
//       return res.status(404).json({
//         success: false,
//         message: "User not found.",
//         Action: "2",
//       });
//     }

//     // User found
//     return res.status(200).json({
//       success: true,
//       message: "User found successfully.",
//       Action: "1",
//       data: rows[0],
//     });

//   } catch (err) {
//     console.error("[checkCustomerByEmailOrMobile]", err);
//     return res.status(500).json({
//       success: false,
//       message: "Internal server error.",
//     });
//   }
// };

// ── MAIN: Customer Loyalty Actions ────────────────────────────────────────────
const checkCustomerByEmailOrMobile = async (req, res) => {
  try {
    const {
      client_id,
      api_key,
      email,
      mobile_number,
      first_name,
      last_name,
      order_id,    
      order_value,
      redeem_points, 
      action: rawAction,
    } = req.body;

    // ── Normalize mobile early ────────────────────────────────────────────
    const normalizedMobile = mobile_number ? normalizePhoneNumber(mobile_number) : null;

    const action = typeof rawAction === 'number'
      ? ACTION_REVERSE_MAP[rawAction]
      : typeof rawAction === 'string' && /^\d+$/.test(rawAction.trim())
        ? ACTION_REVERSE_MAP[parseInt(rawAction.trim(), 10)]
        : rawAction?.toString().toUpperCase();

    /* ---------------------------------------------------
       1. AUTH CHECK
    --------------------------------------------------- */

    if (!client_id || !api_key) {
      return res.status(400).json({ success: false, code: 400, label: "Bad Request", message: "client_id and api_key are required." });
    }

    const docResult = await pool.query(
      `SELECT id, is_active FROM apidocuments WHERE client_id = $1 AND api_key = $2`,
      [client_id, api_key]
    );

    if (docResult.rows.length === 0) {
      return res.status(401).json({ success: false, code: 401, label: "Unauthorized", message: "Invalid client_id or api_key." });
    }

    if (!docResult.rows[0].is_active) {
      return res.status(403).json({ success: false, code: 403, label: "Forbidden", message: "API access is not activated for this account." });
    }

    /* ---------------------------------------------------
       2. FETCH LOYALTY SETTINGS FROM system_settings
    --------------------------------------------------- */

    const settingsResult = await pool.query(
      `SELECT loyalty_point, points_given, amount_spend FROM system_settings LIMIT 1`
    );

    const settings = settingsResult.rows[0] || {};
    const loyaltyEnabled = settings.loyalty_point === true;
    const pointsGiven = parseFloat(settings.points_given) || 0;
    const amountSpend = parseFloat(settings.amount_spend) || 0;

    // Helper: calculate points from an order value using system settings
    const calcPoints = (value) => {
      if (!loyaltyEnabled || amountSpend <= 0 || pointsGiven <= 0) return 0;
      return Math.floor((value / amountSpend) * pointsGiven);
    };


    /* ---------------------------------------------------
       VALIDATIONS
    --------------------------------------------------- */

      if (!email && !normalizedMobile) {
      return res.status(400).json({
        success: false, code: 400, label: "Bad Request",
        message: "Please provide email or mobile_number.",
      });
    }

    if (mobile_number === "") {
      return res.status(400).json({
        success: false, code: 214, label: "Mobile Required",
        message: "Customer mobile number is required.",
      });
    }

    if (normalizedMobile && !/^[0-9]{10,15}$/.test(normalizedMobile)) {
      return res.status(400).json({
        success: false, code: 215, label: "Invalid Mobile",
        message: "Invalid mobile number format.",
      });
    }

    if (email === "") {
      return res.status(400).json({
        success: false, code: 216, label: "Email Required",
        message: "Customer email is required.",
      });
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        success: false, code: 217, label: "Invalid Email",
        message: "Invalid email address.",
      });
    }

    /* ---------------------------------------------------
       FIND CUSTOMER
    --------------------------------------------------- */

    let query = `
  SELECT
    customer_id,
    first_name,
    last_name,
    email,
    contact_number_1,
    contact_number_2,
    status,
    loyalty_point,
    loyality_number
  FROM customer
  WHERE
`;

    let conditions = [];
    let values = [];

    if (email) {
    values.push(email);
    conditions.push(`email = $${values.length}`);
    }

    if (mobile_number) {
    const normalized = normalizePhoneNumber(mobile_number);  // always 94XXXXXXXXX

    // Generate all 3 variants to match whatever format is stored in DB
    const variant94 = normalized;                            // 94XXXXXXXXX
    const variant07 = '0' + normalized.slice(2);            // 07XXXXXXXX
    const variant7  = normalized.slice(2);                  // 7XXXXXXXX

    values.push(variant94, variant07, variant7);
    const p = values.length;
    conditions.push(`
        (
        contact_number_1 IN ($${p - 2}, $${p - 1}, $${p})
        OR contact_number_2 IN ($${p - 2}, $${p - 1}, $${p})
        )
    `);
    }

    query += conditions.join(" OR ");
    query += " ORDER BY customer_id DESC LIMIT 1"; 

    const { rows } = await pool.query(query, values);

    /* ---------------------------------------------------
       CUSTOMER NOT FOUND => AUTO REGISTER
    --------------------------------------------------- */

    if (rows.length === 0) {
      if (!first_name) {
        return res.status(400).json({
          success: false,
          code: 218,
          label: "Customer Name Required",
          message: "First name required for new registration.",
        });
      }

      const insert = await pool.query(
        `INSERT INTO customer
          (first_name, last_name, email, contact_number_1, loyalty_point, status)
         VALUES ($1, $2, $3, $4, 0, 'active')
         RETURNING *`,
        [first_name, last_name || "", email || null, normalizedMobile || null]  // ← normalizedMobile
      );


            await insertPointLog({
            customer_id: insert.rows[0].customer_id,
            comment: "Customer Registered",
            prev_amount: 0,
            adjust_amount: 0,
            new_amount: 0
            });

      return res.status(201).json({
        success: true,
        code: 201,
        label: "Points Awarded",
        message: "New customer created successfully.",
        data: insert.rows[0],
      });
    }

    const customer = rows[0];

    /* ---------------------------------------------------
      CHECK STATUS (ACTIVE / INACTIVE)
    --------------------------------------------------- */

    if (customer.status !== "active") {
      return res.status(403).json({
        success: false,
        code: 221,
        label: "Account Inactive",
        message: "Customer is in inactive status.",
      });
    }

    /* ---------------------------------------------------
      ACTION 1: CHECK CUSTOMER + BALANCE
    --------------------------------------------------- */

    if (action === "CHECK") {
        await _insertLog({
            client_id,
            customer_id:     customer.customer_id,
            order_id:        order_id       || null,
            order_value:     order_value ? parseFloat(order_value) : null,
            customer_mobile: normalizedMobile,
            customer_email:  email          || null,
            action:          ACTION_MAP[action],
            prev_points:     customer.loyalty_point,
            adjust_points:   0,
            new_points:      customer.loyalty_point,
            status_code:     200,
            message:         `Customer found successfully. Total loyalty point balance: ${customer.loyalty_point}.`,
            req,
        });

        return res.status(200).json({
            success: true, code: 200, label: "OK",
            message: `Customer found successfully. Total loyalty point balance: ${customer.loyalty_point}.`,
            data: customer,
            loyalty_point: customer.loyalty_point,
        });
        }

     /* ---------------------------------------------------
      ACTION 2: BALANCE ONLY
    --------------------------------------------------- */

    if (action === "BALANCE") {
        await _insertLog({
            client_id,
            customer_id:     customer.customer_id,
            order_id:        order_id       || null,
            order_value:     order_value ? parseFloat(order_value) : null,
            customer_mobile: normalizedMobile,
            customer_email:  email          || null,
            action:          ACTION_MAP[action],
            prev_points:     customer.loyalty_point,
            adjust_points:   0,
            new_points:      customer.loyalty_point,
            status_code:     204,
            message:         `Customer balance retrieved successfully. Total loyalty point balance: ${customer.loyalty_point}.`,
            req,
        });

        return res.status(200).json({
            success: true, code: 204, label: "Balance Retrieved",
            message: `Customer balance retrieved successfully. Total loyalty point balance: ${customer.loyalty_point}.`,
            loyalty_point: customer.loyalty_point,
        });
        }

    /* ---------------------------------------------------
      ACTION 3: AWARD POINTS (ORDER COMPLETED)
    --------------------------------------------------- */

   if (action === "AWARD") {
      let earnedPoints = 0;

      if (order_value !== undefined && order_value !== null && order_value !== "") {
        const parsedValue = parseFloat(order_value);

        if (isNaN(parsedValue) || parsedValue <= 0) {
          return res.status(400).json({ 
            success: false, code: 210, 
            label: "Invalid Order Value", 
            message: "Order value must be a positive number greater than 0." });
        }

        if (order_id) {
          const dupCheck = await pool.query(
            `SELECT id FROM api_logs WHERE client_id = $1 AND order_id = $2 AND status_code = 201`,
            [client_id, order_id]
          );

          if (dupCheck.rows.length > 0) {
            return res.status(200).json({ 
                success: false, 
                code: 211, label: "Duplicate Order", 
                message: "Loyalty points have already been awarded for this order_id." });
          }
        }

         // ✅ Dynamic formula: floor((order_value / amount_spend) * points_given)
        earnedPoints = calcPoints(parsedValue);
      }

      const update = await pool.query(
        `UPDATE customer SET loyalty_point = loyalty_point + $1 WHERE customer_id = $2
        RETURNING
            customer_id,
            first_name,
            last_name,
            email,
            contact_number_1,
            contact_number_2,
            status,
            loyalty_point,
            loyality_number`,
        [earnedPoints, customer.customer_id]
        );

      await insertPointLog({
        customer_id: customer.customer_id,
        comment: `Points Awarded`,
        prev_amount: customer.loyalty_point,
        adjust_amount: earnedPoints,
        new_amount: update.rows[0].loyalty_point
        });
            
      await _insertLog({
        client_id,
        customer_id:     customer.customer_id,
        order_id:        order_id    || null,  
        order_value:     order_value ? parseFloat(order_value) : null,
        customer_mobile: normalizedMobile,
        customer_email:  email         || null,
        action: ACTION_MAP[action],   // "AWARD" → 1
        prev_points:     customer.loyalty_point,
        adjust_points:   earnedPoints,
        new_points:      update.rows[0].loyalty_point,
        status_code:     201,
        message: `${earnedPoints} loyalty points awarded successfully. Total points: ${update.rows[0].loyalty_point}.`,
        req,
      });


      return res.status(201).json({
        success: true, code: 201, label: "Points Awarded",
        message: `${earnedPoints} loyalty points awarded successfully. Total points: ${update.rows[0].loyalty_point}.`,
        points_added: earnedPoints,
        total_points: update.rows[0].loyalty_point,
        data: update.rows[0],
      });
    }

     /* ---------------------------------------------------
      ACTION 4: REDEEM POINTS
    --------------------------------------------------- */

      if (action === "REDEEM") {
      const redeem = Number(redeem_points || 0);  

      if (redeem <= 0) {
        return res.status(400).json({ 
            success: false, code: 210, 
            label: "Invalid Value", 
            message: "Redeem points must be greater than 0." });
      }

      if (customer.loyalty_point <= 0) {
        return res.status(400).json({ 
            success: false, 
            code: 212, 
            label: "Insufficient Points", 
            message: "No loyalty points available." });
      }

      if (customer.loyalty_point < redeem) {
        return res.status(400).json({ success: false, code: 212, label: "Insufficient Points", message: "Not enough loyalty points to redeem." });
      }

      const update = await pool.query(
        `UPDATE customer SET loyalty_point = loyalty_point - $1 WHERE customer_id = $2 
         RETURNING
            customer_id,
            first_name,
            last_name,
            email,
            contact_number_1,
            contact_number_2,
            status,
            loyalty_point,
            loyality_number`,
        [redeem, customer.customer_id]
      );

      await insertPointLog({
        customer_id: customer.customer_id,
        comment: "Points Redeemed",
        prev_amount: customer.loyalty_point,
        adjust_amount: -redeem,
        new_amount: update.rows[0].loyalty_point
        });

      await _insertLog({
        client_id,
        customer_id:     customer.customer_id,
        order_id:        order_id      || null,
        customer_mobile: normalizedMobile,
        customer_email:  email         || null,
        action: ACTION_MAP[action],   // "REDEEM" → 2
        prev_points:     customer.loyalty_point,
        adjust_points:   -redeem,
        new_points:      update.rows[0].loyalty_point,
        status_code:     202,
        message: `${redeem} loyalty points redeemed successfully. Remaining points: ${update.rows[0].loyalty_point}.`,
        req,
      });

      return res.status(202).json({
        success: true, code: 202, label: "Points Redeemed",
        message: `${redeem} loyalty points redeemed successfully. Remaining points: ${update.rows[0].loyalty_point}.`,
        redeemed_points:  redeem,
        remaining_points: update.rows[0].loyalty_point,
        data: update.rows[0],
      });
    }


    /* ---------------------------------------------------
      ACTION 4: REVERSE POINTS
    --------------------------------------------------- */
if (action === "REVERSE") {

  if (!order_id || !order_value) {
    return res.status(400).json({
      success: false,
      code: 210,
      label: "Missing Required Fields",
      message: "Both order_id and order_value are required for reversal."
    });
  }

  const reverseValue = parseFloat(order_value);

  if (isNaN(reverseValue) || reverseValue <= 0) {
    return res.status(400).json({
      success: false,
      code: 210,
      label: "Invalid Order Value",
      message: "Reverse amount must be a positive number greater than 0."
    });
  }

       // ✅ Dynamic formula: floor((order_value / amount_spend) * points_given)
      const reversedPoints = calcPoints(reverseValue);

      if (reversedPoints <= 0) {
        return res.status(400).json({ 
            success: false, 
            code: 223, 
            label: "Non-Reversible Order", 
            message: "No points available to reverse for this order value." });
      }

      const update = await pool.query(
        `UPDATE customer SET loyalty_point = loyalty_point + $1 WHERE customer_id = $2 
         RETURNING
            customer_id,
            first_name,
            last_name,
            email,
            contact_number_1,
            contact_number_2,
            status,
            loyalty_point,
            loyality_number`,
        [reversedPoints, customer.customer_id]
      );

      await insertPointLog({
        customer_id: customer.customer_id,
        comment: "Points Reversed",
        prev_amount: customer.loyalty_point,
        adjust_amount: reversedPoints,
        new_amount: update.rows[0].loyalty_point
        });
            
      await _insertLog({
        client_id,
        customer_id:     customer.customer_id,
        order_id:        order_id      || null,  // ✏️ CHANGED: optional reference, was order_no
        order_value:     reverseValue,
        customer_mobile: normalizedMobile,
        customer_email:  email         || null,
        action: ACTION_MAP[action],   // "REVERSE" → 4
        prev_points:     customer.loyalty_point,
        adjust_points:   reversedPoints,
        new_points:      update.rows[0].loyalty_point,
        status_code:     203,
        message: `${reversedPoints} loyalty points reversed successfully. Total points: ${update.rows[0].loyalty_point}.`,
        req,
      });

      return res.status(203).json({
        success: true, code: 203, label: "Points Reversed",
        message: `${reversedPoints} loyalty points reversed successfully. Total points: ${update.rows[0].loyalty_point}.`,
        reversed_points: reversedPoints,
        total_points:    update.rows[0].loyalty_point,
        data:            update.rows[0],
      });
    }


    /* ---------------------------------------------------
       DEFAULT : USER FOUND
    --------------------------------------------------- */

    return res.status(200).json({
      success: true,
      code: 200,
      label: "OK",
      message: "User found successfully.",
      data: customer,
    });

  } catch (err) {
    console.error("[checkCustomerByEmailOrMobile]", err);

    return res.status(500).json({
      success: false,
      code: 500,
      label: "Server Error",
      message: "Internal server error.",
    });
  }
};

const getApiDetails = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT 
          id,
          client_id,
          api_key,
          is_active,
          created_at,
          updated_at
       FROM apidocuments
       ORDER BY id ASC`
    );

    return res.status(200).json({
      success: true,
      data: rows
    });

  } catch (err) {
    console.error('[getApiDetails]', err);
    return res.status(500).json({
      success: false,
      message: 'Internal server error.'
    });
  }
};


module.exports = {
  toggleApiStatus,
  regenerateApiKey,
  updateClientId,
  getApiLogs,
  loyaltyPointRequest,
  checkCustomerByEmailOrMobile,
  getApiDetails
};