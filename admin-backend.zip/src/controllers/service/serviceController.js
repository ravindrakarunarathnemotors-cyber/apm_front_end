const pool = require("../../config/db");
const { insertJobLog } = require("../../models/userLogs");;
const { customhookJob } = require("../../models/jobnotificationmodel");
const { customhookInvoice, customhookQuotation } = require("../../models/smsnotificationmodel");

// SEARCH PRODUCTS  (used by the CreateJob search bar)

const searchProducts = async (req, res) => {
  console.log('[Backend] searchProducts hit')
  console.log('[Backend] keyword:', req.query.keyword)
  const { keyword } = req.query;

  try {
    if (!keyword || String(keyword).trim().length < 2) {
      return res.status(400).json({ message: "keyword must be at least 2 characters" });
    }

    const search      = `%${keyword.trim()}%`;
    const exactSearch = keyword.trim();

    const result = await pool.query(
      `SELECT
         p.product_id,
         p.title,
         p.description,
         p.status,
         p.type,
         p.vendor,
         p.price             AS base_price,
         p.default_weight,

         v.variant_id,
         v.variant_type,
         v.variant_value,
         v.sku,
         v.barcode,
         v.price             AS variant_price,
         v.cost_per_item,
         v.inventory_quantity,
         v.weight,
         v.weight_unit,
         v.status            AS variant_status

       FROM products p
       INNER JOIN product_variants v
         ON v.product_id = p.product_id
       WHERE
         p.status  = 'active'
         AND v.status = 'active'
         AND (
           p.title    ILIKE $1
           OR p.type  ILIKE $1
           OR p.vendor ILIKE $1
           OR v.sku   ILIKE $1
           OR v.barcode ILIKE $1
           OR CAST(p.product_id AS TEXT) = $2
           OR CAST(v.variant_id AS TEXT) = $2
         )
       ORDER BY p.product_id ASC, v.variant_id ASC
       LIMIT 50`,
      [search, exactSearch]
    );

    return res.status(200).json({
      message: "Products fetched successfully",
      data: result.rows,
    });

  } catch (error) {
    console.error("Search Products Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// CREATE JOB  (transaction — all-or-nothing)
// Body:
// {
//   job_name, job_description,
//   equipment : [{ equipment_name, note? }],
//   items     : [{ item_type, product_id?, item_name, quantity, unit_price }],
//   services  : [{ service_name, amount }]
// }

const createJob = async (req, res) => {
  const client = await pool.connect();

  const user_id   = req.user?.user_id  ?? 1;
  const user_name = req.user?.username ?? req.user?.first_name ?? 'Unknown';

  // ── Reusable admin log helper — same pattern as rest of your project ──────
  // Writes directly to admin_log (module, log, user_id, date) — no schema change
  const writeAdminLog = async (module, description) => {
    try {
      await pool.query(
        `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
        [module, description, user_id]
      );
    } catch (e) {
      console.error('[writeAdminLog] Failed:', e.message);
    }
  };

  // ── Builds the detailed log string packed into the `log` column ───────────
  // All detail goes here since we only have 4 columns to work with
  const buildLog = ({ status, message, fail_reason = null, details = {} }) => {
    const timestamp = new Date().toISOString();
    const lines = [
      // `[${status}] ${timestamp}`,
      // `User        : ${user_name} (user_id: ${user_id})`,
      `Action      : CREATE Job`,
      `Message     : ${message}`,
    ];
    if (fail_reason)              lines.push(`Fail Reason : ${fail_reason}`);
    if (details.job_name)         lines.push(`Job Name    : ${details.job_name}`);
    if (details.customer_id)      lines.push(`Customer ID : ${details.customer_id}`);
    if (details.job_id)           lines.push(`Job ID      : ${details.job_id}`);
    if (details.item_count !== undefined) lines.push(`Items       : ${details.item_count}`);
    if (details.service_count !== undefined) lines.push(`Services    : ${details.service_count}`);
    if (details.equipment_count !== undefined) lines.push(`Equipment   : ${details.equipment_count}`);
    if (details.grand_total !== undefined) lines.push(`Grand Total : ${details.grand_total}`);
    if (details.extra)            lines.push(`Detail      : ${details.extra}`);
    return lines.join(' | ');
  };

  try {
    const {
      job_name,
      job_description = "",
      customer_id,
      equipment = [],
      items     = [],
      services  = [],
    } = req.body;

    // ── Validation ──────────────────────────────────────────────────────────

    if (!job_name || !String(job_name).trim()) {
      await writeAdminLog(
        'Jobs | CREATE | WARNING',
        buildLog({
          status:      'WARNING',
          message:     'Job creation rejected — job_name was missing or blank',
          fail_reason: 'job_name is a required field',
        })
      );
      return res.status(400).json({ message: "job_name is required" });
    }

    for (const it of items) {
      if (!it.item_name || !String(it.item_name).trim()) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     'Job creation rejected — billing item missing name',
            fail_reason: 'item_name was blank or not provided',
            details:     { job_name },
          })
        );
        return res.status(400).json({ message: "Each item must have an item_name" });
      }

      if (it.quantity === undefined || Number(it.quantity) < 1) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     `Job creation rejected — invalid quantity for item "${it.item_name}"`,
            fail_reason: `quantity must be >= 1, received: ${it.quantity}`,
            details:     { job_name, extra: `Item: ${it.item_name}` },
          })
        );
        return res.status(400).json({ message: `Item '${it.item_name}': quantity must be >= 1` });
      }

      if (it.unit_price === undefined || isNaN(Number(it.unit_price)) || Number(it.unit_price) < 0) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     `Job creation rejected — invalid price for item "${it.item_name}"`,
            fail_reason: `unit_price must be a valid number >= 0, received: ${it.unit_price}`,
            details:     { job_name, extra: `Item: ${it.item_name}` },
          })
        );
        return res.status(400).json({ message: `Item '${it.item_name}': unit_price must be a valid number >= 0` });
      }

      const validTypes = ["PRODUCT", "CUSTOM"];
      if (!validTypes.includes((it.item_type || "").toUpperCase())) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     `Job creation rejected — invalid item_type for "${it.item_name}"`,
            fail_reason: `item_type was "${it.item_type}", must be PRODUCT or CUSTOM`,
            details:     { job_name, extra: `Item: ${it.item_name}` },
          })
        );
        return res.status(400).json({ message: `Item '${it.item_name}': item_type must be PRODUCT or CUSTOM` });
      }
    }

    for (const svc of services) {
      if (!svc.service_name || !String(svc.service_name).trim()) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     'Job creation rejected — service entry missing name',
            fail_reason: 'service_name was blank or not provided',
            details:     { job_name },
          })
        );
        return res.status(400).json({ message: "Each service must have a service_name" });
      }

      if (svc.amount === undefined || isNaN(Number(svc.amount)) || Number(svc.amount) < 0) {
        await writeAdminLog(
          'Jobs | CREATE | WARNING',
          buildLog({
            status:      'WARNING',
            message:     `Job creation rejected — invalid amount for service "${svc.service_name}"`,
            fail_reason: `amount must be >= 0, received: ${svc.amount}`,
            details:     { job_name, extra: `Service: ${svc.service_name}` },
          })
        );
        return res.status(400).json({ message: `Service '${svc.service_name}': amount must be a valid number >= 0` });
      }
    }

    // ── Database Transaction ─────────────────────────────────────────────────

    await client.query("BEGIN");

    const jobResult = await client.query(
      `INSERT INTO job (job_name, job_description, customer_id, status, created_at)
       VALUES ($1, $2, $3, 'PENDING', NOW())
       RETURNING *`,
      [job_name.trim(), job_description?.trim() || null, customer_id || null]
    );
    const job    = jobResult.rows[0];
    const job_id = job.id;

    for (const eq of equipment) {
      if (!eq.equipment_name || !String(eq.equipment_name).trim()) continue;
      await client.query(
        `INSERT INTO pick_from_client (job_id, equipment_name, serial_number, note)
         VALUES ($1, $2, $3, $4)`,
        [job_id, eq.equipment_name.trim(), eq.serial_number?.trim() || null, eq.note || null]
      );
    }

    for (const it of items) {
      const itemType   = it.item_type.toUpperCase();
      const qty        = Number(it.quantity);
      const unitPrice  = Number(it.unit_price);
      const totalPrice = parseFloat((qty * unitPrice).toFixed(2));

      let resolvedProductId = null;
      if (itemType === "PRODUCT" && it.product_id) {
        const prodCheck = await client.query(
          `SELECT product_id FROM products WHERE product_id = $1`, [it.product_id]
        );
        if (prodCheck.rows.length === 0) {
          await client.query("ROLLBACK");
          await writeAdminLog(
            'Jobs | CREATE | ERROR',
            buildLog({
              status:      'ERROR',
              message:     `Job creation rolled back — product not found in database`,
              fail_reason: `product_id ${it.product_id} does not exist in products table`,
              details:     { job_name, customer_id, extra: `Item: ${it.item_name}, product_id: ${it.product_id}` },
            })
          );
          return res.status(404).json({ message: `Product with id ${it.product_id} not found` });
        }
        resolvedProductId = it.product_id;
      }

      await client.query(
        `INSERT INTO job_bill_item
           (job_id, item_type, product_id, item_name, quantity, unit_price, total_price)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [job_id, itemType, resolvedProductId, it.item_name.trim(), qty, unitPrice, totalPrice]
      );
    }

    for (const svc of services) {
      await client.query(
        `INSERT INTO job_other_service (job_id, service_name, amount)
         VALUES ($1, $2, $3)`,
        [job_id, svc.service_name.trim(), Number(svc.amount)]
      );
    }

    await client.query("COMMIT");

    // ── Calculate grand total for the success log ────────────────────────────
    const grandTotal = parseFloat((
      items.reduce((s, i) => s + Number(i.unit_price) * Number(i.quantity), 0) +
      services.reduce((s, sv) => s + Number(sv.amount), 0)
    ).toFixed(2));

    // ── SUCCESS admin log ────────────────────────────────────────────────────
    await writeAdminLog(
      'Jobs | CREATE | INFO',
      buildLog({
        status:  'INFO',
        message: `Job created successfully by ${user_name}`,
        details: {
          job_id,
          job_name:        job_name.trim(),
          customer_id:     customer_id || null,
          item_count:      items.length,
          service_count:   services.length,
          equipment_count: equipment.length,
          grand_total:     grandTotal,
        },
      })
    );

    // ── Notifications ────────────────────────────────────────────────────────
    try {
      let customerName = '', customerPhone = '', customerEmail = '';
      if (customer_id) {
        const custRes = await pool.query(
          `SELECT first_name || ' ' || last_name AS name,
                  contact_number_1 AS phone, email
           FROM customer WHERE customer_id = $1`,
          [customer_id]
        );
        if (custRes.rows.length > 0) {
          customerName  = custRes.rows[0].name  || '';
          customerPhone = custRes.rows[0].phone || '';
          customerEmail = custRes.rows[0].email || '';
        }
      }
      await customhookJob(
        13, job_id, job.job_name, job.job_description || '',
        new Date().toLocaleDateString('en-GB'),
        customerName, customerPhone, customerEmail
      );
    } catch (notifErr) {
      console.warn('[createJob] Notification skipped:', notifErr.message);
    }

    await insertJobLog(job_id, "JOB_CREATE", `New job created: ${job_name}`, null, user_id);

    return res.status(201).json({ message: "Job created successfully", job_id, data: job });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create Job Error:", error);

    // ── CRITICAL unexpected error log ────────────────────────────────────────
    try {
      await pool.query(
        `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
        [
          'Jobs | CREATE | CRITICAL',
          [
            `[CRITICAL] ${new Date().toISOString()}`,
            `User        : ${user_name} (user_id: ${user_id})`,
            `Action      : CREATE Job`,
            `Message     : Unexpected server error during job creation — transaction rolled back`,
            `Fail Reason : ${error?.message || 'Unknown error'}`,
            `Job Name    : ${req.body?.job_name || '(unknown)'}`,
            `Customer ID : ${req.body?.customer_id || 'none'}`,
          ].join('\n'),
          user_id,
        ]
      );
    } catch (logErr) {
      console.error('[createJob] Could not write CRITICAL log:', logErr.message);
    }

    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};

// GET ALL JOBS  

const getAllJobs = async (req, res) => {
  try {
    const { keyword, status, from_date, to_date } = req.query;
    const queryParams = [];
    const whereConditions = [];

    if (keyword) {
      const trimmed = keyword.trim();
      if (/^\d+$/.test(trimmed)) {
        queryParams.push(trimmed);
        whereConditions.push(`j.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmed}%`);
        whereConditions.push(`j.job_name ILIKE $${queryParams.length}`);
      }
    }
    if (from_date && to_date) {
      queryParams.push(from_date, to_date);
      whereConditions.push(`j.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`);
    }
    if (status) {
      queryParams.push(status.toUpperCase());
      whereConditions.push(`j.status = $${queryParams.length}`);
    }

    whereConditions.push(`j.status != 'DELETED'`);
    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(' AND ')}` : '';

    const result = await pool.query(`
      SELECT
        j.id,
        j.job_name,
        j.job_description,
        j.status,
        j.hold_reason,
        j.assigned_users,
        j.created_at,
         j.admin_note,
        -- Customer full name
        CASE 
          WHEN c.customer_id IS NOT NULL 
          THEN c.first_name || ' ' || c.last_name 
          ELSE NULL 
        END AS customer_name,
        c.contact_number_1  AS customer_phone,
        c.email             AS customer_email,
        j.customer_id,
        j.invoice_id,
        COUNT(DISTINCT pfc.id)    AS equipment_count,
        COUNT(DISTINCT jbi.id)    AS item_count,
        COUNT(DISTINCT jos.id)    AS service_count,
        COALESCE(SUM(jbi.total_price), 0)                                  AS total_items_amount,
        COALESCE(SUM(jos.amount), 0)                                       AS total_service_amount,
        COALESCE(SUM(jbi.total_price), 0) + COALESCE(SUM(jos.amount), 0)  AS grand_total
      FROM job j
      LEFT JOIN customer          c   ON c.customer_id = j.customer_id
      LEFT JOIN pick_from_client  pfc ON pfc.job_id = j.id
      LEFT JOIN job_bill_item     jbi ON jbi.job_id = j.id
      LEFT JOIN job_other_service jos ON jos.job_id = j.id
      ${whereClause}
      GROUP BY j.id, j.admin_note, c.customer_id, c.first_name, c.last_name, c.contact_number_1, c.email
      ORDER BY j.created_at DESC
    `, queryParams);

    return res.status(200).json({ message: "Jobs fetched successfully", data: result.rows });
  } catch (error) {
    console.error("Get All Jobs Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// GET JOB BY ID  (full detail — header + equipment + items w/ product info + services)


const getJobById = async (req, res) => {
  const { id } = req.params;

  try {
    // Job header
    const jobResult = await pool.query(
      `SELECT * FROM job WHERE id = $1`,
      [id]
    );

    if (jobResult.rows.length === 0) {
      return res.status(404).json({ message: "Job not found" });
    }

    // Equipment
    const equipmentResult = await pool.query(
      `SELECT * FROM pick_from_client WHERE job_id = $1 ORDER BY id ASC`,
      [id]
    );
    const itemsResult = await pool.query(
      `SELECT
         jbi.id,
         jbi.job_id,
         jbi.item_type,
         jbi.product_id,
         jbi.item_name,
         jbi.quantity,
         jbi.unit_price,
         jbi.total_price,

         p.title             AS product_title,
         p.type              AS product_type,
         p.vendor            AS product_vendor,
         p.status            AS product_status,

         v.variant_id,
         v.variant_value,
         v.sku,
         v.weight,
         v.weight_unit,
         v.inventory_quantity

       FROM job_bill_item jbi

       LEFT JOIN products p
         ON p.product_id = jbi.product_id

       LEFT JOIN LATERAL (
         SELECT variant_id, variant_value, sku, weight, weight_unit, inventory_quantity
         FROM product_variants
         WHERE product_id = jbi.product_id
           AND status = 'active'
         ORDER BY variant_id ASC
         LIMIT 1
       ) v ON true

       WHERE jbi.job_id = $1
       ORDER BY jbi.id ASC`,
      [id]
    );

    // Services
    const servicesResult = await pool.query(
      `SELECT * FROM job_other_service WHERE job_id = $1 ORDER BY id ASC`,
      [id]
    );

    const totalItemsAmount   = itemsResult.rows.reduce((s, r) => s + Number(r.total_price || 0), 0);
    const totalServiceAmount = servicesResult.rows.reduce((s, r) => s + Number(r.amount || 0), 0);

    let customerData = null;
    if (jobResult.rows[0].customer_id) {
      const custResult = await pool.query(
        `SELECT customer_id, first_name, last_name, email, contact_number_1 AS phone, address
         FROM customer WHERE customer_id = $1`,
        [jobResult.rows[0].customer_id]
      );
      if (custResult.rows.length > 0) {
        const c = custResult.rows[0];
        customerData = {
          ...c,
          name: `${c.first_name} ${c.last_name}`.trim(),
        };
      }
    }

    return res.status(200).json({
      ...jobResult.rows[0],
      customer:             customerData,
      equipment:            equipmentResult.rows,
      items:                itemsResult.rows,
      services:             servicesResult.rows,
      total_items_amount:   parseFloat(totalItemsAmount.toFixed(2)),
      total_service_amount: parseFloat(totalServiceAmount.toFixed(2)),
      grand_total:          parseFloat((totalItemsAmount + totalServiceAmount).toFixed(2)),
    });

  } catch (error) {
    console.error("Get Job By ID Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// UPDATE JOB STATUS

const updateJobStatus = async (req, res) => {
  const { id } = req.params;
  const { status, hold_reason } = req.body;
  const user_id = req.user?.user_id ?? null;
  const validStatuses = ["PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED", "ON_HOLD"];

  try {
    if (!status || !validStatuses.includes(status.toUpperCase())) {
      return res.status(400).json({ message: `Allowed statuses: ${validStatuses.join(", ")}` });
    }
    if (status.toUpperCase() === 'ON_HOLD' && !hold_reason?.trim()) {
      return res.status(400).json({ message: "hold_reason is required for ON_HOLD" });
    }

    const result = await pool.query(
      `UPDATE job
      SET status      = $1::varchar,
          hold_reason = CASE WHEN $1::varchar = 'ON_HOLD' THEN $2 ELSE hold_reason END
      WHERE id = $3
      RETURNING *`,
      [status.toUpperCase(), hold_reason?.trim() || null, id]
    );

    if (result.rows.length === 0) return res.status(404).json({ message: "Job not found" });

    const { id: job_id, job_name } = result.rows[0];

    await insertJobLog(
      job_id,
      "JOB_Update",
      `Job Has been Updated : ${job_name}`,
      null,      
      user_id    
    );


    return res.status(200).json({ message: `Status updated to ${status.toUpperCase()}`, data: result.rows[0] });
  } catch (error) {
    console.error("Update Job Status Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// DELETE JOB 

const deleteJob = async (req, res) => {
  const { id } = req.params;
  const user_id = req.user?.user_id ?? null;
  try {
    const result = await pool.query(
      `UPDATE job SET status = 'DELETED', deleted_at = NOW()
       WHERE id = $1 AND status != 'DELETED'
       RETURNING id, job_name`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Job not found or already deleted" });
    }
    const { id: job_id, job_name } = result.rows[0];
    await insertJobLog(job_id, "JOB_DELETE", `Job deleted: ${job_name}`, null, user_id);

    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [
        'Jobs | DELETE | INFO',
        `[INFO] Job deleted | Job ID: ${job_id} | Job: ${job_name}`,
        user_id,
      ]
    );

    return res.status(200).json({ message: "Job deleted successfully", data: result.rows[0] });
  } catch (error) {
    console.error("Delete Job Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const getDeletedJobs = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        j.id, j.job_name, j.job_description, j.status, j.hold_reason,
        j.assigned_users, j.created_at, j.deleted_at,
        CASE WHEN c.customer_id IS NOT NULL THEN c.first_name || ' ' || c.last_name ELSE NULL END AS customer_name,
        c.contact_number_1 AS customer_phone,
        COALESCE(SUM(jbi.total_price), 0) + COALESCE(SUM(jos.amount), 0) AS grand_total
      FROM job j
      LEFT JOIN customer c ON c.customer_id = j.customer_id
      LEFT JOIN job_bill_item jbi ON jbi.job_id = j.id
      LEFT JOIN job_other_service jos ON jos.job_id = j.id
      WHERE j.status = 'DELETED'
      GROUP BY j.id, c.customer_id, c.first_name, c.last_name, c.contact_number_1
      ORDER BY j.deleted_at DESC
    `);
    return res.status(200).json({ message: "Deleted jobs fetched", data: result.rows });
  } catch (error) {
    console.error("Get Deleted Jobs Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// SEARCH CUSTOMERS  

const searchCustomers = async (req, res) => {
  const { keyword } = req.query;
  try {
    if (!keyword || String(keyword).trim().length < 2) {
      return res.status(400).json({ message: "keyword must be at least 2 characters" });
    }
    const search = `%${keyword.trim()}%`;
    const result = await pool.query(
      `SELECT 
         customer_id,
         customer_id                              AS id,   
         first_name || ' ' || last_name           AS name,
         email,
         contact_number_1                         AS phone,
         address
       FROM customer
       WHERE first_name       ILIKE $1
          OR last_name        ILIKE $1
          OR email            ILIKE $1
          OR contact_number_1 ILIKE $1
       ORDER BY first_name ASC
       LIMIT 30`,
      [search]
    );
    return res.status(200).json({ message: "Customers fetched", data: result.rows });
  } catch (error) {
    console.error("Search Customers Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// CREATE CUSTOMER
const createCustomer = async (req, res) => {
  const { name, email, phone, address } = req.body;
  try {
    if (!name || !String(name).trim()) {
      return res.status(400).json({ message: "Customer name is required" });
    }
    const result = await pool.query(
      `INSERT INTO customer (first_name, last_name, email, contact_number_1, address, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      RETURNING 
        customer_id,
        customer_id  AS id,       
        first_name,
        last_name,
        email,
        contact_number_1 AS phone,
        address`,
      [
        name.trim().split(" ")[0] || "",                  // first_name
        name.trim().split(" ").slice(1).join(" ") || "", // last_name
        email?.trim() || null,
        phone?.trim() || null,
        address?.trim() || null
      ]
    );
    return res.status(201).json({ message: "Customer created", data: result.rows[0] });
  } catch (error) {
    console.error("Create Customer Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// SEARCH USERS

const searchUsers = async (req, res) => {
  const { keyword } = req.query;
  try {
    const search = keyword?.trim().length > 0 ? `%${keyword.trim()}%` : '%';
    const result = await pool.query(
      `SELECT 
         u.user_id                            AS id,
         u.first_name || ' ' || u.last_name   AS name,
         u.email,
         u.username,
         u.mobile,
         COALESCE(rl.role_name, 'No Role')    AS role
       FROM users u
       LEFT JOIN role_list rl ON rl.user_id = u.user_id
       WHERE (
         u.first_name ILIKE $1
         OR u.last_name  ILIKE $1
         OR u.username   ILIKE $1
         OR u.email      ILIKE $1
       )
       AND u.status = 'Active'
       ORDER BY u.first_name ASC 
       LIMIT 30`,
      [search]
    );
    return res.status(200).json({ message: "Users fetched", data: result.rows });
  } catch (error) {
    console.error("Search Users Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// ASSIGN USERS — saves user objects [{id, name, role}] into job.assigned_users

const assignUsersToJob = async (req, res) => {
  const { id } = req.params;
  const { users = [] } = req.body;
  const user_id = req.user?.user_id ?? null;
  try {
    const result = await pool.query(
      `UPDATE job SET assigned_users = $1 WHERE id = $2 RETURNING *`,
      [JSON.stringify(users), id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: "Job not found" });

    await insertJobLog(
      id,
      "NEW_USER_ASSIGNMENT",
      `New user(s) assigned to job`,
      null,      
      user_id    
    );

    const assignedNames = users.map(u => u.name).join(', ') || 'None';
    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [
        'Jobs | ASSIGN_USERS | INFO',
        `[INFO] Users assigned to job | Job ID: ${id} | Assigned: ${assignedNames}`,
        user_id,
      ]
    );

    return res.status(200).json({ message: "Users assigned", data: result.rows[0] });
  } catch (error) {
    console.error("Assign Users Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// UPDATE FULL JOB (equipment + items + services — full replace)

const updateJob = async (req, res) => {
  const { id } = req.params;
  const client = await pool.connect();
  const user_id = req.user?.user_id ?? null;
  try {
    const { job_name, job_description, equipment = [], items = [], services = [] } = req.body;

    await client.query("BEGIN");

    await client.query(
      `UPDATE job SET job_name=$1, job_description=$2 WHERE id=$3`,
      [job_name?.trim(), job_description?.trim() || null, id]
    );

    // Replace equipment
    await client.query(`DELETE FROM pick_from_client WHERE job_id=$1`, [id]);
    for (const eq of equipment) {
      if (!eq.equipment_name?.trim()) continue;
      await client.query(
        `INSERT INTO pick_from_client (job_id, equipment_name, serial_number, note)
         VALUES ($1,$2,$3,$4)`,
        [id, eq.equipment_name.trim(), eq.serial_number?.trim() || null, eq.note || null]
      );
    }

    // Replace items
    await client.query(`DELETE FROM job_bill_item WHERE job_id=$1`, [id]);
    for (const it of items) {
      const itemType  = (it.item_type || 'CUSTOM').toUpperCase();
      const qty       = Number(it.quantity);
      const unitPrice = Number(it.unit_price);
      const total     = parseFloat((qty * unitPrice).toFixed(2));
      let   productId = null;
      if (itemType === 'PRODUCT' && it.product_id) {
        const chk = await client.query(`SELECT product_id FROM products WHERE product_id=$1`, [it.product_id]);
        if (chk.rows.length > 0) productId = it.product_id;
      }
      await client.query(
        `INSERT INTO job_bill_item (job_id,item_type,product_id,item_name,quantity,unit_price,total_price)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [id, itemType, productId, it.item_name.trim(), qty, unitPrice, total]
      );
    }

    // Replace services
    await client.query(`DELETE FROM job_other_service WHERE job_id=$1`, [id]);
    for (const svc of services) {
      if (!svc.service_name?.trim()) continue;
      await client.query(
        `INSERT INTO job_other_service (job_id, service_name, amount) VALUES ($1,$2,$3)`,
        [id, svc.service_name.trim(), Number(svc.amount)]
      );
    }

    await client.query("COMMIT");

   await insertJobLog(
       id,
      "JOB_UPDATE",
      `Job updated: ${job_name}`,
      null,      
      user_id    
    );

    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [
        'Jobs | UPDATE | INFO',
        `[INFO] Job updated successfully | Job ID: ${id} | Job: ${job_name?.trim()} | Items: ${items.length} | Services: ${services.length} | Equipment: ${equipment.length}`,
        user_id,
      ]
    );

    return res.status(200).json({ message: "Job updated successfully" });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update Job Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};

const getJobLogs = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `SELECT 
         jl.log_id,
         jl.job_id,
         jl.action,
         jl.description,
         jl.performed_by,
         jl.user_id,
         jl.created_at,
         u.first_name || ' ' || u.last_name AS performed_by_name
       FROM job_log jl
       LEFT JOIN users u ON u.user_id = jl.user_id
       WHERE jl.job_id = $1
       ORDER BY jl.created_at DESC`,
      [id]
    );
    return res.status(200).json({ message: "Logs fetched", data: result.rows });
  } catch (error) {
    console.error("Get Job Logs Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// UPDATE ADMIN NOTE
const updateJobNote = async (req, res) => {
  const { id } = req.params;
  const { admin_note } = req.body;
  const user_id = req.user?.user_id ?? null;
  try {
    const result = await pool.query(
      `UPDATE job SET admin_note = $1 WHERE id = $2 RETURNING *`,
      [admin_note?.trim() || null, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: "Job not found" });

    await insertJobLog(id, "NOTE_UPDATE", `Admin note updated`, null, user_id);
    return res.status(200).json({ message: "Note updated", data: result.rows[0] });
  } catch (error) {
    console.error("Update Note Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

//restore job from deleted list
const restoreJob = async (req, res) => {
  const { id } = req.params;
  const user_id = req.user?.user_id ?? null;
  try {
    const result = await pool.query(
      `UPDATE job 
       SET status = 'PENDING', deleted_at = NULL 
       WHERE id = $1 AND status = 'DELETED'
       RETURNING id, job_name`,
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Job not found or not deleted" });
    }
    const { id: job_id, job_name } = result.rows[0];
    await insertJobLog(job_id, "JOB_RESTORE", `Job restored: ${job_name}`, null, user_id);
    return res.status(200).json({ message: "Job restored successfully", data: result.rows[0] });
  } catch (error) {
    console.error("Restore Job Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


const convertJobToInvoice = async (req, res) => {
  const { id } = req.params;
  const user_id = req.user?.user_id ?? null;
  const client = await pool.connect();

  try {

    const jobResult = await client.query(
      `SELECT * FROM job WHERE id = $1 AND status != 'DELETED'`,
      [id]
    );
    if (jobResult.rows.length === 0) {
      return res.status(404).json({ message: "Job not found" });
    }
    const job = jobResult.rows[0];

    const itemsResult = await client.query(
      `SELECT
         jbi.id,
         jbi.item_type,
         jbi.product_id,
         jbi.item_name,
         jbi.quantity,
         jbi.unit_price,
         jbi.total_price,
         -- grab the first active variant for this product
         v.variant_id
       FROM job_bill_item jbi
       LEFT JOIN LATERAL (
         SELECT variant_id
         FROM product_variants
         WHERE product_id = jbi.product_id
           AND status = 'active'
         ORDER BY variant_id ASC
         LIMIT 1
       ) v ON true
       WHERE jbi.job_id = $1
       ORDER BY jbi.id ASC`,
      [id]
    );
    const items = itemsResult.rows;

    const servicesResult = await client.query(
      `SELECT id, service_name, amount
       FROM job_other_service
       WHERE job_id = $1
       ORDER BY id ASC`,
      [id]
    );
    const services = servicesResult.rows;

    const totalItemQty = items.reduce((s, it) => s + Number(it.quantity || 1), 0);
    const totalItem    = totalItemQty + services.length;

    const totalProducts   = items.reduce((s, it) => s + Number(it.total_price || 0), 0);
    const totalServiceFee = services.reduce((s, sv) => s + Number(sv.amount || 0), 0);
    const grandTotal      = parseFloat((totalProducts + totalServiceFee).toFixed(2));

    let senderName  = null;
    let senderPhone = null;
    if (job.customer_id) {
      const custRes = await client.query(
        `SELECT first_name || ' ' || last_name AS name, contact_number_1 AS phone
         FROM customer WHERE customer_id = $1`,
        [job.customer_id]
      );
      if (custRes.rows.length > 0) {
        senderName  = custRes.rows[0].name;
        senderPhone = custRes.rows[0].phone;
        senderEmail = custRes.rows[0].email;   

      }
    }

    await client.query("BEGIN");

    const headerResult = await client.query(
      `INSERT INTO invoice_header (
         customer_id,
         payment_method_id,
         order_status,
         total_value,
         amount_paid,
         total_item,
         cod,
         payment_status,
         discount,
         interface,
         balance,
         add_to_points,
         invoice_link,
         inventory_deduct,
         table_id,
         full_amount,
         user_id,
         sender_name,
         sender_phone,
         sender_email,
         note,
         created_at
       ) VALUES (
         $1,  -- customer_id
         NULL,-- payment_method_id
         'pending',
         $2,  -- total_value
         0,   -- amount_paid
         $3,  -- total_item
         false,
         'unpaid',
         0,   -- discount
         'backoffice',
         0,   -- balance
         0,   -- add_to_points
         NULL,-- invoice_link
         false,
         NULL,-- table_id
         $2,  -- full_amount (same as total_value, no tax/discount)
         $4,  -- user_id
         $5,  -- sender_name
         $6,  -- sender_phone
         $7,  -- note = job name for traceability
         $8,
         NOW()
       )
       RETURNING id`,
      [
        job.customer_id || null,
        grandTotal,
        totalItem,
        user_id,
        senderName,
        senderPhone,
        senderEmail, 
        `Job #${id}: ${job.job_name}`,
      ]
    );
    const invoiceId = headerResult.rows[0].id;

    for (const it of items) {
      const qty        = Number(it.quantity);
      const unitPrice  = Number(it.unit_price);
      const totalPrice = parseFloat((qty * unitPrice).toFixed(2));

      await client.query(
        `INSERT INTO invoice_details (
           invoice_id,
           product_id,
           variant_id,
           name,
           quantity,
           unit_price,
           total_price,
           discount,
           is_free,
           free_quantity,
           is_custom,
           amount_per_unit,
           unit_type,
           batch_no,
           return_qty
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7,
           0,      -- discount
           false,  -- is_free
           0,      -- free_quantity
           false,  -- is_custom  (product line)
           NULL,   -- amount_per_unit
           '1',    -- unit_type
           NULL,   -- batch_no
           0       -- return_qty
         )`,
        [
          invoiceId,
          it.product_id   || null,
          it.variant_id   || null,   
          it.item_name,
          qty,
          unitPrice,
          totalPrice,
        ]
      );
    }

    const maxVariantResult = await client.query(
      `SELECT COALESCE(MAX(variant_id), 199) AS max_id 
      FROM invoice_details 
      WHERE variant_id BETWEEN 200 AND 999999`
    );
    let serviceVariantId = Number(maxVariantResult.rows[0].max_id) + 1;
    for (const sv of services) {
      const amount = parseFloat(Number(sv.amount).toFixed(2));

      await client.query(
        `INSERT INTO invoice_details (
           invoice_id,
           product_id,
           variant_id,
           name,
           quantity,
           unit_price,
           total_price,
           discount,
           is_free,
           free_quantity,
           is_custom,
           amount_per_unit,
           unit_type,
           batch_no,
           return_qty
         ) VALUES (
           $1,
           NULL,          -- no product_id for service
           $2,            -- variant_id starting at 200
           $3,            -- service name
           1,             -- qty = 1 for a service fee line
           $4,            -- unit_price = service amount
           $4,            -- total_price
           0,
           false,
           0,
           true,          -- is_custom = true for service/labour
           NULL,
           '1',
           NULL,
           0
         )`,
        [invoiceId, serviceVariantId++, sv.service_name, amount]
      );
    }

    await client.query("COMMIT");


    await pool.query(
      `UPDATE job SET invoice_id = $1 WHERE id = $2`,
      [invoiceId, id]
    );

    customhookInvoice(12, invoiceId)
  .catch(err => console.warn('[convertJobToInvoice] Notification failed:', err.message));

    await insertJobLog(
      id,
      "INVOICE_CREATED",
      `Invoice #${invoiceId} created from job`,
      null,
      user_id
    );

    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [
        'Jobs | INVOICE_CREATE | INFO',
        `[INFO] Invoice created from job | Job ID: ${id} | Invoice ID: ${invoiceId} | Grand Total: ${grandTotal}`,
        user_id,
      ]
    );

    return res.status(201).json({
      message: "Invoice created successfully",
      invoice_id: invoiceId,
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Convert Job to Invoice Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};

const getJobInvoice = async (req, res) => {
  const { id } = req.params;
  try {
    const [invoiceResult, itemsResult, brandingResult] = await Promise.all([
      pool.query(
        `SELECT 
           o.id, o.total_value, o.amount_paid, o.payment_status,
           o.full_amount, o.discount, o.tax, o.tax_percentage,
           o.balance, o.interface, o.created_at,
           o.sender_name, o.sender_phone, o.sender_email, o.sender_address
         FROM invoice_header o
         WHERE o.id = $1`,
        [id]
      ),
      pool.query(
        `SELECT 
           ie.name, ie.quantity, ie.unit_price, ie.discount,
           ie.total_price, ie.is_custom, ie.product_id,
           pv.variant_value
         FROM invoice_details ie
         LEFT JOIN product_variants pv ON ie.variant_id = pv.variant_id
         WHERE ie.invoice_id = $1
         ORDER BY ie.id ASC`,
        [id]
      ),
      pool.query(
        `SELECT company_name, address_1, address_2, hotline
         FROM branding_settings LIMIT 1`
      ),
    ]);

    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ message: "Invoice not found" });
    }

    return res.status(200).json({
      order:      invoiceResult.rows[0],
      items:      itemsResult.rows,
      branding:   brandingResult.rows[0] ?? null,
    });
  } catch (error) {
    console.error("Get Job Invoice Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// CONVERT JOB TO QUOTATION

const convertJobToQuotation = async (req, res) => {
  const { id } = req.params;
  const { time_period } = req.body;
  const user_id = req.user?.user_id ?? null;
  const client = await pool.connect();

  try {
    const jobResult = await client.query(
      `SELECT * FROM job WHERE id = $1 AND status != 'DELETED'`, [id]
    );
    if (jobResult.rows.length === 0)
      return res.status(404).json({ message: "Job not found" });
    const job = jobResult.rows[0];

    const itemsResult = await client.query(
      `SELECT jbi.id, jbi.item_type, jbi.product_id, jbi.item_name,
              jbi.quantity, jbi.unit_price, jbi.total_price, v.variant_id
       FROM job_bill_item jbi
       LEFT JOIN LATERAL (
         SELECT variant_id FROM product_variants
         WHERE product_id = jbi.product_id AND status = 'active'
         ORDER BY variant_id ASC LIMIT 1
       ) v ON true
       WHERE jbi.job_id = $1 ORDER BY jbi.id ASC`, [id]
    );
    const items = itemsResult.rows;

    const servicesResult = await client.query(
      `SELECT id, service_name, amount FROM job_other_service
       WHERE job_id = $1 ORDER BY id ASC`, [id]
    );
    const services = servicesResult.rows;

    const totalProducts   = items.reduce((s, it) => s + Number(it.total_price || 0), 0);
    const totalServiceFee = services.reduce((s, sv) => s + Number(sv.amount || 0), 0);
    const grandTotal      = parseFloat((totalProducts + totalServiceFee).toFixed(2));
    const totalItemQty    = items.reduce((s, it) => s + Number(it.quantity || 1), 0);
    const totalItem       = totalItemQty + services.length;

    let senderName = null, senderPhone = null, senderEmail = null;

    if (job.customer_id) {
      const custRes = await client.query(
        `SELECT 
          first_name || ' ' || last_name AS name, 
          contact_number_1 AS phone,
          email
        FROM customer 
        WHERE customer_id = $1`,
        [job.customer_id]
      );

      if (custRes.rows.length > 0) {
        senderName  = custRes.rows[0].name;
        senderPhone = custRes.rows[0].phone;
        senderEmail = custRes.rows[0].email;
      }
    }

    const quotationDate = new Date().toISOString().split('T')[0];

    await client.query("BEGIN");

   const headerResult = await client.query(
    `INSERT INTO quotation_header (
      customer_id, status, total_value, total_item,
      sender_name, sender_phone, sender_email,
      note, time_period,
      quotation_date, full_amount, discount, user_id,
      tax_percentage, tax,
      currency, merchant_id
    ) VALUES (
      $1, 'sent', $2, $3,
      $4, $5, $6,
      $7, $8,
      $9, $10, 0, $11,
      NULL, NULL,
      'USD', 20001
    ) RETURNING id`,
    [
      job.customer_id || null,
      grandTotal,
      totalItem,
      senderName,
      senderPhone,
      senderEmail,
      `Job #${id}: ${job.job_name}`,
      time_period ? Number(time_period) : null,
      quotationDate,
      grandTotal,
      user_id,
    ]
  );

    const quotationId = headerResult.rows[0].id;

    // Insert product/custom items
    for (const it of items) {
      const qty        = Number(it.quantity);
      const unitPrice  = Number(it.unit_price);
      const totalPrice = parseFloat((qty * unitPrice).toFixed(2));
      await client.query(
        `INSERT INTO quotation_details (
           quotation_id, product_id, variant_id, name,
           quantity, unit_price, discount, total_price,
           is_free, free_quantity, is_custom, amount_per_unit, unit_type
         ) VALUES ($1,$2,$3,$4,$5,$6,0,$7,false,0,false,NULL,'1')`,
        [quotationId, it.product_id || null, it.variant_id || null,
         it.item_name, qty, unitPrice, totalPrice]
      );
    }

    // Insert service lines (is_custom = true, variant_id starts at 200)
    const maxVariantResult = await client.query(
      `SELECT COALESCE(MAX(variant_id), 199) AS max_id
       FROM quotation_details WHERE variant_id BETWEEN 200 AND 999999`
    );
    let serviceVariantId = Number(maxVariantResult.rows[0].max_id) + 1;

    for (const sv of services) {
      const amount = parseFloat(Number(sv.amount).toFixed(2));
      await client.query(
        `INSERT INTO quotation_details (
           quotation_id, product_id, variant_id, name,
           quantity, unit_price, discount, total_price,
           is_free, free_quantity, is_custom, amount_per_unit, unit_type
         ) VALUES ($1,NULL,$2,$3,1,$4,0,$4,false,0,true,NULL,'1')`,
        [quotationId, serviceVariantId++, sv.service_name, amount]
      );
    }

    await client.query("COMMIT");

    await pool.query(
      `UPDATE job SET quotation_id = $1 WHERE id = $2`,
      [quotationId, id]
    );

    const custMobile = senderPhone || '';
    const custEmail  = senderEmail || '';

    customhookQuotation(11, quotationId, custMobile, custEmail)
      .catch(err => console.warn('[convertJobToQuotation] Notification failed:', err.message));


    await insertJobLog(id, "QUOTATION_CREATED",
      `Quotation #${quotationId} created from job`, null, user_id);

    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [
        'Jobs | QUOTATION_CREATE | INFO',
        `[INFO] Quotation created from job | Job ID: ${id} | Quotation ID: ${quotationId} | Grand Total: ${grandTotal}`,
        user_id,
      ]
    );

    return res.status(201).json({
      message: "Quotation created successfully",
      quotation_id: quotationId,
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Convert Job to Quotation Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};

// GET JOB QUOTATION

const getJobQuotation = async (req, res) => {
  const { id } = req.params;
  try {
    const [quotationResult, itemsResult, brandingResult] = await Promise.all([
      pool.query(
        `SELECT 
           q.id,
           q.status,
           q.total_value,
           q.full_amount,
           q.discount,
           q.created_at,
           q.time_period,
           q.quotation_date,
           q.sender_name,
           q.sender_phone,
           q.sender_email, 
           q.note,
           q.tax,
           q.tax_percentage,
           q.currency,
           q.quotation_link 
         FROM quotation_header q WHERE q.id = $1`, [id]
      ),
      pool.query(
        `SELECT qd.name, qd.quantity, qd.unit_price, qd.discount,
                qd.total_price, qd.is_custom, qd.product_id,
                pv.variant_value
         FROM quotation_details qd
         LEFT JOIN product_variants pv ON qd.variant_id = pv.variant_id
         WHERE qd.quotation_id = $1 ORDER BY qd.id ASC`, [id]
      ),
      pool.query(
        `SELECT company_name, address_1, address_2, hotline
         FROM branding_settings LIMIT 1`
      ),
    ]);

    if (quotationResult.rows.length === 0)
      return res.status(404).json({ message: "Quotation not found" });

    return res.status(200).json({
      order:    quotationResult.rows[0],
      items:    itemsResult.rows,
      branding: brandingResult.rows[0] ?? null,
    });
  } catch (error) {
    console.error("Get Job Quotation Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

const updateQuotationLink = async (req, res) => {
  const { id } = req.params;
  const { quotation_link } = req.body;

  try {
    if (!quotation_link) {
      return res.status(400).json({ message: "quotation_link is required" });
    }

    const result = await pool.query(
      `UPDATE quotation_header
       SET quotation_link = $1
       WHERE id = $2
       RETURNING id, quotation_link`,
      [quotation_link, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Quotation not found" });
    }

    return res.status(200).json({
      message: "Quotation link saved",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Update Quotation Link Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

module.exports = {
  searchProducts, createJob, getAllJobs, getJobById,
  updateJobStatus, deleteJob, searchCustomers, createCustomer,
  searchUsers, assignUsersToJob, updateJob,getJobLogs,updateJobNote,getDeletedJobs,restoreJob,convertJobToInvoice, getJobInvoice,getJobQuotation, convertJobToQuotation, updateQuotationLink
};

