const pool = require("../config/db");
const { formatPhoneNumber } = require("../models/authModels");
const { adminUserDeatils, systemSettings, brandingSettings, getDeliveryFee, oneCountry, updateLoyaltySuctomer, checkLoyalty, addLoyalty } = require("../models/commonModels");
const { insertNotification } = require("../models/notificationsUpdater");
const { customhook } = require("../models/smsnotificationmodel");
const { insertAdminLog } = require("../models/userLogs");
const bcrypt = require("bcrypt");
const saltRounds = 10;

const getProductSearch = async (req, res) => {
    const { search } = req.query
    const query = `SELECT
        p.product_id,
        p.title,
        pm.media_url AS main_img,
        pmd_first.media_url AS first_extra_img,
        p.amount_per_unit,
        p.measurement_id,
        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
        m.measurement_value,
        json_agg(
            json_build_object(
            'variant_id', v.variant_id,
            'variant_value', v.variant_value,
            'price', v.price,
            'product_id', v.product_id,
            'weight', v.weight,
            'quantity', i.new_quantity,
            'barcode', v.barcode
            )
            ORDER BY v.variant_value
        ) AS variants

        FROM products p
        LEFT JOIN product_variants v  ON v.product_id = p.product_id
        LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
        LEFT JOIN measurements m ON p.measurement_id	= m.measurement_id
        LEFT JOIN LATERAL (
            SELECT media_url
            FROM   product_media
            WHERE  product_id = p.product_id
                AND  main = true AND variant_id IS NOT NULL
            ORDER  BY created_at ASC
            LIMIT  1
            ) pmd_first ON true
        LEFT JOIN LATERAL (
            SELECT new_quantity
            FROM   inventory
            WHERE  variant_id = v.variant_id
            ORDER  BY inventory_id DESC
            LIMIT  1
            ) i ON true
        WHERE p.status = 'active'
      AND (
        p.title ILIKE '%' || $1 || '%'
        OR ($1 ~ '^[0-9]+$' AND p.product_id = $1::int)
        OR v.barcode ILIKE $1
        OR v.variant_id::text ILIKE '%' || $1 || '%'
      )
        GROUP BY p.product_id, pm.media_url, pmd_first.media_url, m.measurement_value
        ORDER BY p.created_at DESC
        LIMIT 10 OFFSET 0`

    try {
        const result = await pool.query(query, [search]);
        return res.status(200).json({
            message: "success",
            result: result.rows
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error"
        });
    }
};

const useMeasurementConverter = (amount, measurement_id) => {

    // Only convert when measurement is grams (id = 3)
    if (measurement_id !== 3) {
        return amount; // return original amount
    }

    // Keep as grams
    return (amount / 1000).toFixed(2)
};

//only add
const addOrder = async (req, res) => {
    const { products, client, clientDetails, billingaddressSame, billingaddress, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountType, selected, discountDetails, loyaltiPoints, bankSlipUrl, lastSubTotal, fastAmount } = req.body
    console.log("products", products)
    const user = req.user
    const user_id = user.user_id

    try {

        const type = discountDetails && discountDetails.type ? discountDetails.type : null

        const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

        //admin merchant id
        const [adminDetails, system_settings, customerLoyalty] = await Promise.all([
            adminUserDeatils(user_id),
            systemSettings(),
            checkLoyalty(clientDetails.value)
        ])
        const merchant_id = adminDetails.merchant_id
        const branch_id = adminDetails.branch_id

        if (customerLoyalty < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })

        // check COD or not
        let cod = false
        if (selectedPaymentMethod.label === "COD") {
            cod = true
        }

        const totalAmount = lastSubTotal

        const totalWeight = products.reduce((total, item) => {
            if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
            return total + parseFloat(item.weight * item.selectedQty)
        }, 0);

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        let parsedDeliveryFee = 0
        const roundedWeight = Math.ceil(parseFloat(totalWeight))
        let sender_country = 'Sri Lanka'
        let delivery_country = 'Sri Lanka'

        if (selected == 'same_as_billing') {
            const [deliveryFeeDetails, sCountry] = await Promise.all([
                getDeliveryFee(clientDetails.country),
                oneCountry(clientDetails.country)
            ])

            sender_country = sCountry
            if (roundedWeight > 1) {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
            } else {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
            }
        } else if (selected == 'default') {
            const [deliveryFeeDetails, sCountry, dCountry] = await Promise.all([
                getDeliveryFee(billingaddress.country),
                oneCountry(clientDetails.country),
                oneCountry(billingaddress.country)
            ])

            sender_country = sCountry
            delivery_country = dCountry

            if (roundedWeight > 1) {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
            } else {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
            }
        } else if (selected == 'store_pickup') {
            sender_country = await oneCountry(clientDetails.country)
            parsedDeliveryFee = 0
        }

        // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  billingaddressSame - tax add on off
        let grandtax = null;
        if (system_settings.tax && billingaddressSame) {
            grandtax = totalTax;
        }

        console.log(system_settings)

        const fullAmount = fastAmount

        console.log("first", fullAmount)

        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let storepickup = 'No'

        //set shipping details
        let shipping_first_name = ''
        let shipping_last_name = ''
        let shipping_address = ''
        let shipping_city = ''
        let shipping_postal_code = ''
        let shipping_apartment = ''
        let shipping_country = 'Sri Lanka'
        let shipping_contact_number_1 = ''
        let shipping_email = ''

        if (selected == 'same_as_billing') {
            shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
            shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
            shipping_address = clientDetails.address ? clientDetails.address : ''
            shipping_city = clientDetails.city ? clientDetails.city : ''
            shipping_postal_code = clientDetails.postal_code ? clientDetails.postal_code : ''
            shipping_apartment = clientDetails.apartment ? clientDetails.apartment : ''
            shipping_contact_number_1 = clientDetails.contact_number_1 ? clientDetails.contact_number_1 : ''
            shipping_email = clientDetails.email ? clientDetails.email : ''
            shipping_country = sender_country ? sender_country : ''
        } else if (selected == 'default') {
            shipping_first_name = billingaddress.first_name ? billingaddress.first_name : ''
            shipping_last_name = billingaddress.last_name ? billingaddress.last_name : ''
            shipping_address = billingaddress.address ? billingaddress.address : ''
            shipping_city = billingaddress.city ? billingaddress.city : ''
            shipping_postal_code = billingaddress.postal_code ? billingaddress.postal_code : ''
            shipping_apartment = billingaddress.apartment ? billingaddress.apartment : ''
            shipping_contact_number_1 = billingaddress.contact_number_1 ? billingaddress.contact_number_1 : ''
            shipping_email = billingaddress.email ? billingaddress.email : ''
            shipping_country = delivery_country ? delivery_country : ''
        } else if (selected == 'store_pickup') {
            const shopDetails = await brandingSettings()
            shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
            shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
            shipping_address = shopDetails.address_1 ? shopDetails.address_1 : ''
            shipping_city = shopDetails.address_2 ? shopDetails.address_2 : ''
            shipping_postal_code = ''
            shipping_apartment = ''
            shipping_contact_number_1 = shopDetails.hotline ? shopDetails.hotline : ''
            shipping_email = shopDetails.support_email ? shopDetails.support_email : ''
            shipping_country = sender_country ? sender_country : ''
            storepickup = 'Yes'
        }

        const delivery_partner_id = selected == 'store_pickup' ? 1 : null

        const orderQuery = `INSERT INTO orders (user_id, customer_id, merchant_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_address, recipient_name, recipient_contact, recipient_email, recipient_address, recipient_city, recipient_postal_code, recipient_country, payment_reference, order_module, delivery_fee, discount, tax_percentage, tax, storepickup, sender_name, sender_city, sender_phone, sender_email, sender_country, recipient_contact_two, full_amount, delivery_partner_id, discount_type, loyalty_points_spent, bank_slip, recipient_addrees_2, sender_addrees_2) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38, $39, $40) RETURNING order_id`

        const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod.value, 'pending', totalAmount, 0, totalQuantity, totalWeight, cod, Number(fullAmount) > 0 ? 'unpaid' : 'paid', system_settings.currency, clientDetails.address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, refference, 'admin', parseFloat(deliveryFee) || 0, parseFloat(totalDiscount ? totalDiscount : 0) || 0, taxValue, grandtax, storepickup, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.city, clientDetails.contact_number_1, clientDetails.email, sender_country, billingaddress.contact_number_2, fullAmount, delivery_partner_id, type, typeLoyaltyPoint, bankSlipUrl, shipping_apartment, clientDetails.apartment]

        const orderResult = await pool.query(orderQuery, OrderParms)

        if (orderResult.rowCount === 0) return res.status(400).json({ message: "order not created" })


        const orderItemParams = []
        const values = []

        products.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            const baseIndex = 10 * i;

            values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

            const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            orderItemParams.push(
                orderResult.rows[0].order_id,
                product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                real_weight,
                is_free,                             // 8. is_free
                free_quantity,
                discount
            );
        });


        //add order items 
        const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

            const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value, 'order'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        const module = "Orders";
        const logMessage = `New order #${orderResult.rows[0].order_id} has been placed by user ${user_id}`;


        const [re, notification] = await Promise.all([
            customhook(1, orderResult.rows[0].order_id),
            insertNotification(user_id, 'Order Management', 'New Order Placed', `New order #${orderResult.rows[0].order_id} has been placed for ${clientDetails.first_name} ${clientDetails.last_name}.`, 'admin', 'Unread'),
            insertAdminLog(user_id, module, logMessage),
            updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty)

        ])

        return res.status(200).json({ message: "success" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({ message: "Internal server error" })
    }
}

// add and paid
const addOrderpaid = async (req, res) => {
    const { products, client, clientDetails, billingaddressSame, billingaddress, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountType, selected, discountDetails, loyaltiPoints, bankSlipUrl, lastSubTotal, fastAmount } = req.body
    // console.log(req.body)
    const user = req.user
    const user_id = user.user_id

    try {

        const type = discountDetails && discountDetails.type ? discountDetails.type : null

        const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)
        console.log(discount)


        //admin merchant id
        const [adminDetails, system_settings, customerLoyalty] = await Promise.all([
            adminUserDeatils(user_id),
            systemSettings(),
            checkLoyalty(clientDetails.value)
        ])
        const merchant_id = adminDetails.merchant_id
        const branch_id = adminDetails.branch_id

        if (customerLoyalty < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })


        // check COD or not
        let cod = false
        if (selectedPaymentMethod.label === "COD") {
            cod = true
        }

        const totalAmount = lastSubTotal

        const totalWeight = products.reduce((total, item) => {
            if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
            return total + parseFloat(item.weight * item.selectedQty)
        }, 0);

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        let parsedDeliveryFee = 0
        const roundedWeight = Math.ceil(parseFloat(totalWeight))
        let sender_country = 'Sri Lanka'
        let delivery_country = 'Sri Lanka'


        if (selected == 'same_as_billing') {
            const [deliveryFeeDetails, sCountry] = await Promise.all([
                getDeliveryFee(clientDetails.country),
                oneCountry(clientDetails.country)
            ])

            sender_country = sCountry
            if (roundedWeight > 1) {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
            } else {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
            }
        } else if (selected == 'default') {
            const [deliveryFeeDetails, sCountry, dCountry] = await Promise.all([
                getDeliveryFee(billingaddress.country),
                oneCountry(clientDetails.country),
                oneCountry(billingaddress.country)
            ])

            sender_country = sCountry
            delivery_country = dCountry

            if (roundedWeight > 1) {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
            } else {
                parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
            }
        } else if (selected == 'store_pickup') {
            sender_country = await oneCountry(clientDetails.country)
            parsedDeliveryFee = 0
        }

       
        let grandtax = null;
        if (system_settings.tax && billingaddressSame) {
            grandtax = totalTax;
        }

        const fullAmount = fastAmount

        console.log(system_settings)
        const maxDelivery = Math.max(parseFloat(parsedDeliveryFee), parseFloat(deliveryFee))

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        const points_given = parseFloat(system_settings.points_given) || 0
        const amount_spend = parseFloat(system_settings.amount_spend) || 0

        if (loyalty_point) {
            const orderPerPoint = fullAmount / amount_spend
            loyalty_points_earned = orderPerPoint * points_given
        }

        console.log("tesing", loyalty_points_earned, fullAmount, points_given, amount_spend)
        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let storepickup = 'No'

        //set shipping details
        let shipping_first_name = ''
        let shipping_last_name = ''
        let shipping_address = ''
        let shipping_city = ''
        let shipping_postal_code = ''
        let shipping_apartment = ''
        let shipping_country = 'Sri Lanka'
        let shipping_contact_number_1 = ''
        let shipping_email = ''

        if (selected == 'same_as_billing') {
            shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
            shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
            shipping_address = clientDetails.address ? clientDetails.address : ''
            shipping_city = clientDetails.city ? clientDetails.city : ''
            shipping_postal_code = clientDetails.postal_code ? clientDetails.postal_code : ''
            shipping_apartment = clientDetails.apartment ? clientDetails.apartment : ''
            shipping_contact_number_1 = clientDetails.contact_number_1 ? clientDetails.contact_number_1 : ''
            shipping_email = clientDetails.email ? clientDetails.email : ''
            shipping_country = sender_country ? sender_country : ''
        } else if (selected == 'default') {
            shipping_first_name = billingaddress.first_name ? billingaddress.first_name : ''
            shipping_last_name = billingaddress.last_name ? billingaddress.last_name : ''
            shipping_address = billingaddress.address ? billingaddress.address : ''
            shipping_city = billingaddress.city ? billingaddress.city : ''
            shipping_postal_code = billingaddress.postal_code ? billingaddress.postal_code : ''
            shipping_apartment = billingaddress.apartment ? billingaddress.apartment : ''
            shipping_contact_number_1 = billingaddress.contact_number_1 ? billingaddress.contact_number_1 : ''
            shipping_email = billingaddress.email ? billingaddress.email : ''
            shipping_country = delivery_country ? delivery_country : ''
        } else if (selected == 'store_pickup') {
            const shopDetails = await brandingSettings()
            shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
            shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
            shipping_address = shopDetails.address_1 ? shopDetails.address_1 : ''
            shipping_city = shopDetails.address_2 ? shopDetails.address_2 : ''
            shipping_postal_code = ''
            shipping_apartment = ''
            shipping_contact_number_1 = shopDetails.hotline ? shopDetails.hotline : ''
            shipping_email = shopDetails.support_email ? shopDetails.support_email : ''
            shipping_country = sender_country ? sender_country : ''
            storepickup = 'Yes'
        }

        const delivery_partner_id = selected == 'store_pickup' ? 1 : null

        const orderQuery = `INSERT INTO orders (user_id, customer_id, merchant_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_address, recipient_name, recipient_contact, recipient_email, recipient_address, recipient_city, recipient_postal_code, recipient_country, payment_reference, order_module, delivery_fee, discount, tax_percentage, tax, storepickup, sender_name, sender_city, sender_phone, sender_email, sender_country, recipient_contact_two, full_amount, delivery_partner_id, discount_type, loyalty_points_spent, loyalty_points_earned, bank_slip) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37, $38, $39) RETURNING order_id`

        const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod.value, 'pending', totalAmount, totalAmount, totalQuantity, totalWeight, cod, 'paid', system_settings.currency, clientDetails.address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, refference, 'admin', parseFloat(deliveryFee), parseFloat(totalDiscount), taxValue, grandtax, storepickup, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.city, clientDetails.contact_number_1, clientDetails.email, sender_country, billingaddress.contact_number_2, fullAmount, delivery_partner_id, type, typeLoyaltyPoint, loyalty_points_earned, bankSlipUrl]

        const orderResult = await pool.query(orderQuery, OrderParms)


        const orderItemParams = []
        const values = []

        products.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

           if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            const baseIndex = 10 * i;

            values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

            const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            orderItemParams.push(
                orderResult.rows[0].order_id,
                product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                real_weight,
                is_free,                             // 8. is_free
                free_quantity,
                discount
            );
        });

        //add order items 
        const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

            const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value, 'order'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        // const re = await customhook(1, orderResult.rows[0].order_id);

        const module = "Orders";
        const logMessage = `New order #${orderResult.rows[0].order_id} has been placed by user ${user_id}`;

        const [re, notification] = await Promise.all([
            customhook(1, orderResult.rows[0].order_id),
            insertNotification(
                user_id,
                'Order Management',
                'Order Placed & Paid',
                `Order #${orderResult.rows[0].order_id} has been placed and marked as paid for ${clientDetails.first_name} ${clientDetails.last_name}.`,
                'admin',
                'Unread'
            ),
            insertAdminLog(user_id, module, logMessage),
            updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty)


        ])

        if (loyalty_point) {
            await addLoyalty(clientDetails.value, loyalty_points_earned)
        }

        return res.status(200).json({ message: "success" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({ message: "Internal server error" })
    }
}

const createCustomer = async (req, res) => {

    const user = req.user
    const user_id = user.user_id

    const { first_name, last_name, email, contact_number_1, address, city, postal_code, apartment, contact_number_2, company_name, picture, company, country } = req.body
    const password = 'guest123';

    try {
        const hash = await bcrypt.hash(password, saltRounds);

        const query = `INSERT INTO customer (first_name, last_name, email, contact_number_1, address, city, postal_code, apartment, country, contact_number_2,company_name,picture, password) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING customer_id`

        if (!first_name || !last_name || !address || !city) return res.status(400).json({ message: "All fields are required" })

        if (!email && !contact_number_1) return res.status(400).json({ message: "Email or Contact number is required" })

        let format_number = ''
        if (contact_number_1) {
            const mobileNew = formatPhoneNumber(contact_number_1);
            if (mobileNew.error) {
                return res.status(400).json({ message: mobileNew.error });
            }
            format_number = mobileNew.formatted;
        }

        const conditions = [];
        const params = [];

        // Normalize email
        const normalizedEmail = email ? String(email).trim().toLowerCase() : null;

        // Add conditions **before building query**
        if (normalizedEmail) {
            params.push(normalizedEmail);
            conditions.push(`LOWER(TRIM(email)) = $${params.length}`);
        }
        if (format_number) {
            params.push(format_number);
            conditions.push(`contact_number_1 = $${params.length}`);
        }

        // Ensure at least one condition
        if (conditions.length === 0) {
            return res.status(400).json({ message: "Email or Contact number is required" });
        }

        // Build final query AFTER conditions are added
        const userCheckQuery = `SELECT * FROM customer WHERE ${conditions.join(' OR ')}`;

        // Execute
        const userCheckResult = await pool.query(userCheckQuery, params);

        if (userCheckResult.rows.length > 0) {
            return res.status(400).json({ message: "User already exists" });
        }


        const result = await pool.query(query, [first_name, last_name, email, format_number, address, city, postal_code || '', apartment || '', country, contact_number_2 || '', company || '', picture, hash])

        if (result.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        const module = "Customer";
        const logMessage = `New customer #${result.rows[0].customer_id} has been created by user ${user_id}`;


        await insertAdminLog(user_id, module, logMessage)
        const ress = await customhook(8, result.rows[0].customer_id);

        return res.status(201).json({ message: "success" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({ message: "Internal server error" })
    }



}






module.exports = { getProductSearch, addOrder, createCustomer, addOrderpaid }