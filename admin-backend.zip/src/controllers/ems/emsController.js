const pool = require("../../config/db");
const { insertemployeeLogs } = require("../../models/userLogs");;
//const updateTransactionRecord = require("../../routes/transactionsUpdater/transactionsUpdater");
const { insertSystemLog } = require("../../models/userLogs");
const { customhookLeave,customhookShiftRoster,customhookPaysheet ,customhookEmployeeOnboard} = require("../../models/emssmsnotificationmodel");


const getEms = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM employement");
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching ems:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// ── Admin Log Helpers (same pattern as job controller) ──────────────────────
const writeAdminLog = async (module, description, user_id = 1) => {
  try {
    await pool.query(
      `INSERT INTO admin_log (module, log, user_id, date) VALUES ($1, $2, $3, NOW())`,
      [module, description, user_id]
    );
  } catch (e) {
    console.error('[writeAdminLog] Failed:', e.message);
  }
};

const buildEmsLog = ({ status, message, fail_reason = null, details = {} }) => {
  const timestamp = new Date().toISOString();
  const lines = [
    // `[${status}] ${timestamp}`,
    `Action      : ${details.action || 'EMS ACTION'}`,
    `Message     : ${message}`,
  ];
  if (fail_reason)                    lines.push(`Fail Reason : ${fail_reason}`);
  if (details.employee_id)            lines.push(`Employee ID : ${details.employee_id}`);
  if (details.employee_name)          lines.push(`Employee    : ${details.employee_name}`);
  if (details.designation_id)         lines.push(`Designation : ${details.designation_id}`);
  if (details.shift_id)               lines.push(`Shift ID    : ${details.shift_id}`);
  if (details.department_id)          lines.push(`Dept ID     : ${details.department_id}`);
  if (details.leave_id)               lines.push(`Leave ID    : ${details.leave_id}`);
  if (details.paysheet_id)            lines.push(`Paysheet ID : ${details.paysheet_id}`);
  if (details.payroll_month)          lines.push(`Pay Month   : ${details.payroll_month}/${details.payroll_year}`);
  if (details.roster_id)              lines.push(`Roster ID   : ${details.roster_id}`);
  if (details.extra)                  lines.push(`Detail      : ${details.extra}`);
  return lines.join('\n');
};


//Get all designations

const getDesignations = async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM designations ORDER BY designation_id DESC"
    );

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching designations:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



// Create designation

const createDesignation = async (req, res) => {
  console.log('Backend received req.body:', req.body);
  const user_id = req.user?.user_id ?? 1;
  const { designation_name, department_name, status, sick_leave, casual_leave, annual_leave, maternity_leave, paternity_leave } = req.body;

   const normalizedStatus = status?.toLowerCase();
  try {
    const result = await pool.query(
      `INSERT INTO designations 
       (designation_name, department_name, status,sick_leave,casual_leave,annual_leave,maternity_leave,paternity_leave )
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [designation_name, department_name, normalizedStatus, sick_leave, casual_leave, annual_leave, maternity_leave, paternity_leave]
    );
    
    //insert admin log
    
      await writeAdminLog(
      'EMS | Designation | CREATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Designation created: ${result.rows[0].designation_name}`,
        details: { action: 'CREATE Designation', designation_id: result.rows[0].designation_id, extra: `Dept: ${department_name}` },
      }),
      user_id
    );

     res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error("DESIGNATION CREATE ERROR:", {  
      message: error.message,
      code: error.code,
      detail: error.detail,
      constraint: error.constraint,
    });
    await writeAdminLog(
      'EMS | Designation | CREATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to create designation', fail_reason: error.message, details: { action: 'CREATE Designation' } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * Update designation
 */
const updateDesignation = async (req, res) => {
  const { id } = req.params;
  const user_id = req.user?.user_id ?? 1;
  const { designation_name, department_name, status, sick_leave, casual_leave, annual_leave, maternity_leave, paternity_leave } = req.body;

  const normalizedStatus = status?.toLowerCase();

  try {
    const result = await pool.query(
      `UPDATE designations
       SET designation_name = $1,
           department_name = $2,
           status = $3,
           sick_leave = $4,
           casual_leave = $5,
           annual_leave = $6,
           maternity_leave = $7,
           paternity_leave = $8,
           updated_at = CURRENT_TIMESTAMP
       WHERE designation_id = $9
       RETURNING *`,
      [designation_name, department_name, status, sick_leave, casual_leave, annual_leave, maternity_leave, paternity_leave, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Designation not found" });
    }

    //insert admin log

    await writeAdminLog(
      'EMS | Designation | UPDATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Designation updated: ${result.rows[0].designation_name}`,
        details: { action: 'UPDATE Designation', designation_id: id },
      }),
      user_id
    );

    res.json(result.rows[0]);
  } catch (error) {
    await writeAdminLog(
      'EMS | Designation | UPDATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to update designation', fail_reason: error.message, details: { action: 'UPDATE Designation', designation_id: id } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * GET all shifts
 */
const getShifts = async (req, res) => {
  try {
    const { keyword } = req.query;

    let queryParams = [];
    let whereConditions = [];

    if (keyword) {
      const trimmed = keyword.trim();
      queryParams.push(`%${trimmed}%`);
      whereConditions.push(
        `(shift_name ILIKE $${queryParams.length}
        OR weekday ILIKE $${queryParams.length}
        OR CAST(shift_in_time AS TEXT) ILIKE $${queryParams.length}
        OR CAST(shift_out_time AS TEXT) ILIKE $${queryParams.length})`
      );
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const result = await pool.query(
      `SELECT * FROM shifts ${whereClause} ORDER BY id DESC`,
      queryParams
    );

    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching shifts:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * GET shift by ID
 */
const getShiftById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      "SELECT * FROM shifts WHERE id = $1",
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Shift not found" });
    }

    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching shift:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * CREATE shift
 */
const createShift = async (req, res) => {
  const {
    shift_name,
    days, // This will now be an array from the frontend
    weekday, // Fallback for single creation if needed
    shift_in_time,
    shift_out_time,
    grace_period_minutes,
    early_ot_minutes,
    after_ot_minutes,
    max_ot_minutes,
    holiday_ot_minutes
  } = req.body;

  const user_id = req.user.user_id;

  try {
    // If multiple days are sent, combine them into a string
    // We take times from the first element assuming they are uniform for the combined shift
    const finalWeekday = Array.isArray(days) 
      ? days.map(d => d.weekday).join(', ') 
      : weekday;
      
    const finalInTime = Array.isArray(days) ? days[0].inTime : shift_in_time;
    const finalOutTime = Array.isArray(days) ? days[0].outTime : shift_out_time;

    const result = await pool.query(
      `INSERT INTO shifts 
      (shift_name, weekday, shift_in_time, shift_out_time, grace_period_minutes, early_ot_minutes, after_ot_minutes, max_ot_minutes, holiday_ot_minutes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`,
      [
        shift_name,
        finalWeekday, // e.g., "Monday, Tuesday, Wednesday"
        finalInTime,
        finalOutTime,
        grace_period_minutes,
        early_ot_minutes,
        after_ot_minutes,
        max_ot_minutes,
        holiday_ot_minutes
      ]
    );

    const newShift = result.rows[0];
    await insertemployeeLogs(null, user_id, "SHIFT_CREATE", `New combined shift created: ${newShift.shift_name}`);

    //insert admin log

    await writeAdminLog(
      'EMS | Shift | CREATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Shift created: ${newShift.shift_name}`,
        details: { action: 'CREATE Shift', shift_id: newShift.id, extra: `Days: ${finalWeekday}, In: ${finalInTime}, Out: ${finalOutTime}` },
      }),
      user_id
    );

    res.status(201).json(newShift);
  } catch (error) {
    await writeAdminLog(
      'EMS | Shift | CREATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to create shift', fail_reason: error.message, details: { action: 'CREATE Shift', extra: `Shift: ${shift_name}` } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * UPDATE shift
 */
const updateShift = async (req, res) => {
  const { id } = req.params;
  const user_id = req.user?.user_id ?? 1;
  const {
    shift_name,
    weekday,
    shift_in_time,
    shift_out_time,
    grace_period_minutes,
    early_ot_minutes,
    after_ot_minutes,
    max_ot_minutes,
    holiday_ot_minutes
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE shifts SET
        shift_name = $1,
        weekday = $2,
        shift_in_time = $3,
        shift_out_time = $4,
        grace_period_minutes = $5,
        early_ot_minutes = $6,
        after_ot_minutes = $7,
        max_ot_minutes = $8,
        holiday_ot_minutes =$9,
        updated_at = CURRENT_TIMESTAMP
       WHERE id = $10
       RETURNING *`,
      [
        shift_name,
        weekday,
        shift_in_time,
        shift_out_time,
        grace_period_minutes,
        early_ot_minutes,
        after_ot_minutes,
        max_ot_minutes,
        holiday_ot_minutes,
        id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Shift not found" });
    }

    //insert admin log

     await writeAdminLog(
      'EMS | Shift | UPDATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Shift updated: ${result.rows[0].shift_name}`,
        details: { action: 'UPDATE Shift', shift_id: id },
      }),
      user_id
    );

    res.status(200).json(result.rows[0]);
  } catch (error) {
    await writeAdminLog(
      'EMS | Shift | UPDATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to update shift', fail_reason: error.message, details: { action: 'UPDATE Shift', shift_id: id } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * UPDATE Only Shift (Add Shift / Change Shift)
 */
const updateEmployeeShift = async (req, res) => {
  const { id } = req.params;
  const { shift_id } = req.body;

  try {
    // Get shift details first
    const shiftResult = await pool.query(
      `SELECT shift_name FROM shifts WHERE id = $1`,
      [shift_id]
    );

    if (shiftResult.rows.length === 0) {
      return res.status(404).json({ message: "Shift not found" });
    }

    const shiftName = shiftResult.rows[0].shift_name;

    const result = await pool.query(
      `UPDATE employee_onboarding
       SET shift_selected_by = $1,
           shift_selected_at = CURRENT_TIMESTAMP,
           shift_name = $2,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $3
       RETURNING *`,
      [req.user?.id || null, shiftName, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.status(200).json({
      message: "Shift updated successfully",
      data: result.rows[0],
    });

  } catch (error) {
    console.error("Error updating shift:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * CREATE ATTENDANCE (Clock In / Manual Entry + Auto Status)
 */
const createAttendance = async (req, res) => {
  const {
    employee_id,
    name,
    check_in_date,
    clock_in_time,
    check_out_date,
    clock_out_time,
    log_source,
    shift_id,
    roster_id,
    attendance_note,
    day_off
  } = req.body;

  if (!employee_id || !check_in_date || !check_out_date || !clock_in_time || !clock_out_time || !shift_id) {
    return res.status(400).json({
      message: "Employee, check_in_date,check_out_date, shift_id, clock_in and clock_out are required"
    });
  }

  try {
    // Check shift exists
    const shiftCheck = await pool.query(
      `SELECT id FROM shifts WHERE id = $1`,
      [shift_id]
    );
    if (shiftCheck.rows.length === 0) {
      return res.status(404).json({ message: "Invalid shift_id" });
    }


    // CHECK IF EMPLOYEE ALREADY CHECKED IN

    const existingAttendance = await pool.query(
      `SELECT *
       FROM attendance
       WHERE employee_id = $1
       AND clock_out_time IS NULL
       ORDER BY attendance_id DESC
       LIMIT 1`,
      [employee_id]
    );

    // CHECK OUT LOGIC

    if (existingAttendance.rows.length > 0 && clock_out_time) {

      const record = existingAttendance.rows[0];

      const checkInDateTime = new Date(
        `${record.check_in_date} ${record.clock_in_time}`
      );

      const now = new Date(
        `${check_out_date} ${clock_out_time}`
      );

      const diffMinutes = (now - checkInDateTime) / (1000 * 60);

      if (diffMinutes < 30) {
        return res.status(400).json({
          message: "Checkout allowed only after 30 minutes"
        });
      }

      const updateAttendance = await pool.query(
        `UPDATE attendance
         SET check_out_date = $1,
             clock_out_time = $2,
             attendance_note = $3
         WHERE attendance_id = $4
         RETURNING *`,
        [
          check_out_date,
          clock_out_time,
          attendance_note || null,
          record.attendance_id
        ]
      );

      return res.status(200).json({
        message: "Checkout recorded successfully",
        data: updateAttendance.rows[0]
      });
    }

    //CHECK IN VALIDATION

    if (!check_in_date || !clock_in_time) {
      return res.status(400).json({
        message: "check_in_date and clock_in_time are required for check-in"
      });
    }

    const alreadyChecked = await pool.query(
      `SELECT 1
       FROM attendance
       WHERE employee_id = $1
       AND check_in_date = $2`,
      [employee_id, check_in_date]
    );

    if (alreadyChecked.rows.length) {
      return res.status(409).json({
        message: "Employee already checked in for this date"
      });
    }


    // Check holiday
    const holidayResult = await pool.query(
      `SELECT holiday_id, holiday_name
       FROM holidays
       WHERE holiday_date = $1`,
      [check_in_date]
    );

    let holiday_id = null;
    let holiday_name = null;

    if (holidayResult.rows.length > 0) {
      holiday_id = holidayResult.rows[0].holiday_id;
      holiday_name = holidayResult.rows[0].holiday_name;
    }

    // Check approved leave
    const leaveResult = await pool.query(
      `SELECT leave_id, duration_type
       FROM leaves
       WHERE employee_id = $1
       AND status = 'Approved'
       AND $2 BETWEEN from_date AND to_date`,
      [employee_id, check_in_date]
    );
    let leave_id = null;
    let halfday = false;
    if (leaveResult.rows.length > 0) {
      leave_id = leaveResult.rows[0].leave_id;
      if (
        leaveResult.rows[0].duration_type === "first_half" ||
        leaveResult.rows[0].duration_type === "second_half"
      ) {
        halfday = true;
      }
    }

    // Fetch shift grace period to determine LATE
    let late = false;
    if (!holiday_id && !leave_id && clock_in_time) {
      const shiftRes = await pool.query(
        `SELECT shift_in_time, grace_period_minutes FROM shifts WHERE id = $1`,
        [shift_id]
      );
      if (shiftRes.rows.length > 0) {
        const shiftInTime = shiftRes.rows[0].shift_in_time;       // e.g. "08:00:00"
        const gracePeriodMinutes = Number(shiftRes.rows[0].grace_period_minutes) || 0;

        const toMins = (t) => {
          const [h, m] = String(t).split(':').map(Number);
          return h * 60 + m;
        };

        const clockInMins = toMins(clock_in_time);
        const shiftInMins = toMins(shiftInTime);
        const deadlineMins = shiftInMins + gracePeriodMinutes;

        if (clockInMins > deadlineMins) {
          late = true;
        }
      }
    }

    // Determine present / absent
    let present = false;
    let absent = false;
    if (holiday_id) {
      present = false;
      absent = false;
    } else if (leave_id && !halfday) {
      present = false;
      absent = false;
    } else if (leave_id && halfday) {
      present = true;
      absent = false;
    } else {
      present = true;
      absent = false;
    }

    // Insert attendance_status  ← added `late` column
    const statusResult = await pool.query(
      `INSERT INTO attendance_status
       (holiday_id, leave_id, day_off, present, halfday, absent, holiday_name, late)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING status_id`,
      [
        holiday_id,
        leave_id,
        day_off || false,
        present,
        halfday,
        absent,
        holiday_name,
        late
      ]
    );
    const attendance_status_id = statusResult.rows[0].status_id;

    // Insert attendance with linked status_id
    const attendanceResult = await pool.query(
      `INSERT INTO attendance
       (employee_id, name, check_in_date, clock_in_time, clock_out_time,check_out_date,
        log_source, shift_id, roster_id, attendance_status_id, attendance_note)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING *`,
      [
        employee_id,
        name,
        check_in_date,
        clock_in_time,
        clock_out_time,
        check_out_date,
        log_source,
        shift_id,
        roster_id,
        attendance_status_id,
        attendance_note || null
      ]
    );

    res.status(201).json({
      message: "Attendance recorded successfully",
      data: attendanceResult.rows[0]
    });

  } catch (error) {
    console.error("Error creating attendance:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * MARK ATTENDANCE
 */
const markAttendance = async (req, res) => {
  try {
    const {
      employee_id,
      check_in_date,
      clock_in_time,
      check_out_date,
      clock_out_time,
      attendance_status_id,
      attendance_note,
    } = req.body;

    // Get shift roster for this employee and date
    const rosterResult = await pool.query(
      `SELECT roster_id, shift_id FROM shift_roster
       WHERE employee_id = $1 AND roster_date = $2`,
      [employee_id, check_in_date]
    );

    const roster_id = rosterResult.rows.length > 0 ? rosterResult.rows[0].roster_id : null;
    const shift_id = rosterResult.rows.length > 0 ? rosterResult.rows[0].shift_id : req.body.shift_id;

    const result = await pool.query(
      `INSERT INTO attendance
       (employee_id, check_in_date, clock_in_time, clock_out_time, check_out_date,
        attendance_status_id, attendance_note, shift_id, roster_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        employee_id,
        check_in_date,
        clock_in_time,
        check_out_date,
        clock_out_time,
        attendance_status_id,
        attendance_note,
        shift_id,
        roster_id
      ]
    );

    res.status(201).json({ message: "Attendance marked", data: result.rows[0] });

  } catch (error) {
    console.error("Mark Attendance Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * GET ALL ATTENDANCE
 */
const getAllAttendance = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        a.attendance_id,
        a.employee_id,
        e.first_name,
        e.last_name,
        a.name AS employee_name,
        a.check_in_date, 
        a.check_out_date,  
        a.clock_in_time,
        a.clock_out_time,
        a.log_source,
        a.shift_id,
        a.roster_id,
        a.attendance_note,

        s.present,
        s.halfday,
        s.absent,
        s.late,
        s.day_off,
        s.holiday_id,
        s.leave_id,
        s.holiday_name,

        l.duration_type   AS leave_duration_type,
        l.leave_type_id,
        l.paid_status,
        l.reason,

        sh.shift_in_time,
        sh.grace_period_minutes

      FROM attendance a
      LEFT JOIN attendance_status s
        ON a.attendance_status_id = s.status_id
      LEFT JOIN leaves l
        ON s.leave_id = l.leave_id
      LEFT JOIN holidays h
        ON s.holiday_id = h.holiday_id
      LEFT JOIN employees e
        ON a.employee_id = e.employee_id
      LEFT JOIN shifts sh
        ON a.shift_id = sh.id
      ORDER BY a.check_in_date DESC
    `);

    res.status(200).json({
      message: "Attendance fetched successfully",
      data: result.rows
    });

  } catch (error) {
    console.error("Error fetching attendance:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET ATTENDANCE BY EMPLOYEE ID
 */

const getAttendanceByEmployee = async (req, res) => {
  const { employee_id } = req.params;
  const { year, month, keyword, log_source } = req.query;

  try {
    let query = `
      SELECT 
        a.attendance_id,
        a.employee_id,
        a.check_in_date,
        a.check_out_date,
        a.clock_in_time,
        a.clock_out_time,
        a.log_source,
        a.shift_id,
        a.attendance_note,

        -- ✅ shift name from shifts table
        sh.shift_name,
        sh.shift_in_time,
        sh.shift_out_time,

        -- ✅ status fields
        s.present,
        s.halfday,
        s.absent,
        s.late,
        s.day_off,
        s.holiday_id,
        s.leave_id,
        s.holiday_name

      FROM attendance a
      LEFT JOIN attendance_status s ON a.attendance_status_id = s.status_id
      LEFT JOIN shifts sh ON a.shift_id = sh.id
      WHERE a.employee_id = $1
    `;

    const params = [employee_id];
    let idx = 2;

    // filter by year + month
    if (year && month) {
      query += ` AND EXTRACT(YEAR  FROM a.check_in_date) = $${idx++}`
      query += ` AND EXTRACT(MONTH FROM a.check_in_date) = $${idx++}`
      params.push(year, month);
    }

    // filter by log_source
    if (log_source) {
      query += ` AND a.log_source = $${idx++}`
      params.push(log_source);
    }

    // keyword search
    if (keyword) {
      query += ` AND (
        CAST(a.check_in_date AS TEXT) ILIKE $${idx} OR
        a.log_source ILIKE $${idx} OR
        sh.shift_name ILIKE $${idx}
      )`
      params.push(`%${keyword}%`);
      idx++;
    }

    query += ` ORDER BY a.check_in_date DESC`;

    const result = await pool.query(query, params);

    res.status(200).json({ data: result.rows });

  } catch (error) {
    console.error("Error fetching employee attendance:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET ATTENDANCE BY DATE
 */
const getAttendanceByDate = async (req, res) => {
  const { date } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM attendance 
       WHERE check_in_date  = $1`,
      [date]
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Error fetching attendance by date:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//GET ATTENDANCE BY SHIFT ID

/**
 * UPDATE CLOCK OUT TIME
 */
const updateClockOut = async (req, res) => {
  const { attendance_id } = req.params;
  const { check_out_date, clock_out_time } = req.body;

  try {
    const result = await pool.query(
      `UPDATE attendance
       SET check_out_date = $1,
           clock_out_time = $2
       WHERE attendance_id = $3
       RETURNING *`,
      [check_out_date, clock_out_time, attendance_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Attendance record not found" });
    }

    res.status(200).json({
      message: "Clock out updated successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating clock out:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * UPDATE CLOCK IN TIME
 */
const updateClockIn = async (req, res) => {
  const { attendance_id } = req.params;
  const { check_in_date, clock_in_time } = req.body;

  try {
    const result = await pool.query(
      `UPDATE attendance
       SET check_in_date = $1,
           clock_in_time = $2
       WHERE attendance_id = $3
       RETURNING *`,
      [check_in_date, clock_in_time, attendance_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Attendance record not found" });
    }

    res.status(200).json({
      message: "Clock in updated successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating clock in:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * CREATE EARNING OR DEDUCTION
 */
const createEarningDeduction = async (req, res) => {
  const {
    name,
    type,
    calculation_type,
    status,
    created_by
  } = req.body;

  try {
    if (!name || !type || !calculation_type || !created_by) {
      return res.status(400).json({
        message: "Name, type, calculation_type, and created_by are required"
      });
    }

    if (!["AMOUNT", "PERCENTAGE"].includes(calculation_type)) {
      return res.status(400).json({
        message: "calculation_type must be AMOUNT or PERCENTAGE"
      });
    }

    const result = await pool.query(
      `INSERT INTO earnings_deductions
       (name, type, calculation_type, status, created_by)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        name,
        type,
        calculation_type,
        status || "ACTIVE",
        created_by
      ]
    );

    res.status(201).json({
      message: "Record created successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Error creating record:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET ALL
 */
const getAllEarningsDeductions = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM earnings_deductions ORDER BY id ASC`
    );
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching records:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};




/**
 * GET ONLY EARNINGS
 */
const getOnlyEarnings = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM earnings_deductions 
       WHERE type = 'EARNINGS'
       ORDER BY id DESC`
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Error fetching earnings:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET ONLY DEDUCTIONS
 */
const getOnlyDeductions = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM earnings_deductions 
       WHERE type = 'DEDUCTIONS'
       ORDER BY id DESC`
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Error fetching deductions:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/* 
    GET ONLY ACTIVE
 */
const getActiveEarningsDeductions = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM earnings_deductions
       WHERE status = 'ACTIVE'
       ORDER BY id DESC`
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Get Active Error:", error.message);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * GET BY ID
 */
const getEarningDeductionById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM earnings_deductions WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Record not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Error fetching record:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * UPDATE Earning And Deduction
 */
const updateEarningDeduction = async (req, res) => {
  const { id } = req.params;
  const {
    name,
    type,
    calculation_type,
    status
  } = req.body;

  try {
    if (!["AMOUNT", "PERCENTAGE"].includes(calculation_type)) {
      return res.status(400).json({
        message: "calculation_type must be AMOUNT or PERCENTAGE"
      });
    }

    const result = await pool.query(
      `UPDATE earnings_deductions
       SET name = $1,
           type = $2,
           calculation_type = $3,
           status = $4
       WHERE id = $5
       RETURNING *`,
      [name, type, calculation_type, status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Record not found" });
    }

    res.status(200).json({
      message: "Record updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Error updating record:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/* 
   CREATE PAYROLL TEMPLATE
*/
const createPayrollTemplate = async (req, res) => {
  try {
    const {
      name,
      status,
      payroll_type,
      value,          // template-level value
      percentage_base = "BASIC_SALARY", // default
      ot_hour_rate = 0,
      holiday_ot_hour_rate = 0,
      no_pay_deduction_rate = 0,
      earnings = [],  // array of { earning_deduction_id, type, calculation_type, value }
      deductions = [] // array of { earning_deduction_id, type, calculation_type, value }
    } = req.body;


    const user = req.user ;
    console .log( "by user:", user);
    const created_by = user?.user_id ;

    // Basic validation
    if (!name || !created_by) {
      return res.status(400).json({ message: "Name and created_by are required" });
    }

    const allowedTypes = ["MONTHLY", "WEEKLY", "DAILY"];
    if (payroll_type && !allowedTypes.includes(payroll_type.toUpperCase())) {
      return res.status(400).json({ message: `Invalid payroll_type. Allowed values: ${allowedTypes.join(", ")}` });
    }

    // Calculate total earnings and deductions for template table
    const totalEarnings = earnings.reduce((acc, e) => acc + Number(e.value || 0), 0);
    const totalDeductions = deductions.reduce((acc, d) => acc + Number(d.value || 0), 0);

    // Insert payroll template
    const templateQuery = `
      INSERT INTO payroll_templates
      (name, status, payroll_type, created_by, earnings, deductions, value, percentage_base, ot_hour_rate, holiday_ot_hour_rate, no_pay_deduction_rate, created_date)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
      RETURNING *;
    `;

    const templateValues = [
      name,
      status || "ACTIVE",
      payroll_type ? payroll_type.toUpperCase() : "MONTHLY",
      created_by,
      totalEarnings,
      totalDeductions,
      value ? Number(value) : 0,
      percentage_base, ot_hour_rate ? Number(ot_hour_rate) : 0,
      holiday_ot_hour_rate ? Number(holiday_ot_hour_rate) : 0,
      no_pay_deduction_rate ? Number(no_pay_deduction_rate) : 0,
    ];

    const templateResult = await pool.query(templateQuery, templateValues);
    const payrollTemplate = templateResult.rows[0];

    // Insert payroll template details (earnings and deductions)
    const detailsInsertPromises = [];

    const insertDetail = (item) => {
      const { earning_deduction_id, type, calculation_type, value } = item;

      const query = `
        INSERT INTO payroll_template_details
        (payroll_template_id, earning_deduction_id, earning_deduction_name, type, amount, value, created_at, updated_at)
        SELECT $1, $2, name, $3,
               CASE WHEN $4 = 'AMOUNT' THEN $5 ELSE 0 END,
               $5,
               NOW(), NOW()
        FROM earnings_deductions
        WHERE id = $2
        RETURNING *;
      `;

      const values = [
        payrollTemplate.id,
        earning_deduction_id,
        type.toUpperCase(),    // "Earning" or "Deduction"
        calculation_type,   // "AMOUNT" or "PERCENTAGE"
        Number(value) || 0
      ];

      return pool.query(query, values);
    };

    earnings.forEach(item => detailsInsertPromises.push(insertDetail(item)));
    deductions.forEach(item => detailsInsertPromises.push(insertDetail(item)));

    const detailsResults = await Promise.all(detailsInsertPromises);

    return res.status(201).json({
      message: "Payroll template created successfully",
      template: payrollTemplate,
      details: detailsResults.flatMap(r => r.rows)
    });

  } catch (error) {
    console.error("Create Payroll Template Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


/* 
   GET ALL PAYROLL TEMPLATES
*/


const getAllPayrollTemplates = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      from_date,
      to_date,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔎 Search by ID or Name
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d+$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`pt.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`pt.name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date Filter
    if (from_date) {
  queryParams.push(from_date);
  whereConditions.push(`pt.created_date::date >= $${queryParams.length}`);
}

if (to_date) {
  queryParams.push(to_date);
  whereConditions.push(`pt.created_date::date <= $${queryParams.length}`);
}

    // 📌 Status Filter
    if (status) {
      queryParams.push(status.toUpperCase());
      whereConditions.push(`COALESCE(UPPER(pt.status), 'INACTIVE') = $${queryParams.length}`);
    }
    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // ✅ Main Query with Employee Count
    const query = `
      SELECT 
        pt.*,
        COUNT(e.employee_id) AS employee_count
      FROM payroll_templates pt
      LEFT JOIN employees e
        ON e.payroll_template_id = pt.id
      ${whereClause}
      GROUP BY pt.id
      ORDER BY pt.created_date DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const result = await pool.query(query, paginatedParams);

    // ✅ Count Query (For Pagination)
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM payroll_templates pt
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    return res.status(200).json({
      payroll_templates: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (error) {
    console.error("Payroll Template Error:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

/* 
   GET PAYROLL TEMPLATE BY ID
*/
const getPayrollTemplateById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT * FROM payroll_templates WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Template not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Template Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/* 
   UPDATE PAYROLL TEMPLATE
*/
const updatePayrollTemplate = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      name,
      status,
      earnings,
      deductions,
      payroll_type,
      value,
      percentage_base,
      ot_hour_rate,
      holiday_ot_hour_rate,
      no_pay_deduction_rate,
    } = req.body;


    const result = await pool.query(
      `UPDATE payroll_templates
       SET name = $1,
           status = $2,
           earnings = $3,
           deductions = $4,
           payroll_type = $5,
           value = $6, 
           percentage_base = $7,
           ot_hour_rate = $8,
           holiday_ot_hour_rate = $9,
           no_pay_deduction_rate = $10
       WHERE id = $11
       RETURNING *`,
      [
        name,
        status,
        earnings,
        deductions,
        payroll_type,
        value,
        percentage_base,
        ot_hour_rate,
        holiday_ot_hour_rate,
        no_pay_deduction_rate,
        id,
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Template not found" });
    }

    res.status(200).json({
      message: "Template updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Template Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// CREATE PAYROLL TEMPLATE DETAIL

const createPayrollTemplateDetail = async (req, res) => {
  const client = await pool.connect();

  try {
    const { payroll_template_id, earning_deduction_id, type, amount, value, name } = req.body;

    if (!payroll_template_id || !type) {
      return res.status(400).json({
        message: "payroll_template_id and type are required"
      });
    }

    await client.query("BEGIN");

    // Check payroll template exists
    const templateResult = await client.query(
      "SELECT id FROM payroll_templates WHERE id = $1",
      [payroll_template_id]
    );
    if (templateResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Invalid payroll_template_id" });
    }

    let finalAmount = Number(amount) || 0;
    let masterName = name || 'Custom';
    let calculationType = 'AMOUNT';

    // ── Custom row (no earning_deduction_id) ─────────────────────────────────
    if (!earning_deduction_id) {
    await client.query(
      `INSERT INTO payroll_template_details
      (payroll_template_id, earning_deduction_name,
        type, amount, value, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, NOW(), NOW())`,
      [
        payroll_template_id,
        masterName,
        type.toUpperCase(),
        finalAmount,
        Number(value) || 0
      ]
    );

    } else {
      // ── Master row ────────────────────────────────────────────────────────
      const masterResult = await client.query(
        "SELECT id, name, type, calculation_type FROM earnings_deductions WHERE id = $1",
        [earning_deduction_id]
      );
      if (masterResult.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Invalid earning_deduction_id" });
      }

      const master = masterResult.rows[0];
      masterName = master.name;

      const isPercentage = master.calculation_type === 'PERCENTAGE' ||
        (Number(amount) === 0 && Number(value) > 0)

      let finalValue = 0

      if (isPercentage) {
        finalValue = Number(value) || 0
        finalAmount = 0
        if (isNaN(finalValue)) {
          await client.query("ROLLBACK");
          return res.status(400).json({ message: "Invalid percentage value" });
        }
      } else {
        finalAmount = Number(amount) || 0
        finalValue = 0
        if (isNaN(finalAmount)) {
          await client.query("ROLLBACK");
          return res.status(400).json({ message: "Invalid amount value" });
        }
      }

      console.log('DEBUG:', { amount, value, isPercentage, finalAmount, finalValue })

      // Insert the detail row
      await client.query(
        `INSERT INTO payroll_template_details
         (payroll_template_id, earning_deduction_id, earning_deduction_name,
          type, amount, value, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())`,
        [
          payroll_template_id,
          earning_deduction_id,
          masterName,
          type.toUpperCase(),
          finalAmount,
          finalValue,
        ]
      );
    }

    // ── Update parent template totals ─────────────────────────────────────────
    if (type.toUpperCase() === "EARNINGS") {
      await client.query(
        `UPDATE payroll_templates
         SET earnings = COALESCE(earnings, 0) + $1
         WHERE id = $2`,
        [finalAmount, payroll_template_id]
      );
    } else {
      await client.query(
        `UPDATE payroll_templates
         SET deductions = COALESCE(deductions, 0) + $1
         WHERE id = $2`,
        [finalAmount, payroll_template_id]
      );
    }

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Payroll template detail added successfully",
      payroll_template_id,
      type,
      added_amount: finalAmount
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Payroll Detail Insert Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};

// CREATE PAYROLL TEMPLATE DETAIL
/*const createPayrollTemplateDetail = async (req, res) => {
  const client = await pool.connect();

  try {
    const { payroll_template_id, earning_deduction_id, type, amount, value } = req.body;

    // Basic validation
    if (!payroll_template_id || !earning_deduction_id || !type) {
      return res.status(400).json({
        message: "payroll_template_id, earning_deduction_id, and type are required"
      });
    }

    await client.query("BEGIN");

    // Check payroll template exists
    const templateResult = await client.query(
      "SELECT id FROM payroll_templates WHERE id = $1",
      [payroll_template_id]
    );

    if (templateResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Invalid payroll_template_id" });
    }

    //  Get earning/deduction master record
    const masterResult = await client.query(
      "SELECT id, name, type, calculation_type FROM earnings_deductions WHERE id = $1",
      [earning_deduction_id]
    );

    if (masterResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Invalid earning_deduction_id" });
    }

    const master = masterResult.rows[0];

    // Type validation (case insensitive)
    if (master.type.toUpperCase() !== type.toUpperCase()) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: `Type mismatch. Expected ${master.type}`
      });
    }

    let finalAmount = 0;
    let storedValue = 0;
    let calculationDetails = {};

    //  Handle calculation types
    if (master.calculation_type === "PERCENTAGE") {

      if (amount === undefined || value === undefined) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: "For PERCENTAGE type, both amount (base value) and value (percentage) are required"
        });
      }

      const baseAmount = Number(amount);
      const percentage = Number(value);

      if (isNaN(baseAmount) || isNaN(percentage)) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: "Invalid numeric values for amount or percentage"
        });
      }

      finalAmount = (baseAmount * percentage) / 100;
      storedValue = percentage;

      calculationDetails = {
        method: "PERCENTAGE",
        base_amount: baseAmount,
        percentage: percentage,
        result: finalAmount
      };

    } else {

      // FIXED AMOUNT

      if (amount === undefined) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: "Amount is required for FIXED calculation type"
        });
      }

      finalAmount = Number(amount);

      if (isNaN(finalAmount)) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: "Invalid amount value"
        });
      }

      storedValue = finalAmount;

      calculationDetails = {
        method: "FIXED",
        amount: finalAmount
      };
    }

    // Insert into payroll_template_details
    const insertQuery = `
      INSERT INTO payroll_template_details
      (payroll_template_id, earning_deduction_id, type, amount, value, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
      RETURNING *;
    `;

    const insertResult = await client.query(insertQuery, [
      payroll_template_id,
      earning_deduction_id,
      type.toUpperCase(),
      finalAmount,   // calculated result
      storedValue    // original input
    ]);

    // Update totals in payroll_templates
    if (type.toUpperCase() === "EARNING") {
      await client.query(
        "UPDATE payroll_templates SET earnings = earnings + $1 WHERE id = $2",
        [finalAmount, payroll_template_id]
      );
    } else if (type.toUpperCase() === "DEDUCTION") {
      await client.query(
        "UPDATE payroll_templates SET deductions = deductions + $1 WHERE id = $2",
        [finalAmount, payroll_template_id]
      );
    }

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Payroll template detail created successfully",
      data: {
        ...insertResult.rows[0],
        earning_deduction_name: master.name,
        calculation: calculationDetails
      } 
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create Payroll Template Detail Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};*/


//GET ALL Payroll Template Details

const getAllPayrollTemplateDetails = async (req, res) => {
  try {
    const query = `
      SELECT 
          ptd.id,
          ptd.payroll_template_id,
          pt.name AS template_name,
          ptd.earning_deduction_id,
          ed.name AS earning_deduction_name,
          ed.type AS master_type,
          ed.calculation_type,
          ptd.type,
          ptd.amount,
          ptd.value,
          ptd.created_at,
          ptd.updated_at
      FROM payroll_template_details ptd
      LEFT JOIN payroll_templates pt
        ON ptd.payroll_template_id = pt.id
      LEFT JOIN earnings_deductions ed
        ON ptd.earning_deduction_id = ed.id
      ORDER BY ptd.id DESC;
    `;

    const result = await pool.query(query);

    return res.status(200).json({
      message: "Payroll template details fetched successfully",
      data: result.rows,
    });

  } catch (error) {
    console.error("Fetch Payroll Template Details Error:", error);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

//GET Details By Payroll Template ID

const getDetailsByPayrollTemplateId = async (req, res) => {
  try {
    const { templateId } = req.params;

    const result = await pool.query(
      `SELECT 
          ptd.id,
          ptd.payroll_template_id,
          ptd.earning_deduction_id,
          COALESCE(ptd.earning_deduction_name, ed.name) AS earning_deduction_name,
          ptd.type,
          ptd.amount,
          ptd.value,
          ed.calculation_type
       FROM payroll_template_details ptd
       LEFT JOIN earnings_deductions ed
         ON ptd.earning_deduction_id = ed.id
       WHERE ptd.payroll_template_id = $1
       ORDER BY ptd.id ASC`,
      [templateId]
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Template Details Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//GET Payroll tamplate Detail By ID

const getPayrollTemplateDetailById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT 
          ptd.*,
          pt.name AS template_name,
          ed.name AS earning_deduction_name
       FROM payroll_template_details ptd
       LEFT JOIN payroll_templates pt
         ON ptd.payroll_template_id = pt.id
       LEFT JOIN earnings_deductions ed
         ON ptd.earning_deduction_id = ed.id
       WHERE ptd.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Detail not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Detail Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


//UPDATE Payroll tamplate Details

const updatePayrollTemplateDetail = async (req, res) => {
  try {
    const { id } = req.params;
    const { earning_deduction_id, type, amount, value } = req.body;

    const result = await pool.query(
      `UPDATE payroll_template_details
       SET earning_deduction_id = $1,
           type = $2,
           amount = $3,
           value = $4,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING *`,
      [earning_deduction_id, type, amount, value, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Detail not found" });
    }

    res.status(200).json({
      message: "Detail updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Detail Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * CREATE EMPLOYEE
 */
const createEmployee = async (req, res) => {

  const user_id = req.user?.user_id ?? 1;

  try {
    const {
      first_name,
      middle_name,
      last_name,
      nic,
      contact_no,
      email,
      date_of_birth,
      marital_status,
      gender,
      nationality,
      address,
      city,
      country,
      bank_account_no,
      mobile_number,
      passport_number,
      account_type,
      account_holder_name,
      bank_branch,
      joined_date,
      job_specification,
      employment_status,
      probation_start_date,
      probation_end_date,
      date_of_permanency,
      contract_start_date,
      contract_end_date,
      job_category,
      comments,
      special_note,
      designation_id,
      shift_id,
      payroll_template_id,
      department_id,
      outlet_id,
      emergency_contact_full_name,
      emergency_contact_relationship,
      emergency_contact_mobile_no,
      emergency_contact_address,
      net_salary_effective_date,
      salary_start_day,
      salary_start_date,
      first_salary_strategy,
      salary_generation_type,
    } = req.body;

     // ── Normalize casing to match DB constraints ──────────────────────────
    const maritalStatusMap = {
  'single': 'SINGLE', 'married': 'MARRIED',
  'divorced': 'DIVORCED', 'widowed': 'WIDOWED',
}

const normalizedMaritalStatus = marital_status
  ? (maritalStatusMap[marital_status.toLowerCase()] ?? marital_status)
  : null;

const accountTypeMap = {
  'savings': 'Savings', 'current': 'Current',
}
const normalizedAccountType = account_type
  ? (accountTypeMap[account_type.toLowerCase()] ?? account_type)
  : null;

const genderMap = {
  'male': 'MALE', 'female': 'FEMALE', 'other': 'OTHER',
}
const normalizedGender = gender
  ? (genderMap[gender.toLowerCase()] ?? gender)
  : null;

const employmentStatusMap = {
  'permanent': 'PERMANENT', 'probation': 'PROBATION', 'contract': 'CONTRACT',
}
const normalizedEmploymentStatus = employment_status
  ? (employmentStatusMap[employment_status.toLowerCase()] ?? employment_status)
  : null;
    // ─────────────────────────────────────────────────────────────────────

    // ── Derive salary_start_day + first_salary_strategy from salary_start_date ──
    let derivedStartDay = salary_start_day || null;
    let derivedStrategy = first_salary_strategy || 'CURRENT_MONTH';

    if (salary_start_date && joined_date && !salary_start_day) {
      const start  = new Date(salary_start_date);
      const joined = new Date(joined_date);
      derivedStartDay = start.getDate();
      derivedStrategy =
        start.getMonth() === joined.getMonth() &&
        start.getFullYear() === joined.getFullYear()
          ? 'CURRENT_MONTH'
          : 'NEXT_MONTH';
    }

    // const user_id = 1 ;
    //console.log("user_id",user_id)

    // Required validation
    if (
      !first_name ||
      !last_name ||
      !nic ||
      !email ||
      !designation_id ||
      !payroll_template_id ||
      !department_id
    ) {
      return res.status(400).json({ message: "Required fields missing" });
    }

    // :white_check_mark: Defaults
    const finalFirstSalaryStrategy = first_salary_strategy || "CURRENT_MONTH";
    const finalSalaryGenerationType = salary_generation_type || "MANUAL";

    // :white_check_mark: Validate
    if (!["CURRENT_MONTH", "NEXT_MONTH"].includes(finalFirstSalaryStrategy)) {
      return res.status(400).json({ message: "Invalid first_salary_strategy" });
    }

    if (!["AUTO", "MANUAL"].includes(finalSalaryGenerationType)) {
      return res.status(400).json({ message: "Invalid salary_generation_type" });
    }

    // :white_check_mark: Helper: safe date (handles day 31 overflow)
    const safeDate = (year, month, day) => {
      const d = new Date(year, month, day);
      if (d.getMonth() !== month) {
        return new Date(year, month + 1, 0);
      }
      return d;
    };

    // :white_check_mark: Helper: get next salary cycle date
    const getNextSalaryDate = (date, startDay) => {
      const d = new Date(date);
      return safeDate(d.getFullYear(), d.getMonth() + 1, startDay);
    };

    // :white_check_mark: Helper: get current cycle date
    const getCurrentSalaryDate = (joinedDate, startDay) => {
      const d = new Date(joinedDate);
      const currentMonthDate = safeDate(d.getFullYear(), d.getMonth(), startDay);
      if (d <= currentMonthDate) {
        return currentMonthDate;
      }
      return safeDate(d.getFullYear(), d.getMonth() + 1, startDay);
    };

    // :white_check_mark: Use a let variable to allow reassignment
    let finalNetSalaryEffectiveDate = net_salary_effective_date || null;

    // :white_check_mark: AUTO CALCULATE net_salary_effective_date if not provided
    if (!finalNetSalaryEffectiveDate) {
      if (finalFirstSalaryStrategy === "CURRENT_MONTH") {
        finalNetSalaryEffectiveDate = getCurrentSalaryDate(joined_date, salary_start_day);
      } else {
        finalNetSalaryEffectiveDate = getNextSalaryDate(joined_date, salary_start_day);
      }
    }

    const result = await pool.query(
      `INSERT INTO employees (
        first_name, middle_name, last_name, nic, contact_no, email,
        date_of_birth, marital_status, gender, nationality,
        address, city, country, bank_account_no,
        mobile_number, passport_number, account_type,
        account_holder_name, bank_branch,
        joined_date, job_specification, employment_status,
        probation_start_date, probation_end_date,
        date_of_permanency, contract_start_date, contract_end_date,
        job_category, comments, special_note,
        designation_id, shift_id, payroll_template_id,
        department_id, outlet_id, emergency_contact_full_name,
        emergency_contact_relationship, emergency_contact_mobile_no,
        emergency_contact_address, net_salary_effective_date,
        salary_start_day, salary_start_date, first_salary_strategy
      )
      VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
        $11,$12,$13,$14,$15,$16,$17,$18,$19,
        $20,$21,$22,$23,$24,$25,$26,$27,$28,$29,
        $30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43
      )
      RETURNING *`,
      [
        first_name,
        middle_name,
        last_name,
        nic,
        contact_no,
        email,
        date_of_birth,
        normalizedMaritalStatus,
        normalizedGender,
        nationality,
        address,
        city,
        country,
        bank_account_no,
        mobile_number,
        passport_number,
        normalizedAccountType,
        account_holder_name,
        bank_branch,
        joined_date,
        job_specification,
        normalizedEmploymentStatus,
        probation_start_date,
        probation_end_date,
        date_of_permanency,
        contract_start_date,
        contract_end_date,
        job_category,
        comments,
        special_note || null,
        designation_id,
        shift_id || null,
        payroll_template_id,
        department_id,
        outlet_id,
        emergency_contact_full_name,
        emergency_contact_relationship,
        emergency_contact_mobile_no,
        emergency_contact_address,
        finalNetSalaryEffectiveDate,   // :white_check_mark: fixed: was net_salary_effective_date (const)
        derivedStartDay,               // $41
        salary_start_date || null,     // $42
        derivedStrategy,               // $43
      ]
    );

    // res.status(201).json({
    //   message: "Employee created successfully",
    //   data: result.rows[0]
    // });

    const newEmployee = result.rows[0];

    // Insert log
    await insertemployeeLogs(
      newEmployee.employee_id,
      user_id,  // logged-in user id
      "EMPLOYEE_CREATE",
      "New employee created"
    );

    //insert admin log

    await writeAdminLog(
    'EMS | Employee | CREATE | INFO',
    buildEmsLog({
      status: 'INFO',
      message: `Employee created: ${newEmployee.first_name} ${newEmployee.last_name}`,
      details: {
        action: 'CREATE Employee',
        employee_id: newEmployee.employee_id,
        employee_name: `${newEmployee.first_name} ${newEmployee.last_name}`,
        designation_id: newEmployee.designation_id,
        department_id: newEmployee.department_id,
        extra: `NIC: ${nic}, Email: ${email}`,
      },
    }),
    user_id
  );

 /*  SEND EMPLOYEE ONBOARDING SMS + EMAIL NOTIFICATION */

try {
  const employee_id = newEmployee.employee_id;
  const joined_date = newEmployee.joined_date;

  if (!employee_id) throw new Error("employee_id is required for onboarding notifications");

  // Get employee contact info
  const empContact = await pool.query(
    `SELECT first_name, last_name, contact_no, email
     FROM employees
     WHERE employee_id = $1`,
    [employee_id]
  );

  const employee = empContact.rows[0];

  const employee_mobile = employee?.contact_no || null;
  const employee_email = employee?.email || null;
  const first_name = employee?.first_name || null;
  const last_name = employee?.last_name || null;

  let hookResponse = null;

  // Send onboarding notification
  try {
    hookResponse = await customhookEmployeeOnboard(
    18,
    employee_id,
    first_name,
    last_name,
    employee_mobile,  // ← must match the signature order
    employee_email,
    joined_date
  );
  } catch (hookError) {
    console.error("Custom hook (onboarding) failed:", hookError);
  }

} catch (err) {
  console.error("Failed to fetch employee for onboarding notifications:", err);
}

    return res.status(201).json({
      message: "Employee created successfully",
      data: newEmployee
    });

  } catch (error) {
    console.error("Create Employee Error:", error);

     const { first_name, last_name, nic } = req.body; 

    if (error.code === '23505') {
      const constraint = error.constraint || '';
      const detail = error.detail || '';

      let message = 'A record with this information already exists';
      let field = null;

      if (constraint.includes('email') || detail.includes('email')) {
        message = 'This email address is already registered';
        field = 'email';
      } else if (constraint.includes('mobile_number') || detail.includes('mobile_number')) {
        message = 'This mobile number is already registered';
        field = 'mobile_number';
      } else if (constraint.includes('nic') || detail.includes('nic')) {
        message = 'This NIC number is already registered';
        field = 'nic';
      } else if (constraint.includes('contact_no') || detail.includes('contact_no')) {
        message = 'This contact number is already registered';
        field = 'contact_no';
      } else if (constraint.includes('bank_account_no') || detail.includes('bank_account_no')) {
        message = 'This bank account number is already registered';
        field = 'bank_account_no';
      }
      
      //insert admin log

      await writeAdminLog(
      'EMS | Employee | CREATE | WARNING',
      buildEmsLog({
        status: 'WARNING',
        message: 'Employee creation rejected — duplicate entry',
        fail_reason: `Duplicate field: ${field ?? 'unknown'}`,
        details: { action: 'CREATE Employee', extra: `NIC: ${nic}` },
      }),
      user_id
    );

      return res.status(409).json({
        message,
        field,
        code: 'DUPLICATE_ENTRY'
      });
    }

    //insert admin log

    await writeAdminLog(
      'EMS | Employee | CREATE | CRITICAL',
      buildEmsLog({
        status: 'CRITICAL',
        message: 'Unexpected error during employee creation',
        fail_reason: error.message,
        details: { action: 'CREATE Employee', extra: `Name: ${first_name} ${last_name}` },
      }),
      user_id
    );

    res.status(500).json({ message: "Internal Server Error" });
  }
};

//add by senesh
const getEmployeeLogsById = async (req, res) => {
  const { employeeId } = req.params;
  try {
    const result = await pool.query(
      `SELECT 
          el.log_id,
          el.employee_id,
          el.log_date,
          el.log_time,
          el.module AS action_type,
          el.comments AS description,
          el.user_id,
          el.created_at,
          el.updated_at,
          CONCAT(u.first_name, ' ', u.last_name) AS performed_by_name
       FROM employee_logs el
       LEFT JOIN users u ON u.user_id = el.user_id
       WHERE el.employee_id = $1
       ORDER BY el.log_date DESC, el.log_time DESC`,
      [employeeId]
    );
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Get Employee Logs By ID Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * GET ALL EMPLOYEES 
 */
const getAllEmployees = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        e.*,
        d.designation_name,
        dep.department_name,
        s.shift_name,
        p.name AS payroll_template_name,
        p.payroll_type,
        o.name AS outlet_name
      FROM employees e
      LEFT JOIN designations d
        ON e.designation_id = d.designation_id
      LEFT JOIN departments dep
        ON e.department_id = dep.department_id
      LEFT JOIN shifts s
        ON e.shift_id = s.id
      LEFT JOIN payroll_templates p
        ON e.payroll_template_id = p.id
      LEFT JOIN outlets o
        ON e.outlet_id = o.outlet_id
      ORDER BY e.employee_id DESC
    `);

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Employees Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * GET EMPLOYEE BY ID
 */
const getEmployeeById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT 
          e.*, 
          d.designation_name,
          dep.department_name,
          s.shift_name,
          p.name AS payroll_template_name,
          p.payroll_type
       FROM employees e
       LEFT JOIN designations d
         ON e.designation_id = d.designation_id
       LEFT JOIN departments dep
         ON e.department_id = dep.department_id
       LEFT JOIN shifts s
         ON e.shift_id = s.id
       LEFT JOIN payroll_templates p
         ON e.payroll_template_id = p.id
       WHERE e.employee_id = $1`,
      [id]
    );


    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Employee Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

/**
 * UPDATE EMPLOYEE
 */
const updateEmployee = async (req, res) => {
  const { id } = req.params;

  try {
    const {
      first_name,
      middle_name,
      last_name,
      contact_no,
      email,
      employment_status,
      designation_id,
      shift_id,
      payroll_template_id,
      department_id,
      mobile_number,
      passport_number,
      account_type,
      account_holder_name,
      bank_branch,
      special_note,
      net_salary_effective_date: rawNetSalaryDate,
      salary_start_day,
      first_salary_strategy,      // ✅ NEW
      salary_generation_type,
      salary_start_date
    } = req.body;

    let net_salary_effective_date = rawNetSalaryDate;

    // ✅ Validate new fields
    if (
      first_salary_strategy &&
      !['CURRENT_MONTH', 'NEXT_MONTH'].includes(first_salary_strategy)
    ) {
      return res.status(400).json({
        message: "Invalid first_salary_strategy"
      });
    }

    if (
      salary_generation_type &&
      !['AUTO', 'MANUAL'].includes(salary_generation_type)
    ) {
      return res.status(400).json({
        message: "Invalid salary_generation_type"
      });
    }

    // ✅ Helper: safe date
    const safeDate = (year, month, day) => {
      const d = new Date(year, month, day);
      if (d.getMonth() !== month) {
        return new Date(year, month + 1, 0);
      }
      return d;
    };

    // ✅ Helper: next salary date
    const getNextSalaryDate = (date, startDay) => {
      const d = new Date(date);
      return safeDate(d.getFullYear(), d.getMonth() + 1, startDay);
    };

    /**IMPORTANT 
     
     If user manually updates net_salary_effective_date → KEEP IT
     If NOT provided but salary_start_day changed → recalculate next cycle
     */

    if (!net_salary_effective_date && salary_start_day) {
      const today = new Date();

      net_salary_effective_date = getNextSalaryDate(
        today,
        salary_start_day
      );
    }


    const result = await pool.query(
      `UPDATE employees
       SET first_name = $1,
           middle_name = $2,
           last_name = $3,
           contact_no = $4,
           email = $5,
           employment_status = $6,
           designation_id = $7,
           shift_id = $8,
           payroll_template_id = $9,
           department_id = $10,
           mobile_number = $11,
           passport_number = $12,
           account_type = $13,
           account_holder_name = $14,
           bank_branch = $15,
           special_note = $16,      -- ✅ NEW
           net_salary_effective_date = $17,
           salary_start_day = $18,
           first_salary_strategy = $19,     -- ✅ NEW
           salary_generation_type = $20,
           salary_start_date = $21,
           updated_at = CURRENT_TIMESTAMP
       WHERE employee_id = $22
       RETURNING *`,
      [
        first_name,
        middle_name,
        last_name,
        contact_no,
        email,
        employment_status,
        designation_id,
        shift_id || null,
        payroll_template_id,
        department_id,
        mobile_number,
        passport_number,
        account_type,
        account_holder_name,
        bank_branch,
        special_note,
        net_salary_effective_date,
        salary_start_day,
        first_salary_strategy || 'CURRENT_MONTH',   
        salary_generation_type || 'AUTO', 
        salary_start_date,
        id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    //insert admin log

    await writeAdminLog(
      'EMS | Employee | UPDATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Employee updated: ${result.rows[0].first_name} ${result.rows[0].last_name}`,
        details: {
          action: 'UPDATE Employee',
          employee_id: id,
          employee_name: `${result.rows[0].first_name} ${result.rows[0].last_name}`,
          designation_id,
          department_id,
        },
      }),
      user_id
    );

    res.status(200).json({ message: "Employee updated successfully", data: result.rows[0] });
  } catch (error) {
    await writeAdminLog(
      'EMS | Employee | UPDATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to update employee', fail_reason: error.message, details: { action: 'UPDATE Employee', employee_id: id } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * CREATE DEPARTMENT
 */
const createDepartment = async (req, res) => {
  try {
    const { department_name, status } = req.body;

    if (!department_name) {
      return res.status(400).json({
        message: "Department name is required"
      });
    }

    const result = await pool.query(
      `INSERT INTO departments (department_name, status)
       VALUES ($1, $2)
       RETURNING *`,
      [
        department_name,
        status || "Active"
      ]
    );

    await writeAdminLog(
    'EMS | Department | CREATE | INFO',
    buildEmsLog({
      status: 'INFO',
      message: `Department created: ${result.rows[0].department_name}`,
      details: { action: 'CREATE Department', department_id: result.rows[0].department_id },
    }),
    req.user?.user_id ?? 1
  );

    res.status(201).json({
      message: "Department created successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Create Department Error:", error);

    if (error.code === "23505") {
      return res.status(400).json({
        message: "Department name already exists"
      });
    }

    res.status(500).json({ message: "Internal Server Error" });
  }
};


//GET ALL DEPARTMENTS

const getAllDepartments = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT *
       FROM departments
       ORDER BY department_id DESC`
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Departments Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//GET DEPARTMENT BY ID

const getDepartmentById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM departments
       WHERE department_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Department not found"
      });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Department Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


//UPDATE DEPARTMENT

const updateDepartment = async (req, res) => {
  const { id } = req.params;

  try {
    const { department_name, status } = req.body;

    const result = await pool.query(
      `UPDATE departments
       SET department_name = $1,
           status = $2,
           updated_at = CURRENT_TIMESTAMP
       WHERE department_id = $3
       RETURNING *`,
      [department_name, status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Department not found"
      });
    }

    await writeAdminLog(
    'EMS | Department | UPDATE | INFO',
    buildEmsLog({
      status: 'INFO',
      message: `Department updated: ${result.rows[0].department_name}`,
      details: { action: 'UPDATE Department', department_id: id },
    }),
    req.user?.user_id ?? 1
  );

    res.status(200).json({
      message: "Department updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Department Error:", error);

    if (error.code === "23505") {
      return res.status(400).json({
        message: "Department name already exists"
      });
    }

    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * CREATE LEAVE
 */
const createLeave = async (req, res) => {
  try {
    const {
      employee_id,
      leave_type_id,
      duration_type,
      from_date,
      to_date,
      reason
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;



    // Basic validation
    if (!employee_id || !leave_type_id || !duration_type || !from_date || !reason) {
      return res.status(400).json({
        message: "Required fields missing"
      });
    }

    const validDurations = ["full_day", "first_half", "second_half", "multiple"];

    if (!validDurations.includes(duration_type)) {
      return res.status(400).json({
        message: "Invalid duration type"
      });
    }

    // Handle to_date logic
    let finalToDate = to_date;

    if (duration_type !== "multiple") {
      finalToDate = from_date;
    }

    if (duration_type === "multiple" && !to_date) {
      return res.status(400).json({
        message: "To date is required for multiple leave"
      });
    }

    // Get employee designation
    const empResult = await pool.query(
      `SELECT designation_id FROM employees WHERE employee_id = $1`,
      [employee_id]
    );

    if (empResult.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const designation_id = empResult.rows[0].designation_id;

    //  Get designation leave limits
    const desigResult = await pool.query(
      `SELECT sick_leave, casual_leave, annual_leave
       FROM designations
       WHERE designation_id = $1`,
      [designation_id]
    );

    const designation = desigResult.rows[0];

    // Get leave type name
    const leaveTypeResult = await pool.query(
      `SELECT name FROM leave_types WHERE leave_type_id = $1`,
      [leave_type_id]
    );

    const leaveTypeName = leaveTypeResult.rows[0].name.toLowerCase();

    // Calculate requested leave days
    const from = new Date(from_date);
    const to = new Date(finalToDate);

    let totalDays = (to - from) / (1000 * 60 * 60 * 24) + 1;

    if (duration_type === "first_half" || duration_type === "second_half") {
      totalDays = 0.5;
    }

    // Get already used PAID approved leave
    const usedLeaveResult = await pool.query(
      `SELECT SUM(
          CASE 
            WHEN duration_type = 'first_half' OR duration_type = 'second_half' THEN 0.5
            ELSE (to_date - from_date + 1)
          END
        ) AS used_days
       FROM leaves
       WHERE employee_id = $1
       AND leave_type_id = $2
       AND status = 'Approved'
       AND paid_status = 'paid'`,
      [employee_id, leave_type_id]
    );

    const usedDays = parseFloat(usedLeaveResult.rows[0].used_days) || 0;

    const totalAfterApply = usedDays + totalDays;

    //  Get allowed balance
    let allowedDays = 0;

    if (leaveTypeName.includes("sick")) allowedDays = designation.sick_leave;
    if (leaveTypeName.includes("casual")) allowedDays = designation.casual_leave;
    if (leaveTypeName.includes("annual")) allowedDays = designation.annual_leave;
    //change by senesh

    // Decide paid or unpaid
    let paid_status = "paid";

    if (totalAfterApply > allowedDays) {
      paid_status = "unpaid";
    }

    // Insert leave
    const result = await pool.query(
      `INSERT INTO leaves
       (employee_id, leave_type_id, duration_type, from_date, to_date, reason, paid_status, designation_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [
        employee_id,
        leave_type_id,
        duration_type,
        from_date,
        finalToDate,
        reason,
        paid_status,
        designation_id
      ]
    );

    // Insert log
    const newLeave = result.rows[0];
    await insertemployeeLogs(
      employee_id,
      user_id,  // logged-in user id
      "LEAVE_CREATE",
      "New leave created"
    );

    //insert admin log

    await writeAdminLog(
      'EMS | Leave | CREATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Leave applied (${paid_status}) for employee ${employee_id}`,
        details: {
          action: 'CREATE Leave',
          employee_id,
          leave_id: newLeave.leave_id,
          extra: `Type: ${leaveTypeName}, Duration: ${duration_type}, Days: ${totalDays}, Status: ${paid_status}`,
        },
      }),
      user_id
    );

    res.status(201).json({
      message: paid_status === "paid"
        ? "Leave applied successfully (Paid Leave)"
        : "Leave applied successfully (Unpaid Leave - Balance Exceeded)",
      data: result.rows[0]
    });

  } catch (error) {
    await writeAdminLog(
      'EMS | Leave | CREATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to create leave', fail_reason: error.message, details: { action: 'CREATE Leave', employee_id } }),
      user_id
    );
    console.error("Create Leave Error:", error);
    res.status(500).json({ message: "Internal Server Error" });

  }
};


/**
 * GET ALL LEAVES
 */
// const getAllLeaves = async (req, res) => {
//   try{
//   const {
//       keyword,
//       from_date,
//       to_date,
//       status
//     } = req.query;

//     let queryParams = [];
//     let whereConditions = [];

//     // 🔍 KEYWORD FILTER (Employee ID or Name)
//     if (keyword) {
//       const trimmedKeyword = keyword.trim();

//       if (/^\d+$/.test(trimmedKeyword)) {
//         // Search by employee_id
//         queryParams.push(parseInt(trimmedKeyword, 10));
//         whereConditions.push(`l.employee_id = $${queryParams.length}`);
//       } else {
//         // Search by employee name
//         queryParams.push(`%${trimmedKeyword}%`);
//         whereConditions.push(`(
//           e.first_name ILIKE $${queryParams.length} OR
//           e.last_name ILIKE $${queryParams.length}
//         )`);
//       }
//     }

//     // 📅 FROM DATE FILTER
//     if (from_date) {
//       queryParams.push(from_date);
//       whereConditions.push(`l.from_date >= $${queryParams.length}`);
//     }

//     // 📅 TO DATE FILTER
//     if (to_date) {
//       queryParams.push(to_date);
//       whereConditions.push(`l.to_date <= $${queryParams.length}`);
//     }

//     // 📌 STATUS FILTER (case-insensitive)
//     if (status) {
//       queryParams.push(status.trim().toUpperCase());
//       whereConditions.push(`UPPER(l.status) = $${queryParams.length}`);
//     }

//     // 🧠 BUILD WHERE CLAUSE
//     const whereClause = whereConditions.length
//       ? `WHERE ${whereConditions.join(" AND ")}`
//       : "";

//     // 🧾 FINAL QUERY
//     const result = await pool.query(
//       `
//       SELECT 
//         l.*,
//         e.first_name,
//         e.last_name,
//         e.designation_id,
//         lt.name AS leave_type_name
//       FROM leaves l
//       LEFT JOIN employees e
//         ON l.employee_id = e.employee_id
//       LEFT JOIN leave_types lt
//         ON l.leave_type_id = lt.leave_type_id
//       ${whereClause}
//       ORDER BY l.leave_id DESC
//       `,
//       queryParams
//     );

//     res.status(200).json({
//       count: result.rows.length,
//       data: result.rows
//     });

//   } catch (error) {
//     console.error("Fetch Leaves Error:", error);
//     res.status(500).json({ message: "Internal Server Error" });
//   }
// };

const getAllLeaves = async (req, res) => {
  try {
    const {
      keyword = '',
      from_date,
      to_date,
      status,
      page = 1,
      limit = 10,
    } = req.body;

    console.log("keyword",keyword);

    let queryParams = [];
    let whereConditions = [];

    // 🔍 KEYWORD FILTER
   if (keyword) {
  const trimmedKeyword = keyword.trim();

  if (/^\d+$/.test(trimmedKeyword)) {
    // 🔢 Search by employee_id
    queryParams.push(parseInt(trimmedKeyword, 10));
    whereConditions.push(`l.employee_id = $${queryParams.length}`);
  } else {
    // 🔍 FULL NAME SEARCH (first + middle + last)
    queryParams.push(`%${trimmedKeyword}%`);
    whereConditions.push(`(
      CONCAT(
        COALESCE(e.first_name, ''), ' ',
        COALESCE(e.middle_name, ''), ' ',
        COALESCE(e.last_name, '')
      ) ILIKE $${queryParams.length}
    )`);
  }
}

    // 📅 FROM DATE
    if (from_date) {
      queryParams.push(from_date);
      whereConditions.push(`l.from_date >= $${queryParams.length}`);
    }

    // 📅 TO DATE
    if (to_date) {
      queryParams.push(to_date);
      whereConditions.push(`l.to_date <= $${queryParams.length}`);
    }

    // 📌 STATUS
    if (status) {
      queryParams.push(status.toUpperCase());
      whereConditions.push(`UPPER(l.status) = $${queryParams.length}`);
    }

    // 🧠 WHERE CLAUSE
    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // ✅ PAGINATION (FIXED)
    const offset = (page - 1) * limit;

    // MAIN QUERY params
    const dataParams = [...queryParams];
    dataParams.push(limit);
    const limitIndex = dataParams.length;

    dataParams.push(offset);
    const offsetIndex = dataParams.length;

    // 🧾 DATA QUERY
    const dataQuery = `
      SELECT 
        l.*,
        e.first_name,
        e.last_name,
        e.designation_id,
        lt.name AS leave_type_name
      FROM leaves l
      LEFT JOIN employees e
        ON l.employee_id = e.employee_id
      LEFT JOIN leave_types lt
        ON l.leave_type_id = lt.leave_type_id
      ${whereClause}
      ORDER BY l.leave_id DESC
      LIMIT $${limitIndex} OFFSET $${offsetIndex}
    `;

    // 🔢 COUNT QUERY
    const countQuery = `
      SELECT COUNT(*) 
      FROM leaves l
      LEFT JOIN employees e
        ON l.employee_id = e.employee_id
      ${whereClause}
    `;

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataQuery, dataParams),
      pool.query(countQuery, queryParams),
    ]);

    const totalCount = parseInt(countResult.rows[0].count, 10);
    const totalPages = Math.ceil(totalCount / limit);

    res.status(200).json({
      leaves: dataResult.rows,
      totalCount,
      totalPages,
      currentPage: Number(page),
    });

  } catch (error) {
    console.error("Fetch Leaves Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};
/**
 * GET LEAVES BY EMPLOYEE
 */
const getLeavesByEmployee = async (req, res) => {
  const { employee_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM leaves
       WHERE employee_id = $1
       ORDER BY leave_id DESC`,
      [employee_id]
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Employee Leaves Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * UPDATE LEAVE STATUS (Approve / Reject)
 */
const updateLeaveStatus = async (req, res) => {
  const { leave_id } = req.params;
  const { status, admin_note, paid_status } = req.body;
  const user_id = req.user?.user_id ?? 1;

   try {
    // validation check — ADD WARNING log:
    if (!["Approved", "Rejected"].includes(status)) {
      await writeAdminLog(
        'EMS | Leave | STATUS_UPDATE | WARNING',
        buildEmsLog({ status: 'WARNING', message: 'Invalid leave status value', fail_reason: `status "${status}" is not allowed`, details: { action: 'UPDATE Leave Status', leave_id } }),
        user_id
      );
      return res.status(400).json({ message: "Invalid status value" });
    }

    const result = await pool.query(
      `UPDATE leaves
       SET status = $1,
           admin_note = $2,
           paid_status = $3,
           updated_at = CURRENT_TIMESTAMP
       WHERE leave_id = $4
       RETURNING *`,
      [status, admin_note || null, paid_status || 'paid', leave_id]
    );

    await writeAdminLog(
      'EMS | Leave | STATUS_UPDATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Leave ${status} for employee ${result.rows[0].employee_id}`,
        details: {
          action: 'UPDATE Leave Status',
          leave_id,
          employee_id: result.rows[0].employee_id,
          extra: `Status: ${status}, Paid: ${paid_status}, Note: ${admin_note ?? 'none'}`,
        },
      }),
      user_id
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Leave not found"
      });
    }

    const leave = result.rows[0]; // the updated leave record
    const employee_id = leave.employee_id; // <-- get employee_id from updated leave


    /*  SEND SMS + EMAIL NOTIFICATION */

    // Get employee contact
    const empContact = await pool.query(
      `SELECT first_name, last_name, contact_no, email
       FROM employees
       WHERE employee_id = $1`,
      [employee_id]
    );

    const employee = empContact.rows[0];

    const employee_mobile = employee?.contact_no || null;
    const employee_email = employee?.email || null;
    const first_name = employee?.first_name || null;

    let hookResponse = null;

    /* CALL HOOK BASED ON STATUS */
    try {
      if (status === "Approved") {
        hookResponse = await customhookLeave(
          14, // Approve Action ID
          leave.leave_id,
          employee_mobile,
          employee_email,
          first_name
        );
      } else if (status === "Rejected") {
        hookResponse = await customhookLeave(
          15, // Reject Action ID
          leave.leave_id,
          employee_mobile,
          employee_email,
          first_name
        );
      }
    } catch (hookError) {
      console.error("Custom hook failed:", hookError);
    }

    res.status(200).json({
      message: `Leave ${status} successfully`,
      data: result.rows[0]
    });

   } catch (error) {
    await writeAdminLog(
      'EMS | Leave | STATUS_UPDATE | ERROR',
      buildEmsLog({ status: 'ERROR', message: 'Failed to update leave status', fail_reason: error.message, details: { action: 'UPDATE Leave Status', leave_id } }),
      user_id
    );
    res.status(500).json({ message: "Internal Server Error" });
  }
};



/**
 * GET ALL LEAVE TYPES (ID + NAME)
 */
const getLeaveTypes = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT leave_type_id, name
       FROM leave_types
       ORDER BY leave_type_id ASC`
    );

    return res.status(200).json({
      leave_types: result.rows
    });

  } catch (error) {
    console.error("Get Leave Types Error:", error);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};


//GET outlets
const getOutlets = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT outlet_id, name
       FROM outlets
       ORDER BY outlet_id ASC`
    );

    return res.status(200).json({
      outlet_id: result.rows
    });

  } catch (error) {
    console.error("Get outlets Error:", error);
    return res.status(500).json({
      message: "Internal Server Error"
    });
  }
};


/**
 * CREATE EMPLOYEE DOCUMENT
 */
const createEmployeeDocument = async (req, res) => {
  try {
    const { employee_id, document_name, file_url, uploaded_by } = req.body;

    if (!employee_id || !document_name || !file_url || !uploaded_by) {
      return res.status(400).json({
        message: "employee_id, document_name, file_url and uploaded_by are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO employee_documents
       (employee_id, document_name, file_url, uploaded_by)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [employee_id, document_name, file_url, uploaded_by]
    );

    return res.status(201).json({
      message: "Document uploaded successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Create Document Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET DOCUMENTS BY EMPLOYEE
 */
const getDocumentsByEmployee = async (req, res) => {
  const { employee_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM employee_documents
       WHERE employee_id = $1
       ORDER BY uploaded_at DESC`,
      [employee_id]
    );

    return res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Documents Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


/**
 * GET DOCUMENT BY ID
 */
const getDocumentById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM employee_documents
       WHERE document_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Document not found" });
    }

    return res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Get Document Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


//CREATE Appreciation
const createAppreciation = async (req, res) => {
  try {
    const { employee_id, subject, description } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    if (!employee_id || !subject || !description) {
      return res.status(400).json({
        message: "employee_id, subject and description are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO appreciations
       (employee_id, subject, description)
       VALUES ($1, $2, $3)
       RETURNING *`,
      [employee_id, subject, description]
    );

    const newAppreciation = result.rows[0];

    // Insert log
    await insertemployeeLogs(
      employee_id,
      user_id,  // logged-in user id
      "APPRECIATION_CREATE",
      ` ${subject}`
    );

    return res.status(201).json({
      message: "Appreciation created successfully",
      data: newAppreciation
    });



  } catch (error) {
    console.error("Create Appreciation Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


//GET All Appreciations (With Employee Name)
const getAllAppreciations = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT 
          a.appreciation_id,
          a.subject,
          a.description,
          a.created_at,
          e.employee_id,
          e.first_name,
          e.last_name
       FROM appreciations a
       JOIN employees e 
         ON a.employee_id = e.employee_id
       ORDER BY a.created_at DESC`
    );

    return res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Appreciations Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


//GET Appreciation By ID
const getAppreciationById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM appreciations
       WHERE appreciation_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Appreciation not found" });
    }

    return res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Get Appreciation Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

//employee logs
const getAllEmployeeLogs = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT log_id,
              employee_id,
              log_date,
              log_time,
              module,
              comments,
              user_id,
              created_at,
              updated_at
       FROM employee_logs
       ORDER BY log_date DESC, log_time DESC`
    );

    res.status(200).json({
      count: result.rows.length,
      data: result.rows
    });

  } catch (error) {
    console.error("Get All Employee Logs Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};





//CREATE HOLIDAY
const createHoliday = async (req, res) => {
  try {
    const {
      holiday_date,
      holiday_name,
      holiday_type,
      occasion,
      employment_status,
      department_ids,
      designation_ids
    } = req.body;

    if (!holiday_date || !holiday_name) {
      return res.status(400).json({
        message: "Holiday date and name are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO holidays
       (holiday_date, holiday_name, holiday_type, occasion, employment_status, department_ids, designation_ids)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING *`,
      [
        holiday_date,
        holiday_name,
        holiday_type,
        occasion,
        employment_status,
        department_ids || [],
        designation_ids || []
      ]
    );

    await writeAdminLog(
    'EMS | Holiday | CREATE | INFO',
    buildEmsLog({
      status: 'INFO',
      message: `Holiday created: ${result.rows[0].holiday_name}`,
      details: {
        action: 'CREATE Holiday',
        extra: `Date: ${holiday_date}, Type: ${holiday_type ?? 'N/A'}`,
      },
    }),
    req.user?.user_id ?? 1
  );

    res.status(201).json({
      message: "Holiday created successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Create Holiday Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// GET HOLIDAY NAME SUGGESTIONS
const getHolidayNameSuggestions = async (req, res) => {
  try {
    const { q } = req.query
    if (!q || q.trim().length < 2) return res.json([])

    const result = await pool.query(
      `SELECT DISTINCT holiday_name
       FROM holidays
       WHERE holiday_name ILIKE $1
       ORDER BY holiday_name ASC
       LIMIT 8`,
      [`%${q.trim()}%`]
    )
    res.json(result.rows.map(r => ({ holiday_name: r.holiday_name })))
  } catch (error) {
    console.error('Holiday suggestions error:', error)
    res.status(500).json([])
  }
}

//GET ALL HOLIDAYS (With Department + Designation Names)
// ❌ CURRENT — whereClause built but never used in query
const getAllHolidays = async (req, res) => {
  try {
    const { keyword, holiday_type, date_from, date_to } = req.query

    let queryParams = []
    let whereConditions = []

    if (keyword) {
      const trimmed = keyword.trim()
      if (/^\d+$/.test(trimmed)) {
        queryParams.push(parseInt(trimmed))
        whereConditions.push(`h.holiday_id = $${queryParams.length}`)
      } else {
        queryParams.push(`%${trimmed}%`)
        whereConditions.push(`h.holiday_name ILIKE $${queryParams.length}`)
      }
    }

    if (holiday_type) {
      queryParams.push(holiday_type)
      whereConditions.push(`h.holiday_type = $${queryParams.length}`)
    }

    if (date_from) {
      queryParams.push(date_from)
      whereConditions.push(`h.holiday_date >= $${queryParams.length}`)
    }

    if (date_to) {
      queryParams.push(date_to)
      whereConditions.push(`h.holiday_date <= $${queryParams.length}`)
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(' AND ')}`
      : ''

    // ✅ FIX — add ${whereClause} and pass queryParams to the query
    const result = await pool.query(`
      SELECT 
          h.holiday_id,
          h.holiday_date,
          h.holiday_name,
          h.holiday_type,
          h.occasion,
          h.employment_status,
          h.department_ids,
          h.designation_ids,
          ARRAY_AGG(DISTINCT d.department_name) AS departments,
          ARRAY_AGG(DISTINCT ds.designation_name) AS designations
      FROM holidays h
      LEFT JOIN departments d ON d.department_id = ANY(h.department_ids)
      LEFT JOIN designations ds ON ds.designation_id = ANY(h.designation_ids)
      ${whereClause}
      GROUP BY 
          h.holiday_id, h.holiday_date, h.holiday_name,
          h.holiday_type, h.occasion, h.employment_status,
          h.department_ids, h.designation_ids
      ORDER BY h.holiday_id DESC
    `, queryParams)  // ✅ queryParams passed here

       const updatedRows = result.rows.map(row => {
      const date = new Date(row.holiday_date);
      date.setDate(date.getDate() + 1); // 👈 add 1 day

      return {
        ...row,
        holiday_date: date
      };
    });

    res.status(200).json(updatedRows)

  } catch (error) {
    console.error('Fetch Holidays Error:', error)
    res.status(500).json({ message: 'Internal Server Error' })
  }
}


//GET HOLIDAY BY ID
const getHolidayById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM holidays WHERE holiday_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Holiday not found"
      });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Holiday Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


//UPDATE HOLIDAY
const updateHoliday = async (req, res) => {
  const { id } = req.params;

  try {
    const {
      holiday_date,
      holiday_name,
      holiday_type,
      occasion,
      employment_status,
      department_ids,
      designation_ids
    } = req.body;

    const result = await pool.query(
      `UPDATE holidays
       SET holiday_date = $1,
           holiday_name = $2,
           holiday_type = $3,
           occasion = $4,
           employment_status = $5,
           department_ids = $6,
           designation_ids = $7,
           updated_at = CURRENT_TIMESTAMP
       WHERE holiday_id = $8
       RETURNING *`,
      [
        holiday_date,
        holiday_name,
        holiday_type,
        occasion,
        employment_status,
        department_ids || [],
        designation_ids || [],
        id
      ]
    );
    

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Holiday not found"
      });
    }

    await writeAdminLog(
      'EMS | Holiday | UPDATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Holiday updated: ${result.rows[0].holiday_name}`,
        details: { action: 'UPDATE Holiday', extra: `ID: ${id}, Date: ${holiday_date}` },
      }),
      req.user?.user_id ?? 1
    );

    res.status(200).json({
      message: "Holiday updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Holiday Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};



// CREATE SHIFT ROSTER
const createShiftRoster = async (req, res) => {
  
  const { employee_ids, shift_id, roster_date, remarks } = req.body
  
  try {
    

    console.log('=== ROSTER DATE DEBUG ===')
    console.log('roster_date received from frontend:', roster_date)
    console.log('typeof roster_date:', typeof roster_date)

    if (!employee_ids || employee_ids.length === 0 || !shift_id || !roster_date) {
      return res.status(400).json({ message: "Employee(s), Shift, and Date are required" })
    }

    const createdRosters = []

    for (let employee_id of employee_ids) {
      // 1. Upsert the roster entry
      const result = await pool.query(
  `INSERT INTO shift_roster (employee_id, shift_id, roster_date, remarks)
   VALUES ($1, $2, $3, $4)
   ON CONFLICT (employee_id, roster_date) DO UPDATE
   SET shift_id = EXCLUDED.shift_id,
       remarks  = EXCLUDED.remarks,
       updated_at = CURRENT_TIMESTAMP
   RETURNING 
     roster_id, 
     employee_id, 
     shift_id, 
     roster_date::text AS roster_date, 
     remarks, 
     created_at, 
     updated_at`,
  [employee_id, shift_id, roster_date, remarks || null]
)


      console.log('roster saved to DB:', result.rows[0].roster_date)
      console.log('roster_date raw from DB:', JSON.stringify(result.rows[0].roster_date))

      const roster = result.rows[0]
    console.log('roster saved to DB:', roster.roster_date)
console.log('roster_date raw from DB:', JSON.stringify(roster.roster_date))
      createdRosters.push(roster)

      await writeAdminLog(
      'EMS | Roster | CREATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Shift roster assigned to employee ${employee_id}`,
        details: {
          action: 'CREATE Shift Roster',
          employee_id,
          roster_id: roster.roster_id,
          shift_id,
          extra: `Date: ${roster_date}`,
        },
      }),
      req.user?.user_id ?? 1
    );

      // Get employee + shift details
const empShiftResult = await pool.query(
        `SELECT 
            e.first_name,
            e.last_name,
            e.contact_no,
            e.email,
            s.shift_name,
            s.shift_in_time,
            s.shift_out_time
         FROM employees e
         LEFT JOIN shifts s ON s.id = $1
         WHERE e.employee_id = $2`,
        [shift_id, employee_id]
      );

      const empShift = empShiftResult.rows[0];
      const employee_mobile = empShift?.contact_no || null;
      const employee_email = empShift?.email || null;
      const first_name = empShift?.first_name || null;
      const last_name = empShift?.last_name || null;

      // 3️⃣ Send shift roster notification
      let hookResponse = null;
      try {
        hookResponse = await customhookShiftRoster(
          16,              // actionId
          roster.roster_id, // roster_id  ← use the saved roster's ID
          employee_mobile,  // employee_mobile
          employee_email,   // employee_email (not used in SMS but kept for email hook)
          first_name,
          last_name,
          empShift.shift_name,
          empShift.shift_in_time,
          empShift.shift_out_time,
          roster_date
        );
      } catch (hookError) {
        console.error("Custom hook (shift roster) failed:", hookError);
      }


      // 2. Check if attendance already exists for this employee on this date
      const attendanceCheck = await pool.query(
        `SELECT attendance_id, attendance_status_id
        FROM attendance
        WHERE employee_id = $1
          AND check_in_date::date = DATE '${roster_date}'`,
        [employee_id]
      )

      if (attendanceCheck.rows.length > 0) {
        const attendance = attendanceCheck.rows[0]

        // 3. Update the attendance shift_id and roster_id
        await pool.query(
          `UPDATE attendance
          SET shift_id  = $1,
              roster_id = $2
          WHERE attendance_id = $3`,
          [shift_id, roster.roster_id, attendance.attendance_id]
        )

        // 4. Recalculate LATE status based on new shift
        const attendanceDetail = await pool.query(
          `SELECT clock_in_time FROM attendance WHERE attendance_id = $1`,
          [attendance.attendance_id]
        )

        const clock_in_time = attendanceDetail.rows[0]?.clock_in_time

        if (clock_in_time) {
          const shiftRes = await pool.query(
            `SELECT shift_in_time, grace_period_minutes FROM shifts WHERE id = $1`,
            [shift_id]
          )

          if (shiftRes.rows.length > 0) {
            const shiftInTime = shiftRes.rows[0].shift_in_time
            const gracePeriodMinutes = Number(shiftRes.rows[0].grace_period_minutes) || 0

            const toMins = (t) => {
              const [h, m] = String(t).split(':').map(Number)
              return h * 60 + m
            }

            const clockInMins = toMins(clock_in_time)
            const shiftInMins = toMins(shiftInTime)
            const deadlineMins = shiftInMins + gracePeriodMinutes
            const late = clockInMins > deadlineMins

            // 5. Update attendance_status with recalculated late flag
            await pool.query(
              `UPDATE attendance_status
               SET late = $1
               WHERE status_id = $2`,
              [late, attendance.attendance_status_id]
            )
          }
        }
      }
    }

    res.status(201).json({ message: "Shift roster(s) assigned", data: createdRosters })

  } catch (error) {
    await writeAdminLog(
    'EMS | Roster | CREATE | ERROR',
    buildEmsLog({ status: 'ERROR', message: 'Failed to create shift roster', fail_reason: error.message, details: { action: 'CREATE Shift Roster', shift_id: shift_id ?? 'unknown', extra: `Date: ${roster_date}` } }),
    req.user?.user_id ?? 1
  );
    console.error("Create Shift Roster Error:", error)
    res.status(500).json({ message: "Internal Server Error" })
  }
}


// GET ALL SHIFT ROSTERS (with employee and shift details)

const getAllShiftRosters = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT sr.*, CONCAT(e.first_name, ' ', e.last_name) AS employee_name, s.shift_name
      FROM shift_roster sr
      LEFT JOIN employees e ON e.employee_id = sr.employee_id
      LEFT JOIN shifts s ON s.id = sr.shift_id
      ORDER BY sr.roster_id DESC
    `);

    const updatedRows = result.rows.map(row => {
      const date = new Date(row.roster_date);
      date.setDate(date.getDate() + 1); // 👈 add 1 day

      return {
        ...row,
        roster_date: date
      };
    });

    res.status(200).json(updatedRows);
  } catch (error) {
    console.error("Fetch Shift Rosters Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
}
// GET SHIFT ROSTER BY ID
const getShiftRosterById = async (req, res) => {
  const { id } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM shift_roster WHERE roster_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Roster not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Fetch Shift Roster Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//added by senesh
const getRosterByMonth = async (req, res) => {
  try {
    const { year, month } = req.query


    if (!year || !month) {
      return res.status(400).json({ message: "year and month are required" })
    }

    const result = await pool.query(`
      SELECT 
        sr.roster_id,
        sr.employee_id,
        sr.shift_id,
        sr.roster_date::text AS roster_date,
        sr.remarks,
        TO_CHAR(sr.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at,
        TO_CHAR(sr.updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS updated_at,
        CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
        s.shift_name
      FROM shift_roster sr
      LEFT JOIN employees e ON e.employee_id = sr.employee_id
      LEFT JOIN shifts s ON s.id = sr.shift_id
      WHERE EXTRACT(YEAR FROM sr.roster_date) = $1
        AND EXTRACT(MONTH FROM sr.roster_date) = $2
      ORDER BY sr.roster_id ASC
    `, [year, month])

    res.status(200).json(result.rows)

  } catch (error) {
    console.error("Fetch Shift Rosters Error:", error)
    res.status(500).json({ message: "Internal Server Error" })
  }
}

// UPDATE SHIFT ROSTER
const updateShiftRoster = async (req, res) => {
  const { id } = req.params;
  const { employee_id, shift_id, roster_date, remarks } = req.body;

  try {
    const result = await pool.query(
      `UPDATE shift_roster
       SET employee_id = $1,
           shift_id = $2,
           roster_date = $3,
           remarks = $4,
           updated_at = CURRENT_TIMESTAMP
       WHERE roster_id = $5
       RETURNING *`,
      [employee_id, shift_id, roster_date, remarks || null, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Roster not found" });
    }

    res.status(200).json({ message: "Roster updated", data: result.rows[0] });

  } catch (error) {
    console.error("Update Shift Roster Error:", error);
    if (error.code === '23505') { // unique violation
      return res.status(400).json({ message: "Roster for this employee, shift, and date already exists" });
    }
    res.status(500).json({ message: "Internal Server Error" });
  }
};


//addedbysenesh
// const getLeaveBalanceByEmployee = async (req, res) => {
//   const { employee_id } = req.params;

//   try {
//     // Get employee's designation
//     const empResult = await pool.query(
//       `SELECT designation_id FROM employees WHERE employee_id = $1`,
//       [employee_id]
//     );

//     if (empResult.rows.length === 0) {
//       return res.status(404).json({ message: "Employee not found" });
//     }

//     const designation_id = empResult.rows[0].designation_id;

//     // Get designation leave allocations
//     const desigResult = await pool.query(
//       `SELECT sick_leave, casual_leave, annual_leave
//        FROM designations WHERE designation_id = $1`,
//       [designation_id]
//     );

//     if (desigResult.rows.length === 0) {
//       return res.status(404).json({ message: "Designation not found" });
//     }

const getLeaveBalanceByEmployee = async (req, res) => {
  const { employee_id } = req.params;
  try {
    // Get employee's designation
    const empResult = await pool.query(
      `SELECT designation_id FROM employees WHERE employee_id = $1`,
      [employee_id]
    );
    if (empResult.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }
    const designation_id = empResult.rows[0].designation_id;
    // Get designation leave allocations
    const desigResult = await pool.query(
      `SELECT sick_leave, casual_leave, annual_leave
       FROM designations WHERE designation_id = $1`,
      [designation_id]
    );
    if (desigResult.rows.length === 0) {
      return res.status(404).json({ message: "Designation not found" });
    }
    const desig = desigResult.rows[0];
    // Get leave types
    const leaveTypesResult = await pool.query(
      `SELECT leave_type_id, name FROM leave_types ORDER BY leave_type_id ASC`
    );
    // Get used approved paid leaves per type
    const usedResult = await pool.query(
      `SELECT 
          leave_type_id,
          SUM(
            CASE 
              WHEN duration_type = 'first_half' OR duration_type = 'second_half' THEN 0.5
              ELSE (to_date::date - from_date::date + 1)
            END
          ) AS used_days
       FROM leaves
       WHERE employee_id = $1
         AND status = 'Approved'
         AND paid_status = 'paid'
       GROUP BY leave_type_id`,
      [employee_id]
    );
    // Map used days by leave_type_id
    const usedMap = {};
    usedResult.rows.forEach((r) => {
      usedMap[r.leave_type_id] = parseFloat(r.used_days) || 0;
    });
    // Build balance array
    const balances = leaveTypesResult.rows.map((lt) => {
      const name = lt.name.toLowerCase();
      let allocated = 0;
      if (name.includes('sick')) allocated = parseFloat(desig.sick_leave) || 0;
      if (name.includes('casual')) allocated = parseFloat(desig.casual_leave) || 0;
      if (name.includes('annual')) allocated = parseFloat(desig.annual_leave) || 0;

      const used = usedMap[lt.leave_type_id] || 0;
      const remaining = Math.max(0, allocated - used);
      return {
        leave_type_id: lt.leave_type_id,
        leave_type_name: lt.name,
        allocated,
        used,
        remaining,
      };
    });
    return res.status(200).json(balances);
  } catch (error) {
    console.error("Get Leave Balance Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

//     // Get leave types
//     const leaveTypesResult = await pool.query(
//       `SELECT leave_type_id, name FROM leave_types ORDER BY leave_type_id ASC`
//     );

//     // Get used approved paid leaves per type
//     const usedResult = await pool.query(
//       `SELECT 
//           leave_type_id,
//           SUM(
//             CASE 
//               WHEN duration_type = 'first_half' OR duration_type = 'second_half' THEN 0.5
//               ELSE (to_date::date - from_date::date + 1)
//             END
//           ) AS used_days
//        FROM leaves
//        WHERE employee_id = $1
//          AND status = 'Approved'
//          AND paid_status = 'paid'
//        GROUP BY leave_type_id`,
//       [employee_id]
//     );

//     // Map used days by leave_type_id
//     const usedMap = {};
//     usedResult.rows.forEach((r) => {
//       usedMap[r.leave_type_id] = parseFloat(r.used_days) || 0;
//     });

//     // Build balance array
//     const balances = leaveTypesResult.rows.map((lt) => {
//       const name = lt.name.toLowerCase();
//       let allocated = 0;

//       if (name.includes('sick'))   allocated = parseFloat(desig.sick_leave)   || 0;
// if (name.includes('casual')) allocated = parseFloat(desig.casual_leave) || 0;
// if (name.includes('annual')) allocated = parseFloat(desig.annual_leave) || 0;
// //change upper three line by senesh
//       const used      = usedMap[lt.leave_type_id] || 0;
//       const remaining = Math.max(0, allocated - used);

//       return {
//         leave_type_id:   lt.leave_type_id,
//         leave_type_name: lt.name,
//         allocated,
//         used,
//         remaining,
//       };
//     });

//     return res.status(200).json(balances);

//   } catch (error) {
//     console.error("Get Leave Balance Error:", error);
//     return res.status(500).json({ message: "Internal Server Error" });
//   }
// };


// GENERATE PAYSHEET
const generatePaysheet = async (req, res = null) => {
  const client = await pool.connect();

  const normalizeType = (t) => {
    const upper = (t ?? '').toUpperCase()
    if (upper === 'EARNINGS') return 'EARNING'
    if (upper === 'DEDUCTIONS') return 'DEDUCTION'
    return upper
  }

  try {
    await client.query("BEGIN");

    // REPLACE WITH THIS:
const {
  employee_id,
  payroll_month,
  payroll_year,
  salary_range_start,
  salary_range_end,
  line_items = [],
  total_earnings = null,
  total_deductions = null,
  net_salary = null,
  generation_type = 'MANUAL',   // ← default is now MANUAL
} = req.body;

const user_id = req.user?.user_id;

// ── Guard: block manual UI calls for AUTO employees ──────────────────────────
if (generation_type === 'MANUAL') {
  const empGenRes = await client.query(
    `SELECT e.salary_generation_type, pt.payroll_type
     FROM employees e
     LEFT JOIN payroll_templates pt ON e.payroll_template_id = pt.id
     WHERE e.employee_id = $1`,
    [employee_id]
  );

  const empGenType = empGenRes.rows[0]?.salary_generation_type;

  if (empGenType === 'AUTO') {
    await client.query("ROLLBACK");
    const msg = "This employee is set to AUTO paysheet generation. Manual generation is disabled.";
    if (res) return res.status(403).json({ message: msg });
    else return { message: msg, error: true };
  }
}
    // ── Duplicate check ───────────────────────────────────────────────────
    const duplicate = await client.query(
      `SELECT paysheet_id FROM paysheets
       WHERE employee_id=$1 AND payroll_month=$2 AND payroll_year=$3`,
      [employee_id, payroll_month, payroll_year]
    );
    if (duplicate.rows.length > 0) {
      await client.query("ROLLBACK");
      if (res) return res.status(400).json({ message: "Paysheet already exists" });
      else return { message: "Paysheet already exists" };
    }

    // ── Employee info ─────────────────────────────────────────────────────
    const empRes = await client.query(
      `SELECT
          e.employee_id,
          e.payroll_template_id,
          CONCAT(e.first_name,' ',COALESCE(e.middle_name||' ',''),e.last_name) AS employee_name
       FROM employees e WHERE e.employee_id=$1`,
      [employee_id]
    );
    if (empRes.rows.length === 0) {
      await client.query("ROLLBACK");
      if (res) return res.status(404).json({ message: "Employee not found" });
      else return { message: "Employee not found" };
    }
    const { payroll_template_id, employee_name } = empRes.rows[0];

    // ── Fetch OT rates + no-pay rate from payroll template ────────────────
    const templateRateRes = await client.query(
      `SELECT ot_hour_rate, holiday_ot_hour_rate, no_pay_deduction_rate
       FROM payroll_templates
       WHERE id = $1`,
      [payroll_template_id]
    );
    if (!templateRateRes.rows.length) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Payroll template not found" });
    }
    const ot_hour_rate = Number(templateRateRes.rows[0].ot_hour_rate) || 0;
    const holiday_ot_hour_rate = Number(templateRateRes.rows[0].holiday_ot_hour_rate) || 0;
    const no_pay_deduction_rate = Number(templateRateRes.rows[0].no_pay_deduction_rate) || 0;

    // ── Attendance summary (with OT minutes) ─────────────────────────────
    const att = await client.query(
      `SELECT
         COUNT(*) FILTER (WHERE s.present=true)  AS present_days,
         COUNT(*) FILTER (WHERE s.absent=true)   AS absent_days,
         COUNT(*) FILTER (WHERE s.halfday=true)  AS half_days,
         COUNT(*) FILTER (WHERE s.late=true)     AS late_count,

         -- Holiday OT: only counts if employee worked past shift_out_time
         -- after_ot_minutes is the THRESHOLD (must work at least this many minutes OT)
         -- max_ot_minutes is the HARD CAP per day
         COALESCE(SUM(
           CASE
             WHEN h.holiday_date IS NOT NULL
                  AND a.clock_out_time IS NOT NULL
                  AND a.clock_out_time > sh.shift_out_time
                  AND EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60
                      >= sh.holiday_ot_minutes
             THEN LEAST(
               EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS holiday_overtime_minutes,

         -- Normal After-Shift OT:
         -- after_ot_minutes = threshold (employee must stay at least this many mins past shift end)
         -- max_ot_minutes   = hard cap on payable OT per day
         -- Example: after_ot_minutes=60, max=120, employee stays 45min → 0 OT (threshold not met)
         -- Example: after_ot_minutes=60, max=120, employee stays 90min → 90min OT paid
         -- Example: after_ot_minutes=60, max=120, employee stays 150min → 120min OT paid (capped)
         COALESCE(SUM(
           CASE
             WHEN h.holiday_date IS NULL
                  AND a.clock_out_time IS NOT NULL
                  AND a.clock_out_time > sh.shift_out_time
                  AND EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60
                      >= sh.after_ot_minutes
             THEN LEAST(
               EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS normal_overtime_minutes,

         -- Early OT: employee arrives before shift_in_time
         -- early_ot_minutes = max early OT window allowed (also acts as cap)
         -- max_ot_minutes   = hard cap per day (shared with after OT)
         -- Example: early_ot_minutes=60, employee arrives 30min early → 30min early OT paid
         -- Example: early_ot_minutes=60, employee arrives 90min early → 60min early OT paid (capped)
         COALESCE(SUM(
           CASE
             WHEN h.holiday_date IS NULL
                  AND a.clock_in_time IS NOT NULL
                  AND a.clock_in_time < sh.shift_in_time
             THEN LEAST(
               EXTRACT(EPOCH FROM (sh.shift_in_time::time - a.clock_in_time::time)) / 60,
               sh.early_ot_minutes,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS early_overtime_minutes

       FROM attendance a
       JOIN attendance_status s  ON a.attendance_status_id = s.status_id
       JOIN shifts sh             ON a.shift_id = sh.id
       LEFT JOIN holidays h       ON a.check_in_date = h.holiday_date
       WHERE a.employee_id=$1 AND a.check_in_date BETWEEN $2 AND $3`,
      [employee_id, salary_range_start, salary_range_end]
    );

    const sm = att.rows[0];
    const presentDays = Number(sm.present_days || 0);
    const absentDays = Number(sm.absent_days || 0);
    const halfDays = Number(sm.half_days || 0);
    const lateCount = Number(sm.late_count || 0);
    const workingDays = presentDays + absentDays + halfDays;

    const normalOtHours   = Number(sm.normal_overtime_minutes  || 0) / 60;
    const holidayOtHours  = Number(sm.holiday_overtime_minutes || 0) / 60;
    const earlyOtHours    = Number(sm.early_overtime_minutes   || 0) / 60;

    // ── Unpaid leave days ─────────────────────────────────────────────────
    const unpaidLeaveRes = await client.query(
      `SELECT COUNT(*) AS unpaid_leave_days
       FROM leaves l
       CROSS JOIN generate_series(l.from_date, l.to_date, interval '1 day') d(day)
       WHERE l.employee_id=$1
         AND l.status='Approved'
         AND l.paid_status='unpaid'
         AND d.day BETWEEN $2 AND $3`,
      [employee_id, salary_range_start, salary_range_end]
    );
    const unpaidLeaveDays = Number(unpaidLeaveRes.rows[0].unpaid_leave_days || 0);

    // ── No-pay rule ───────────────────────────────────────────────────────
    const lateNoPayDays = Math.floor(lateCount / 3);
    const totalNoPayDays = absentDays + unpaidLeaveDays + lateNoPayDays;

    // ── Insert paysheet header (totals updated at the end) ────────────────
    // REPLACE WITH THIS:
const psRes = await client.query(
  `INSERT INTO paysheets
   (employee_id, employee_name,
    salary_range_start, salary_range_end,
    payroll_month, payroll_year,
    total_working_days, present_days, absent_days, half_days, late_count,
    payroll_status, payroll_template_id)
   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'GENERATED',$12)
   RETURNING *`,
  [
    employee_id, employee_name,
    salary_range_start, salary_range_end,
    payroll_month, payroll_year,
    workingDays, presentDays, absentDays, halfDays, lateCount,
    payroll_template_id,
  ]
);

    const paysheet_id = psRes.rows[0].paysheet_id;

    // ── Insert wizard line items (template items + custom items) ──────────
    let finalEarnings = 0;
    let finalDeductions = 0;

    if (line_items.length > 0) {
      // Frontend sent wizard items — use them (edited amounts + custom items)
      for (const item of line_items) {
        const edId = item.earning_deduction_id ? Number(item.earning_deduction_id) : null;
        const itemType = normalizeType(item.type);
        const itemAmount = Number(item.amount) || 0;

        if (itemType === 'EARNING') finalEarnings += itemAmount;
        if (itemType === 'DEDUCTION') finalDeductions += itemAmount;

        if (edId) {
          await client.query(
            `INSERT INTO paysheet_details
               (paysheet_id, earning_deduction_id, earning_deduction_name, type, amount)
             VALUES ($1,$2,$3,$4,$5)`,
            [paysheet_id, edId, item.name ?? null, itemType, itemAmount]
          );
        } else {
          await client.query(
            `INSERT INTO paysheet_details
               (paysheet_id, earning_deduction_name, type, amount)
             VALUES ($1,$2,$3,$4)`,
            [paysheet_id, item.name ?? null, itemType, itemAmount]
          );
        }
      }
    } else {
      // No wizard items sent — fallback: load from template
      const templateDetails = await client.query(
        `SELECT ptd.*,
                COALESCE(ptd.earning_deduction_name, ed.name) AS resolved_name,
                ed.type AS ed_type, ed.calculation_type
         FROM payroll_template_details ptd
         LEFT JOIN earnings_deductions ed ON ptd.earning_deduction_id = ed.id
         WHERE ptd.payroll_template_id=$1`,
        [payroll_template_id]
      );

      for (const row of templateDetails.rows) {
        let amount = Number(row.amount);
        if (row.calculation_type === 'PERCENTAGE' || row.calculation_type === 'PERCENT') {
          const base = templateDetails.rows
            .filter(t => ['EARNING', 'EARNINGS'].includes((t.ed_type ?? '').toUpperCase()))
            .reduce((s, t) => s + Number(t.value || t.amount), 0);
          amount = (base * Number(row.value)) / 100;
        }

        const rowType = normalizeType(row.ed_type ?? row.type);
        if (rowType === 'EARNING') finalEarnings += amount;
        if (rowType === 'DEDUCTION') finalDeductions += amount;

        await client.query(
          `INSERT INTO paysheet_details
             (paysheet_id, earning_deduction_id, earning_deduction_name, type, amount)
           VALUES ($1,$2,$3,$4,$5)`,
          [paysheet_id, row.earning_deduction_id, row.resolved_name, rowType, amount]
        );
      }
    }

    // ── Auto-insert: Normal OT ────────────────────────────────────────────
    // ── Auto-insert: Normal After-Shift OT ───────────────────────────────
    let normalOtAmount  = 0;
    let holidayOtAmount = 0;
    let earlyOtAmount   = 0;
    let noPayAmount     = 0;

    if (normalOtHours > 0 && ot_hour_rate > 0) {
      normalOtAmount = parseFloat((normalOtHours * ot_hour_rate).toFixed(2));
      finalEarnings += normalOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
           (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Normal Overtime','EARNING',$2)`,
        [paysheet_id, normalOtAmount]
      );
    }

    // ── Auto-insert: Early OT ─────────────────────────────────────────────
    // Uses same ot_hour_rate as normal OT
    // early_ot_minutes on the shift acts as both threshold-window and cap
    if (earlyOtHours > 0 && ot_hour_rate > 0) {
      earlyOtAmount = parseFloat((earlyOtHours * ot_hour_rate).toFixed(2));
      finalEarnings += earlyOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
           (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Early Overtime','EARNING',$2)`,
        [paysheet_id, earlyOtAmount]
      );
    }

    // ── Auto-insert: Holiday OT ───────────────────────────────────────────
    if (holidayOtHours > 0 && holiday_ot_hour_rate > 0) {
      holidayOtAmount = parseFloat((holidayOtHours * holiday_ot_hour_rate).toFixed(2));
      finalEarnings += holidayOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
           (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Holiday Overtime','EARNING',$2)`,
        [paysheet_id, holidayOtAmount]
      );
    }
    // AUTO UNPAID LEAVE DEDUCTION

    // ── Auto-insert: No-Pay deduction ─────────────────────────────────────
    // totalNoPayDays = absentDays + unpaidLeaveDays + lateNoPayDays (every 3 lates = 1 day)
    // no_pay_deduction_rate is a flat rate per no-pay day (set in payroll template)
    // This is the SINGLE deduction block for all no-pay scenarios — do NOT add a
    // separate absent-days or late-penalty block, as that would double-count.
    // ── Auto-insert: No-Pay deduction (absent + unpaid leave) ─────────────────
    const noPayOnlyDays = absentDays + unpaidLeaveDays;
    if (noPayOnlyDays > 0 && no_pay_deduction_rate > 0) {
      noPayAmount = parseFloat((noPayOnlyDays * no_pay_deduction_rate).toFixed(2));
      finalDeductions += noPayAmount;
      await client.query(
        `INSERT INTO paysheet_details
          (paysheet_id, earning_deduction_name, type, amount)
        VALUES ($1,'No Pay Deduction','DEDUCTION',$2)`,
        [paysheet_id, noPayAmount]
      );
    }

    // ── Auto-insert: Late deduction (every 3 lates = 1 day deduction) ─────────
    let lateDeductionAmount = 0;
    if (lateNoPayDays > 0 && no_pay_deduction_rate > 0) {
      lateDeductionAmount = parseFloat((lateNoPayDays * no_pay_deduction_rate).toFixed(2));
      finalDeductions += lateDeductionAmount;
      await client.query(
        `INSERT INTO paysheet_details
          (paysheet_id, earning_deduction_name, type, amount)
        VALUES ($1,'Late Deduction','DEDUCTION',$2)`,
        [paysheet_id, lateDeductionAmount]
      );
    }

    // ── Update paysheet with final totals ─────────────────────────────────
    const finalNet = finalEarnings - finalDeductions;

    await client.query(
      `UPDATE paysheets
       SET total_earnings=$1, total_deductions=$2, net_salary=$3
       WHERE paysheet_id=$4`,
      [finalEarnings, finalDeductions, finalNet, paysheet_id]
    );


    // INSERT SYSTEM LOG
    
  await insertSystemLog(
  user_id, // logged-in user id
  "Paysheet_Create",
  `Paysheet generated for ${employee_name} (${payroll_month}/${payroll_year})`
);

  await client.query("COMMIT");

    await writeAdminLog(
      'EMS | Paysheet | GENERATE | INFO',
      buildEmsLog({
        status: 'INFO',
        message: `Paysheet generated for ${employee_name}`,
        details: {
          action: 'GENERATE Paysheet',
          employee_id,
          employee_name,
          paysheet_id,
          payroll_month,
          payroll_year: payroll_year,
          extra: `Earnings: ${finalEarnings}, Deductions: ${finalDeductions}, Net: ${finalNet}`,
        },
      }),
      user_id
    );

if (res) {
    return res.status(201).json({
  message: "Paysheet generated successfully",
  paysheet_id,
  employee_name,
  total_earnings: finalEarnings,
  total_deductions: finalDeductions,
  net_salary: finalNet,
  normal_ot_amount: normalOtAmount,
  early_ot_amount: earlyOtAmount,
  holiday_ot_amount: holidayOtAmount,
  no_pay_amount: noPayAmount,
  late_deduction_amount: lateDeductionAmount,
  absent_days: absentDays,
  unpaid_leave_days: unpaidLeaveDays,
  late_no_pay_days: lateNoPayDays,
  total_no_pay_days: totalNoPayDays,
});

    } else {
  return {
    paysheet_id,
    employee_name,
    total_earnings: finalEarnings,
    total_deductions: finalDeductions,
    net_salary: finalNet
  };
}

  } catch (error) {
    await writeAdminLog(
    'EMS | Paysheet | GENERATE | CRITICAL',
    buildEmsLog({
      status: 'CRITICAL',
      message: 'Paysheet generation failed — transaction rolled back',
      fail_reason: error.message,
      details: { action: 'GENERATE Paysheet', employee_id: req.body?.employee_id, payroll_month: req.body?.payroll_month, payroll_year: req.body?.payroll_year },
    }),
    req.user?.user_id ?? 1
  );
    await client.query("ROLLBACK");
    console.error("Generate Paysheet Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};


// LOCK / UPDATE PAYROLL STATUS

const updatePaysheetStatus = async (req, res) => {
  try {
    const { paysheet_id } = req.params;
    const { status, payslip_url: payslip_url_from_body = '' } = req.body;

    // 1. Fetch paysheet
    const paysheetRes = await pool.query(
  `SELECT p.payroll_status, p.employee_id,
          e.salary_generation_type AS generation_type
   FROM paysheets p
   JOIN employees e ON p.employee_id = e.employee_id
   WHERE p.paysheet_id = $1`,
  [paysheet_id]
);

    if (paysheetRes.rows.length === 0) {
      return res.status(404).json({ message: "Paysheet not found" });
    }

    // ✅ Destructure ONCE — fixes "not defined" errors
    const { payroll_status, employee_id, generation_type } = paysheetRes.rows[0];

    // ✅ Single locked check using the destructured variable
    if (["APPROVED", "PAID"].includes(payroll_status)) {
      return res.status(400).json({ message: "Payroll locked. Cannot modify." });
    }

    // ✅ generation_type is now defined
    if (generation_type === 'AUTO' && status === 'DRAFT') {
      return res.status(400).json({
        message: "Cannot set AUTO-generated paysheet back to DRAFT."
      });
    }

    // 2. Update payroll status
    const result = await pool.query(
      `UPDATE paysheets
       SET payroll_status = $1, updated_at = CURRENT_TIMESTAMP
       WHERE paysheet_id = $2
       RETURNING *`,
      [status, paysheet_id]
    );

    // 3. Fetch payslip URL from paysheet_invoices table
    const invoiceRes = await pool.query(
      `SELECT payslip_url 
       FROM paysheet_invoices 
       WHERE paysheet_detail_id = $1 
       ORDER BY created_at DESC 
       LIMIT 1`,
      [paysheet_id]
    );

    const payslip_url = invoiceRes.rows[0]?.payslip_url || "";

    // 4. Fetch employee contact info
    const empContact = await pool.query(
      `SELECT first_name, last_name, contact_no, email
       FROM employees
       WHERE employee_id = $1`,
      [employee_id]   // ✅ now uses the destructured variable
    );

    const employee = empContact.rows[0];

    if (employee) {
      const employee_mobile = employee.contact_no || null;
      const employee_email  = employee.email || null;
      const first_name      = employee.first_name || "";
      const last_name       = employee.last_name || "";

      try {
        await customhookPaysheet(
          17,
          paysheet_id,
          employee_email,
          employee_mobile,
          payslip_url_from_body,
          first_name,
          last_name
        );
        console.log("✅ Paysheet notification sent");
      } catch (hookError) {
        console.error("❌ Failed to send paysheet notification:", hookError);
      }
    }

    await writeAdminLog(
    'EMS | Paysheet | STATUS_UPDATE | INFO',
    buildEmsLog({
      status: 'INFO',
      message: `Paysheet status changed to ${status}`,
      details: {
        action: 'UPDATE Paysheet Status',
        paysheet_id,
        employee_id,
        extra: `New Status: ${status}`,
      },
    }),
    req.user?.user_id ?? 1
  );

    res.status(200).json({ message: "Status updated", data: result.rows[0] });

  } catch (error) {
    console.error("Update Paysheet Status Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// Get all paysheets with optional filters
const getAllPaysheets = async (req, res) => {
  try {
    const { keyword, date_from, date_to, status, page = 1, per_page = 10 } = req.query

    const parsedPage  = parseInt(page, 10)
    const parsedLimit = parseInt(per_page, 10)
    const offset      = (parsedPage - 1) * parsedLimit

    const queryParams     = []
    const whereConditions = []

    if (keyword) {
      const trimmed = keyword.trim()
      if (/^\d+$/.test(trimmed)) {
        queryParams.push(parseInt(trimmed, 10))
        whereConditions.push(`p.employee_id = $${queryParams.length}`)
      } else {
        // ← FIX: search each word separately so "John Doe" matches
        const words = trimmed.split(/\s+/).filter(Boolean)
        words.forEach(word => {
          queryParams.push(`%${word}%`)
          const n = queryParams.length
          whereConditions.push(
            `(e.first_name ILIKE $${n} OR e.middle_name ILIKE $${n} OR e.last_name ILIKE $${n})`
          )
        })
      }
    }

    if (date_from) {
      queryParams.push(date_from)
      whereConditions.push(`p.salary_range_start >= $${queryParams.length}`)
    }

    if (date_to) {
      queryParams.push(date_to)
      whereConditions.push(`p.salary_range_end <= $${queryParams.length}`)
    }

    if (status) {
      queryParams.push(status.trim().toUpperCase())
      whereConditions.push(`UPPER(p.payroll_status) = $${queryParams.length}`)
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(' AND ')}`
      : ''

    const countResult = await pool.query(
      `SELECT COUNT(*) AS total
       FROM paysheets p
       LEFT JOIN employees e ON p.employee_id = e.employee_id
       ${whereClause}`,
      queryParams
    )
    const total = parseInt(countResult.rows[0].total, 10)

    const dataResult = await pool.query(
      `SELECT
         p.*,
         e.first_name || ' ' || COALESCE(e.middle_name || ' ', '') || e.last_name AS employee_full_name,
         d.designation_name,
         dept.department_name,
         o.name AS outlet_name
       FROM paysheets p
       LEFT JOIN employees e    ON p.employee_id = e.employee_id
       LEFT JOIN designations d ON e.designation_id = d.designation_id
       LEFT JOIN departments dept ON e.department_id = dept.department_id
       LEFT JOIN outlets o      ON e.outlet_id = o.outlet_id
       ${whereClause}
       ORDER BY p.payroll_year DESC, p.payroll_month DESC
       LIMIT $${queryParams.length + 1}
       OFFSET $${queryParams.length + 2}`,
      [...queryParams, parsedLimit, offset]
    )

    res.status(200).json({
      message: 'Paysheets fetched successfully',
      data:       dataResult.rows,
      total,
      page:       parsedPage,
      per_page:   parsedLimit,
      totalPages: Math.ceil(total / parsedLimit),
    })

  } catch (error) {
    console.error('Get Paysheets Error:', error)
    res.status(500).json({ message: 'Internal Server Error' })
  }
}



//Get Paysheet By Id
const getPaysheetById = async (req, res) => {
  try {
    const { paysheet_id } = req.params;

    const result = await pool.query(
      `SELECT * FROM paysheets WHERE paysheet_id = $1`,
      [paysheet_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Paysheet not found" });
    }

     const paysheet = result.rows[0];

    // 👇 Add +1 day to roster_date (or your date field)
    if (paysheet.roster_date) {
      const date = new Date(paysheet.roster_date);
      date.setDate(date.getDate() + 1);
      paysheet.roster_date = date;
    }

    res.status(200).json(paysheet);


  } catch (error) {
    res.status(500).json({ message: "Internal Server Error" });
  }
};


// ADD PAYSHEET DETAIL
const addPaysheetDetail = async (req, res) => {
  try {
    const { paysheet_id, earning_deduction_id, type, amount } = req.body;

    if (!["EARNING", "DEDUCTION"].includes(type)) {
      return res.status(400).json({ message: "Invalid type" });
    }

    await pool.query(
      `INSERT INTO paysheet_details
       (paysheet_id, earning_deduction_id, type, amount)
       VALUES ($1,$2,$3,$4)`,
      [paysheet_id, earning_deduction_id, type, amount]
    );

    res.status(201).json({ message: "Paysheet detail added" });

  } catch (error) {
    res.status(500).json({ message: "Internal Server Error" });
  }
};

// GET PAYSHEET DETAILS 

const getPaysheetDetails = async (req, res) => {
  try {
    const { paysheet_id } = req.params;

    const result = await pool.query(
      `SELECT 
          pd.paysheet_detail_id,
          pd.paysheet_id,
          pd.earning_deduction_id,
          COALESCE(pd.earning_deduction_name, ed.name) AS earning_deduction_name,
          COALESCE(pd.type, ed.type)                   AS type,
          pd.amount
       FROM paysheet_details pd
       LEFT JOIN earnings_deductions ed ON pd.earning_deduction_id = ed.id
       WHERE pd.paysheet_id = $1
       ORDER BY pd.paysheet_detail_id ASC`,
      [paysheet_id]
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Get Paysheet Details Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const getPaysheetsByEmployee = async (req, res) => {
  try {
    const { employee_id } = req.params
    const result = await pool.query(
      `SELECT p.*, 
              e.salary_generation_type AS generation_type
       FROM paysheets p
       JOIN employees e ON p.employee_id = e.employee_id
       WHERE p.employee_id = $1 
       ORDER BY p.payroll_year DESC, p.payroll_month DESC`,
      [employee_id]
    )
    res.status(200).json(result.rows)
  } catch (error) {
    res.status(500).json({ message: "Internal Server Error" })
  }
}

// DELETE all details for a template (used before re-saving on edit)
const deleteDetailsByTemplateId = async (req, res) => {
  try {
    const { templateId } = req.params;
    await pool.query(
      `DELETE FROM payroll_template_details WHERE payroll_template_id = $1`,
      [templateId]
    );
    res.status(200).json({ message: "Details cleared" });
  } catch (error) {
    console.error("Delete Template Details Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};
// add by senesh 

// UPDATE EXISTING PAYSHEET
const updatePaysheet = async (req, res) => {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const {
      paysheet_id,
      salary_range_start,
      salary_range_end
    } = req.body;

    // Fetch existing paysheet
    const paysheetRes = await client.query(
  `SELECT p.employee_id, p.payroll_template_id, p.payroll_status,
          e.salary_generation_type AS generation_type
   FROM paysheets p
   JOIN employees e ON p.employee_id = e.employee_id
   WHERE p.paysheet_id = $1`,
  [paysheet_id]
);

    if (!paysheetRes.rows.length) {
      return res.status(404).json({ message: "Paysheet not found" });
    }

    const { employee_id, payroll_template_id ,generation_type,payroll_status } = paysheetRes.rows[0];

     // 2️⃣ Optional: prevent editing AUTO-generated paysheets if already GENERATED/APPROVED
    if (generation_type === 'AUTO' && ["GENERATED","APPROVED","PAID"].includes(payroll_status)) {
      return res.status(400).json({ message: "AUTO-generated paysheet cannot be manually updated" });
    }

    // Fetch employee name
    const empRes = await client.query(
      `SELECT CONCAT(first_name, ' ', COALESCE(middle_name || ' ', ''), last_name) AS employee_name
       FROM employees
       WHERE employee_id = $1`,
      [employee_id]
    );

    const employee_name = empRes.rows[0].employee_name;

    // Fetch OT rates from payroll template
    const templateRateRes = await client.query(
      `SELECT ot_hour_rate, holiday_ot_hour_rate
       FROM payroll_templates
       WHERE id = $1`,
      [payroll_template_id]
    );

    if (!templateRateRes.rows.length) throw new Error("Payroll template not found");

    const ot_hour_rate = Number(templateRateRes.rows[0].ot_hour_rate) || 0;
    const holiday_ot_hour_rate = Number(templateRateRes.rows[0].holiday_ot_hour_rate) || 0;

    // Attendance summary (normal + holiday OT)
    const attendance = await client.query(
      `SELECT 
         COUNT(*) FILTER (WHERE s.present = true) AS present_days,
         COUNT(*) FILTER (WHERE s.absent = true) AS absent_days,
         COUNT(*) FILTER (WHERE s.halfday = true) AS half_days,
         COUNT(*) FILTER (WHERE s.late = true) AS late_count,

         COALESCE(SUM(
           CASE 
             WHEN h.holiday_date IS NOT NULL
                  AND a.clock_out_time IS NOT NULL
                  AND a.clock_out_time > sh.shift_out_time
                  AND EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60
                      >= sh.holiday_ot_minutes
             THEN LEAST(
               EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS holiday_overtime_minutes,

         COALESCE(SUM(
           CASE 
             WHEN h.holiday_date IS NULL
                  AND a.clock_out_time IS NOT NULL
                  AND a.clock_out_time > sh.shift_out_time
                  AND EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60
                      >= sh.after_ot_minutes
             THEN LEAST(
               EXTRACT(EPOCH FROM (a.clock_out_time::time - sh.shift_out_time::time)) / 60,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS normal_overtime_minutes,

         COALESCE(SUM(
           CASE 
             WHEN h.holiday_date IS NULL
                  AND a.clock_in_time IS NOT NULL
                  AND a.clock_in_time < sh.shift_in_time
             THEN LEAST(
               EXTRACT(EPOCH FROM (sh.shift_in_time::time - a.clock_in_time::time)) / 60,
               sh.early_ot_minutes,
               sh.max_ot_minutes
             )
             ELSE 0
           END
         ), 0) AS early_overtime_minutes

       FROM attendance a
       JOIN attendance_status s ON a.attendance_status_id = s.status_id
       JOIN shifts sh ON a.shift_id = sh.id
       LEFT JOIN holidays h ON a.check_in_date = h.holiday_date
       WHERE a.employee_id=$1 
         AND a.check_in_date BETWEEN $2 AND $3`,
      [employee_id, salary_range_start, salary_range_end]
    );

    const summary = attendance.rows[0];
    const presentDays  = Number(summary.present_days || 0);
    const absentDays   = Number(summary.absent_days || 0);
    const halfDays     = Number(summary.half_days || 0);
    const lateCount    = Number(summary.late_count || 0);
    const normalOtHours  = Number(summary.normal_overtime_minutes  || 0) / 60;
    const holidayOtHours = Number(summary.holiday_overtime_minutes || 0) / 60;
    const earlyOtHours   = Number(summary.early_overtime_minutes   || 0) / 60;
    const totalWorkingDays = presentDays + absentDays + halfDays;

    // Remove existing paysheet details
    await client.query(
      `DELETE FROM paysheet_details WHERE paysheet_id = $1`,
      [paysheet_id]
    );

    let totalEarnings = 0;
    let totalDeductions = 0;

    // Get payroll template earnings/deductions
    const templateDetails = await client.query(
      `SELECT pd.*, ed.name AS ed_name, ed.type AS ed_type, ed.calculation_type
       FROM payroll_template_details pd
       JOIN earnings_deductions ed ON pd.earning_deduction_id = ed.id
       WHERE pd.payroll_template_id = $1`,
      [payroll_template_id]
    );

    for (let row of templateDetails.rows) {
      let amount = Number(row.amount);

      // PERCENT calculation
      if (row.calculation_type === "PERCENT") {
        const earningsOnly = templateDetails.rows
          .filter(t => t.ed_type === "EARNING")
          .reduce((sum, t) => sum + Number(t.value), 0);
        amount = (earningsOnly * amount) / 100;
      }

      if (row.ed_type === "EARNING") totalEarnings += amount;
      else if (row.ed_type === "DEDUCTION") totalDeductions += amount;

      await client.query(
        `INSERT INTO paysheet_details
         (paysheet_id, earning_deduction_id, type, amount)
         VALUES ($1,$2,$3,$4)`,
        [paysheet_id, row.earning_deduction_id, row.type, amount]
      );
    }

    // Normal OT
   // Normal After-Shift OT
    if (normalOtHours > 0 && ot_hour_rate > 0) {
      const normalOtAmount = parseFloat((normalOtHours * ot_hour_rate).toFixed(2));
      totalEarnings += normalOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
         (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Normal Overtime','EARNING',$2)`,
        [paysheet_id, normalOtAmount]
      );
    }

    // Early OT
    if (earlyOtHours > 0 && ot_hour_rate > 0) {
      const earlyOtAmount = parseFloat((earlyOtHours * ot_hour_rate).toFixed(2));
      totalEarnings += earlyOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
         (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Early Overtime','EARNING',$2)`,
        [paysheet_id, earlyOtAmount]
      );
    }

    // Holiday OT
    if (holidayOtHours > 0 && holiday_ot_hour_rate > 0) {
      const holidayOtAmount = parseFloat((holidayOtHours * holiday_ot_hour_rate).toFixed(2));
      totalEarnings += holidayOtAmount;
      await client.query(
        `INSERT INTO paysheet_details
         (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'Holiday Overtime','EARNING',$2)`,
        [paysheet_id, holidayOtAmount]
      );
    }

    // Unpaid leave deduction
    // ── No-Pay deduction (replaces the separate absent + late blocks) ─────
    // Fetch no_pay_deduction_rate which was missing from updatePaysheet
    const noPayRateRes = await client.query(
      `SELECT no_pay_deduction_rate FROM payroll_templates WHERE id = $1`,
      [payroll_template_id]
    );
    const no_pay_deduction_rate_upd = Number(noPayRateRes.rows[0]?.no_pay_deduction_rate) || 0;

    const unpaidLeaveResUpd = await client.query(
      `SELECT COUNT(*) AS unpaid_leave_days
       FROM leaves l
       CROSS JOIN generate_series(l.from_date, l.to_date, interval '1 day') d(day)
       WHERE l.employee_id=$1
         AND l.status='Approved'
         AND l.paid_status='unpaid'
         AND d.day BETWEEN $2 AND $3`,
      [employee_id, salary_range_start, salary_range_end]
    );
    const unpaidLeaveDaysUpd = Number(unpaidLeaveResUpd.rows[0].unpaid_leave_days || 0);

    const lateNoPayDaysUpd = Math.floor(lateCount / 3);
    const totalNoPayDaysUpd = absentDays + unpaidLeaveDaysUpd + lateNoPayDaysUpd;

    if (totalNoPayDaysUpd > 0 && no_pay_deduction_rate_upd > 0) {
      const noPayAmountUpd = parseFloat((totalNoPayDaysUpd * no_pay_deduction_rate_upd).toFixed(2));
      totalDeductions += noPayAmountUpd;
      await client.query(
        `INSERT INTO paysheet_details
         (paysheet_id, earning_deduction_name, type, amount)
         VALUES ($1,'No Pay Deduction','DEDUCTION',$2)`,
        [paysheet_id, noPayAmountUpd]
      );
    }

    const netSalary = totalEarnings - totalDeductions;

    // Update paysheet totals and attendance info
    await client.query(
      `UPDATE paysheets
       SET salary_range_start = $1,
           salary_range_end = $2,
           total_working_days = $3,
           present_days = $4,
           absent_days = $5,
           half_days = $6,
           late_count = $7,
           total_earnings = $8,
           total_deductions = $9,
           net_salary = $10,
           payroll_status = 'UPDATED'
       WHERE paysheet_id = $11`,
      [
        salary_range_start,
        salary_range_end,
        totalWorkingDays,
        presentDays,
        absentDays,
        halfDays,
        lateCount,
        totalEarnings,
        totalDeductions,
        netSalary,
        paysheet_id
      ]
    );

    await client.query("COMMIT");

    

    res.status(200).json({
      message: "Paysheet updated successfully",
      paysheet_id,
      employee_id,
      employee_name,
      generation_type,
      total_earnings: totalEarnings,
      total_deductions: totalDeductions,
      net_salary: netSalary
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update Paysheet Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
};


//Create Paysheet Invoice

const createPaysheetInvoice = async (req, res) => {
  try {
    const {
      paysheet_detail_id,
      payment_reference,
      payment_status,
      admin_note,
      payslip_url,
      account_id,
      account_name,
      bank_account,
      payment_method
    } = req.body;

    const user = req.user;
    const paid_by = user?.user_id; 

    if (!paysheet_detail_id || !payment_reference || !paid_by || !account_id) {
      return res.status(400).json({
        message: "paysheet_detail_id, payment_reference, paid_by and account_id are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO paysheet_invoices
      (paysheet_detail_id, payment_reference, paid_by, payment_status,
       admin_note, payslip_url, account_id, account_name, bank_account, payment_method)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
      RETURNING *`,
      [
        paysheet_detail_id,
        payment_reference,
        paid_by,                    
        payment_status || "PAID",
        admin_note || null,
        payslip_url || null,
        account_id,
        account_name || null,
        bank_account ?? null,        
        payment_method || "BANK_TRANSFER"
      ]
    );

    res.status(201).json({
      message: "Paysheet invoice created successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Create Paysheet Invoice Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//Get All Paysheet Invoices
const getAllPaysheetInvoices = async (req, res) => {
  try {

    const result = await pool.query(`
      SELECT 
        pi.*,
        a.name AS account_name
      FROM paysheet_invoices pi
      LEFT JOIN accounts a 
      ON pi.account_id = a.id
      ORDER BY pi.paysheet_invoice_id DESC
    `);

    res.status(200).json({
      message: "Paysheet invoices fetched successfully",
      data: result.rows
    });

  } catch (error) {
    console.error("Get Paysheet Invoices Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//Get Invoice by Paysheet Detail
const getInvoiceByPaysheetDetail = async (req, res) => {
  const { paysheet_detail_id } = req.params;

  try {
    const result = await pool.query(
      `SELECT *
       FROM paysheet_invoices
       WHERE paysheet_detail_id = $1`,
      [paysheet_detail_id]
    );

    res.status(200).json(result.rows);

  } catch (error) {
    console.error("Fetch Invoice Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//Update Paysheet Invoice
const updatePaysheetInvoice = async (req, res) => {
  const { paysheet_invoice_id } = req.params;

  const {
    payment_reference,
    paid_by,
    payment_status,
    admin_note,
    payslip_url,
    account_id,
    account_name,
    payment_method
  } = req.body;

  try {
    const result = await pool.query(
      `UPDATE paysheet_invoices
       SET payment_reference=$1,
           paid_by=$2,
           payment_status=$3,
           admin_note=$4,
           payslip_url=$5,
           account_id=$6,
           account_name=$7,
           payment_method=$8
       WHERE paysheet_invoice_id=$9
       RETURNING *`,
      [
        payment_reference,
        paid_by,
        payment_status,
        admin_note,
        payslip_url,
        account_id,
        account_name,
        payment_method,
        paysheet_invoice_id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Invoice not found"
      });
    }

    res.status(200).json({
      message: "Paysheet invoice updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Invoice Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

//addbysenesh11
// Get payment methods
const getPaymentMethods = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT payment_method_id AS id, method_name AS name, payment_type
       FROM payment_methods
       WHERE status = 'active'
       ORDER BY payment_method_id ASC`
    );
    return res.status(200).json(result.rows);
  } catch (error) {
    console.error("Get Payment Methods Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


// Get bank accounts only
const getBankAccounts = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, balance
       FROM accounts
       WHERE bank_account = true
       AND status = 'active'
       ORDER BY id ASC`
    );
    return res.status(200).json(result.rows);
  } catch (error) {
    console.error("Get Bank Accounts Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


const VALID_TYPES = ['GENERAL','WARNING','APPRECIATION','DISCIPLINARY'];

// CREATE EMPLOYEE REMARK
const createEmployeeRemark = async (req, res) => {
  try {
    const { employee_id, remark, remark_date, remark_type } = req.body;

    //const user = req.user;
    //const user_id = user.user_id;

    const user = req.user;
    const user_id = user?.user_id;


    if (!employee_id || !remark) {
      return res.status(400).json({
        message: "employee_id and remark are required"
      });
    }

    const type = remark_type || 'GENERAL';

    // ✅ Validate type
    if (!VALID_TYPES.includes(type)) {
      return res.status(400).json({
        message: `Invalid remark_type. Allowed: ${VALID_TYPES.join(", ")}`
      });
    }

    const result = await pool.query(
      `INSERT INTO employee_remarks
       (employee_id, remark, remark_by, remark_date, remark_type)
       VALUES ($1, $2, $3, COALESCE($4, CURRENT_TIMESTAMP), $5)
       RETURNING *`,
      [employee_id, remark, user_id, remark_date, type]
    );

    const newRemark = result.rows[0];

    await insertemployeeLogs(
      employee_id,
      user_id,
      "EMPLOYEE_REMARK_CREATE",
      `[${type}] ${remark}`
    );

    return res.status(201).json({
      message: "Remark created successfully",
      data: newRemark
    });

  } catch (error) {
    console.error("Create Remark Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// GET ALL EMPLOYEE REMARKS
const getAllEmployeeRemarks = async (req, res) => {
  try {
    const { remark_type } = req.query;

    let query = `
      SELECT er.*, 
             e.first_name, 
             e.last_name
      FROM employee_remarks er
      LEFT JOIN employees e 
      ON er.employee_id = e.employee_id
    `;

    const values = [];

    if (remark_type) {
      query += ` WHERE er.remark_type = $1`;
      values.push(remark_type);
    }

    query += ` ORDER BY er.remark_date DESC`;

    const result = await pool.query(query, values);

    return res.status(200).json({
      data: result.rows
    });

  } catch (error) {
    console.error("Get All Remarks Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// GET REMARKS BY EMPLOYEE
const getRemarksByEmployee = async (req, res) => {
  try {
    const { employee_id } = req.params;
    const { remark_type } = req.query;

    let query = `
      SELECT *
      FROM employee_remarks
      WHERE employee_id = $1
    `;

    const values = [employee_id];

    if (remark_type) {
      query += ` AND remark_type = $2`;
      values.push(remark_type);
    }

    query += ` ORDER BY remark_date DESC`;

    const result = await pool.query(query, values);

    return res.status(200).json({
      data: result.rows
    });

  } catch (error) {
    console.error("Get Remarks Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// UPDATE EMPLOYEE REMARK
const updateEmployeeRemark = async (req, res) => {
  try {
    const { id } = req.params;
    const { remark, remark_type } = req.body;

    const user = req.user ;
    const user_id = user?.user_id ?? 1;

    if (!remark) {
      return res.status(400).json({
        message: "remark is required"
      });
    }

    let typeQuery = "";
    let values = [remark];

    if (remark_type) {
      if (!VALID_TYPES.includes(remark_type)) {
        return res.status(400).json({
          message: `Invalid remark_type. Allowed: ${VALID_TYPES.join(", ")}`
        });
      }
      typeQuery = ", remark_type = $2";
      values.push(remark_type, id);
    } else {
      values.push(id);
    }

    const result = await pool.query(
      `UPDATE employee_remarks
       SET remark = $1
       ${typeQuery},
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $${values.length}
       RETURNING *`,
      values
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        message: "Remark not found"
      });
    }

    return res.status(200).json({
      message: "Remark updated successfully",
      data: result.rows[0]
    });

  } catch (error) {
    console.error("Update Remark Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};

// ── ADD THIS ENTIRE BLOCK after updateEmployee ────────────────────────────────
const updateEmployeeGenerationType = async (req, res) => {
  const { id } = req.params;
  const { generation_type } = req.body;

  if (!['AUTO', 'MANUAL'].includes(generation_type)) {
    return res.status(400).json({
      message: "generation_type must be AUTO or MANUAL"
    });
  }

  try {
    const empRes = await pool.query(
      `SELECT e.employee_id,
              e.payroll_template_id,
              e.salary_generation_type,
              pt.payroll_type,
              pt.name AS template_name
       FROM employees e
       LEFT JOIN payroll_templates pt ON e.payroll_template_id = pt.id
       WHERE e.employee_id = $1`,
      [id]
    );

    /*await pool.query(
  `UPDATE paysheets
   SET generation_type = $1
   WHERE employee_id = $2
     AND generation_type != $1`,
  [generation_type, id]
);*/

    if (empRes.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const { payroll_type, template_name } = empRes.rows[0];

    if (
      generation_type === 'AUTO' &&
      payroll_type?.toUpperCase() !== 'MONTHLY'
    ) {
      return res.status(400).json({
        message: `AUTO generation is only available for MONTHLY payroll templates. This employee has a ${payroll_type ?? 'unknown'} template (${template_name ?? 'unnamed'}).`,
        payroll_type,
        template_name,
      });
    }

    const result = await pool.query(
      `UPDATE employees
       SET salary_generation_type = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE employee_id = $2
       RETURNING employee_id, salary_generation_type, payroll_template_id`,
      [generation_type, id]
    );

    res.status(200).json({
      message: `Paysheet generation updated to ${generation_type}`,
      data: result.rows[0],
    });

  } catch (error) {
    console.error("Update Generation Type Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const updateEmployeeSalaryDate = async (req, res) => {
  const { id } = req.params;
  const { net_salary_effective_date } = req.body;

  if (!net_salary_effective_date) {
    return res.status(400).json({ message: "net_salary_effective_date is required" });
  }

  try {
    const result = await pool.query(
      `UPDATE employees
       SET net_salary_effective_date = $1,
           updated_at = CURRENT_TIMESTAMP
       WHERE employee_id = $2
       RETURNING employee_id, net_salary_effective_date`,
      [net_salary_effective_date, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }

    res.status(200).json({
      message: "Next salary date updated",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Update Salary Date Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};


//  create increments and promotions
const createincrements = async (req, res) => {
    try {
        const {
            employee_id,
            change_type,
            amount,
            note,
            effective_date,
            new_designation_id,
        } = req.body;

        const user = req.user;
        const user_id = user?.user_id ;

        // ✅ Validation
        if (!employee_id || !change_type || !effective_date) {
            return res.status(400).json({ message: 'Missing required fields' });
        }

        // enforce logic (same as DB constraint)
        if (
            (['PROMOTION', 'DEMOTION'].includes(change_type) && !new_designation_id) ||
            (['INCREMENT', 'SALARY_REVISION'].includes(change_type) && new_designation_id)
        ) {
            return res.status(400).json({
                message: 'Invalid designation usage for change type'
            });
        }

        const result = await pool.query(
            `INSERT INTO increments_and_promotions
            (employee_id, change_type, amount, note, effective_date, new_designation_id, created_by)
            VALUES ($1,$2,$3,$4,$5,$6,$7)
            RETURNING *`,
            [
                employee_id,
                change_type,
                amount || 0,
                note,
                effective_date,
                new_designation_id || null,
                created_by
            ]
        );

        // ✅ Auto update designation if promotion/demotion
        if (['PROMOTION', 'DEMOTION'].includes(change_type)) {
            await db.query(
                `UPDATE employees 
                 SET designation_id = $1 
                 WHERE employee_id = $2`,
                [new_designation_id, employee_id]
            );
        }

        res.status(201).json(result.rows[0]);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};


//  GET all increments and promotions
const getAllincrements = async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT ip.*, e.name AS employee_name, d.name AS designation_name
            FROM increments_and_promotions ip
            LEFT JOIN employees e ON ip.employee_id = e.employee_id
            LEFT JOIN designations d ON ip.new_designation_id = d.designation_id
            ORDER BY ip.created_at DESC
        `);

        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};


// get increment by employee id
const getincrementsByEmployeeid = async (req, res) => {
    try {
        const { employee_id } = req.params;

        const result = await pool.query(
            `SELECT * FROM increments_and_promotions 
             WHERE employee_id = $1
             ORDER BY effective_date DESC`,
            [employee_id]
        );

        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

//update increments and promotions
const updateincrements = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            change_type,
            amount,
            note,
            effective_date,
            new_designation_id
        } = req.body;

        const result = await pool.query(
            `UPDATE increments_and_promotions
             SET change_type=$1,
                 amount=$2,
                 note=$3,
                 effective_date=$4,
                 new_designation_id=$5,
                 updated_at=NOW()
             WHERE id=$6
             RETURNING *`,
            [
                change_type,
                amount,
                note,
                effective_date,
                new_designation_id || null,
                id
            ]
        );

        res.json(result.rows[0]);

    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};


const getPayrollTemplateNames = async (req, res) => {
  try {
    const { search } = req.query;

    const result = await pool.query(
      `SELECT DISTINCT id, name
       FROM payroll_templates
       WHERE name ILIKE $1
       ORDER BY name ASC
       LIMIT 10`,
      [`%${search || ''}%`]
    );

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching template names:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
};

const checkDuplicateEmployee = async (req, res) => {
  const { mobile_number, email, nic, contact_no } = req.body

  const checks = [
    { field: 'email',         column: 'email',         value: email },
    { field: 'mobile_number', column: 'mobile_number', value: mobile_number },
    { field: 'nic',           column: 'nic',           value: nic },
    { field: 'contact_no',    column: 'contact_no',    value: contact_no },
  ]

  try {
    for (const check of checks) {
      if (!check.value) continue
      const result = await pool.query(
        `SELECT 1 FROM employees WHERE ${check.column} = $1 LIMIT 1`,
        [check.value]
      )
      if (result.rows.length > 0) {
        return res.status(409).json({
          code: 'DUPLICATE_ENTRY',
          field: check.field,
          message: `This ${check.field.replace(/_/g, ' ')} is already registered`,
        })
      }
    }
    return res.status(200).json({ ok: true })
  } catch (error) {
    console.error('Check Duplicate Error:', error)
    return res.status(500).json({ message: 'Internal Server Error' })
  }
}


const getLeavesByQuery = async (req, res) => {
  try {
    const { employee_id, year, month, status, from_date, to_date } = req.query

    let queryParams = []
    let whereConditions = []

    if (employee_id) {
      queryParams.push(parseInt(employee_id, 10))
      whereConditions.push(`l.employee_id = $${queryParams.length}`)
    }

    if (year) {
      queryParams.push(parseInt(year, 10))
      whereConditions.push(`EXTRACT(YEAR FROM l.from_date) = $${queryParams.length}`)
    }

    if (month && month !== '0') {
      queryParams.push(parseInt(month, 10))
      whereConditions.push(`EXTRACT(MONTH FROM l.from_date) = $${queryParams.length}`)
    }

    if (status) {
      queryParams.push(status.trim())
      whereConditions.push(`l.status = $${queryParams.length}`)
    }

    if (from_date) {
      queryParams.push(from_date)
      whereConditions.push(`l.from_date <= $${queryParams.length}`)
    }

    if (to_date) {
      queryParams.push(to_date)
      whereConditions.push(`l.to_date >= $${queryParams.length}`)
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(' AND ')}`
      : ''

    const result = await pool.query(
      `SELECT 
         l.*,
         e.first_name,
         e.last_name,
         lt.name AS leave_type_name
       FROM leaves l
       LEFT JOIN employees e ON l.employee_id = e.employee_id
       LEFT JOIN leave_types lt ON l.leave_type_id = lt.leave_type_id
       ${whereClause}
       ORDER BY l.leave_id DESC`,
      queryParams
    )

    res.status(200).json(result.rows)

  } catch (error) {
    console.error('Get Leaves By Query Error:', error)
    res.status(500).json({ message: 'Internal Server Error' })
  }
}


module.exports = {
  getEms, getDesignations, createDesignation, updateDesignation, getShifts, getShiftById, createShift,
  updateShift, updateEmployeeShift, createAttendance, getAllAttendance, getAttendanceByEmployee,
  getAttendanceByDate, updateClockOut, updateClockIn, createEarningDeduction, getAllEarningsDeductions, getOnlyEarnings, getOnlyDeductions,
  getEarningDeductionById, getActiveEarningsDeductions, updateEarningDeduction, createPayrollTemplate, getAllPayrollTemplates,
  getPayrollTemplateById, updatePayrollTemplate, createPayrollTemplateDetail, getAllPayrollTemplateDetails, getDetailsByPayrollTemplateId, getPayrollTemplateDetailById,
  updatePayrollTemplateDetail, createEmployee, getAllEmployees, getEmployeeById, updateEmployee, createDepartment, getAllDepartments, getDepartmentById, updateDepartment, createLeave,
  getAllLeaves, getLeavesByEmployee, updateLeaveStatus, getLeaveTypes, getOutlets, createEmployeeDocument, getDocumentsByEmployee, getDocumentById, createAppreciation, getAllAppreciations,
  getAppreciationById, getAllEmployeeLogs, createHoliday, getAllHolidays, getHolidayById, updateHoliday, createShiftRoster, getAllShiftRosters, getShiftRosterById, updateShiftRoster,
  getRosterByMonth, markAttendance, getEmployeeLogsById, getLeaveBalanceByEmployee, generatePaysheet, getAllPaysheets, getPaysheetById, addPaysheetDetail, getPaysheetDetails, updatePaysheetStatus, 
  getPaysheetsByEmployee, deleteDetailsByTemplateId, createPaysheetInvoice, getAllPaysheetInvoices, getInvoiceByPaysheetDetail, updatePaysheetInvoice, updatePaysheet, getPaymentMethods,
  getBankAccounts,createEmployeeRemark,getAllEmployeeRemarks,getRemarksByEmployee,updateEmployeeRemark,updateEmployeeGenerationType,updateEmployeeSalaryDate,createincrements,
  getAllincrements,getincrementsByEmployeeid,updateincrements,getPayrollTemplateNames,getHolidayNameSuggestions,getLeavesByQuery,checkDuplicateEmployee};
