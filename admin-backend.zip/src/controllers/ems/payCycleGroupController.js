const pool = require('../../config/db');

// ── helpers ───────────────────────────────────────────────────────────────────
const lastDayOfMonth = (y, m) => new Date(y, m + 1, 0).getDate();

const safeDate = (y, m, d) => {
  const max = lastDayOfMonth(y, m);
  return new Date(y, m, Math.min(parseInt(d, 10), max));
};

const toISO = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

/**
 * Given a group config and a reference date (any date inside the target month),
 * returns { period_start, period_end, pay_date } for that month's cycle.
 */
const computeCycle = (group, referenceDate) => {
  const [ry, rm, rd] = referenceDate.split('-').map(Number);
const ref = new Date(ry, rm - 1, rd);
  const y   = ref.getFullYear();
  const m   = ref.getMonth();

  let periodStart, periodEnd;

  if (group.cutoff_type === 'last_day') {
    periodStart = new Date(y, m, 1);
    periodEnd   = safeDate(y, m, lastDayOfMonth(y, m));
  } else {
    const cd   = parseInt(group.cutoff_day, 10);
    periodEnd  = safeDate(y, m, cd);
    // start = day after previous month's cutoff
    const prevCd  = Math.min(cd, lastDayOfMonth(y, m - 1));
    const prevEnd = new Date(y, m - 1, prevCd);
    periodStart   = new Date(prevEnd);
    periodStart.setDate(prevEnd.getDate() + 1);
  }

  const offset  = parseInt(group.payrun_month_offset, 10);
  const payDate = safeDate(
    periodEnd.getFullYear(),
    periodEnd.getMonth() + offset,
    parseInt(group.payrun_day, 10)
  );

  return {
    period_start: toISO(periodStart),
    period_end:   toISO(periodEnd),
    pay_date:     toISO(payDate),
  };
};

/**
 * Compute next pay date after a completed cycle.
 * Used when updating net_salary_effective_date after paysheet generation.
 */
const computeNextPayDate = (group, lastPeriodEnd) => {
  // next cycle reference = day after last period ended
  const [ny, nm, nd] = lastPeriodEnd.split('-').map(Number);
const next = new Date(ny, nm - 1, nd);
  next.setDate(next.getDate() + 1);
  const { pay_date } = computeCycle(group, toISO(next));
  return pay_date;
};

// ── CRUD ──────────────────────────────────────────────────────────────────────

const getAllPayCycleGroups = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT pcg.*,
              COUNT(e.employee_id) AS employee_count
       FROM pay_cycle_groups pcg
       LEFT JOIN employees e ON e.pay_cycle_group_id = pcg.id
       GROUP BY pcg.id
       ORDER BY pcg.id DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

const getPayCycleGroupById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT * FROM pay_cycle_groups WHERE id = $1', [id]
    );
    if (!result.rows.length) return res.status(404).json({ message: 'Not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

const createPayCycleGroup = async (req, res) => {
  try {
    const {
      name, description,
      cutoff_type, cutoff_day,
      payrun_day, payrun_month_offset = 1,
    } = req.body;

    if (!name || !cutoff_type || !payrun_day) {
      return res.status(400).json({
        message: 'name, cutoff_type and payrun_day are required'
      });
    }
    if (cutoff_type === 'specific' && !cutoff_day) {
      return res.status(400).json({
        message: 'cutoff_day required when cutoff_type is specific'
      });
    }

    const result = await pool.query(
      `INSERT INTO pay_cycle_groups
         (name, description, pay_frequency, cutoff_type,
          cutoff_day, payrun_day, payrun_month_offset)
       VALUES ($1,$2,'MONTHLY',$3,$4,$5,$6)
       RETURNING *`,
      [
        name.trim(),
        description?.trim() || null,
        cutoff_type,
        cutoff_type === 'specific' ? parseInt(cutoff_day, 10) : null,
        parseInt(payrun_day, 10),
        parseInt(payrun_month_offset, 10),
      ]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

const updatePayCycleGroup = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name, description, cutoff_type,
      cutoff_day, payrun_day, payrun_month_offset, is_active,
    } = req.body;

    const result = await pool.query(
      `UPDATE pay_cycle_groups
       SET name=$1, description=$2, cutoff_type=$3, cutoff_day=$4,
           payrun_day=$5, payrun_month_offset=$6, is_active=$7, updated_at=NOW()
       WHERE id=$8 RETURNING *`,
      [
        name, description || null, cutoff_type,
        cutoff_type === 'specific' ? parseInt(cutoff_day, 10) : null,
        parseInt(payrun_day, 10),
        parseInt(payrun_month_offset, 10),
        is_active ?? true,
        id,
      ]
    );
    if (!result.rows.length) return res.status(404).json({ message: 'Not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

// Preview cycles for the UI live preview (no DB needed)
const previewPayCycleGroup = async (req, res) => {
  try {
    const {
      cutoff_type, cutoff_day,
      payrun_day, payrun_month_offset = 1,
    } = req.query;

    if (!cutoff_type || !payrun_day) {
      return res.status(400).json({ message: 'cutoff_type and payrun_day required' });
    }

    const group   = { cutoff_type, cutoff_day, payrun_day, payrun_month_offset };
    const today   = new Date();
    const periods = [0, 1, 2].map(offset => {
      const ref = new Date(today.getFullYear(), today.getMonth() + offset, 1);
      return computeCycle(group, toISO(ref));
    });

    res.json(periods);
  } catch (err) {
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

module.exports = {
  getAllPayCycleGroups,
  getPayCycleGroupById,
  createPayCycleGroup,
  updatePayCycleGroup,
  previewPayCycleGroup,
  computeCycle,
  computeNextPayDate,
  toISO,
};