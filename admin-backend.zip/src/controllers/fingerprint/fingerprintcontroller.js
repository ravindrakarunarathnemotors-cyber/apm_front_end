const pool = require("../../config/db");

// ── GET Fingerprint API Details ──────────────────────────────────────────────
const getFingerprintApiDetails = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, client_id, api_key, is_active, created_at, updated_at
       FROM apidocuments ORDER BY id ASC LIMIT 1`
    );

    const deviceRows = await pool.query(
      `SELECT device_id, till_name AS device_name, device_model
       FROM device_management
       WHERE type = 'attendance_device' AND status = 'Active'
       ORDER BY device_id ASC`
    );

    return res.status(200).json({
      success: true,
      data: rows,
      devices: deviceRows.rows,
    });
  } catch (err) {
    console.error("[getFingerprintApiDetails]", err);
    return res.status(500).json({ success: false, message: "Internal server error." });
  }
};

// ── RECEIVE Fingerprint Events from HikSync desktop app ─────────────────────
const receiveFingerprintEvents = async (req, res) => {
  try {
    const apiKey  = req.headers["x-api-key"];
    const clientId = req.headers["x-client-id"];
    const deviceId = req.headers["x-device-id"];

    // ── 1. Auth ────────────────────────────────────────────────────────────
    if (!apiKey || !clientId) {
      return res.status(401).json({
        success: false, code: 401, label: "Unauthorized",
        message: "X-API-Key and X-Client-ID headers are required.",
      });
    }

    const docResult = await pool.query(
      `SELECT id, is_active FROM apidocuments
       WHERE client_id = $1 AND api_key = $2`,
      [clientId, apiKey]
    );

    if (docResult.rows.length === 0) {
      return res.status(401).json({
        success: false, code: 401, label: "Unauthorized",
        message: "Invalid API key or Client ID.",
      });
    }

    if (!docResult.rows[0].is_active) {
      return res.status(403).json({
        success: false, code: 403, label: "Forbidden",
        message: "API access is not activated for this account.",
      });
    }

    // ── 2. Validate payload ────────────────────────────────────────────────
    const { device_id, events } = req.body;

    if (!events || !Array.isArray(events) || events.length === 0) {
      return res.status(400).json({
        success: false, code: 400, label: "Bad Request",
        message: "events array is required and must not be empty.",
      });
    }

    // ── 3. Get default shift ───────────────────────────────────────────────
    const shiftResult = await pool.query(
      `SELECT id FROM shifts ORDER BY id ASC LIMIT 1`
    );
    const defaultShiftId = shiftResult.rows[0]?.id || null;

    const inserted    = [];
    const attInserted = [];
    const attSkipped  = [];

    // ── 4. Process each event ──────────────────────────────────────────────
    for (const event of events) {
      const {
        employee_no, name, card_no,
        event_time, event_type, door_no, verify_mode,
      } = event;

      if (!employee_no || !event_time) continue;

      // ── 4a. Save to fingerprint_logs (without attendance_id yet) ──────────
      const { rows: fpRows } = await pool.query(
        `INSERT INTO fingerprint_logs
          (device_id, client_id, employee_no, name, card_no,
           event_time, event_type, door_no, verify_mode,
           raw_payload, status_code, message)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
         RETURNING id`,
        [
          device_id || deviceId || null,
          clientId,
          employee_no,
          name || null,
          card_no || null,
          event_time,
          event_type || null,
          door_no || null,
          verify_mode || null,
          JSON.stringify(event),
          201,
          "Event recorded successfully.",
        ]
      );
      const fingerprintLogId = fpRows[0].id;
      inserted.push(fingerprintLogId);

      // ── 4b. Match employee by employee_no (maps to employee_id) ───────────
      const empResult = await pool.query(
        `SELECT employee_id, CONCAT(first_name, ' ', last_name) AS full_name
         FROM employees
         WHERE CAST(employee_id AS VARCHAR) = $1
         LIMIT 1`,
        [String(employee_no)]
      );

      if (empResult.rows.length === 0) {
        attSkipped.push({ employee_no, reason: "Employee not found in system" });
        continue;
      }

      const employee     = empResult.rows[0];
      const employeeId   = employee.employee_id;
      const employeeName = employee.full_name || name || "";

      // ── 4c. Parse date and time from event_time ────────────────────────────
      const eventDate = new Date(event_time);
      const checkDate = eventDate.toISOString().split("T")[0];         // YYYY-MM-DD
      const checkTime = eventDate.toTimeString().split(" ")[0].substring(0, 5); // HH:MM

    // ── 4d. Check if attendance already exists for this employee+date ──────
      // We no longer trust event_type from the device. Instead: first punch of
      // the day = clock-in, next punch far enough away = clock-out, anything
      // closer than MIN_MINUTES_BETWEEN_PUNCHES = ignored as a duplicate scan.
      const MIN_MINUTES_BETWEEN_PUNCHES = 60; // tune as needed (e.g. 120)

      const existingAtt = await pool.query(
        `SELECT attendance_id, clock_in_time, clock_out_time
         FROM attendance
         WHERE employee_id = $1 AND check_in_date = $2
         LIMIT 1`,
        [employeeId, checkDate]
      );

      if (existingAtt.rows.length > 0) {
        const existingAttId    = existingAtt.rows[0].attendance_id;
        const existingClockIn  = existingAtt.rows[0].clock_in_time;
        const existingClockOut = existingAtt.rows[0].clock_out_time;

        const refTime      = existingClockOut || existingClockIn;
        const refDateTime  = new Date(`${checkDate}T${refTime}`);
        const thisDateTime = new Date(`${checkDate}T${checkTime}`);
        const diffMinutes  = (thisDateTime - refDateTime) / (1000 * 60);

        if (diffMinutes < MIN_MINUTES_BETWEEN_PUNCHES) {
          // Too soon after the last punch — accidental double-scan, ignore.
          await pool.query(
            `UPDATE fingerprint_logs SET attendance_id = $1 WHERE id = $2`,
            [existingAttId, fingerprintLogId]
          );
          attSkipped.push({
            employee_no,
            reason: `Punch within ${MIN_MINUTES_BETWEEN_PUNCHES} min of previous punch — ignored`,
          });
          continue;
        }

        // Far enough from the last punch — this is the clock-out.
        await pool.query(
          `UPDATE attendance
           SET clock_out_time = $1, check_out_date = $2
           WHERE attendance_id = $3`,
          [checkTime, checkDate, existingAttId]
        );
        await pool.query(
          `UPDATE fingerprint_logs SET attendance_id = $1 WHERE id = $2`,
          [existingAttId, fingerprintLogId]
        );
        attInserted.push({ type: "clock_out_updated", employee_id: employeeId, date: checkDate });
        continue;
      }

      // No existing record for this employee+date — this punch becomes the
      // CLOCK-IN, regardless of what event_type the device reported.

      // ── 4e. No existing record — only create attendance on Entry event ──────
      if (event_type !== "Entry" && event_type !== "entry") {
        attSkipped.push({
          employee_no,
          reason: `Exit event but no Entry record found for ${checkDate}`,
        });
        continue;
      }

      // ── 4f. Check for holiday ──────────────────────────────────────────────
      const holidayResult = await pool.query(
        `SELECT holiday_id, holiday_name FROM holidays WHERE holiday_date = $1`,
        [checkDate]
      );
      const holiday_id   = holidayResult.rows[0]?.holiday_id   || null;
      const holiday_name = holidayResult.rows[0]?.holiday_name || null;

      // ── 4g. Check for approved leave ──────────────────────────────────────
      const leaveResult = await pool.query(
        `SELECT leave_id, duration_type FROM leaves
         WHERE employee_id = $1
           AND status = 'Approved'
           AND $2 BETWEEN from_date AND to_date`,
        [employeeId, checkDate]
      );
      const leave_id = leaveResult.rows[0]?.leave_id || null;
      const halfday  = ["first_half", "second_half"].includes(
        leaveResult.rows[0]?.duration_type
      );

      // ── 4h. Check if late based on shift ──────────────────────────────────
      let late = false;
      if (!holiday_id && !leave_id && defaultShiftId) {
        const shiftRes = await pool.query(
          `SELECT shift_in_time, grace_period_minutes FROM shifts WHERE id = $1`,
          [defaultShiftId]
        );
        if (shiftRes.rows.length > 0) {
          const shiftInTime        = shiftRes.rows[0].shift_in_time;
          const gracePeriodMinutes = Number(shiftRes.rows[0].grace_period_minutes) || 0;
          const toMins = (t) => {
            const [h, m] = String(t).split(":").map(Number);
            return h * 60 + m;
          };
          if (toMins(checkTime) > toMins(shiftInTime) + gracePeriodMinutes) {
            late = true;
          }
        }
      }

      // ── 4i. Determine present/absent flags ────────────────────────────────
      let present = true;
      let absent  = false;
      if (holiday_id) {
        present = false;
        absent  = false;
      } else if (leave_id && !halfday) {
        present = false;
        absent  = false;
      }

      // ── 4j. Insert attendance_status row ──────────────────────────────────
      const newStatusResult = await pool.query(
        `INSERT INTO attendance_status
          (holiday_id, leave_id, day_off, present, halfday, absent, holiday_name, late)
         VALUES ($1, $2, false, $3, $4, $5, $6, $7)
         RETURNING status_id`,
        [holiday_id, leave_id, present, halfday, absent, holiday_name, late]
      );
      const statusId = newStatusResult.rows[0].status_id;

      // ── 4k. Insert attendance row ──────────────────────────────────────────
      try {
        const { rows: attRows } = await pool.query(
          `INSERT INTO attendance
            (employee_id, name, check_in_date, clock_in_time, clock_out_time,
             log_source, shift_id, attendance_status_id, check_out_date)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
           RETURNING attendance_id`,
          [
            employeeId,
            employeeName,
            checkDate,
            checkTime,
            null,            // ✅ clock_out_time stays null until the 2nd punch arrives
            "FINGERPRINT",
            defaultShiftId,
            statusId,
            null,            // ✅ check_out_date stays null too
          ]
        );
        const newAttendanceId = attRows[0].attendance_id;

        // ── Link fingerprint log to new attendance ──────────────────────────
        await pool.query(
          `UPDATE fingerprint_logs SET attendance_id = $1 WHERE id = $2`,
          [newAttendanceId, fingerprintLogId]
        );

        attInserted.push({ type: "attendance_created", employee_id: employeeId, date: checkDate });
      } catch (attErr) {
        console.error("[attendance insert error]", attErr.message);
        attSkipped.push({ employee_no, reason: attErr.message });
      }
    }

    return res.status(200).json({
      success: true,
      code: 200,
      label: "OK",
      message: `${inserted.length} event(s) recorded. ${attInserted.length} attendance record(s) created/updated.`,
      recorded_count:     inserted.length,
      attendance_count:   attInserted.length,
      attendance_skipped: attSkipped.length,
      ids: inserted,
    });

  } catch (err) {
    console.error("[receiveFingerprintEvents]", err);
    return res.status(500).json({
      success: false, code: 500, label: "Server Error",
      message: "Internal server error.",
    });
  }
};

// ── GET Fingerprint Logs ─────────────────────────────────────────────────────
const getFingerprintLogs = async (req, res) => {
  try {
    const {
      keyword, device_id, from_date, to_date,
      page = 1, limit = 20,
    } = req.query;

    const parsedPage  = parseInt(page,  10);
    const parsedLimit = parseInt(limit, 10);
    const offset      = (parsedPage - 1) * parsedLimit;

    let params = [];
    let where  = [];

    if (keyword && keyword.trim()) {
      params.push(`%${keyword.trim()}%`);
      const n = params.length;
      where.push(`(employee_no ILIKE $${n} OR name ILIKE $${n} OR card_no ILIKE $${n})`);
    }
    if (device_id && device_id.trim()) {
      params.push(device_id.trim());
      where.push(`device_id = $${params.length}`);
    }
    if (from_date) { params.push(from_date); where.push(`event_time::date >= $${params.length}`); }
    if (to_date)   { params.push(to_date);   where.push(`event_time::date <= $${params.length}`); }

    const whereClause = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countRes = await pool.query(
      `SELECT COUNT(*) AS total FROM fingerprint_logs ${whereClause}`, params
    );
    const total = parseInt(countRes.rows[0].total, 10);

    const dataParams = [...params, parsedLimit, offset];
    const dataRes = await pool.query(
      `SELECT
         fl.id,
         fl.device_id,
         fl.client_id,
         fl.employee_no,
         fl.name,
         fl.card_no,
         fl.event_time,
         fl.event_type,
         fl.door_no,
         fl.verify_mode,
         fl.status_code,
         fl.message,
         fl.attendance_id,
         fl.created_at,
         a.check_in_date,
         a.clock_in_time,
         a.clock_out_time
       FROM fingerprint_logs fl
       LEFT JOIN attendance a ON fl.attendance_id = a.attendance_id
       ${whereClause}
       ORDER BY fl.created_at DESC
       LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
      dataParams
    );

    return res.status(200).json({
      success: true,
      data: dataRes.rows,
      total,
      page: parsedPage,
      per_page: parsedLimit,
      total_pages: Math.ceil(total / parsedLimit),
    });
  } catch (err) {
    console.error("[getFingerprintLogs]", err);
    return res.status(500).json({ success: false, message: "Internal server error." });
  }
};

// ── SYNC Fingerprint Logs → Attendance (Shift-Aware) ────────────────────────
const syncFingerprintLogs = async (req, res) => {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // ── Helper: "HH:MM" or "HH:MM:SS" → total minutes ────────────────────
    const toMins = (t) => {
      if (!t) return 0;
      const parts = String(t).split(":").map(Number);
      return parts[0] * 60 + (parts[1] || 0);
    };

    // ── 1. Load ALL shifts once ───────────────────────────────────────────
    const shiftsRes = await client.query(
      `SELECT id, shift_name, shift_in_time, shift_out_time,
              grace_period_minutes, after_ot_minutes, max_ot_minutes
       FROM shifts ORDER BY id ASC`
    );
    const shifts = shiftsRes.rows;

    if (shifts.length === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        success: false,
        message: "No shifts configured. Please create a shift first.",
      });
    }

    // ── 2. Build shift windows ────────────────────────────────────────────
    // For each shift, compute:
    //   windowStart = shift_in_time - 2 hours  (earliest valid clock-in)
    //   windowEnd   = shift_out_time + after_ot_minutes + 2 hours (latest valid clock-out)
    // If windowEnd crosses midnight (> 1440 mins), the shift spans two calendar days.

    const shiftWindows = shifts.map((s) => {
      const inMins      = toMins(s.shift_in_time);
      const outMins     = toMins(s.shift_out_time);
      const afterOt     = Number(s.after_ot_minutes) || 0;
      const grace       = Number(s.grace_period_minutes) || 0;

      // Window opens 2 hours before shift_in (catch early arrivals)
      const windowStart = Math.max(0, inMins - 120);

      // Window closes 2 hours after shift_out + max OT buffer
      const windowEnd   = outMins + afterOt + 120;

      // Does this shift span into the next calendar day?
      const spansNextDay = windowEnd > 1440 || outMins < inMins;

      return {
        ...s,
        inMins,
        outMins,
        grace,
        afterOt,
        windowStart,   // minutes from midnight
        windowEnd,     // minutes from midnight (may exceed 1440 if overnight)
        spansNextDay,
      };
    });

    // ── 3. Match a log event to the best shift window ─────────────────────
    // Returns { shift, checkDate } where checkDate is the shift's "anchor date"
    // (the calendar date the shift STARTED on, not necessarily when clock-out happened)
    const matchShift = (eventTime) => {
      const d          = new Date(eventTime);
      const minuteOfDay = d.getHours() * 60 + d.getMinutes();
      const dateStr    = d.toISOString().split("T")[0]; // YYYY-MM-DD

      // Try matching against today's date first, then yesterday
      // (handles overnight shifts where exit is next calendar day)
      for (const shift of shiftWindows) {
        if (shift.spansNextDay) {
          // Overnight shift: entry window is today, exit can be tomorrow
          // Entry: windowStart → 1440 (midnight)
          // Exit:  0 → (windowEnd - 1440)
          const entryWindowStart = shift.windowStart;
          const exitWindowEnd    = shift.windowEnd - 1440;

          if (minuteOfDay >= entryWindowStart) {
            // This looks like an entry for this overnight shift
            return { shift, checkDate: dateStr, matchType: "entry_overnight" };
          }
          if (minuteOfDay <= exitWindowEnd) {
            // This looks like an exit for the PREVIOUS day's overnight shift
            const yesterday = new Date(d);
            yesterday.setDate(yesterday.getDate() - 1);
            return {
              shift,
              checkDate: yesterday.toISOString().split("T")[0],
              matchType: "exit_overnight",
            };
          }
        } else {
          // Normal shift: both entry and exit within same calendar day
          if (
            minuteOfDay >= shift.windowStart &&
            minuteOfDay <= shift.windowEnd
          ) {
            return { shift, checkDate: dateStr, matchType: "normal" };
          }
        }
      }

      // Fallback: use first shift, anchor to event's calendar date
      return { shift: shiftWindows[0], checkDate: dateStr, matchType: "fallback" };
    };

    // ── 4. Fetch all PENDING logs, ordered by employee + event_time ───────
    const logsRes = await client.query(`
      SELECT *
      FROM fingerprint_logs
      WHERE sync_status = 'PENDING'
        AND employee_no IS NOT NULL
      ORDER BY employee_no ASC, event_time ASC
    `);

    if (logsRes.rows.length === 0) {
      await client.query("COMMIT");
      return res.status(200).json({
        success: true,
        message: "No pending logs to sync.",
        synced: 0, skipped: 0, duplicates: 0,
      });
    }

    // ── 5. Group logs by employee_no + shift_checkDate ────────────────────
    // Key: "employeeNo__YYYY-MM-DD__shiftId"
    // For each group we keep:
    //   entry: the FIRST log whose event_type = Entry within the shift window
    //   exit:  the LAST  log whose event_type = Exit  within the shift window
    //   extras: all other logs in this group (duplicates)

// ── 5. Group logs by employee_no + shift_checkDate ────────────────────
    // Key: "employeeNo__YYYY-MM-DD__shiftId"
    const MIN_MINUTES_BETWEEN_PUNCHES = 60; // keep in sync with receiveFingerprintEvents

    const rawGroups = {}; // key → { shift, checkDate, employeeNo, logs: [] }

    for (const log of logsRes.rows) {
      const { shift, checkDate } = matchShift(log.event_time);
      const key = `${log.employee_no}__${checkDate}__${shift.id}`;

      if (!rawGroups[key]) {
        rawGroups[key] = { shift, checkDate, employeeNo: log.employee_no, logs: [] };
      }
      rawGroups[key].logs.push(log);
    }

    // ── 6. Within each group, sort chronologically: first punch = entry,
    //      next punch far enough away = exit, anything closer = duplicate.
    const groups = {};
    const duplicateIds = [];

    for (const [key, g] of Object.entries(rawGroups)) {
      const sorted = [...g.logs].sort(
        (a, b) => new Date(a.event_time) - new Date(b.event_time)
      );

      const entry = sorted[0];
      let exit = null;
      let refTime = new Date(entry.event_time);

      for (let i = 1; i < sorted.length; i++) {
        const log = sorted[i];
        const diffMinutes = (new Date(log.event_time) - refTime) / (1000 * 60);

        if (diffMinutes < MIN_MINUTES_BETWEEN_PUNCHES) {
          duplicateIds.push(log.id); // too close — noise/duplicate scan
          continue;
        }

        exit = log;                 // far enough — becomes (or extends) the exit
        refTime = new Date(log.event_time);
      }

      groups[key] = { shift: g.shift, checkDate: g.checkDate, employeeNo: g.employeeNo, entry, exit };
    }

    if (duplicateIds.length > 0) {
      await client.query(
        `UPDATE fingerprint_logs
         SET sync_status = 'DUPLICATE'
         WHERE id = ANY($1::int[])`,
        [duplicateIds]
      );
    }

    // ── 7. Process each group ─────────────────────────────────────────────
    let synced = 0, skipped = 0;

    for (const [, g] of Object.entries(groups)) {
      const { shift, checkDate, employeeNo, entry, exit } = g;

      // No entry at all → skip exit too
      if (!entry) {
        const toSkip = [exit?.id].filter(Boolean);
        if (toSkip.length) {
          await client.query(
            `UPDATE fingerprint_logs SET sync_status = 'SKIPPED'
             WHERE id = ANY($1::int[])`,
            [toSkip]
          );
          skipped++;
        }
        continue;
      }

      // ── 7a. Match employee in DB ────────────────────────────────────────
      const empRes = await client.query(
        `SELECT employee_id,
                CONCAT(first_name,' ',last_name) AS full_name
         FROM employees
         WHERE CAST(employee_id AS VARCHAR) = $1
         LIMIT 1`,
        [String(employeeNo)]
      );

      if (empRes.rows.length === 0) {
        const toSkip = [entry.id, exit?.id].filter(Boolean);
        await client.query(
          `UPDATE fingerprint_logs SET sync_status = 'SKIPPED'
           WHERE id = ANY($1::int[])`,
          [toSkip]
        );
        skipped += toSkip.length;
        continue;
      }

      const { employee_id, full_name } = empRes.rows[0];

      // ── 7b. Parse clock-in ──────────────────────────────────────────────
      const entryDt  = new Date(entry.event_time);
      const clockIn  = entryDt.toTimeString().substring(0, 5); // HH:MM

      // ── 7c. Parse clock-out ─────────────────────────────────────────────
      // For overnight shifts, clock-out date may differ from checkDate
      let clockOut     = null;
      let checkOutDate = checkDate;

      if (exit) {
        const exitDt = new Date(exit.event_time);
        clockOut     = exitDt.toTimeString().substring(0, 5);
        checkOutDate = exitDt.toISOString().split("T")[0];
      }

      // ── 7d. Attendance already exists? ─────────────────────────────────
      const existingRes = await client.query(
        `SELECT attendance_id, clock_out_time, log_source
         FROM attendance
         WHERE employee_id = $1 AND check_in_date = $2
         LIMIT 1`,
        [employee_id, checkDate]
      );

      if (existingRes.rows.length > 0) {
        const existing = existingRes.rows[0];

        // Update clock-out only if record is FINGERPRINT-sourced and we have an exit
        if (clockOut && existing.log_source === "FINGERPRINT") {
          await client.query(
            `UPDATE attendance
             SET clock_out_time = $1, check_out_date = $2
             WHERE attendance_id = $3`,
            [clockOut, checkOutDate, existing.attendance_id]
          );
        }

        const linkIds = [entry.id, exit?.id].filter(Boolean);
        await client.query(
          `UPDATE fingerprint_logs
           SET sync_status = 'SYNCED', attendance_id = $1
           WHERE id = ANY($2::int[])`,
          [existing.attendance_id, linkIds]
        );
        synced += linkIds.length;
        continue;
      }

      // ── 7e. Holiday check ───────────────────────────────────────────────
      const holidayRes = await client.query(
        `SELECT holiday_id, holiday_name
         FROM holidays WHERE holiday_date = $1`,
        [checkDate]
      );
      const holiday_id   = holidayRes.rows[0]?.holiday_id   || null;
      const holiday_name = holidayRes.rows[0]?.holiday_name || null;

      // ── 7f. Approved leave check ────────────────────────────────────────
      const leaveRes = await client.query(
        `SELECT leave_id, duration_type FROM leaves
         WHERE employee_id = $1
           AND status = 'Approved'
           AND $2 BETWEEN from_date AND to_date`,
        [employee_id, checkDate]
      );
      const leave_id = leaveRes.rows[0]?.leave_id || null;
      const halfday  = ["first_half","second_half"].includes(
        leaveRes.rows[0]?.duration_type
      );

      // ── 7g. LATE check against matched shift ────────────────────────────
      let late = false;
      if (!holiday_id && !leave_id) {
        const deadlineMins =
          toMins(shift.shift_in_time) + Number(shift.grace_period_minutes || 0);
        if (toMins(clockIn) > deadlineMins) late = true;
      }

      // ── 7h. present / absent flags ──────────────────────────────────────
      let present = true;
      let absent  = false;
      if (holiday_id)             { present = false; absent = false; }
      else if (leave_id && !halfday) { present = false; absent = false; }

      // ── 7i. Insert attendance_status ────────────────────────────────────
      const statusRes = await client.query(
        `INSERT INTO attendance_status
           (holiday_id, leave_id, day_off, present, halfday,
            absent, holiday_name, late)
         VALUES ($1,$2,false,$3,$4,$5,$6,$7)
         RETURNING status_id`,
        [holiday_id, leave_id, present, halfday, absent, holiday_name, late]
      );
      const statusId = statusRes.rows[0].status_id;

      // ── 7j. Insert attendance ───────────────────────────────────────────
      const attRes = await client.query(
        `INSERT INTO attendance
           (employee_id, name, check_in_date, clock_in_time,
            clock_out_time, log_source, shift_id,
            attendance_status_id, check_out_date)
         VALUES ($1,$2,$3,$4,$5,'FINGERPRINT',$6,$7,$8)
         RETURNING attendance_id`,
        [
          employee_id,
          full_name || entry.name || "",
          checkDate,
          clockIn,
          clockOut,                    // ✅ null if no exit punch yet — no longer defaults to clockIn
          shift.id,
          statusId,
          exit ? checkOutDate : null,  // ✅ null check_out_date until there's an actual exit
        ]
      );
      const newAttId = attRes.rows[0].attendance_id;

      // ── 7k. Link logs → attendance ──────────────────────────────────────
      const linkIds = [entry.id, exit?.id].filter(Boolean);
      await client.query(
        `UPDATE fingerprint_logs
         SET sync_status = 'SYNCED', attendance_id = $1
         WHERE id = ANY($2::int[])`,
        [newAttId, linkIds]
      );
      synced += linkIds.length;
    }

    await client.query("COMMIT");

    return res.status(200).json({
      success: true,
      message: `Sync complete. ${synced} logs synced, ${skipped} skipped, ${duplicateIds.length} duplicates marked.`,
      synced,
      skipped,
      duplicates: duplicateIds.length,
    });

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("[syncFingerprintLogs]", err);
    return res.status(500).json({
      success: false,
      message: "Sync failed: " + err.message,
    });
  } finally {
    client.release();
  }
};
  
// ── GET Employee List (for HikSync desktop app enrollment) ──────────────────
const getEmployeeList = async (req, res) => {
  try {
    const apiKey   = req.headers["x-api-key"];
    const clientId = req.headers["x-client-id"];

    // ── 1. Auth (same as receiveFingerprintEvents) ─────────────────────────
    if (!apiKey || !clientId) {
      return res.status(401).json({
        success: false, code: 401, label: "Unauthorized",
        message: "X-API-Key and X-Client-ID headers are required.",
      });
    }

    const docResult = await pool.query(
      `SELECT id, is_active FROM apidocuments
       WHERE client_id = $1 AND api_key = $2`,
      [clientId, apiKey]
    );

    if (docResult.rows.length === 0) {
      return res.status(401).json({
        success: false, code: 401, label: "Unauthorized",
        message: "Invalid API key or Client ID.",
      });
    }

    if (!docResult.rows[0].is_active) {
      return res.status(403).json({
        success: false, code: 403, label: "Forbidden",
        message: "API access is not activated for this account.",
      });
    }

    // ── 2. Fetch employee list ──────────────────────────────────────────────
    const { rows } = await pool.query(
      `SELECT
         CAST(employee_id AS VARCHAR) AS employee_no,
         CONCAT(first_name, ' ', last_name) AS name
       FROM employees
       ORDER BY employee_id ASC`
    );

    return res.status(200).json({
      success: true,
      employees: rows,
    });

  } catch (err) {
    console.error("[getEmployeeList]", err);
    return res.status(500).json({
      success: false, code: 500, label: "Server Error",
      message: "Internal server error.",
    });
  }
};


module.exports = {
  getFingerprintApiDetails,
  receiveFingerprintEvents,
  getFingerprintLogs,
  syncFingerprintLogs,
  getEmployeeList, 
}; 