// const { loginUser } = require("../services/AuthService");
const bcrypt = require("bcrypt");
const saltRounds = 10;

// const login = async (req, res) => {
//   try {
//     const { email, password } = req.body;
//     console.log(email)
//     const response = await loginUser(email, password);
//     res.json(response);
//   } catch (error) {
//    console.log(error)
//     res.status(401).json({ message: error.message });
    
//   }
// };

// const register = (req, res, next) => {
//   const email = req.body.email;
//   const password = req.body.password;

//   bcrypt.hash(password, saltRounds, function (err, hash) {
//      console.log(hash);
//   });
  


// };


module.exports = {  };
