const pool = require("../config/db");
const { customhook } = require("../models/smsnotificationmodel");

function normalizePhoneNumber(mobile = '') {
    const cleaned = mobile.replace(/\D/g, '') // remove +, spaces, etc

    let normalized;
    if (cleaned.startsWith('94')) normalized = cleaned
    else if (cleaned.startsWith('0')) normalized = `94${cleaned.slice(1)}`
    else if (cleaned.startsWith('7')) normalized = `94${cleaned}`
    else normalized = cleaned

    return {
        withCountryCode: normalized,        // "94711236547"
        withZero: `0${normalized.slice(2)}` // "0711236547"
    }
}

const getAllCustomer = async (req, res) => {
    try {
        const { customer } = req.query

        if (!customer || !customer.trim()) {
            return res.status(400).json({ message: "Search term is required" })
        }

        const trimmed = customer.trim()
        const nameParts = trimmed.split(/\s+/)
        const searchTerm = `%${trimmed}%`

        // Only normalize phone if input looks like a number
        const isPhoneSearch = /^[\d\s\+\-\(\)]+$/.test(trimmed)

        let query
        let values

        if (nameParts.length >= 2) {
            const firstName = `%${nameParts[0]}%`
            const lastName = `%${nameParts.slice(1).join(' ')}%`

            query = `
                SELECT 
                    customer_id AS value, 
                    first_name, 
                    last_name, 
                    contact_number_1, 
                    address, 
                    email,
                    city, 
                    postal_code, 
                    company_name, 
                    apartment, 
                    country, 
                    loyalty_point
                FROM customer 
                WHERE status = 'active' 
                AND (
                    (first_name ILIKE $1 AND last_name ILIKE $2) OR
                    (first_name ILIKE $2 AND last_name ILIKE $1) OR
                    email ILIKE $3
                )
                LIMIT 20
            `
            values = [firstName, lastName, searchTerm]

        } else if (isPhoneSearch) {
            // Input is a number — search phone only
            const { withCountryCode, withZero } = normalizePhoneNumber(trimmed)
            const phoneTerm1 = `%${withCountryCode}%`
            const phoneTerm2 = `%${withZero}%`

            query = `
                SELECT 
                    customer_id AS value, 
                    first_name, 
                    last_name, 
                    contact_number_1, 
                    address, 
                    email,
                    city, 
                    postal_code, 
                    company_name, 
                    apartment, 
                    country, 
                    loyalty_point
                FROM customer 
                WHERE status = 'active' 
                AND (
                    contact_number_1 LIKE $1 OR
                    contact_number_1 LIKE $2
                )
                LIMIT 20
            `
            values = [phoneTerm1, phoneTerm2]

        } else {
            // Input is text — search name and email only
            query = `
                SELECT 
                    customer_id AS value, 
                    first_name, 
                    last_name, 
                    contact_number_1, 
                    address, 
                    email,
                    city, 
                    postal_code, 
                    company_name, 
                    apartment, 
                    country, 
                    loyalty_point
                FROM customer 
                WHERE status = 'active' 
                AND (
                    first_name ILIKE $1 OR
                    last_name  ILIKE $1 OR
                    email      ILIKE $1
                )
                LIMIT 20
            `
            values = [searchTerm]
        }

        const { rows } = await pool.query(query, values)

        if (rows.length === 0) {
            return res.status(400).json({ message: "Customer not found" })
        }

        const allResult = rows.map((name) => {
            const label = `${name.value} - ${name.first_name} ${name.last_name}`
            return { ...name, label }
        })

        return res.status(200).json({ message: "All Customers Found", result: allResult })

    } catch (err) {
        console.error('Error fetching customers:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
}

// const getAllPaymentMethod = async (req, res) => {
//     try {
//         const query = `SELECT payment_method_id as value, method_name as label FROM payment_methods WHERE status = 'active'`;
//         const { rows } = await pool.query(query);
//         return res.status(200).json({ message: "All Payment Method Found", result: rows });
//     } catch (err) {
//         console.error('Error fetching variants:', err);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };
// const getAllPaymentMethod = async (req, res) => {
//     try {
//         const query = `
//             SELECT 
//                 payment_method_id AS value, method_name AS label
//             FROM payment_methods
//             WHERE status = 'active'  AND web_show IS TRUE AND payment_method_id NOT IN (1, 2)
//         `;
//         const { rows } = await pool.query(query);
//         return res.status(200).json({ message: "All Payment Method Found", result: rows });
//     } catch (err) {
//         console.error('Error fetching payment methods:', err);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };


const getAllPaymentMethod = async (req, res) => {
    try {
        const query = `
            SELECT 
                payment_method_id AS value, method_name AS label, transaction_fixed_fee, transaction_fee, commission_status
            FROM payment_methods
            WHERE status = 'active'  AND web_show IS TRUE  
        `;
        const { rows } = await pool.query(query);
        return res.status(200).json({ message: "All Payment Method Found", result: rows });
    } catch (err) {
        console.error('Error fetching payment methods:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};


const allCountry = async (req, res) => {
    try {
        const result = await pool.query(`SELECT id, country_name FROM countries WHERE status = 'active'`);

        return res.status(200).json({ message: "success", result: result.rows });
    } catch (err) {
        console.error('Error fetching system settings:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch system settings' });
    }
};

const Notification = async (req, res) => {
    try {
        const { action_id, order_id } = req.body

        const response = await customhook(action_id, order_id)
        return res.status(200).json({ message: "success", result: response });
    } catch (err) {
        console.error('Error fetching system settings:', err);
        res.status(500).json({ success: false, message: 'Failed to fetch system settings' });
    }
};

const getAllCustomerUpdate = async (req, res) => {
    try {

        const { customer } = req.query
        console.log(customer)
        // const isNumber = !isNaN(customer) ? Number(customer) : null;

        const query = `SELECT 
    c.customer_id AS value,
    c.first_name,
    c.last_name,
    c.contact_number_1,
    c.address,
    c.email,
    c.city,
    c.company_name,
    c.postal_code,
    c.apartment,
    c.country,
    c.loyalty_point,
    co.country_name
FROM customer c
LEFT JOIN countries co ON co.id = c.country::INTEGER
WHERE 
    c.status = 'active'
    AND (
        c.first_name ILIKE $1 
        OR c.email ILIKE $1 
        OR c.contact_number_1 ILIKE $1
        OR c.customer_id::text ILIKE $1
    );
`

        const { rows } = await pool.query(query, [`%${customer}%`])

        if (rows.length === 0) return res.status(400).json({ message: "Hub not found" })

        const allResult = rows.map((name) => {
            const label = `${name.value} - ${name.first_name} ${name.last_name} `
            return { ...name, label }
        })

        return res.status(200).json({ message: "All City Found", result: allResult });
    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};
const getAllAccount = async (req, res) => {
    try {

        const { method_id } = req.query

        // const isNumber = !isNaN(customer) ? Number(customer) : null;

        const query = `SELECT id as value, name as label FROM accounts WHERE status = 'active' AND p_method_id = $1;`

        const { rows } = await pool.query(query, [method_id])

        if (rows.length === 0) return res.status(400).json({ message: "Account not found" })

        return res.status(200).json({ message: "All City Found", rows });
    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const saveCustomer = async (req, res) => {
    const {clientDetails} = req.body
    try {
        let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2,  address = $3, city = $4, country = $5`
        let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.address, clientDetails.city, clientDetails.country]

        if (clientDetails.email) {
            customerQuery += `, email = $${customerParams.length + 1}`
            customerParams.push(clientDetails.email)
        }

        if (clientDetails.contact_number_1) {
            customerQuery += `, contact_number_1 = $${customerParams.length + 1}`
            customerParams.push(clientDetails.contact_number_1)
        }

        if (clientDetails.apartment) {
            customerQuery += `, apartment = $${customerParams.length + 1}`
            customerParams.push(clientDetails.apartment)
        }

        if (clientDetails.postal_code) {
            customerQuery += `, postal_code = $${customerParams.length + 1}`
            customerParams.push(clientDetails.state)
        }

        customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
        customerParams.push(clientDetails.id)

        const customerResult = await pool.query(customerQuery, customerParams)

        if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        return res.status(200).json({ message: "customer updated successfully" });

    } catch (err) {
        console.error('Error fetching variants:', err);
    }

}

const getPermissionforuser = async (req, res) => {
  const user = req.user;
  const role_id = user.role_id;

  try {
    const roleQuery = `SELECT privileges FROM role_list WHERE id = $1`;
    const { rows } = await pool.query(roleQuery, [role_id]);

    if (rows.length === 0) {
      return res.status(400).json({ message: "Role not found" });
    }

    let privileges = rows[0].privileges;

    // ✅ Convert to integer array
    if (typeof privileges === "string") {
      privileges = JSON.parse(privileges);
    }

    const privilegeIds = privileges.map((id) => parseInt(id));

    // ✅ Fetch only matching menu items
    const menuQuery = `
      SELECT id 
      FROM uimenudata
      WHERE id = ANY($1::int[]) AND show = false
    `;

    const menuResult = await pool.query(menuQuery, [privilegeIds]);

    if (menuResult.rows.length === 0) {
      return res.status(400).json({ message: "Menu not found" });
    }

    const roleIds = menuResult.rows.map((r) => parseInt(r.id));

    return res.status(200).json({
      message: "Permissions fetched",
      data: roleIds,
    });

  } catch (err) {
    console.error('Error fetching permissions:', err);
    return res.status(500).json({ message: "Server error" });
  }
};

module.exports = { getAllCustomer, getAllPaymentMethod, allCountry, Notification, getAllCustomerUpdate, getAllAccount, saveCustomer, getPermissionforuser }