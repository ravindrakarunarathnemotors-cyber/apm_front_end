const pool = require("../config/db");
const { getCategoryIds, collectionIDS, productBrandIds } = require("../models/commonQuery");


// auto discount check ......................................................
const autodiscountCheck = async (req, res) => {
    const { cart_products, user_id } = req.body;


    try {
        // 🛑 Safety: handle missing or empty cart
        if (!Array.isArray(cart_products) || cart_products.length === 0) {
            return res.status(400).json({ success: false });
        }

        const totalAmount = cart_products.reduce((total, item) => {
            const price = parseFloat(item.price || 0);
            const qty = parseInt(item.selectedQty || 0);
            return total + price * qty;
        }, 0);

        // Get customer type (new or existing)
        const totalOrderResult = await pool.query(
            `SELECT COUNT(*) AS total FROM orders WHERE customer_id = $1`,
            [user_id]
        );

        const totalOrders = parseInt(totalOrderResult.rows[0]?.total || 0);
        const CustomerType = totalOrders === 0 ? 'new' : 'existing';



        const [product, orderDiscount] = await Promise.all([
            findProductDiscount(cart_products, totalAmount, user_id, CustomerType),
            orderAutoDiscount(user_id, CustomerType, totalAmount),
        ]);

        // --------------- Product Discounts -------------------- //
        let GenaralProduct = null

        if (product?.success === true) {
            GenaralProduct = product?.applied_discount
        }

        // --------------- Order Discounts -------------------- //
        const validDiscountscorrect = (orderDiscount || []).filter(
            (o) => o && o.discount_value > 0
        );

        const highestDiscount =
            validDiscountscorrect.length > 0
                ? validDiscountscorrect.reduce((max, obj) =>
                    obj.discount_value > max.discount_value ? obj : max
                )
                : null;

        // console.log(GenaralProduct, highestDiscount);
        const finalResult = compareDiscounts(GenaralProduct, highestDiscount);

        return res.status(200).json({
            success: true,
            data: { product: GenaralProduct, order: highestDiscount },
            final: finalResult
        });

    } catch (err) {
        console.error('Error in autodiscountCheck:', err);
        res
            .status(500)
            .json({ success: false, error: 'Internal Server Error', details: err.message });
    }
};

const findProductDiscount = async (cart_products, totalAmount, user_id, CustomerType) => {
    try {
        // Step 1: prepare ID sets
        const productIds = [...new Set(cart_products.map(p => p.product_id))];

        const categoryMap = {}; // product_id -> category_ids[]
        const collectionMap = {}; // product_id -> collection_ids[]
        const brandMap = {}; // product_id -> brand_ids[]

        for (const item of cart_products) {
            const [category_ids, collection_ids, brand_ids] = await Promise.all([
                getCategoryIds(item.product_id),
                collectionIDS(item.product_id),
                productBrandIds(item.product_id),
            ]);
            categoryMap[item.product_id] = category_ids;
            collectionMap[item.product_id] = collection_ids;
            brandMap[item.product_id] = brand_ids;
        }

        const allCategoryIds = Object.values(categoryMap).flat();
        const allCollectionIds = Object.values(collectionMap).flat();
        const allBrandIds = Object.values(brandMap).flat();

        // Step 2: fetch relevant discounts
        const q = `
            SELECT *
            FROM discounts
            WHERE status = 'active'
            AND start_date::date <= CURRENT_DATE
            AND (end_date::date >= CURRENT_DATE OR end_date IS NULL)
            AND main_discount_type  = 'product'
            AND prod_discount_method !=  'code'
            AND (
                target_products && $1::int[]
            OR target_categories && $2::int[]
            OR target_collections && $3::int[]
            OR target_brands && $4::int[]
            )
            AND (
                min_max_purchase_discount_limits = FALSE
                OR (
                min_max_purchase_discount_limits = TRUE
                AND $5 >= COALESCE(min_purchase_amount, 0)
                )
            );
            `;

        const { rows: discounts } = await pool.query(q, [
            productIds,
            allCategoryIds,
            allCollectionIds,
            allBrandIds,
            totalAmount
        ]);

        if (discounts.length === 0) {
            return { success: false }
        }


        // Step 3: evaluate total per discount
        const discountTotals = [];

        for (const d of discounts) {

            const {
                discount_id,
                unlimited_usage,
                discount_value_type,
                discount_value,
                max_discount_amount,
                customer_eligibility,
                usage_limit_per_account
            } = d

            let totalDiscount = 0;
            const applicableProducts = [];

            for (const item of cart_products) {
                const pid = item.product_id;
                const cats = categoryMap[pid] || [];
                const cols = collectionMap[pid] || [];
                const brs = brandMap[pid] || [];

                // Per customer usage check
                const customerUsageQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1 AND user_id = $2 AND type = 'order'`

                // Eligibility
                if (customer_eligibility !== 'all' && customer_eligibility !== CustomerType) break;

                if (!unlimited_usage) {
                    const custRes = await pool.query(customerUsageQuery, [discount_id, user_id]);
                    if (parseInt(custRes.rows[0].count) >= usage_limit_per_account) break

                }

                const matches =
                    (d.target_products || []).includes(pid) ||
                    (d.target_categories || []).some(c => cats.includes(c)) ||
                    (d.target_collections || []).some(c => cols.includes(c)) ||
                    (d.target_brands || []).some(b => brs.includes(b));


                if (!matches) continue;

                // Calculate discount for this product
                const price = parseFloat(item.price);
                const selectedQtyy = parseInt(item.selectedQty);
                const totalAmount = price * selectedQtyy;

                let thisDiscount = discount_value_type === 'fixed'
                    ? Math.min(
                        parseFloat(discount_value),
                        totalAmount
                    )
                    : Math.min(
                        (price * selectedQtyy) * (parseFloat(discount_value) / 100),
                        max_discount_amount ? parseFloat(max_discount_amount) : Infinity
                    );// percent-based example

                // Cap total if exceed max
                const maxAllowed = parseFloat(max_discount_amount || 0);
                if (maxAllowed > 0 && totalDiscount + thisDiscount > maxAllowed) {
                    const remaining = maxAllowed - totalDiscount;
                    thisDiscount = remaining > 0 ? remaining : 0;
                }

                if (thisDiscount > 0) {
                    totalDiscount += thisDiscount;
                    applicableProducts.push({
                        product_id: pid,
                        discount_value: thisDiscount,
                        variant_id: item.variant_id
                    });
                }

                // Stop if reached max
                if (maxAllowed > 0 && totalDiscount >= maxAllowed) break;
            }

            if (totalDiscount > 0) {
                discountTotals.push({
                    discount_id: d.discount_id,
                    total_discount_value: totalDiscount,
                    max_discount: max_discount_amount,
                    discount_value: discount_value,
                    applicableProducts,
                });
            }
        }


        // Step 4: choose biggest total discount
        const best = discountTotals.reduce(
            (max, d) => (d.total_discount_value > max.total_discount_value ? d : max),
            { total_discount_value: 0 }
        );

        // Step 5: return
        return {
            success: true,
            applied_discount: best,
        }

    } catch (error) {
        console.log(error)
        return { success: false }

    }
}


// Helper for reuse
const processDiscount = async (discount, user_id, CustomerType, price) => {
    const {
        discount_id,
        usage_limit_total,
        unlimited_usage,
        discount_value_type,
        discount_value,
        max_discount_amount,
        customer_eligibility,
        usage_limit_per_account
    } = discount;


    // Total usage check
    const usageCountQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1`

    // Per customer usage check
    const customerUsageQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1 AND user_id = $2 AND type = 'order'`

    // Eligibility
    if (customer_eligibility !== 'all' && customer_eligibility !== CustomerType) return null;

    // Check usage limits
    // if (usage_limit_total) {
    //     const totalRes = await pool.query(usageCountQuery, [discount_id]);
    //     if (parseInt(totalRes.rows[0].count) >= usage_limit_total) return null;
    // }

    if (!unlimited_usage) {
        const custRes = await pool.query(customerUsageQuery, [discount_id, user_id]);
        if (parseInt(custRes.rows[0].count) >= usage_limit_per_account) return null;
    }

    // Compute discount value
    const value =
        discount_value_type === 'fixed'
            ? parseFloat(discount_value)
            : Math.min(
                price * (parseFloat(discount_value) / 100),
                 max_discount_amount == null
                    ? Infinity
                    : parseFloat(max_discount_amount)
            );

    return { discount_id, discount_value: value };
};

//auto order discount general and payment method
const orderAutoDiscount = async (user_id, CustomerType, price) => {

    try {
        const orderDiscountQuery = `
      SELECT *
      FROM discounts
      WHERE status = 'active'
      AND start_date::date <= CURRENT_DATE
      AND (end_date::date >= CURRENT_DATE OR end_date IS NULL)
      AND order_discount_method IN ('general')
      AND (
        min_max_purchase_discount_limits = FALSE
        OR (
          min_max_purchase_discount_limits = TRUE
          AND $1 >= COALESCE(min_purchase_amount, 0)
        )
      )
    `;

        const orderDiscountResult = await pool.query(orderDiscountQuery, [price]);
        // console.log("first discount", orderDiscountResult.rows)
        // 🧩 No rows → just return empty array
        if (!orderDiscountResult?.rows?.length) {
            return [];
        }

        const validDiscounts = [];

        for (const d of orderDiscountResult.rows) {
            const result = await processDiscount(d, user_id, CustomerType, price);

            if (result && result.discount_value > 0) {
                const last_cal_discount = Math.min(parseFloat(result.discount_value), price)
                validDiscounts.push({
                    discount_id: result.discount_id,
                    discount_value: last_cal_discount,
                    type: 'order auto',
                    order_discount_method: d.order_discount_method || 'general',
                });
            }
        }

        // 🧩 Still empty? return safe array
        if (!validDiscounts.length) {
            return [];
        }

        return validDiscounts;
    } catch (error) {
        console.error('Error in orderAutoDiscount:', error);
        // 🧩 Always return empty array on failure, never undefined or null
        return [];
    }
};

//compare discount and select one
const compareDiscounts = (product, order) => {
    // ✅ Handle missing / invalid structures gracefully
    const hasProduct = product && typeof product === 'object' && Object.keys(product).length > 0;
    const hasOrder = order && typeof order === 'object' && Object.keys(order).length > 0;

    // Extract values safely
    const productDiscount = hasProduct
        ? Number(product?.total_discount_value || 0)
        : 0;

    const orderDiscount = hasOrder
        ? Number(order?.discount_value || 0)
        : 0;

    // Determine which is higher
    if (productDiscount === 0 && orderDiscount === 0) {
        return 'none'
    }

    if (productDiscount > orderDiscount) {
        return 'product'
    } else {
        return 'order'
    }
};



//dilvery discount
const autodeliverydiscountCheck = async (req, res) => {
    const { cart_products, deliverFee, user_id } = req.body;


    try {
        // 🛑 Safety: handle missing or empty cart
        if (!Array.isArray(cart_products) || cart_products.length === 0) {
            return res.status(400).json({ success: false });
        }

        const totalAmount = cart_products.reduce((total, item) => {
            const price = parseFloat(item.price || 0);
            const qty = parseInt(item.selectedQty || 0);
            return total + price * qty;
        }, 0);

        // Get customer type (new or existing)
        const totalOrderResult = await pool.query(
            `SELECT COUNT(*) AS total FROM orders WHERE customer_id = $1`,
            [user_id]
        );

        const totalOrders = parseInt(totalOrderResult.rows[0]?.total || 0);
        const CustomerType = totalOrders === 0 ? 'new' : 'existing';

        const orderDiscount = await orderAutoShippingDiscount(user_id, CustomerType, totalAmount, deliverFee)

        // --------------- Order Discounts -------------------- //
        const validDiscountscorrect = (orderDiscount || []).filter(
            (o) => o && o.discount_value > 0
        );

        const highestDiscount =
            validDiscountscorrect.length > 0
                ? validDiscountscorrect.reduce((max, obj) =>
                    obj.discount_value > max.discount_value ? obj : max
                )
                : null;



        return res.status(200).json({
            success: true,
            data: highestDiscount,
            final: 'shipping'
        });

    } catch (err) {
        console.error('Error in autodiscountCheck:', err);
        res
            .status(500)
            .json({ success: false, error: 'Internal Server Error', details: err.message });
    }
};

const orderAutoShippingDiscount = async (user_id, CustomerType, price, deliverFee) => {
    try {
        const orderDiscountQuery = `
      SELECT *
      FROM discounts
      WHERE status = 'active'
      AND start_date::date <= CURRENT_DATE
      AND (end_date::date >= CURRENT_DATE OR end_date IS NULL)
      AND order_discount_method IN ('shipping')
      AND (
        min_max_purchase_discount_limits = FALSE
        OR (
          min_max_purchase_discount_limits = TRUE
          AND $1 >= COALESCE(min_purchase_amount, 0)
        )
      )
    `;

        const orderDiscountResult = await pool.query(orderDiscountQuery, [price]);



        // 🧩 No rows → just return empty array
        if (!orderDiscountResult?.rows?.length === 0) {
            return [];
        }
        // console.log(orderDiscountResult?.rows, "delievbry discount")
        const validDiscounts = [];

        for (const d of orderDiscountResult.rows) {
            const result = await processDeliveryDiscount(d, user_id, CustomerType, price, deliverFee);
             console.log("result",result);

            if (result && result.discount_value > 0) {
                console.log(orderDiscountResult?.rows, "delievbry discount1")
                validDiscounts.push({
                    discount_id: result.discount_id,
                    discount_value: result.discount_value,
                    type: 'order auto',
                    order_discount_method: 'shipping',
                });
            }
        }
        console.log(validDiscounts)
        // 🧩 Still empty? return safe array
        if (!validDiscounts.length) {
            return [];
        }

        return validDiscounts;
    } catch (error) {
        console.error('Error in orderAutoDiscount:', error);
        // 🧩 Always return empty array on failure, never undefined or null
        return [];
    }
};

const processDeliveryDiscount = async (discount, user_id, CustomerType, price, deliverFee) => {
    const {
        discount_id,
        usage_limit_total,
        unlimited_usage,
        discount_value_type,
        discount_value,
        max_discount_amount,
        customer_eligibility,
        usage_limit_per_account
    } = discount;

    console.log("customer", customer_eligibility, CustomerType)

    // Total usage check
    // const usageCountQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1`

    // Per customer usage check
    const customerUsageQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1 AND user_id = $2 AND type = 'order'`

    // Eligibility
    if (customer_eligibility !== 'all' && customer_eligibility !== CustomerType) return null;

    // // Check usage limits
    // if (usage_limit_total) {
    //     const totalRes = await pool.query(usageCountQuery, [discount_id]);
    //     if (parseInt(totalRes.rows[0].count) >= usage_limit_total) return null;
    // }

    if (!unlimited_usage) {
        const custRes = await pool.query(customerUsageQuery, [discount_id, user_id]);
        if (parseInt(custRes.rows[0].count) >= usage_limit_per_account) return null;
    }

    // Compute discount value
    const value =
        discount_value_type === 'fixed'
            ?  Math.min(parseFloat(deliverFee), parseFloat(discount_value))
            : Math.min(
                Number(deliverFee) * (parseFloat(discount_value) / 100),
                 max_discount_amount == null
                    ? Infinity
                    : parseFloat(max_discount_amount)
            );

    return { discount_id, discount_value: value };
};


//method discount
const autodpmethoddiscountCheck = async (req, res) => {
    const { cart_products, id, user_id } = req.body;

    try {
        // 🛑 Safety: handle missing or empty cart
        if (!Array.isArray(cart_products) || cart_products.length === 0) {
            return res.status(400).json({ success: false });
        }

        const totalAmount = cart_products.reduce((total, item) => {
            const price = parseFloat(item.price || 0);
            const qty = parseInt(item.selectedQty || 0);
            return total + price * qty;
        }, 0);

        // Get customer type (new or existing)
        const totalOrderResult = await pool.query(
            `SELECT COUNT(*) AS total FROM orders WHERE customer_id = $1`,
            [user_id]
        );

        const totalOrders = parseInt(totalOrderResult.rows[0]?.total || 0);
        const CustomerType = totalOrders === 0 ? 'new' : 'existing';

        const orderDiscount = await orderAutoPmethodDiscount(user_id, CustomerType, totalAmount, id)

        // --------------- Order Discounts -------------------- //
        const validDiscountscorrect = (orderDiscount || []).filter(
            (o) => o && o.discount_value > 0
        );

        const highestDiscount =
            validDiscountscorrect.length > 0
                ? validDiscountscorrect.reduce((max, obj) =>
                    obj.discount_value > max.discount_value ? obj : max
                )
                : null;



        return res.status(200).json({
            success: true,
            data: highestDiscount,
            final: 'method'
        });

    } catch (err) {
        console.error('Error in autodiscountCheck:', err);
        res
            .status(500)
            .json({ success: false, error: 'Internal Server Error', details: err.message });
    }
};

const orderAutoPmethodDiscount = async (user_id, CustomerType, price, id) => {
    try {
        const orderDiscountQuery = `
      SELECT *
      FROM discounts
      WHERE status = 'active'
      AND start_date::date <= CURRENT_DATE
      AND (end_date::date >= CURRENT_DATE OR end_date IS NULL)
      AND order_discount_method IN ('payment_method')
      AND $1 = ANY(payment_method)
      AND (
        min_max_purchase_discount_limits = FALSE
        OR (
          min_max_purchase_discount_limits = TRUE
          AND $2 >= COALESCE(min_purchase_amount, 0)
        )
      )
    `;

        const orderDiscountResult = await pool.query(orderDiscountQuery, [parseInt(id), price]);

        // 🧩 No rows → just return empty array
        if (!orderDiscountResult?.rows?.length) {
            return [];
        }

        const validDiscounts = [];

        for (const d of orderDiscountResult.rows) {
            const result = await processDiscount(d, user_id, CustomerType, price);

            if (result && result.discount_value > 0) {
                 const last_cal_discount = Math.min(parseFloat(result.discount_value), price)
                validDiscounts.push({
                    discount_id: result.discount_id,
                    discount_value: last_cal_discount,
                    type: 'order auto',
                    order_discount_method: 'payment_method',
                });
            }
        }

        // 🧩 Still empty? return safe array
        if (!validDiscounts.length) {
            return [];
        }

        return validDiscounts;
    } catch (error) {
        console.error('Error in orderAutoDiscount:', error);
        // 🧩 Always return empty array on failure, never undefined or null
        return [];
    }
};


//buyx gety
const autodbuyxdiscountCheck = async (req, res) => {
    const { cart_products, user_id } = req.body;

    try {
        // 🛑 Safety: handle missing or empty cart
        if (!Array.isArray(cart_products) || cart_products.length === 0) {
            return res.status(400).json({ success: false });
        }

        const totalAmount = cart_products.reduce((total, item) => {
            const price = parseFloat(item.price || 0);
            const qty = parseInt(item.selectedQty || 0);
            return total + price * qty;
        }, 0);

        // Get customer type (new or existing)
        const totalOrderResult = await pool.query(
            `SELECT COUNT(*) AS total FROM orders WHERE customer_id = $1`,
            [user_id]
        );

        const totalOrders = parseInt(totalOrderResult.rows[0]?.total || 0);
        const CustomerType = totalOrders === 0 ? 'new' : 'existing';

        const product = await countproductbuyxDiscount(cart_products, totalAmount, user_id, CustomerType)
        // console.log(product)

        let GenaralProduct = null

        if (product?.success === true) {
            GenaralProduct = product?.applied_discount
        }

        return res.status(200).json({
            success: true,
            data: GenaralProduct,
            final: 'buyx'
        });

    } catch (err) {
        console.error('Error in autodiscountCheck:', err);
        res
            .status(500)
            .json({ success: false, error: 'Internal Server Error', details: err.message });
    }
};

const countproductbuyxDiscount = async (cart_products, totalAmount, user_id, CustomerType) => {
    try {
        // Step 1: prepare ID sets
        const productIds = [...new Set(cart_products.map(p => p.product_id))];

        const categoryMap = {}; // product_id -> category_ids[]
        const collectionMap = {}; // product_id -> collection_ids[]
        const brandMap = {}; // product_id -> brand_ids[]

        for (const item of cart_products) {
            const [category_ids, collection_ids, brand_ids] = await Promise.all([
                getCategoryIds(item.product_id),
                collectionIDS(item.product_id),
                productBrandIds(item.product_id),
            ]);
            categoryMap[item.product_id] = category_ids;
            collectionMap[item.product_id] = collection_ids;
            brandMap[item.product_id] = brand_ids;
        }

        const allCategoryIds = Object.values(categoryMap).flat();
        const allCollectionIds = Object.values(collectionMap).flat();
        const allBrandIds = Object.values(brandMap).flat();

        // Step 2: fetch relevant discounts
        const q = `
            SELECT *
            FROM discounts
            WHERE status = 'active'
            AND start_date::date <= CURRENT_DATE
            AND (end_date::date >= CURRENT_DATE OR end_date IS NULL)
            AND main_discount_type  = 'product'
            AND prod_discount_method =  'buyxgety'
            AND (
                target_products && $1::int[]
            OR target_categories && $2::int[]
            OR target_collections && $3::int[]
            OR target_brands && $4::int[]
            );
            `;

        const { rows: discounts } = await pool.query(q, [
            productIds,
            allCategoryIds,
            allCollectionIds,
            allBrandIds
        ]);

        if (discounts.length === 0) {
            return { success: false }
        }

        // Step 3: evaluate total per discount
        const discountTotals = [];

        for (const d of discounts) {

            const {
                discount_id,
                unlimited_usage,
                discount_value_type,
                discount_value,
                max_discount_amount,
                customer_eligibility,
                usage_limit_per_account,
                customer_buys_qty,
                customer_gets_qty
            } = d

            let totalDiscount = 0;
            const applicableProducts = [];

            for (const item of cart_products) {
                const pid = item.product_id;
                const cats = categoryMap[pid] || [];
                const cols = collectionMap[pid] || [];
                const brs = brandMap[pid] || [];

                // Per customer usage check
                const customerUsageQuery = `SELECT COUNT(*) FROM discount_usage WHERE discount_id = $1 AND user_id = $2 AND type = 'order'`

                // Eligibility
                if (customer_eligibility !== 'all' && customer_eligibility !== CustomerType) break;


                if (!unlimited_usage) {
                    const custRes = await pool.query(customerUsageQuery, [discount_id, user_id]);
                    if (parseInt(custRes.rows[0].count) >= usage_limit_per_account) break
                }

                const matches =
                    (d.target_products || []).includes(pid) ||
                    (d.target_categories || []).some(c => cats.includes(c)) ||
                    (d.target_collections || []).some(c => cols.includes(c)) ||
                    (d.target_brands || []).some(b => brs.includes(b));

                if (!matches) continue;

                // Check customer buys
                if (customer_buys_qty > 0 && item.selectedQty < customer_buys_qty) continue

                const applyDiscountAmount = Math.floor(item.selectedQty / customer_buys_qty);

                const totalfreeCount = parseFloat(applyDiscountAmount * customer_gets_qty);

                // Calculate discount for this product
                const price = parseFloat(item.price);
                let thisDiscount = price * totalfreeCount;

                totalDiscount += thisDiscount;

                // Cap total if exceed max
                // const maxAllowed = parseFloat(max_discount_amount || 0);
                // if (maxAllowed > 0 && totalDiscount + thisDiscount > maxAllowed) {
                //     const remaining = maxAllowed - totalDiscount;
                //     thisDiscount = remaining > 0 ? remaining : 0;
                // }

                // Stop if reached max
                applicableProducts.push({
                    product_id: pid,
                    variant_id: item.variant_id,
                    discount_value: thisDiscount,
                    free_count: totalfreeCount
                });
                // if (maxAllowed > 0 && totalDiscount >= maxAllowed) break;
            }

            if (totalDiscount > 0) {
                discountTotals.push({
                    discount_id: d.discount_id,
                    total_discount_value: totalDiscount,
                    applicableProducts,
                });
            }
        }


        // Step 4: choose biggest total discount
        const best = discountTotals.reduce(
            (max, d) => (d.total_discount_value > max.total_discount_value ? d : max),
            { total_discount_value: 0 }
        );

        // Step 5: return
        return {
            success: true,
            applied_discount: best,
        }
    } catch (error) {
        console.error('Error in countproductGenralDiscount:', error);
        // 🧩 Fallback object instead of null
        return { success: false }
    }
};

//..................................................................................

module.exports = {
    autodiscountCheck,
    autodeliverydiscountCheck,
    autodpmethoddiscountCheck,
    autodbuyxdiscountCheck
}