const pool = require("../config/db");
const { formatPhoneNumber } = require("../models/authModels");
const { adminUserDeatils, systemSettings, brandingSettings, getDeliveryFee, oneCountry, updateLoyaltySuctomer, checkLoyalty, addLoyalty } = require("../models/commonModels");
const { insertNotification } = require("../models/notificationsUpdater");
const { customhook } = require("../models/smsnotificationmodel");
const { insertAdminLog } = require("../models/userLogs");
const updateTransactionRecord = require("../routes/transactionsUpdater/transactionsUpdater");

const createInvoice = async (req, res) => {
    const { products, client, clientDetails, taxManualEnable, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountDetails, loyaltiPoints, bankSlipUrl, selectAccount, amount, lastSubTotal, fastAmount, inventoryDeduct } = req.body
    console.log("products", products)
    const user = req.user
    const user_id = user.user_id
    const merchant_id = user.merchant_id
    const outlet_id = user.outlet_id

    try {

        const type = discountDetails && discountDetails.type ? discountDetails.type : null

        const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

        const convertAmount = amount ? parseFloat(amount) : 0

        //admin merchant id
        const [adminDetails, system_settings, customerLoyalty] = await Promise.all([
            adminUserDeatils(user_id),
            systemSettings(),
            checkLoyalty(clientDetails.value)
        ])

        const merchant_id = adminDetails.merchant_id
        const username = adminDetails.username

        if (customerLoyalty < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })

        // check COD or not
        let cod = false
        if (selectedPaymentMethod?.value == 3) {
            cod = true
        }

        const totalAmount = lastSubTotal

        // const totalWeight = products.reduce((total, item) => {
        //     if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
        //     return total + parseFloat(item.weight * item.selectedQty)
        // }, 0);

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  taxManualEnable - tax add on off
        let grandtax = null;
        if (system_settings.tax && taxManualEnable) {
            grandtax = totalTax;
        }

        const fullAmount = fastAmount

        console.log("first", fullAmount)

        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let paymentStatus = 'unpaid'
        if (Number(fullAmount) == 0) {
            paymentStatus = 'paid'
        } else if (convertAmount == 0) {
            paymentStatus = 'unpaid'
        } else if (convertAmount < fullAmount) {
            paymentStatus = 'partially paid'
        } else if (convertAmount == fullAmount) {
            paymentStatus = 'paid'
        } else if (convertAmount > fullAmount) {
            return res.status(400).json({ message: "Amount is greater than total amount" })
        }

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        if (convertAmount > 0) {
            const points_given = parseFloat(system_settings.points_given) || 0
            const amount_spend = parseFloat(system_settings.amount_spend) || 0

            if (loyalty_point) {
                const orderPerPoint = convertAmount / amount_spend
                loyalty_points_earned = orderPerPoint * points_given
            }
        }

        const orderQuery = `INSERT INTO invoice_header (user_id, customer_id, merchant_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_name, sender_phone, sender_email, sender_address, sender_city, sender_country, payment_reference,  delivery_fee, discount, tax_percentage, tax,  full_amount,  discount_type, loyalty_points_spent, bank_slip, loyalty_points_earned, inventory_deduct, sender_addrees_2, outlet_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31) RETURNING id`

        const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod ? selectedPaymentMethod.value : null, 'pending', totalAmount, convertAmount, totalQuantity, 0, cod, paymentStatus, system_settings.currency, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.contact_number_1, clientDetails.email, clientDetails.address, clientDetails.city, clientDetails.country_name, refference, 0, totalDiscount, taxValue, grandtax, fullAmount, type, typeLoyaltyPoint, bankSlipUrl, loyalty_points_earned, inventoryDeduct, clientDetails.apartment, outlet_id]

        const orderResult = await pool.query(orderQuery, OrderParms)

        if (orderResult.rowCount === 0) return res.status(400).json({ message: "order not created" })


        const orderItemParams = []
        const values = []

        products.forEach(async (product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id == product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id == product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            if (type === 'manual_product' && product.discount) {
                const productDiscount = product.discountType === 'fixed' ? product.discount : (Number(product.price) * Number(product.selectedQty) * Number(product.discount)) / 100
                if (productDiscount) {
                    discount = productDiscount
                }
            }
            // const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            const baseIndex = 15 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8},
                $${baseIndex + 9}, $${baseIndex + 10}, $${baseIndex + 11}, $${baseIndex + 12},
                $${baseIndex + 13}, $${baseIndex + 14}, $${baseIndex + 15})`
            );


            orderItemParams.push(
                orderResult.rows[0].id,
                product.is_custom ? null : product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                0,
                is_free,                             // 8. is_free
                free_quantity,
                product.title || null,             // name
                product.description || null,       // description
                product.is_custom === true,         // is_custom
                product.amount_per_unit || null,   // amount_per_unit
                product.measurement_id || null,
                discount
            );

            //inventory
            if (inventoryDeduct && product.is_custom === false) {
                // console.log(product.variant_id);
                const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' ORDER BY inventory_id DESC LIMIT 1`;

                const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

                const searchInventoryResult = await pool.query(searchInventoryQuery, [
                    product.variant_id,
                    outlet_id,
                    merchant_id
                ]);

                let previous_quantity = 0;

                if (searchInventoryResult.rows.length > 0) {
                    previous_quantity = searchInventoryResult.rows[0].new_quantity;
                }

                const total_free = product.measurement_id == 1 ? free_quantity : Number(free_quantity) * Number(product.amount_per_unit)
                const current_qty = product.measurement_id == 1 ? product.selectedQty : Number(product.selectedQty) * Number(product.amount_per_unit)
                const total_qty = current_qty + total_free

                const new_quantity = Number(previous_quantity) - Number(total_qty);

                const insertInventoryResult = await pool.query(insertInventoryQuery, [
                    product.variant_id,
                    outlet_id,
                    username,
                    `Invoice(${orderResult.rows[0].id}) stock out`,
                    "stock out",
                    previous_quantity,
                    -total_qty,
                    new_quantity,
                    "active",
                    merchant_id,
                    user_id
                ]);

                if (insertInventoryResult.rowCount === 0) {
                    return res.status(400).json({ message: "Inventory not updated" })
                }
            }


        });


        //add order items 
        const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight, is_free, free_quantity, name, description, is_custom, amount_per_unit, unit_type, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

            const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].id, discountDetails.discount_id, client.value, 'invoice'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        if (convertAmount > 0) {
            const paymentHistoryQuery = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, reference, doc, loyalty_points_earned, loyalty_points_spent, acc_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`
            const UpadteAccountQuery = `UPDATE accounts SET balance = balance + $1 WHERE id = $2`

            const [paymentHistoryResult, updateAccount] = await Promise.all([
                pool.query(paymentHistoryQuery, [orderResult.rows[0].id, user_id, selectedPaymentMethod.value, convertAmount, refference, bankSlipUrl, loyalty_points_earned, typeLoyaltyPoint, selectAccount]),
                pool.query(UpadteAccountQuery, [convertAmount, selectAccount])
            ])

            if (paymentHistoryResult.rowCount === 0 || updateAccount.rowCount === 0) return res.status(400).json({ message: "Payment history not added" })
        }

        const module = "Invoive";
        const logMessage = `New invoice #${orderResult.rows[0].id} has been placed by user ${user_id}`;


        const [notification] = await Promise.all([
            insertNotification(user_id, 'Invoice Management', 'New Invoice Created', `New invoice #${orderResult.rows[0].id} has been placed for ${clientDetails.first_name} ${clientDetails.last_name}.`, 'admin', 'Unread'),
            insertAdminLog(user_id, module, logMessage),
            updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty)

        ])

        if (loyalty_point && convertAmount > 0) {
            await addLoyalty(clientDetails.value, loyalty_points_earned)
        }

        return res.status(200).json({ message: "success" });
    } catch (error) {
        console.log(error)
        return res.status(500).json({ message: "Internal server error" })
    }
}


const partiallyPayment = async (req, res) => {
    try {
        const { amount, invoice_id, file, paymentMethod, reference, subMethod } = req.body
        const user = req.user
        const user_id = user.user_id
        const system_settings = await systemSettings();


        const converAmount = parseFloat(amount)
        if (isNaN(converAmount)) return res.status(400).json({ message: "Amount is not valid" })

        const invoiceQuery = `SELECT id, customer_id, amount_paid, payment_status, full_amount  FROM invoice_header WHERE id = $1`
        const invoiceResult = await pool.query(invoiceQuery, [invoice_id])

        if (invoiceResult.rows.length === 0) return res.status(400).json({ message: "Invoice not found" })

        const invoice = invoiceResult.rows[0]
        const invoice_Fullamount = parseFloat(invoice.full_amount)
        const invoice_Amountpaid = parseFloat(invoice.amount_paid)
        const customer_id = invoice.customer_id

        if (invoice.payment_status === 'paid') return res.status(400).json({ message: "Invoice already paid" })

        const remainingAmount = invoice_Fullamount - invoice_Amountpaid

        if (converAmount > remainingAmount) return res.status(400).json({ message: `The amount entered is higher than the remaining balance. Please enter a valid amount.` })

        const newAmountPaid = invoice_Amountpaid + converAmount

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        if (converAmount > 0) {
            const points_given = parseFloat(system_settings.points_given) || 0
            const amount_spend = parseFloat(system_settings.amount_spend) || 0

            if (loyalty_point) {
                const orderPerPoint = converAmount / amount_spend
                loyalty_points_earned = orderPerPoint * points_given
            }
        }

        let paymentStatus = 'partially paid'

        if (newAmountPaid === invoice_Fullamount) paymentStatus = 'paid'
        if (newAmountPaid < invoice_Fullamount) paymentStatus = 'partially paid'

        console.log(paymentStatus)
        const updateInvoiceQuery = `UPDATE invoice_header SET amount_paid = $1, payment_status = $2,loyalty_points_earned = COALESCE(loyalty_points_earned, 0) + $3 WHERE id = $4` // loyalty_points_earned add before in here
        const updateInvoiceResult = await pool.query(updateInvoiceQuery, [newAmountPaid, paymentStatus, loyalty_points_earned, invoice_id])

        if (updateInvoiceResult.rowCount === 0) return res.status(400).json({ message: "Invoice not updated" })
const client = await pool.connect()

        try {
            await client.query("BEGIN")

            const paymentHistoryQuery = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, reference, doc, loyalty_points_earned, acc_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`
            const paymentHistoryResult = await client.query(paymentHistoryQuery, [
                invoice_id, user_id, paymentMethod, converAmount, reference, file, loyalty_points_earned, subMethod
            ])

            if (paymentHistoryResult.rowCount === 0) {
                await client.query("ROLLBACK")
                return res.status(400).json({ message: "Payment history not added" })
            }

            if (loyalty_point) {
                await addLoyalty(customer_id, loyalty_points_earned)
            }

            await updateTransactionRecord({
                client,
                amount:           converAmount,
                account_id:       subMethod,
                category_id:      paymentMethod,
                transaction_type: "income",
                note:             reference || `Invoice payment for invoice #${invoice_id}`,
                by_user_id:       user_id,
                payer_payee_id:   customer_id || null,
                outlet_id:        null,
                log_module:       "Invoice Payment",
                log_message:      `Invoice payment of ${converAmount} received for invoice #${invoice_id} by user ${user_id}. Status: ${paymentStatus}`,
            })

            await client.query("COMMIT")

            return res.status(200).json({ message: "success" })

        } catch (err) {
            await client.query("ROLLBACK")
            throw err
        } finally {
            client.release()
        }

    } catch (error) {
        console.error(error)
        return res.status(500).json({ message: "Internal server error" })
    }
}


const oneInvoiceUpdateDetails = async (req, res) => {
    const { order_id } = req.params;

    if (!order_id) {
        return res.status(400).json({ message: "order_id is required" });
    }

    const query = `
    SELECT
      o.id,
      o.order_status,
      o.payment_status,
      o.customer_id,
      o.payment_method_id,
      o.sender_name,
      o.sender_city,	
      o.sender_phone,
      o.sender_email,	
      o.sender_address,
      sender_co.id AS sender_country_id,
      sender_country AS sender_country_name,
      o.payment_reference,
      o.loyalty_points_spent,
      o.loyalty_points_earned,
      cu.loyalty_point,
      o.bank_slip,
      o.discount,
      o.discount_type,
      json_agg(
        json_build_object(
          'variant_id', oi.variant_id,
          'variant_value', v.variant_value,
          'count', CASE WHEN oi.amount_per_unit IS NULL THEN NULL ELSE oi.quantity * oi.amount_per_unit END,
          'product_id', oi.product_id,
          'selectedQty', oi.quantity,
          'unit_price', oi.unit_price,
          'price', oi.unit_price,
          'total_price', oi.total_price,
          'measurement_needed', CASE WHEN oi.unit_type::integer  = 1 THEN false ELSE true END,
          'measurement_id', oi.unit_type,
          'measurement_value', m.measurement_value,
          'amount_per_unit', oi.amount_per_unit,
          'main_img', pm.media_url,
          'first_extra_img', pmd_first.media_url,
          'title', oi.name,
          'description', oi.description
        )
        ORDER BY oi.id
      ) AS variants
    FROM invoice_header o
    INNER JOIN invoice_details oi ON oi.invoice_id = o.id
    LEFT JOIN products p ON p.product_id = oi.product_id
    LEFT JOIN product_variants v ON v.variant_id = oi.variant_id
    INNER JOIN customer cu ON cu.customer_id = o.customer_id
    LEFT JOIN measurements m ON oi.unit_type::integer = m.measurement_id
    LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
    LEFT JOIN countries sender_co ON LOWER(sender_co.country_name) = LOWER(o.sender_country)
    LEFT JOIN LATERAL (
      SELECT media_url
      FROM product_media
      WHERE product_id = p.product_id AND main = true AND variant_id IS NOT NULL
      ORDER BY created_at ASC
      LIMIT 1
    ) pmd_first ON true
    WHERE o.id = $1
    GROUP BY o.id, sender_co.id, cu.loyalty_point
  `;

    try {
        const result = await pool.query(query, [order_id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }
        return res.status(200).json({ message: "success", result: result.rows[0] });
    } catch (err) {
        console.error("Error fetching products by order ID:", err);
        return res.status(500).json({ message: "Server error", error: err.message });
    }
}

const updateInvoice = async (req, res) => {
    try {
        const { order_id } = req.params;
        const { products, client, clientDetails, taxManualEnable, billingaddress, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountType, selected, discountDetails, loyaltiPoints, bankSlipUrl, selectAccount, amount, lastSubTotal, fastAmount } = req.body

        // ✅ take from token instead of hardcoding
        const user = req.user
        const user_id = user.user_id
        const merchant_id = req.user?.merchant_id;
        const branch_id = req.user?.outlet_id || 1;


        const orderDetailsQuery = `SELECT id, customer_id, order_status, loyalty_points_spent, loyalty_points_earned, payment_status FROM invoice_header WHERE id = $1`;

        const [system_settings, orderDetails] = await Promise.all([
            systemSettings(),
            pool.query(orderDetailsQuery, [order_id])
        ]);

        if (orderDetails.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const order = orderDetails.rows[0];

        if (order.order_status !== "pending" || order.payment_status !== "unpaid") {
            return res.status(400).json({ message: "Order is not in pending status or already paid" });
        }

        const previousLoyaltyPoint = Number(order.loyalty_points_spent)
        const previousEarnedLoyaltyPoint = Number(order.loyalty_points_earned)

        //reset to previous value to loyality poins
        const updateLoyalityQuery = `UPDATE customer 
        SET loyalty_point = loyalty_point + $1 WHERE customer_id = $2`

        const updateLoyalityResult = await pool.query(updateLoyalityQuery, [(previousLoyaltyPoint - previousEarnedLoyaltyPoint), order.customer_id])

        if (updateLoyalityResult.rowCount === 0) {
            return res.status(404).json({ message: "Customer not found" });
        }

        const customerLoyalty = await checkLoyalty(clientDetails.value)

        const type = discountDetails && discountDetails.type ? discountDetails.type : null

        const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

        const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

        //calculate corrct ponit to reduce from customer
        const totalLoyalPoynt = Number(customerLoyalty)

        if ((totalLoyalPoynt) < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })

        const convertAmount = amount ? parseFloat(amount) : 0

        // check COD or not
        let cod = false
        if (selectedPaymentMethod == 3) {
            cod = true
        }

        const totalAmount = lastSubTotal

        const totalQuantity = products.reduce((total, item) => {
            return total + item.selectedQty
        }, 0);

        const totalDiscount = parseFloat(discount) || 0;

        // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  taxManualEnable - tax add on off
        let grandtax = null;
        if (system_settings.tax && taxManualEnable) {
            grandtax = totalTax;
        }

        console.log(system_settings)

        const fullAmount = fastAmount

        // update customer Details
        if (clientDetails.saveInfo === true) {
            let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
            let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

            if (clientDetails.email) {
                customerQuery += `, email = $${customerParams.length + 1}`
                customerParams.push(clientDetails.email)
            }

            if (clientDetails.apartment) {
                customerQuery += `, apartment = $${customerParams.length + 1}`
                customerParams.push(clientDetails.apartment)
            }

            if (clientDetails.postal_code) {
                customerQuery += `, postal_code = $${customerParams.length + 1}`
                customerParams.push(clientDetails.state)
            }

            customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
            customerParams.push(client.value)

            const customerResult = await pool.query(customerQuery, customerParams)

            if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

        }

        let paymentStatus = 'unpaid'
        if (Number(fullAmount) == 0) {
            paymentStatus = 'paid'
        } else if (convertAmount == 0) {
            paymentStatus = 'unpaid'
        } else if (convertAmount < fullAmount) {
            paymentStatus = 'partially paid'
        } else if (convertAmount == fullAmount) {
            paymentStatus = 'paid'
        } else if (convertAmount > fullAmount) {
            return res.status(400).json({ message: "Amount is greater than total amount" })
        }

        let loyalty_points_earned = 0
        const loyalty_point = system_settings.loyalty_point
        if (convertAmount > 0) {
            const points_given = parseFloat(system_settings.points_given) || 0
            const amount_spend = parseFloat(system_settings.amount_spend) || 0

            if (loyalty_point) {
                const orderPerPoint = convertAmount / amount_spend
                loyalty_points_earned = orderPerPoint * points_given
            }
        }

        const orderQuery = `
         UPDATE invoice_header 
                SET 
                user_id = $1,
                customer_id = $2,
                merchant_id = $3,
                payment_method_id = $4,
                total_value = $5,
                amount_paid = $6,
                total_item = $7,
                cod = $8,
                currency = $9,
                sender_name = $10,
                sender_city = $11,
                sender_phone = $12,
                sender_email = $13,
                sender_country = $14,
                sender_address = $15,
                payment_reference = $16,
                discount = $17,
                tax_percentage = $18,
                tax = $19,
                full_amount = $20,
                discount_type = $21,
                loyalty_points_spent = $22,
                bank_slip = $23,
                loyalty_points_earned = $24,
                payment_status = $25
                WHERE id = $26
                RETURNING id;

        `;


        const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod ? selectedPaymentMethod.value : null, totalAmount, convertAmount, totalQuantity, cod, system_settings.currency, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.city, clientDetails.contact_number_1, clientDetails.email, clientDetails.country_name, clientDetails.address, refference, parseFloat(totalDiscount ? totalDiscount : 0) || 0, taxValue, grandtax, fullAmount, type, typeLoyaltyPoint, bankSlipUrl, loyalty_points_earned, paymentStatus, order_id]

        const orderResult = await pool.query(orderQuery, OrderParms);

        if (orderResult.rowCount === 0) {
            return res.status(400).json({ message: "Order not found" });
        }

        const deleteItemsQuery = pool.query(
            `DELETE FROM invoice_details WHERE invoice_id = $1`,
            [order_id]
        );

        const deleteDiscountQuery = pool.query(
            `DELETE FROM discount_usage WHERE order_id = $1 AND type = 'invoice'`,
            [order_id]
        );

        const [deleteItemsResult, deleteDiscountResult] = await Promise.all([
            deleteItemsQuery,
            deleteDiscountQuery,
        ]);

        if (deleteItemsResult.rowCount === 0) {
            return res.status(400).json({ message: "Order not found" });
        }

        const orderItemParams = []
        const values = []

        products.forEach((product, i) => {

            let is_free = false;
            let free_quantity = 0;
            let discount = 0;

            // Check if discount applies
            if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
                const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
            }

            if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
                const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
                if (match) {
                    discount = match.discount_value || 0;
                }
            }

            if (type === 'manual_product' && product.discount) {
                const productDiscount = product.discountType === 'fixed' ? product.discount : (Number(product.price) * Number(product.selectedQty) * Number(product.discount)) / 100
                if (productDiscount) {
                    discount = productDiscount
                }
            }
            // const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

            const baseIndex = 15 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8},
                $${baseIndex + 9}, $${baseIndex + 10}, $${baseIndex + 11}, $${baseIndex + 12},
                $${baseIndex + 13}, $${baseIndex + 14}, $${baseIndex + 15})`
            );


            orderItemParams.push(
                orderResult.rows[0].id,
                product.is_custom ? null : product.product_id,
                product.variant_id,
                product.selectedQty,
                product.price,
                product.price * product.selectedQty,
                0,
                is_free,                             // 8. is_free
                free_quantity,
                product.title || null,             // name
                product.description || null,       // description
                product.is_custom === true,         // is_custom
                product.amount_per_unit || null,   // amount_per_unit
                product.measurement_id || null,
                discount
            );
        });

        //add order items 
        const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight, is_free, free_quantity, name, description, is_custom, amount_per_unit, unit_type, discount) VALUES ${values.join(',')}`


        const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

        if (orderItemResult.rowCount === 0) {
            return res.status(400).json({ message: "Order item not added" })
        }

        if (discountDetails && discountDetails?.discount_id && type != 'manual') {
            //discount useage table
            const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

            const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value, 'invoice'])

            if (discountUsageResult.rowCount === 0) {
                return res.status(400).json({ message: "Discount usage not added" })
            }
        }

        if (convertAmount > 0) {
            const paymentHistoryQuery = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, reference, doc, loyalty_points_earned, loyalty_points_spent, acc_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`
            const UpadteAccountQuery = `UPDATE accounts SET balance = balance + $1 WHERE id = $2`

            const [paymentHistoryResult, updateAccount] = await Promise.all([
                pool.query(paymentHistoryQuery, [orderResult.rows[0].id, user_id, selectedPaymentMethod.value, convertAmount, refference, bankSlipUrl, typeLoyaltyPoint, loyalty_points_earned, selectAccount]),
                pool.query(UpadteAccountQuery, [convertAmount, selectAccount])
            ])

            if (paymentHistoryResult.rowCount === 0 || updateAccount.rowCount === 0) return res.status(400).json({ message: "Payment history not added" })
        }

        const module = "Invoice";
        const logMessage = `Invoice #${order_id} has been updated by user ${user_id}.`;

        const [notification] = await Promise.all([
            insertNotification(user_id, 'Order Management', 'Update Order', `Order #${order_id} has been updated by user ${user_id}.`, 'admin', 'Unread'),
            insertAdminLog(user_id, module, logMessage),
            updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty)

        ])

        if (loyalty_point && convertAmount > 0) {
            await addLoyalty(clientDetails.value, loyalty_points_earned)
        }

        return res.status(200).json({
            message: "Order updated successfully",
        });

    } catch (err) {
        console.error('Error updating order:', err);
        return res.status(500).json({ message: "Server error", error: err.message });
    }
}

const deleteInvoice = async (req, res) => {

    const user = req.user
    const user_id = user.user_id
    // const merchant_id = user.merchant_id;
    // const outlet_id = user.outlet_id

    const client = await pool.connect();

    try {
        const { order_id } = req.body

        if (!order_id) {
            return res.status(400).json({ message: "Order ID is required" })
        }

        const invoice_details = `SELECT id, variant_id,quantity, free_quantity, amount_per_unit, unit_type, batch_no FROM invoice_details WHERE invoice_id = $1`
        const invoice_header = `SELECT outlet_id, merchant_id, customer_id, loyalty_points_earned, loyalty_points_spent FROM invoice_header WHERE id = $1`
        const userQuery = `SELECT username FROM users WHERE user_id = $1`;

        const [invoice_details_result, invoice_header_result, userResult] = await Promise.all([
            pool.query(invoice_details, [order_id]),
            pool.query(invoice_header, [order_id]),
            pool.query(userQuery, [user_id]),
        ])

        if (invoice_details_result.rows.length === 0) {
            return res.status(400).json({ message: "Invoice not found" })
        }

        if (userResult.rows.length === 0) return res.status(400).json({ message: "User not found" })

        if (invoice_header_result.rows.length === 0) return res.status(400).json({ message: "Invoice header not found" })

        const username = userResult.rows[0].username

        const products = invoice_details_result.rows
        const header = invoice_header_result.rows[0]

        if (!header.outlet_id || !header.merchant_id) return res.status(400).json({ message: "Outlet or merchant not found" })

        await client.query('BEGIN')

        // -----------------------------
        // GET PAYMENT HISTORY
        // -----------------------------
        const result = await client.query(
            `SELECT acc_id, amount, method_id, invoice_id FROM invoice_payment_history WHERE invoice_id = $1`,
            [order_id]
        )

        if (result.rows.length === 0) {
            throw new Error("Payment history not found")
        }

        //loyality_points
        if (header.customer_id) {
            const customer_id = header.customer_id;
            const earn_point = parseFloat(header.loyalty_points_earned) || 0;
            const spend_point = parseFloat(header.loyalty_points_spent) || 0;

            const loyalty_result = await client.query(
                `SELECT loyalty_point FROM customer WHERE customer_id = $1`,
                [customer_id]
            );

            if (loyalty_result.rows.length === 0) {
                throw new Error("Customer not found")
            }

            const current = parseFloat(loyalty_result.rows[0].loyalty_point) || 0

            const last_amount = current - earn_point + spend_point;

            const updateCustomer = await client.query(
                `UPDATE customer SET loyalty_point =  $1 WHERE customer_id = $2`,
                [last_amount, customer_id]
            )

            if (updateCustomer.rowCount === 0) {
                throw new Error("Customer not found")
            }

            const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;

            const new_amount = current + last_amount

            const result = await client.query(query, [customer_id, current, last_amount, new_amount, 'Invoice Deleted']);

            if (result.rowCount === 0) {
                throw new Error(`Failed to add points log`);
            }

        }

        // -----------------------------
        // REVERSE ACCOUNT BALANCES
        // -----------------------------
        for (const payment of result.rows) {
            //used amount
            const amount = parseFloat(payment.amount)

            if (payment.method_id == 5 || payment.method_id == 8 || payment.method_id == 4) {
                const acc_id = payment.acc_id

                if (!acc_id) {
                    throw new Error("Invalid account id")
                }

                const updateAccount = await client.query(
                    `UPDATE accounts SET balance = balance - $1 WHERE id = $2`,
                    [amount, acc_id]
                )

                if (updateAccount.rowCount === 0) {
                    throw new Error("Account not found")
                }
            } 

        }

        // -----------------------------
        // DEACTIVATE PAYMENT HISTORY
        // -----------------------------
        const paymentUpdate = await client.query(
            `UPDATE invoice_payment_history SET status = 'inactive' WHERE invoice_id = $1`,
            [order_id]
        )

        if (paymentUpdate.rowCount === 0) {
            throw new Error("Payment history update failed")
        }

        // -----------------------------
        // DELETE INVOICE
        // -----------------------------
        const deleteResult = await client.query(
            `UPDATE invoice_header SET order_status = 'delete', payment_status = 'unpaid' WHERE id = $1`,
            [order_id]
        )

        if (deleteResult.rowCount === 0) {
            throw new Error("Order not found")
        }

        for (const product of products) {
            let free_quantity = 0;

            if (Number(product.free_quantity) > 0) {
                const per_unit = product.amount_per_unit ? Number(product.amount_per_unit) : 1
                free_quantity = Number(product.free_quantity) * Number(per_unit)
            }

            // console.log(product.variant_id);
            const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' AND (batch_number = $4 OR (batch_number IS NULL AND $4 IS NULL)) ORDER BY inventory_id DESC LIMIT 1`;

            const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id, batch_number
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

            const searchInventoryResult = await client.query(searchInventoryQuery, [
                product.variant_id,
                header.outlet_id,
                header.merchant_id,
                product.batch_no
            ]);

            let previous_quantity = 0;

            if (searchInventoryResult.rows.length > 0) {
                previous_quantity = searchInventoryResult.rows[0].new_quantity;
            }
            console.log("inventory free", free_quantity)

            const product_quantity = product.amount_per_unit ? Number(product.quantity) * Number(product.amount_per_unit) : Number(product.quantity)

            const total_qty = free_quantity + product_quantity;

            const new_quantity = Number(previous_quantity) + total_qty

            const insertInventoryResult = await client.query(insertInventoryQuery, [
                product.variant_id,
                header.outlet_id,
                username,
                `POS stock in invoice number ${order_id}`,
                "stock in",
                previous_quantity,
                total_qty,
                new_quantity,
                "active",
                header.merchant_id,
                user_id,
                product.batch_no
            ]);

            if (insertInventoryResult.rowCount === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "Inventory not updated" })
            }
        }

        // -----------------------------
        // COMMIT FIRST
        // -----------------------------
        await client.query('COMMIT')

        // -----------------------------
        // LOGS AFTER COMMIT
        // -----------------------------
        const module = "Invoice";
        const logMessage = `Invoice #${order_id} deleted by user ${req.user?.user_id}`;

        await Promise.all([
            insertNotification(
                req.user?.user_id,
                'Invoice Management',
                'Delete Invoice',
                `Invoice #${order_id} has been deleted by user ${req.user?.user_id}.`,
                'admin',
                'Unread'
            ),
            insertAdminLog(req.user?.user_id, module, logMessage)
        ])

        return res.status(200).json({
            message: "Order deleted successfully",
        });

    } catch (err) {

        await client.query('ROLLBACK')

        console.error('Error deleting order:', err);

        return res.status(400).json({
            message: err.message || "Server error"
        });

    } finally {
        client.release();
    }
};

const deleteBackOfficeInvoice = async (req, res) => {

    const user = req.user
    const user_id = user.user_id
    // const merchant_id = user.merchant_id;
    // const outlet_id = user.outlet_id

    const client = await pool.connect();

    try {
        const { order_id } = req.body

        if (!order_id) {
            return res.status(400).json({ message: "Order ID is required" })
        }

        const invoice_details = `SELECT id, variant_id,quantity, free_quantity, amount_per_unit, unit_type, batch_no FROM invoice_details WHERE invoice_id = $1 AND is_custom = false`
        const invoice_header = `SELECT outlet_id, merchant_id, customer_id, loyalty_points_earned, loyalty_points_spent FROM invoice_header WHERE id = $1`
        const userQuery = `SELECT username FROM users WHERE user_id = $1`;

        const [invoice_details_result, invoice_header_result, userResult] = await Promise.all([
            pool.query(invoice_details, [order_id]),
            pool.query(invoice_header, [order_id]),
            pool.query(userQuery, [user_id]),
        ])

        if (invoice_details_result.rows.length === 0) {
            return res.status(400).json({ message: "Invoice not found" })
        }

        if (userResult.rows.length === 0) return res.status(400).json({ message: "User not found" })

        if (invoice_header_result.rows.length === 0) return res.status(400).json({ message: "Invoice header not found" })

        const username = userResult.rows[0].username

        const products = invoice_details_result.rows
        const header = invoice_header_result.rows[0]

        if (!header.outlet_id || !header.merchant_id) return res.status(400).json({ message: "Outlet or merchant not found" })

        await client.query('BEGIN')

        // -----------------------------
        // GET PAYMENT HISTORY
        // -----------------------------
        const result = await client.query(
            `SELECT acc_id, amount, method_id, invoice_id FROM invoice_payment_history WHERE invoice_id = $1`,
            [order_id]
        )

        if (result.rows.length === 0) {
            throw new Error("Payment history not found")
        }

        //loyality_points
        if (header.customer_id) {
            const customer_id = header.customer_id;
            const earn_point = parseFloat(header.loyalty_points_earned) || 0;
            const spend_point = parseFloat(header.loyalty_points_spent) || 0;

            const loyalty_result = await client.query(
                `SELECT loyalty_point FROM customer WHERE customer_id = $1`,
                [customer_id]
            );

            if (loyalty_result.rows.length === 0) {
                throw new Error("Customer not found")
            }

            const current = parseFloat(loyalty_result.rows[0].loyalty_point) || 0

            const last_amount = current - earn_point + spend_point;

            const updateCustomer = await client.query(
                `UPDATE customer SET loyalty_point =  $1 WHERE customer_id = $2`,
                [last_amount, customer_id]
            )

            if (updateCustomer.rowCount === 0) {
                throw new Error("Customer not found")
            }

            const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;

            const new_amount = current + last_amount

            const result = await client.query(query, [customer_id, current, last_amount, new_amount, 'Invoice Deleted']);

            if (result.rowCount === 0) {
                throw new Error(`Failed to add points log`);
            }

        }

        // -----------------------------
        // REVERSE ACCOUNT BALANCES
        // -----------------------------
        for (const payment of result.rows) {
            //used amount
            const amount = parseFloat(payment.amount)

            if (payment.method_id == 5 || payment.method_id == 8 || payment.method_id == 4) {
                const acc_id = payment.acc_id

                if (!acc_id) {
                    throw new Error("Invalid account id")
                }

                const updateAccount = await client.query(
                    `UPDATE accounts SET balance = balance - $1 WHERE id = $2`,
                    [amount, acc_id]
                )

                if (updateAccount.rowCount === 0) {
                    throw new Error("Account not found")
                }
            } 

        }

        // -----------------------------
        // DEACTIVATE PAYMENT HISTORY
        // -----------------------------
        const paymentUpdate = await client.query(
            `UPDATE invoice_payment_history SET status = 'inactive' WHERE invoice_id = $1`,
            [order_id]
        )

        if (paymentUpdate.rowCount === 0) {
            throw new Error("Payment history update failed")
        }

        // -----------------------------
        // DELETE INVOICE
        // -----------------------------
        const deleteResult = await client.query(
            `UPDATE invoice_header SET order_status = 'delete', payment_status = 'unpaid' WHERE id = $1`,
            [order_id]
        )

        if (deleteResult.rowCount === 0) {
            throw new Error("Order not found")
        }

        for (const product of products) {
            let free_quantity = 0;

            if (Number(product.free_quantity) > 0) {
                const per_unit = product.amount_per_unit ? Number(product.amount_per_unit) : 1
                free_quantity = Number(product.free_quantity) * Number(per_unit)
            }

            // console.log(product.variant_id);
            const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' AND (batch_number = $4 OR (batch_number IS NULL AND $4 IS NULL)) ORDER BY inventory_id DESC LIMIT 1`;

            const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id, batch_number
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

            const searchInventoryResult = await client.query(searchInventoryQuery, [
                product.variant_id,
                header.outlet_id,
                header.merchant_id,
                product.batch_no
            ]);

            let previous_quantity = 0;

            if (searchInventoryResult.rows.length > 0) {
                previous_quantity = searchInventoryResult.rows[0].new_quantity;
            }
            console.log("inventory free", free_quantity)

            const product_quantity = product.amount_per_unit ? Number(product.quantity) * Number(product.amount_per_unit) : Number(product.quantity)

            const total_qty = free_quantity + product_quantity;

            const new_quantity = Number(previous_quantity) + total_qty

            const insertInventoryResult = await client.query(insertInventoryQuery, [
                product.variant_id,
                header.outlet_id,
                username,
                `POS stock in invoice number ${order_id}`,
                "stock in",
                previous_quantity,
                total_qty,
                new_quantity,
                "active",
                header.merchant_id,
                user_id,
                product.batch_no
            ]);

            if (insertInventoryResult.rowCount === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "Inventory not updated" })
            }
        }

        // -----------------------------
        // COMMIT FIRST
        // -----------------------------
        await client.query('COMMIT')

        // -----------------------------
        // LOGS AFTER COMMIT
        // -----------------------------
        const module = "Invoice";
        const logMessage = `Invoice #${order_id} deleted by user ${req.user?.user_id}`;

        await Promise.all([
            insertNotification(
                req.user?.user_id,
                'Invoice Management',
                'Delete Invoice',
                `Invoice #${order_id} has been deleted by user ${req.user?.user_id}.`,
                'admin',
                'Unread'
            ),
            insertAdminLog(req.user?.user_id, module, logMessage)
        ])

        return res.status(200).json({
            message: "Order deleted successfully",
        });

    } catch (err) {

        await client.query('ROLLBACK')

        console.error('Error deleting order:', err);

        return res.status(400).json({
            message: err.message || "Server error"
        });

    } finally {
        client.release();
    }
};

module.exports = {
    createInvoice, partiallyPayment, oneInvoiceUpdateDetails, updateInvoice, deleteInvoice, deleteBackOfficeInvoice
}