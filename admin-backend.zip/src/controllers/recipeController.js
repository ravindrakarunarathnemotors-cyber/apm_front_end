const pool = require("../config/db");
const { insertAdminLog } = require("../models/userLogs");

const getProductSearch = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id


    const { search } = req.query;
    const query = `SELECT
    v.variant_id,
    v.variant_value,
    v.price,
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
    pm.media_url AS main_img,
    pmd_first.media_url AS first_extra_img
    FROM products p
    JOIN product_variants v
    ON p.product_id = v.product_id
    LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
    LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
        AND main = true 
        AND variant_id IS NOT NULL
        ORDER BY created_at ASC
        LIMIT 1
    ) pmd_first ON true
    WHERE p.status = 'active' AND v.status = 'active'
    AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR v.variant_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )
    ORDER BY v.variant_id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};
const getRawMaterialSearch = async (req, res) => {
    const user = req.user;


    const { search } = req.query;
    const query = `SELECT
    r.id,
    r.name,
    r.reorder_level,
    r.measurement_unit,
    m.measurement_value,
    CASE WHEN r.measurement_unit = 1 THEN false ELSE true END AS measurement_needed
    FROM raw_material r
    LEFT JOIN measurements m ON r.measurement_unit = m.measurement_id
    WHERE r.status = 'Active'
    AND r.name ILIKE '%' || $1 || '%'
    ORDER BY r.id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const saveRecipe = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id
    const user_id = user.user_id

    const client = await pool.connect();
    try {

        const { selectProduct, allIngredents } = req.body
        console.log(selectProduct)

        if (!selectProduct || allIngredents.length === 0) {
            return res.status(400).json({ message: "Please select product and add ingredents" })
        }

        for (const item of allIngredents) {
            if (!item.quantity) {
                return res.status(400).json({
                    message: "Please add quantity for all ingredients"
                });
            }
        }

        await client.query("BEGIN");

        const query2 = `SELECT * FROM recipe WHERE variant_id = $1`;
        const result2 = await client.query(query2, [selectProduct.variant_id]);

        if (result2.rows.length > 0) {
            const query1 = `DELETE FROM recipe WHERE variant_id = $1`;
            const result1 = await client.query(query1, [selectProduct.variant_id]);

            if (result1.rowCount === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "Failed to delete recipe" })
            }

        }


        const params = [];
        const values = [];

        allIngredents.forEach((item, i) => {

            const baseIndex = 8 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8})`
            );

            params.push(
                selectProduct.product_id,
                selectProduct.variant_id,
                item.id,
                item.quantity,
                item.measurement_unit,
                user_id,
                new Date(),
                'active'
            );
        });

        const query = `
            INSERT INTO recipe (product_id, variant_id, raw_id, quantity, measurement_unit, by, date, status)
            VALUES ${values.join(", ")}
            RETURNING id;
        `;

        const result = await client.query(query, params);

        if (result.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to save recipe" })
        }

        const module = "Recipe";
        const logMessage = `User ${user_id} created recipe for product ${selectProduct.product_id} with name '${selectProduct.name}'`;

        await insertAdminLog(user_id, module, logMessage)

        await client.query("COMMIT");

        return res.status(200).json({ message: "Recipe saved successfully" });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    } finally {
        client.release();
    }

}

const allRecipe = async (req, res) => {
    const user = req.user;

    const { page, date, todate, inputKeywords } = req.body;

    const parsedLimit = 25;
    const parsedPage = parseInt(page, 10) || 1;
    const offset = (parsedPage - 1) * parsedLimit;

    try {
        const queryParams = [];
        let whereConditions = [];

        // base condition
        whereConditions.push(`r.status = 'active'`);

        // date filter
        if (date && todate) {
            whereConditions.push(
                `r.date::date BETWEEN $${queryParams.length + 1} AND $${queryParams.length + 2}`
            );
            queryParams.push(date, todate);
        }

        // keyword filter (FIXED: single parameter)
        if (inputKeywords) {
            whereConditions.push(
                `(p.title ILIKE $${queryParams.length + 1} OR r.product_id::text ILIKE $${queryParams.length + 1})`
            );
            queryParams.push(`%${inputKeywords}%`);
        }

        const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

        // MAIN QUERY
        const query = `
                    SELECT 
                r.variant_id,
                r.product_id,
                MAX(r.date) AS date,
                p.title AS name,
                u.first_name,
                v.variant_value,
                r.by,
                json_agg(
                    json_build_object(
                        'raw_id', r.raw_id,
                        'quantity', r.quantity,
                        'measurement_unit', r.measurement_unit,
                        'measurement_value', m.measurement_value,
                        'material_name', rm.name
                    )
                ) AS ingredients
            FROM recipe r
            LEFT JOIN products p ON p.product_id = r.product_id
            LEFT JOIN product_variants v ON v.variant_id = r.variant_id
            LEFT JOIN raw_material rm ON rm.id = r.raw_id
            LEFT JOIN measurements m ON m.measurement_id = r.measurement_unit
            LEFT JOIN users u ON u.user_id = r.by
            ${whereClause}
            GROUP BY 
                r.variant_id,
                r.product_id,
                p.title,
                u.first_name,
                r.by,
                v.variant_value
            ORDER BY MAX(r.date) DESC
            LIMIT $${queryParams.length + 1}
            OFFSET $${queryParams.length + 2};
        `;

        // COUNT QUERY (FIXED: includes products table join)
        const countQuery = `
            SELECT COUNT(DISTINCT (r.product_id, r.variant_id)) AS total
            FROM recipe r
            LEFT JOIN products p ON p.product_id = r.product_id
            LEFT JOIN raw_material rm ON rm.id = r.raw_id
            LEFT JOIN measurements m ON m.measurement_id = r.measurement_unit
            LEFT JOIN users u ON u.user_id = r.by
            ${whereClause};
        `;

        const [result, countResult] = await Promise.all([
            pool.query(query, [...queryParams, parsedLimit, offset]),
            pool.query(countQuery, queryParams)
        ]);

        const total = parseInt(countResult.rows[0].total, 10);

        return res.status(200).json({
            message: "success",
            result: result.rows,
            total,
            totalPages: Math.ceil(total / parsedLimit)
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const add_raw_material_stock = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id
    const client = await pool.connect();

    try {
        const { outlet_id, stocktype, ingredients } = req.body;

        // 🔴 Basic Validation
        if (!outlet_id || !stocktype || !ingredients || ingredients.length === 0) {
            return res.status(400).json({
                message: "Missing required fields"
            });
        }

        if (!["in", "out"].includes(stocktype)) {
            return res.status(400).json({
                message: "Invalid stock type"
            });
        }

        for (const item of ingredients) {
            if (!item.quantity) {
                return res.status(400).json({
                    message: "Please add quantity for all ingredients"
                });
            }
        }

        const remark =
            stocktype === "in"
                ? "Stock In via Raw Material Module"
                : "Stock Out via Raw Material Module";

        await client.query("BEGIN");

        // 1️⃣ Insert Header
        const headerResult = await client.query(
            `INSERT INTO ingredients_stock_header
            (user_id, stock_type, remark, created_at, outlet_id)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id`,
            [user_id, stocktype, remark || null, new Date(), outlet_id]
        );

        if (headerResult.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({
                message: "Failed to Insert Ingredients Stock Header"
            });
        }

        const sheet_id = headerResult.rows[0].id;

        // 2️⃣ Process Each Ingredient
        for (const item of ingredients) {

            const { id, quantity } = item;

            if (!id || !quantity) {
                await client.query("ROLLBACK");
                return res.status(400).json({
                    message: "Invalid ingredient data"
                });
            }

            // 2.1️⃣ Get Previous Stock
            const prevStockResult = await client.query(
                `SELECT current_stock
                 FROM material_inventory
                 WHERE material_id = $1
                 AND outlet_id = $2
                 ORDER BY id DESC
                 LIMIT 1`,
                [id, outlet_id]
            );

            const prev_stock = prevStockResult.rows.length > 0
                ? Number(prevStockResult.rows[0].current_stock)
                : 0;

            // 2.2️⃣ Calculate New Stock
            let change_stock = Number(quantity);
            let current_stock;

            if (stocktype === "in") {
                current_stock = prev_stock + change_stock;
            } else {
                current_stock = prev_stock - change_stock;

                // if (current_stock < 0) {
                //     await client.query("ROLLBACK");
                //     return res.status(400).json({
                //         message: `Insufficient stock for material ID ${id}`
                //     });
                // }
            }

            // 2.3️⃣ Insert into ingredients_stock_details
            await client.query(
                `INSERT INTO ingredients_stock_details
                (sheet_id, ingredient_id, prev_stock, change_stock, current_stock, created_at)
                VALUES ($1, $2, $3, $4, $5, NOW())`,
                [sheet_id, id, prev_stock, change_stock, current_stock]
            );

            // 2.4️⃣ Insert into material_inventory (ledger entry)
            await client.query(
                `INSERT INTO material_inventory
                (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type)
                VALUES ($1, $2, $3, $4, $5, $9, $6, $7, $8, $10)`,
                [
                    id,
                    prev_stock,
                    stocktype === "in" ? change_stock : -change_stock,
                    current_stock,
                    user_id,
                    "RAW_MATERIAL_STOCK",
                    outlet_id,
                    remark || null,
                    new Date(),
                    stocktype
                ]
            );
        }

        const module = "RAW_MATERIAL_STOCK";
        const logMessage = `Admin ${user_id} updated raw material stock`;

        await insertAdminLog(user_id, module, logMessage),

            await client.query("COMMIT");

        return res.status(200).json({
            message: "Stock updated successfully"
        });

    } catch (error) {
        await client.query("ROLLBACK");
        console.error(error);

        return res.status(500).json({
            message: "Internal server error"
        });
    } finally {
        client.release();
    }
};

const getAllkitchen = async (req, res) => {
    const user = req.user;

    const query = `SELECT
    id as value,
    name as label,
    outlet_id
    FROM kitchen
    WHERE status = 'Active'
        `;

    try {
        const result = await pool.query(query);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const getProductSearchkitchen = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id

    const { search } = req.query;
    const query = `SELECT
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
    v.variant_id,
    v.variant_value
    FROM products p 
    JOIN product_variants v ON p.product_id = v.product_id
    WHERE p.status = 'active' AND v.status = 'active'
    AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )
    ORDER BY p.product_id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const getProductSearchassignkitchen = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id

    const { search } = req.query;
    const query = `SELECT
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed
    FROM products p 
    WHERE p.status = 'active'
    AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )
    ORDER BY p.product_id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const getIngredientsforProducts = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;

    const { allProducts } = req.body;
    // return

    if (!allProducts || !Array.isArray(allProducts) || allProducts.length === 0) {
        return res.status(400).json({ message: "No products provided" });
    }

    try {

        // ===============================
        // 1️⃣ Get Recipe Data
        // ===============================

        const productIds = allProducts.map(p => p.id);

        const recipeQuery = `
            SELECT 
                r.variant_id,
                r.raw_id,
                r.quantity AS recipe_quantity,
                rm.name AS raw_material_name,
                r.measurement_unit,
                m.measurement_value
            FROM recipe r
            JOIN raw_material rm ON rm.id = r.raw_id
            JOIN measurements m ON m.measurement_id = r.measurement_unit
            WHERE r.variant_id = ANY($1)
            AND r.status = 'active'
        `;

        const { rows } = await pool.query(recipeQuery, [productIds]);
        console.log(rows)
        const ingredientMap = {};

        rows.forEach(recipeRow => {

            const product = allProducts.find(p => p.id === recipeRow.variant_id);
            if (!product) return;

            const totalQuantity =
                Number(recipeRow.recipe_quantity) * Number(product.quantity);

            if (ingredientMap[recipeRow.raw_id]) {
                ingredientMap[recipeRow.raw_id].quantity += totalQuantity;
            } else {
                ingredientMap[recipeRow.raw_id] = {
                    raw_id: recipeRow.raw_id,
                    name: recipeRow.raw_material_name,
                    measurement_unit: recipeRow.measurement_value,
                    quantity: totalQuantity,
                    unit: recipeRow.measurement_unit
                };
            }

        });

        const allIngredients = Object.values(ingredientMap);

        if (allIngredients.length === 0) {
            return res.status(400).json({ message: "No ingredients found" });
        }

        // ===============================
        // 2️⃣ Get Latest Stock
        // ===============================

        const rawIds = allIngredients.map(i => i.raw_id);

        const stockQuery = `
            SELECT DISTINCT ON (material_id)
                material_id,
                current_stock
            FROM material_inventory
            WHERE material_id = ANY($1)
            AND outlet_id = $2
            ORDER BY material_id, id DESC
        `;

        const { rows: stockRows } = await pool.query(stockQuery, [rawIds, outlet_id]);

        const stockMap = {};
        stockRows.forEach(row => {
            stockMap[row.material_id] = Number(row.current_stock);
        });

        const shortageArray = [];

        // ===============================
        // 3️⃣ Attach Stock + Validate
        // ===============================

        allIngredients.forEach(ingredient => {

            const currentStock = stockMap[ingredient.raw_id] || 0;
            const requiredQty = Number(ingredient.quantity);

            const shortageQty =
                requiredQty > currentStock
                    ? requiredQty - currentStock
                    : 0;

            // Attach directly into original array
            ingredient.current_stock = currentStock;
            ingredient.shortage_quantity = shortageQty;

            if (shortageQty > 0) {
                shortageArray.push({
                    raw_id: ingredient.raw_id,
                    name: ingredient.name,
                    required_quantity: requiredQty,
                    current_stock: currentStock,
                    shortage_quantity: shortageQty,
                    measurement_unit: ingredient.measurement_unit,
                    unit: ingredient.unit
                });
            }

        });

        return res.status(200).json({
            message: "Ingredients calculated successfully",
            ingredients: allIngredients,
            insufficient_stock: shortageArray
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const relaseProducts = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id;
    // const outlet_id = user.outlet_id;

    const { products, kitchen_id, shoppingList, ingredients } = req.body;

    const client = await pool.connect();

    try {

        if (!products || !Array.isArray(products) || products.length === 0 ||
            !kitchen_id ||
            !ingredients || ingredients.length === 0) {

            return res.status(400).json({ message: "Invalid data provided" });
        }

        const kitchenOutletResult = await pool.query("SELECT outlet_id FROM kitchen WHERE id = $1", [kitchen_id])

        if (kitchenOutletResult.rows.length === 0) {
            return res.status(404).json({ message: "Kitchen not found" });
        }

        const outlet_id = kitchenOutletResult.rows[0].outlet_id;


        await client.query('BEGIN');

        // =====================================================
        // 1️⃣ INSERT PRODUCTION HEADER
        // =====================================================

        const headerResult = await client.query(
            `INSERT INTO production_header 
             (kitchen_id, created_at, by, status) 
             VALUES ($1, $2, $3, $4) 
             RETURNING id`,
            [kitchen_id, new Date(), user_id, 'pending']
        );

        const production_header_id = headerResult.rows[0].id;

        // =====================================================
        // 2️⃣ INSERT PRODUCT DETAILS (WITH raw_id)
        // =====================================================

        const productIds = products.map(p => p.id);

        const recipeQuery = `
            SELECT 
                r.variant_id,
                r.raw_id,
                r.quantity AS recipe_quantity,
                r.measurement_unit
            FROM recipe r
            WHERE r.variant_id = ANY($1)
            AND r.status = 'active'
        `;

        const { rows } = await client.query(recipeQuery, [productIds]);

        if (rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: "No recipes found" });
        }

        const productValues = [];
        const productParams = [];

        rows.forEach((recipeRow, i) => {

            const product = products.find(p => p.id === recipeRow.variant_id);
            if (!product) return;

            const totalQuantity =
                Number(recipeRow.recipe_quantity) * Number(product.quantity);

            const baseIndex = i * 5;

            productValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5})`
            );

            productParams.push(
                production_header_id,
                recipeRow.variant_id,
                totalQuantity,
                recipeRow.measurement_unit,
                recipeRow.raw_id
            );
        });

        await client.query(
            `INSERT INTO production_details_product
             (production_id, product_id, quantity, unit, raw_id)
             VALUES ${productValues.join(', ')}`,
            productParams
        );

        // =====================================================
        // 3️⃣ INSERT INGREDIENT DETAILS
        // =====================================================

        const ingredientValues = [];
        const ingredientParams = [];

        ingredients.forEach((item, i) => {

            const baseIndex = i * 4;

            ingredientValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4})`
            );

            ingredientParams.push(
                production_header_id,
                item.raw_id,
                item.quantity,
                item.unit
            );
        });

        const ingredientResult = await client.query(
            `INSERT INTO production_details
             (production_id, ingredient_id, quantity, unit)
             VALUES ${ingredientValues.join(', ')}`,
            ingredientParams
        );

        if (ingredientResult.rowCount === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: "No ingredients found" });
        }

        // =====================================================
        // 4️⃣ INSERT SHOPPING LIST (ONLY IF EXISTS)
        // =====================================================

        if (shoppingList && shoppingList.length > 0) {

            const shopValues = [];
            const shopParams = [];

            shoppingList.forEach((item, i) => {

                const baseIndex = i * 4;

                shopValues.push(
                    `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4})`
                );

                shopParams.push(
                    production_header_id,
                    item.raw_id,
                    item.shortage_quantity,
                    item.unit
                );
            });

            const shopResult = await client.query(
                `INSERT INTO shopping_list
                 (production_id, ingredient_id, quantity, unit)
                 VALUES ${shopValues.join(', ')}`,
                shopParams
            );

            if (shopResult.rowCount === 0) {
                await client.query('ROLLBACK');
                return res.status(400).json({ message: "No shopping list found" });
            }
        }

        // =====================================================
        // 5️⃣ DEDUCT STOCK FROM MATERIAL INVENTORY
        // =====================================================

        for (const item of ingredients) {

            // Get latest stock row
            const stockResult = await client.query(
                `SELECT current_stock
         FROM material_inventory
         WHERE material_id = $1
         AND outlet_id = $2
         ORDER BY id DESC
         LIMIT 1`,
                [item.raw_id, outlet_id]
            );

            const previousStock = stockResult.rowCount > 0
                ? Number(stockResult.rows[0].current_stock)
                : 0;

            const requiredQty = Number(item.quantity);
            const newStock = previousStock - requiredQty;

            // Insert stock-out row
            const outletstiockResult = await client.query(
                `INSERT INTO material_inventory
            (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type)
            VALUES ($1, $2, $3, $4, $5, NOW(), $6, $7, $8, $9)`,
                [
                    item.raw_id,
                    previousStock,
                    -requiredQty,              // minus because stock out
                    newStock,
                    user_id,
                    'KITCHEN_RELEASE',
                    outlet_id,
                    'Stock Out via Kitchen Production',
                    'out'
                ]
            );

            if (outletstiockResult.rowCount === 0) {
                await client.query('ROLLBACK');
                return res.status(400).json({ message: "Stock update failed" });
            }


            // Get latest kitchen stock row
            const kitchenstockResult = await client.query(
                `SELECT current_stock
                    FROM kitchen_inventory
                    WHERE material_id = $1
                    AND kitchen_id = $2
                    ORDER BY id DESC
                    LIMIT 1`,
                [item.raw_id, kitchen_id]
            );

            const previouskitchenStock = kitchenstockResult.rowCount > 0
                ? Number(kitchenstockResult.rows[0].current_stock)
                : 0;

            const addQty = Number(item.quantity);
            const newkitchenStock = previouskitchenStock + addQty;

            // insert kitchen stock in
            const kotechstockResult = await client.query(
                `INSERT INTO kitchen_inventory
            (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type, kitchen_id)
            VALUES ($1, $2, $3, $4, $5, NOW(), $6, $7, $8, $9, $10)`,
                [
                    item.raw_id,
                    previouskitchenStock,
                    addQty,              // minus because stock out
                    newkitchenStock,
                    user_id,
                    'KITCHEN_RELEASE',
                    outlet_id,
                    'Stock Out via Kitchen Production',
                    'in',
                    kitchen_id
                ]
            );

            if (kotechstockResult.rowCount === 0) {
                await client.query('ROLLBACK');
                return res.status(400).json({ message: "Kitchen stock update failed" });
            }

        }

        await client.query('COMMIT');

        return res.status(200).json({
            message: "Production released successfully"
        });

    } catch (error) {

        await client.query('ROLLBACK');
        console.error(error);

        return res.status(500).json({
            message: "Internal server error"
        });

    } finally {
        client.release();
    }
};

const allProductionSheet = async (req, res) => {
    const user = req.user;

    const { page, date, todate, kitchen_id } = req.body;
    const parsedLimit = 25
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    try {

        const queryParams = [];
        let whereConditions = [];

        whereConditions.push(`WHERE TRUE`)

        if (date && todate) {
            whereConditions.push(`ph.created_at::date BETWEEN $${queryParams.length + 1} AND $${queryParams.length + 2}`)
            queryParams.push(date, todate)
        }

        if (kitchen_id) {
            whereConditions.push(`ph.kitchen_id = $${queryParams.length + 1}`)
            queryParams.push(kitchen_id)
        }

        const whereClause = `${whereConditions.join(" AND ")}`;

        let query = `
                    SELECT 
                        ph.id,
                        ph.kitchen_id,
                        ph.created_at,
                        k.name,
                        u.first_name,
                        ph.by,
                        ph.status,

                        COALESCE(ingredients.ingredients, '[]') AS ingredients,
                        COALESCE(shopping.shopping_list, '[]') AS shopping_list

                    FROM production_header ph

                    LEFT JOIN kitchen k 
                        ON k.id = ph.kitchen_id

                    LEFT JOIN users u 
                        ON u.user_id = ph.by


                    /* ---------- INGREDIENTS ---------- */

                    LEFT JOIN LATERAL (
                        SELECT json_agg(
                            json_build_object(
                                'id', p.id,
                                'ingredient_id', p.ingredient_id,
                                'ingredient_name', rm.name,
                                'measurement_unit', p.unit,
                                'measurement_value', m.measurement_value,
                                'quantity', p.quantity
                            )
                        ) AS ingredients
                        FROM production_details p
                        LEFT JOIN raw_material rm 
                            ON rm.id = p.ingredient_id
                        LEFT JOIN measurements m 
                            ON m.measurement_id = p.unit
                        WHERE p.production_id = ph.id
                    ) ingredients ON TRUE


                    /* ---------- SHOPPING LIST ---------- */

                    LEFT JOIN LATERAL (
                        SELECT json_agg(
                            json_build_object(
                                'id', s.id,
                                'ingredient_id', s.ingredient_id,
                                'ingredient_name', rm.name,
                                'measurement_unit', s.unit,
                                'measurement_value', m.measurement_value,
                                'quantity', s.quantity
                            )
                        ) AS shopping_list
                        FROM shopping_list s
                        LEFT JOIN raw_material rm 
                            ON rm.id = s.ingredient_id
                        LEFT JOIN measurements m 
                            ON m.measurement_id = s.unit
                        WHERE s.production_id = ph.id
                    ) shopping ON TRUE

                    ${whereClause}

                    ORDER BY ph.id DESC
                    LIMIT $${queryParams.length + 1}
                    OFFSET $${queryParams.length + 2};
                    `;

        const countQuery = `
            SELECT COUNT(DISTINCT (ph.id)) AS total
            FROM production_header ph
            ${whereClause};
            `;

        const [result, countResult] = await Promise.all([
            pool.query(query, [...queryParams, parsedLimit, offset]),
            pool.query(countQuery, queryParams)
        ])

        const total = parseInt(countResult.rows[0].total, 10);
        console.log(total)

        return res.status(200).json({ message: "success", result: result.rows, total: total, totalPages: Math.ceil(total / parsedLimit) });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


const assignProductsToKitchen = async (req, res) => {

    const { kitchen_id, product_ids } = req.body;

    if (!kitchen_id || !product_ids || product_ids.length === 0) {
        return res.status(400).json({ message: "Invalid data" });
    }

    const client = await pool.connect();

    try {
        await client.query("BEGIN");

        for (const product_id of product_ids) {

            const existing = await client.query(
                `SELECT kitchen_id FROM kitchen_products 
                 WHERE product_id = $1 AND status = 'Active'`,
                [product_id]
            );

            if (existing.rowCount === 0) {

                // ✅ Insert new
                await client.query(
                    `INSERT INTO kitchen_products (kitchen_id, product_id, status)
                     VALUES ($1,$2,'Active')`,
                    [kitchen_id, product_id]
                );

            } else {

                const currentKitchen = existing.rows.map(row => row.kitchen_id);
                console.log("type", typeof (currentKitchen), typeof (kitchen_id))
                console.log("value", currentKitchen, (kitchen_id))
                if (!currentKitchen.includes(Number(kitchen_id))) {
                    // ✅ Insert new
                    await client.query(
                        `INSERT INTO kitchen_products (kitchen_id, product_id, status)
                     VALUES ($1,$2,'Active')`,
                        [kitchen_id, product_id]
                    );

                }
            }
        }

        await client.query("COMMIT");

        return res.status(200).json({ message: "Products assigned successfully" });

    } catch (error) {
        await client.query("ROLLBACK");
        console.error(error);
        return res.status(500).json({ message: error.message });
    } finally {
        client.release();
    }
};

const getKitchenProducts = async (req, res) => {

    const { kitchen_id } = req.params;

    try {

        const query = `
      SELECT 
        kp.product_id,
        p.title,
        kp.status
      FROM kitchen_products kp
      JOIN products p
        ON p.product_id = kp.product_id
      WHERE kp.kitchen_id = $1 AND kp.status = 'Active'
      ORDER BY p.title
    `;

        const result = await pool.query(query, [kitchen_id]);

        res.status(200).json({
            result: result.rows
        });

    } catch (error) {

        console.error(error);
        res.status(500).json({ message: error.message });

    }

}

const removeKitchenProduct = async (req, res) => {

    const { kitchen_id, product_id } = req.body;

    if (!kitchen_id || !product_id) {
        return res.status(400).json({ message: "Invalid data" });
    }

    try {

        const result = await pool.query(
            `UPDATE kitchen_products SET status = 'Inactive'
       WHERE kitchen_id = $1
       AND product_id = $2`,
            [kitchen_id, product_id]
        );
        // const result = await pool.query(
        //   `DELETE FROM kitchen_products
        //    WHERE kitchen_id = $1
        //    AND product_id = $2`,
        //   [kitchen_id, product_id]
        // );

        if (result.rowCount === 0) {
            return res.status(404).json({ message: "Product not found" });
        }

        res.status(200).json({
            message: "Product removed"
        });

    } catch (error) {

        console.error(error);
        res.status(500).json({ message: error.message });

    }

}

const getCookisdisplayid = (req, res) => {
    const { kot_display_id } = req.cookies
    console.log(kot_display_id)

    try {
        if (!kot_display_id) {
            return res.status(400).json({ message: "kot_display_id is missing" });
        }

        return res.status(200).json({
            message: "kot_display_id cookie saved successfully",
            kot_display_id: kot_display_id
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Server error" });
    }
}

const getKotDisplay = async (req, res) => {

    try {
        const query = `SELECT device_id, till_name FROM device_management WHERE type = 'kot_display' AND status = 'Active'`

        const { rows } = await pool.query(query)

        if (rows.length === 0) {
            return res.status(400).json({ message: "KOT Display not found" });
        }

        return res.status(200).json({ message: "KOT Display found", result: rows });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Server error" });
    }
}

const saveCookistillid = (req, res) => {
    const { display_id } = req.body;

    try {
        if (!display_id) {
            return res.status(400).json({ message: "display is required" });
        }

        res.cookie("kot_display_id", display_id, {
            httpOnly: false,
            secure: true,
            sameSite: "None",
            maxAge: 1000 * 60 * 60 * 24 * 365 * 2, // 2 years
            path: "/",
        });

        return res.status(200).json({
            success: true,
            message: "display_id cookie saved successfully",
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Server error" });
    }
}

const unaasignProducts = async (req, res) => {
    const { page = 1, limit = 25 } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    try {
        const countQuery = `
            SELECT COUNT(*) AS total
            FROM products p
            WHERE p.status = 'active'
            AND NOT EXISTS (
                SELECT 1
                FROM kitchen_products kp
                WHERE kp.product_id = p.product_id
                AND kp.status = 'Active'
            );
        `;

        const dataQuery = `
            SELECT p.product_id, p.title
            FROM products p
            WHERE p.status = 'active'
            AND NOT EXISTS (
                SELECT 1
                FROM kitchen_products kp
                WHERE kp.product_id = p.product_id
                AND kp.status = 'Active'
            )
           ORDER BY p.product_id DESC LIMIT $1 OFFSET $2 ;
        `;

        const [countResult, dataResult] = await Promise.all([
            pool.query(countQuery),
            pool.query(dataQuery, [parsedLimit, offset])
        ]);

        const totalRecords = parseInt(countResult.rows[0].total, 10);
        const totalPages = Math.ceil(totalRecords / parsedLimit);

        return res.status(200).json({
            message: "success",
            result: dataResult.rows,
            pagination: {
                currentPage: parsedPage,
                limit: parsedLimit,
                totalRecords,
                totalPages
            }
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Server error" });
    }
};


const ingredientsInventory = async (req, res) => {
    try {
        const {
            page = 1,
            limit = 25,
            keyword
        } = req.body;

        const parsedLimit = parseInt(limit, 10);
        const parsedPage = parseInt(page, 10);
        const offset = (parsedPage - 1) * parsedLimit;

        let queryParams = [];
        let whereConditions = [];

        if (keyword) {
            const trimmedKeyword = keyword.trim();

            queryParams.push(`%${trimmedKeyword}%`);

            whereConditions.push(`
                (
                    r.name ILIKE $${queryParams.length}
                    OR r.id::text ILIKE $${queryParams.length}
                )
            `);
        }

        const whereClause = whereConditions.length
            ? `WHERE ${whereConditions.join(" AND ")}`
            : "";

        const rawMaterialQuery = `
            SELECT
                r.id,
                r.name,
                r.weight,
                r.reorder_level,
                r.measurement_unit,
                m.measurement_value,
                r.status,

                COALESCE(mi.current_stock, 0) AS in_outlet,

                COALESCE(ki.in_kitchen, 0) AS in_kitchen,

                COALESCE(mi.current_stock, 0) +
                COALESCE(ki.in_kitchen, 0) AS total

            FROM raw_material r

            LEFT JOIN measurements m
                ON r.measurement_unit = m.measurement_id

            -- latest material inventory row
            LEFT JOIN (
                SELECT DISTINCT ON (material_id)
                    material_id,
                    current_stock
                FROM material_inventory
                ORDER BY material_id, id DESC
            ) mi
                ON mi.material_id = r.id

            -- latest stock per kitchen, then sum
            LEFT JOIN (
                SELECT
                    material_id,
                    SUM(current_stock) AS in_kitchen
                FROM (
                    SELECT DISTINCT ON (material_id, kitchen_id)
                        material_id,
                        kitchen_id,
                        current_stock
                    FROM kitchen_inventory
                    ORDER BY material_id, kitchen_id, id DESC
                ) latest_kitchen_stock
                GROUP BY material_id
            ) ki
                ON ki.material_id = r.id

            ${whereClause}

            ORDER BY r.id DESC
            LIMIT $${queryParams.length + 1}
            OFFSET $${queryParams.length + 2}
        `;

        const countQuery = `
            SELECT COUNT(*) AS total
            FROM raw_material r
            ${whereClause}
        `;

        const paginatedParams = [
            ...queryParams,
            parsedLimit,
            offset
        ];

        const [rawMaterialResult, countResult] = await Promise.all([
            pool.query(rawMaterialQuery, paginatedParams),
            pool.query(countQuery, queryParams)
        ]);

        const total = parseInt(countResult.rows[0].total, 10);

        return res.json({
            raw_materials: rawMaterialResult.rows,
            total,
            totalPages: Math.ceil(total / parsedLimit),
            currentPage: parsedPage,
        });

    } catch (err) {
        console.error("Error fetching raw materials:", err);
        return res.status(500).json({
            error: "Internal server error"
        });
    }
};

const createSheet = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;
    const user_id = user.user_id;
    const merchant_id = user.merchant_id

    const { allProducts, kitchen_id, sheet } = req.body

    const client = await pool.connect();

    try {
        // console.log(allProducts, kitchen_id, sheet)

        const userQuery = `SELECT username FROM users WHERE user_id = $1`;

        const [userResult, kitchenOutletResult] = await Promise.all([
            pool.query(userQuery, [user_id]),
            pool.query("SELECT outlet_id FROM kitchen WHERE id = $1", [kitchen_id])
        ])

        if (userResult.rows.length === 0) return res.status(400).json({ message: "User not found" })

        const username = userResult.rows[0].username

        if (kitchenOutletResult.rowCount === 0) {
            return res.status(400).json({ message: "Kitchen not found" });
        }

        const kitchen_outlet = kitchenOutletResult.rows[0].outlet_id;

        await client.query("BEGIN");

        const insertSheetQuery = `
            INSERT INTO production_sheet_header (type, kitchen_id, created_at, by)
            VALUES ($1, $2, NOW(), $3)
            RETURNING id
        `;

        const sheetResult = await client.query(insertSheetQuery, [sheet, kitchen_id, user_id]);

        if (sheetResult.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to create production sheet" });
        }

        const sheetId = sheetResult.rows[0].id;

        const sheetValues = [];
        const sheetParams = [];

        allProducts.forEach((item, i) => {

            const baseIndex = i * 3;

            sheetValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3})`
            );

            sheetParams.push(
                sheetId,
                item.id,
                item.quantity
            );
        });

        const insertSheetDetailQuery = `
            INSERT INTO production_sheet_details (sheet_id, varient_id, quantity)
            VALUES ${sheetValues.join(', ')}
        `;

        const sheetDetails = await client.query(insertSheetDetailQuery, sheetParams);

        if (sheetDetails.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to insert production sheet details" });
        }

        if (sheet === 'production') {
            for (const product of allProducts) {

                const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' ORDER BY inventory_id DESC LIMIT 1`;

                const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

                const searchInventoryResult = await client.query(searchInventoryQuery, [
                    product.id,
                    kitchen_outlet,
                    merchant_id
                ]);

                let previous_quantity = 0;

                if (searchInventoryResult.rows.length > 0) {
                    previous_quantity = searchInventoryResult.rows[0].new_quantity;
                }

                const total_qty = Number(product.quantity);

                const new_quantity = Number(previous_quantity) + total_qty

                const insertInventoryResult = await client.query(insertInventoryQuery, [
                    product.id,
                    kitchen_outlet,
                    username,
                    `Stock in from Production Sheet: ${sheetId}`,
                    "stock in",
                    previous_quantity,
                    total_qty,
                    new_quantity,
                    "active",
                    merchant_id,
                    user_id,
                ]);

                if (insertInventoryResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert inventory" });
                }
            }

            // Create a map of variant_id -> ordered quantity for quick lookup
            const productOrderMap = new Map(
                allProducts.map(p => [Number(p.id), Number(p.quantity)])
            );

            const variantIds = Array.from(productOrderMap.keys());

            if (variantIds.length === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "No products found" });
            }

            // 2. Fetch all matching recipe rules for these variants
            const recipeResult = await client.query(
                `SELECT variant_id, raw_id, quantity AS recipe_qty 
             FROM recipe
             WHERE variant_id = ANY($1)`,
                [variantIds]
            );

            const requiredMaterials = {};
            for (const row of recipeResult.rows) {
                const variantQty = productOrderMap.get(row.variant_id) || 0;
                const totalNeeded = Number(row.recipe_qty) * variantQty;

                requiredMaterials[row.raw_id] = (requiredMaterials[row.raw_id] || 0) + totalNeeded;
            }
            console.log(requiredMaterials)
            const materialIds = Object.keys(requiredMaterials).map(Number);
            if (materialIds.length === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "No materials found" });
            }

            // 3. Fetch the LATEST stock for each required material_id for this kitchen
            // Uses DISTINCT ON to cleanly grab only the newest record per material
            const inventoryResult = await client.query(
                `SELECT DISTINCT ON (material_id) material_id, current_stock 
             FROM kitchen_inventory
             WHERE kitchen_id = $1 AND material_id = ANY($2)
             ORDER BY material_id, date DESC, id DESC`,
                [kitchen_id, materialIds]
            );

            // Map current stock balances (default to 0 if no inventory record exists yet)
            const currentStockMap = new Map();
            inventoryResult.rows.forEach(row => {
                currentStockMap.set(row.material_id, Number(row.current_stock));
            });

            // 4. Prepare and execute the inserts for new stock adjustments
            const insertQuery = `
            INSERT INTO kitchen_inventory
            (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type, kitchen_id)
            VALUES ($1, $2, $3, $4, $5, NOW(), $6, $7, $8, $9, $10)
        `;

            for (const materialId of materialIds) {
                const prevStock = currentStockMap.get(materialId) || 0;
                const adjustStock = requiredMaterials[materialId];
                const newStock = prevStock - adjustStock; // Deducting stock

                console.log(prevStock, adjustStock, newStock, "stock")

                const values = [
                    materialId,                           // material_id
                    prevStock,                            // prev_stock
                    adjustStock,                          // adjust_stock
                    newStock,                             // current_stock
                    user_id,                                   // by (User ID)
                    'Production Sheet',                    // module
                    kitchen_outlet,                                    // outlet_id
                    `Stock deducted from production sheet ${sheetId}`,   // note
                    'out',                                // type (changing to 'out' since it's a deduction)
                    kitchen_id                             // kitchen_id
                ];

                const kitchenInventoryResult = await client.query(insertQuery, values);

                if (kitchenInventoryResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert kitchen inventory" });
                }
            }


        } else {

            for (const product of allProducts) {

                const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' ORDER BY inventory_id DESC LIMIT 1`;

                const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

                const searchInventoryResult = await client.query(searchInventoryQuery, [
                    product.id,
                    kitchen_outlet,
                    merchant_id
                ]);

                let previous_quantity = 0;

                if (searchInventoryResult.rows.length > 0) {
                    previous_quantity = searchInventoryResult.rows[0].new_quantity;
                }

                const total_qty = Number(product.quantity);

                const new_quantity = Number(previous_quantity) - total_qty

                const insertInventoryResult = await client.query(insertInventoryQuery, [
                    product.id,
                    kitchen_outlet,
                    username,
                    `Stock in Production Sheet: ${sheetId}`,
                    "stock out",
                    previous_quantity,
                    -total_qty,
                    new_quantity,
                    "active",
                    merchant_id,
                    user_id,
                ]);

                if (insertInventoryResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert inventory" });
                }
            }

        }

        await client.query("COMMIT");
        return res.status(200).json({ message: "Stock updated successfully" });
    } catch (err) {
        await client.query("ROLLBACK");
        console.error("Error fetching raw materials:", err);
        return res.status(500).json({ error: "Internal server error" });
    } finally {
        client.release();
    }
}

const createSheetIngreients = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;
    const user_id = user.user_id;
    const merchant_id = user.merchant_id

    const { allIngredents, kitchen_id, sheet } = req.body

    const client = await pool.connect();

    try {
        console.log(allIngredents, kitchen_id, sheet)
        // return

        const userQuery = `SELECT username FROM users WHERE user_id = $1`;

        const kitchenOutletResult = await pool.query("SELECT outlet_id FROM kitchen WHERE id = $1", [kitchen_id])

        if (kitchenOutletResult.rowCount === 0) {
            return res.status(400).json({ message: "Kitchen not found" });
        }

        const kitchen_outlet = kitchenOutletResult.rows[0].outlet_id;

        await client.query("BEGIN");

        const insertSheetQuery = `
            INSERT INTO ingredient_sheet_header (type, kitchen_id, created_at, by)
            VALUES ($1, $2, NOW(), $3)
            RETURNING id
        `;

        const sheetResult = await client.query(insertSheetQuery, [sheet, kitchen_id, user_id]);

        if (sheetResult.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to create production sheet" });
        }

        const sheetId = sheetResult.rows[0].id;

        const sheetValues = [];
        const sheetParams = [];

        allIngredents.forEach((item, i) => {

            const baseIndex = i * 3;

            sheetValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3})`
            );

            sheetParams.push(
                sheetId,
                item.id,
                item.quantity
            );
        });

        const insertSheetDetailQuery = `
            INSERT INTO ingredient_sheet_details (sheet_id, ingredient, quantity)
            VALUES ${sheetValues.join(', ')}
        `;

        const sheetDetails = await client.query(insertSheetDetailQuery, sheetParams);

        if (sheetDetails.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to insert production sheet details" });
        }

        if (sheet === 'ingredient') {

            for (const item of allIngredents) {

                const qty = Number(item.quantity);

                // Get latest kitchen stock
                const kitchenStockResult = await client.query(
                    `SELECT current_stock
                    FROM kitchen_inventory
                    WHERE material_id = $1
                    AND kitchen_id = $2
                    ORDER BY id DESC
                    LIMIT 1`,
                    [item.id, kitchen_id]
                );

                const prevStock =
                    kitchenStockResult.rows.length > 0
                        ? Number(kitchenStockResult.rows[0].current_stock)
                        : 0;

                const currentStock = prevStock - qty;

               const insertResult = await client.query(
                    `INSERT INTO kitchen_inventory
                    (
                        material_id,
                        prev_stock,
                        adjust_stock,
                        current_stock,
                        by,
                        date,
                        module,
                        outlet_id,
                        note,
                        type,
                        kitchen_id
                    )
                    VALUES
                    ($1,$2,$3,$4,$5,NOW(),$6,$7,$8,$9,$10)`,
                    [
                        item.id,
                        prevStock,
                        qty,
                        currentStock,
                        user_id,
                        'Production Sheet',
                        outlet_id,
                        `Stock deducted from ingredient sheet ${sheetId}`,
                        'out',
                        kitchen_id
                    ]
                );

                if (insertResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert kitchen inventory" });
                }
            }

        } else {

            for (const item of allIngredents) {

                const qty = Number(item.quantity);

                // ---------------- Kitchen Inventory ----------------

                const kitchenStockResult = await client.query(
                    `SELECT current_stock
                    FROM kitchen_inventory
                    WHERE material_id = $1
                    AND kitchen_id = $2
                    ORDER BY id DESC
                    LIMIT 1`,
                    [item.id, kitchen_id]
                );

                const kitchenPrevStock =
                    kitchenStockResult.rows.length > 0
                        ? Number(kitchenStockResult.rows[0].current_stock)
                        : 0;

                const kitchenCurrentStock = kitchenPrevStock - qty;

               const insertResult = await client.query(
                    `INSERT INTO kitchen_inventory
                    (
                        material_id,
                        prev_stock,
                        adjust_stock,
                        current_stock,
                        by,
                        date,
                        module,
                        outlet_id,
                        note,
                        type,
                        kitchen_id
                    )
                    VALUES
                    ($1,$2,$3,$4,$5,NOW(),$6,$7,$8,$9,$10)`,
                    [
                        item.id,
                        kitchenPrevStock,
                        qty,
                        kitchenCurrentStock,
                        user_id,
                        'Production Sheet',
                        outlet_id,
                        `Stock deducted from production sheet ${sheetId}`,
                        'out',
                        kitchen_id
                    ]
                );

                if (insertResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert kitchen inventory" });
                }

                // ---------------- Outlet(Material) Inventory ----------------

                const materialStockResult = await client.query(
                    `SELECT current_stock
                    FROM material_inventory
                    WHERE material_id = $1
                    AND outlet_id = $2
                    ORDER BY id DESC
                    LIMIT 1`,
                    [item.id, kitchen_outlet]
                );

                const materialPrevStock =
                    materialStockResult.rowCount > 0
                        ? Number(materialStockResult.rows[0].current_stock)
                        : 0;

                const materialCurrentStock = materialPrevStock + qty;

                const insertMaterialResult = await client.query(
                    `INSERT INTO material_inventory
                    (
                        material_id,
                        prev_stock,
                        adjust_stock,
                        current_stock,
                        by,
                        date,
                        module,
                        outlet_id,
                        note,
                        type
                    )
                    VALUES
                    ($1,$2,$3,$4,$5,NOW(),$6,$7,$8,$9)`,
                    [
                        item.id,
                        materialPrevStock,
                        qty,
                        materialCurrentStock,
                        user_id,
                        'Production Sheet',
                        kitchen_outlet,
                        `Stock returned from production sheet ${sheetId} from kitchen ${kitchen_id}`,
                        'in'
                    ]
                );

                if (insertMaterialResult.rowCount === 0) {
                    await client.query("ROLLBACK");
                    return res.status(400).json({ message: "Failed to insert material inventory" });
                }
            }
        }

        await client.query("COMMIT");
        return res.status(200).json({ message: "Stock updated successfully" });
    } catch (err) {
        await client.query("ROLLBACK");
        console.error("Error fetching raw materials:", err);
        return res.status(500).json({ error: "Internal server error" });
    } finally {
        client.release();
    }
}

module.exports = {
    getProductSearch,
    getRawMaterialSearch,
    saveRecipe,
    allRecipe,
    add_raw_material_stock,
    getAllkitchen,
    getProductSearchkitchen,
    getIngredientsforProducts,
    relaseProducts,
    allProductionSheet,
    assignProductsToKitchen,
    getKitchenProducts,
    removeKitchenProduct,
    getCookisdisplayid,
    getKotDisplay,
    saveCookistillid,
    unaasignProducts,
    ingredientsInventory,
    createSheet,
    createSheetIngreients,
    getProductSearchassignkitchen
};