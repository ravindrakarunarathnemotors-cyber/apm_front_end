const pool = require("../config/db");
const { insertAdminLog } = require("../models/userLogs");

const getProductSearch = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id


    const { search } = req.query;
    const query = `SELECT
    v.variant_id,
    v.variant_value,
    v.price,
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
    pm.media_url AS main_img,
    pmd_first.media_url AS first_extra_img
    FROM products p
    JOIN product_variants v
    ON p.product_id = v.product_id
    LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
    LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
        AND main = true 
        AND variant_id IS NOT NULL
        ORDER BY created_at ASC
        LIMIT 1
    ) pmd_first ON true
    WHERE p.status = 'active'
    AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR v.variant_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )
    ORDER BY v.variant_id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};
const getRawMaterialSearch = async (req, res) => {
    const user = req.user;


    const { search } = req.query;
    const query = `SELECT
    r.id,
    r.name,
    r.reorder_level,
    r.measurement_unit,
    m.measurement_value,
    CASE WHEN r.measurement_unit = 1 THEN false ELSE true END AS measurement_needed
    FROM raw_material r
    LEFT JOIN measurements m ON r.measurement_unit = m.measurement_id
    WHERE r.status = 'Active'
    AND r.name ILIKE '%' || $1 || '%'
    ORDER BY r.id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const saveRecipe = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id
    const user_id = user.user_id

    const client = await pool.connect();
    try {

        const { selectProduct, allIngredents } = req.body

        if (!selectProduct || allIngredents.length === 0) {
            return res.status(400).json({ message: "Please select product and add ingredents" })
        }

        for (const item of allIngredents) {
            if (!item.quantity) {
                return res.status(400).json({
                    message: "Please add quantity for all ingredients"
                });
            }
        }

        await client.query("BEGIN");

        const query2 = `SELECT * FROM recipe WHERE product_id = $1`;
        const result2 = await client.query(query2, [selectProduct.product_id]);

        if (result2.rows.length > 0) {
            const query1 = `DELETE FROM recipe WHERE product_id = $1`;
            const result1 = await client.query(query1, [selectProduct.product_id]);

            if (result1.rowCount === 0) {
                await client.query("ROLLBACK");
                return res.status(400).json({ message: "Failed to delete recipe" })
            }

        }


        const params = [];
        const values = [];

        allIngredents.forEach((item, i) => {

            const baseIndex = 8 * i;

            values.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8})`
            );

            params.push(
                selectProduct.product_id,
                selectProduct.variant_id,
                item.id,
                item.quantity,
                item.measurement_unit,
                user_id,
                new Date(),
                'active'
            );
        });

        const query = `
            INSERT INTO recipe (product_id, variant_id, raw_id, quantity, measurement_unit, by, date, status)
            VALUES ${values.join(", ")}
            RETURNING id;
        `;

        const result = await client.query(query, params);

        if (result.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({ message: "Failed to save recipe" })
        }

        const module = "Recipe";
        const logMessage = `User ${user_id} created recipe for product ${selectProduct.product_id} with name '${selectProduct.name}'`;

        await insertAdminLog(user_id, module, logMessage),


            await client.query("COMMIT");
        return res.status(200).json({ message: "Recipe saved successfully" });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    } finally {
        client.release();
    }

}

const allRecipe = async (req, res) => {
    const user = req.user;

    const { page, date, todate, inputKeywords } = req.body;
    const parsedLimit = 25
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    try {

        const queryParams = [];
        let whereConditions = [];

        whereConditions.push(`r.status = 'active'`)

        if (date && todate) {
            whereConditions.push(`r.date::date BETWEEN $${queryParams.length + 1} AND $${queryParams.length + 2}`)
            queryParams.push(date, todate)
        }

        if (inputKeywords) {
            whereConditions.push(`(p.title ILIKE $${queryParams.length + 1} OR r.product_id::text ILIKE $${queryParams.length + 2})`)
            queryParams.push(`%${inputKeywords}%`, `%${inputKeywords}%`)
        }

        const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

        let query = `SELECT 
                            r.product_id,
                            r.variant_id,
                            r.date,
                            p.title AS name,
                            u.first_name,
                            r.by,
                            json_agg(
                                json_build_object(
                                    'raw_id', r.raw_id,
                                    'quantity', r.quantity,
                                    'measurement_unit', r.measurement_unit,
                                    'measurement_value', m.measurement_value,
                                    'material_name', rm.name
                                )
                            ) AS ingredients
                        FROM recipe r
                        LEFT JOIN products p ON p.product_id = r.product_id
                        LEFT JOIN raw_material rm ON rm.id = r.raw_id
                        LEFT JOIN measurements m ON m.measurement_id = r.measurement_unit
                        LEFT JOIN users u ON u.user_id = r.by
                        ${whereClause} 
                        GROUP BY r.product_id, r.variant_id, r.date, p.title, u.first_name, r.by
                        ORDER BY r.date DESC LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
                    `;

        const countQuery = `
            SELECT COUNT(DISTINCT (r.product_id, r.variant_id)) AS total
            FROM recipe r
            ${whereClause};
            `;

        const [result, countResult] = await Promise.all([
            pool.query(query, [...queryParams, parsedLimit, offset]),
            pool.query(countQuery, queryParams)
        ])

        const total = parseInt(countResult.rows[0].total, 10);
        console.log(total)

        return res.status(200).json({ message: "success", result: result.rows, total: total, totalPages: Math.ceil(total / parsedLimit) });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const add_raw_material_stock = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id
    const client = await pool.connect();

    try {
        const { outlet_id, stocktype, ingredients } = req.body;

        // 🔴 Basic Validation
        if (!outlet_id || !stocktype || !ingredients || ingredients.length === 0) {
            return res.status(400).json({
                message: "Missing required fields"
            });
        }

        if (!["in", "out"].includes(stocktype)) {
            return res.status(400).json({
                message: "Invalid stock type"
            });
        }

        for (const item of ingredients) {
            if (!item.quantity) {
                return res.status(400).json({
                    message: "Please add quantity for all ingredients"
                });
            }
        }

        const remark =
            stocktype === "in"
                ? "Stock In via Raw Material Module"
                : "Stock Out via Raw Material Module";

        await client.query("BEGIN");

        // 1️⃣ Insert Header
        const headerResult = await client.query(
            `INSERT INTO ingredients_stock_header
            (user_id, stock_type, remark, created_at, outlet_id)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id`,
            [user_id, stocktype, remark || null, new Date(), outlet_id]
        );

        if (headerResult.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({
                message: "Failed to Insert Ingredients Stock Header"
            });
        }

        const sheet_id = headerResult.rows[0].id;

        // 2️⃣ Process Each Ingredient
        for (const item of ingredients) {

            const { id, quantity } = item;

            if (!id || !quantity) {
                await client.query("ROLLBACK");
                return res.status(400).json({
                    message: "Invalid ingredient data"
                });
            }

            // 2.1️⃣ Get Previous Stock
            const prevStockResult = await client.query(
                `SELECT current_stock
                 FROM material_inventory
                 WHERE material_id = $1
                 AND outlet_id = $2
                 ORDER BY id DESC
                 LIMIT 1`,
                [id, outlet_id]
            );

            const prev_stock = prevStockResult.rows.length > 0
                ? Number(prevStockResult.rows[0].current_stock)
                : 0;

            // 2.2️⃣ Calculate New Stock
            let change_stock = Number(quantity);
            let current_stock;

            if (stocktype === "in") {
                current_stock = prev_stock + change_stock;
            } else {
                current_stock = prev_stock - change_stock;

                // if (current_stock < 0) {
                //     await client.query("ROLLBACK");
                //     return res.status(400).json({
                //         message: `Insufficient stock for material ID ${id}`
                //     });
                // }
            }

            // 2.3️⃣ Insert into ingredients_stock_details
            await client.query(
                `INSERT INTO ingredients_stock_details
                (sheet_id, ingredient_id, prev_stock, change_stock, current_stock, created_at)
                VALUES ($1, $2, $3, $4, $5, NOW())`,
                [sheet_id, id, prev_stock, change_stock, current_stock]
            );

            // 2.4️⃣ Insert into material_inventory (ledger entry)
            await client.query(
                `INSERT INTO material_inventory
                (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type)
                VALUES ($1, $2, $3, $4, $5, $9, $6, $7, $8, $10)`,
                [
                    id,
                    prev_stock,
                    stocktype === "in" ? change_stock : -change_stock,
                    current_stock,
                    user_id,
                    "RAW_MATERIAL_STOCK",
                    outlet_id,
                    remark || null,
                    new Date(),
                    stocktype
                ]
            );
        }

        const module = "RAW_MATERIAL_STOCK";
        const logMessage = `Admin ${user_id} updated raw material stock`;

        await insertAdminLog(user_id, module, logMessage),

            await client.query("COMMIT");

        return res.status(200).json({
            message: "Stock updated successfully"
        });

    } catch (error) {
        await client.query("ROLLBACK");
        console.error(error);

        return res.status(500).json({
            message: "Internal server error"
        });
    } finally {
        client.release();
    }
};

const getAllkitchen = async (req, res) => {
    const user = req.user;

    const query = `SELECT
    id as value,
    name as label,
    outlet_id
    FROM kitchen
    WHERE status = 'Active'
        `;

    try {
        const result = await pool.query(query);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const getProductSearchkitchen = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id

    const { search } = req.query;
    const query = `SELECT
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed
    FROM products p 
    WHERE p.status = 'active'
    AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )
    ORDER BY p.product_id
    LIMIT 10 OFFSET 0;
`;

    try {
        const result = await pool.query(query, [`%${search}%`]);
        return res.status(200).json({
            message: "success",
            result: result.rows,
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const getIngredientsforProducts = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;

    const { allProducts } = req.body;

    if (!allProducts || !Array.isArray(allProducts) || allProducts.length === 0) {
        return res.status(400).json({ message: "No products provided" });
    }

    try {

        // ===============================
        // 1️⃣ Get Recipe Data
        // ===============================

        const productIds = allProducts.map(p => p.id);

        const recipeQuery = `
            SELECT 
                r.product_id,
                r.raw_id,
                r.quantity AS recipe_quantity,
                rm.name AS raw_material_name,
                r.measurement_unit,
                m.measurement_value
            FROM recipe r
            JOIN raw_material rm ON rm.id = r.raw_id
            JOIN measurements m ON m.measurement_id = r.measurement_unit
            WHERE r.product_id = ANY($1)
            AND r.status = 'active'
        `;

        const { rows } = await pool.query(recipeQuery, [productIds]);

        const ingredientMap = {};

        rows.forEach(recipeRow => {

            const product = allProducts.find(p => p.id === recipeRow.product_id);
            if (!product) return;

            const totalQuantity =
                Number(recipeRow.recipe_quantity) * Number(product.quantity);

            if (ingredientMap[recipeRow.raw_id]) {
                ingredientMap[recipeRow.raw_id].quantity += totalQuantity;
            } else {
                ingredientMap[recipeRow.raw_id] = {
                    raw_id: recipeRow.raw_id,
                    name: recipeRow.raw_material_name,
                    measurement_unit: recipeRow.measurement_value,
                    quantity: totalQuantity,
                    unit: recipeRow.measurement_unit
                };
            }

        });

        const allIngredients = Object.values(ingredientMap);

        if (allIngredients.length === 0) {
            return res.status(400).json({ message: "No ingredients found" });
        }

        // ===============================
        // 2️⃣ Get Latest Stock
        // ===============================

        const rawIds = allIngredients.map(i => i.raw_id);

        const stockQuery = `
            SELECT DISTINCT ON (material_id)
                material_id,
                current_stock
            FROM material_inventory
            WHERE material_id = ANY($1)
            AND outlet_id = $2
            ORDER BY material_id, id DESC
        `;

        const { rows: stockRows } = await pool.query(stockQuery, [rawIds, outlet_id]);

        const stockMap = {};
        stockRows.forEach(row => {
            stockMap[row.material_id] = Number(row.current_stock);
        });

        const shortageArray = [];

        // ===============================
        // 3️⃣ Attach Stock + Validate
        // ===============================

        allIngredients.forEach(ingredient => {

            const currentStock = stockMap[ingredient.raw_id] || 0;
            const requiredQty = Number(ingredient.quantity);

            const shortageQty =
                requiredQty > currentStock
                    ? requiredQty - currentStock
                    : 0;

            // Attach directly into original array
            ingredient.current_stock = currentStock;
            ingredient.shortage_quantity = shortageQty;

            if (shortageQty > 0) {
                shortageArray.push({
                    raw_id: ingredient.raw_id,
                    name: ingredient.name,
                    required_quantity: requiredQty,
                    current_stock: currentStock,
                    shortage_quantity: shortageQty,
                    measurement_unit: ingredient.measurement_unit,
                    unit: ingredient.unit
                });
            }

        });

        return res.status(200).json({
            message: "Ingredients calculated successfully",
            ingredients: allIngredients,
            insufficient_stock: shortageArray
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};

const relaseProducts = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id;
    const outlet_id = user.outlet_id;

    const { products, kitchen_id, shoppingList, ingredients } = req.body;

    const client = await pool.connect();

    try {

        if (!products || !Array.isArray(products) || products.length === 0 ||
            !kitchen_id ||
            !ingredients || ingredients.length === 0) {

            return res.status(400).json({ message: "Invalid data provided" });
        }

        await client.query('BEGIN');

        // =====================================================
        // 1️⃣ INSERT PRODUCTION HEADER
        // =====================================================

        const headerResult = await client.query(
            `INSERT INTO production_header 
             (kitchen_id, created_at, by, status) 
             VALUES ($1, $2, $3, $4) 
             RETURNING id`,
            [kitchen_id, new Date(), user_id, 'pending']
        );

        const production_header_id = headerResult.rows[0].id;

        // =====================================================
        // 2️⃣ INSERT PRODUCT DETAILS (WITH raw_id)
        // =====================================================

        const productIds = products.map(p => p.id);

        const recipeQuery = `
            SELECT 
                r.product_id,
                r.raw_id,
                r.quantity AS recipe_quantity,
                r.measurement_unit
            FROM recipe r
            WHERE r.product_id = ANY($1)
            AND r.status = 'active'
        `;

        const { rows } = await client.query(recipeQuery, [productIds]);

        if (rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: "No recipes found" });
        }

        const productValues = [];
        const productParams = [];

        rows.forEach((recipeRow, i) => {

            const product = products.find(p => p.id === recipeRow.product_id);
            if (!product) return;

            const totalQuantity =
                Number(recipeRow.recipe_quantity) * Number(product.quantity);

            const baseIndex = i * 5;

            productValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5})`
            );

            productParams.push(
                production_header_id,
                recipeRow.product_id,
                totalQuantity,
                recipeRow.measurement_unit,
                recipeRow.raw_id
            );
        });

        await client.query(
            `INSERT INTO production_details_product
             (production_id, product_id, quantity, unit, raw_id)
             VALUES ${productValues.join(', ')}`,
            productParams
        );

        // =====================================================
        // 3️⃣ INSERT INGREDIENT DETAILS
        // =====================================================

        const ingredientValues = [];
        const ingredientParams = [];

        ingredients.forEach((item, i) => {

            const baseIndex = i * 4;

            ingredientValues.push(
                `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4})`
            );

            ingredientParams.push(
                production_header_id,
                item.raw_id,
                item.quantity,
                item.unit
            );
        });

        const ingredientResult = await client.query(
            `INSERT INTO production_details
             (production_id, ingredient_id, quantity, unit)
             VALUES ${ingredientValues.join(', ')}`,
            ingredientParams
        );

        if (ingredientResult.rowCount === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: "No ingredients found" });
        }

        // =====================================================
        // 4️⃣ INSERT SHOPPING LIST (ONLY IF EXISTS)
        // =====================================================

        if (shoppingList && shoppingList.length > 0) {

            const shopValues = [];
            const shopParams = [];

            shoppingList.forEach((item, i) => {

                const baseIndex = i * 4;

                shopValues.push(
                    `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4})`
                );

                shopParams.push(
                    production_header_id,
                    item.raw_id,
                    item.shortage_quantity,
                    item.unit
                );
            });

            const shopResult = await client.query(
                `INSERT INTO shopping_list
                 (production_id, ingredient_id, quantity, unit)
                 VALUES ${shopValues.join(', ')}`,
                shopParams
            );

            if (shopResult.rowCount === 0) {
                await client.query('ROLLBACK');
                return res.status(400).json({ message: "No shopping list found" });
            }
        }

        // =====================================================
        // 5️⃣ DEDUCT STOCK FROM MATERIAL INVENTORY
        // =====================================================

        for (const item of ingredients) {

            // Get latest stock row
            const stockResult = await client.query(
                `SELECT current_stock
         FROM material_inventory
         WHERE material_id = $1
         AND outlet_id = $2
         ORDER BY id DESC
         LIMIT 1`,
                [item.raw_id, outlet_id]
            );

            const previousStock = stockResult.rowCount > 0
                ? Number(stockResult.rows[0].current_stock)
                : 0;

            const requiredQty = Number(item.quantity);
            const newStock = previousStock - requiredQty;

            // Insert stock-out row
            await client.query(
                `INSERT INTO material_inventory
         (material_id, prev_stock, adjust_stock, current_stock, by, date, module, outlet_id, note, type)
         VALUES ($1, $2, $3, $4, $5, NOW(), $6, $7, $8, $9)`,
                [
                    item.raw_id,
                    previousStock,
                    -requiredQty,              // minus because stock out
                    newStock,
                    user_id,
                    'KITCHEN_RELEASE',
                    outlet_id,
                    'Stock Out via Kitchen Production',
                    'out'
                ]
            );
        }

        await client.query('COMMIT');

        return res.status(200).json({
            message: "Production released successfully"
        });

    } catch (error) {

        await client.query('ROLLBACK');
        console.error(error);

        return res.status(500).json({
            message: "Internal server error"
        });

    } finally {
        client.release();
    }
};

const allProductionSheet = async (req, res) => {
    const user = req.user;

    const { page, date, todate, kitchen_id } = req.body;
    const parsedLimit = 25
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    try {

        const queryParams = [];
        let whereConditions = [];

        whereConditions.push(`WHERE TRUE`)

        if (date && todate) {
            whereConditions.push(`ph.created_at::date BETWEEN $${queryParams.length + 1} AND $${queryParams.length + 2}`)
            queryParams.push(date, todate)
        }

        if (kitchen_id) {
            whereConditions.push(`ph.kitchen_id = $${queryParams.length + 1}`)
            queryParams.push(kitchen_id)
        }

        const whereClause = `${whereConditions.join(" AND ")}`;

        let query = `
                    SELECT 
                        ph.id,
                        ph.kitchen_id,
                        ph.created_at,
                        k.name,
                        u.first_name,
                        ph.by,
                        ph.status,

                        COALESCE(ingredients.ingredients, '[]') AS ingredients,
                        COALESCE(shopping.shopping_list, '[]') AS shopping_list

                    FROM production_header ph

                    LEFT JOIN kitchen k 
                        ON k.id = ph.kitchen_id

                    LEFT JOIN users u 
                        ON u.user_id = ph.by


                    /* ---------- INGREDIENTS ---------- */

                    LEFT JOIN LATERAL (
                        SELECT json_agg(
                            json_build_object(
                                'id', p.id,
                                'ingredient_id', p.ingredient_id,
                                'ingredient_name', rm.name,
                                'measurement_unit', p.unit,
                                'measurement_value', m.measurement_value,
                                'quantity', p.quantity
                            )
                        ) AS ingredients
                        FROM production_details p
                        LEFT JOIN raw_material rm 
                            ON rm.id = p.ingredient_id
                        LEFT JOIN measurements m 
                            ON m.measurement_id = p.unit
                        WHERE p.production_id = ph.id
                    ) ingredients ON TRUE


                    /* ---------- SHOPPING LIST ---------- */

                    LEFT JOIN LATERAL (
                        SELECT json_agg(
                            json_build_object(
                                'id', s.id,
                                'ingredient_id', s.ingredient_id,
                                'ingredient_name', rm.name,
                                'measurement_unit', s.unit,
                                'measurement_value', m.measurement_value,
                                'quantity', s.quantity
                            )
                        ) AS shopping_list
                        FROM shopping_list s
                        LEFT JOIN raw_material rm 
                            ON rm.id = s.ingredient_id
                        LEFT JOIN measurements m 
                            ON m.measurement_id = s.unit
                        WHERE s.production_id = ph.id
                    ) shopping ON TRUE

                    ${whereClause}

                    ORDER BY ph.id DESC
                    LIMIT $${queryParams.length + 1}
                    OFFSET $${queryParams.length + 2};
                    `;

        const countQuery = `
            SELECT COUNT(DISTINCT (ph.id)) AS total
            FROM production_header ph
            ${whereClause};
            `;

        const [result, countResult] = await Promise.all([
            pool.query(query, [...queryParams, parsedLimit, offset]),
            pool.query(countQuery, queryParams)
        ])

        const total = parseInt(countResult.rows[0].total, 10);
        console.log(total)

        return res.status(200).json({ message: "success", result: result.rows, total: total, totalPages: Math.ceil(total / parsedLimit) });
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


const assignProductsToKitchen = async (req, res) => {

    const { kitchen_id, product_ids } = req.body;

    if (!kitchen_id || !product_ids || product_ids.length === 0) {
        return res.status(400).json({ message: "Invalid data" });
    }

    const client = await pool.connect();

    try {
        await client.query("BEGIN");

        for (const product_id of product_ids) {

            const existing = await client.query(
                `SELECT kitchen_id FROM kitchen_products 
                 WHERE product_id = $1 AND status = 'Active'`,
                [product_id]
            );

            if (existing.rowCount === 0) {

                // ✅ Insert new
                await client.query(
                    `INSERT INTO kitchen_products (kitchen_id, product_id, status)
                     VALUES ($1,$2,'Active')`,
                    [kitchen_id, product_id]
                );

            } else {

                const currentKitchen = existing.rows[0].kitchen_id;

                if (currentKitchen !== kitchen_id) {

                    // 🔁 Move to new kitchen
                    await client.query(
                        `UPDATE kitchen_products 
                         SET kitchen_id = $1
                         WHERE product_id = $2 AND status = 'Active'`,
                        [kitchen_id, product_id]
                    );

                }
            }
        }

        await client.query("COMMIT");

        return res.status(200).json({ message: "Products assigned successfully" });

    } catch (error) {
        await client.query("ROLLBACK");
        console.error(error);
        return res.status(500).json({ message: error.message });
    } finally {
        client.release();
    }
};

const getKitchenProducts = async (req, res) => {

  const { kitchen_id } = req.params;

  try {

    const query = `
      SELECT 
        kp.product_id,
        p.title,
        kp.status
      FROM kitchen_products kp
      JOIN products p
        ON p.product_id = kp.product_id
      WHERE kp.kitchen_id = $1 AND kp.status = 'Active'
      ORDER BY p.title
    `;

    const result = await pool.query(query, [kitchen_id]);

    res.status(200).json({
      result: result.rows
    });

  } catch (error) {

    console.error(error);
    res.status(500).json({ message: error.message });

  }

}

const removeKitchenProduct = async (req, res) => {

  const { kitchen_id, product_id } = req.body;

  if (!kitchen_id || !product_id) {
    return res.status(400).json({ message: "Invalid data" });
  }

  try {

    const result = await pool.query(
      `UPDATE kitchen_products SET status = 'Inactive'
       WHERE kitchen_id = $1
       AND product_id = $2`,
      [kitchen_id, product_id]
    );
    // const result = await pool.query(
    //   `DELETE FROM kitchen_products
    //    WHERE kitchen_id = $1
    //    AND product_id = $2`,
    //   [kitchen_id, product_id]
    // );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    res.status(200).json({
      message: "Product removed"
    });

  } catch (error) {

    console.error(error);
    res.status(500).json({ message: error.message });

  }

}

const getCookisdisplayid = (req, res) => {
  const { kot_display_id } = req.cookies
  console.log(kot_display_id)

  try {
    if (!kot_display_id) {
      return res.status(400).json({ message: "kot_display_id is missing" });
    }

    return res.status(200).json({
      message: "kot_display_id cookie saved successfully",
      kot_display_id: kot_display_id
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
}

const getKotDisplay = async (req, res) => {
  
  try {
    const query = `SELECT device_id, till_name FROM device_management WHERE type = 'kot_display' AND status = 'Active'`

    const { rows } = await pool.query(query)

    if (rows.length === 0) {
      return res.status(400).json({ message: "KOT Display not found" });
    }

    return res.status(200).json({ message: "KOT Display found", result: rows });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
}

const saveCookistillid = (req, res) => {
  const { display_id } = req.body;

  try {
    if (!display_id) {
      return res.status(400).json({ message: "display is required" });
    }

    res.cookie("kot_display_id", display_id, {
      httpOnly: false,
      secure: true,
      sameSite: "None",
      maxAge: 1000 * 60 * 60 * 24 * 365 * 2, // 2 years
      path: "/",
    });

    return res.status(200).json({
      success: true,
      message: "display_id cookie saved successfully",
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
}

module.exports = {
    getProductSearch,
    getRawMaterialSearch,
    saveRecipe,
    allRecipe,
    add_raw_material_stock,
    getAllkitchen,
    getProductSearchkitchen,
    getIngredientsforProducts,
    relaseProducts,
    allProductionSheet,
    assignProductsToKitchen,
    getKitchenProducts,
    removeKitchenProduct,
    getCookisdisplayid, 
    getKotDisplay,
    saveCookistillid
};