const User = require("../models/userModels");
const createRateLimiter = require("../middleware/rateLimiter");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
require("dotenv").config();

const { insertAdminLog } = require("../models/userLogs");

const login = async (req, res) => {
  const { email, password } = req.body;

  // useful metadata
  const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;

  const userAgent = req.headers["user-agent"];

  try {
    const userDetails = await User.login(email, password);

    console.log("userDetails", userDetails);

    // FAILED LOGIN
    if (userDetails.error) {
      await insertAdminLog(
        null,
        "AUTH_LOGIN_FAILED",
        `Email: ${email} | Status: FAILED | Browser: ${userAgent} | Time: ${new Date().toISOString()}`,
      );

      return res.status(404).json({
        message: userDetails.error,
      });
    }

    // SUCCESS LOGIN
    await insertAdminLog(
      userDetails.user_id,
      "AUTH_LOGIN_SUCCESS",
      `Email: ${email} | Status: SUCCESS | Browser: ${userAgent} | Time: ${new Date().toISOString()}`,
    );

    // POST-LOGIN TRIGGER
    const portalData = await User.getPortalInterfacesByRole(
      userDetails.role_id,
    );

    userDetails.portal_interface_id = portalData.portal_interface_id;

    userDetails.portal_interfaces = portalData.portal_interfaces;

    // ✅ JWT payload
    const payload = {
      user_id: userDetails.user_id,
      role_id: userDetails.role_id,
      merchant_id: userDetails.merchant_id,
      outlet_id: userDetails.outlet_id,
    };

    // ACCESS TOKEN (short lived)
    const accessToken = jwt.sign(
      payload,
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "5m" }
    );

    // REFRESH TOKEN (long lived)
    const refreshToken = jwt.sign(
      payload,
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: "24h" }
    );

    // ✅ SET COOKIES (IMPORTANT PART)
    res.cookie("access_token", accessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "none",
      maxAge: 5 * 60 * 1000, // 5 minutes
    });

    res.cookie("refresh_token", refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "none",
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    });

    return res.status(200).json({
      message: "Login Successful",
      user: userDetails
    });
  } catch (error) {
    console.log(error);

    // SERVER ERROR LOGIN LOG
    await insertAdminLog(
      null,
      "AUTH_LOGIN_ERROR",
      `Email: ${email} | Status: ERROR | Browser: ${userAgent} | Time: ${new Date().toISOString()}`,
    );

    return res.status(500).json({
      message: "Internal server error",
    });
  }
};

const register = (req, res, next) => {
  const email = req.body.email;
  const password = req.body.password;

  bcrypt.hash(password, saltRounds, function (err, hash) {
    console.log(hash);
  });
};

module.exports = { login, register };
