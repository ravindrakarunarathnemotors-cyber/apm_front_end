const User = require('../models/userModels');
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
require("dotenv").config();

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const userDetails = await User.login(email, password);
    console.log('userDetails', userDetails);

    if (userDetails.error) {
      return res.status(404).json({ message: userDetails.error });
    }

    // 🔥 POST-LOGIN TRIGGER (ADDITIVE, NON-BREAKING)
    const portalData = await User.getPortalInterfacesByRole(
      userDetails.role_id
    );

    userDetails.portal_interface_id = portalData.portal_interface_id;
    userDetails.portal_interfaces = portalData.portal_interfaces;
    // 🔥 END TRIGGER

    const accessToken = jwt.sign(
      {
        user_id: userDetails.user_id,
        role_id: userDetails.role_id,
        merchant_id: userDetails.merchant_id,
        outlet_id: userDetails.outlet_id
      },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "8h" }
    );

    const refreshToken = jwt.sign(
      {
        user_id: userDetails.user_id,
        role_id: userDetails.role_id,
        merchant_id: userDetails.merchant_id,
        outlet_id: userDetails.outlet_id
      },
      process.env.REFRESH_TOKEN_SECRET,
      { expiresIn: "24h" }
    );

    return res.status(200).json({
      message: "Login Successful",
      user: userDetails,
      accessToken: accessToken,
      refreshToken: refreshToken
    });

  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const register = (req, res, next) => {
  const email = req.body.email;
  const password = req.body.password;

  bcrypt.hash(password, saltRounds, function (err, hash) {
    console.log(hash);
  });
};

module.exports = { login, register };
