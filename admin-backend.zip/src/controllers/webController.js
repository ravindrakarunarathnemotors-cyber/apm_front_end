const pool = require("../config/db");

// ========== WEB TEMPLATES ==========

const getTemplate = async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM web_templates WHERE status = 'active' ORDER BY id ASC"
    );
    res.status(200).json({ templates: rows });
  } catch (error) {
    console.error("Error fetching templates:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// ========== WEB PAGES ==========

// Get all pages
const getPages = async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM pages ORDER BY  created_at ASC"
    );
    res.json({ pages: rows });
    console.log(rows);
  } catch (error) {
    console.error("Error fetching pages:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Get a single page by id
const getPage = async (req, res) => {
  const { id } = req.params;
  try {
    const { rows } = await pool.query("SELECT * FROM pages WHERE id = $1", [
      id,
    ]);
    if (rows.length === 0)
      return res.status(404).json({ message: "Page not found" });
    res.json(rows[0]);
  } catch (error) {
    console.error("Error fetching page:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Create a new page
const createPage = async (req, res) => {
  const { title, slug, status = "active" } = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO pages (title, slug, status )
       VALUES ($1, $2, $3)
       RETURNING *`,
      [title, slug, status]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error("Error creating page:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Update a page
const updatePage = async (req, res) => {
  const { id } = req.params;
  const { title, slug, status } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE pages
       SET title = $1, slug = $2,  status = $3, updated_at = CURRENT_TIMESTAMP
       WHERE id = $4
       RETURNING *`,
      [title, slug, status, id]
    );
    if (rows.length === 0)
      return res.status(404).json({ message: "Page not found" });
    res.json(rows[0]);
  } catch (error) {
    console.error("Error updating page:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Delete a page
const deletePage = async (req, res) => {
  const { id } = req.params;
  try {
    const { rowCount } = await pool.query("DELETE FROM pages WHERE id = $1", [
      id,
    ]);
    if (rowCount === 0)
      return res.status(404).json({ message: "Page not found" });
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting page:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// ========== WEB TEMPLATE SECTIONS ==========

// Get all sections/components for a template
const getTemplateSections = async (req, res) => {
  const { templateId } = req.params;
  try {
    const { rows } = await pool.query(
      `SELECT * FROM web_template_sections 
       WHERE template_id = $1 AND status = 'active' 
       ORDER BY "order" ASC`,
      [templateId]
    );
    res.status(200).json({ sections: rows });
  } catch (error) {
    console.error("Error fetching template sections:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// ========== SELECTED TEMPLATE (Current Template) ==========

// Get the current selected template
const getSelectedTemplate = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT st.*, wt.*
       FROM selected_template st
       LEFT JOIN web_templates wt ON st.template_id = wt.id
       LIMIT 1`
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: "No selected template found" });
    }
    res.status(200).json(rows[0]);
  } catch (error) {
    console.error("Error fetching selected template:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Set (update) the current selected template
const setSelectedTemplate = async (req, res) => {
  const { template_id } = req.body;
  try {
    await pool.query("DELETE FROM selected_template"); // Only one allowed
    await pool.query(
      `INSERT INTO selected_template (template_id) VALUES ($1)`,
      [template_id]
    );
    res.json({ success: true });
  } catch (error) {
    console.error("Error setting selected template:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// ========== SELECTED SECTIONS (Homepage Layout) ==========

// Get selected homepage sections (in order)
const getSelectedSections = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM selected_sections ORDER BY section_order ASC`
    );
    res.status(200).json({ sections: rows });
  } catch (error) {
    console.error("Error fetching selected sections:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Set homepage section order (replace all)
const setSelectedSections = async (req, res) => {
  const { sections } = req.body; // Expects: [{ section_key, section_order }]
  try {
    await pool.query("DELETE FROM selected_sections");
    if (Array.isArray(sections)) {
      for (const s of sections) {
        await pool.query(
          `INSERT INTO selected_sections (section_key, section_order) VALUES ($1, $2)`,
          [s.section_key, s.section_order]
        );
      }
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Error saving selected sections:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Get all components
// const getComponents = async (req, res) => {
//   try {
//     const { rows } = await pool.query(
//       "SELECT * FROM components ORDER BY id ASC"
//     );
//     res.status(200).json(rows);
//   } catch (error) {
//     console.error("Error fetching components:", error);
//     res.status(500).json({ message: "Internal server error" });
//   }
// };
// Get all components
const getComponents = async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM web_template_sections ORDER BY id ASC"
    );
    res.status(200).json(rows);
  } catch (error) {
    console.error("Error fetching components:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Create a new component
const createComponent = async (req, res) => {
  const { name, description, json_schema, status = "active" } = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO components (name, description, json_schema, status)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [name, description, JSON.stringify(json_schema), status]
    );
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error("Error creating component:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Update a component
const updateComponent = async (req, res) => {
  const { id } = req.params;
  const { name, description, json_schema, status } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE components
       SET name = $1, description = $2, json_schema = $3, status = $4, updated_at = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING *`,
      [name, description, JSON.stringify(json_schema), status, id]
    );
    if (rows.length === 0)
      return res.status(404).json({ message: "Component not found" });
    res.json(rows[0]);
  } catch (error) {
    console.error("Error updating component:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Delete a component
const deleteComponent = async (req, res) => {
  const { id } = req.params;
  try {
    const { rowCount } = await pool.query(
      "DELETE FROM components WHERE id = $1",
      [id]
    );
    if (rowCount === 0)
      return res.status(404).json({ message: "Component not found" });
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting component:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// ========== WEB PAGE COMPONENTS ==========

// Get all components/sections for a page
// GET /web/page-components?page_id=1
const getPageComponents = async (req, res) => {

  try {
    const { rows } = await pool.query(
      `SELECT * FROM web_template_sections `,
    
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch components" });
  }
};


// Create a new page section/component
// POST /web/page-components
const createPageComponent = async (req, res) => {
  const { page_id, component_key, order, props_json, status = "active" } = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO web_page_components (page_id, component_key, order, props_json, status)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [page_id, component_key, order, JSON.stringify(props_json), status]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to add component" });
  }
};

// Update a page section/component
const updatePageComponent = async (req, res) => {
  const { id } = req.params;
  const { order, props_json, status } = req.body;

  // Build update dynamically
  const fields = [];
  const values = [];
  let idx = 1;

  if (order !== undefined) {
    fields.push(`"order" = $${idx++}`);
    values.push(order);
  }
  if (props_json !== undefined) {
    fields.push(`props_json = $${idx++}`);
    values.push(JSON.stringify(props_json));
  }
  if (status !== undefined) {
    fields.push(`status = $${idx++}`);
    values.push(status);
  }

  if (!fields.length)
    return res.status(400).json({ message: "Nothing to update" });
  values.push(id);

  try {
    const { rows } = await pool.query(
      `UPDATE web_page_components SET ${fields.join(
        ", "
      )}, updated_at = CURRENT_TIMESTAMP WHERE id = $${idx} RETURNING *`,
      values
    );
    if (!rows.length)
      return res.status(404).json({ message: "Section not found" });
    res.json(rows[0]);
  } catch (error) {
    console.error("Error updating page component:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Delete a page section/component
const deletePageComponent = async (req, res) => {
  const { id } = req.params;
  try {
    const { rowCount } = await pool.query(
      "DELETE FROM web_page_components WHERE id = $1",
      [id]
    );
    if (rowCount === 0)
      return res.status(404).json({ message: "Section not found" });
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting page component:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


// GET Activated template id
const getSalesChannelTemplate = async (req, res) => {
  // const { salesChannelId } = req.params;
   const salesChannelId = 1; 
   
  try {
    const { rows } = await pool.query(
      `SELECT template_id FROM sales_channel WHERE id = $1`,
      [salesChannelId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: "Sales channel not found" });
    }
    res.json({ template_id: rows[0].template_id });
  } catch (error) {
    console.error("Error fetching sales channel template_id:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


// PUT /web/web_templates/:templateId/sections
const updateTemplateSections = async (req, res) => {
  const { templateId } = req.params;
  const { sections, salesChannelId } = req.body; // sections: [{id, display, order}], salesChannelId: number

  if (!Array.isArray(sections) || !salesChannelId) {
    return res.status(400).json({ message: "sections array and salesChannelId are required" });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Update all provided sections
    for (const s of sections) {
      await client.query(
        `UPDATE web_template_sections
         SET display = $1, "order" = $2, updated_at = CURRENT_TIMESTAMP
         WHERE id = $3 AND template_id = $4`,
        [!!s.display, s.order, s.id, templateId]
      );
    }

    // Update template_id on sales_channel
    await client.query(
      `UPDATE sales_channel
       SET template_id = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [templateId, salesChannelId]
    );

    await client.query('COMMIT');
    res.json({ success: true });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error("Error updating template sections:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    client.release();
  }
};

const getCategoriesWithCount = async (req, res) => {
  try {
    const query = `
          
WITH RECURSIVE category_tree AS (
  -- roots
  SELECT
    c.category_id       AS root_id,
    c.category_id       AS category_id,
    c.category_under,
    0                   AS depth
  FROM categories c
  WHERE c.status = 'active'
    AND c.category_under IS NULL

  UNION ALL

  -- descendants
  SELECT
    ct.root_id,
    c.category_id,
    c.category_under,
    ct.depth + 1
  FROM categories c
  JOIN category_tree ct
    ON c.category_under = ct.category_id
  WHERE c.status = 'active'
)
SELECT 
  ct.root_id as category_id,
        r.name,
  r.mobile_url,
  r.desktop_url,   
  COUNT(DISTINCT p.product_id) AS product_count
FROM category_tree ct
LEFT JOIN product_category pc 
  ON ct.category_id = pc.category_id
  LEFT JOIN categories r
  ON r.category_id = ct.root_id
LEFT JOIN products p ON p.product_id = pc.product_id AND p.status = 'active'

GROUP BY ct.root_id, r.name, r.mobile_url, r.desktop_url
ORDER BY ct.root_id;

            `;
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching categories with count:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};




const getFeaturedProducts = async (req, res) => {
  try {
    const collectionId = 1;

    const { rows } = await pool.query(
      `
      SELECT
        p.product_id,
        p.title,
        p.price,
        p.search_engine_desc,
        pm.media_url
      FROM product_collections pc
      JOIN products p
        ON p.product_id = pc.product_id
      -- pick one image per product: main image first, else newest active
      LEFT JOIN LATERAL (
        SELECT m.media_url
        FROM product_media m
        WHERE m.product_id = p.product_id
          AND m.status = 'active'
        ORDER BY m.main DESC, m.created_at DESC, m.media_id DESC
        LIMIT 1
      ) pm ON TRUE
      WHERE pc.collection_id = $1
        AND p.publishing_online = TRUE
      ORDER BY p.created_at DESC
      `,
      [collectionId]
    );

    res.json(rows);
  } catch (error) {
    console.error("Error fetching featured products:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


const getBestSellingProducts = async (req, res) => {
  try {
    const collectionId = 4;

    const { rows } = await pool.query(
      `
      SELECT
        p.product_id,
        p.title,
        p.price,
        p.search_engine_desc,
        pm.media_url
      FROM product_collections pc
      JOIN products p
        ON p.product_id = pc.product_id
      -- pick one image per product: main image first, else newest active
      LEFT JOIN LATERAL (
        SELECT m.media_url
        FROM product_media m
        WHERE m.product_id = p.product_id
          AND m.status = 'active'
        ORDER BY m.main DESC, m.created_at DESC, m.media_id DESC
        LIMIT 1
      ) pm ON TRUE
      WHERE pc.collection_id = $1
        AND p.publishing_online = TRUE
      ORDER BY p.created_at DESC
      `,
      [collectionId]
    );

    res.json(rows);
  } catch (error) {
    console.error("Error fetching featured products:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

const getSpecialProducts = async (req, res) => {
  try {
    const collectionId = 5;

    const { rows } = await pool.query(
      `
      SELECT
        p.product_id,
        p.title,
        p.price,
        p.search_engine_desc,
        pm.media_url
      FROM product_collections pc
      JOIN products p
        ON p.product_id = pc.product_id
      -- pick one image per product: main image first, else newest active
      LEFT JOIN LATERAL (
        SELECT m.media_url
        FROM product_media m
        WHERE m.product_id = p.product_id
          AND m.status = 'active'
        ORDER BY m.main DESC, m.created_at DESC, m.media_id DESC
        LIMIT 1
      ) pm ON TRUE
      WHERE pc.collection_id = $1
        AND p.publishing_online = TRUE
      ORDER BY p.created_at DESC
      `,
      [collectionId]
    );

    res.json(rows);
  } catch (error) {
    console.error("Error fetching featured products:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};





// Get all collections
const getCollections = async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM collections WHERE status = 'active' ORDER BY collection_id ASC"
    );
    res.status(200).json(rows);
  } catch (error) {
    console.error("Error fetching components:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};


// Get all products for collection
const getCollectionProducts = async (req, res) => {
  try {
    const collectionId = Number(req.params.collection_id || req.query.collection_id);
    if (!Number.isFinite(collectionId)) {
      return res.status(400).json({ error: 'collection_id is required (param or query)' });
    }

    const limit  = Math.min(Math.max(parseInt(req.query.limit ?? '100', 10), 1), 200);
    const offset = Math.max(parseInt(req.query.offset ?? '0', 10), 0);
    const merchantId = req.query.merchant_id ? Number(req.query.merchant_id) : null;

    const orderByKey = String(req.query.order_by || 'manual').toLowerCase();
    const ORDER_MAP = {
      manual:      ' p.product_id DESC',
      price_asc:   'p.price ASC NULLS LAST',
      price_desc:  'p.price DESC NULLS LAST',
      created_desc:'p.created_at DESC NULLS LAST',
    };
    const orderBy = ORDER_MAP[orderByKey] || ORDER_MAP.manual;

    // NOTE: adjust table names/columns here to match your schema:
    // - products:            p (product_id, title, price, search_engine_desc, status, created_at, merchant_id)
    // - product_collections: pc (collection_id, product_id, position)
    // - product_media:       m  (product_id, url, is_primary, sort_order, created_at)
    //
    // If your media table/column differs, change the LATERAL subquery.
    const params = [collectionId, limit, offset];
    let merchantFilter = '';
    if (Number.isFinite(merchantId)) {
      params.push(merchantId);
      merchantFilter = ' AND p.merchant_id = $4';
    }

    const sql = `
      SELECT
        p.product_id,
        p.title,
        p.price::text AS price,
        p.search_engine_desc,
        pm.media_url AS media_url
      FROM products p
      JOIN product_collections pc
        ON pc.product_id = p.product_id
       AND pc.collection_id = $1
      LEFT JOIN LATERAL (
        SELECT m.media_url
        FROM product_media m
        WHERE m.product_id = p.product_id
        ORDER BY m.media_id DESC, m.created_at
        LIMIT 1
      ) pm ON TRUE
       ${merchantFilter}
      ORDER BY ${orderBy}
      LIMIT $2 OFFSET $3;
    `;

    const { rows } = await pool.query(sql, params);
    return res.json(rows);
  } catch (err) {
    console.error('getCollectionProducts error:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
};




module.exports = {
  getTemplate,
  getPages,
  getPage,
  createPage,
  updatePage,
  deletePage,
  // New builder logic:
  getTemplateSections,
  getSelectedTemplate,
  setSelectedTemplate,
  getSelectedSections,
  setSelectedSections,
  getComponents,
  createComponent,
  updateComponent,
  deleteComponent,

  getPageComponents,
  createPageComponent,
  updatePageComponent,
  deletePageComponent,

  updateTemplateSections,
  getSalesChannelTemplate,
  getCategoriesWithCount,
  getFeaturedProducts,
  getBestSellingProducts,
  getSpecialProducts,
  getCollections,
  getCollectionProducts,
};
