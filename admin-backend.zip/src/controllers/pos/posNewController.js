const pool = require("../../config/db");
const { insertAdminLog } = require("../../models/userLogs");

 const getVoucherById = async (req, res) => {
    const client = await pool.connect();

    try {
        const { voucherId } = req.params;

        const result = await client.query(
            `
            SELECT
                id,
                voucher_id,
                amount
            FROM voucher
            WHERE voucher_id = $1 AND status = 'active'
            LIMIT 1
            `,
            [voucherId]
        );

        if (result.rowCount === 0) {
            return res.status(404).json({
                success: false,
                message: "Voucher not found."
            });
        }

        const voucher = result.rows[0];

        return res.status(200).json({
            success: true,
            voucher: {
                id: voucher.id,
                voucher_id: voucher.voucher_id,
                amount: Number(voucher.amount)
            },
        });
    } catch (error) {
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Internal server error."
        });
    } finally {
        client.release();
    }
};

module.exports = {
   getVoucherById
}