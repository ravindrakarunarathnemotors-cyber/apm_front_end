const { json } = require("express");
const pool = require("../../config/db");
const { systemSettings, checkLoyalty, updateLoyaltySuctomer, addLoyalty } = require("../../models/commonModels");
const { insertAdminLog } = require("../../models/userLogs");
const { decryptId } = require("../../util/orderEncrypt");
const updateTransactionRecord = require("../../routes/transactionsUpdater/transactionsUpdater");
const { customhook } = require("../../models/smsnotificationmodel");
const { getIO } = require("../../socket");

function normalizePhoneNumber(mobile = '') {
    const cleaned = mobile.replace(/\D/g, '') // remove +, spaces, etc

    if (cleaned.startsWith('94')) return cleaned
    if (cleaned.startsWith('0')) return `94${cleaned.slice(1)}`
    if (cleaned.startsWith('7')) return `94${cleaned}`

    return cleaned
}

const getAllCustomer = async (req, res) => {
    try {
        const { customer } = req.body;

        // ✅ clean input
        const search = customer?.trim();
        if (!search) {
            return res.status(400).json({ message: "Search value is required" });
        }

        const realNumber = normalizePhoneNumber(search);

        const conditions = [];
        const values = [];
        let i = 1;

        // 🔍 Name search (first, last, full name)
        conditions.push(`
            (
                first_name ILIKE $${i}
                OR last_name ILIKE $${i}
                OR concat_ws(' ', first_name, last_name) ILIKE $${i}
            )
        `);
        values.push(`%${search}%`);
        i++;

        // 📱 Phone search (ONLY if valid number)
        if (realNumber) {
            conditions.push(`
        contact_number_1 ILIKE $${i}
        OR contact_number_1 ILIKE $${i + 1}
    `);

            values.push(`%${search}%`);      // direct number entered
            values.push(`%${realNumber}%`);  // normalized number

            i += 2;
        }


        // 🎟 Loyalty number (BIGINT → text)
        conditions.push(`loyality_number::text ILIKE $${i}`);
        values.push(`%${search}%`);

        const query = `
            SELECT
                customer_id AS id,
                first_name,
                last_name,
                contact_number_1 AS mobile,
                email,
                loyalty_point
            FROM customer
            WHERE status = 'active'
              AND (${conditions.join(' OR ')})
        `;

        const { rows } = await pool.query(query, values);

        if (rows.length === 0) {
            return res.status(404).json({ message: "Customer not found" });
        }

        const options = rows.map(item => ({
            value: item.id,
            label: `${item.mobile} - ${item.first_name} ${item.last_name}`,
            ...item
        }));

        return res.status(200).json({
            message: "Customers Found",
            result: options
        });

    } catch (err) {
        console.error('Error fetching customers:', err);
        return res.status(500).json({ error: 'Internal server error' });
    }
};


const saveCustomer = async (req, res) => {
    try {

        const { customer, id } = req.body
        console.log(id)

        const query = `UPDATE invoice_header SET customer_id = $1 WHERE id = $2;`

        const { rowCount } = await pool.query(query, [customer.id, id])

        if (rowCount === 0) return res.status(400).json({ message: "Customer not found" })

        return res.status(200).json({ message: "Customer updated successfully" });
    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getoneCustomer = async (req, res) => {
    try {
        const { customer } = req.body;

        // ✅ clean input
        const search = customer?.trim();
        if (!search) {
            return res.status(400).json({ message: "Search value is required" });
        }

        const realNumber = normalizePhoneNumber(search);


        const query = `
            SELECT
                customer_id AS id,
                first_name,
                last_name,
                contact_number_1 AS mobile,
                email,
                loyalty_point
            FROM customer
            WHERE status = 'active'
              AND (contact_number_1 = $1 OR contact_number_1 = $2)
        `;

        const { rows } = await pool.query(query, [search, realNumber]);

        if (rows.length === 0) {
            return res.status(404).json({ message: "Customer not found" });
        }

        const options = rows[0]

        return res.status(200).json({
            message: "Customers Found",
            result: options
        });

    } catch (err) {
        console.error('Error fetching customers:', err);
        return res.status(500).json({ error: 'Internal server error' });
    }
};

const savepayments = async (req, res) => {
    try {

        const { id, payments } = req.body

        const query = `UPDATE invoice_header SET payments = $1::jsonb WHERE id = $2;`

        const { rowCount } = await pool.query(query, [JSON.stringify(payments), id])

        if (rowCount === 0) return res.status(400).json({ message: "Invoice not found" })

        return res.status(200).json({ message: "Invoice updated successfully" });
    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getCardTypes = async (req, res) => {
    try {
        const query = `SELECT id, name FROM card_types WHERE status = 'Active'`;
        const { rows } = await pool.query(query);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Card types not found' });
        }
        res.json(rows);
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getTerminal = async (req, res) => {
    const user = req.user
    const outlet_id = user.outlet_id
    try {
        const query = `SELECT id, name, account_name FROM card_terminal WHERE status = 'active' AND outlet_id = $1`;
        const { rows } = await pool.query(query, [outlet_id]);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Card types not found' });
        }
        res.json(rows);
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};


const getoneToken = async (req, res) => {
    const { id } = req.body
    try {
        const query = `SELECT id, amount, used_amount, date FROM return_token WHERE status = 'active' AND id = $1`;
        const { rows } = await pool.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'Return token not found' });
        }

        return res.status(200).json({ message: "Return token found", result: rows[0] });
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getoneVoucher = async (req, res) => {
    const { id } = req.body
    try {
        const query = `SELECT voucher_id as id, amount, used_amount, date FROM voucher WHERE status = 'active' AND voucher_id = $1`;
        const { rows } = await pool.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'Voucher not found' });
        }

        return res.status(200).json({ message: "Voucher found", result: rows[0] });
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getCustomerPoint = async (req, res) => {
    const { selectedCustomer } = req.body
    // console.log(selectedCustomer)
    try {
        const query = `SELECT loyalty_point FROM customer WHERE customer_id = $1`;
        const { rows } = await pool.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'Customer not found' });
        }

        return res.status(200).json({ message: "Customer loyalty points found", result: rows[0] });
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const completeInvoice = async (req, res) => {
    const { posDetails } = req.body
    // console.log(posDetails.discountDetails)
    const io = getIO();

    const user = req.user
    const user_id = user.user_id
    const merchant_id = user.merchant_id
    const outlet_id = user.outlet_id

    const client = await pool.connect();

    try {

        const invoice_id = parseFloat(posDetails.activeInvoice.id)
        const products = posDetails.activeInvoice.items
        const discountType = posDetails.discountType
        const tillId = posDetails.tillId

        const addPoints = posDetails.addPoints && Number(posDetails.addPoints) > 0 ? Number(posDetails.addPoints) : 0

        const finalTotal = parseFloat(posDetails.finalTotal) || 0
        const dueBalance = Math.abs(posDetails.dueBalance) || 0


        if (!invoice_id) return res.status(400).json({ message: "Invoice ID not found" })
        if (!products) return res.status(400).json({ message: "Products not found" })

        await client.query('BEGIN')

        const order_discount = posDetails && posDetails.discount ? posDetails.discount : 0
        const payment_method_discount = posDetails && posDetails.discountPaymentMethod ? posDetails.discountPaymentMethod.discount_value : 0

        // total discount
        const discount = order_discount + payment_method_discount

        //discount details
        const discount_array = []
        if (parseFloat(order_discount) > 0) {
            discount_array.push({ discount_type: 'order', discount_value: order_discount })
        }
        if (parseFloat(payment_method_discount) > 0) {
            discount_array.push({ discount_type: 'payment_method', discount_value: payment_method_discount })
        }

        const userQuery = `SELECT username FROM users WHERE user_id = $1`;

        const [userResult, system_settings, checkInvoiceResult] = await Promise.all([
            pool.query(userQuery, [user_id]),
            systemSettings(),
            pool.query(`SELECT id, order_status, table_id FROM invoice_header WHERE id = $1`, [invoice_id])
        ])

        if (userResult.rows.length === 0) return res.status(400).json({ message: "User not found" })

        if (checkInvoiceResult.rows.length === 0) return res.status(400).json({ message: "Invoice not found" })

        if (checkInvoiceResult.rows[0].order_status == 'completed') return res.status(400).json({ message: "Invoice already completed" })

        const username = userResult.rows[0].username

        const table_id = checkInvoiceResult.rows[0].table_id

        // await client.query('COMMIT')
        // return res.status(200).json({ message: "success" });

        const selectedCustomer = posDetails && posDetails.selectedCustomer ? posDetails.selectedCustomer : null

        let customerLoyalty = 0

        if (selectedCustomer) {
            customerLoyalty = await checkLoyalty(selectedCustomer.id)
        }
        // console.log(customerLoyalty)
        //calculation used loyality points
        let usedLoyality_points = 0
        usedLoyality_points = posDetails.payments.find(p => p.method_id === 9)?.total_amount ?? 0

        if (customerLoyalty < usedLoyality_points) return res.status(400).json({ message: "Customer doesn't have enough loyalty points" })

        const totalQuantity = products.reduce((total, item) => {
            return total + parseFloat(item.selectedqty || 0)
        }, 0);

        let loyalty_points_earned = 0

        const loyalty_point = system_settings.loyalty_point
        const points_given = parseFloat(system_settings.points_given) || 0
        const amount_spend = parseFloat(system_settings.amount_spend) || 0

        if (loyalty_point && finalTotal > 0 && selectedCustomer) {
            loyalty_points_earned = (finalTotal / amount_spend) * points_given
        }
        console.log("loyalty_points_earned", loyalty_points_earned)
        //update invoice details
        for (const product of products) {
            let is_free = false;
            let free_quantity = 0;
            const price = Number(product.price) || 0;
            const qty = Number(product.selectedqty) || 0;
            const discountValue = Number(product.discount) || 0;

            let discount = 0;

            if (product.discountType === "fixed") {
                discount = discountValue;
            } else {
                const total = price * qty;
                discount = total * (discountValue / 100);
            }

            if (discountType === 'buyx' && Array.isArray(posDetails?.discountDetails?.applicableProducts)) {
                const match = posDetails.discountDetails.applicableProducts.find(d => Number(d.product_id) == Number(product.product_id));
                if (match) {
                    is_free = true;
                    free_quantity = match.free_count || 0;
                }
                discount_array.push({ discount_type: 'buyx', details: posDetails.discountDetails })
            }

            const Update_product_details = `UPDATE invoice_details SET discount = $1, free_quantity = $2, is_free = $3 WHERE invoice_id = $4 AND variant_id	= $5 AND product_id = $6 AND (
              batch_no = $7
              OR (batch_no IS NULL AND $7 IS NULL)
            )`
            console.log("product free", free_quantity)
            const product_details_result = await client.query(Update_product_details, [discount, free_quantity, is_free, invoice_id, Number(product.variant_id), Number(product.product_id), product.batch_number])

            if (product_details_result.rowCount === 0) {
                await client.query('ROLLBACK')
                return res.status(400).json({ message: "Product not found" })
            }


        }

        let tax_percentage = null
        let tax = null

        if (posDetails.taxEnabled) {
            tax_percentage = posDetails.taxFields.value
            tax = { "name": posDetails.taxFields.key, "value": posDetails.totalTax }
        }

        const InvoiceQuery = `UPDATE invoice_header SET merchant_id = $1, order_status = $2, total_value = $3, amount_paid = $4, total_item = $5, total_weight = $6, cod = $7, payment_status = $8, currency = $9, delivery_fee = $10, discount = $11, tax_percentage = $12, tax = $13, full_amount = $14,  discount_details = $15, loyalty_points_spent = $16,  loyalty_points_earned = $17, customer_id = $18, balance = $19, add_to_points = $20, created_at = NOW(), user_id = $21, outlet_id = $22, service_charge = $23, service_percentage = $24, service_type = $25 WHERE id = $26`

        const params = [merchant_id, 'completed', posDetails.subtotal, finalTotal, totalQuantity, 0, false, 'paid', system_settings.currency, 0, discount, tax_percentage, tax, finalTotal, JSON.stringify(discount_array), usedLoyality_points, loyalty_points_earned, selectedCustomer ? selectedCustomer.id : null, dueBalance, addPoints, user_id, outlet_id, posDetails.service_charge, posDetails.servicePercentage, table_id ? 'dining' : 'takeaway', invoice_id]


        const module = "Pos";
        const logMessage = `User ${user_id} completed invoice ${invoice_id}`;

        const invoiceResult = await client.query(InvoiceQuery, params)

        if (invoiceResult.rowCount === 0) {
            await client.query('ROLLBACK')
            return res.status(400).json({ message: "Invoice not found" })
        }

        const [payment_result, logResult, inventoryResult] = await Promise.all([
            paymentMethod_save(posDetails.payments, client, invoice_id, user_id, selectedCustomer, customerLoyalty, dueBalance, tillId, addPoints, outlet_id),
            insertAdminLog(user_id, module, logMessage),
            inventoryAdjustment(products, outlet_id, merchant_id, user_id, username, client, discountType, posDetails)
        ])

        if (payment_result.status === false) {
            await client.query('ROLLBACK')
            return res.status(400).json({ message: payment_result.message })
        }


        // console.log(inventoryResult)
        if (inventoryResult.status === false) {
            await client.query('ROLLBACK')
            return res.status(400).json({ message: inventoryResult.message })
        }

        if (loyalty_point && parseFloat(loyalty_points_earned) > 0 && selectedCustomer) {
            await addLoyalty(selectedCustomer.id, loyalty_points_earned)
        }

        if (addPoints && Number(addPoints) > 0 && selectedCustomer) {
            await addLoyalty(selectedCustomer.id, addPoints)
        }

        await client.query('COMMIT')

        const responsehook = await customhook(13, invoice_id)

        const saveDeatils = await InvoiceDeatils(invoice_id)

        io.emit("kitchen-order-status", {
            invoice_id,
            status: "processing"
        });
        
        return res.status(200).json({ message: "Invoice completed successfully", saveDeatils: saveDeatils.result });
    } catch (err) {
        await client.query('ROLLBACK')
        console.error('Complete invoice error:', err)

        res.status(500).json({ error: 'Failed to complete invoice' })

    } finally {
        // 🔥 ALWAYS release
        client.release()
    }
};

const paymentMethod_save = async (payments, client, invoice_id, user_id, selectedCustomer, customerLoyalty, dueBalance, tillId, addPoints, outlet_id) => {
    console.log('outlet_id', outlet_id)
    for (const payment of payments) {



        if (payment.method_id == 4) {
            for (const entry of payment.entries) {
                console.log(entry)
                const result = await client.query(
                    `UPDATE accounts SET balance = balance + $1 WHERE id = $2`,
                    [entry.amount, entry.account]
                );

                if (result.rowCount === 0) {
                    return { status: false, message: `Failed to save credit card transaction` };
                }

                const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, reference, acc_id, till_id) VALUES ($1, $2, $3, $4, $5, $6, $7)`

                const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, entry.amount, entry.reference, entry.account, tillId])

                if (payment_history.rowCount === 0) {
                    return { status: false, message: "Failed to save payment history" }
                }

            }

        }

        if (payment.method_id == 5) {

            const correct_amount = parseFloat(payment.total_amount) - parseFloat(dueBalance) - parseFloat(addPoints)

            const result = await client.query(
                `SELECT id FROM accounts WHERE p_method_id = $1 AND outlet_id = $2`,
                [5, outlet_id]
            );

            if (result.rows.length === 0) {
                return { status: false, message: `Failed to update account` };
            }

            const account_id = result.rows[0].id;

            const transactionResult = await updateTransactionRecord({
                client,
                amount: correct_amount,
                account_id: account_id,
                category_id: 1, // ✅ Supplier Payment category
                transaction_type: "income",
                note: `This is an income from POS, invoice ID: ${invoice_id}, Payment Method: Cash`,
                by_user_id: user_id,
                payer_payee_id: 1,
                outlet_id: outlet_id,
                log_module: "POS",
                log_message: `This is an income from POS, invoice ID: ${invoice_id}`,
            })

            const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, acc_id, till_id) VALUES ($1, $2, $3, $4, $5, $6)`

            const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, correct_amount, account_id, tillId])

            if (payment_history.rowCount === 0) {
                return { status: false, message: "Failed to save payment history" }
            }

        }


        if (payment.method_id == 6) {
            for (const entry of payment.entries) {
                // console.log("entry", entry.amount, entry.id, invoice_id)
                const result = await client.query(
                    `
                        UPDATE voucher
                        SET used_amount = used_amount + $1,
                             used_inv_id = COALESCE(used_inv_id, '[]'::jsonb)
                                || jsonb_build_array(
                                        jsonb_build_object(
                                            'id', $3::bigint,
                                            'amount', $1
                                        )
                                    ),
                                    status = CASE 
                                                WHEN (used_amount + $1) = amount THEN 'used'
                                                ELSE status
                                            END
                        WHERE voucher_id = $2
                        AND used_amount + $1 <= amount
                        RETURNING voucher_id;

                        `,
                    [entry.amount, entry.id, invoice_id]
                );

                if (result.rowCount === 0) {

                    return { status: false, message: `Insufficient voucher balance for voucher ID ${entry.id}` };
                }

                const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, till_id) VALUES ($1, $2, $3, $4, $5)`

                const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, entry.amount, tillId])

                if (payment_history.rowCount === 0) {
                    return { status: false, message: "Failed to save payment history" }
                }

            }

        }

        if (payment.method_id == 7) {
            for (const entry of payment.entries) {

                const result = await client.query(
                    `
                        UPDATE return_token
                        SET used_amount = used_amount + $1,
                            used_inv_id = COALESCE(used_inv_id, '[]'::jsonb)
                                || jsonb_build_array(
                                        jsonb_build_object(
                                            'id', $3::bigint,
                                            'amount', $1
                                        )
                                    ),
                                    status = CASE 
                                                WHEN (used_amount + $1) = amount THEN 'used'
                                                ELSE status
                                            END
                        WHERE id = $2
                        AND used_amount + $1 <= amount
                        RETURNING id;

                        `,
                    [entry.amount, entry.id, invoice_id]
                );

                if (result.rowCount === 0) {

                    return { status: false, message: `Insufficient voucher balance for voucher ID ${entry.id}` };
                }

                const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, till_id) VALUES ($1, $2, $3, $4, $5)`

                const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, entry.amount, tillId])

                if (payment_history.rowCount === 0) {
                    return { status: false, message: "Failed to save payment history" }
                }

            }

        }

        if (payment.method_id == 8) {
            for (const entry of payment.entries) {

                const result = await client.query(
                    ` INSERT INTO credit_card_transaction (terminal_id, amount, reference, card_type, invoice_id) VALUES ($1, $2, $3, $4, $5) 
                        `,
                    [entry.terminal, entry.amount, entry.reference, entry.cardType, invoice_id]
                );

                if (result.rowCount === 0) {

                    return { status: false, message: `Failed to save credit card transaction` };
                }

                const findAccountID = await client.query(
                    `SELECT account_id FROM card_terminal WHERE id = $1`,
                    [entry.terminal]
                )

                if (findAccountID.rows.length === 0) {
                    return { status: false, message: `Terminal not found` };
                }

                const account_id = findAccountID.rows[0].account_id

                // const accountresult = await client.query(
                //     `UPDATE accounts SET balance = balance + $1 WHERE id = $2`,
                //     [entry.amount, account_id]
                // );

                // if (accountresult.rowCount === 0) {
                //     return { status: false, message: `Failed to update account` };
                // }

                const transactionResult = await updateTransactionRecord({
                    client,
                    amount: entry.amount,
                    account_id: account_id,
                    category_id: 1, // ✅ Supplier Payment category
                    transaction_type: "income",
                    note: `This is an income from POS, invoice ID: ${invoice_id}, Payment Method: Credit Card`,
                    by_user_id: user_id,
                    payer_payee_id: 1,
                    outlet_id: outlet_id,
                    log_module: "POS",
                    log_message: `This is an income from POS, invoice ID: ${invoice_id}`,
                });

                const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, till_id, acc_id) VALUES ($1, $2, $3, $4, $5, $6)`

                const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, entry.amount, tillId, account_id])

                if (payment_history.rowCount === 0) {
                    return { status: false, message: "Failed to save payment history" }
                }

            }

        }

        if (payment.method_id == 9) {


            const insertPaymentHistory = `INSERT INTO invoice_payment_history (invoice_id, user_id, method_id, amount, till_id) VALUES ($1, $2, $3, $4, $5)`

            const payment_history = await client.query(insertPaymentHistory, [invoice_id, user_id, payment.method_id, payment.total_amount, tillId])

            if (payment_history.rowCount === 0) {
                return { status: false, message: "Failed to save payment history" }
            }

            if (selectedCustomer) {
                await updateLoyaltySuctomer(selectedCustomer.id, payment.total_amount, customerLoyalty, `used loyalty points for invoice ${invoice_id} from POS`);
            }

        }



    }

    return { status: true, message: "Payments saved successfully" }
}

const inventoryAdjustment = async (products, outlet_id, merchant_id, user_id, username, client, discountType, posDetails) => {

    try {
        for (const product of products) {
            let free_quantity = 0;

            if (discountType === 'buyx' && Array.isArray(posDetails?.discountDetails?.applicableProducts)) {
                const match = posDetails.discountDetails.applicableProducts.find(d => Number(d.product_id) === Number(product.product_id));
                if (match) {
                    free_quantity = match.free_count || 0;
                }
            }

            // console.log(product.variant_id);
            const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' AND (batch_number = $4 OR (batch_number IS NULL AND $4 IS NULL)) ORDER BY inventory_id DESC LIMIT 1`;

            const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id, batch_number
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

            const searchInventoryResult = await client.query(searchInventoryQuery, [
                product.variant_id,
                outlet_id,
                merchant_id,
                product.batch_number
            ]);

            let previous_quantity = 0;

            if (searchInventoryResult.rows.length > 0) {
                previous_quantity = searchInventoryResult.rows[0].new_quantity;
            }
            console.log("inventory free", free_quantity)

            const total_qty = (Number(product.amount_per_unit ? product.amount_per_unit : 1) * Number(free_quantity)) + Number(product.qty);

            const new_quantity = Number(previous_quantity) - total_qty

            const insertInventoryResult = await client.query(insertInventoryQuery, [
                product.variant_id,
                outlet_id,
                username,
                `POS stock out invoice number ${posDetails.activeInvoice.id}`,
                "stock out",
                previous_quantity,
                -total_qty,
                new_quantity,
                "active",
                merchant_id,
                user_id,
                product.batch_number
            ]);

            if (insertInventoryResult.rowCount === 0) {
                return {
                    status: false,
                    message: `Failed to update inventory for product ${product.variant_id}`
                };
            }
        }

        return {
            status: true,
            message: "Inventory updated successfully for all products"
        };

    } catch (error) {
        console.log(error)
        return { status: false, message: "Internal server error" }
    }

}

const InvoiceDeatils = async (invoice_id) => {

    try {
        const query = `SELECT
                        ih.id,
                        ih.order_status AS status,
                        ih.total_value,
                        ih.currency,
                        ih.discount,
                        ih.created_at as date,
                        ih.full_amount,
                        ih.tax,
                        ih.balance,
                        ih.add_to_points,
                        ih.service_percentage,
                        ih.service_charge,
                        c.first_name AS customer_name,
                        c.contact_number_1 AS customer_number,
                        u.first_name,
                        COALESCE(ih.payments, '[]'::jsonb) AS payments,
                        COALESCE(ih.salespersons, '[]'::jsonb) AS salespersons,
                        COALESCE(
                            json_agg(
                            json_build_object(
                                'product_id', ind.product_id,
                                'variant_id', ind.variant_id,
                                'variant_value', pv.variant_value,
                                'selectedqty', ind.quantity,
                                'price', ind.unit_price,
                                'total_price', ind.total_price,
                                'amount_per_unit', ind.amount_per_unit,
                                'measurement_id', ind.unit_type,
                                'discount', ind.discount,
                                'name', p.title,
                                'measurement_value', m.measurement_value,
                                'batch_number', ind.batch_no,
                                'free_quantity', ind.free_quantity,
                                'qty', CASE
                                            WHEN ind.unit_type::integer = 1
                                            THEN ind.quantity
                                            ELSE
                                            ind.quantity * ind.amount_per_unit
                                        END
                            )
                            ) FILTER (WHERE ind.id IS NOT NULL),
                            '[]'
                        ) AS items
                        FROM invoice_header ih
                        LEFT JOIN invoice_details ind ON ind.invoice_id = ih.id
                        LEFT JOIN products p ON p.product_id = ind.product_id
                        LEFT JOIN product_variants pv ON pv.variant_id = ind.variant_id
                        LEFT JOIN measurements m ON m.measurement_id = ind.unit_type::integer
                        LEFT JOIN users u ON u.user_id = ih.user_id
                        LEFT JOIN customer c ON c.customer_id = ih.customer_id
                        WHERE ih.id = $1
                        GROUP BY ih.id, u.first_name, c.first_name, c.contact_number_1

        `

        const result = await pool.query(query, [invoice_id])

        if (result.rows.length === 0) return { status: false, message: "Invoice not found" }

        return { status: true, message: "success", result: result.rows[0] }
    } catch (error) {
        console.log(error)
        return { status: false, message: "Internal server error" }
    }
}

const savesales = async (req, res) => {
    try {

        const { id, payments } = req.body

        const query = `UPDATE invoice_header SET salespersons = $1::jsonb WHERE id = $2;`

        const { rowCount } = await pool.query(query, [JSON.stringify(payments), id])

        if (rowCount === 0) return res.status(400).json({ message: "Invoice not found" })

        return res.status(200).json({ message: "Invoice updated successfully" });
    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getTill = async (req, res) => {
    try {
        const query = `SELECT device_id,
          type,
          display_id,
          till_name,  
          enable_customer_input,
          device_info,
          banner_files FROM device_management WHERE status = 'Active' AND type = 'till' ORDER BY device_id`;
        const { rows } = await pool.query(query);
        if (rows.length === 0) {
            return res.status(404).json({ error: 'Till not found' });
        }
        return res.status(200).json({ message: "success", result: rows });
    } catch (err) {
        console.error('Error fetching card types:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
}

const newCustomer = async (req, res) => {
    try {

        const { form } = req.body

        // console.log(form)

        const query = `SELECT customer_id FROM customer WHERE contact_number_1 = $1`

        const { rows } = await pool.query(query, [Number(form.mobile)])

        if (rows.length > 0) return res.status(400).json({ message: "Customer already exist" })

        const query1 = `INSERT INTO customer (first_name, last_name, contact_number_1, email, birthday, loyality_number) VALUES ($1, $2, $3, $4, $5, $6) RETURNING customer_id, first_name, last_name, contact_number_1 as mobile, email, loyalty_point`

        const addCustomerResult = await pool.query(query1, [form.firstName, form.lastName, form.mobile, form.email, form.birthday || null, form.loyaltyNumber ? form.loyaltyNumber : null])

        if (addCustomerResult.rowCount === 0) return res.status(400).json({ message: "Customer not created" })

        const Customer = addCustomerResult.rows[0]

        const options = {
            id: Customer.customer_id,
            value: Customer.customer_id,
            label: `${Customer.mobile} - ${Customer.first_name} ${Customer.last_name}`,
            ...Customer
        }

        return res.status(200).json({ message: "All Customers Found", result: options });

    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const ReprintInvoiceDeatils = async (req, res) => {

    const user = req.user
    const user_id = user.user_id
    const merchant_id = user.merchant_id
    const outlet_id = user.outlet_id

    try {
        const query = `SELECT
                        ih.id,
                        ih.order_status AS status,
                        ih.total_value,
                        ih.currency,
                        ih.discount,
                        ih.created_at as date,
                        ih.full_amount,
                        ih.tax,
                        ih.balance,
                        ih.add_to_points,
                        ih.service_percentage,
                        ih.service_charge,
                        u.first_name,
                        c.first_name AS customer_name,
                        c.contact_number_1 AS customer_number,
                        COALESCE(ih.payments, '[]'::jsonb) AS payments,
                        COALESCE(ih.salespersons, '[]'::jsonb) AS salespersons,
                        COALESCE(
                            json_agg(
                            json_build_object(
                                'product_id', ind.product_id,
                                'variant_id', ind.variant_id,
                                'variant_value', pv.variant_value,
                                'selectedqty', ind.quantity,
                                'price', ind.unit_price,
                                'total_price', ind.total_price,
                                'amount_per_unit', ind.amount_per_unit,
                                'measurement_id', ind.unit_type,
                                'discount', ind.discount,
                                'name', p.title,
                                'measurement_value', m.measurement_value,
                                'batch_number', ind.batch_no,
                                'free_quantity', ind.free_quantity,
                                'qty', CASE
                                            WHEN ind.unit_type::integer = 1
                                            THEN ind.quantity
                                            ELSE
                                            ind.quantity * ind.amount_per_unit
                                        END
                            )
                            ) FILTER (WHERE ind.id IS NOT NULL),
                            '[]'
                        ) AS items
                        FROM invoice_header ih
                        LEFT JOIN invoice_details ind ON ind.invoice_id = ih.id
                        LEFT JOIN products p ON p.product_id = ind.product_id
                        LEFT JOIN product_variants pv ON pv.variant_id = ind.variant_id
                        LEFT JOIN measurements m ON m.measurement_id = ind.unit_type::integer
                        LEFT JOIN users u ON u.user_id = ih.user_id
                        LEFT JOIN customer c ON c.customer_id = ih.customer_id
                        WHERE ih.user_id = $1 AND DATE(ih.created_at) = CURRENT_DATE AND ih.order_status = 'completed' AND ih.interface = 'pos'
                        GROUP BY ih.id, u.first_name, c.first_name, c.contact_number_1 ORDER BY ih.id DESC

        `

        const result = await pool.query(query, [user_id])

        if (result.rows.length === 0) return res.status(400).json({ message: "Invoice not found" })

        return res.status(200).json({ message: "success", result: result.rows });
    } catch (error) {
        console.log(error)
        return { status: false, message: "Internal server error" }
    }
}

const getSalesPersons = async (req, res) => {
    try {

        const query = `SELECT
                        employee_id AS id,
                        CONCAT(first_name, ' ', last_name) AS name
                    FROM employees
                    WHERE employment_status IN ('PERMANENT', 'PROBATION') AND is_sales_person = true;`

        const { rows } = await pool.query(query)

        if (rows.length === 0) return res.status(400).json({ message: "Sales person not found" })

        const options = rows.map((item) => {
            return {
                id: item.id,
                value: item.id,
                label: ` ${item.id} - ${item.name}`,
                ...item
            }
        })
        return res.status(200).json({ message: "All Customers Found", result: options });

    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};

const getOneInvoice = async (req, res) => {
    try {

        const { invoice_id } = req.body

        const id = decryptId(invoice_id)

        /* ---------------- ORDER ITEMS ---------------- */
        const itemsQuery = `
                            SELECT 
                        o.id,
                        o.customer_id,
                        o.payment_method_id,
                        o.order_status,
                        o.total_value,
                        o.amount_paid,
                        o.total_item,
                        o.total_weight,
                        o.payment_status,
                        o.currency,
                        o.sender_name,
                        o.sender_phone,
                        o.sender_email,
                        o.sender_address,
                        o.sender_city,
                        o.sender_postal_code,
                        o.sender_country,
                        o.sender_addrees_2,
                        o.discount,
                        o.created_at,
                        o.tax_percentage,
                        o.tax,
                        o.full_amount,
                        o.loyalty_points_earned,
                        o.loyalty_points_spent,
                        o.discount_type,
                        o.interface,
                        o.balance,
                        o.add_to_points,
                        o.user_id,
                        o.service_charge,
                        o.service_percentage,
                        u.first_name AS user_name,
                        c.first_name AS customer_name,
                        c.contact_number_1 AS customer_contact_number,

                        COALESCE(o.payments, '[]'::jsonb) AS payments,

                        /* ITEMS ARRAY */
                        COALESCE(
                            json_agg(
                                json_build_object(
                                    'id', ie.id,
                                    'product_id', ie.product_id,
                                    'variant_id', ie.variant_id,
                                    'name', ie.name,
                                    'description', ie.description,
                                    'item_weight', ie.item_weight,
                                    'quantity', ie.quantity,
                                    'unit_price', ie.unit_price,
                                    'discount', ie.discount,
                                    'total_price', ie.total_price,
                                    'is_free', ie.is_free,
                                    'free_quantity', ie.free_quantity,
                                    'is_custom', ie.is_custom,
                                    'amount_per_unit', ie.amount_per_unit,
                                    'unit_type', ie.unit_type,
                                    'variant_value', pv.variant_value,
                                    'measurement_value', m.measurement_value
                                )
                            ) FILTER (WHERE ie.id IS NOT NULL),
                            '[]'
                        ) AS items

                    FROM invoice_header o

                    LEFT JOIN invoice_details ie 
                        ON ie.invoice_id = o.id

                    LEFT JOIN product_variants pv 
                        ON ie.variant_id = pv.variant_id

                    LEFT JOIN measurements m 
                        ON ie.unit_type::INTEGER = m.measurement_id

                    LEFT JOIN customer c 
                        ON o.customer_id = c.customer_id

                    LEFT JOIN users u 
                        ON o.user_id = u.user_id

                    WHERE o.id = $1

                    GROUP BY 
                        o.id,
                        c.first_name,
                        u.first_name,
                        c.contact_number_1

                    ORDER BY o.created_at DESC;
        `;


        /* ---------------- invoice_payment_history ---------------- */
        const orderPaymentHistoryQuery = `SELECT  
            ip.id,
            ip.date,
            ip.invoice_id,
            ip.amount,
            ip.reference,
            ip.doc,
            ip.method_id,
            ip.status,
            pm.method_name
        FROM invoice_payment_history ip 
        LEFT JOIN payment_methods pm ON ip.method_id = pm.payment_method_id
        WHERE ip.invoice_id = $1`;

        /* ---------------- BRANDING ---------------- */
        const brandingQuery = `
          SELECT logo_url_white, company_name, address_1, address_2, hotline
          FROM branding_settings
          LIMIT 1
        `

        /* ---------------- SYSTEM SETTINGS ---------------- */
        const settingsQuery = `
          SELECT terms_conditions
          FROM system_settings
          LIMIT 1
        `

        const posSettingsQuery = `
          SELECT return_policy
          FROM pos_settings
          LIMIT 1
        `

        const [itemsResult, orderPaymentHistoryResult, brandingResult, settingsResult, posSettingsResult] = await Promise.all([
            pool.query(itemsQuery, [id]),
            pool.query(orderPaymentHistoryQuery, [id]),
            pool.query(brandingQuery),
            pool.query(settingsQuery),
            pool.query(posSettingsQuery)
        ]);

        if (itemsResult.rows.length === 0 || brandingResult.rows.length === 0 || settingsResult.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        const reutn_policy = posSettingsResult.rows[0]?.return_policy ?? null

        /* ---------------- RESPONSE ---------------- */
        return res.status(200).json({

            order_items: itemsResult.rows[0],
            order_payment_history: orderPaymentHistoryResult.rows,
            system_settings: {
                terms_conditions: settingsResult.rows[0]?.terms_conditions
                    ? JSON.parse(settingsResult.rows[0].terms_conditions)
                    : null,
            },
            brandingData: brandingResult.rows[0] ?? null,
            reutn_policy: reutn_policy
        });

    } catch (error) {
        console.error('Error fetching variants:', error);
        return res.status(500).json({ error: 'Internal server error' })
    }
}

const getAllAccount = async (req, res) => {
    try {

        const query = `SELECT id as value, name as label FROM accounts WHERE status = 'active' AND bank_account = true`

        const { rows } = await pool.query(query)

        if (rows.length === 0) return res.status(400).json({ message: "Sales person not found" })

        return res.status(200).json({ message: "All Customers Found", result: rows });

    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};
const resetDeviceInfo = async (req, res) => {
    try {
        const {device_id} = req.body
        const query = `UPDATE device_management SET device_info = null WHERE device_id = $1`

        const { rowCount } = await pool.query(query, [device_id])

        if (rowCount === 0) return res.status(400).json({ message: "Device not found" })

        return res.status(200).json({ message: "All Customers Found" });

    } catch (err) {
        console.error('Error fetching variants:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
};




module.exports = {
    getAllCustomer, saveCustomer, savepayments, getCardTypes, getTerminal, getoneToken, getoneVoucher, getCustomerPoint, completeInvoice, savesales, getTill, newCustomer, ReprintInvoiceDeatils, getSalesPersons, getoneCustomer, getOneInvoice, getAllAccount, resetDeviceInfo
}
