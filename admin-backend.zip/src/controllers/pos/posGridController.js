const pool = require("../../config/db");
const { insertAdminLog } = require("../../models/userLogs");
const { getIO } = require("../../socket");


const getAllCategoryID = async (id) => {
    const allIds = [id]; // include main parent first

    const findChildren = async (parentId) => {
        const query = `
      SELECT category_id 
      FROM categories 
      WHERE category_under = $1
    `;

        const { rows } = await pool.query(query, [parentId]);

        for (const row of rows) {
            allIds.push(row.category_id);
            await findChildren(row.category_id); // recursive call
        }
    };

    await findChildren(id);

    return allIds;
};

const fetchCategories = async (req, res) => {
    try {
        const query = `SELECT category_id, name FROM categories WHERE status = 'active' AND category_under IS NULL ORDER BY name ASC`;
        const { rows } = await pool.query(query);

        const newArray = [{ name: 'All', category_id: 0 }, ...rows];

        return res.status(200).json({ data: newArray });
    } catch (error) {
        console.error("Error fetching categories:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

const fetchProducts = async (req, res) => {
    try {
        const user = req.user;
        const outlet_id = user.outlet_id;

        const { activeCategory = 0, page = 1, inputValue } = req.body;

        const parsedLimit = 15;
        const parsedPage = parseInt(page, 10);
        const offset = (parsedPage - 1) * parsedLimit;

        let categoryIds = [];
        let filterByCategory = false;

        if (parseInt(activeCategory) !== 0) {
            categoryIds = await getAllCategoryID(activeCategory);
            filterByCategory = true;
        }

        // ---------------------------
        // WHERE condition
        // ---------------------------
        let whereClause = `p.status = 'active'`;
        let params = [];
        let paramIndex = 1;

        if (filterByCategory) {
            whereClause += ` AND pc.category_id = ANY($${paramIndex})`;
            params.push(categoryIds);
            paramIndex++;
        }

        if (inputValue && inputValue.trim() !== "") {
            whereClause += ` AND (
          p.title ILIKE '%' || $${paramIndex} || '%'
          OR p.product_id::text ILIKE '%' || $${paramIndex} || '%'
          OR v.variant_id::text ILIKE '%' || $${paramIndex} || '%'
          OR EXISTS (
              SELECT 1
              FROM unnest(p.similar_keywords) AS sk(keyword)
              WHERE sk.keyword ILIKE '%' || $${paramIndex} || '%'
          )
      )`;
            params.push(inputValue.trim());
            paramIndex++;
        }

        // outlet param
        const outletParamIndex = paramIndex;
        params.push(outlet_id);
        paramIndex++;

        // limit
        const limitParamIndex = paramIndex;
        params.push(parsedLimit);
        paramIndex++;

        // offset
        const offsetParamIndex = paramIndex;
        params.push(offset);

        // ---------------------------
        // MAIN QUERY
        // ---------------------------
        const query = `
      SELECT DISTINCT ON (v.variant_id)
        v.variant_id,
        v.variant_value,
        v.price,
        v.weight,
        v.barcode,
        v.continue_selling_oos,
        COALESCE(i.new_quantity, 0) AS quantity,
        p.product_id,
        p.title AS name,
        p.amount_per_unit,
        p.measurement_id,
        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
        m.measurement_value,
        pm.media_url AS main_img,
        pmd_first.media_url AS first_extra_img,
        COALESCE(bc.batch_count, 0) AS batch_count
      FROM product_variants v
      JOIN products p ON p.product_id = v.product_id
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      LEFT JOIN product_media pm 
        ON pm.product_id = p.product_id 
        AND pm.main = true 
        AND pm.variant_id IS NULL
      LEFT JOIN measurements m 
        ON p.measurement_id = m.measurement_id
      LEFT JOIN LATERAL (
          SELECT media_url
          FROM product_media
          WHERE product_id = p.product_id
            AND main = true 
            AND variant_id IS NOT NULL
          ORDER BY created_at ASC
          LIMIT 1
      ) pmd_first ON true
      LEFT JOIN LATERAL (
          SELECT new_quantity
          FROM inventory
          WHERE variant_id = v.variant_id 
            AND outlet_id = $${outletParamIndex}
          ORDER BY inventory_id DESC
          LIMIT 1
      ) i ON true
      LEFT JOIN LATERAL (
          SELECT COUNT(*) AS batch_count
          FROM batch_management bm
          WHERE bm.variant_id = v.variant_id 
            AND bm.status = 'active'
      ) bc ON true
      WHERE ${whereClause}
      ORDER BY v.variant_id
      LIMIT $${limitParamIndex}
      OFFSET $${offsetParamIndex}
    `;

        // ---------------------------
        // COUNT QUERY
        // ---------------------------
        const countQuery = `
      SELECT COUNT(DISTINCT v.variant_id) AS total
      FROM product_variants v
      JOIN products p ON p.product_id = v.product_id
      LEFT JOIN product_category pc ON p.product_id = pc.product_id
      WHERE ${whereClause}
    `;

        // Build params only for count query (category + input search)
        let countParams = [];

        if (filterByCategory) {
            countParams.push(categoryIds);
        }

        if (inputValue && inputValue.trim() !== "") {
            countParams.push(inputValue.trim());
        }

        const [result, countResult] = await Promise.all([
            pool.query(query, params),
            pool.query(countQuery, countParams)
        ]);

        const total = parseInt(countResult.rows[0].total, 10);
        const totalPages = Math.ceil(total / parsedLimit);

        return res.status(200).json({
            data: result.rows,
            total,
            totalPages,
            currentPage: parsedPage
        });

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal server error",
        });
    }
};


const fetchTables = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;
    try {
        const query = `SELECT 
                        rt.id,
                        rt.name,
                        rt.table_id,
                        rt.seats,
                        ih.user_id,
                        u.first_name,
                        u.last_name,
                        (ih.id IS NOT NULL) AS has_invoice
                    FROM restaurant_tables rt

                    LEFT JOIN LATERAL (
                        SELECT id, user_id
                        FROM invoice_header
                        WHERE table_id = rt.id
                        AND order_status != 'completed'
                        LIMIT 1
                    ) ih ON TRUE

                    LEFT JOIN users u 
                    ON u.user_id = ih.user_id

                    WHERE rt.status = 'Active'
                    AND rt.outlet_id = $1`
        const { rows } = await pool.query(query, [outlet_id]);

        return res.status(200).json({ result: rows });
    } catch (error) {
        console.error("Error fetching categories:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

const saveTableForInvoice = async (req, res) => {
    const user = req.user;
    const outlet_id = user.outlet_id;

    const { table_id, invoice_id } = req.body;
    try {
        if (!table_id || !invoice_id) return res.status(400).json({ message: "table_id or invoice_id is missing" })

        const Checkquery = `SELECT id FROM invoice_header WHERE table_id = $1 AND order_status != 'completed'`;
        const { rows } = await pool.query(Checkquery, [table_id]);

        if (rows.length > 0) {
            return res.status(400).json({ message: `Table ${table_id} already has an open invoice ${rows[0].id}` });
        }

        const updateQuery = `UPDATE invoice_header SET table_id = $1 WHERE id = $2 AND order_status != 'completed'`;
        const { rowCount } = await pool.query(updateQuery, [table_id, invoice_id]);

        if (rowCount === 0) {
            return res.status(404).json({ message: "Invoice not found or already completed" });
        }

        return res.status(200).json({ message: "success" });
    } catch (error) {
        console.error("Error fetching categories:", error);
        res.status(500).json({ message: "Internal server error" });
    }
}

const selectTableInvoice = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id;
    const merchant_id = user.merchant_id;
    const outlet_id = user.outlet_id;

    const { table_id } = req.body

    try {
        const updatedraftTable = `UPDATE invoice_header SET order_status = $1 WHERE user_id = $2 AND order_status = 'draft'`
        const updateTableForuser = `UPDATE invoice_header SET order_status = $1, user_id = $3 WHERE table_id = $2 AND order_status != 'completed'`

        const result1 = await pool.query(updatedraftTable, ['hold', user_id])

        const result2 = await pool.query(updateTableForuser, ['draft', table_id, user_id])

        if (result2.rowCount === 0) return res.status(400).json({ message: "Table not found" })


        const query = `SELECT ih.id, ind.product_id, ind.variant_id, ind.quantity as selectedqty, ind.unit_price as price, ind.total_price, ind.item_weight, ind.amount_per_unit, ind.unit_type as measurement_id, ind.discount, p.title as name, m.measurement_value, ind.batch_no as batch_number, pv.variant_value,
        COALESCE(i.new_quantity, 0) AS quantity, pv.continue_selling_oos, ind.invoice_item_uid,
        CASE
        WHEN ind.unit_type::integer = 1
            THEN ind.quantity
        ELSE
            ind.quantity * ind.amount_per_unit
        END AS qty
        FROM invoice_details ind
        INNER JOIN invoice_header ih ON ih.id = ind.invoice_id
        INNER JOIN products p ON p.product_id = ind.product_id
        LEFT JOIN product_variants pv ON pv.variant_id = ind.variant_id
        LEFT JOIN measurements m ON m.measurement_id = ind.unit_type:: integer
        LEFT JOIN LATERAL (
            SELECT new_quantity
            FROM inventory
            WHERE variant_id = ind.variant_id AND outlet_id = $3
            ORDER BY inventory_id DESC
            LIMIT 1
        ) i ON true
        WHERE ih.user_id = $1 AND ih.order_status = $2 AND ih.table_id = $4
        ORDER BY ind.id ASC
        `;

        const invoice_header_query = `SELECT i.id, i.customer_id, c.first_name, c.last_name, c.loyalty_point, i.table_id, 
    COALESCE(i.payments, '[]'::jsonb) AS payments, COALESCE(i.salespersons, '[]'::jsonb) AS salespersons
        FROM invoice_header i
        LEFT JOIN customer c ON c.customer_id = i.customer_id 
        WHERE i.user_id = $1 AND i.order_status = $2 AND i.table_id = $3`;

        const [result, invoice_header_result] = await Promise.all([
            pool.query(query, [user_id, "draft", outlet_id, table_id]),
            pool.query(invoice_header_query, [user_id, "draft", table_id]),
        ]);

        if (result.rows.length === 0 && invoice_header_result.rows.length === 0)
            return res.status(400).json({ message: "Invoice not found" });

        const invoice_header = invoice_header_result.rows[0];

        return res
            .status(200)
            .json({
                message: "success",
                result: result.rows,
                invoice_id: invoice_header.id,
                invoice_header: invoice_header,
            });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

async function calculateDelta(invoiceId, client = pool) {
    const query = `
    SELECT
      i.id                                          AS invoice_item_id,
      i.invoice_id,
      i.product_id,
      COALESCE(kp.kitchen_id, 1)                    AS kitchen_id,
      i.quantity                                     AS total_qty,
      COALESCE(SUM(k.qty), 0)::int                  AS already_sent,
      (i.quantity - COALESCE(SUM(k.qty), 0))::int   AS delta
    FROM invoice_details i
    LEFT JOIN kitchen_products kp
      ON  kp.product_id = i.product_id
      AND kp.status     = 'Active'
    LEFT JOIN kitchen_order_lines k
      ON  k.product_id  = i.product_id
      AND k.invoice_id  = i.invoice_id
      AND k.is_reprint  = false
    WHERE i.invoice_id = $1
    GROUP BY i.id, i.invoice_id, i.product_id, kp.kitchen_id, i.quantity
    HAVING (i.quantity - COALESCE(SUM(k.qty), 0)) > 0
    ORDER BY COALESCE(kp.kitchen_id, 1), i.product_id
  `;

    const { rows } = await client.query(query, [invoiceId]);
    return rows;
}

function groupByKitchen(deltaRows) {
    return deltaRows.reduce((acc, row) => {
        const kid = row.kitchen_id;
        if (!acc[kid]) acc[kid] = [];
        acc[kid].push(row);
        return acc;
    }, {});
}

// ─── Send to Kitchen ─────────────────────────────────────────────────────────
const sendToKitchen = async (req, res) => {
    const { invoiceId } = req.body;

    const user = req.user;
    const sentBy = user.user_id;

    if (!invoiceId) {
        return res.status(400).json({ message: 'invoiceId is required' });
    }

    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        // const deltaRows = await calculateDelta(invoiceId, client);

        const [deltaRows, invoiceData] = await Promise.all([
            calculateDelta(invoiceId, client),
            pool.query('SELECT table_id FROM invoice_header WHERE id = $1', [invoiceId])
        ]);

        if (deltaRows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: 'No new items to send' });
        }

        if (invoiceData.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ message: 'Invoice not found' });
        }

        const table_id = invoiceData.rows[0].table_id || null;

        // 1. Insert ONE header for the entire send event
        const { rows: headerRows } = await client.query(
            `INSERT INTO kitchen_order_lines_header
         (sent_by, sent_at, table_id)
       VALUES ($1, NOW(), $2)
       RETURNING *`,
            [sentBy, table_id]
        );
        const header = headerRows[0];

        // 2. Insert all delta items linked to that single header
        const values = [];
        const params = [];
        let i = 1;

        for (const row of deltaRows) {
            values.push(`($${i++}, $${i++}, $${i++}, $${i++}, $${i++}, false)`);
            params.push(
                header.id,       // order_line_id → links to header
                row.invoice_id,
                row.product_id,
                row.kitchen_id,
                row.delta
            );
        }

        const { rows: lines } = await client.query(
            `INSERT INTO kitchen_order_lines
         (order_line_id, invoice_id, product_id, kitchen_id, qty, is_reprint)
       VALUES ${values.join(', ')}
       RETURNING *`,
            params
        );

        await client.query('COMMIT');

        // Fetch inserted lines with product name, grouped by kitchen
        const { rows: enriched } = await client.query(
            `SELECT
     l.invoice_id,
     l.kitchen_id,
     l.product_id,
     l.qty,
     p.title AS product_name,
     k.name AS kitchen_name,
     k.display_id,
     h.sent_at,
     h.id,
     h.table_id
   FROM kitchen_order_lines l
   LEFT JOIN kitchen_order_lines_header h ON h.id = l.order_line_id
   LEFT JOIN products p ON p.product_id = l.product_id
   LEFT JOIN kitchen k ON k.id = l.kitchen_id
   WHERE l.order_line_id = $1
   ORDER BY l.kitchen_id, p.title`,
            [header.id]
        );

        // Group by kitchen_id
        const groupedByKitchen = enriched.reduce((acc, row) => {
            const kid = row.kitchen_id;
            if (!acc[kid]) {
                acc[kid] = {
                    kitchen_id: kid,
                    header_id: row.id,
                    invoice_id: row.invoice_id,
                    kitchen_name: row.kitchen_name,
                    sent_at: row.sent_at,
                    display_id: row.display_id,
                    table_id: row.table_id,
                    items: [],
                };
            }
            acc[kid].items.push({
                product_id: row.product_id,
                product_name: row.product_name,
                qty: row.qty,
            });
            return acc;
        }, {});

        res.status(201).json({
            message: 'Sent to kitchen successfully',
            header_id: header.id,
            kitchens: Object.values(groupedByKitchen),
        });

        sendToDisplay(groupedByKitchen)

    } catch (error) {
        console.error('sendToKitchen error:', error);
        await client.query('ROLLBACK');
        return res.status(500).json({ message: 'Internal server error' });
    } finally {
        client.release();
    }
};

const sendToDisplay = (groupedByKitchen) => {
    try {
        const io = getIO();

        const kitchens = Object.values(groupedByKitchen);

        console.log(kitchens)

        kitchens.forEach(kitchen => {
            console.log(`kitchen:${kitchen.display_id}`);
            io.to(`kitchen:${kitchen.display_id}`).emit('new-order', {

                kitchen_id: kitchen.kitchen_id,
                invoice_id: kitchen.invoice_id,
                kitchen_name: kitchen.kitchen_name,
                header_id: kitchen.header_id,
                sent_at: kitchen.sent_at,
                table_id: kitchen.table_id,
                items: kitchen.items
            });
        });

    } catch (error) {
        console.error("sendToDisplay socket error:", error);
    }
};

const getOneKitchenHistory = async (headerId) => {
    try {
        const { rows } = await pool.query(
            `SELECT
          h.id            AS header_id,
          h.sent_by,
          h.sent_at,
          l.id            AS line_id,
          l.invoice_id,
          l.product_id,
          l.kitchen_id,
          l.qty,
          l.is_reprint,
          p.title         AS product_name
       FROM kitchen_order_lines_header h
       INNER JOIN kitchen_order_lines l ON l.order_line_id = h.id
       LEFT JOIN products p ON p.product_id = l.product_id
       WHERE h.id = $1
       ORDER BY h.sent_at DESC, h.id, l.kitchen_id, p.title`,
            [headerId]
        );

        if (!rows.length) return null;

        const header = {
            header_id: rows[0].header_id,
            invoice_id: rows[0].invoice_id,
            sent_by: rows[0].sent_by,
            sent_at: rows[0].sent_at,
            kitchens: {},
        };

        for (const row of rows) {
            if (!header.kitchens[row.kitchen_id]) {
                header.kitchens[row.kitchen_id] = {
                    kitchen_id: row.kitchen_id,
                    items: [],
                };
            }

            header.kitchens[row.kitchen_id].items.push({
                line_id: row.line_id,
                product_id: row.product_id,
                product_name: row.product_name,
                qty: row.qty,
                is_reprint: row.is_reprint,
            });
        }

        // convert kitchens object → array
        header.kitchens = Object.values(header.kitchens);

        return header;

    } catch (error) {
        console.error('getOneKitchenHistory error:', error);
        throw error; // let caller handle it
    }
};


// ─── Kitchen History ──────────────────────────────────────────────────────────
// Groups lines under their header so you can see each send event separately.
// sendCount tells you how many times the button was pressed per kitchen.
const getKitchenHistory = async (req, res) => {
    try {
        const { rows } = await pool.query(
            `SELECT
                h.id            AS header_id,
                h.sent_by,
                h.sent_at,
                l.id            AS line_id,
                l.invoice_id,
                l.product_id,
                l.kitchen_id,
                l.qty,
                l.is_reprint,
                p.title          AS product_name
             FROM kitchen_order_lines_header h
             INNER JOIN kitchen_order_lines l ON l.order_line_id = h.id
             LEFT JOIN products p ON p.product_id = l.product_id
             WHERE h.sent_at::date = CURRENT_DATE
             ORDER BY 
    h.sent_at DESC,
    h.id DESC,
    l.kitchen_id ASC,
    p.title ASC;`
        );

        const headersMap = {};

        for (const row of rows) {
            if (!headersMap[row.header_id]) {
                headersMap[row.header_id] = {
                    header_id: row.header_id,
                    invoice_id: row.invoice_id,
                    sent_by: row.sent_by,
                    sent_at: row.sent_at,
                    kitchens: {},
                };
            }

            const header = headersMap[row.header_id];

            if (!header.kitchens[row.kitchen_id]) {
                header.kitchens[row.kitchen_id] = {
                    kitchen_id: row.kitchen_id,
                    items: [],
                };
            }

            header.kitchens[row.kitchen_id].items.push({
                line_id: row.line_id,
                product_id: row.product_id,
                product_name: row.product_name,
                qty: row.qty,
                is_reprint: row.is_reprint,
            });
        }

        const history = Object.values(headersMap)
            .map(header => ({
                ...header,
                kitchens: Object.values(header.kitchens),
            }))
            .sort((a, b) => new Date(b.sent_at) - new Date(a.sent_at));

        return res.status(200).json({
            date: new Date().toISOString().split('T')[0],
            sendCount: history.length,
            result: history,
        });

    } catch (error) {
        console.error('getKitchenHistory error:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
};

const getPendingKitchenOrders = async (req, res) => {
    const dispayId = req.cookies.kot_display_id;

    if (!dispayId) {
        return res.status(400).json({
            success: false,
            message: "dispay ID not found in cookies"
        });
    }

    const client = await pool.connect();

    try {

        const kitchen = await client.query(
            `SELECT id FROM kitchen WHERE display_id = $1 `,
            [dispayId]
        );

        if (kitchen.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: "Kitchen not found"
            });
        }

        const kitchenId = kitchen.rows[0].id;

        console.log(kitchenId)

        const result = await client.query(
            `SELECT 
        kol.kitchen_id,
        k.name AS kitchen_name,        -- ✅ alias added
        kol.invoice_id,
        ko.id AS header_id,
        ko.sent_at,
        ko.table_id,
        kol.product_id,
        p.title AS product_name,       -- ✅ alias added
        kol.qty
      FROM kitchen_order_lines kol
      JOIN kitchen_order_lines_header ko ON ko.id = kol.order_line_id
      JOIN kitchen k ON k.id = kol.kitchen_id
      JOIN products p ON p.product_id = kol.product_id
      WHERE kol.kitchen_id = $1 AND kol.status = 'pending'
      ORDER BY kol.id DESC`,
            [kitchenId]
        );

        const rows = result.rows;

        const grouped = {};

        for (const row of rows) {
            const key = row.header_id;

            if (!grouped[key]) {
                grouped[key] = {
                    kitchen_id: row.kitchen_id,
                    kitchen_name: row.kitchen_name,   // ✅ now correct
                    invoice_id: row.invoice_id,
                    header_id: row.header_id,
                    sent_at: row.sent_at,
                    table_id: row.table_id,
                    items: []
                };
            }

            grouped[key].items.push({
                product_id: row.product_id,
                product_name: row.product_name,    // ✅ now correct
                qty: row.qty
            });
        }

        const response = Object.values(grouped).sort(
            (a, b) => b.header_id - a.header_id  // DESC
        );

        res.json({
            success: true,
            data: response
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: "Server error"
        });
    } finally {
        client.release();
    }
};

const completeKitchenOrders = async (req, res) => {
    const { header_id, kitchen_id } = req.body

    if (!header_id) {
        return res.status(400).json({
            success: false,
            message: "header_id is required"
        });
    }

    const client = await pool.connect();

    try {
        await client.query("BEGIN");

        const result = await client.query(
            `UPDATE kitchen_order_lines SET status = 'completed' WHERE order_line_id	 = $1 AND kitchen_id = $2`,
            [header_id, kitchen_id]
        );

        if (result.rowCount === 0) {
            await client.query("ROLLBACK");
            return res.status(400).json({
                success: false,
                message: "header_id not found"
            });
        }

        await client.query("COMMIT");

        res.json({
            success: true,
            message: "Order completed successfully"
        });

    } catch (error) {
        console.error(error);
        await client.query("ROLLBACK");
        res.status(500).json({
            success: false,
            message: "Server error"
        });
    } finally {
        client.release();
    }
}

module.exports = {
    fetchCategories,
    fetchProducts,
    fetchTables,
    saveTableForInvoice,
    selectTableInvoice,
    sendToKitchen,
    getKitchenHistory,
    getPendingKitchenOrders,
    completeKitchenOrders
}