const pool = require("../../config/db");
const { getvariantwithBatchno } = require("../../models/posModels");
const { insertAdminLog } = require("../../models/userLogs");

//display no security
const getsystemSettingsDisplay = async (req, res) => {
  try {
    const query = `SELECT field_config, inventory_strategy_id, tax, tax_value, currency FROM system_settings WHERE id = 1`;
    const result = await pool.query(query);

    if (result.rows.length === 0)
      return res
        .status(400)
        .json({ success: false, message: "System setting not found" });

    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error("Error fetching system settings:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch system settings" });
  }
};

const getwelcome = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT welcome_image, company_name, logo_url, logo_url_white, logo_name_white, logo_name_dark, address_1, address_2, hotline, info_email, website_url
      FROM branding_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Welcome image not found" });
    }

    res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching welcome image:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

//......................................................
//
const getsystemSettings = async (req, res) => {
  try {
    const query = `SELECT field_config, inventory_strategy_id, tax, tax_value, currency FROM system_settings WHERE id = 1`;
    const result = await pool.query(query);

    if (result.rows.length === 0)
      return res
        .status(400)
        .json({ success: false, message: "System setting not found" });

    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error("Error fetching system settings:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch system settings" });
  }
};

const getPosSettings = async (req, res) => {
  try {
    const query = `
            SELECT sound, restaurant_mode, logo_url, return_policy, quantity_dialog, scan_code, web_url
            FROM pos_settings
            WHERE id = 1
        `;

    const result = await pool.query(query);
    // console.log('data', result);

    if (result.rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: "POS settings not found",
      });
    }

    res.status(200).json({
      success: true,
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error fetching POS settings:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch POS settings",
    });
  }
};

const updatePosSettings = async (req, res) => {
  try {
    const {
      sound,
      restaurant_mode,
      logo_url,
      return_policy,
      quantity_dialog,
      scan_code,
      web_url,
    } = req.body;

    const query = `
      UPDATE pos_settings
      SET
        sound = COALESCE($1, sound),
        restaurant_mode = COALESCE($2, restaurant_mode),
        logo_url = COALESCE($3, logo_url),
        return_policy = COALESCE($4::jsonb, return_policy),
        quantity_dialog = COALESCE($5, quantity_dialog),
        scan_code = COALESCE($6, scan_code),
        web_url = COALESCE($7, web_url),
        updated_at = NOW()
      WHERE id = 1
      RETURNING sound, restaurant_mode, logo_url, return_policy
    `;

    const values = [
      sound ?? null,
      restaurant_mode ?? null,
      logo_url ?? null,
      return_policy ? JSON.stringify(return_policy) : null,
      quantity_dialog ?? false,
      scan_code ?? "all",
      web_url ?? null,
    ];

    const result = await pool.query(query, values);

    res.status(200).json({
      success: true,
      message: "POS settings updated successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating POS settings:", error);
    res.status(500).json({
      success: false,
      message: "Failed to update POS settings",
    });
  }
};

//....................

const CreateInvoiceID = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { till_id } = req.cookies;

  try {
    // 1️⃣ Check if draft invoice exists
    const draftResult = await pool.query(
      `
      SELECT id
      FROM invoice_header
      WHERE user_id = $1
      AND order_status = 'draft'
      LIMIT 1
      `,
      [user_id],
    );

    if (draftResult.rowCount > 0) {
      const draftId = draftResult.rows[0].id;

      // 2️⃣ Check if draft has items
      const itemsResult = await pool.query(
        `
        SELECT 1
        FROM invoice_details
        WHERE invoice_id = $1
        LIMIT 1
        `,
        [draftId],
      );

      // 🚫 Draft exists but has NO items → block
      if (itemsResult.rowCount === 0) {
        return res.status(400).json({
          message:
            "Draft invoice exists without items. Complete or delete it first.",
        });
      }
    }

    // 3️⃣ Check HOLD invoice without items
    const holdInvoiceResult = await pool.query(
      `
      SELECT ih.id
      FROM invoice_header ih
      WHERE ih.order_status = 'hold' AND ih.user_id = $1
      AND NOT EXISTS (
        SELECT 1
        FROM invoice_details id
        WHERE id.invoice_id = ih.id
      )
      LIMIT 1
      `,
      [user_id],
    );

    // ✅ If hold invoice exists → return it
    if (holdInvoiceResult.rowCount > 0) {
      const holdInvoiceId = holdInvoiceResult.rows[0].id;

      // ✅ convert HOLD → DRAFT
      await pool.query(
        `
        UPDATE invoice_header
        SET order_status = 'draft',
            user_id = $1
        WHERE id = $2
        `,
        [user_id, holdInvoiceId],
      );

      return res.status(200).json({
        message: "hold invoice reused",
        invoice_id: holdInvoiceId,
      });
    }

    const orderQuery = `INSERT INTO invoice_header (user_id, merchant_id, order_status, interface, till_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`;

    const OrderParms = [user_id, merchant_id, "draft", "pos", till_id];

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0)
      return res.status(400).json({ message: "order not created" });

    const invoice_id = orderResult.rows[0].id;

    const module = "Invoive";
    const logMessage = `New invoice #${invoice_id} has been placed by user ${user_id}`;

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({ message: "success", invoice_id: invoice_id });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getProductSearch = async (req, res) => {
  const user = req.user;
  const outlet_id = user.outlet_id;
  const { till_id } = req.cookies;

  // console.log("till_id", till_id)

  const { search, scan_code } = req.query;

  let query = `SELECT
    v.variant_id,
    v.variant_value,
    v.price,
    v.weight,
    v.barcode,
    v.continue_selling_oos,

    -- inventory
    COALESCE(i.new_quantity, 0) AS quantity,

    -- product details embedded per variant
    p.product_id,
    p.title AS name,
    p.amount_per_unit,
    p.measurement_id,
    CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
    m.measurement_value,

    -- media
    pm.media_url AS main_img,
    pmd_first.media_url AS first_extra_img,
    COALESCE(bc.batch_count, 0) AS batch_count
    FROM product_variants v
    JOIN products p 
    ON p.product_id = v.product_id
    LEFT JOIN product_media pm 
    ON pm.product_id = p.product_id 
    AND pm.main = true 
    AND pm.variant_id IS NULL
    LEFT JOIN measurements m 
    ON p.measurement_id = m.measurement_id
    LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
        AND main = true 
        AND variant_id IS NOT NULL
        ORDER BY created_at ASC
        LIMIT 1
    ) pmd_first ON true
    LEFT JOIN LATERAL (
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = v.variant_id AND outlet_id = $2
        ORDER BY inventory_id DESC
        LIMIT 1
    ) i ON true
    LEFT JOIN LATERAL (
    SELECT COUNT(*) AS batch_count
    FROM batch_management bm
    WHERE bm.variant_id = v.variant_id AND bm.status = 'active'
    ) bc ON true
    WHERE p.status = 'active'
`;

  if (scan_code == "all") {
    query += `  AND (
        p.title ILIKE '%' || $1 || '%'
        OR v.barcode::text ILIKE $1
        OR p.product_id::text ILIKE $1
        OR v.variant_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )`;
  }

  if (scan_code == "barcode") {
    query += `  AND (
        p.title ILIKE '%' || $1 || '%'
        OR v.barcode::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )`;
  }

  if (scan_code == "product") {
    query += `  AND (
        p.title ILIKE '%' || $1 || '%'
        OR p.product_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )`;
  }

  if (scan_code == "variant") {
    query += `  AND (
        p.title ILIKE '%' || $1 || '%'
        OR v.variant_id::text ILIKE $1
        OR EXISTS (
        SELECT 1
        FROM unnest(p.similar_keywords) AS sk(keyword)
        WHERE sk.keyword ILIKE '%' || $1 || '%'
    )
    )`;
  }

  query += ` ORDER BY v.variant_id LIMIT 10 OFFSET 0;`;

  try {
    const result = await pool.query(query, [`%${search}%`, outlet_id]);
    return res.status(200).json({
      message: "success",
      result: result.rows,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
};

// normal invoice abd add product
const createTemporyInvoice = async (req, res) => {
  const { products } = req.body;
  // console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { till_id } = req.cookies;

  try {
    const orderQuery = `INSERT INTO invoice_header (user_id, merchant_id, order_status, interface, till_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`;

    const OrderParms = [user_id, merchant_id, "draft", "pos", till_id];

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0)
      return res.status(400).json({ message: "order not created" });

    const invoice_id = orderResult.rows[0].id;

    const orderItemParams = [
      invoice_id,
      products.product_id,
      products.variant_id,
      1,
      products.price,
      Number(products.price),
      0,
      products.amount_per_unit || null,
      products.measurement_id || null,
      0,
      products.name,
    ];

    //add order items
    const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight,  amount_per_unit, unit_type, discount, name) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

    const orderItemResult = await pool.query(orderItemQuery, orderItemParams);

    if (orderItemResult.rowCount === 0) {
      return res.status(400).json({ message: "Order item not added" });
    }

    const module = "Invoive";
    const logMessage = `New invoice #${invoice_id} has been placed by user ${user_id}`;

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({ message: "success", invoice_id: invoice_id });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
const addItemsToInvoice = async (req, res) => {
  const { products, invoice_id } = req.body;
  // console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  try {
    const checkProductQuery = `SELECT id, quantity, unit_price FROM invoice_details WHERE invoice_id = $1 AND product_id = $2 AND variant_id = $3`;

    const checkProductResult = await pool.query(checkProductQuery, [
      invoice_id,
      products.product_id,
      products.variant_id,
    ]);

    let module = "";
    let logMessage = ``;

    if (checkProductResult.rows.length > 0) {
      const updateProductQuery = `UPDATE invoice_details SET quantity = quantity + 1, total_price = $1 WHERE invoice_id = $2 AND product_id = $3 AND variant_id = $4`;

      console.log(checkProductResult.rows[0]);

      const total_price =
        Number(checkProductResult.rows[0].unit_price) *
        (Number(checkProductResult.rows[0].quantity) + 1);

      const updateProductParams = [
        total_price,
        invoice_id,
        products.product_id,
        products.variant_id,
      ];

      const updateProductResult = await pool.query(
        updateProductQuery,
        updateProductParams,
      );

      if (updateProductResult.rowCount === 0) {
        return res.status(400).json({ message: "Order item not updated" });
      }

      module = "Add Product to Invoive";
      logMessage = `New product (${products.variant_id}) has been added to invoice #${invoice_id} by user ${user_id}`;
    } else {
      const orderItemParams = [
        invoice_id,
        products.product_id,
        products.variant_id,
        1,
        products.price,
        Number(products.price),
        0,
        products.amount_per_unit || null,
        products.measurement_id || null,
        0,
        products.name,
      ];

      //add order items
      const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight,  amount_per_unit, unit_type, discount, name) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

      const orderItemResult = await pool.query(orderItemQuery, orderItemParams);

      if (orderItemResult.rowCount === 0) {
        return res.status(400).json({ message: "Order item not added" });
      }

      module = "Add Product to Invoive";
      logMessage = `New product (${products.variant_id}) has been added to invoice #${invoice_id} by user ${user_id}`;
    }

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({ message: "success", invoice_id: invoice_id });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

//one batch and add product
const onebatchaddItemsToInvoice = async (req, res) => {
  const { products, invoice_id } = req.body;
  // console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const outlet_id = user.outlet_id;

  try {
    const result = await getvariantwithBatchno(
      Number(products.variant_id),
      outlet_id,
    );

    const batch_no = result.batch_number;
    console.log(result);
    // return res.status(400).json({ message: "success", batch_no: batch_no });

    const checkProductQuery = `SELECT id, quantity, unit_price FROM invoice_details WHERE invoice_id = $1 AND product_id = $2 AND variant_id = $3 AND batch_no = $4`;

    const checkProductResult = await pool.query(checkProductQuery, [
      invoice_id,
      products.product_id,
      products.variant_id,
      batch_no,
    ]);

    let module = "";
    let logMessage = ``;

    if (checkProductResult.rows.length > 0) {
      const updateProductQuery = `UPDATE invoice_details SET quantity = quantity + 1, total_price = $1 WHERE invoice_id = $2 AND product_id = $3 AND variant_id = $4`;

      const total_price =
        Number(checkProductResult.rows[0].unit_price) *
        (Number(checkProductResult.rows[0].quantity) + 1);

      const updateProductParams = [
        total_price,
        invoice_id,
        products.product_id,
        products.variant_id,
      ];

      const updateProductResult = await pool.query(
        updateProductQuery,
        updateProductParams,
      );

      if (updateProductResult.rowCount === 0) {
        return res.status(400).json({ message: "Order item not updated" });
      }

      module = "Add Product to Invoive";
      logMessage = `New product (${products.variant_id}) has been added to invoice #${invoice_id} by user ${user_id}`;
    } else {
      const orderItemParams = [
        invoice_id,
        products.product_id,
        products.variant_id,
        1,
        result.price,
        Number(result.price),
        0,
        products.amount_per_unit || null,
        products.measurement_id || null,
        0,
        batch_no,
        products.name || null,
      ];

      //add order items
      const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight,  amount_per_unit, unit_type, discount, batch_no, name) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

      const orderItemResult = await pool.query(orderItemQuery, orderItemParams);

      if (orderItemResult.rowCount === 0) {
        return res.status(400).json({ message: "Order item not added" });
      }

      module = "Add Product to Invoive";
      logMessage = `New product (${products.variant_id}) has been added to invoice #${invoice_id} by user ${user_id}`;
    }

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res
      .status(200)
      .json({ message: "success", invoice_id: invoice_id, result: result });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const onebatchcreateTemporyInvoice = async (req, res) => {
  const { products } = req.body;
  console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const outlet_id = user.outlet_id;
  const merchant_id = user.merchant_id;

  const { till_id } = req.cookies;

  try {
    const result = await getvariantwithBatchno(
      Number(products.variant_id),
      outlet_id,
    );

    const batch_no = result.batch_number;

    const orderQuery = `INSERT INTO invoice_header (user_id, merchant_id, order_status, interface, till_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`;

    const OrderParms = [user_id, merchant_id, "draft", "pos", till_id];

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0)
      return res.status(400).json({ message: "order not created" });

    const invoice_id = orderResult.rows[0].id;

    const orderItemParams = [
      invoice_id,
      products.product_id,
      products.variant_id,
      1,
      result.price,
      Number(result.price),
      0,
      products.amount_per_unit || null,
      products.measurement_id || null,
      0,
      batch_no,
      products.name || null,
    ];

    //add order items
    const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight,  amount_per_unit, unit_type, discount, batch_no, name) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

    const orderItemResult = await pool.query(orderItemQuery, orderItemParams);

    if (orderItemResult.rowCount === 0) {
      return res.status(400).json({ message: "Order item not added" });
    }

    const module = "Invoive";
    const logMessage = `New invoice #${invoice_id} has been placed by user ${user_id}`;

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res
      .status(200)
      .json({ message: "success", invoice_id: invoice_id, result: result });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const FIFOaddItemsToInvoice = async (req, res) => {
  const client = await pool.connect();

  try {
    const { products, invoice_id } = req.body;

    if (!products || products.length === 0) {
      return res.status(400).json({ message: "No products provided" });
    }

    const user = req.user;
    const user_id = user.user_id;

    const { product_id, variant_id } = products[0];

    await client.query("BEGIN");

    // 1️⃣ Remove existing FIFO rows for this variant
    await client.query(
      `DELETE FROM invoice_details
             WHERE invoice_id = $1
               AND product_id = $2
               AND variant_id = $3`,
      [invoice_id, product_id, variant_id],
    );

    // 2️⃣ Build bulk insert
    const values = [];
    const params = [];

    products.forEach((product, i) => {
      const base = i * 12;

      values.push(
        `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4},
                  $${base + 5}, $${base + 6}, $${base + 7}, $${base + 8},
                  $${base + 9}, $${base + 10}, $${base + 11}, $${base + 12})`,
      );

      params.push(
        invoice_id,
        product.product_id,
        product.variant_id,
        Number(product.selectedqty),
        Number(product.price),
        Number(product.price) * Number(product.selectedqty),
        0, // item_weight
        product.amount_per_unit || null,
        product.measurement_id || null,
        0, // discount
        product.batch_number,
        product.name || null,
      );
    });

    // 3️⃣ Insert FIFO rows
    const insertQuery = `
            INSERT INTO invoice_details (
                invoice_id,
                product_id,
                variant_id,
                quantity,
                unit_price,
                total_price,
                item_weight,
                amount_per_unit,
                unit_type,
                discount,
                batch_no,
                name
            )
            VALUES ${values.join(",")}
        `;

    const insertResult = await client.query(insertQuery, params);

    if (insertResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: "Invoice items not inserted",
      });
    }

    // 4️⃣ Admin log
    const module = "FIFO Add Product to Invoice";
    const logMessage = `FIFO product added to invoice #${invoice_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "success",
      invoice_id,
      items: products,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
};

const FIFOcreateTemporyInvoice = async (req, res) => {
  const { products } = req.body;
  console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const outlet_id = user.outlet_id;
  const merchant_id = user.merchant_id;

  const { till_id } = req.cookies;

  try {
    if (!products || products.length === 0) {
      return res.status(400).json({ message: "No products provided" });
    }

    const orderQuery = `INSERT INTO invoice_header (user_id, merchant_id, order_status, interface, till_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`;

    const OrderParms = [user_id, merchant_id, "draft", "pos", till_id];

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0)
      return res.status(400).json({ message: "order not created" });

    const invoice_id = orderResult.rows[0].id;

    // 2️⃣ Build bulk insert
    const values = [];
    const params = [];

    products.forEach((product, i) => {
      const base = i * 12;

      values.push(
        `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4},
                  $${base + 5}, $${base + 6}, $${base + 7}, $${base + 8},
                  $${base + 9}, $${base + 10}, $${base + 11}, $${base + 12})`,
      );

      params.push(
        invoice_id,
        product.product_id,
        product.variant_id,
        Number(product.selectedqty),
        Number(product.price),
        Number(product.price) * Number(product.selectedqty),
        0, // item_weight
        product.amount_per_unit || null,
        product.measurement_id || null,
        0, // discount
        product.batch_number,
        product.name || null,
      );
    });

    // 3️⃣ Insert FIFO rows
    const insertQuery = `
            INSERT INTO invoice_details (
                invoice_id,
                product_id,
                variant_id,
                quantity,
                unit_price,
                total_price,
                item_weight,
                amount_per_unit,
                unit_type,
                discount,
                batch_no,
                name
            )
            VALUES ${values.join(",")}
        `;

    const insertResult = await pool.query(insertQuery, params);

    if (insertResult.rowCount === 0) {
      return res.status(400).json({
        message: "Invoice items not inserted",
      });
    }

    const module = "Invoive";
    const logMessage = `New invoice #${invoice_id} has been placed by user ${user_id}`;

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({ message: "success", invoice_id: invoice_id });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const manualaddItemsToInvoice = async (req, res) => {
  const client = await pool.connect();

  try {
    const { products, invoice_id } = req.body;
    console.log("products", products);

    if (!products) {
      return res.status(400).json({ message: "No products provided" });
    }
    // return
    const user = req.user;
    const user_id = user.user_id;

    await client.query("BEGIN");

    // 1️⃣ Remove existing FIFO rows for this variant
    await client.query(
      `DELETE FROM invoice_details
             WHERE invoice_id = $1
               AND product_id = $2
               AND variant_id = $3
               AND batch_no = $4`,
      [
        invoice_id,
        products.product_id,
        products.variant_id,
        products.batch_number,
      ],
    );

    const orderItemParams = [
      invoice_id,
      products.product_id,
      products.variant_id,
      Number(products.selectedqty),
      products.price,
      Number(products.price) * Number(products.selectedqty),
      0,
      products.amount_per_unit || null,
      products.measurement_id || null,
      0,
      products.batch_number,
      products.name || null,
    ];

    //add order items
    const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight,  amount_per_unit, unit_type, discount, batch_no, name) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`;

    const orderItemResult = await pool.query(orderItemQuery, orderItemParams);

    if (orderItemResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Order item not added" });
    }

    // 4️⃣ Admin log
    const module = "Manual Add Product to Invoice";
    const logMessage = `Manual product added to invoice #${invoice_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "success",
      invoice_id,
      items: products,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
};

//get batch details
const getbatchDetails = async (req, res) => {
  const { products, inventory_strategy_id } = req.body;
  // console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const outlet_id = user.outlet_id;
  const variant_id = products.variant_id;

  try {
    if (!variant_id)
      return res.status(400).json({ message: "variant_id is required" });

    const query = `
                    SELECT
                        v.variant_id,
                        v.variant_value,
                        v.weight,
                        v.barcode,
                        v.continue_selling_oos,

                        -- inventory per batch
                        COALESCE(i.new_quantity, 0) AS quantity,

                        -- product details
                        p.product_id,
                        p.title AS name,
                        p.amount_per_unit,
                        p.measurement_id,
                        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
                        m.measurement_value,

                        -- media
                        pm.media_url AS main_img,
                        pmd_first.media_url AS first_extra_img,

                        -- batch (one row per batch)
                        bm.selling_price AS price,
                        bm.batch_number,
                        bm.expiry_date,
                        bm.created_at

                    FROM product_variants v
                    JOIN products p 
                        ON p.product_id = v.product_id

                    JOIN batch_management bm
                        ON bm.variant_id = v.variant_id
                        AND bm.status = 'active'

                    LEFT JOIN LATERAL (
                        SELECT new_quantity
                        FROM inventory
                        WHERE variant_id = bm.variant_id
                            AND batch_number = bm.batch_number AND outlet_id = $2
                        ORDER BY inventory_id DESC
                        LIMIT 1
                    ) i ON true

                    LEFT JOIN product_media pm 
                        ON pm.product_id = p.product_id
                        AND pm.main = true
                        AND pm.variant_id IS NULL

                    LEFT JOIN measurements m 
                        ON p.measurement_id = m.measurement_id

                    LEFT JOIN LATERAL (
                        SELECT media_url
                        FROM product_media
                        WHERE product_id = p.product_id
                            AND main = true
                            AND variant_id IS NOT NULL
                        ORDER BY created_at ASC
                        LIMIT 1
                    ) pmd_first ON true

                    WHERE p.status = 'active' AND v.variant_id = $1
                    ORDER BY
                    v.variant_id,
                    CASE WHEN $3 = 1 THEN bm.created_at END ASC,
                    CASE WHEN $3 = 2 THEN bm.created_at END DESC
                    `;

    const { rows } = await pool.query(query, [
      variant_id,
      outlet_id,
      inventory_strategy_id,
    ]);

    return res.status(200).json({
      message: "success",
      data: rows,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getmanualbatchDetails = async (req, res) => {
  const { products } = req.body;
  // console.log("products", products);
  const user = req.user;
  const user_id = user.user_id;
  const outlet_id = user.outlet_id;
  const variant_id = products.variant_id;

  try {
    if (!variant_id)
      return res.status(400).json({ message: "variant_id is required" });

    const query = `
                    SELECT
                        v.variant_id,
                        v.variant_value,
                        v.weight,
                        v.barcode,
                        v.continue_selling_oos,

                        -- inventory per batch
                        COALESCE(i.new_quantity, 0) AS quantity,

                        -- product details
                        p.product_id,
                        p.title AS name,
                        p.amount_per_unit,
                        p.measurement_id,
                        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
                        m.measurement_value,

                        -- media
                        pm.media_url AS main_img,
                        pmd_first.media_url AS first_extra_img,

                        -- batch (one row per batch)
                        bm.selling_price AS price,
                        bm.batch_number,
                        bm.expiry_date,
                        bm.created_at

                    FROM product_variants v
                    JOIN products p 
                        ON p.product_id = v.product_id

                    JOIN batch_management bm
                        ON bm.variant_id = v.variant_id
                        AND bm.status = 'active'

                    LEFT JOIN LATERAL (
                        SELECT new_quantity
                        FROM inventory
                        WHERE variant_id = bm.variant_id
                            AND batch_number = bm.batch_number AND outlet_id = $2
                        ORDER BY inventory_id DESC
                        LIMIT 1
                    ) i ON true

                    LEFT JOIN product_media pm 
                        ON pm.product_id = p.product_id
                        AND pm.main = true
                        AND pm.variant_id IS NULL

                    LEFT JOIN measurements m 
                        ON p.measurement_id = m.measurement_id

                    LEFT JOIN LATERAL (
                        SELECT media_url
                        FROM product_media
                        WHERE product_id = p.product_id
                            AND main = true
                            AND variant_id IS NOT NULL
                        ORDER BY created_at ASC
                        LIMIT 1
                    ) pmd_first ON true

                    WHERE p.status = 'active' AND v.variant_id = $1
                    ORDER BY
                    v.variant_id, bm.created_at ASC
                    `;

    const { rows } = await pool.query(query, [variant_id, outlet_id]);

    return res.status(200).json({
      message: "success",
      data: rows,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const getDraftInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;
  const outlet_id = user.outlet_id;

  try {
    const query = `SELECT ih.id, ind.product_id, ind.variant_id, ind.quantity as selectedqty, ind.unit_price as price, ind.total_price, ind.item_weight, ind.amount_per_unit, ind.unit_type as measurement_id, ind.discount, p.title as name, m.measurement_value, ind.batch_no as batch_number, pv.variant_value,
        COALESCE(i.new_quantity, 0) AS quantity, pv.continue_selling_oos, ind.invoice_item_uid,
        CASE
        WHEN ind.unit_type::integer = 1
            THEN ind.quantity
        ELSE
            ind.quantity * ind.amount_per_unit
        END AS qty
        FROM invoice_details ind
        INNER JOIN invoice_header ih ON ih.id = ind.invoice_id
        INNER JOIN products p ON p.product_id = ind.product_id
        LEFT JOIN product_variants pv ON pv.variant_id = ind.variant_id
        LEFT JOIN measurements m ON m.measurement_id = ind.unit_type:: integer
        LEFT JOIN LATERAL (
            SELECT new_quantity
            FROM inventory
            WHERE variant_id = ind.variant_id AND outlet_id = $3
            ORDER BY inventory_id DESC
            LIMIT 1
        ) i ON true
        WHERE ih.user_id = $1 AND ih.order_status = $2
        ORDER BY ind.id ASC
        `;

    const invoice_header_query = `SELECT i.id, i.customer_id, c.first_name, c.last_name, c.loyalty_point, i.table_id, rt.table_id as table_name,
    COALESCE(i.payments, '[]'::jsonb) AS payments, COALESCE(i.salespersons, '[]'::jsonb) AS salespersons
        FROM invoice_header i
        LEFT JOIN customer c ON c.customer_id = i.customer_id 
        LEFT JOIN restaurant_tables rt ON rt.id = i.table_id
        WHERE i.user_id = $1 AND i.order_status = $2`;

    const [result, invoice_header_result] = await Promise.all([
      pool.query(query, [user_id, "draft", outlet_id]),
      pool.query(invoice_header_query, [user_id, "draft"]),
    ]);

    if (result.rows.length === 0 && invoice_header_result.rows.length === 0)
      return res.status(400).json({ message: "Invoice not found" });

    const invoice_header = invoice_header_result.rows[0];

    // console.log(invoice_header_result.rows[0].payments);

    return res.status(200).json({
      message: "success",
      result: result.rows,
      invoice_id: invoice_header.id,
      invoice_header: invoice_header,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};
const getHoldInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;
  const outlet_id = user.outlet_id;

  try {
    const query = `SELECT
                        ih.id,
                        ih.order_status AS status,
                        ih.created_at as createdAt,
                        ih.table_id,
                        rt.table_id as table_name,
                        COALESCE(ih.payments, '[]'::jsonb) AS payments,
                        COALESCE(ih.salespersons, '[]'::jsonb) AS salesPersons,
                        CASE 
                            WHEN ih.customer_id IS NULL THEN NULL
                            ELSE json_build_object(
                                'id', ih.customer_id,
                                'first_name', c.first_name,
                                'last_name', c.last_name,
                                'loyalty_point', c.loyalty_point
                            )
                        END AS customer,
                        COALESCE(
                            json_agg(
                            json_build_object(
                                'product_id', ind.product_id,
                                'variant_id', ind.variant_id,
                                'variant_value', pv.variant_value,
                                'continue_selling_oos', pv.continue_selling_oos,
                                'selectedqty', ind.quantity,
                                'quantity', COALESCE(i.new_quantity, 0),
                                'price', ind.unit_price,
                                'total_price', ind.total_price,
                                'item_weight', ind.item_weight,
                                'amount_per_unit', ind.amount_per_unit,
                                'measurement_id', ind.unit_type,
                                'discount', ind.discount,
                                'name', p.title,
                                'measurement_value', m.measurement_value,
                                'batch_number', ind.batch_no,
                                'invoice_item_uid', ind.invoice_item_uid,
                                'qty', CASE
                                            WHEN ind.unit_type::integer = 1
                                            THEN ind.quantity
                                            ELSE
                                            ind.quantity * ind.amount_per_unit
                                        END
                            )
                            ) FILTER (WHERE ind.id IS NOT NULL),
                            '[]'
                        ) AS items
                        FROM invoice_header ih
                        LEFT JOIN invoice_details ind ON ind.invoice_id = ih.id
                        LEFT JOIN restaurant_tables rt ON rt.id = ih.table_id
                        LEFT JOIN products p ON p.product_id = ind.product_id
                        LEFT JOIN product_variants pv ON pv.variant_id = ind.variant_id
                        LEFT JOIN measurements m ON m.measurement_id = ind.unit_type::integer
                        LEFT JOIN customer c ON c.customer_id = ih.customer_id 
                        LEFT JOIN LATERAL (
                            SELECT new_quantity
                            FROM inventory
                            WHERE variant_id = ind.variant_id AND outlet_id = $3
                            ORDER BY inventory_id DESC
                            LIMIT 1
                        ) i ON true
                        WHERE ih.user_id = $1
                        AND ih.order_status = $2
                        GROUP BY ih.id, c.first_name, c.last_name, c.loyalty_point, rt.table_id
                        ORDER BY ih.id DESC;

        `;

    const result = await pool.query(query, [user_id, "hold", outlet_id]);

    if (result.rows.length === 0)
      return res.status(400).json({ message: "Invoice not found" });

    return res.status(200).json({ message: "success", result: result.rows });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const deleteiItemsFromInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { item, id } = req.body;
  // console.log(item, id);

  try {
    const query = `DELETE FROM invoice_details WHERE invoice_id = $1 AND variant_id	= $2 AND product_id = $3 AND (
              batch_no = $4
              OR (batch_no IS NULL AND $4 IS NULL)
            )`;

    const result = await pool.query(query, [
      id,
      item.variant_id,
      item.product_id,
      item.batch_number,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({
        message: "Item not found or already deleted",
      });
    }

    return res.status(200).json({ message: "success" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const updateiItemsFromInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { products, id, selectedqty, count } = req.body;
  // console.log(products, id, selectedqty, count);
  // return
  try {
    const total_price = Number(count) * Number(products.price);
    const query = `UPDATE invoice_details SET quantity = $5, total_price = $6 WHERE invoice_id = $1 AND variant_id	= $2 AND product_id = $3 AND (
              batch_no = $4
              OR (batch_no IS NULL AND $4 IS NULL)
            )`;

    const result = await pool.query(query, [
      id,
      products.variant_id,
      products.product_id,
      products.batch_number,
      count,
      total_price,
    ]);

    if (result.rowCount === 0) {
      return res.status(404).json({
        message: "Item not found or already deleted",
      });
    }

    return res.status(200).json({ message: "success" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const draftToHoldInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { invoice_id } = req.body;
  console.log(invoice_id);
  //
  try {
    const query = `UPDATE invoice_header SET order_status = 'hold' WHERE id = $1`;

    const result = await pool.query(query, [invoice_id]);

    if (result.rowCount === 0) {
      return res.status(404).json({
        message: "Invoice Update failed ",
      });
    }

    return res.status(200).json({ message: "success" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const discardInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { invoice_id } = req.body;
  console.log(invoice_id);

  try {
    const checkQuery = `SELECT order_status FROM invoice_header WHERE id = $1`;

    const { rows } = await pool.query(checkQuery, [invoice_id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: "Invoice not found" });
    }

    if (rows[0].order_status === "completed") {
      return res.status(400).json({ message: "Invoice already completed" });
    }

    const query = `DELETE FROM invoice_details WHERE invoice_id = $1`;

    const result = await pool.query(query, [invoice_id]);

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ message: "Item not found or already deleted" });
    }

    const query2 = `DELETE FROM invoice_header WHERE id = $1`;

    const result2 = await pool.query(query2, [invoice_id]);

    if (result2.rowCount === 0) {
      return res
        .status(404)
        .json({ message: "Item not found or already deleted" });
    }

    const module = "Discard Invoive";
    const logMessage = `invoice #${invoice_id} has been discarded by user ${user_id}`;

    const adminLog = await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({ message: "success" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const holdtoDraftInvoice = async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  const merchant_id = user.merchant_id;

  const { id } = req.body;

  const client = await pool.connect();

  try {
    const query1 = `UPDATE invoice_header SET order_status = 'hold' WHERE order_status = 'draft' AND user_id = $1`;
    const query2 = `UPDATE invoice_header SET order_status = 'draft' WHERE id = $1`;
    await client.query("BEGIN");

    const result1 = await client.query(query1, [user_id]);

    // if (result1.rowCount === 0) {
    //     await client.query('ROLLBACK');
    //     return res.status(404).json({ message: "Item not found or already deleted" });
    // }

    const result2 = await client.query(query2, [id]);

    if (result2.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Invoice Update failed" });
    }

    await client.query("COMMIT");
    return res.status(200).json({ message: "success" });
  } catch (err) {
    await client.query("ROLLBACK");
    console.log(err);
    return res.status(500).json({ message: "Internal server error" });
  } finally {
    client.release();
  }
};

const saveCookistillid = async (req, res) => {
  const { till_id, till_name, os, browser, device_type } = req.body;

  try {
    if (!till_id) {
      return res.status(400).json({ message: "till_id is required" });
    }

    res.cookie("till_id", till_id, {
      httpOnly: false,
      secure: true,
      sameSite: "None",
      maxAge: 1000 * 60 * 60 * 24 * 365 * 2, // 2 years
      path: "/",
    });

    // ✅ Prepare device info
    const deviceInfo = {
      os,
      browser,
      device_type,
    };

    // ✅ Save to DB
    await pool.query(
      `INSERT INTO device_management (device_id, till_name, device_info)
       VALUES ($1, $2, $3)
       ON CONFLICT (device_id)
       DO UPDATE SET 
          device_info = EXCLUDED.device_info,
          till_name = EXCLUDED.till_name`,
      [till_id, till_name, JSON.stringify(deviceInfo)],
    );

    return res.status(200).json({
      success: true,
      message: "till_id cookie saved successfully",
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const releaseTill = async (req, res) => {
  try {
    const till_id = req.cookies.till_id;

    if (!till_id) {
      return res.status(400).json({ message: "No till found in cookie" });
    }

    // ✅ Clear device_info
    await pool.query(
      `UPDATE device_management
       SET device_info = NULL
       WHERE device_id = $1`,
      [till_id]
    );

    // ✅ Clear cookie
    res.clearCookie("till_id", {
      httpOnly: false,
      secure: true,
      sameSite: "None",
      path: "/",
    });

    return res.status(200).json({
      success: true,
      message: "Till released successfully",
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};

const getCookistillid = (req, res) => {
  const { till_id } = req.cookies;
  console.log(till_id);

  try {
    if (!till_id) {
      return res.status(400).json({ message: "till_id is missing" });
    }

    return res.status(200).json({
      message: "till_id cookie saved successfully",
      till_id: till_id,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getsystemSettings,
  getPosSettings,
  updatePosSettings,
  getProductSearch,
  createTemporyInvoice,
  getDraftInvoice,
  getHoldInvoice,
  addItemsToInvoice,
  onebatchaddItemsToInvoice,
  onebatchcreateTemporyInvoice,
  getbatchDetails,
  FIFOaddItemsToInvoice,
  FIFOcreateTemporyInvoice,
  getmanualbatchDetails,
  manualaddItemsToInvoice,
  getHoldInvoice,
  deleteiItemsFromInvoice,
  updateiItemsFromInvoice,
  draftToHoldInvoice,
  discardInvoice,
  holdtoDraftInvoice,
  saveCookistillid,
  releaseTill,
  getCookistillid,
  CreateInvoiceID,
  getsystemSettingsDisplay,
  getwelcome,
};
