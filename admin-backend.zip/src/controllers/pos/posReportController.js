const pool = require("../../config/db");
const { } = require("../../models/commonModels");
const { insertAdminLog } = require("../../models/userLogs");

const getDailyCashierReport = async (req, res) => {
    const user = req.user;
    const user_id = user.user_id;
    const { tillId } = req.params

    try {
        const query = `
            SELECT 
                u.first_name, 
                u.last_name, 
                u.user_id,
                COALESCE(SUM(ih.balance), 0) AS balance, 
                COALESCE(SUM(ih.add_to_points), 0) AS add_to_points,
                DATE(CURRENT_DATE) AS date
            FROM invoice_header ih
            INNER JOIN users u ON u.user_id = ih.user_id
            WHERE ih.user_id = $1 
              AND ih.interface = 'pos' 
              AND ih.created_at >= CURRENT_DATE 
              AND ih.created_at < CURRENT_DATE + INTERVAL '1 day' AND ih.till_id = $2 AND ih.order_status = 'completed'
            GROUP BY u.first_name, u.last_name, u.user_id;
        `;

        const detailsQuery = `
            SELECT 
                p.method_name,
                i.method_id,
                COALESCE(SUM(i.amount), 0) AS amount
            FROM invoice_payment_history i
            INNER JOIN payment_methods p 
                ON p.payment_method_id = i.method_id
            WHERE i.user_id = $1 AND i.status = 'active' 
              AND i.date >= CURRENT_DATE 
              AND i.date < CURRENT_DATE + INTERVAL '1 day' AND i.till_id = $2
            GROUP BY p.method_name, i.method_id;
        `;

        const [result, details] = await Promise.all([
            pool.query(query, [user_id, tillId]),
            pool.query(detailsQuery, [user_id, tillId]),
        ]);

        const row = result.rows[0] || {
            first_name: '',
            last_name: '',
            balance: 0,
            add_to_points: 0,
            date: new Date()
        };

        const data = {
            cashierName: `${row.first_name} ${row.last_name}(${row.user_id})`,
            balance: Number(row.balance),
            add_to_points: Number(row.add_to_points),
            date: new Date(),
            payments: details.rows || []
        };

        res.status(200).json({ success: true, result: data });

    } catch (error) {
        console.error("Error fetching daily cashier report:", error);
        res.status(500).json({ success: false, message: "Failed to fetch report" });
    }
};


const getSalesSummaryReport = async (req, res) => {


    const { tillId, fromDate, toDate, user_id } = req.body

    try {

        let params = [];
        let orderParams = [];

        /* ===============================
           INVOICE TOTAL SUMMARY
        =============================== */

        let invoiceTotalQuery = `
        SELECT 
            COALESCE(SUM(ih.balance), 0) AS balance, 
            COALESCE(SUM(ih.add_to_points), 0) AS add_to_points,
            COALESCE(SUM(ih.loyalty_points_earned), 0) AS loyalty_points_earned,
            COALESCE(SUM(ih.loyalty_points_spent), 0) AS loyalty_points_spent
        FROM invoice_header ih
        WHERE ih.payment_status IN ('paid', 'partially paid')
    `;

        /* ===============================
           INVOICE PAYMENT METHOD SUMMARY
        =============================== */

        let invoiceDetailsQuery = `
        SELECT 
            p.method_name,
            i.method_id,
            COALESCE(SUM(i.amount), 0) AS amount
        FROM invoice_payment_history i
        INNER JOIN payment_methods p 
            ON p.payment_method_id = i.method_id
        WHERE i.status = 'active'
    `;

        /* ===============================
           ORDER PAYMENT METHOD SUMMARY
        =============================== */

        let orderPaymentQuery = `
        SELECT
            p.method_name,
            o.payment_method_id,
            COALESCE(SUM(o.full_amount::numeric), 0) AS order_total
        FROM orders o
        INNER JOIN payment_methods p 
            ON p.payment_method_id = o.payment_method_id
        WHERE o.order_status = 'completed'
    `;

        /* ===============================
           ORDER LOYALTY TOTALS (SEPARATE)
        =============================== */

        let orderLoyaltyQuery = `
        SELECT
            COALESCE(SUM(o.loyalty_points_earned), 0) AS total_loyalty_earned,
            COALESCE(SUM(o.loyalty_points_spent), 0) AS total_loyalty_spent
        FROM orders o
        WHERE o.order_status = 'completed'
    `;

        /* ===============================
           DATE FILTER
        =============================== */

        if (fromDate && toDate) {

            invoiceDetailsQuery += `
            AND i.date >= $${params.length + 1}
            AND i.date < ($${params.length + 2}::date + INTERVAL '1 day')
        `;

            invoiceTotalQuery += `
            AND ih.created_at >= $${params.length + 1}
            AND ih.created_at < ($${params.length + 2}::date + INTERVAL '1 day')
        `;

            orderPaymentQuery += `
            AND o.created_at >= $${orderParams.length + 1}
            AND o.created_at < ($${orderParams.length + 2}::date + INTERVAL '1 day')
        `;

            orderLoyaltyQuery += `
            AND o.created_at >= $${orderParams.length + 1}
            AND o.created_at < ($${orderParams.length + 2}::date + INTERVAL '1 day')
        `;

            params.push(fromDate, toDate);
            orderParams.push(fromDate, toDate);
        }

        if (tillId) {
            invoiceTotalQuery += ` AND ih.till_id = $${params.length + 1}`
            invoiceDetailsQuery += ` AND i.till_id = $${params.length + 1}`
            params.push(tillId)
        }

        invoiceDetailsQuery += ` GROUP BY p.method_name, i.method_id`;
        orderPaymentQuery += ` GROUP BY p.method_name, o.payment_method_id`;

        /* ===============================
           EXECUTE
        =============================== */

        const [
            invoiceTotals,
            invoiceDetails,
            orderPayments,
            orderLoyalty
        ] = await Promise.all([
            pool.query(invoiceTotalQuery, params),
            pool.query(invoiceDetailsQuery, params),
            pool.query(orderPaymentQuery, orderParams),
            pool.query(orderLoyaltyQuery, orderParams)
        ]);

        /* ===============================
           COMBINE RESULTS
        =============================== */

        const response = {
            invoice: {
                totals: invoiceTotals.rows[0],
                payments: invoiceDetails.rows
            },
            orders: {
                payments: orderPayments.rows,
                loyalty: orderLoyalty.rows[0]
            }
        };

        res.status(200).json({ success: true, data: response });

    } catch (error) {
        console.error("Error fetching report:", error);
        res.status(500).json({ success: false, message: "Failed to fetch report" });
    }



    // if (user_id) {
    //     query = ` AND ih.user_id = $${params.length + 1}`
    //     detailsQuery = ` AND i.user_id = $${params.length + 1}`
    //     params.push(user_id)
    // }


};

const getAllTillId = async (req, res) => {
    try {
        const result = await pool.query(`SELECT device_id as value, till_name as label FROM device_management WHERE type = 'till' AND status = 'Active'`);
        const tillIds = result.rows;
        res.json({ success: true, data: tillIds });
    } catch (error) {
        console.error('Error fetching till IDs:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch till IDs' });
    }
};


module.exports = { getDailyCashierReport, getSalesSummaryReport, getAllTillId }