const pool = require("../config/db");
const { insertAdminLog } = require("../models/userLogs");

const authenticateApi = async (clientId, apiKey) => {
    if (!clientId || !apiKey) {
        return {
            success: false,
            status: 401,
            response: {
                ok: false,
                error: {
                    code: "UNAUTHORIZED",
                    message: "Missing client id or API key"
                }
            }
        };
    }

    const query = `
        SELECT client_id
        FROM apidocuments
        WHERE client_id = $1
          AND api_key = $2
          AND is_active = TRUE
        LIMIT 1;
    `;

    const { rowCount } = await pool.query(query, [clientId, apiKey]);

    if (rowCount === 0) {
        return {
            success: false,
            status: 401,
            response: {
                ok: false,
                error: {
                    code: "UNAUTHORIZED",
                    message: "Invalid client id or API key"
                }
            }
        };
    }

    return {
        success: true
    };
};


const getKitchens = async (req, res) => {
    try {
        const clientId = req.headers["x-client-id"];
        const apiKey = req.headers["x-api-key"];

        // Authenticate API request
        const auth = await authenticateApi(clientId, apiKey);

        if (!auth.success) {
            return res.status(auth.status).json(auth.response);
        }

        const query = `
            SELECT
                id AS kitchen_id,
                name,
                kot_printer_id AS printer_id
            FROM kitchen
            WHERE status = 'Active'
            ORDER BY id;
        `;

        const { rows } = await pool.query(query);

        try {
            await insertAdminLog(
                10,
                "KOT Print Agent",
                "Kitchen list fetched successfully."
            );
        } catch (err) {
            console.error("Admin log error:", err.message);
        }

        return res.status(200).json({
            ok: true,
            kitchens: rows
        });

    } catch (err) {
        console.error("getKitchens:", err);

        return res.status(500).json({
            ok: false,
            error: {
                code: "INTERNAL",
                message: "Internal server error"
            }
        });
    }
};

const getPendingKOTs = async (req, res) => {
    try {
        const clientId = req.headers["x-client-id"];
        const apiKey = req.headers["x-api-key"];

        // Authenticate request
        const auth = await authenticateApi(clientId, apiKey);

        if (!auth.success) {
            return res.status(auth.status).json(auth.response);
        }

        // Optional kitchen filter
        let kitchenFilter = "";
        let params = [];

        if (req.query.kitchen_ids) {
            const kitchenIds = req.query.kitchen_ids
                .split(",")
                .map(id => parseInt(id.trim()))
                .filter(id => !isNaN(id));

            if (kitchenIds.length > 0) {
                params.push(kitchenIds);
                kitchenFilter = `AND kol.kitchen_id = ANY($1)`;
            }
        }

        const query = `
            SELECT
                kol.id AS line_id,
                kol.order_line_id AS header_id,
                kol.kitchen_id,
                kol.invoice_id,
                kol.note,
                ih.id AS invoice_no,
                kol.qty,
                kol.is_reprint,
                kol.variant_id,
                pv.variant_value,
                p.title AS product_name,
                k.name AS kitchen_name,
                h.table_id,
                h.sent_at
            FROM kitchen_order_lines kol
            INNER JOIN kitchen_order_lines_header h
                ON h.id = kol.order_line_id
            LEFT JOIN products p
                ON p.product_id = kol.product_id
            LEFT JOIN product_variants pv ON pv.variant_id = kol.variant_id
            LEFT JOIN kitchen k
                ON k.id = kol.kitchen_id
            LEFT JOIN invoice_header ih
                ON ih.id = kol.invoice_id
            WHERE kol.print_status = 'pending'
            ${kitchenFilter}
            ORDER BY kol.order_line_id, kol.kitchen_id, kol.id;
        `;

        const { rows } = await pool.query(query, params);

        // Group by (header_id + kitchen_id)
        const grouped = {};

        rows.forEach(row => {
            const key = `${row.header_id}_${row.kitchen_id}`;

            if (!grouped[key]) {
                grouped[key] = {
                    header_id: `${row.header_id} (INV-${row.invoice_no})`,
                    kitchen_id: row.kitchen_id,
                    kitchen_name: row.kitchen_name,
                    invoice_no: String(row.invoice_no),
                    table: row.table_id,
                    is_reprint: row.is_reprint,
                    sent_at: row.sent_at,
                    line_ids: [],
                    items: []
                };
            }

            grouped[key].line_ids.push(row.line_id);

            grouped[key].items.push({
                line_id: `${row.line_id}`,
                name: `${row.product_name} - ${row.variant_value || ""}${row.note ? ` (${row.note})` : ""}`.trim(),
                variant_id: row.variant_id,
                qty: row.qty,
                note: ""
            });
        });

        const kots = Object.values(grouped);


        return res.status(200).json({
            ok: true,
            kots
        });

    } catch (err) {
        console.error("getPendingKOTs:", err);

        return res.status(500).json({
            ok: false,
            error: {
                code: "INTERNAL",
                message: "Internal server error"
            }
        });
    }
};

const acknowledgeKOT = async (req, res) => {
    try {
        const clientId = req.headers["x-client-id"];
        const apiKey = req.headers["x-api-key"];

        // Authenticate request
        const auth = await authenticateApi(clientId, apiKey);

        if (!auth.success) {
            return res.status(auth.status).json(auth.response);
        }

        const { line_ids, printer_id } = req.body;

        // Validate request body
        if (
            !Array.isArray(line_ids) ||
            line_ids.length === 0 ||
            !printer_id
        ) {
            return res.status(400).json({
                ok: false,
                error: {
                    code: "VALIDATION",
                    message: "line_ids must be a non-empty array and printer_id is required."
                }
            });
        }

        const query = `
            UPDATE kitchen_order_lines
            SET
                print_status = 'printed',
                printer_id = $1
            WHERE id = ANY($2::int[])
              AND print_status = 'pending';
        `;

        const result = await pool.query(query, [printer_id, line_ids]);

        try {
            await insertAdminLog(
                10,
                "KOT Print Agent",
                `Acknowledged ${result.rowCount} KOT line(s). Printer ID: ${printer_id}`
            );
        } catch (err) {
            console.error("Error inserting admin log:", err);
        }

        return res.status(200).json({
            ok: true,
            printed: result.rowCount
        });

    } catch (err) {
        console.error("acknowledgeKOT:", err);

        return res.status(500).json({
            ok: false,
            error: {
                code: "INTERNAL",
                message: "Internal server error"
            }
        });
    }
};


const getApiDocuments = async (req, res) => {
    try {
        const query = `
            SELECT client_id, api_key
            FROM apidocuments
            WHERE id = 1;
        `;

        const { rows } = await pool.query(query);

        return res.status(200).json({
            ok: true,
            documents: rows[0]
        });

    } catch (err) {
        console.error("getApiDocuments:", err);

        return res.status(500).json({
            ok: false,
            error: {
                code: "INTERNAL",
                message: "Internal server error"
            }
        });
    }
};

module.exports = {
    acknowledgeKOT,
    getPendingKOTs,
    getKitchens,
    getApiDocuments
};