const cron = require('node-cron');
const pool = require('../config/db');
const { generatePaysheet } = require('../controllers/ems/emsController');
const { log }            = require('../util/log');
const { sendSlackAlert } = require('../util/alertWebhook');

// ─── Helpers ─────────────────────────────────────────────────────────────────

// Format date → YYYY-MM-DD
const formatDate = (date) => new Date(date).toISOString().split('T')[0];

// Get month & year from a date
const getMonthYear = (date) => {
  const d = new Date(date);
  return {
    month: d.getMonth() + 1,
    year:  d.getFullYear(),
  };
};

// ─── Main exported function (also used by the manual trigger route) ───────────

const runPayrollCron = async () => {
  const results = { processed: [], skipped: [], errors: [] };

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const today    = new Date();
    const todayStr = formatDate(today);

    log.info({ todayStr }, 'AUTO PAYROLL CRON STARTED');

    // ── 1. Get all AUTO employees ────────────────────────────────────────────
    const employees = await client.query(`
      SELECT employee_id,
             salary_start_date,
             net_salary_effective_date
      FROM employees
      WHERE salary_generation_type = 'AUTO'
    `);

    log.info({ count: employees.rows.length }, 'AUTO employees found');

    // ── 2. Loop all employees ────────────────────────────────────────────────
    for (const emp of employees.rows) {
      const { employee_id, salary_start_date, net_salary_effective_date } = emp;

      // ── 3. Decide target date ──────────────────────────────────────────────
        if (!salary_start_date && !net_salary_effective_date) {
          log.warn({ employee_id }, 'Skipping — no salary_start_date or net_salary_effective_date set');
          results.skipped.push({ employee_id, reason: 'no_salary_dates' });
          continue;
        }

        const rawDate    = net_salary_effective_date || salary_start_date;
        const targetDate = new Date(rawDate);

        // Catch null/invalid dates that resolve to 1970
        if (isNaN(targetDate.getTime()) || targetDate.getFullYear() < 2000) {
          log.warn({ employee_id, rawDate }, 'Skipping — invalid or epoch target date');
          results.skipped.push({ employee_id, reason: 'invalid_target_date' });
          continue;
        }

        const targetDateStr = formatDate(targetDate);

      // ── 4. Only run if today matches target date ───────────────────────────
      // (Uncomment the line below when you go live; currently disabled for testing)
      // if (targetDateStr !== todayStr) {
      //   log.info({ employee_id, targetDateStr, todayStr }, 'Skipping — date not matched');
      //   results.skipped.push({ employee_id, reason: 'date_not_matched' });
      //   continue;
      // }

      // ── 4. Only run if today matches OR target date is overdue ─────────────
      if (targetDateStr > todayStr) {
        // Future date — not due yet, skip
        log.info({ employee_id, targetDateStr, todayStr }, 'Skipping — not due yet');
        results.skipped.push({ employee_id, reason: 'not_due_yet' });
        continue;
      }
      // If targetDateStr === todayStr → due today, process ✅
      // If targetDateStr < todayStr  → overdue, process now ✅

      const { month, year } = getMonthYear(targetDate);

      // ── 5. Prevent duplicate payroll ──────────────────────────────────────
      const exists = await client.query(
        `SELECT paysheet_id FROM paysheets
         WHERE employee_id=$1 AND payroll_month=$2 AND payroll_year=$3`,
        [employee_id, month, year]
      );

      if (exists.rows.length > 0) {
        log.warn({ employee_id, month, year }, 'Paysheet already exists — skipping');
        results.skipped.push({ employee_id, reason: 'already_exists' });
        continue;
      }

      // ── 5b. Pre-flight: verify payroll template exists ─────────────────────
      const templateCheck = await client.query(
        `SELECT pt.id 
        FROM employees e
        LEFT JOIN payroll_templates pt ON e.payroll_template_id = pt.id
        WHERE e.employee_id = $1`,
        [employee_id]
      );

      if (!templateCheck.rows[0]?.id) {
        log.warn({ employee_id }, 'Skipping — no valid payroll template assigned');
        results.skipped.push({ employee_id, reason: 'no_payroll_template' });
        continue; // skip cleanly instead of erroring
      }

      // ── 6. Calculate salary range (full month based on target date) ────────
      const startDate = new Date(targetDate);
      const endDate   = new Date(targetDate);
      endDate.setMonth(endDate.getMonth() + 1);
      endDate.setDate(endDate.getDate() - 1);

      // ── 7. Generate paysheet ───────────────────────────────────────────────
      try {
        // Build a mock res object so generatePaysheet never hits null.status()
        let paysheetResult = null;
        const mockRes = {
          status: (code) => ({
            json: (data) => {
              paysheetResult = { code, data };
              return paysheetResult;
            },
          }),
        };

        await generatePaysheet(
          {
            body: {
              employee_id,
              payroll_month:      month,
              payroll_year:       year,
              salary_range_start: startDate,
              salary_range_end:   endDate,
              generation_type:    'AUTO',
            },
            user: { user_id: 1 },
          },
          mockRes  // ← pass mock res so res.status() never throws
        );

        // If the mock res captured a 4xx/5xx, treat it as an error
        if (paysheetResult?.code >= 400) {
          throw new Error(paysheetResult?.data?.message ?? 'Paysheet generation returned error');
        }

        log.info({ employee_id, month, year }, 'Paysheet generated successfully');
        results.processed.push({ employee_id, month, year });

      } catch (err) {
        log.error({ err, employee_id }, 'Failed to generate paysheet for employee');
        results.errors.push({ employee_id, error: err.message });
        continue; // skip date update for this employee, move to next
      }

      // ── 8. Update next effective date (next month, same day) ──────────────
      const nextDate = new Date(targetDate);
      nextDate.setMonth(nextDate.getMonth() + 1);

      await client.query(
        `UPDATE employees
         SET net_salary_effective_date=$1
         WHERE employee_id=$2`,
        [nextDate, employee_id]
      );

      log.info({ employee_id, nextDate: formatDate(nextDate) }, 'Next salary date updated');
    }

    await client.query('COMMIT');

    log.info(
      {
        processed: results.processed.length,
        skipped:   results.skipped.length,
        errors:    results.errors.length,
      },
      'AUTO PAYROLL CRON COMPLETED'
    );

    // ── Alert if any individual paysheets failed (but cron itself succeeded) ─
    if (results.errors.length > 0) {
      await sendSlackAlert({
        title:   'Payroll Cron — Partial Failures ⚠️',
        message: `${results.errors.length} employee(s) failed during AUTO payroll generation.`,
        level:   'warn',
        details: {
          failed_employees: results.errors.map(e => e.employee_id).join(', '),
          processed:        results.processed.length,
          skipped:          results.skipped.length,
          errors:           results.errors.length,
          date:             formatDate(new Date()),
        },
      });
    }

    return results;

  } catch (error) {
    // ── Full cron crash → rollback + Slack alert ───────────────────────────
    await client.query('ROLLBACK');

    log.error({ err: error }, 'AUTO PAYROLL CRON FAILED — transaction rolled back');

    await sendSlackAlert({
      title:   'Payroll Cron FAILED 💸',
      message: error.message,
      level:   'error',
      details: {
        stack:     error.stack?.split('\n')[1] ?? '',
        processed: results.processed.length,
        errors:    results.errors.length,
        failedAt:  new Date().toISOString(),
      },
    });

    throw error; // re-throw so the scheduler sees the failure

  } finally {
    client.release();
  }
};

// // // ─── Cron schedule (runs every minute for testing; change to '10 0 * * *' for production) ───
// cron.schedule('* * * * *', async () => {
//   try {
//     await runPayrollCron();
//   } catch (err) {
//     // Error already logged and alerted inside runPayrollCron.
//     // Catching here prevents the cron scheduler from crashing.
//     log.error({ err }, 'Cron schedule caught re-thrown error — scheduler kept alive');
//   }
// });

// // ─── Cron schedule (runs at 12:10 AM daily) ──────────────────────────────────
cron.schedule('10 0 * * *', async () => {
  try {
    await runPayrollCron();
  } catch (err) {
    // Error already logged and alerted inside runPayrollCron.
    // Catching here prevents the cron scheduler from crashing.
    log.error({ err }, 'Cron schedule caught re-thrown error — scheduler kept alive');
  }
}, {
  timezone: 'Asia/Colombo'  // ← set your server timezone explicitly
});


module.exports = { runPayrollCron };