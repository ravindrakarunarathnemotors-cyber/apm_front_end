const cron = require('node-cron');
const pool = require('../config/db');
const { generatePaysheet } = require('../controllers/ems/emsController');

const fmt = (d) => d.toISOString().split('T')[0];

// ── Helper: get the target run date for an employee ───────────────────────────
// Priority 1: net_salary_effective_date (set manually in Settings tab)
// Priority 2: salary_start_date (set during onboarding)
// Priority 3: salary_start_day of current month (fallback)
const getTargetDate = (emp, today) => {
  if (emp.net_salary_effective_date) {
    return new Date(emp.net_salary_effective_date);
  }

  if (emp.salary_start_date) {
    return new Date(emp.salary_start_date);
  }

  // Fallback: use salary_start_day of current month
  const day = emp.salary_start_day ?? 1;
  const target = new Date(today.getFullYear(), today.getMonth(), day);
  return target;
};

// ── Helper: advance date by exactly 1 month (same day) ───────────────────────
const nextMonthSameDay = (date) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + 1);
  return d;
};

// ── MAIN CRON — runs at 12:10 AM daily ───────────────────────────────────────
cron.schedule('10 0 * * *', () => runPayrollCron());

// Exported so the test endpoint can call it directly
const runPayrollCron = async () => {
  console.log('🕛 AUTO PAYROLL CRON STARTED:', new Date().toISOString());
  const client = await pool.connect();

  const results = {
    processed: [],
    skipped: [],
    errors: [],
  };

  try {
    await client.query('BEGIN');

    const today = new Date();
    const todayStr = fmt(today);

    // Fetch only AUTO employees with MONTHLY templates
   const { rows: employees } = await client.query(`
  SELECT
    e.employee_id,
    e.salary_start_day,
    e.salary_start_date,
    e.net_salary_effective_date,
    e.salary_generation_type,
    pt.payroll_type,
    pt.id AS payroll_template_id
  FROM employees e
  LEFT JOIN payroll_templates pt ON e.payroll_template_id = pt.id
  WHERE e.salary_generation_type = 'AUTO'
    AND UPPER(COALESCE(NULLIF(pt.payroll_type::text, ''), 'NONE')) = 'MONTHLY'
`);

    console.log(`👥 Found ${employees.length} AUTO MONTHLY employees`);

    for (const emp of employees) {
      const { employee_id } = emp;

      try {
        const targetDate = getTargetDate(emp, today);
        const targetStr  = fmt(targetDate);

        // Only run today's employees
        if (targetStr !== todayStr) {
          results.skipped.push({
            employee_id,
            reason: `target date ${targetStr} ≠ today ${todayStr}`,
          });
          continue;
        }

        const month = targetDate.getMonth() + 1;
        const year  = targetDate.getFullYear();

        // Prevent duplicate paysheets
        const { rows: existing } = await client.query(
          `SELECT paysheet_id FROM paysheets
           WHERE employee_id = $1 AND payroll_month = $2 AND payroll_year = $3`,
          [employee_id, month, year]
        );

        if (existing.length > 0) {
          results.skipped.push({
            employee_id,
            reason: `paysheet already exists for ${month}/${year}`,
          });
          continue;
        }

        // Full month date range
        const startDate = fmt(new Date(year, month - 1, 1));
        const endDate   = fmt(new Date(year, month, 0));  // last day of month

        // Generate — passes generation_type: 'AUTO' to bypass the manual guard
        const result = await generatePaysheet({
          body: {
            employee_id,
            payroll_month:      month,
            payroll_year:       year,
            salary_range_start: startDate,
            salary_range_end:   endDate,
            generation_type:    'AUTO',
          }
        }, null);

        if (result?.error) {
          results.errors.push({ employee_id, error: result.message });
          continue;
        }

        // Advance net_salary_effective_date to next month
        const nextDate = fmt(nextMonthSameDay(targetDate));

        await client.query(
          `UPDATE employees
           SET net_salary_effective_date = $1
           WHERE employee_id = $2`,
          [nextDate, employee_id]
        );

        results.processed.push({
          employee_id,
          paysheet_id: result.paysheet_id,
          month,
          year,
          next_run: nextDate,
        });

        console.log(`✅ Generated → Emp ${employee_id} | ${month}/${year} | Next: ${nextDate}`);

      } catch (empError) {
        console.error(`❌ Error for Emp ${employee_id}:`, empError.message);
        results.errors.push({ employee_id, error: empError.message });
      }
    }

    await client.query('COMMIT');
    console.log('✅ CRON COMPLETED:', JSON.stringify(results, null, 2));
    return results;

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ CRON FAILED (top-level):', error);
    throw error;
  } finally {
    client.release();
  }
};

module.exports = { runPayrollCron };