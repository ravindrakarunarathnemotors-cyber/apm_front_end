const cron = require("node-cron");
const pool = require("../config/db");

// Runs every hour at minute 0
cron.schedule(
  "* * * * *",
  async () => {
    const startTime = Date.now();

    try {
      console.log("[OTP CLEANUP] Cron started...");

      const query = `
        UPDATE users
        SET otp = NULL,
            otp_expires_at = NULL
        WHERE otp_expires_at IS NOT NULL
          AND otp_expires_at < NOW()
      `;

      const result = await pool.query(query);

      const duration = Date.now() - startTime;

      console.log(
        `[OTP CLEANUP] Completed successfully | Cleared: ${result.rowCount} OTP(s) | Duration: ${duration}ms`,
      );
    } catch (error) {
      console.error("[OTP CLEANUP] Failed:", {
        message: error.message,
        stack: error.stack,
      });
    }
  },
  {
    timezone: "UTC", //keeps cron consistent across servers
  },
);
