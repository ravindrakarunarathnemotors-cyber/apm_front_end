const pool = require("../config/db");

const LIMIT_CONFIG = {
    users: {
        limitColumn: "users_limit",
        table: "users",
    },
    products: {
        limitColumn: "products_limit",
        table: "products",
    },
    till: {
        limitColumn: "tills_limit",
        table: "device_management",
    },
    outlets: {
        limitColumn: "outlets_limit",
        table: "outlets",
    },
};

const checkLimit = async (moduleName) => {
    const config = LIMIT_CONFIG[moduleName];

    if (!config) {
        return { exceeded: false };
    }

    const settingsResult = await pool.query(
        `SELECT ${config.limitColumn} AS limit_value
     FROM system_settings
     LIMIT 1`
    );

    
    const limit = Number(settingsResult.rows[0]?.limit_value || 0);
    console.log(limit)

    // 0 = unlimited
    if (limit === 0) {
        return {
            exceeded: false,
            currentCount: null,
            limit: 0,
        };
    }

    let countResult;
    if (config.table === 'device_management') {
        countResult = await pool.query(
            `SELECT COUNT(*) AS total FROM ${config.table} WHERE type = 'till'`
        );

    } else {
        countResult = await pool.query(
            `SELECT COUNT(*) AS total FROM ${config.table}`
        );
    }

    const currentCount = Number(countResult.rows[0].total);

    return {
        exceeded: currentCount >= limit,
        currentCount,
        limit,
    };
};

module.exports = checkLimit;