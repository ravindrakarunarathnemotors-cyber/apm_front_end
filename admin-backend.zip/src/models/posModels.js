const pool = require("../config/db");

const getvariantwithBatchno = async (id, outlet_id) => {
    const query = `SELECT
                        v.variant_id,
                        v.variant_value,
                        v.weight,
                        v.barcode,

                        -- inventory
                        COALESCE(i.new_quantity, 0) AS quantity,

                        -- product details embedded per variant
                        p.product_id,
                        p.title AS name,
                        p.amount_per_unit,
                        p.measurement_id,
                        CASE WHEN p.measurement_id = 1 THEN false ELSE true END AS measurement_needed,
                        m.measurement_value,

                        -- media
                        pm.media_url AS main_img,
                        pmd_first.media_url AS first_extra_img,

                        -- batch
                        bc.selling_price as price,
                        bc.batch_number,
                        bc.expiry_date
                        FROM product_variants v
                        JOIN products p 
                        ON p.product_id = v.product_id
                        LEFT JOIN product_media pm 
                        ON pm.product_id = p.product_id 
                        AND pm.main = true 
                        AND pm.variant_id IS NULL
                        LEFT JOIN measurements m 
                        ON p.measurement_id = m.measurement_id
                        LEFT JOIN LATERAL (
                            SELECT media_url
                            FROM product_media
                            WHERE product_id = p.product_id
                            AND main = true 
                            AND variant_id IS NOT NULL
                            ORDER BY created_at ASC
                            LIMIT 1
                        ) pmd_first ON true
                        LEFT JOIN LATERAL (
                        SELECT selling_price, batch_number, expiry_date	
                        FROM batch_management bm
                        WHERE bm.variant_id = v.variant_id AND bm.status = 'active'
                        LIMIT 1
                        ) bc ON true
                        LEFT JOIN LATERAL (
                        SELECT new_quantity
                        FROM inventory
                        WHERE variant_id = v.variant_id
                        AND batch_number = bc.batch_number AND outlet_id = $2
                        ORDER BY inventory_id DESC
                        LIMIT 1
                        ) i ON true
                        WHERE p.status = 'active'
                        AND v.variant_id = $1
                        ORDER BY v.variant_id
                        LIMIT 1;
                    `

    const result = await pool.query(query, [Number(id), outlet_id])

    if (result.rows.length === 0) throw new Error("User not found");
    return result.rows[0];
}

module.exports = {getvariantwithBatchno}