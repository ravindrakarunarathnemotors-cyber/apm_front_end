const pool = require("../config/db");
const axios = require("axios");

const formatPhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]+$/; // Ensure only numbers are allowed
  if (!phoneRegex.test(phone)) {
    return { error: "Invalid phone number. Only digits are allowed." };
  }
  if (phone.startsWith("07") && phone.length === 10) {
    return { formatted: "94" + phone.substring(1) }; // Convert 07xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("+94") && phone.length === 12) {
    return { formatted: phone.substring(1) }; // Remove "+" to make it 94xxxxxxxxxx
  } else if (phone.startsWith("7") && phone.length === 9) {
    return { formatted: "94" + phone }; // Convert 7xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("94") && phone.length === 11) {
    return { formatted: phone }; // Keep as is
  }
  return { error: "Invalid phone number format." };
};
const transexpress = async (client, order_id, user_id, delivery_partner_id) => {
  try {
    console.log("🚀 Transexpress START");
    console.log("order_id:", order_id);
    console.log("user_id:", user_id);
    console.log("delivery_partner_id:", delivery_partner_id);

    const BASE_URL = "https://portal.transexpress.lk/api";

    const partnerRes = await client.query(
      `SELECT email, password 
       FROM delivery_partners 
       WHERE partner_id = $1`,
      [delivery_partner_id]
    );

    if (partnerRes.rowCount === 0) {
      throw new Error("Delivery partner not found");
    }

    const { email, password } = partnerRes.rows[0];

    if (!email || !password) {
      throw new Error("Missing email or password for delivery partner");
    }

    console.log("🔑 Using credentials:", email);


    const loginRes = await axios.post(
      `${BASE_URL}/login/client`,
      {
        email,
        password,
      },
      {
        headers: {
          Accept: "application/json",
        },
      }
    );

    console.log("🔐 Login Response:", loginRes.data);

    const token = loginRes.data?.token;

    if (!token) {
      throw new Error("Failed to get Transexpress token");
    }


    const infoRes = await client.query(
      `SELECT 
        recipient_name,
        recipient_contact,
        recipient_address,
        recipient_city,
        payment_status,
        payment_method_id,
        total_weight::numeric AS parcel_weight,
        order_note,
        full_amount
       FROM orders 
       WHERE order_id = $1`,
      [order_id]
    );

    if (infoRes.rowCount === 0) {
      throw new Error("Order not found");
    }

    const info = infoRes.rows[0];

    console.log("📦 Order Info:", info);


    const phone = formatPhoneNumber(info.recipient_contact);

    if (phone.error) {
      throw new Error(phone.error);
    }


    const payload = {
      order_no: order_id,
      customer_name: info.recipient_name || "",
      address: info.recipient_address || "",
      description: info.order_note || "General item",
      phone_no: phone.formatted,
      phone_no2: "",
      cod:
        info.payment_method_id === 3 && info.payment_status === "unpaid"
          ? Number(info.full_amount) || 0
          : 0,
      city: info.recipient_city || "",
      note: "Order from system",
    };

    console.log("📤 Order Payload:", payload);

    // =========================================
    // 5️⃣ CREATE ORDER API CALL
    // =========================================
    const orderRes = await axios.post(
      `${BASE_URL}/orders/upload/single-auto-without-city`,
      payload,
      {
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log("📥 Order API Response:", orderRes.data);

    const waybill = orderRes.data?.orders?.waybill_id || null;
    return {
      success: true,
      waybill: waybill,
      data: orderRes.data,
    };

  } catch (error) {
    console.error("❌ Transexpress ERROR:", error.response?.data || error.message);

    return {
      success: false,
      error: error.response?.data || error.message,
    };
  }
};

const citypak = async (client, order_id, delivery_partner_id) => {

  try {
    console.log("🚀 Citypak START");
    console.log("🚀 Transexpress START");
    console.log("order_id:", order_id);

    console.log("delivery_partner_id:", delivery_partner_id);

    const BASE_URL = "https://falcon.citypak.lk/customer_api/v1";

    // 1️⃣ Get API key from DB
    const partnerRes = await client.query(
      `SELECT api_key 
       FROM delivery_partners 
       WHERE partner_id = $1`,
      [delivery_partner_id]
    );

    if (partnerRes.rowCount === 0) {
      throw new Error("Citypak partner not found");
    }

    const { api_key } = partnerRes.rows[0];

    if (!api_key) {
      throw new Error("Missing API key for Citypak");
    }

    console.log("🔑 Using API KEY:", api_key);


    const infoRes = await client.query(
      `SELECT 
        recipient_name,
        recipient_contact,
        recipient_address,
        recipient_city,
        payment_status,
        payment_method_id,
        total_weight::numeric AS parcel_weight,
        order_note,
        full_amount
       FROM orders 
       WHERE order_id = $1`,
      [order_id]
    );

    if (infoRes.rowCount === 0) {
      throw new Error("Order not found");
    }

    const info = infoRes.rows[0];

    // 3️⃣ Format phone
    const phone = formatPhoneNumber(info.recipient_contact);
    if (phone.error) {
      throw new Error(phone.error);
    }

    // 4️⃣ Prepare payload
    const payload = {
      token: api_key,
      reference: String(order_id),

      from_name: "Your Company",
      from_address_line_1: "Colombo",
      from_address_line_4: "Colombo",
      from_contact_name: "Sender",
      from_contact_1: "94771234567",

      to_name: info.recipient_name || "",
      to_address_line_1: info.recipient_address || "",
      to_address_line_4: info.recipient_city || "",
      to_contact_name: info.recipient_name || "",
      to_contact_1: phone.formatted,

      description: info.order_note || "General item",
      weight_g: Math.max(
        1,
        Math.min(Number(info.parcel_weight || 500), 100000)
      ),

      cash_on_delivery_amount:
        info.payment_method_id === 3 && info.payment_status === "unpaid"
          ? Number(info.full_amount).toFixed(2) || 0
          : 0,

      number_of_pieces: 1,
    };

    console.log("📤 Citypak Payload:", payload);

    // 5️⃣ API CALL
    const res = await axios.post(`${BASE_URL}/orders`, payload, {
      headers: {
        "Content-Type": "application/json",
      },
    });

    console.log("📥 Citypak Response:", res.data);

    // if (!res.data.success) {
    //   throw new Error(res.data.message);
    // }
    if (!res.data.success) {

      let errorMessage = res.data.message || "Citypak API Error";

      // If validation errors exist
      if (
        Array.isArray(res.data.data) &&
        res.data.data.length > 0
      ) {
        errorMessage = res.data.data.join(", ");
      }

      throw new Error(errorMessage);
    }

    const tracking =
      res.data?.data?.items?.[0]?.tracking_number || null;

    return {
      success: true,
      waybill: tracking,
      data: res.data,
    };

  } catch (error) {
    console.error("❌ Citypak ERROR:", error.response?.data || error.message);

    return {
      success: false,
      error: error.response?.data || error.message,
    };
  }
};

module.exports = { transexpress, citypak };