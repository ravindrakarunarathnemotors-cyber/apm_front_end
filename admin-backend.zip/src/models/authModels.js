const pool = require("../config/db");

const getUserByEmail = async (email) => {
  const result = await pool.query("SELECT * FROM users WHERE username = $1 AND status = 'Active'", [email]);
  return result.rows[0];
};

const checkPrivilegesForRole = async (role_id) => {
  try {
 
    const result = await pool.query("SELECT privileges FROM role_list WHERE id = $1", [role_id]);
    
    if (result.rows.length === 0) {
      return { error: "Role not found" };
    }

    
    const privileges = result.rows[0].privileges;
    
  
    const hasPrivilege1 = privileges.includes("1");
    const hasPrivilege2 = privileges.includes("2");

  
    if (hasPrivilege1 && hasPrivilege2) {
      return { privileges: 'Both' };
    } else if (hasPrivilege1) {
      return { privileges: 'one' };
    } else if (hasPrivilege2) {
      return { privileges: 'two' };
    } else {
      return { privileges: 'No relevant privileges' };
    }
  } catch (err) {
    console.error("Error checking privileges:", err);
    return { error: "Error checking privileges" };
  }
};

const formatPhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]+$/; // Ensure only numbers are allowed

  if (!phoneRegex.test(phone)) {
    return { error: "Invalid phone number. Only digits are allowed." };
  }

  if (phone.startsWith("07") && phone.length === 10) {
    return { formatted: "94" + phone.substring(1) }; // Convert 07xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("+94") && phone.length === 12) {
    return { formatted: phone.substring(1) }; // Remove "+" to make it 94xxxxxxxxxx
  } else if (phone.startsWith("7") && phone.length === 9) {
    return { formatted: "94" + phone }; // Convert 7xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("94") && phone.length === 11) {
    return { formatted: phone }; // Keep as is
  }

  return { error: "Invalid phone number format." };
};

const formatEmail = (email) => { 
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { error: "Invalid email format." };
  }
  return { formatted: email }; 
};

module.exports = { getUserByEmail ,formatPhoneNumber,checkPrivilegesForRole,formatEmail};
