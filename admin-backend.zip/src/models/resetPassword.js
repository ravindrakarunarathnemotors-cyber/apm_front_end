const https = require("https");
const pool = require("../config/db");
const axios = require("axios");

const insertemaillog = async (email, msg, subject, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_email_temp_log (email, msg, status, date, sentdate, action,subject) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3, $4) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [email, msg, action, subject]);

        return result.rows[0]; 
    } catch (error) {
        console.error("❌ Error inserting email log:", error);
        throw error;
    }
};

async function sendEmailWithPostmark(to, subject, message, apiToken, fromEmail) {

    if (!apiToken) {
        console.error("Error: Postmark API token is missing.");
        return "Postmark API token is not configured.";
    }

    const postData = {
        "From": fromEmail,
        "To": to,
        "Subject": subject,
        "HtmlBody": message,
        "MessageStream": "outbound"
    };

    try {
        const response = await axios.post("https://api.postmarkapp.com/email", postData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        });

        console.log("Email sent successfully:", response.data);
        return response.data; 
    } catch (error) {
        console.error("Error sending email:", error.response ? error.response.data : error.message);
        return `Error sending email: ${error.response ? JSON.stringify(error.response.data) : error.message}`;
    }
}


// async function getEmailMsg(username, message) {
//     try {


//         // Fetch branding details
//         const brandingQuery = await pool.query(
//             "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
//         );

//         const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

//         return `
//         <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
//             <!-- Header Section -->
//             <div style="text-align: center; padding: 20px 0;">
//                 <img src="${branding.logo_url}" 
//                      alt="Logo" 
//                      style="max-width: 150px; margin-bottom: 10px;">
//                 <h2 style="color: #1a4e8a; margin: 0;">Order Notification</h2>
//             </div>

//            <!-- Main Content -->
//                 <div style="
//                 background: #ffffff; 
//                 padding: 20px; 
//                 border-radius: 8px;  
//                 box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
//                 font-size: 16px; 
//                 color: #333; 
//                 text-align: center;
//                 ">
//                 <style>
//                     ul, ol {
//                     text-align: left !important; /* Lists keep their default alignment */
//                     display: inline-block; /* Shrink-wrap the list to keep it centered as a block */
//                     margin-left: 0;
//                     padding-left: 20px; /* show bullets/numbers properly */
//                     text-indent: 0;
//                         text-align: center;

//                     }
//                 </style>
//                 ${message}
//                 </div>


//             <!-- Contact Info -->
//             <div style="margin-top: 20px; text-align: center;">
//                 <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>

//                 <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
//                     Hotline: ${branding.hotline || "[Your Hotline Number]"}
//                 </p>

//                 <p style="font-size: 16px;">
//                     Website: 
//                     <a href="${branding.website_url}" style="color:#1a4e8a; text-decoration: none;">
//                         ${branding.website_url}
//                     </a>
//                 </p>
//             </div>

//             <!-- Footer -->
//             <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
//                 <p>Thank you for choosing <strong>${branding.company_name}</strong>. We look forward to a great partnership!</p>
//                 <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
//             </div>
//         </div>
//         `;

//     } catch (error) {
//         console.error("Error generating email message:", error.message);
//         return null;
//     }
// }


async function getEmailMsg(username, otpNumber) {
    try {
        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #DCE6F1; border-radius: 8px; background-color: #F4F8FC;">
            <!-- Header Section -->
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url}" alt="Logo" style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1A4E8A; margin: 0;">Password Reset Verification</h2>
            </div>
            <!-- Main Content -->
            <div style="
                background: #FFFFFF;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                font-size: 16px;
                color: #333;
                text-align: center;
            ">
                <p style="margin-bottom: 10px;">Hello ${username},</p>
                <p style="margin-bottom: 20px;">
                    We received a request to reset your password. Use the following One-Time Password (OTP) to proceed:
                </p>
                <p style="
                    font-size: 24px;
                    font-weight: bold;
                    letter-spacing: 4px;
                    color: #1A4E8A;
                    background: #E6F0FB;
                    padding: 12px 24px;
                    display: inline-block;
                    border-radius: 6px;
                ">
                    ${otpNumber}
                </p>
                <p style="margin-top: 20px; color: #555;">
                    This OTP is valid for the next <strong>5 minutes</strong>.
                    If you did not request a password reset, please ignore this email.
                </p>
            </div>
            <!-- Contact Info -->
            <div style="margin-top: 20px; text-align: center;">
                <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>
                <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #E6F0FB; padding: 10px; display: inline-block; border-radius: 6px;">
                    Hotline: ${branding.hotline || "[Your Hotline Number]"}
                </p>
                
            </div>
            <!-- Footer -->
            <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                <p>Thank you for choosing <strong>${branding.company_name}</strong>.</p>
                <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
            </div>
        </div>
        `;
    } catch (error) {
        console.error("Error generating email message:", error.message);
        return null;
    }
}


const getemailsettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                billing_email,
                postmark_server_token
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No email settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; 
    } catch (error) {
        console.error(" Error fetching email settings:", error);
        throw error;
    }
};


const sendemailtemp = async (user_id,otp,subject) => {
    try {
          console.log("🔹 sendemailtemp called with:", { user_id, otp, subject });

        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        
        // const smsResult = await pool.query(
        //     "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
        //     [actionId]
        // );

        // if (smsResult.rows.length === 0) return null;
        // const template = smsResult.rows[0];

         const userResult = await pool.query(
            `SELECT 
                user_id,
                first_name,
                last_name,
                email,
                mobile,
                role_id,
                status
             FROM users
             WHERE user_id = $1
             LIMIT 1`,
            [user_id]
        );

        if (userResult.rows.length === 0) return null;
        const user = userResult.rows[0];

        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] ?? {};

        // 4. Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 5. Placeholder replacement
        const placeholders = {
            "[first_name]": user.first_name,
            "[last_name]": user.last_name,
            "[full_name]": `${user.first_name} ${user.last_name}`,
            "[otp]": otp,
            "[email]": user.email,
            "[mobile]": user.mobile,
            "[user_id]": user.user_id,
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email
        };

        let finalMessage = `[otp]`;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 6. Generate HTML email body
        const emailHTML = await getEmailMsg(`${user.first_name} ${user.last_name}`, finalMessage);

         if (billing_email && postmark_token) {
            await sendEmailWithPostmark(
                user.email,
                subject,
                emailHTML,
                postmark_token,
                billing_email
            );

            await insertemaillog(user.email, finalMessage, subject, "password_reset");
        }

        // 7. Admin Emails
        // if (template.admin === 'Yes' && billing_email && postmark_token) {
        //     const adminSettings = await pool.query(
        //         "SELECT notification_emails FROM system_settings LIMIT 1"
        //     );

        //     let rawEmails = adminSettings.rows[0]?.notification_emails;
        //     let adminEmails = [];

        //     if (typeof rawEmails === 'string') {
        //         adminEmails = rawEmails.split(',').map(e => e.trim());
        //     } else if (Array.isArray(rawEmails)) {
        //         adminEmails = rawEmails.map(e => e.trim());
        //     } else {
        //         console.warn("⚠️ notification_emails is not a string or array:", rawEmails);
        //     }

        //     for (const email of adminEmails) {
        //         try {
        //             const emailResponse = await sendEmailWithPostmark(
        //                 email,
        //                 template.subject,
        //                 emailHTML,
        //                 postmark_token,
        //                 billing_email
        //             );
        //             console.log(`✅ Email sent to admin: ${email}`, emailResponse);
        //             await insertemaillog(email, finalMessage, template.subject, actionId);

        //         } catch (err) {
        //             console.error(`❌ Failed to send email to admin: ${email}`, err);
        //         }
        //     }
        // }

        // 8. Client Email
        // if (template.client === 'Yes' && billing_email && postmark_token) {
        //     try {
        //         const clientEmailResponse = await sendEmailWithPostmark(
        //             user.email,
        //             template.subject,
        //             emailHTML,
        //             postmark_token,
        //             billing_email
        //         );
        //         console.log(`✅ Email sent to client: ${user.email}`, clientEmailResponse);
        //         await insertemaillog(user.email, finalMessage, template.subject, actionId);

        //     } catch (err) {
        //         console.error(`❌ Failed to send email to client: ${user.email}`, err);
        //     }
        // }

        // 9. Final return
        return {
            message: finalMessage,
           // sendToAdmin: template.admin === 'Yes',
           // sendToClient: template.client === 'Yes',
            userDetails: user,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp:", error);
        return null;
    }
};



module.exports = { sendemailtemp };