const pool = require("../config/db");

/**
 * Insert a new notification into the notifications table
 * @param {number} user_id - The target user's ID
 * @param {string} module - The module name (e.g., "Order Management")
 * @param {string} event_type - The event type (e.g., "New Order Placed")
 * @param {string} channel - Notification channel (Email, SMS, Website Notification)
 * @param {string} message_template - The message content/template
 * @param {string} [status='Pending'] - Notification status
 */
const insertNotification = async (user_id, module, event_type, message_template, channel, status = 'Unread') => {
  try {
    const query = `
      INSERT INTO notifications (user_id, module, event_type, channel, message_template, status, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())`;

    await pool.query(query, [user_id, module, event_type, channel, message_template, status]);

    console.log(`Notification Added: [${module}] ${event_type} -> ${status}`);
  } catch (error) {
    console.error("Error inserting notification:", error);
  }
};



// sample usage in routes


// const { insertNotification } = require("../../models/notifications");

// // Example: after creating an order
// const parsed_session_user_id = parseInt(session_user_id, 10);
// if (!parsed_session_user_id) {
//   throw new Error("Session user ID is missing or invalid. Cannot insert notification.");
// }

// await insertNotification(
//   parsed_session_user_id,          // user_id
//   'Order Management',              // module
//   'New Order Placed',              // event_type
//   'Email',                         // channel
//   `New order #${order_id} has been placed by ${customer_name}.`, // message_template
//   'Read/Unread'                        // status (optional)
// );










module.exports = { insertNotification };
