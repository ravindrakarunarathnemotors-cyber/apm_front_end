const pool = require("../config/db");


const getCategoryIds = async (pid) => {
  try {
    const findCategoryQuery = `SELECT category_id FROM product_category WHERE product_id = $1`;
    const result = await pool.query(findCategoryQuery, [pid]);
    if (result.rows.length === 0) {
      return [];
    }

    const id = result.rows[0].category_id;
    const allCategoryIds = [id]; // start with the given category
    const query = `SELECT category_under FROM categories WHERE category_id = $1`;

    // Step 1: get immediate parent
    const parentResult = await pool.query(query, [id]);
    if (!parentResult.rows.length || !parentResult.rows[0].category_under) {
      return allCategoryIds;
    }

    const parentId = parentResult.rows[0].category_under;
    allCategoryIds.push(parentId);

    // Step 2: get parent of parent (grandparent)
    const grandParentResult = await pool.query(query, [parentId]);
    if (!grandParentResult.rows.length || !grandParentResult.rows[0].category_under) {
      return allCategoryIds;
    }

    const grandParentId = grandParentResult.rows[0].category_under;
    allCategoryIds.push(grandParentId);

    // Step 3: (optional) stop here since you said 3 levels max
    return allCategoryIds;
  } catch (err) {
    console.error("Error fetching category hierarchy:", err);
    throw new Error("Failed to fetch category hierarchy");
  }
};

const collectionIDS = async (id) => {
  try {
    const query = `SELECT collection_id FROM product_collections WHERE product_id = $1`;
    const result = await pool.query(query, [id]);
    const collectionIds = result.rows.map((row) => row.collection_id);
    return collectionIds;
  } catch (err) {
    console.error("Error fetching collection IDs:", err);
    throw new Error("Failed to fetch collection IDs");
  }
};

const productBrandIds = async (id) => {
  try {
    const query = `SELECT brand_id FROM product_brands WHERE product_id = $1`;
    const result = await pool.query(query, [id]);
    const collectionIds = result.rows.map((row) => row.brand_id);
    return collectionIds;
  } catch (err) {
    console.error("Error fetching collection IDs:", err);
    throw new Error("Failed to fetch collection IDs");
  }
};



module.exports = { getCategoryIds, collectionIDS, productBrandIds };