const pool = require("../config/db");
const bcrypt = require("bcrypt");

class User {
  static async login(email, password) {
    try {
      const userQuery = `
        SELECT 
          u.user_id,
          u.username,
          u.email,
          rl.id AS role_id,
          u.password,
          u.merchant_id,
          u.outlet_id,
          u.status
        FROM users u
        LEFT JOIN role_list rl ON rl.id = u.role_id   
        WHERE u.username = $1
        LIMIT 1;
      `;

      const { rows } = await pool.query(userQuery, [email]);

      if (rows.length === 0) {
        return { error: "No user found with this username" };
      }

      const user = rows[0];
      console.log("[User.login] role_id from role_list:", user.role_id);

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) return { error: "Incorrect password" };

      delete user.password;
      return user;
    } catch (error) {
      throw new Error("Login failed: " + error.message);
    }
  }

  static async getPortalInterfacesByRole(role_id) {
    try {
      const query = `
        SELECT
          rl.portal_interface AS portal_interface_id,
          COALESCE(
            json_agg(to_jsonb(pi)),
            '[]'
          ) AS portal_interfaces
        FROM role_list rl
        LEFT JOIN portal_interface pi
          ON pi.interface_id = rl.portal_interface
        WHERE rl.id = $1
        GROUP BY rl.portal_interface
      `;

      const { rows } = await pool.query(query, [role_id]);

      return (
        rows[0] || {
          portal_interface_id: null,
          portal_interfaces: [],
        }
      );
    } catch (error) {
      throw new Error("Failed to fetch portal interfaces: " + error.message);
    }
  }
}

module.exports = User;
