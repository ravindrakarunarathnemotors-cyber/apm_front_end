const https = require("https");
const pool = require("../config/db");
const axios = require("axios");


function send_sms(client_id, api_key, sender_id, message, recipient_contact_no, sms_api_endpoint) {
    return new Promise((resolve, reject) => {
        // Extract hostname from API endpoint
        const url = new URL(sms_api_endpoint);
        const hostname = url.hostname;
        const path = `/v1/send/?user_id=${encodeURIComponent(client_id)}&api_key=${encodeURIComponent(api_key)}&sender_id=${encodeURIComponent(sender_id)}&message=${encodeURIComponent(message)}&recipient_contact_no=${encodeURIComponent(recipient_contact_no)}`;

        const options = {
            method: "GET",
            hostname: hostname,
            path: path,
            headers: {},
            maxRedirects: 20
        };

        const req = https.request(options, (res) => {
            let chunks = [];

            res.on("data", (chunk) => {
                chunks.push(chunk);
            });

            res.on("end", () => {
                const body = Buffer.concat(chunks).toString();
                try {
                    resolve(JSON.parse(body));
                } catch (error) {
                    resolve(body);
                }
            });

            res.on("error", (error) => {
                console.error("SMS API Error:", error);
                reject(error);
            });
        });

        req.end();
    });
}


const getsmssettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                sms_gateway_name,
                sms_user_id,
                sms_sender_id,
                sms_api_endpoint,
                sms_api_key
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No SMS settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching SMS settings:", error);
        throw error;
    }
};


const insertsmslog = async (mobileno, msg, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_sms_temp_log (mobileno, msg, status, date, sentdate, action) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [mobileno, msg, action]);

        return result.rows[0]; // Return inserted row with ID
    } catch (error) {
        console.error("❌ Error inserting SMS log:", error);
        throw error;
    }
};

// ----- Leave SMS Notifications -----
const sendsmstemp_leave = async (actionId, leave_id, employee_mobile) => {
    try {

        // 1️⃣ Check if SMS notifications are enabled globally
        const globalStatusResult = await pool.query(
            "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
        );

        const globalStatus = globalStatusResult.rows[0];

        if (globalStatus?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

          // 2️⃣ Fetch SMS template for this action
        const smsTemplateResult = await pool.query(
            "SELECT msg, admin, employee FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!smsTemplateResult.rows.length) {
            console.log("No active SMS template found for this action.");
            return null;
        }

        const template = smsTemplateResult.rows[0];


        // 3️⃣ Fetch leave + employee details
        const leaveResult = await pool.query(
            `SELECT 
                l.*, 
                e.first_name,
                e.last_name,
                e.contact_no,
                e.email,
                lt.name AS leave_type
            FROM leaves l
            LEFT JOIN employees e ON l.employee_id = e.employee_id
            LEFT JOIN leave_types lt ON l.leave_type_id = lt.leave_type_id
            WHERE l.leave_id = $1`,
            [leave_id]
        );

        if (!leaveResult.rows.length) {
            console.log("No leave record found:", leave_id);
            return null;
        }

        const leave = leaveResult.rows[0];


        // 4️⃣ Fetch branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};

        const branding = {
            company_name: brandingRow.company_name || '',
            hotline: brandingRow.hotline || '',
            support_email: brandingRow.support_email || ''
        };


        // 5️⃣ Fetch SMS API settings
        const settings = await getsmssettings();

        const sms_user_id = settings?.sms_user_id || '';
        const sms_api_key = settings?.sms_api_key || '';
        const sms_sender_id = settings?.sms_sender_id || '';
        const sms_api_endpoint = settings?.sms_api_endpoint || '';


        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": leave.first_name || '',
            "[name]": leave.first_name || '',
            "[leave_type]": leave.leave_type || '',
            "[from_date]": leave.from_date || '',
            "[to_date]": leave.to_date || '',
            "[phone]": leave.contact_no || '',
            "[email]": leave.email || '',
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value.toString());
        }


        // 7️⃣ Send SMS to admin if configured
        if (template.admin === 'Yes') {

            const rawPhones = String(globalStatus.notification_mobile_numbers || '');
            const adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);

            for (const phone of adminPhones) {

                try {

                    if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );

                        console.log(`SMS sent to admin: ${phone}`, smsResponse);

                        await insertsmslog(phone, finalMessage, actionId);
                    } else {
                        console.warn("Missing SMS API settings.");
                    }
                } catch (err) {
                    console.error("Failed to send admin SMS:", err);
                }

            }

        }


        // 8️⃣ Send SMS to employee if configured
        if (template.employee === 'Yes') {
            try {
                if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        employee_mobile,
                        sms_api_endpoint
                    );

                    console.log(`SMS sent to employee: ${employee_mobile}`, smsResponse);

                    await insertsmslog(employee_mobile, finalMessage, actionId);

                } else {
                    console.warn("Missing SMS API settings.");
                }

            } catch (err) {
                console.error("Failed to send employee SMS:", err);
            }

        }


        // 9️⃣ Return response
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToEmployee: template.employee === 'Yes',
            leaveDetails: leave,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_leave:", error);
        return null;
    }
};


// ----- Shift Roster SMS -----
const sendsmstemp_shiftroster = async (actionId, roster_id, employee_mobile) => {
    try {

        // 1️⃣ Check if SMS notifications are enabled globally
        const globalStatusResult = await pool.query(
            "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
        );

        const globalStatus = globalStatusResult.rows[0];

        if (globalStatus?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }


        // 2️⃣ Fetch SMS template for this action
        const smsTemplateResult = await pool.query(
            "SELECT msg, admin, employee FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!smsTemplateResult.rows.length) {
            console.log("No active SMS template found for this action.");
            return null;
        }

        const template = smsTemplateResult.rows[0];


        // 3️⃣ Fetch shift roster details
        const rosterResult = await pool.query(
            `SELECT 
                r.*,
                e.first_name,
                e.last_name,
                e.contact_no,
                s.shift_name,
                s.shift_in_time,
                s.shift_out_time
            FROM shift_roster r
            LEFT JOIN employees e ON r.employee_id = e.employee_id
            LEFT JOIN shifts s ON r.shift_id = r.shift_id
            WHERE r.roster_id = $1`,
            [roster_id]
        );

        if (!rosterResult.rows.length) {
            console.log("No shift roster found for this ID:", roster_id);
            return null;
        }

        const roster = rosterResult.rows[0];


        // 4️⃣ Fetch branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};

        const branding = {
            company_name: brandingRow.company_name || '',
            hotline: brandingRow.hotline || '',
            support_email: brandingRow.support_email || ''
        };


        // 5️⃣ Fetch SMS API settings
        const settings = await getsmssettings();

        const sms_user_id = settings?.sms_user_id || '';
        const sms_api_key = settings?.sms_api_key || '';
        const sms_sender_id = settings?.sms_sender_id || '';
        const sms_api_endpoint = settings?.sms_api_endpoint || '';


        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": roster.first_name || '',
            "[name]": roster.first_name || '',
            "[shift_name]": roster.shift_name || '',
            "[shift_date]": roster.roster_date || '',
            "[shift_start]": roster.shift_in_time || '',
            "[shift_end]": roster.shift_out_time || '',
            "[phone]": roster.contact_no || '',
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value.toString());
        }

        // 7️⃣ Send SMS to admin if configured
        if (template.admin === 'Yes') {

            const rawPhones = String(globalStatus.notification_mobile_numbers || '');
            const adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);

            for (const phone of adminPhones) {

                try {

                    if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );

                        console.log(`SMS sent to admin: ${phone}`, smsResponse);

                        await insertsmslog(phone, finalMessage, actionId);

                    } else {
                        console.warn("Missing SMS API settings. Cannot send admin SMS.");
                    }

                } catch (err) {
                    console.error("Failed to send admin SMS:", err);
                }

            }

        }

        // 8️⃣ Send SMS to employee if configured
        if (template.employee === 'Yes') {

            try {

                if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        employee_mobile,
                        sms_api_endpoint
                    );

                    console.log(`SMS sent to employee: ${employee_mobile}`, smsResponse);

                    await insertsmslog(employee_mobile, finalMessage, actionId);

                } else {
                    console.warn("Missing SMS API settings. Cannot send employee SMS.");
                }

            } catch (err) {
                console.error("Failed to send employee SMS:", err);
            }

        }

        // 9️⃣ Return final info
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToEmployee: template.employee === 'Yes',
            shiftRosterDetails: roster,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_shiftroster:", error);
        return null;
    }
};


// ----- Employee Onboarding SMS 

const sendsmstemp_employeeonboard = async (actionId, employee_id, employee_mobile) => {
    try {

        // 1️⃣ Check if SMS notifications are enabled globally
        const globalStatusResult = await pool.query(
            "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
        );

        const globalStatus = globalStatusResult.rows[0];

        if (globalStatus?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

        // 2️⃣ Fetch SMS template for this action
        const smsTemplateResult = await pool.query(
            "SELECT msg, admin, employee FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!smsTemplateResult.rows.length) {
            console.log("No active SMS template found for this action.");
            return null;
        }

        const template = smsTemplateResult.rows[0];

        // 3️⃣ Fetch employee details
        const employeeResult = await pool.query(
            `SELECT 
                employee_id,
                first_name,
                last_name,
                contact_no,
                email,
                joined_date
            FROM employees
            WHERE employee_id = $1`,
            [employee_id]
        );

        if (!employeeResult.rows.length) {
            console.log("No employee found for this ID:", employee_id);
            return null;
        }

        const employee = employeeResult.rows[0];

        // 4️⃣ Fetch branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};

        const branding = {
            company_name: brandingRow.company_name || '',
            hotline: brandingRow.hotline || '',
            support_email: brandingRow.support_email || ''
        };

        // 5️⃣ Fetch SMS API settings
        const settings = await getsmssettings();

        const sms_user_id = settings?.sms_user_id || '';
        const sms_api_key = settings?.sms_api_key || '';
        const sms_sender_id = settings?.sms_sender_id || '';
        const sms_api_endpoint = settings?.sms_api_endpoint || '';

        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": employee.first_name || '',
            "[name]": employee.first_name || '',
            "[phone]": employee.contact_no || '',
            "[email]": employee.email || '',
            "[join_date]": employee.joined_date || '',
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value.toString());
        }

        // 7️⃣ Send SMS to admin if configured
        if (template.admin === 'Yes') {

            const rawPhones = String(globalStatus.notification_mobile_numbers || '');
            const adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);
            for (const phone of adminPhones) {
                try {
                    if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );
                        console.log(`SMS sent to admin: ${phone}`, smsResponse);

                        await insertsmslog(phone, finalMessage, actionId);
                    } else {
                        console.warn("Missing SMS API settings. Cannot send admin SMS.");
                    }

                } catch (err) {
                    console.error("Failed to send admin SMS:", err);
                }
            }
        }

        // 8️⃣ Send SMS to employee if configured
        if (template.employee === 'Yes') {

            try {

                if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        employee_mobile,
                        sms_api_endpoint
                    );

                    console.log(`SMS sent to employee: ${employee_mobile}`, smsResponse);

                    await insertsmslog(employee_mobile, finalMessage, actionId);

                } else {
                    console.warn("Missing SMS API settings. Cannot send employee SMS.");
                }

            } catch (err) {
                console.error("Failed to send employee SMS:", err);
            }

        }

        // 9️⃣ Return final info
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToEmployee: template.employee === 'Yes',
            employeeDetails: employee,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_employeeonboard:", error);
        return null;
    }
};

//paysheet SMS

const sendsmstemp_paysheet = async (actionId, paysheet_id, employee_mobile, payslip_url_override = '') => {
  try {

    // 1️⃣ Check if SMS notifications are enabled globally
    const globalStatusResult = await pool.query(
      "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
    );
    const globalStatus = globalStatusResult.rows[0];

    if (globalStatus?.sms_notification_status !== 'enabled') {
      console.log("SMS notifications are disabled.");
      return null;
    }

    // 2️⃣ Fetch SMS template for this action
    const smsTemplateResult = await pool.query(
      "SELECT msg, admin, employee FROM sms_template WHERE action = $1 AND status = 'Active'",
      [actionId]
    );

    if (!smsTemplateResult.rows.length) {
      console.log("No active SMS template found for this action.");
      return null;
    }

    const template = smsTemplateResult.rows[0];

    // 3️⃣ Fetch paysheet + employee details
    const paysheetResult = await pool.query(
      `SELECT 
          p.paysheet_id,
          p.net_salary,
          p.salary_range_start,
          p.salary_range_end,
          e.first_name,
          e.last_name,
          e.contact_no,
          e.email
       FROM paysheets p
       LEFT JOIN employees e ON p.employee_id = e.employee_id
       WHERE p.paysheet_id = $1`,
      [paysheet_id]
    );

    if (!paysheetResult.rows.length) {
      console.log("No paysheet found for this ID:", paysheet_id);
      return null;
    }

    const paysheet = paysheetResult.rows[0];

    const paysheet_link = payslip_url_override || '';
    console.log("SMS paysheet_link:", paysheet_link);

    // 5️⃣ Fetch branding info
    const brandingResult = await pool.query(
      "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
    );

    const brandingRow = brandingResult.rows[0] || {};
    const branding = {
      company_name: brandingRow.company_name || '',
      hotline: brandingRow.hotline || '',
      support_email: brandingRow.support_email || ''
    };

    // 6️⃣ Fetch SMS API settings
    const settings = await getsmssettings();
    const sms_user_id = settings?.sms_user_id || '';
    const sms_api_key = settings?.sms_api_key || '';
    const sms_sender_id = settings?.sms_sender_id || '';
    const sms_api_endpoint = settings?.sms_api_endpoint || '';

    // 7️⃣ Replace placeholders
    const placeholders = {
      "[first_name]": paysheet.first_name || '',
      "[name]": `${paysheet.first_name} ${paysheet.last_name}` || '',
      "[phone]": paysheet.contact_no || '',
      "[email]": paysheet.email || '',
      "[Paysheet_Link]": paysheet_link || '',  // ← use the variable fetched above
      "[net_salary]": paysheet.net_salary || '',
      "[salary_start]": paysheet.salary_range_start || '',
      "[salary_end]": paysheet.salary_range_end || '',
      "[Hotline]": branding.hotline,
      "[Webname]": branding.company_name,
      "[company_email]": branding.support_email
    };

    let finalMessage = template.msg;

    for (const [key, value] of Object.entries(placeholders)) {
      finalMessage = finalMessage.replaceAll(key, value.toString());
    }

    // 8️⃣ Send SMS to Admin
    if (template.admin === 'Yes') {

      const rawPhones = String(globalStatus.notification_mobile_numbers || '');
      const adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);

      for (const phone of adminPhones) {
        try {

          if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

            const smsResponse = await send_sms(
              sms_user_id,
              sms_api_key,
              sms_sender_id,
              finalMessage,
              phone,
              sms_api_endpoint
            );

            console.log(`SMS sent to admin: ${phone}`, smsResponse);

            await insertsmslog(phone, finalMessage, actionId);

          } else {
            console.warn("Missing SMS API settings. Cannot send admin SMS.");
          }

        } catch (err) {
          console.error("Failed to send admin SMS:", err);
        }
      }
    }

    // 9️⃣ Send SMS to Employee
    if (template.employee === 'Yes') {

      try {

        if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {

          const smsResponse = await send_sms(
            sms_user_id,
            sms_api_key,
            sms_sender_id,
            finalMessage,
            employee_mobile,
            sms_api_endpoint
          );

          console.log(`SMS sent to employee: ${employee_mobile}`, smsResponse);

          await insertsmslog(employee_mobile, finalMessage, actionId);

        } else {
          console.warn("Missing SMS API settings. Cannot send employee SMS.");
        }

      } catch (err) {
        console.error("Failed to send employee SMS:", err);
      }
    }

    // 🔟 Return final info
    return {
      message: finalMessage,
      sendToAdmin: template.admin === 'Yes',
      sendToEmployee: template.employee === 'Yes',
      paysheetDetails: paysheet,
      branding
    };

  } catch (error) {
    console.error("Error in sendsmstemp_paysheet:", error);
    return null;
  }
};

// ----- Employee Account Invitation SMS -----
const sendsmstemp_invitation = async (firstName, contactNo, password, username) => {
    try {
        const globalStatusResult = await pool.query(
            "SELECT sms_notification_status FROM system_settings LIMIT 1"
        );
        const globalStatus = globalStatusResult.rows[0];

        if (globalStatus?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

        const settings = await getsmssettings();
        const sms_user_id    = settings?.sms_user_id    || '';
        const sms_api_key    = settings?.sms_api_key    || '';
        const sms_sender_id  = settings?.sms_sender_id  || '';
        const sms_api_endpoint = settings?.sms_api_endpoint || '';

        if (!sms_user_id || !sms_api_key || !sms_sender_id || !sms_api_endpoint) {
            console.warn("Missing SMS API settings. Cannot send invitation SMS.");
            return null;
        }

        const brandingResult = await pool.query(
            "SELECT company_name FROM branding_settings LIMIT 1"
        );
        const companyName = brandingResult.rows[0]?.company_name || 'EMS';

        const message = `Welcome to ${companyName}, ${firstName}! Your login credentials: Username: ${username} | Password: ${password} Please log in and change your password immediately.`;

        const smsResponse = await send_sms(
            sms_user_id,
            sms_api_key,
            sms_sender_id,
            message,
            contactNo,
            sms_api_endpoint
        );

        console.log(`Invitation SMS sent to: ${contactNo}`, smsResponse);
        await insertsmslog(contactNo, message, 'INVITATION');

        return { message, smsResponse };

    } catch (error) {
        console.error("Error in sendsmstemp_invitation:", error);
        return null;
    }
};


const sendemailtemp_shiftroster = async (actionId, roster_id) => {
    try {

        // 1️⃣ Check global email notification status
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2️⃣ Get active email template
        const emailResult = await pool.query(
            "SELECT msg, admin, employee, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (emailResult.rows.length === 0) return null;
        const template = emailResult.rows[0];

        // 3️⃣ Get shift roster + employee + shift details
        const rosterResult = await pool.query(
            `SELECT 
                sr.roster_id,
                sr.roster_date,
                e.employee_id,
                e.first_name,
                e.last_name,
                e.contact_no,
                e.email,
                s.shift_name,
                s.shift_in_time,
                s.shift_out_time
            FROM shift_roster sr
            LEFT JOIN employees e ON sr.employee_id = e.employee_id
            LEFT JOIN shifts s ON sr.shift_id = s.id
            WHERE sr.roster_id = $1`,
            [roster_id]
        );

        if (rosterResult.rows.length === 0) return null;

        const roster = rosterResult.rows[0];

        // 4️⃣ Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 5️⃣ Get email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Placeholder replacements
        const placeholders = {
            "[first_name]": roster.first_name,
            "[name]": `${roster.first_name} ${roster.last_name}`,
            "[phone]": roster.contact_no,
            "[email]": roster.email,

            "[Shift_Name]": roster.shift_name,
            "[Shift_In]": roster.shift_in_time,
            "[Shift_Out]": roster.shift_out_time,
            "[Roster_Date]": roster.roster_date,

            "[Hotline]": branding.hotline ?? "",
            "[Webname]": branding.company_name ?? "",
            "[company_email]": branding.support_email ?? ""
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7️⃣ Generate HTML email body
        const emailHTML = await getEmailMsg(roster.first_name, finalMessage);

        // 8️⃣ Send Admin Email
        if (template.admin === 'Yes' && billing_email && postmark_token) {

            const adminQuery = await pool.query(
                "SELECT notification_emails FROM system_settings LIMIT 1"
            );

            let rawEmails = adminQuery.rows[0]?.notification_emails ?? [];
            let adminEmails = [];

            if (typeof rawEmails === "string") {
                adminEmails = rawEmails.split(",").map(e => e.trim());
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            }

            for (const email of adminEmails) {
                try {

                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );

                    console.log(`✔ Admin email sent: ${email}`);

                    await insertemaillog(email, finalMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed admin email: ${email}`, err);
                }
            }
        }

        // 9️⃣ Send Employee Email
        if (template.employee === 'Yes' && billing_email && postmark_token) {
            try {

                const response = await sendEmailWithPostmark(
                    roster.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                console.log(`✔ Employee email sent: ${roster.email}`);

                await insertemaillog(roster.email, finalMessage, template.subject, actionId);

            } catch (err) {
                console.error(`❌ Failed employee email: ${roster.email}`, err);
            }
        }

        // 🔟 Return response
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToEmployee: template.employee === 'Yes',
            rosterDetails: roster,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp_shiftroster:", error);
        return null;
    }
};

//********************************************************************************************************************************************************************** */

async function sendEmailWithPostmark(to, subject, message, apiToken, fromEmail) {

    if (!apiToken) {
        console.error("Error: Postmark API token is missing.");
        return "Postmark API token is not configured.";
    }

    const postData = {
        "From": fromEmail,
        "To": to,
        "Subject": subject,
        "HtmlBody": message,
        "MessageStream": "outbound" // Default message stream for transactional emails
    };

    try {
        const response = await axios.post("https://api.postmarkapp.com/email", postData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        });

        console.log("Email sent successfully:", response.data);
        return response.data; // Return full Postmark response
    } catch (error) {
        console.error("Error sending email:", error.response ? error.response.data : error.message);
        return `Error sending email: ${error.response ? JSON.stringify(error.response.data) : error.message}`;
    }
}

async function getEmailMsgPaysheet(employeeName, message, paysheetLink) {
    try {
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        // message already has [Paysheet_Button] replaced — just use it directly
        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url || ''}" 
                     alt="Logo" 
                     style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1a4e8a; margin: 0;">Paysheet Notification</h2>
            </div>

            <div style="background:#ffffff; padding:20px; border-radius:8px; 
                        box-shadow:0px 4px 12px rgba(0,64,128,0.05); font-size:16px; color:#333;">
                <p>Dear <strong>${employeeName}</strong>,</p>
                ${message}
            </div>

            <div style="text-align:center; font-size:12px; color:#777; margin-top:30px;">
                <p>Thank you for being part of <strong>${branding.company_name || ""}</strong>.</p>
                <p>For any queries, contact us at 
                   <a href="mailto:${branding.support_email || '#'}">${branding.support_email || ""}</a> 
                   or call ${branding.hotline || ""}.
                </p>
            </div>
        </div>
        `;
    } catch (error) {
        console.error("Error generating paysheet email message:", error.message);
        return null;
    }
}


async function getEmailMsg(username, message) {
    try {
        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
            <!-- Header Section -->
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url}" 
                     alt="Logo" 
                     style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1a4e8a; margin: 0;">Order Notification</h2>
            </div>

           <!-- Main Content -->
                <div style="
                background: #ffffff; 
                padding: 20px; 
                border-radius: 8px;  
                box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                font-size: 16px; 
                color: #333; 
                text-align: center;
                ">
                <style>
                    ul, ol {
                    text-align: left !important; /* Lists keep their default alignment */
                    display: inline-block; /* Shrink-wrap the list to keep it centered as a block */
                    margin-left: 0;
                    padding-left: 20px; /* show bullets/numbers properly */
                    text-indent: 0;
                        text-align: center;

                    }
                </style>
                ${message}
                </div>


            <!-- Contact Info -->
            <div style="margin-top: 20px; text-align: center;">
                <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>

                <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
                    Hotline: ${branding.hotline || "[Your Hotline Number]"}
                </p>

                <p style="font-size: 16px;">
                    Website: 
                    <a href="${branding.website_url}" style="color:#1a4e8a; text-decoration: none;">
                        ${branding.website_url}
                    </a>
                </p>
            </div>

            <!-- Footer -->
            <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                <p>Thank you for choosing <strong>${branding.company_name}</strong>. We look forward to a great partnership!</p>
                <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
            </div>
        </div>
        `;

    } catch (error) {
        console.error("Error generating email message:", error.message);
        return null;
    }
}

const getemailsettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                billing_email,
                postmark_server_token
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No email settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching email settings:", error);
        throw error;
    }
};


//leave email notification
const sendemailtemp_leave = async (actionId, leave_id, employee_email) => {
    try {
        // 1️⃣ Check global email notification status
        const globalstatusResult = await pool.query(
            "SELECT email_notification_status, notification_emails FROM system_settings LIMIT 1"
        );
        const globalstatus = globalstatusResult.rows[0];
        console.log("Global status for email notifications:", globalstatus);
        if (!globalstatus) {
            console.warn("System settings not found");
            return null;
        }
        if (globalstatus.email_notification_status !== 'enabled') return null;

        // 2️⃣ Get email template for the action
        const templateResult = await pool.query(
            "SELECT msg, admin, employee, subject FROM email_template WHERE action = $1 AND status='Active'",
            [actionId]
        );
        if (!templateResult.rows || !templateResult.rows.length) {
            console.warn("Email template not found for actionId:", actionId);
            return null;
        }
        const template = templateResult.rows[0];
        console.log("Email template fetched:", template);

        // 3️⃣ Get leave and employee details
        const leaveResult = await pool.query(
            `SELECT l.*, e.first_name AS emp_first_name, e.last_name AS emp_last_name, 
                    e.contact_no AS phone, e.email AS emp_email
             FROM leaves l
             LEFT JOIN employees e ON l.employee_id = e.employee_id
             WHERE l.leave_id = $1`,
            [leave_id]
        );

        if (!leaveResult.rows || !leaveResult.rows.length) {
            console.warn("Leave not found with leave_id:", leave_id);
            return null;
        }
        const leave = leaveResult.rows[0];
        console.log("Leave details fetched:", leave);

        // 4️⃣ Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] || {};
        console.log("Branding info fetched:", branding);

        // 5️⃣ Email server settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Prepare placeholders
        const placeholders = {
            "[first_name]": leave.emp_first_name || '',
            "[name]": `${leave.emp_first_name || ''} ${leave.emp_last_name || ''}`,
            "[phone]": leave.phone || '',
            "[email]": leave.emp_email || '',
            "[Leave_Type]": leave.leave_type || '',
            "[Leave_Status]": leave.status || '',
            "[Hotline]": branding.hotline || '',
            "[Webname]": branding.company_name || '',
            "[company_email]": branding.support_email || ''
        };

        // 7️⃣ Replace placeholders in template
        let finalMessage = template.msg || '';
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.split(key).join(value);
        }

        const emailHTML = await getEmailMsg(leave.emp_first_name, finalMessage);

        // 8️⃣ Send emails to admins if configured
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            let adminEmails = [];
            const rawEmails = globalstatus.notification_emails;
            if (typeof rawEmails === 'string') adminEmails = rawEmails.split(',').map(e => e.trim());
            else if (Array.isArray(rawEmails)) adminEmails = rawEmails.map(e => e.trim());

            for (const email of adminEmails) {
                await sendEmailWithPostmark(email, template.subject, emailHTML, postmark_token, billing_email);
                await insertemaillog(email, finalMessage, template.subject, actionId);
            }
        }

        // 9️⃣ Send email to employee if configured
        if (template.employee === 'Yes' && billing_email && postmark_token && employee_email) {
            await sendEmailWithPostmark(employee_email, template.subject, emailHTML, postmark_token, billing_email);
            await insertemaillog(employee_email, finalMessage, template.subject, actionId);
        }

        return { message: finalMessage, leaveDetails: leave, branding };

    } catch (error) {
        console.error("Error in sendemailtemp_leave:", error);
        return null;
    }
};


const insertemaillog = async (email, msg, subject, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_email_temp_log (email, msg, status, date, sentdate, action,subject) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3, $4) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [email, msg, action, subject]);

        return result.rows[0]; // Return inserted row with ID
    } catch (error) {
        console.error("❌ Error inserting email log:", error);
        throw error;
    }
};


// ----- Paysheet Email -----
const sendemailtemp_paysheet = async (actionId, paysheet_id, employee_email, payslip_url_override = '') => {
    try {

        // 1️⃣ Check global email notification status
        const globalstatus = await pool.query(
            "SELECT email_notification_status, notification_emails FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2️⃣ Get active email template
        const templateResult = await pool.query(
            "SELECT msg, admin, employee, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (templateResult.rows.length === 0) return null;

        const template = templateResult.rows[0];

        // 3️⃣ Fetch paysheet + employee details
        const paysheetResult = await pool.query(
            `SELECT 
                p.*,
                e.first_name,
                e.last_name,
                e.contact_no,
                e.email
             FROM paysheets p
             LEFT JOIN employees e 
             ON p.employee_id = e.employee_id
             WHERE p.paysheet_id = $1`,
            [paysheet_id]
        );

        if (paysheetResult.rows.length === 0) return null;

        const paysheet = paysheetResult.rows[0];

        const paysheet_link = payslip_url_override || '';
        console.log("Email paysheet_link:", paysheet_link);

        // 4️⃣ Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 5️⃣ Email settings
        const settings = await getemailsettings();

        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Replace placeholders
        // In sendemailtemp_paysheet, replace the entire placeholders object with this:
const placeholders = {
    "[first_name]":      paysheet.first_name || "",
    "[name]":            `${paysheet.first_name} ${paysheet.last_name}` || "",
    "[phone]":           paysheet.contact_no || "",
    "[email]":           paysheet.email || "",
    "[Paysheet_Link]":   paysheet_link || "",

    // ← FIXED: ternary now correctly placed after the key
    "[Paysheet_Button]": paysheet_link
        ? `<div style="margin:20px 0;text-align:center;">
               <a href="${paysheet_link}" 
                  style="display:inline-block;padding:12px 28px;font-size:15px;
                         color:#ffffff;background-color:#1a4e8a;text-decoration:none;
                         border-radius:6px;font-weight:600;">
                 &#128196; View &amp; Download Payslip
               </a>
             </div>`
        : '',

    "[net_salary]":     paysheet.net_salary
                          ? Number(paysheet.net_salary).toLocaleString('en-LK', { minimumFractionDigits: 2 })
                          : "",
    "[salary_start]":   paysheet.salary_range_start
                          ? String(paysheet.salary_range_start).split('T')[0]
                          : "",
    "[salary_end]":     paysheet.salary_range_end
                          ? String(paysheet.salary_range_end).split('T')[0]
                          : "",

    "[Hotline]":        branding.hotline || "",
    "[Webname]":        branding.company_name || "",
    "[company_email]":  branding.support_email || ""
};

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? "").toString());
        }

        // 7️⃣ Generate HTML email body
        const emailHTML = await getEmailMsgPaysheet(
            paysheet.first_name,
            finalMessage,
            paysheet_link    // ← FIXED: was paysheet.payslip_url (undefined)
        );

        // 8️⃣ Send Admin Emails
        if (template.admin === "Yes" && billing_email && postmark_token) {

            let adminEmails = [];
            const rawEmails = globalstatus.rows[0]?.notification_emails;

            if (typeof rawEmails === "string") {
                adminEmails = rawEmails.split(",").map(e => e.trim()).filter(Boolean);
            }
            else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim()).filter(Boolean);
            }

            for (const email of adminEmails) {
                try {

                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );

                    console.log(`✅ Email sent to admin: ${email}`, response);

                    const logMessage = finalMessage.replaceAll("[Paysheet_Button]", "");

                    await insertemaillog(email, logMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed to send email to admin: ${email}`, err);
                }
            }
        }

        // 9️⃣ Send Employee Email
        if (template.employee === "Yes" && billing_email && postmark_token && employee_email) {

            try {
                const response = await sendEmailWithPostmark(
                    employee_email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                console.log(`✅ Email sent to employee: ${employee_email}`, response);

                await insertemaillog(employee_email, finalMessage, template.subject, actionId);

            } catch (err) {
                console.error(`❌ Failed to send email to employee: ${employee_email}`, err);
            }
        }

        // 🔟 Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === "Yes",
            sendToEmployee: template.employee === "Yes",
            paysheetDetails: paysheet,
            paysheet_link,   // ← also return it for reference
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp_paysheet:", error);
        return null;
    }
};


// ----- Employee Onboarding EMAIL

const sendemailtemp_employeeonboard = async (actionId, employee_id) => {
    try {

        // 1️⃣ Check global email status
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2️⃣ Get active email template
        const emailResult = await pool.query(
            "SELECT msg, admin, employee, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (emailResult.rows.length === 0) return null;

        const template = emailResult.rows[0];

        // 3️⃣ Get employee details
        const employeeResult = await pool.query(
            `SELECT 
                employee_id,
                first_name,
                last_name,
                contact_no,
                mobile_number,
                email,
                joined_date
            FROM employees
            WHERE employee_id = $1`,
            [employee_id]
        );

        if (employeeResult.rows.length === 0) return null;

        const employee = employeeResult.rows[0];

        // 4️⃣ Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 5️⃣ Get email settings
        const settings = await getemailsettings();

        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Placeholder replacements
        const placeholders = {
            "[first_name]": employee.first_name,
            "[name]": `${employee.first_name} ${employee.last_name}`,
            "[phone]": employee.contact_no ?? employee.mobile_number,
            "[email]": employee.email,
            "[join_date]": employee.joined_date,

            "[Hotline]": branding.hotline ?? "",
            "[Webname]": branding.company_name ?? "",
            "[company_email]": branding.support_email ?? "",
            "[website]": branding.website_url ?? ""
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7️⃣ Generate HTML body
        const emailHTML = await getEmailMsg(employee.first_name, finalMessage);

        // 8️⃣ Send Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {

            const adminQuery = await pool.query(
                "SELECT notification_emails FROM system_settings LIMIT 1"
            );

            let rawEmails = adminQuery.rows[0]?.notification_emails ?? [];

            let adminEmails = [];

            if (typeof rawEmails === "string") {
                adminEmails = rawEmails.split(",").map(e => e.trim());
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            }

            for (const email of adminEmails) {
                try {
                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );
                    console.log(`✔ Admin email sent: ${email}`);
                    await insertemaillog(email, finalMessage, template.subject, actionId);
                } catch (err) {
                    console.error(`❌ Failed admin email: ${email}`, err);
                }
            }
        }

        // 9️⃣ Send Employee Email
        if (template.employee === 'Yes' && billing_email && postmark_token) {
            try {
                const response = await sendEmailWithPostmark(
                    employee.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                console.log(`✔ Employee email sent: ${employee.email}`);

                await insertemaillog(employee.email, finalMessage, template.subject, actionId);
            } 
            catch (err) {
                console.error(`❌ Failed employee email: ${employee.email}`, err);
            }
        }

        // Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToEmployee: template.employee === 'Yes',
            employeeDetails: employee,
            branding
        };
    } catch (error) {
        console.error("❌ Error in sendemailtemp_employeeonboard:", error);
        return null;
    }
};



const customhookLeave = async (actionId, leave_id, employee_mobile, employee_email,first_name) => {
    console.log("employee_email",employee_email)
    console.log("actionId",actionId)
    console.log("leave_id",leave_id)
    console.log("employee_mobile",employee_mobile)
    console.log("first_name",first_name)
    
    const sms = await sendsmstemp_leave(actionId, leave_id, employee_mobile,first_name);
    const email = await sendemailtemp_leave(actionId, leave_id, employee_email,first_name);
    return { sms, email };
};

const customhookShiftRoster = async (actionId, roster_id,employee_id, employee_mobile,first_name,last_name,shift_name,shift_in_time,shift_out_time) => {

    const sms = await sendsmstemp_shiftroster(actionId, roster_id,employee_id, employee_mobile,first_name,last_name,shift_name,shift_in_time,shift_out_time);
    const email = await sendemailtemp_shiftroster(actionId, roster_id,employee_id, employee_mobile,first_name,last_name,shift_name,shift_in_time,shift_out_time);
    return { sms , email};
};

const customhookPaysheet = async (actionId, paysheet_id, employee_email, employee_mobile, payslip_url = '') => {
    const email = await sendemailtemp_paysheet(actionId, paysheet_id, employee_email, payslip_url);
    const sms   = await sendsmstemp_paysheet(actionId, paysheet_id, employee_mobile, payslip_url);
    return { email, sms };
};

const customhookEmployeeOnboard = async (actionId, employee_id, first_name,last_name, employee_mobile, employee_email,joined_date) => {
    const sms = await sendsmstemp_employeeonboard(actionId, employee_id, first_name,last_name, employee_mobile,joined_date);
    const email  = await sendemailtemp_employeeonboard(actionId, employee_id, first_name,last_name, employee_email,joined_date);
    return { sms, email  };
};

// ----- Employee Account Invitation Email -----
const sendemailtemp_invitation = async (firstName, email, setupLink) => {
    try {
        // 1. Check global email status
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );
        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2. Get email settings (Postmark token + from address)
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        if (!billing_email || !postmark_token) {
            console.error("Missing Postmark settings. Cannot send invitation email.");
            return null;
        }

        // 3. Get branding
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] ?? {};

        // 4. Build the email HTML (uses your existing branded wrapper)
        const subject = `Welcome to ${branding.company_name || 'EMS'} - Set Up Your Account`;

        const bodyContent = `
            <p style="font-size:16px; color:#333;">Hello <strong>${firstName}</strong>,</p>
            <p style="font-size:15px; color:#555;">
                Your EMS account has been created. Click the button below to create your password 
                and activate your account.
            </p>
            <div style="text-align:center; margin: 28px 0;">
                <a href="${setupLink}" 
                   style="display:inline-block; padding:13px 30px; font-size:15px;
                          color:#ffffff; background-color:#198754; text-decoration:none;
                          border-radius:6px; font-weight:600;">
                    Create Password
                </a>
            </div>
            <p style="font-size:13px; color:#6c757d;">
                This invitation link will expire in <strong>24 hours</strong>.<br/>
                If you did not expect this email, please ignore it.
            </p>
        `;

        // Reuse your existing branded HTML wrapper
        const emailHTML = await getEmailMsg(firstName, bodyContent);

        // 5. Send via Postmark
        await sendEmailWithPostmark(email, subject, emailHTML, postmark_token, billing_email);

        // 6. Log it
        await insertemaillog(email, bodyContent, subject, 'INVITATION');

        console.log(`✔ Invitation email sent to: ${email}`);
        return true;

    } catch (error) {
        console.error("❌ Error in sendemailtemp_invitation:", error);
        return null;
    }
};


// ----- Invitation Hook -----
const customhookInvitation = async (firstName, email, setupLink, contactNo, password, username) => {
    const sms = await sendsmstemp_invitation(firstName, contactNo, password, username);
    const emailResult = await sendemailtemp_invitation(firstName, email, setupLink); // ← add this
    return { sms, emailResult };
};

module.exports = {send_sms,sendsmstemp_leave,sendemailtemp_leave,sendsmstemp_shiftroster,sendemailtemp_paysheet,sendsmstemp_employeeonboard,
    sendemailtemp_employeeonboard,sendsmstemp_paysheet,
    customhookLeave,customhookShiftRoster,customhookPaysheet,customhookEmployeeOnboard,sendemailtemp_invitation,
    customhookInvitation,sendsmstemp_invitation,};


