const pool = require("../config/db");

const adminUserDeatils = async (id) => {
    const query = `SELECT user_id, merchant_id, branch_id, username FROM users WHERE user_id = $1`;

    const result = await pool.query(query, [id]);

    if (result.rows.length === 0) throw new Error("User not found");
    return result.rows[0];
}

const systemSettings = async () => {
    const query = `SELECT id, currency, tax,tax_value, loyalty_point, points_given, amount_spend FROM system_settings WHERE id = 1`;
    const result = await pool.query(query);

    if (result.rows.length === 0) throw new Error("System setting not found");
    return result.rows[0];
}

const brandingSettings = async () => {
    const query = `SELECT address_2, address_1, hotline, support_email FROM branding_settings WHERE id = 1`;
    const result = await pool.query(query);

    if (result.rows.length === 0) throw new Error("System setting not found");
    return result.rows[0];
}

const getDeliveryFee = async (id) => {

    if (!id) throw new Error("country not found");

    const deliverQuery = `SELECT fee, additional_fee FROM delivery_fee WHERE country_id = $1`;
    const defaultCountry = `SELECT fee, additional_fee FROM delivery_fee WHERE id = 1`;

    const [deliveryFee, defaultFee] = await Promise.all([
        pool.query(deliverQuery, [parseFloat(id)]),
        pool.query(defaultCountry),
    ]);

    if (defaultFee.rows.length === 0) throw new Error("delivery fee not found");

    if (deliveryFee.rows.length === 0) return defaultFee.rows[0]

    return deliveryFee.rows[0]
}

const oneCountry = async (id) => {
    try {
        const result = await pool.query('SELECT country_name FROM countries WHERE id = $1', [Number(id)]);

        if (result.rows.length === 0) {
            throw new Error('Country not found');
        }

        return result.rows[0].country_name;
    } catch (err) {
        console.error('Error fetching system settings:', err);
        throw new Error('Failed to fetch system settings');
    }
};
const getCountryNameByid = async (name) => {
    try {
        const result = await pool.query('SELECT country_name FROM countries WHERE country_name ILIKE $1', [name]);

        if (result.rows.length === 0) {
            throw new Error('Country not found');
        }

        return result.rows[0].id;
    } catch (err) {
        console.error('Error fetching system settings:', err);
        throw new Error('Failed to fetch system settings');
    }
};

const checkLoyalty = async (id) => {
    try {
        const result = await pool.query('SELECT loyalty_point FROM customer WHERE customer_id = $1', [Number(id)]);

        if (result.rows.length === 0) {
            throw new Error('Loyalty not found');
        }

        return result.rows[0].loyalty_point;
    } catch (err) {
        console.error('Error fetching system settings:', err);
        throw new Error('Failed to fetch system settings');
    }
};

// corrected function
const updateLoyaltySuctomer = async (id, loyaltiPoints, customerLoyalty, comment = '') => {
  try {
    // skip if nothing to deduct (null/undefined/0 or negative)
    if (loyaltiPoints == null || Number(loyaltiPoints) <= 0) return null;

    const idNum = Number(id);
    const pointsToDeduct = Number(loyaltiPoints);
    const current = Number(customerLoyalty) || 0;

    // compute and clamp to zero
    const newLoyaltyPoint = Math.max(0, current - pointsToDeduct);

    const result = await pool.query(
      'UPDATE customer SET loyalty_point = $2 WHERE customer_id = $1 RETURNING 	customer_id, loyalty_point',
      [idNum, newLoyaltyPoint]
    );

    if (result.rowCount === 0) {
      throw new Error(`Customer with id ${idNum} not found`);
    }

    await addRemoveLogs(idNum, pointsToDeduct, current, comment)
    // return updated row for clarity
    return result.rows[0];
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};

const addLoyalty = async (id, loyalty_points_earned, comment = '') => {
  try {
    // skip if nothing to deduct (null/undefined/0 or negative)
    if (loyalty_points_earned == null || Number(loyalty_points_earned) <= 0) return null;

    const idNum = Number(id);
    const pointsToAdd = Number(loyalty_points_earned)

    const loyalty_result = await pool.query(
      `SELECT loyalty_point FROM customer WHERE customer_id = $1`,
      [idNum]
    );

    const current = loyalty_result.rows[0].loyalty_point || 0

    const result = await pool.query(
      `UPDATE customer
    SET loyalty_point = loyalty_point + $1
    WHERE customer_id = $2
    RETURNING loyalty_point;`,
      [pointsToAdd ,idNum]
    );

    if (result.rowCount === 0) {
      throw new Error(`Customer with id ${idNum} not found`);
    }

    await addPonitsLogs(id, pointsToAdd, current, comment)
    // return updated row for clarity
    return result.rows[0];
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};
const addRemoveLogs = async (id, pointsToDeduct, current, comment) => {
  try {
  
    const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;
    const new_amount = Number(current) - Number(pointsToDeduct)
    const result = await pool.query(query, [id, current, -pointsToDeduct, new_amount, comment]);

    if (result.rowCount === 0) {
      throw new Error(`Failed to add points log`);
    }

    return 
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};
const addPonitsLogs = async (id, pointsToAdd, current, comment) => {
  try {
  
    const query = `INSERT INTO points_logs (customer_id, prev_amount, adjust_amount, new_amount, comment) VALUES ($1, $2, $3, $4, $5)`;
    const new_amount = Number(current) + Number(pointsToAdd)
    const result = await pool.query(query, [id, current, pointsToAdd, new_amount, comment]);

    if (result.rowCount === 0) {
      throw new Error(`Failed to add points log`);
    }

    return 
  } catch (err) {
    console.error('Error updating customer loyalty:', err);
    throw err; // rethrow so caller can handle it
  }
};









module.exports = { adminUserDeatils, systemSettings, brandingSettings, getDeliveryFee, oneCountry, checkLoyalty, updateLoyaltySuctomer, addLoyalty }