const https  = require("https");
const pool   = require("../config/db");
const axios  = require("axios");

// ── Helpers ────────────────────────────────────────────────────────────────

const getsmssettings = async () => {
  try {
    const result = await pool.query(
      `SELECT sms_gateway_name, sms_user_id, sms_sender_id,
              sms_api_endpoint, sms_api_key
       FROM system_settings LIMIT 1`
    );
    return result.rows[0] || null;
  } catch (err) {
    console.error("Error fetching SMS settings:", err);
    return null;
  }
};

const getemailsettings = async () => {
  try {
    const result = await pool.query(
      `SELECT billing_email, postmark_server_token
       FROM system_settings LIMIT 1`
    );
    return result.rows[0] || null;
  } catch (err) {
    console.error("Error fetching email settings:", err);
    return null;
  }
};

function send_sms(client_id, api_key, sender_id, message, recipient, sms_api_endpoint) {
  return new Promise((resolve, reject) => {
    const url      = new URL(sms_api_endpoint);
    const hostname = url.hostname;
    const path     = `/v1/send/?user_id=${encodeURIComponent(client_id)}&api_key=${encodeURIComponent(api_key)}&sender_id=${encodeURIComponent(sender_id)}&message=${encodeURIComponent(message)}&recipient_contact_no=${encodeURIComponent(recipient)}`;

    const req = https.request({ method: "GET", hostname, path, headers: {}, maxRedirects: 20 }, (res) => {
      let chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("end",  ()      => {
        const body = Buffer.concat(chunks).toString();
        try { resolve(JSON.parse(body)); } catch { resolve(body); }
      });
      res.on("error", reject);
    });
    req.end();
  });
}

async function sendEmailWithPostmark(to, subject, html, apiToken, fromEmail) {
  try {
    const response = await axios.post("https://api.postmarkapp.com/email", {
      From: fromEmail, To: to, Subject: subject,
      HtmlBody: html, MessageStream: "outbound",
    }, {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Postmark-Server-Token": apiToken,
      },
    });
    return response.data;
  } catch (err) {
    console.error("Postmark error:", err.response?.data || err.message);
    return null;
  }
}

// ── Logging ───────────────────────────────────────────────────────────────

const insertsmslog = async (mobileno, msg, action) => {
  try {
    await pool.query(
      `INSERT INTO send_sms_temp_log (mobileno, msg, status, date, sentdate, action)
       VALUES ($1, $2, 'Sent', NOW(), NOW(), $3)`,
      [mobileno, msg, action]
    );
  } catch (err) { console.error("SMS log error:", err); }
};

const insertemaillog = async ({
  email,
  msg,
  subject,
  action,
  status = 'Sent',
  batche_id = null
}) => {
  try {
    await pool.query(
      `INSERT INTO send_email_temp_log
       (email, msg, status, date, sentdate, batche_id, action, subject)
       VALUES ($1, $2, $3, NOW(), NOW(), $4, $5, $6)`,
      [
        email,
        msg,
        status,
        batche_id,
        action,
        subject
      ]
    );
  } catch (err) {
    console.error("❌ Email log error:", err);
  }
};




// ── Email Template Helper ──────────────────────────────────────────────────

async function getEmailMsg(customerName, message) {
  try {
    const brandingQuery = await pool.query(
      "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
    );
    const branding = brandingQuery.rows[0] || {};

    return `
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;
                border:1px solid #dce6f1;border-radius:8px;background-color:#f4f8fc;">
      <div style="text-align:center;padding:20px 0;">
        <img src="${branding.logo_url || ''}" alt="Logo" style="max-width:150px;margin-bottom:10px;">
        <h2 style="color:#1a4e8a;margin:0;">Job Notification</h2>
      </div>
      <div style="background:#fff;padding:20px;border-radius:8px;
                  box-shadow:0px 4px 12px rgba(0,64,128,0.05);font-size:16px;color:#333;">
        <p>Dear <strong>${customerName || 'Customer'}</strong>,</p>
        ${message}
      </div>
      <div style="text-align:center;font-size:12px;color:#777;margin-top:30px;">
        <p>Thank you for choosing <strong>${branding.company_name || ''}</strong>.</p>
        <p>Hotline: ${branding.hotline || ''} |
           Email: <a href="mailto:${branding.support_email || ''}">${branding.support_email || ''}</a>
        </p>
      </div>
    </div>`;
  } catch (err) {
    console.error("getEmailMsg error:", err);
    return message;
  }
}

// ── SMS Job Sender ────────────────────────────────────────────────────────

const sendsmstemp_job = async (actionId, job_id, customer_phone, customer_name, customer_email, job_name, job_description, job_date) => {
  try {
    const globalRes = await pool.query(
      "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
    );
    const global = globalRes.rows[0];
    if (global?.sms_notification_status !== 'enabled') {
      console.log('[Job SMS] SMS notifications disabled');
      return null;
    }

    const templateRes = await pool.query(
      "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
      [actionId]
    );
    if (!templateRes.rows.length) {
      console.log('[Job SMS] No active SMS template for action:', actionId);
      return null;
    }
    const template = templateRes.rows[0];

    const brandingRes = await pool.query(
      "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
    );
    const branding = brandingRes.rows[0] || {};

    const settings        = await getsmssettings();
    const sms_user_id     = settings?.sms_user_id      || '';
    const sms_api_key     = settings?.sms_api_key      || '';
    const sms_sender_id   = settings?.sms_sender_id    || '';
    const sms_api_endpoint = settings?.sms_api_endpoint || '';

    const placeholders = {
      '[name]':            customer_name         || '',
      '[phone]':           customer_phone        || '',
      '[email]':           customer_email        || '',
      '[job_id]':          String(job_id),
      '[job_name]':        job_name              || '',
      '[job_description]': job_description       || '',
      '[job_date]':        job_date              || '',
      '[Hotline]':         branding.hotline      || '',
      '[Webname]':         branding.company_name || '',
      '[company_email]':   branding.support_email || '',
    };

    let finalMessage = template.msg;
    for (const [key, val] of Object.entries(placeholders)) {
      finalMessage = finalMessage.replaceAll(key, val);
    }

    // Admin SMS
    if (template.admin === 'Yes') {
      const adminPhones = String(global.notification_mobile_numbers || '')
        .split(',').map(p => p.trim()).filter(Boolean);
      for (const phone of adminPhones) {
        try {
          if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {
            const response = await send_sms(sms_user_id, sms_api_key, sms_sender_id, finalMessage, phone, sms_api_endpoint);
            await insertsmslog(phone, finalMessage, actionId);
            console.log('[Job SMS] Admin SMS sent to:', phone, 'Response:', response);
          }
        } catch (err) { console.error('[Job SMS] Admin SMS failed:', err); }
      }
    }

    // Client SMS
    if (template.client === 'Yes' && customer_phone) {
      try {
        if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {
          const response = await send_sms(sms_user_id, sms_api_key, sms_sender_id, finalMessage, customer_phone, sms_api_endpoint);
          await insertsmslog(customer_phone, finalMessage, actionId);
          console.log('[Job SMS] Client SMS sent to:', customer_phone, 'Response:', response);
        }
      } catch (err) { console.error('[Job SMS] Client SMS failed:', err); }
    }

    return { message: finalMessage };
  } catch (err) {
    console.error('[Job SMS] Error:', err);
    return null;
  }
};

// ── Email Job Sender with full log ─────────────────────────────────────────

const sendemailtemp_job = async (actionId, job_id, customer_email, customer_name, customer_phone, job_name, job_description, job_date) => {
  try {
    const globalRes = await pool.query(
      "SELECT email_notification_status, notification_emails FROM system_settings LIMIT 1"
    );
    const global = globalRes.rows[0];
    if (global?.email_notification_status !== 'enabled') {
      console.log('[Job Email] Email notifications disabled');
      return null;
    }

    const templateRes = await pool.query(
      "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
      [actionId]
    );
    if (!templateRes.rows.length) {
      console.log('[Job Email] No active email template for action:', actionId);
      return null;
    }
    const template = templateRes.rows[0];

    const brandingRes = await pool.query(
      "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
    );
    const branding = brandingRes.rows[0] || {};

    const settings       = await getemailsettings();
    const billing_email  = settings?.billing_email;
    const postmark_token = settings?.postmark_server_token;

    const placeholders = {
      '[name]':            customer_name         || '',
      '[phone]':           customer_phone        || '',
      '[email]':           customer_email        || '',
      '[job_id]':          String(job_id),
      '[job_name]':        job_name              || '',
      '[job_description]': job_description       || '',
      '[job_date]':        job_date              || '',
      '[Hotline]':         branding.hotline      || '',
      '[Webname]':         branding.company_name || '',
      '[company_email]':   branding.support_email || '',
    };

    let finalMessage = template.msg;
    for (const [key, val] of Object.entries(placeholders)) {
      finalMessage = finalMessage.replaceAll(key, val);
    }

    const emailHTML = await getEmailMsg(customer_name, finalMessage);

    // Admin email
    if (template.admin === 'Yes' && billing_email && postmark_token) {
      let adminEmails = [];
      const rawEmails = global.notification_emails;
      if (typeof rawEmails === 'string') adminEmails = rawEmails.split(',').map(e => e.trim()).filter(Boolean);
      else if (Array.isArray(rawEmails))  adminEmails = rawEmails.map(e => e.trim()).filter(Boolean);

      for (const email of adminEmails) {
        try {
          const response = await sendEmailWithPostmark(email, template.subject, emailHTML, postmark_token, billing_email);
          await insertemaillog({
            email,
            msg: finalMessage,
            subject: template.subject,
            action: actionId,
            status: 'Sent',
            response,
            recipient_type: 'admin',
            triggered_by: 'job',
            ref_id: job_id
          });
          console.log('[Job Email] Admin email sent:', email, 'Response:', response);
        } catch (err) {
          await insertemaillog({
            email,
            msg: finalMessage,
            subject: template.subject,
            action: actionId,
            status: 'Failed',
            recipient_type: 'admin',
            triggered_by: 'job',
            ref_id: job_id
          });
          console.error('[Job Email] Admin email failed:', err);
        }
      }
    }

    // Client email
    if (template.client === 'Yes' && billing_email && postmark_token && customer_email) {
      try {
        const response = await sendEmailWithPostmark(customer_email, template.subject, emailHTML, postmark_token, billing_email);
        await insertemaillog({
          email: customer_email,
          msg: finalMessage,
          subject: template.subject,
          action: actionId,
          status: 'Sent',
          response,
          recipient_type: 'client',
          triggered_by: 'job',
          ref_id: job_id
        });
        console.log('[Job Email] Client email sent:', customer_email, 'Response:', response);
      } catch (err) {
        await insertemaillog({
          email: customer_email,
          msg: finalMessage,
          subject: template.subject,
          action: actionId,
          status: 'Failed',
          recipient_type: 'client',
          triggered_by: 'job',
          ref_id: job_id
        });
        console.error('[Job Email] Client email failed:', err);
      }
    }

    return { message: finalMessage };
  } catch (err) {
    console.error('[Job Email] Error:', err);
    return null;
  }
};

// ── Master hook ─────────────────────────────────────────────────────────────

const customhookJob = async (actionId, job_id, job_name, job_description, job_date, customer_name, customer_phone, customer_email) => {
  console.log('[customhookJob] firing → actionId:', actionId, 'job_id:', job_id);
  const sms   = await sendsmstemp_job(actionId, job_id, customer_phone, customer_name, customer_email, job_name, job_description, job_date);
  const email = await sendemailtemp_job(actionId, job_id, customer_email, customer_name, customer_phone, job_name, job_description, job_date);
  return { sms, email };
};

module.exports = { customhookJob };
