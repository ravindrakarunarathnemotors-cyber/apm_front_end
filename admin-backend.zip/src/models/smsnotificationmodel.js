const https = require("https");
const pool = require("../config/db");
const axios = require("axios");
const { encryptId } = require("../util/orderEncrypt");

function send_sms(client_id, api_key, sender_id, message, recipient_contact_no, sms_api_endpoint) {
    return new Promise((resolve, reject) => {
        // Extract hostname from API endpoint
        const url = new URL(sms_api_endpoint);
        const hostname = url.hostname;
        const path = `/v1/send/?user_id=${encodeURIComponent(client_id)}&api_key=${encodeURIComponent(api_key)}&sender_id=${encodeURIComponent(sender_id)}&message=${encodeURIComponent(message)}&recipient_contact_no=${encodeURIComponent(recipient_contact_no)}`;

        const options = {
            method: "GET",
            hostname: hostname,
            path: path,
            headers: {},
            maxRedirects: 20
        };

        const req = https.request(options, (res) => {
            let chunks = [];

            res.on("data", (chunk) => {
                chunks.push(chunk);
            });

            res.on("end", () => {
                const body = Buffer.concat(chunks).toString();
                try {
                    resolve(JSON.parse(body));
                } catch (error) {
                    resolve(body);
                }
            });

            res.on("error", (error) => {
                console.error("SMS API Error:", error);
                reject(error);
            });
        });

        req.end();
    });
}





const getsmssettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                sms_gateway_name,
                sms_user_id,
                sms_sender_id,
                sms_api_endpoint,
                sms_api_key
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No SMS settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching SMS settings:", error);
        throw error;
    }
};



const insertsmslog = async (mobileno, msg, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_sms_temp_log (mobileno, msg, status, date, sentdate, action) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [mobileno, msg, action]);

        return result.rows[0]; // Return inserted row with ID
    } catch (error) {
        console.error("❌ Error inserting SMS log:", error);
        throw error;
    }
};


const insertemaillog = async (email, msg, subject, action) => {
    try {
        const insertQuery = `
            INSERT INTO send_email_temp_log (email, msg, status, date, sentdate, action,subject) 
            VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3, $4) 
            RETURNING id;
        `;

        const result = await pool.query(insertQuery, [email, msg, action, subject]);

        return result.rows[0]; // Return inserted row with ID
    } catch (error) {
        console.error("❌ Error inserting email log:", error);
        throw error;
    }
};


const sendsmstemp = async (actionId, order_id) => {
    try {

        const globalstatus = await pool.query(
            "SELECT sms_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }



        console.log(` Fetching SMS templates for actionId: ${actionId}`);

        // 1. Get SMS template
        const smsResult = await pool.query(
            "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (smsResult.rows.length === 0) {
            console.log(" No active SMS template found.");
            return null;
        }

        const template = smsResult.rows[0];

        // 2. Get order details
        console.log(` Fetching order details for order_id: ${order_id}`);
        const parcelResult = await pool.query(
            `SELECT 
                p.order_id AS order_id, 
                p.total_value AS amount, 
                p.recipient_name AS name, 
                p.recipient_contact AS phone, 
                p.recipient_address AS address, 
                p.recipient_city AS city, 
                p.recipient_email AS email,
                p.delivery_type AS delivery_type,
                p.tracking_id AS tracking_id,
                p.delivery_fee AS delivery_fee,
                p.loyalty_points_spent AS loyalty_points_spent,
                p.reason_id as reason_detail,
                c.customer_id,
                c.loyalty_point
            FROM orders p
            LEFT JOIN customer c ON p.customer_id = c.customer_id
            WHERE p.order_id = $1`,
            [order_id]
        );



        if (parcelResult.rows.length === 0) {
            console.log(" No parcel found for this order.");
            return null;
        }

        const parcel = parcelResult.rows[0];

        // 3. Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email,website_url FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};
        const branding = {
            company_name: brandingRow.company_name ?? '',
            hotline: brandingRow.hotline ?? '',
            support_email: brandingRow.support_email ?? ''
        };

        // 4. Get SMS settings
        const settings = await getsmssettings();
        console.log("🔧 SMS Settings:", settings);

        const sms_user_id = settings?.sms_user_id ?? '';
        const sms_api_key = settings?.sms_api_key ?? '';
        const sms_sender_id = settings?.sms_sender_id ?? '';
        const sms_api_endpoint = settings?.sms_api_endpoint ?? '';

        const encryptID = encryptId(parcel.order_id)

        // 5. Placeholder replacements
        const orderLink = `${brandingRow.website_url?.replace(/\/$/, '')}/order/${encryptID}`;

        const placeholders = {
            "[first_name]": parcel.name,
            "[name]": parcel.name,
            "[phone]": parcel.phone,
            "[email]": parcel.email,
            "[order_id]": parcel.order_id,
            "[delivery_type]": parcel.delivery_type ?? '',
            "[amount]": parcel.amount,
            "[address]": parcel.address,
            "[city]": parcel.city,
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email,
            "[reason]": parcel.reason_detail || 'N/A',
            "[tracking_id]": parcel.tracking_id ?? '',
            "[delivery_fee]": parcel.delivery_fee ?? '',
            "[invoice_link]": orderLink,  // ✅ Add this
            "[order_link]": orderLink,     // ✅ Optional alias loyalty_point
            "[all_points]": parcel.loyalty_point ?? '0',
            "[spending_points]": parcel.loyalty_points_spent ?? '0',

        };


        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 6. Admin SMS
        if (template.admin === 'Yes') {
            const systemSettingsResult = await pool.query(
                "SELECT notification_mobile_numbers FROM system_settings LIMIT 1"
            );

            const rawPhones = systemSettingsResult.rows[0]?.notification_mobile_numbers;
            console.log(" Raw adminPhones:", rawPhones);

            let adminPhones = [];

            if (typeof rawPhones === 'string') {
                adminPhones = rawPhones.split(',').map(p => p.trim());
            } else if (Array.isArray(rawPhones)) {
                adminPhones = rawPhones;
            }

            if (!sms_user_id || !sms_api_key || !sms_sender_id || !sms_api_endpoint) {
                console.error(" Missing SMS API settings. Cannot send SMS to admin.");
            } else if (adminPhones.length > 0) {
                for (const phone of adminPhones) {
                    try {
                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );
                        console.log(` SMS sent to admin: ${phone}`, smsResponse);
                        await insertsmslog(phone, finalMessage, actionId);

                    } catch (smsError) {
                        console.error(` Failed to send SMS to admin: ${phone}`, smsError);
                    }
                }
            } else {
                console.warn(" No valid admin phone numbers found.");
            }
        }

        // 7. Client SMS
        if (template.client === 'Yes') {
            if (!sms_user_id || !sms_api_key || !sms_sender_id || !sms_api_endpoint) {
                console.error(" Missing SMS API settings. Cannot send SMS to client.");
            } else {
                try {
                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        parcel.phone,
                        sms_api_endpoint
                    );
                    console.log(` SMS sent to client: ${parcel.phone}`, smsResponse);
                    await insertsmslog(parcel.phone, finalMessage, actionId);

                } catch (smsError) {
                    console.error(` Failed to send SMS to client: ${parcel.phone}`, smsError);
                }
            }
        }

        // 8. Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            parcelDetails: parcel,
            branding: {
                companyName: branding.company_name,
                hotline: branding.hotline,
                supportEmail: branding.support_email
            }
        };

    } catch (error) {
        console.error(" Error in sendsmstemp:", error);
        return null;
    }
};


const sendsmstemp_user_register = async (actionId, order_id) => {
    try {
        const customer_id = order_id;  // ✔ JUST ASSIGN
        const password = 'guest123';

        // 1. Check global SMS status
        const globalstatus = await pool.query(
            "SELECT sms_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

        console.log(`Fetching SMS templates for actionId: ${actionId}`);

        // 2. Get SMS template
        const smsResult = await pool.query(
            "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (smsResult.rows.length === 0) {
            console.log("No active SMS template found.");
            return null;
        }

        const template = smsResult.rows[0];

        // 3. Get customer details
        console.log(`Fetching customer details for customer_id: ${customer_id}`);

        const customerResult = await pool.query(
            `SELECT 
                customer_id, 
                first_name, 
                last_name, 
                contact_number_1 AS phone, 
                email
            FROM customer
            WHERE customer_id = $1`,
            [customer_id]
        );

        if (customerResult.rows.length === 0) {
            console.log("No customer found for this customer_id.");
            return null;
        }

        const customer = customerResult.rows[0];

        // 4. Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = {
            company_name: brandingResult.rows[0]?.company_name ?? '',
            hotline: brandingResult.rows[0]?.hotline ?? '',
            support_email: brandingResult.rows[0]?.support_email ?? '',
            website_url: brandingResult.rows[0]?.website_url ?? ''
        };

        // 5. Get SMS settings
        const settings = await getsmssettings();
        console.log("SMS Settings:", settings);

        const sms_user_id = settings?.sms_user_id ?? '';
        const sms_api_key = settings?.sms_api_key ?? '';
        const sms_sender_id = settings?.sms_sender_id ?? '';
        const sms_api_endpoint = settings?.sms_api_endpoint ?? '';

        // 6. Placeholder replacements
        const placeholders = {
            "[first_name]": customer.first_name,
            "[name]": `${customer.first_name} ${customer.last_name}`,
            "[phone]": customer.phone,
            "[email]": customer.email,
            "[Username]": customer.email,

            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email,
            "[Password]": password,

        };

        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value ?? '');
        }

        // 7. Admin SMS send
        if (template.admin === 'Yes') {
            const systemSettingsResult = await pool.query(
                "SELECT notification_mobile_numbers FROM system_settings LIMIT 1"
            );

            const rawPhones = systemSettingsResult.rows[0]?.notification_mobile_numbers;
            let adminPhones = [];

            if (typeof rawPhones === 'string') {
                adminPhones = rawPhones.split(',').map(p => p.trim());
            } else if (Array.isArray(rawPhones)) {
                adminPhones = rawPhones;
            }

            for (const phone of adminPhones) {
                try {
                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        phone,
                        sms_api_endpoint
                    );
                    console.log(`SMS sent to admin: ${phone}`, smsResponse);
                    await insertsmslog(phone, finalMessage, actionId);

                } catch (smsError) {
                    console.error(`Failed to send SMS to admin: ${phone}`, smsError);
                }
            }
        }

        // 8. Client SMS send
        if (template.client === 'Yes') {
            try {
                const smsResponse = await send_sms(
                    sms_user_id,
                    sms_api_key,
                    sms_sender_id,
                    finalMessage,
                    customer.phone,
                    sms_api_endpoint
                );
                console.log(`SMS sent to client: ${customer.phone}`, smsResponse);
                await insertsmslog(customer.phone, finalMessage, actionId);

            } catch (smsError) {
                console.error(`Failed to send SMS to client: ${customer.phone}`, smsError);
            }
        }

        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            customerDetails: customer,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_user_register:", error);
        return null;
    }
};


//send invoice link **************************************************************

const sendsm_invoice_link = async (actionId, invoice_id) => {
    try {

        console.log(`[SMS] Start sending SMS for invoice: ${invoice_id}`);

        // 1. Check global SMS status
        const globalstatus = await pool.query(
            "SELECT sms_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.sms_notification_status !== 'enabled') {
            console.log("[SMS] SMS notifications are disabled in system settings.");
            return false;
        }

        // 2. Get SMS template
        const smsResult = await pool.query(
            "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (smsResult.rows.length === 0) {
            console.error(`[SMS] No active SMS template found for action: ${actionId}`);
            return false;
        }

        const template = smsResult.rows[0];

        // 3. Get invoice + customer details
        const customerResult = await pool.query(
            `SELECT 
                ih.customer_id,
                ih.full_amount,
                ih.created_at,
                ih.loyalty_points_earned,
                c.first_name,
                c.last_name,
                c.contact_number_1 as phone
            FROM invoice_header ih
            LEFT JOIN customer c ON c.customer_id = ih.customer_id
            WHERE ih.id = $1`,
            [invoice_id]
        );

        if (customerResult.rows.length === 0) {
            console.error(`[SMS] Invoice not found for ID: ${invoice_id}`);
            return false;
        }

        const customer = customerResult.rows[0];

        if (!customer.phone) {
            console.warn(`[SMS] Customer phone not found for invoice: ${invoice_id}`);
            return false;
        }

        // 4. Get SMS settings
        const settings = await getsmssettings();

        if (!settings) {
            console.error("[SMS] SMS settings missing.");
            return false;
        }

        const sms_user_id = settings?.sms_user_id ?? '';
        const sms_api_key = settings?.sms_api_key ?? '';
        const sms_sender_id = settings?.sms_sender_id ?? '';
        const sms_api_endpoint = settings?.sms_api_endpoint ?? '';

        const encryptID = encryptId(invoice_id);

        const url = `${process.env.FRONTEND_URL}/ebill/${encryptID}`;

        let invoice_date = '';

        if (customer.created_at) {
            const date = new Date(customer.created_at);

            invoice_date = date.toLocaleString("en-LK", {
                timeZone: "Asia/Colombo",
                year: "numeric",
                month: "short",
                day: "2-digit",
                hour: "2-digit",
                minute: "2-digit"
            });
        }

        // 5. Replace placeholders
        const placeholders = {
            "[amount]": customer.full_amount,
            "[date]": invoice_date,
            "[customer_name]": `${customer.first_name ?? ''} ${customer.last_name ?? ''}`,
            "[loyalty_points]": customer.loyalty_points_earned ?? 0,
            "[inv_link]": url
        };

        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value ?? '');
        }

        console.log("[SMS] Final message:", finalMessage);

        // 6. Send Admin SMS
        if (template.admin === 'Yes') {

            const systemSettingsResult = await pool.query(
                "SELECT notification_mobile_numbers FROM system_settings LIMIT 1"
            );

            const rawPhones = systemSettingsResult.rows[0]?.notification_mobile_numbers;

            let adminPhones = [];

            if (typeof rawPhones === 'string') {
                adminPhones = rawPhones.split(',').map(p => p.trim());
            } else if (Array.isArray(rawPhones)) {
                adminPhones = rawPhones;
            }

            console.log(`[SMS] Sending admin SMS to: ${adminPhones.join(", ")}`);

            for (const phone of adminPhones) {
                try {

                    await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        phone,
                        sms_api_endpoint
                    );

                    await insertsmslog(phone, finalMessage, actionId);

                    console.log(`[SMS] Admin SMS sent successfully → ${phone}`);

                } catch (err) {
                    console.error(`[SMS] Admin SMS failed → ${phone}`, err);
                }
            }
        }

        // 7. Send Client SMS
        if (template.client === 'Yes' && customer.phone) {
            console.log("customer number", customer.phone)
            try {

                await send_sms(
                    sms_user_id,
                    sms_api_key,
                    sms_sender_id,
                    finalMessage,
                    customer.phone,
                    sms_api_endpoint
                );

                await insertsmslog(customer.phone, finalMessage, actionId);

                console.log(`[SMS] Client SMS sent successfully → ${customer.phone}`);

            } catch (err) {
                console.error(`[SMS] Client SMS failed → ${customer.phone}`, err);
            }
        }

        console.log(`[SMS] SMS process completed for invoice ${invoice_id}`);

        return true;

    } catch (error) {

        console.error("[SMS] Unexpected error in sendsm_invoice_link:", error);
        return false;
    }
};

const sendemailtemp_invoice_link = async (actionId, invoice_id) => {
    try {
        

        // 1. Check global email status
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2. Get active email template
        const emailResult = await pool.query(
            "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (emailResult.rows.length === 0) return null;
        const template = emailResult.rows[0];

        // 3. Get customer details
        const customerResult = await pool.query(
            `SELECT 
                ih.customer_id,
                ih.full_amount,
                ih.created_at,
                ih.loyalty_points_earned,
                c.first_name,
                c.last_name,
                c.contact_number_1 as phone,
                c.email
            FROM invoice_header ih
            LEFT JOIN customer c ON c.customer_id = ih.customer_id
            WHERE ih.id = $1`,
            [invoice_id]
        );

        if (customerResult.rows.length === 0) {
            console.error(`[SMS] Invoice not found for ID: ${invoice_id}`);
            return false;
        }

        const customer = customerResult.rows[0];

        if (!customer.phone) {
            console.warn(`[SMS] Customer phone not found for invoice: ${invoice_id}`);
            return false;
        }

        // 4. Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 5. Get email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        const encryptID = encryptId(invoice_id);

        const url = `${process.env.FRONTEND_URL}/ebill/${encryptID}`;

        let invoice_date = '';

        if (customer.created_at) {
            const date = new Date(customer.created_at);

            invoice_date = date.toLocaleString("en-LK", {
                timeZone: "Asia/Colombo",
                year: "numeric",
                month: "short",
                day: "2-digit",
                hour: "2-digit",
                minute: "2-digit"
            });
        }

        // 6. Placeholder replacements
        const placeholders = {
            "[amount]": customer.full_amount,
            "[date]": invoice_date,
            "[customer_name]": `${customer.first_name ?? ''} ${customer.last_name ?? ''}`,
            "[loyalty_points]": customer.loyalty_points_earned ?? 0,
            "[inv_link]": url,

            "[Hotline]": branding.hotline ?? "",
            "[Webname]": branding.company_name ?? "",
            "[company_email]": branding.support_email ?? ""
        };

        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7. Generate HTML body
        const emailHTML = await getEmailMsg(customer.first_name, finalMessage);

        // 8. Send Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            const adminQuery = await pool.query(
                "SELECT notification_emails FROM system_settings LIMIT 1"
            );

            let rawEmails = adminQuery.rows[0]?.notification_emails ?? [];
            let adminEmails = [];

            if (typeof rawEmails === "string") {
                adminEmails = rawEmails.split(",").map(e => e.trim());
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            }

            for (const email of adminEmails) {
                try {
                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );

                    console.log(`✔ Admin email sent: ${email}`);
                    await insertemaillog(email, finalMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed admin email: ${email}`, err);
                }
            }
        }

        // 9. Send Client Email
        if (template.client === 'Yes' && billing_email && postmark_token) {
            try {
                const response = await sendEmailWithPostmark(
                    customer.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                console.log(`✔ Client email sent: ${customer.email}`);
                await insertemaillog(customer.email, finalMessage, template.subject, actionId);

            } catch (err) {
                console.error(`❌ Failed client email: ${customer.email}`, err);
            }
        }

        // Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            customerDetails: customer,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp:", error);
        return null;
    }
};

//-------------------------------------------------------------------------------

// ****************************************************************************************************************************************************
//email Function start from here


async function sendEmailWithPostmark(to, subject, message, apiToken, fromEmail) {

    if (!apiToken) {
        console.error("Error: Postmark API token is missing.");
        return "Postmark API token is not configured.";
    }

    const postData = {
        "From": fromEmail,
        "To": to,
        "Subject": subject,
        "HtmlBody": message,
        "MessageStream": "outbound" // Default message stream for transactional emails
    };

    try {
        const response = await axios.post("https://api.postmarkapp.com/email", postData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        });

        console.log("Email sent successfully:", response.data);
        return response.data; // Return full Postmark response
    } catch (error) {
        console.error("Error sending email:", error.response ? error.response.data : error.message);
        return `Error sending email: ${error.response ? JSON.stringify(error.response.data) : error.message}`;
    }
}


async function getEmailMsg(username, message) {
    try {


        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );

        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
            <!-- Header Section -->
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url}" 
                     alt="Logo" 
                     style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1a4e8a; margin: 0;">Order Notification</h2>
            </div>

           <!-- Main Content -->
                <div style="
                background: #ffffff; 
                padding: 20px; 
                border-radius: 8px;  
                box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                font-size: 16px; 
                color: #333; 
                text-align: center;
                ">
                <style>
                    ul, ol {
                    text-align: left !important; /* Lists keep their default alignment */
                    display: inline-block; /* Shrink-wrap the list to keep it centered as a block */
                    margin-left: 0;
                    padding-left: 20px; /* show bullets/numbers properly */
                    text-indent: 0;
                        text-align: center;

                    }
                </style>
                ${message}
                </div>


            <!-- Contact Info -->
            <div style="margin-top: 20px; text-align: center;">
                <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>

                <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
                    Hotline: ${branding.hotline || "[Your Hotline Number]"}
                </p>

                <p style="font-size: 16px;">
                    Website: 
                    <a href="${branding.website_url}" style="color:#1a4e8a; text-decoration: none;">
                        ${branding.website_url}
                    </a>
                </p>
            </div>

            <!-- Footer -->
            <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                <p>Thank you for choosing <strong>${branding.company_name}</strong>. We look forward to a great partnership!</p>
                <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
            </div>
        </div>
        `;

    } catch (error) {
        console.error("Error generating email message:", error.message);
        return null;
    }
}


async function getEmailMsgQuotation(username, message, quotationLink) {
    try {
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        // Create button only if link exists
        const buttonHTML = quotationLink
            ? `<div style="margin:20px 0; text-align:center;">
                    <a href="${quotationLink}" 
                       style="
                           display:inline-block;
                           padding:12px 25px;
                           font-size:16px;
                           color:#ffffff;
                           background-color:#1a4e8a;
                           text-decoration:none;
                           border-radius:6px;
                       ">
                       View Quotation
                    </a>
               </div>`
            : '';

        let processedMessage = message;

        // ✅ Replace placeholder only if exists
        if (processedMessage.includes("[Quo_Button]")) {
            processedMessage = processedMessage.replaceAll(
                "[Quo_Button]",
                buttonHTML
            );
        } else {
            // Remove if exists accidentally
            processedMessage = processedMessage.replaceAll("[Quo_Button]", "");
        }

        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url || ''}" 
                     alt="Logo" 
                     style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1a4e8a; margin: 0;">Quotation Notification</h2>
            </div>

            <div style="
                background:#ffffff; 
                padding:20px; 
                border-radius:8px;  
                box-shadow:0px 4px 12px rgba(0,64,128,0.05);
                font-size:16px; 
                color:#333;
            ">
                ${processedMessage}
            </div>

            <div style="text-align:center; font-size:12px; color:#777; margin-top:30px;">
                <p>Thank you for considering <strong>${branding.company_name || ""}</strong>.</p>
            </div>
        </div>
        `;
    } catch (error) {
        console.error("Error generating quotation email message:", error.message);
        return null;
    }
}




async function getEmailMsgInvoice(username, message, invoiceLink) {
    try {
        // Fetch branding details
        const brandingQuery = await pool.query(
            "SELECT company_name, hotline, logo_url, website_url, support_email FROM branding_settings LIMIT 1"
        );
        const branding = brandingQuery.rows.length > 0 ? brandingQuery.rows[0] : {};

        // Button HTML
        const buttonHTML = invoiceLink
            ? `<a href="${invoiceLink}" 
                  style="
                      display: inline-block;
                      padding: 12px 25px;
                      margin: 20px 0;
                      font-size: 16px;
                      color: #ffffff;
                      background-color: #1a4e8a;
                      text-decoration: none;
                      border-radius: 6px;
                  ">
                  View Invoice
               </a>`
            : '';

        return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #dce6f1; border-radius: 8px; background-color: #f4f8fc;">
            
            <!-- Header Section -->
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url || ''}" 
                     alt="Logo" 
                     style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1a4e8a; margin: 0;">Invoice Notification</h2>
            </div>

            <!-- Main Content -->
            <div style="
                background: #ffffff; 
                padding: 20px; 
                border-radius: 8px;  
                box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                font-size: 16px; 
                color: #333; 
                text-align: center;
            ">
                <style>
                    ul, ol {
                        text-align: left !important; 
                        display: inline-block; 
                        padding-left: 20px; 
                    }
                </style>

                ${message}
                ${buttonHTML}
            </div>

            <!-- Contact Info -->
            <div style="margin-top: 20px; text-align: center;">
                <p style="color: #555; font-size: 14px;">
                    If you have any questions or need assistance regarding your invoice, please contact us:
                </p>

                <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #e6f0fb; padding: 10px; display: inline-block; border-radius: 6px;">
                    Hotline: ${branding.hotline || "N/A"}
                </p>

                <p style="font-size: 16px;">
                    Website:
                    <a href="${branding.website_url || '#'}" style="color:#1a4e8a; text-decoration: none;">
                        ${branding.website_url || ""}
                    </a>
                </p>
            </div>

            <!-- Footer -->
            <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                <p>
                    Thank you for choosing 
                    <strong>${branding.company_name || ""}</strong>.
                </p>
                <p>
                    Warm regards,<br>
                    <strong>${branding.company_name || ""} Team</strong>
                </p>
            </div>
        </div>
        `;
    } catch (error) {
        console.error("Error generating invoice email message:", error.message);
        return null;
    }
}

const getemailsettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                billing_email,
                postmark_server_token
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No email settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching email settings:", error);
        throw error;
    }
};




const sendemailtemp = async (actionId, order_id) => {
    try {

        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 1. Get active email template
        const smsResult = await pool.query(
            "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (smsResult.rows.length === 0) return null;
        const template = smsResult.rows[0];

        // 2. Get order/parcel details
        const parcelResult = await pool.query(
            `SELECT 
                p.order_id AS order_id, 
                p.total_value AS amount, 
                p.recipient_name AS name, 
                p.recipient_contact AS phone, 
                p.recipient_address AS address, 
                p.recipient_city AS city, 
                p.recipient_email AS email,
                p.delivery_type AS delivery_type,
                p.tracking_id AS tracking_id,
                p.delivery_fee AS delivery_fee,
                p.loyalty_points_spent AS loyalty_points_spent,
                p.reason_id as reason_detail,
                c.customer_id,
                c.loyalty_point
            FROM orders p
            LEFT JOIN customer c ON p.customer_id = c.customer_id
            WHERE p.order_id = $1`,
            [order_id]
        );



        if (parcelResult.rows.length === 0) return null;
        const parcel = parcelResult.rows[0];

        // 3. Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] ?? {};

        // 4. Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        const encryptID = encryptId(parcel.order_id)

        // 5. Placeholder replacement
        const orderLink = `${branding.website_url?.replace(/\/$/, '')}/order/${encryptID}`;

        const placeholders = {
            "[first_name]": parcel.name,
            "[name]": parcel.name,
            "[phone]": parcel.phone,
            "[email]": parcel.email,
            "[order_id]": parcel.order_id,
            "[delivery_type]": parcel.delivery_type ?? '',
            "[amount]": parcel.amount,
            "[address]": parcel.address,
            "[city]": parcel.city,
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email,
            "[reason]": parcel.reason_detail || 'N/A',
            "[tracking_id]": parcel.tracking_id ?? '',
            "[delivery_fee]": parcel.delivery_fee ?? '',
            "[invoice_link]": orderLink,  // ✅ Add this
            "[order_link]": orderLink,    // ✅ Optional alias
            "[all_points]": parcel.loyalty_point ?? '0',
            "[spending_points]": parcel.loyalty_points_spent ?? '0',
        };


        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 6. Generate HTML email body
        const emailHTML = await getEmailMsg(parcel.name, finalMessage);

        // 7. Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            const adminSettings = await pool.query(
                "SELECT notification_emails FROM system_settings LIMIT 1"
            );

            let rawEmails = adminSettings.rows[0]?.notification_emails;
            let adminEmails = [];

            if (typeof rawEmails === 'string') {
                adminEmails = rawEmails.split(',').map(e => e.trim());
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            } else {
                console.warn("⚠️ notification_emails is not a string or array:", rawEmails);
            }

            for (const email of adminEmails) {
                try {
                    const emailResponse = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );
                    console.log(`✅ Email sent to admin: ${email}`, emailResponse);
                    await insertemaillog(email, finalMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed to send email to admin: ${email}`, err);
                }
            }
        }

        // 8. Client Email
        if (template.client === 'Yes' && billing_email && postmark_token) {
            try {
                const clientEmailResponse = await sendEmailWithPostmark(
                    parcel.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );
                console.log(`✅ Email sent to client: ${parcel.email}`, clientEmailResponse);
                await insertemaillog(parcel.email, finalMessage, template.subject, actionId);

            } catch (err) {
                console.error(`❌ Failed to send email to client: ${parcel.email}`, err);
            }
        }

        // 9. Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            parcelDetails: parcel,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp:", error);
        return null;
    }
};

const sendemailtemp_user_register = async (actionId, order_id) => {
    try {
        // ✔ Just assign order_id as customer_id
        const customer_id = order_id;
        const password = 'guest123';

        // 1. Check global email status
        const globalstatus = await pool.query(
            "SELECT email_notification_status FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2. Get active email template
        const emailResult = await pool.query(
            "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (emailResult.rows.length === 0) return null;
        const template = emailResult.rows[0];

        // 3. Get customer details
        const customerResult = await pool.query(
            `SELECT 
                customer_id,
                first_name,
                last_name,
                contact_number_1 AS phone,
                email
            FROM customer
            WHERE customer_id = $1`,
            [customer_id]
        );

        if (customerResult.rows.length === 0) return null;
        const customer = customerResult.rows[0];

        // 4. Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const branding = brandingResult.rows[0] ?? {};

        // 5. Get email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6. Placeholder replacements
        const placeholders = {
            "[first_name]": customer.first_name,
            "[name]": `${customer.first_name} ${customer.last_name}`,
            "[phone]": customer.phone,
            "[email]": customer.email,
            "[Username]": customer.email,

            "[Hotline]": branding.hotline ?? "",
            "[Webname]": branding.company_name ?? "",
            "[company_email]": branding.support_email ?? "",
            "[Password]": password ?? ""  // ✔ matches SMS version
        };

        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7. Generate HTML body
        const emailHTML = await getEmailMsg(customer.first_name, finalMessage);

        // 8. Send Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            const adminQuery = await pool.query(
                "SELECT notification_emails FROM system_settings LIMIT 1"
            );

            let rawEmails = adminQuery.rows[0]?.notification_emails ?? [];
            let adminEmails = [];

            if (typeof rawEmails === "string") {
                adminEmails = rawEmails.split(",").map(e => e.trim());
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            }

            for (const email of adminEmails) {
                try {
                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );

                    console.log(`✔ Admin email sent: ${email}`);
                    await insertemaillog(email, finalMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed admin email: ${email}`, err);
                }
            }
        }

        // 9. Send Client Email
        if (template.client === 'Yes' && billing_email && postmark_token) {
            try {
                const response = await sendEmailWithPostmark(
                    customer.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );

                console.log(`✔ Client email sent: ${customer.email}`);
                await insertemaillog(customer.email, finalMessage, template.subject, actionId);

            } catch (err) {
                console.error(`❌ Failed client email: ${customer.email}`, err);
            }
        }

        // Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            customerDetails: customer,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp:", error);
        return null;
    }
};


const customhook = async (actionId, order_id) => {
    try {
        // Do nothing for quotation & invoice
        if (actionId === 11 || actionId === 12) {
            return {
                sms: null,
                email: null,
                sms_user_register: null,
                email_user_register: null
            };
        }

        let ressms = null;
        let resemail = null;
        let ressms_user_register = null;
        let resemail_user_register = null;
        let invoice_link_sms = null;
        let invoice_link_email = null;

        // User register
        if (actionId === 8 || actionId === 9) {
            ressms_user_register =
                await sendsmstemp_user_register(actionId, order_id);
            resemail_user_register =
                await sendemailtemp_user_register(actionId, order_id);
        } else if (actionId === 13) {
            console.log("invoice link sms checking")
            invoice_link_sms = await sendsm_invoice_link(actionId, order_id);
            invoice_link_email = await sendemailtemp_invoice_link(actionId, order_id);

        } else {
            ressms = await sendsmstemp(actionId, order_id);
            resemail = await sendemailtemp(actionId, order_id);
        }

        return {
            sms: ressms,
            email: resemail,
            sms_user_register: ressms_user_register,
            email_user_register: resemail_user_register,
            invoice_link_sms: invoice_link_sms,
            invoice_link_email: invoice_link_email
        };

    } catch (error) {
        console.error("Error in customhook:", error);
        throw error;
    }
};


const sendsmstemp_quotation = async (actionId, quotation_id, customer_mobile) => {
    try {
        // 1️⃣ Check if SMS notifications are enabled globally
        const globalStatusResult = await pool.query(
            "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
        );
        const globalStatus = globalStatusResult.rows[0];

        if (globalStatus?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

        // 2️⃣ Fetch SMS template for this action
        const smsTemplateResult = await pool.query(
            "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!smsTemplateResult.rows.length) {
            console.log("No active SMS template found for this action.");
            return null;
        }

        const template = smsTemplateResult.rows[0];

        // 3️⃣ Fetch quotation details
        const quotationResult = await pool.query(
            `SELECT q.*, c.first_name, c.last_name, c.contact_number_1 AS phone, c.email
             FROM quotation_header q
             LEFT JOIN customer c ON q.customer_id = c.customer_id
             WHERE q.id = $1`,
            [quotation_id]
        );

        if (!quotationResult.rows.length) {
            console.log("No quotation found for this ID:", quotation_id);
            return null;
        }

        const quotation = quotationResult.rows[0];

        // 4️⃣ Fetch branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};
        const branding = {
            company_name: brandingRow.company_name || '',
            hotline: brandingRow.hotline || '',
            support_email: brandingRow.support_email || ''
        };

        // 5️⃣ Fetch SMS API settings
        const settings = await getsmssettings();
        const sms_user_id = settings?.sms_user_id || '';
        const sms_api_key = settings?.sms_api_key || '';
        const sms_sender_id = settings?.sms_sender_id || '';
        const sms_api_endpoint = settings?.sms_api_endpoint || '';

        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": quotation.first_name || '',
            "[name]": quotation.first_name || '',
            "[phone]": quotation.phone || '',
            "[email]": quotation.email || '',
            "[Quo_Link]": quotation.quotation_link || '',
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email
        };

        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, value.toString());
        }

        // 7️⃣ Send SMS to admin if configured
        if (template.admin === 'Yes') {
            const rawPhones = String(globalStatus.notification_mobile_numbers || '');
            const adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);



            for (const phone of adminPhones) {
                try {
                    if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {
                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );
                        console.log(`SMS sent to admin: ${phone}`, smsResponse);
                        await insertsmslog(phone, finalMessage, actionId);
                    } else {
                        console.warn("Missing SMS API settings. Cannot send admin SMS.");
                    }
                } catch (err) {
                    console.error("Failed to send admin SMS:", err);
                }
            }
        }

        // 8️⃣ Send SMS to client if configured
        if (template.client === 'Yes') {
            try {
                if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {
                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        customer_mobile,
                        sms_api_endpoint
                    );
                    console.log(`SMS sent to client: ${customer_mobile}`, smsResponse);
                    await insertsmslog(customer_mobile, finalMessage, actionId);
                } else {
                    console.warn("Missing SMS API settings. Cannot send client SMS.");
                }
            } catch (err) {
                console.error("Failed to send client SMS:", err);
            }
        }

        // 9️⃣ Return final info
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            quotationDetails: quotation,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_quotation:", error);
        return null;
    }
};

const sendemailtemp_quotation = async (actionId, quotation_id, customer_email) => {
    try {
        // 1️⃣ Check email notifications
        const globalstatus = await pool.query(
            "SELECT email_notification_status, notification_emails FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2️⃣ Get active email template
        const templateResult = await pool.query(
            "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (templateResult.rows.length === 0) return null;
        const template = templateResult.rows[0];

        // 3️⃣ Fetch quotation and customer details
        const quotationResult = await pool.query(
            `SELECT q.*, c.first_name, c.last_name, c.contact_number_1 AS phone, c.email
             FROM quotation_header q
             LEFT JOIN customer c ON q.customer_id = c.customer_id
             WHERE q.id = $1`,
            [quotation_id]
        );

        if (quotationResult.rows.length === 0) return null;
        const quotation = quotationResult.rows[0];

        // 4️⃣ Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] ?? {};

        // 5️⃣ Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": quotation.first_name || '',
            "[name]": quotation.first_name || '',
            "[phone]": quotation.phone || '',
            "[email]": quotation.email || '',
            "[Quo_Link]": quotation.quotation_link || '',
            // "[Quo_Button]": quotation.quotation_link || '',

            "[Hotline]": branding.hotline || '',
            "[Webname]": branding.company_name || '',
            "[company_email]": branding.support_email || ''
        };

        // let finalMessage = template.msg;
        // for (const [key, value] of Object.entries(placeholders)) {
        //     finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        // }
        let finalMessage = template.msg;

        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }


        // 7️⃣ Generate HTML email body
        // When generating HTML
        const emailHTML = await getEmailMsgQuotation(
            quotation.first_name,
            finalMessage,
            quotation.quotation_link
        );


        // 8️⃣ Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            let adminEmails = [];
            const rawEmails = globalstatus.rows[0]?.notification_emails;

            if (typeof rawEmails === 'string') {
                adminEmails = rawEmails.split(',').map(e => e.trim()).filter(Boolean);
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim()).filter(Boolean);
            }

            for (const email of adminEmails) {
                try {
                    const response = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );
                    console.log(`✅ Email sent to admin: ${email}`, response);
                    const logMessage = finalMessage.replaceAll("[Quo_Button]", "");

                    await insertemaillog(email, logMessage, template.subject, actionId);

                } catch (err) {
                    console.error(`❌ Failed to send email to admin: ${email}`, err);
                }
            }
        }

        // 9️⃣ Client Email
        if (template.client === 'Yes' && billing_email && postmark_token && quotation.email) {
            try {
                const response = await sendEmailWithPostmark(
                    customer_email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );
                console.log(`✅ Email sent to client: ${customer_email}`, response);
                await insertemaillog(customer_email, finalMessage, template.subject, actionId);
            } catch (err) {
                console.error(`❌ Failed to send email to client: ${customer_email}`, err);
            }
        }

        // 10️⃣ Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            quotationDetails: quotation,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp_quotation:", error);
        return null;
    }
};


const customhookQuotation = async (actionId, quotation_id, customer_mobile, customer_email) => {
    try {
        let ressms = null;
        let resemail = null;

        // Only run for quotation action
        if (actionId === 11) {
            ressms = await sendsmstemp_quotation(actionId, quotation_id, customer_mobile);
            resemail = await sendemailtemp_quotation(actionId, quotation_id, customer_email);
        }

        return {
            sms: ressms,
            email: resemail
        };

    } catch (error) {
        console.error("Error in customhookQuotation:", error);
        throw error;
    }
};


const sendsmstemp_invoice = async (actionId, invoice_id) => {
    try {
        // 1️⃣ Check global SMS status
        const globalstatus = await pool.query(
            "SELECT sms_notification_status, notification_mobile_numbers FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.sms_notification_status !== 'enabled') {
            console.log("SMS notifications are disabled.");
            return null;
        }

        console.log(`Fetching SMS template for actionId: ${actionId}`);

        // 2️⃣ Get SMS template
        const smsResult = await pool.query(
            "SELECT msg, admin, client FROM sms_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!smsResult.rows.length) {
            console.log("No active SMS template found.");
            return null;
        }

        const template = smsResult.rows[0];

        // 3️⃣ Get invoice details
        console.log(`Fetching invoice details for invoice_id: ${invoice_id}`);
        const invoiceResult = await pool.query(
            `SELECT i.*, c.first_name, c.last_name, c.contact_number_1 AS phone, c.email
             FROM invoice_header i
             LEFT JOIN customer c ON i.customer_id = c.customer_id
             WHERE i.id = $1`,
            [invoice_id]
        );

        if (!invoiceResult.rows.length) {
            console.log("No invoice found for this ID:", invoice_id);
            return null;
        }

        const invoice = invoiceResult.rows[0];

        // 4️⃣ Get branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );

        const brandingRow = brandingResult.rows[0] || {};
        const branding = {
            company_name: brandingRow.company_name ?? '',
            hotline: brandingRow.hotline ?? '',
            support_email: brandingRow.support_email ?? '',
            website_url: brandingRow.website_url ?? ''
        };

        // 5️⃣ Get SMS API settings
        const settings = await getsmssettings();
        const sms_user_id = settings?.sms_user_id ?? '';
        const sms_api_key = settings?.sms_api_key ?? '';
        const sms_sender_id = settings?.sms_sender_id ?? '';
        const sms_api_endpoint = settings?.sms_api_endpoint ?? '';

        // 6️⃣ Prepare placeholders (using [Inv_Link])
        const placeholders = {
            "[name]": invoice.first_name || '',
            "[phone]": invoice.phone || '',
            "[email]": invoice.email || '',
            "[Hotline]": branding.hotline,
            "[Webname]": branding.company_name,
            "[company_email]": branding.support_email,
            "[Inv_Link]": invoice.invoice_link || ''  // ✅ Directly from invoice_header
        };

        // Replace placeholders in template
        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7️⃣ Send SMS to admin
        if (template.admin === 'Yes') {
            const rawPhones = globalstatus.rows[0]?.notification_mobile_numbers || '';
            let adminPhones = [];

            if (typeof rawPhones === 'string') {
                adminPhones = rawPhones.split(',').map(p => p.trim()).filter(Boolean);
            } else if (Array.isArray(rawPhones)) {
                adminPhones = rawPhones;
            }

            if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint && adminPhones.length > 0) {
                for (const phone of adminPhones) {
                    try {
                        const smsResponse = await send_sms(
                            sms_user_id,
                            sms_api_key,
                            sms_sender_id,
                            finalMessage,
                            phone,
                            sms_api_endpoint
                        );
                        console.log(`SMS sent to admin: ${phone}`, smsResponse);
                        await insertsmslog(phone, finalMessage, actionId);
                    } catch (err) {
                        console.error(`Failed to send SMS to admin: ${phone}`, err);
                    }
                }
            } else {
                console.warn("Missing SMS API settings or no admin phones configured.");
            }
        }

        // 8️⃣ Send SMS to client
        if (template.client === 'Yes') {
            if (sms_user_id && sms_api_key && sms_sender_id && sms_api_endpoint) {
                try {
                    const smsResponse = await send_sms(
                        sms_user_id,
                        sms_api_key,
                        sms_sender_id,
                        finalMessage,
                        invoice.phone,
                        sms_api_endpoint
                    );
                    console.log(`SMS sent to client: ${invoice.phone}`, smsResponse);
                    await insertsmslog(invoice.phone, finalMessage, actionId);
                } catch (err) {
                    console.error(`Failed to send SMS to client: ${invoice.phone}`, err);
                }
            } else {
                console.error("Missing SMS API settings. Cannot send SMS to client.");
            }
        }

        // 9️⃣ Return final info
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            invoiceDetails: invoice,
            branding
        };

    } catch (error) {
        console.error("Error in sendsmstemp_invoice:", error);
        return null;
    }
};


const sendemailtemp_invoice = async (actionId, invoice_id) => {
    try {
        // 1️⃣ Check email notifications
        const globalstatus = await pool.query(
            "SELECT email_notification_status, notification_emails FROM system_settings LIMIT 1"
        );

        if (globalstatus.rows[0]?.email_notification_status !== 'enabled') {
            console.log("Email notifications are disabled.");
            return null;
        }

        // 2️⃣ Get active email template
        const templateResult = await pool.query(
            "SELECT msg, admin, client, subject FROM email_template WHERE action = $1 AND status = 'Active'",
            [actionId]
        );

        if (!templateResult.rows.length) return null;
        const template = templateResult.rows[0];

        // 3️⃣ Fetch invoice and customer details
        const invoiceResult = await pool.query(
            `SELECT i.*, c.first_name, c.last_name, c.contact_number_1 AS phone, c.email
             FROM invoice_header i
             LEFT JOIN customer c ON i.customer_id = c.customer_id
             WHERE i.id = $1`,
            [invoice_id]
        );

        if (!invoiceResult.rows.length) return null;
        const invoice = invoiceResult.rows[0];

        // 4️⃣ Branding info
        const brandingResult = await pool.query(
            "SELECT company_name, hotline, support_email, website_url FROM branding_settings LIMIT 1"
        );
        const branding = brandingResult.rows[0] ?? {};

        // 5️⃣ Email settings
        const settings = await getemailsettings();
        const billing_email = settings?.billing_email;
        const postmark_token = settings?.postmark_server_token;

        // 6️⃣ Replace placeholders
        const placeholders = {
            "[first_name]": invoice.first_name || '',
            "[name]": invoice.first_name || '',
            "[phone]": invoice.phone || '',
            "[email]": invoice.email || '',
            "[Inv_Link]": invoice.invoice_link || '', // ✅ Invoice link from invoice_header

            "[Hotline]": branding.hotline || '',
            "[Webname]": branding.company_name || '',
            "[company_email]": branding.support_email || ''
        };

        let finalMessage = template.msg;
        for (const [key, value] of Object.entries(placeholders)) {
            finalMessage = finalMessage.replaceAll(key, (value ?? '').toString());
        }

        // 7️⃣ Generate HTML email body (you can customize this function)
        const emailHTML = await getEmailMsgInvoice(
            invoice.first_name,
            finalMessage,
            placeholders["[Inv_Link]"] // URL for button or link
        );

        // 8️⃣ Admin Emails
        if (template.admin === 'Yes' && billing_email && postmark_token) {
            let rawEmails = globalstatus.rows[0]?.notification_emails;
            let adminEmails = [];

            if (typeof rawEmails === 'string') {
                adminEmails = rawEmails.split(',').map(e => e.trim()).filter(Boolean);
            } else if (Array.isArray(rawEmails)) {
                adminEmails = rawEmails.map(e => e.trim());
            } else {
                console.warn("⚠️ notification_emails is not a string or array:", rawEmails);
            }

            for (const email of adminEmails) {
                try {
                    const emailResponse = await sendEmailWithPostmark(
                        email,
                        template.subject,
                        emailHTML,
                        postmark_token,
                        billing_email
                    );
                    console.log(`✅ Email sent to admin: ${email}`, emailResponse);
                    await insertemaillog(email, finalMessage, template.subject, actionId);
                } catch (err) {
                    console.error(`❌ Failed to send email to admin: ${email}`, err);
                }
            }
        }

        // 9️⃣ Client Email
        if (template.client === 'Yes' && billing_email && postmark_token) {
            try {
                const clientEmailResponse = await sendEmailWithPostmark(
                    invoice.email,
                    template.subject,
                    emailHTML,
                    postmark_token,
                    billing_email
                );
                console.log(`✅ Email sent to client: ${invoice.email}`, clientEmailResponse);
                await insertemaillog(invoice.email, finalMessage, template.subject, actionId);
            } catch (err) {
                console.error(`❌ Failed to send email to client: ${invoice.email}`, err);
            }
        }

        // 🔟 Final return
        return {
            message: finalMessage,
            sendToAdmin: template.admin === 'Yes',
            sendToClient: template.client === 'Yes',
            invoiceDetails: invoice,
            branding
        };

    } catch (error) {
        console.error("❌ Error in sendemailtemp_invoice:", error);
        return null;
    }
};


const customhookInvoice = async (actionId, invoice_id) => {
    try {
        let ressms = null;
        let resemail = null;

        // Only run for invoice action
        if (actionId === 12) {
            ressms = await sendsmstemp_invoice(actionId, invoice_id);
            resemail = await sendemailtemp_invoice(actionId, invoice_id);
        }

        return {
            sms: ressms,
            email: resemail
        };

    } catch (error) {
        console.error("Error in customhookInvoice:", error);
        throw error;
    }
};





module.exports = { send_sms, sendsmstemp, sendemailtemp, customhook, customhookQuotation, customhookInvoice };

