const pool = require("../config/db");
const https = require("https");
const axios = require("axios");


const getSmsSettings = async () => {
    try {
        const result = await pool.query(`
            SELECT 
                sms_gateway_name,
                sms_user_id,
                sms_sender_id,
                sms_api_endpoint,
                sms_api_key,
                postmark_server_token
            FROM system_settings
            LIMIT 1
        `);

        if (result.rows.length === 0) {
            console.log(" No SMS settings found in system_settings table.");
            return null;
        }

        return result.rows[0]; // Return settings as an object
    } catch (error) {
        console.error(" Error fetching SMS settings:", error);
        throw error;
    }
};



function send_sms(client_id, api_key, sender_id, message, recipient_contact_no, sms_api_endpoint) {
    return new Promise((resolve, reject) => {
        // Extract hostname from API endpoint
        const url = new URL(sms_api_endpoint);
        const hostname = url.hostname;
        const path = `/v1/send/?user_id=${encodeURIComponent(client_id)}&api_key=${encodeURIComponent(api_key)}&sender_id=${encodeURIComponent(sender_id)}&message=${encodeURIComponent(message)}&recipient_contact_no=${encodeURIComponent(recipient_contact_no)}`;

        const options = {
            method: "GET",
            hostname: hostname,
            path: path,
            headers: {},
            maxRedirects: 20
        };

        const req = https.request(options, (res) => {
            let chunks = [];

            res.on("data", (chunk) => {
                chunks.push(chunk);
            });

            res.on("end", () => {
                const body = Buffer.concat(chunks).toString();
                try {
                    resolve(JSON.parse(body));
                } catch (error) {
                    resolve(body);
                }
            });

            res.on("error", (error) => {
                console.error("SMS API Error:", error);
                reject(error);
            });
        });

        req.end();
    });
}

async function sendEmailWithPostmark(to, subject, message, apiToken) {
    const fromEmail = "hi@simpleexpress.lk"; // Replace with your verified sender email

    if (!apiToken) {
        console.error("Error: Postmark API token is missing.");
        return "Postmark API token is not configured.";
    }

    const postData = {
        "From": fromEmail,
        "To": to,
        "Subject": subject,
        "HtmlBody": message,
        "MessageStream": "outbound" // Default message stream for transactional emails
    };

    try {
        const response = await axios.post("https://api.postmarkapp.com/email", postData, {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        });

        console.log("Email sent successfully:", response.data);
        return response.data; // Return full Postmark response
    } catch (error) {
        console.error("Error sending email:", error.response ? error.response.data : error.message);
        return `Error sending email: ${error.response ? JSON.stringify(error.response.data) : error.message}`;
    }
}


function getDbUploadEmail(file_url) {
    try {
      const logo = 'https://d8y1.c2.e2-9.dev/spark-files/1741858203213-20250313093003-Compsssany_Logo.png';
      const dateTime = new Date().toLocaleString('en-GB', { timeZone: 'Asia/Colombo' });
  
      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #f4f4f4;">
          <!-- Header Section -->
          <div style="text-align: center; padding: 20px 0;">
            <img src="${logo}" alt="Simple Express Logo" style="max-width: 150px; margin-bottom: 10px;">
          </div>
          <h2 style="color: #333; text-align: center;">DB backup uploaded</h2>
          <div style="background: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.05);">
            <p style="color: #555; font-size: 16px;"><strong>File URL:</strong> <a href="${file_url}" target="_blank">${file_url}</a></p>
            <p style="color: #555; font-size: 16px;"><strong>Date & Time:</strong> ${dateTime}</p>
          </div>
          <p style="text-align: center; font-size: 12px; color: #888; margin-top: 20px;">© ${new Date().getFullYear()} Simple Express. All rights reserved.</p>
        </div>
      `;
    } catch (error) {
      console.error("Error generating email message:", error.message);
      return null;
    }
  }


async function getadminSmsMessages(client_id) {
    try {
        // Fetch client details
        const clientQuery = await pool.query(
            "SELECT id, first_name, last_name, mobile, business_name, agent_id FROM clients WHERE id = $1",
            [client_id]
        );

        if (clientQuery.rows.length === 0) {
            throw new Error("Client not found");
        }

        const client = clientQuery.rows[0];

        // Fetch agent details
        const agentQuery = await pool.query(
            "SELECT first_name, last_name FROM admin_user WHERE id = $1",
            [client.agent_id]
        );

        const agent = agentQuery.rows.length > 0 ? agentQuery.rows[0] : { first_name: "Unknown", last_name: "" };

        // Shortened SMS message (Under 160 characters)
        return `New Registration - ID: ${client.id}, Name: ${client.first_name} ${client.last_name}, Mobile: ${client.mobile}, Business: ${client.business_name}, Agent: ${agent.first_name} ${agent.last_name} (ID: ${client.agent_id})`;
        
    } catch (error) {
        console.error("Error generating SMS message:", error.message);
        return null;
    }
}
  

// Example Usage:







module.exports = { getSmsSettings, send_sms,sendEmailWithPostmark, getDbUploadEmail, getadminSmsMessages };
