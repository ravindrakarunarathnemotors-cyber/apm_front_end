const https = require("https");
const pool = require("../config/db");
const axios = require("axios");

const insertemaillog = async (email, msg, subject, action) => {
    const insertQuery = `
        INSERT INTO send_email_temp_log
        (email, msg, status, date, sentdate, action, subject)
        VALUES ($1, $2, 'Sent', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, $3, $4)
        RETURNING id;
    `;

    const result = await pool.query(insertQuery, [
        email,
        msg,
        action,
        subject
    ]);

    return result.rows[0];
};

/* ===============================
   SEND EMAIL VIA POSTMARK
================================ */
async function sendEmailWithPostmark(to, subject, message, apiToken, fromEmail) {
    const postData = {
        From: fromEmail,
        To: to,
        Subject: subject,
        HtmlBody: message,
        MessageStream: "outbound"
    };

    const response = await axios.post(
        "https://api.postmarkapp.com/email",
        postData,
        {
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Postmark-Server-Token": apiToken
            }
        }
    );

    return response.data;
}

/* ===============================
   EMAIL TEMPLATE
================================ */
async function getEmailMsg(content, quotationUrl) {
    const brandingQuery = await pool.query(
        "SELECT company_name, hotline, logo_url FROM branding_settings LIMIT 1"
    );

    const branding = brandingQuery.rows[0] ?? {};

      return `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #DCE6F1; border-radius: 8px; background-color: #F4F8FC;">
            <!-- Header Section -->
            <div style="text-align: center; padding: 20px 0;">
                <img src="${branding.logo_url}" alt="Logo" style="max-width: 150px; margin-bottom: 10px;">
                <h2 style="color: #1A4E8A; margin: 0;">Quotation Sent</h2>
            </div>
            <!-- Main Content -->
            <div style="
                background: #FFFFFF;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0px 4px 12px rgba(0, 64, 128, 0.05);
                font-size: 16px;
                color: #333;
                text-align: center;
            ">
                <p style="margin-bottom: 10px;">Hello ${content},</p>
                <p style="margin-bottom: 20px;">
            Thank you for your interest in <strong>${branding.company_name}</strong>.
            Your quotation has been successfully prepared.Your quotation is ready. View here::
        </p>
               
          <a
  href="${quotationUrl}"
  target="_blank"
  style="
    display: inline-block;
    padding: 12px 24px;
    background-color: #1A4E8A;
    color: #ffffff;
    text-decoration: none;
    font-size: 16px;
    font-weight: bold;
    border-radius: 6px;
    margin-top: 10px;
  "
>
  View Quotation
</a>
 






                
               
            </div>
            <!-- Contact Info -->
            <div style="margin-top: 20px; text-align: center;">
                <p style="color: #555; font-size: 14px;">If you have any questions or need assistance, please don't hesitate to contact us:</p>
                <p style="font-size: 16px; font-weight: bold; color:#1a4e8a; background: #E6F0FB; padding: 10px; display: inline-block; border-radius: 6px;">
                    Hotline: ${branding.hotline || "[Your Hotline Number]"}
                </p>
                
            </div>
            <!-- Footer -->
            <div style="text-align: center; font-size: 12px; color: #777; margin-top: 30px;">
                <p>Thank you for choosing <strong>${branding.company_name}</strong>.</p>
                <p>Warm regards, <br> <strong>${branding.company_name} Team</strong></p>
            </div>
        </div>
        `;
}

/* ===============================
   GET EMAIL SETTINGS
================================ */
const getemailsettings = async () => {
    const result = await pool.query(`
        SELECT billing_email, postmark_server_token
        FROM system_settings
        LIMIT 1
    `);

    return result.rows[0] ?? null;
};

/* ===============================
   MAIN EMAIL FUNCTION
================================ */
const sendemailtemp = async (
    customer_name,
    message,
    subject,
    toEmail
) => {
    try {
        if (!toEmail) return null;

        const settings = await getemailsettings();
        if (!settings) return null;

        const emailHTML = await getEmailMsg(
            customer_name,
            message
        );

        await sendEmailWithPostmark(
            toEmail,
            subject,
            emailHTML,
            settings.postmark_server_token,
            settings.billing_email
        );

        await insertemaillog(
            toEmail,
            message,
            subject,
            "quotation_send"
        );

        return true;

    } catch (error) {
        console.error("❌ sendemailtemp error:", error);
        return null;
    }
};


module.exports = { sendemailtemp };