const pool = require("../config/db");

const insertAdminLog = async ( user_id, module, log) => {
  try {
    const query = `
      INSERT INTO admin_log (user_id, module, log, date) 
      VALUES ($1, $2, $3, NOW())`;
    
    await pool.query(query, [user_id, module, log]);
    console.log(`User Log Added: ${module} - ${log}`);
  } catch (error) {
    console.error("Error inserting user log:", error);
  }
};


const insertSystemLog = async (user_id, module, log) => {
  try {
    const query = `
      INSERT INTO system_log (user_id, module, log, "date")
      VALUES ($1, $2, $3, NOW())
    `;
    console.debug(`[SystemLog] preparing insert → user=${user_id}, module=${module}, log=${log}`);
    const result = await pool.query(query, [user_id, module, log]);
    console.debug(`[SystemLog] query result: rowCount=${result.rowCount}`);
    console.log(`[SystemLog] inserted: ${module} - ${log} (user ${user_id})`);
  } catch (error) {
    console.error("Error inserting system log:", error);
  }
};


const insertemployeeLogs = async (employee_id,user_id, module, comments) => {
  try {
    const query = `
      INSERT INTO employee_logs 
      (employee_id,user_id, module, comments, log_date)
      VALUES ($1, $2, $3,$4, NOW())
    `;
    console.debug(`[employeeLogs] preparing insert → employee=${employee_id}user=${user_id}, module=${module}, comments=${comments}`);
    
    const result = await pool.query(query, [
      employee_id,user_id, module, comments]);

    console.debug(`[employeeLogs] query result: rowCount=${result.rowCount}`);
    console.log(`[employeeLogs] inserted: ${module} - ${comments} (user ${user_id}) (employee ${employee_id})`);
  } catch (error) {
    console.error("Error inserting employee logs:", error);
  }
};

const insertJobLog = async (job_id, action, description, performed_by, user_id) => {
  try {
    const query = `
      INSERT INTO job_log
      (job_id, action, description, performed_by, user_id, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
    `;

    console.debug(`[jobLog] preparing insert → job=${job_id}, action=${action}, performed_by=${performed_by}, user=${user_id}, description=${description}`);

    const result = await pool.query(query, [
      job_id,
      action,
      description,
      performed_by,
      user_id
    ]);

    console.debug(`[jobLog] query result: rowCount=${result.rowCount}`);
    console.log(`[jobLog] inserted: action='${action}' by '${performed_by}' on job ${job_id} (user ${user_id})`);
    
  } catch (error) {
    console.error (`[jobLog] Error inserting job log for job ${job_id}:`, error.message);
    console.error("Error inserting job log:", error);
  }
};





module.exports = {insertAdminLog, insertSystemLog,insertemployeeLogs,insertJobLog};