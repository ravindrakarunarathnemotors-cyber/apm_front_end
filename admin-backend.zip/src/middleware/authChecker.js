// ozb_Backend/src/middleware/authChecker.js
const express = require('express');
const pool = require('../config/db');
const authenticateToken = require('./authMiddleware');

const router = express.Router();

router.get('/role-allowed-urls', authenticateToken, async (req, res) => {

  const user = req.user
  const role_id = user.role_id; // Get role_id from authenticated user
  if (!role_id) {
    return res.status(400).json({ message: 'role_id is required' });
  }

  try {
    // Step 1: derive IDs from privileges
    const idsResult = await pool.query(
      `
      WITH priv AS (
        SELECT unnest(COALESCE(rl.privileges, '{}'::text[])) AS raw_pid
        FROM role_list rl
        WHERE rl.id = $1
          AND rl.status = 'active'
      )
      SELECT DISTINCT
             NULLIF(regexp_replace(raw_pid, '\\D+', '', 'g'), '')::int AS id
      FROM priv
      WHERE regexp_replace(raw_pid, '\\D+', '', 'g') <> ''
      `,
      [role_id]
    );

    const derivedIds = idsResult.rows.map(r => r.id).filter(Boolean);
    // console.log(`[AuthChecker] Role ${role_id} derived privilege IDs:`, derivedIds);
    console.log(`Role ${role_id} derived privilege IDs:`, derivedIds);

    // Step 2: fetch routes for those IDs
    const { rows } = await pool.query(
      `
      SELECT DISTINCT u.route
      FROM uimenudata u
      WHERE u.id = ANY($1::int[])
      ORDER BY u.route ASC;
      `,
      [derivedIds]
    );

    const urls = rows.map(r => r.route); // includes "#" and nulls
    // console.log(`[AuthChecker] Role ${role_id} routes:`, urls);

    return res.status(200).json({ urls }); // ✅ Only return urls
  } catch (err) {
    console.error('Error fetching allowed URLs:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Optional health check
router.get('/ping', (_req, res) => res.json({ ok: true }));

module.exports = router;
