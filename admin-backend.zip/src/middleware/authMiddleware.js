const jwt = require("jsonwebtoken");
const pool = require("../config/db");

const authenticateToken = (req, res, next) => {
  console.log("Cookies:", req.cookies);

  const token = req.cookies?.access_token;

  if (!token) {
    console.log("NO ACCESS TOKEN");

    return res.status(401).json({
      message: "Access token required",
    });
  }

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, async (err, user) => {
    if (err) {
      console.log("JWT ERROR:", err.message);

      return res.status(403).json({
        message: "Access token expired or invalid",
      });
    }

    console.log("AUTH USER:", user.user_id);

    try {
      const result = await pool.query(
        `
        SELECT status
        FROM users
        WHERE user_id = $1
        LIMIT 1
        `,
        [user.user_id],
      );

      console.log("DB STATUS:", result.rows[0]?.status);

      if (result.rows.length === 0) {
        return res.status(401).json({
          message: "User not found",
          logout: true,
        });
      }

      if (result.rows[0].status === "Inactive") {
        return res.status(401).json({
          message: "Account has been deactivated",
          logout: true,
        });
      }

      req.user = user;
      next();
    } catch (error) {
      console.error("Auth middleware error:", error);

      return res.status(500).json({
        message: "Authentication check failed",
      });
    }
  });
};

module.exports = authenticateToken;
