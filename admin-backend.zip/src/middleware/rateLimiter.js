const { rateLimit, ipKeyGenerator } = require("express-rate-limit");

/**
 * Reusable rate limiter factory
 */
const createRateLimiter = ({
  windowMs = 15 * 60 * 1000,
  max = 5,
  message = "Too many requests, please try again later.",
  keyGenerator,
}) => {
  return rateLimit({
    windowMs,
    max,

    standardHeaders: true,
    legacyHeaders: false,

    keyGenerator: keyGenerator || ((req) => ipKeyGenerator(req.ip)),

    handler: (req, res) => {
      const retryAfterSeconds = Math.max(
        0,
        Math.ceil(
          (new Date(req.rateLimit.resetTime).getTime() - Date.now()) / 1000,
        ),
      );

      return res.status(429).json({
        ok: false,
        message,

        // raw seconds for frontend countdown
        retry_after_seconds: retryAfterSeconds,

        // exact unlock timestamp
        retry_after_timestamp: new Date(
          Date.now() + retryAfterSeconds * 1000,
        ).toISOString(),
      });
    },
  });
};

module.exports = createRateLimiter;
