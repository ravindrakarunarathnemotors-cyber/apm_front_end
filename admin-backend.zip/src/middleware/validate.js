// src/middleware/validate.js
const { log } = require('../util/log');

const validate = (schema, source = 'body') => (req, res, next) => {
  const { error, value } = schema.validate(req[source], {
    abortEarly:    false,  // return ALL errors at once
    stripUnknown:  true,   // remove fields not in schema
  });

  if (error) {
    log.warn(
      { path: req.path, errors: error.details.map(d => d.message) },
      'Request validation failed'
    );
    return res.status(400).json({
      message: 'Validation failed',
      errors:  error.details.map(d => ({
        field:   d.context?.label ?? d.path.join('.'),
        message: d.message.replace(/['"]/g, ''),
      })),
    });
  }

  req[source] = value; // use the coerced/stripped value
  next();
};

module.exports = { validate };