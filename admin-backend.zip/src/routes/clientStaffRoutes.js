const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const pool = require("../config/db");
const { formatPhoneNumber } = require("../models/authModels")
const { insertAdminLog } = require("../models/userLogs");

const bcrypt = require("bcrypt");


const router = express.Router();


router.get("/client-staff", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        users.*, 
        role_list.role_name,
        o.name AS outlet_name,
        users.outlet_id
      FROM users
      JOIN role_list ON users.role_id = role_list.id
      LEFT JOIN outlets o ON users.outlet_id = o.outlet_id
      ORDER BY users.user_id DESC
    `);
    // console.log("rowsclients",result.rows); 
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching client staff:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/adduser", authenticateToken, async (req, res) => {

  try {
    const { firstName, lastName, email, phone, password, role, username, branch, client_id, employee } = req.body;

    // Get merchant_id from middleware (decoded token)
    const merchant_id = req.user.merchant_id;

    const employeeId = employee || null; // Set to null if not provided

    // Validate required fields
    if (!firstName || !lastName || !email || !phone || !password || !role || !branch || !username) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const limitCheck = await checkLimit("users");

    if (limitCheck.exceeded) {
      return res.status(460).json({
        success: false,
        code: "LIMIT_EXCEEDED",
        message:
          "Your user limit has been reached. Please contact your administrator to increase the allowed limit.",
      });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);
    const status = "Active"; // Default status

    // Format phone number
    const mobileNew = formatPhoneNumber(phone);
    if (mobileNew.error) {
      return res.status(400).json({ message: mobileNew.error });
    }
    const formattedPhone = mobileNew.formatted;

    // Check if username already exists
    const userNameCheck = await pool.query(
      "SELECT user_id FROM users WHERE username = $1",
      [username]
    );

    if (userNameCheck.rows.length > 0) {
      return res.status(409).json({ message: "Username already exists" });
    }

    // Insert the new user — now including outlet_id = branch + merchant_id
    const result = await pool.query(
      `INSERT INTO users 
        (first_name, last_name, username, email, mobile, password, role_id, status, branch_id, outlet_id, merchant_id, employee_id) 
       VALUES 
        ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) 
       RETURNING *`,
      [
        firstName,
        lastName,
        username,
        email,
        formattedPhone,
        hashedPassword,
        role,
        status,
        branch,     // branch_id
        branch,     // outlet_id (same as branch)
        merchant_id, // from middleware
        employeeId     // employee_id
      ]
    );

    res.status(201).json({ message: "User added successfully", user: result.rows[0] });
  } catch (error) {
    console.error("Error adding user:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/addrole", authenticateToken, async (req, res) => {
  try {
    const {
      roleName,
      privileges,
      dashboardAccess,
      portal_interface_id,
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    const status = "active";
    const createdAt = new Date();

    const portalInterface = portal_interface_id
      ? parseInt(portal_interface_id, 10)
      : null;

    const result = await pool.query(
      `
      INSERT INTO role_list (
        role_name,
        date,
        status,
        privileges,
        dashboard_access,
        user_id,
        portal_interface
      )
      VALUES ($1, $2, $3, $4::TEXT[], $5::TEXT[], $6, $7)
      RETURNING *;
      `,
      [
        roleName,
        createdAt,
        status,
        privileges,
        dashboardAccess,
        user_id,
        portalInterface, //  included
      ]
    );

    res.status(201).json({
      message: "Role added successfully",
      role: result.rows[0],
    });
  } catch (error) {
    console.error("Error adding role:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/sidebar", authenticateToken, async (req, res) => {
  try {

    const user = req.user;
    console.log(user)
    const roleid = user.role_id

    const roleResult = await pool.query(
      "SELECT privileges, dashboard_access FROM role_list WHERE id = $1",
      [roleid]
    );

    if (roleResult.rows.length === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    const privileges = roleResult.rows[0].privileges;
    const dashboardAccess = roleResult.rows[0].dashboard_access;


    const menuResult = await pool.query(
      "SELECT * FROM uimenudata WHERE id = ANY($1) AND show = true ORDER BY sidebar_order ASC",
      [privileges]
    );

    let menuItems = menuResult.rows;


    console.log(dashboardAccess)
    // if (dashboardAccess && dashboardAccess.length > 0) {
    //   const dashboardItems = await pool.query(
    //     "SELECT * FROM uimenudata WHERE privilege_id = ANY($1)",
    //     [dashboardAccess]
    //   );


    //   menuItems = [...dashboardItems.rows, ...menuItems];
    // }

    res.json(menuItems);
  } catch (error) {
    console.error("Error fetching sidebar menu:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.get("/sidebar-items", authenticateToken, async (req, res) => {
  try {

    const menuItemsResult = await pool.query(
      "SELECT id, parent_id, name, route, icon, sidebar_order, show FROM uimenudata WHERE package_show = true ORDER BY sidebar_order ASC"
    );

    const menuItems = menuItemsResult.rows;


    const menuMap = {};
    const sidebarOptions = [];

    menuItems.forEach((item) => {
      menuMap[item.id] = { ...item, subcategories: [] };
    });

    menuItems.forEach((item) => {
      if (item.parent_id) {
        menuMap[item.parent_id]?.subcategories.push(menuMap[item.id]);
      } else {
        sidebarOptions.push(menuMap[item.id]);
      }
    });

    res.json(sidebarOptions);
  } catch (error) {
    console.error("Error fetching sidebar menu:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/get-roles", authenticateToken, async (req, res) => {



  try {
    const result = await pool.query(
      "SELECT id, role_name,status,privileges FROM role_list WHERE status ='active' ORDER BY id DESC",

    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching roles:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/get-branch", authenticateToken, async (req, res) => {
  const { query } = req.body;
  console.log("Received query for branch search:", query);
  try {
    const result = await pool.query(
      `SELECT 
         outlet_id AS branch_id, 
         name AS branch_name 
       FROM outlets 
       WHERE name ILIKE $1 
       ORDER BY outlet_id DESC`,
      [`%${query}%`]  // Case-insensitive search

    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching branchs:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/get-active-outlets", authenticateToken, async (req, res) => {
  console.log("Fetching all ACTIVE branches");

  try {
    const result = await pool.query(
      `
      SELECT 
        outlet_id AS branch_id, 
        name AS branch_name 
      FROM outlets 
      WHERE is_active = true
      ORDER BY outlet_id DESC
      `
    );

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching active branches:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/get-role-table", authenticateToken, async (req, res) => {
  let { page = 1, limit = 25, search } = req.body;


  page = parseInt(page);
  limit = parseInt(limit);
  const offset = (page - 1) * limit;


  try {
    let query = `SELECT id, role_name, status, privileges FROM role_list WHERE TRUE`;
    let queryParams = [];
    let countQuery = `SELECT COUNT(*) FROM role_list WHERE TRUE`;
    let countParams = [];

    if (search) {
      queryParams.push(`%${search}%`);
      query += ` AND (role_name ILIKE $1 OR id::text ILIKE $1)`;

      countParams.push(`%${search}%`);
      countQuery += ` AND (role_name ILIKE $1 OR id::text ILIKE $1)`;
    }

    queryParams.push(limit, offset);
    const limitPosition = queryParams.length - 1;
    const offsetPosition = queryParams.length;

    query += ` ORDER BY id DESC LIMIT $${limitPosition} OFFSET $${offsetPosition}`;
    const result = await pool.query(query, queryParams);
    const countResult = await pool.query(countQuery, countParams);

    const totalRoles = parseInt(countResult.rows[0].count, 10);

    res.json({
      roles: result.rows,
      totalRoles,
      totalPages: Math.ceil(totalRoles / limit),
      currentPage: page,
    });
  } catch (error) {
    console.error("Error fetching roles:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/check-username", async (req, res) => {
  const { username } = req.body;

  if (!username) {
    return res.status(400).json({ message: "Username is required" });
  }

  try {
    const result = await pool.query("SELECT COUNT(*) FROM users WHERE username = $1", [username]);
    const usernameExists = parseInt(result.rows[0].count) > 0;

    return res.json({ exists: usernameExists });
  } catch (error) {
    console.error("Error checking username:", error);
    return res.status(500).json({ message: "Server error" });
  }
});



router.post("/update-role-status", authenticateToken, async (req, res) => {

  const { roleId, status } = req.body;

  try {
    const result = await pool.query(
      "UPDATE role_list SET status = $1 WHERE id = $2 RETURNING *",
      [status, roleId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    res.json({ message: "Role status updated successfully", role: result.rows[0] });
  } catch (error) {
    console.error("Error updating role status:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/update-role-privileges", authenticateToken, async (req, res) => {
  const { roleId, privileges } = req.body;

  if (!roleId || !Array.isArray(privileges) || privileges.length === 0) {
    return res.status(400).json({ message: "Invalid request data" });
  }

  try {
    // Sort privileges in ascending order (Min → Max)
    const sortedPrivileges = privileges.sort((a, b) => a - b);

    // Convert sorted array to PostgreSQL array format {3,6,7,8}
    const formattedPrivileges = `{${sortedPrivileges.join(",")}}`;

    // Update the privileges column in role_list table
    const result = await pool.query(
      "UPDATE role_list SET privileges = $1 WHERE id = $2 RETURNING *",
      [formattedPrivileges, roleId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    res.json({ message: "Role privileges updated successfully", role: result.rows[0] });
  } catch (error) {
    console.error("Error updating role privileges:", error);
    res.status(500).json({ message: "Server error" });
  }
});



router.post("/get-role-privileges", authenticateToken, async (req, res) => {
  const { roleId } = req.body;

  try {
    // Query to fetch privileges and dashboard access for the role
    const roleQuery = await pool.query(
      "SELECT privileges, dashboard_access FROM role_list WHERE id = $1",
      [roleId]
    );

    if (roleQuery.rowCount === 0) {
      return res.status(404).json({ message: "Role not found" });
    }

    // Extract privileges and dashboard access from role
    const { privileges = [], dashboard_access = [] } = roleQuery.rows[0];

    console.log("Privileges IDs Array:", privileges);

    // Fetch all privilege data from uimenudata
    const privilegeQuery = await pool.query(
      `SELECT id, parent_id, name, route, icon, sidebar_order, show FROM uimenudata WHERE package_show = true ORDER BY sidebar_order`
    );

    if (privilegeQuery.rowCount === 0) {
      return res.json({ privileges: [], dashboardAccess: dashboard_access });
    }

    // Function to build a hierarchy of privileges
    const buildHierarchy = (parentId) => {
      // Find all children (subcategories) for the given parentId
      return privilegeQuery.rows
        .filter(row => row.parent_id === parentId)
        .map(row => ({
          ...row,
          // Recursively add subcategories if any
          subcategories: buildHierarchy(row.id),
          assigned: privileges.includes(row.id.toString()) // Mark privilege as assigned if in role's privileges
        }));
    };

    // Get top-level privileges (parent components) and mark their assigned status
    const topLevelPrivileges = buildHierarchy(null);

    console.log("Structured Privileges with Subcategories:", topLevelPrivileges);

    // Return the structured data with assigned/unassigned status
    res.json({ privileges: topLevelPrivileges, dashboardAccess: dashboard_access });

  } catch (error) {
    console.error("Error fetching role privileges:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/edit-user", authenticateToken, async (req, res) => {
  const { first_name, last_name, email, mobile, selected_userId, newPassword, confirmPassword, branch_id, role_id } = req.body;
  const user = req.user
  const user_id = user.user_id
  const module = "Users";
  try {
    if (newPassword && confirmPassword) {
      // Case: Update Password
      if (newPassword !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }

      // Hash the new password before updating it
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      const result = await pool.query(
        `UPDATE users 
         SET password = $1 
         WHERE user_id = $2 RETURNING *`,
        [hashedPassword, selected_userId]
      );

      if (result.rows.length > 0) {

        const logMessage = `Admin ${user_id} updated password for user ${selected_userId}`;
        await insertAdminLog(user_id, module, logMessage);
        return res.status(200).json({ message: "Password updated successfully" });
      } else {
        return res.status(404).json({ message: "User not found" });
      }
    } else {
      const mobileNew = formatPhoneNumber(mobile);
      if (mobileNew.error) {
        return res.status(400).json({ message: mobileNew.error });
      }
      const formattedPhone = mobileNew.formatted;

      const result = await pool.query(
        `UPDATE users 
         SET first_name = $1, last_name = $2, email = $3, mobile = $4, outlet_id = $6, role_id = $7
         WHERE user_id = $5 RETURNING *`,
        [first_name, last_name, email, formattedPhone, selected_userId, branch_id, role_id]
      );

      if (result.rows.length > 0) {
        const logMessage = `Admin ${user_id} updated details for user ${selected_userId}`;
        await insertAdminLog(user_id, module, logMessage);
        return res.status(200).json({ message: "User details updated successfully", user: result.rows[0] });
      } else {
        return res.status(404).json({ message: "User not found" });
      }
    }
  } catch (error) {
    console.error("Error updating user details:", error);
    res.status(500).json({ message: "Server error" });
  }
});



router.put('/togglestatus', authenticateToken, async (req, res) => {
  try {
    const { user_id, status } = req.body;

    if (!user_id) {
      return res.status(400).json({ message: 'user_id is required' });
    }

    const allowed = ['Active', 'Inactive'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ message: 'Invalid status. Use "Active" or "Inactive".' });
    }

    const { rows, rowCount } = await pool.query(
      `
      UPDATE users
         SET status = $2
       WHERE user_id = $1
      RETURNING user_id, status
      `,
      [user_id, status]
    );

    if (rowCount === 0) {
      return res.status(404).json({ message: 'User not found' });
    }



    return res.json(rows[0]);
  } catch (err) {
    console.error('toggle-status error:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});


// fetch active portal interfaces

router.get("/active-portal-interfaces", authenticateToken, async (req, res) => {

  const client = await pool.connect();

  try {
    const { rows } = await client.query(
      `
        SELECT interface_id, name, route
        FROM portal_interface
        WHERE status = 'active'
        ORDER BY name ASC
        `
    );

    res.status(200).json({
      interfaces: rows,
    });
  } catch (error) {
    console.error("Error fetching active portal interfaces:", error);
    res.status(500).json({
      message: "Failed to fetch active portal interfaces",
    });
  } finally {
    client.release();
  }
}
);

const jwt = require('jsonwebtoken');
const checkLimit = require("../models/limitChecker");

router.get("/get-billing-confirm", async (req, res) => {
  const client = await pool.connect();

  try {
    const { rows } = await client.query(`
      SELECT 
        billing_client_id,
        billing_servise_id,
        billing_pid,
        billing_base_url
      FROM system_settings
      ORDER BY id DESC
      LIMIT 1
    `);

    if (rows.length === 0) {
      return res.status(404).json({ message: "No billing settings found" });
    }

    const config = rows[0];

    // Create a secure payload payload
    const payload = {
      clientId: config.billing_client_id,
      serviceId: config.billing_servise_id,
      pid: config.billing_pid
    };

    // Sign a token that expires in 5 minutes
    // Make sure JWT_SHARED_SECRET is defined in your ERP .env file
    const secureToken = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '5m' });

    res.status(200).json({
      billing_base_url: config.billing_base_url,
      token: secureToken
    });
  } catch (error) {
    console.error("Error fetching billing settings:", error);
    res.status(500).json({
      message: "Failed to fetch billing settings",
      error: error.message,
    });
  } finally {
    client.release();
  }
});




// Helper function to safely parse integer values
function safeParseInt(value, defaultValue = 0) {
  if (value === undefined || value === null || value === '') {
    return defaultValue;
  }
  
  const parsed = parseInt(value);
  if (isNaN(parsed)) {
    // Handle 'unlimited' or other non-numeric values
    if (typeof value === 'string' && value.toLowerCase() === 'unlimited') {
      return 0; // Or some large number, or null if your DB allows
    }
    return defaultValue;
  }
  return parsed;
}

router.post("/uimenuupdate", async (req, res) => {
  console.log("Request body:", JSON.stringify(req.body, null, 2));

  try {
    const {
      serviceId,
      features,
      selected_features,
      user_count,
      product_count,
      till_count,
      outlet_count
    } = req.body;

    // Start transaction
    await pool.query('BEGIN');

    // 1. Update system_settings table with limits
    if (user_count !== undefined || product_count !== undefined ||
      till_count !== undefined || outlet_count !== undefined || serviceId !== undefined) {

      const updateFields = [];
      const updateValues = [];
      let paramCounter = 1;

      // Use safe parsing for all count values
      const safeUserCount = safeParseInt(user_count);
      const safeProductCount = safeParseInt(product_count);
      const safeTillCount = safeParseInt(till_count);
      const safeOutletCount = safeParseInt(outlet_count);

      if (user_count !== undefined) {
        updateFields.push(`users_limit = $${paramCounter++}`);
        updateValues.push(safeUserCount);
      }
      if (product_count !== undefined) {
        updateFields.push(`products_limit = $${paramCounter++}`);
        updateValues.push(safeProductCount);
      }
      if (till_count !== undefined) {
        updateFields.push(`tills_limit = $${paramCounter++}`);
        updateValues.push(safeTillCount);
      }
      if (outlet_count !== undefined) {
        updateFields.push(`outlets_limit = $${paramCounter++}`);
        updateValues.push(safeOutletCount);
      }
      if (serviceId !== undefined) {
        updateFields.push(`billing_servise_id = $${paramCounter++}`);
        updateValues.push(parseInt(serviceId) || null);
      }

      if (updateFields.length > 0) {
        updateFields.push(`updated_at = CURRENT_TIMESTAMP`);

        const systemUpdateQuery = `
          UPDATE system_settings 
          SET ${updateFields.join(', ')}
          WHERE id = (SELECT id FROM system_settings LIMIT 1)
          RETURNING id, users_limit, products_limit, tills_limit, outlets_limit, billing_servise_id
        `;

        const systemResult = await pool.query(systemUpdateQuery, updateValues);

        if (systemResult.rowCount === 0) {
          // Insert if no row exists
          const insertFields = ['users_limit', 'products_limit', 'tills_limit', 'outlets_limit', 'billing_servise_id', 'updated_at'];
          const insertValues = [
            safeUserCount,
            safeProductCount,
            safeTillCount,
            safeOutletCount,
            serviceId ? parseInt(serviceId) : null,
            new Date()
          ];
          const placeholders = insertValues.map((_, i) => `$${i + 1}`).join(', ');

          await pool.query(
            `INSERT INTO system_settings (${insertFields.join(', ')}) 
             VALUES (${placeholders})`,
            insertValues
          );
          console.log("New system settings record created");
        } else {
          console.log("System settings updated:", systemResult.rows[0]);
        }
      }
    }

    // Rest of your code remains the same...
    // 2. Update UI menus based on selected_features or features
    let parentIds = [];

    // Use selected_features if available, otherwise use features array
    const menuFeatures = (selected_features && selected_features.length > 0)
      ? selected_features.map(f => f.name)
      : (features || []);

    if (menuFeatures && Array.isArray(menuFeatures) && menuFeatures.length > 0) {
      console.log("Updating menus for features:", menuFeatures);

      // Get matching parent menu IDs
      const parentMenus = await pool.query(
        `
        SELECT id, name
        FROM uimenudata
        WHERE parent_id IS NULL
        AND name = ANY($1::text[])
        `,
        [menuFeatures]
      );

      parentIds = parentMenus.rows.map(row => row.id);
      console.log("Found parent menu IDs:", parentIds);
      console.log("Found parent menu names:", parentMenus.rows.map(row => row.name));

      if (parentIds.length > 0) {
        // Update matched parents and their children
        const updateResult = await pool.query(
          `
          UPDATE uimenudata
          SET show = TRUE,
              package_show = TRUE
          WHERE id = ANY($1::int[])
             OR parent_id = ANY($1::int[])
          RETURNING id, name, parent_id
          `,
          [parentIds]
        );
        console.log(`Updated ${updateResult.rowCount} menu items`);
      } else {
        console.log("No matching parent menus found");
      }
    }

    // Commit transaction
    await pool.query('COMMIT');

    res.json({
      success: true,
      message: "UI menu and system settings updated successfully",
      data: {
        serviceId: serviceId,
        updatedParentIds: parentIds,
        limits: {
          users_limit: safeUserCount,
          products_limit: safeProductCount,
          tills_limit: safeTillCount,
          outlets_limit: safeOutletCount
        }
      }
    });

  } catch (error) {
    // Rollback transaction on error
    await pool.query('ROLLBACK');
    console.error("Error:", error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

router.get('/resource-allocation', async (req, res) => {
  const { serviceId } = req.query;

  console.log(`External System: Fetching resource allocation for serviceId: ${serviceId}`);

  try {
    // Simplified query - just get the first row since system_settings is a single record
    const systemResult = await pool.query(
      `SELECT 
        users_limit,
        products_limit,
        tills_limit,
        outlets_limit,
        billing_servise_id,
        updated_at
       FROM system_settings 
       LIMIT 1`
    );

    let resourceData = {
      users: { unlimited: false, count: 0 },
      products: { unlimited: false, count: 0 },
      tills: { unlimited: false, count: 0 },
      outlets: { unlimited: false, count: 0 }
    };

    if (systemResult.rows.length > 0) {
      const settings = systemResult.rows[0];

      console.log("Found system settings:", settings);

      // Users limit (0 means unlimited)
      resourceData.users = {
        unlimited: settings.users_limit === 0,
        count: settings.users_limit === 0 ? null : settings.users_limit
      };

      // Products limit (0 means unlimited)
      resourceData.products = {
        unlimited: settings.products_limit === 0,
        count: settings.products_limit === 0 ? null : settings.products_limit
      };

      // Tills limit (0 means unlimited)
      resourceData.tills = {
        unlimited: settings.tills_limit === 0,
        count: settings.tills_limit === 0 ? null : settings.tills_limit
      };

      // Outlets limit (0 means unlimited)
      resourceData.outlets = {
        unlimited: settings.outlets_limit === 0,
        count: settings.outlets_limit === 0 ? null : settings.outlets_limit
      };
    } else {
      console.log("No system settings found, using defaults");
      // Default values if no record exists
      resourceData = {
        users: { unlimited: true, count: null },
        products: { unlimited: true, count: null },
        tills: { unlimited: true, count: null },
        outlets: { unlimited: true, count: null }
      };
    }

    console.log(`External System: Resource allocation retrieved - Users: ${resourceData.users.unlimited ? 'Unlimited' : resourceData.users.count}, Products: ${resourceData.products.unlimited ? 'Unlimited' : resourceData.products.count}`);

    return res.status(200).json({
      success: true,
      data: resourceData,
      message: "Resource allocation retrieved successfully"
    });

  } catch (error) {
    console.error("External System Error:", error.message);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message
    });
  }
});

// PUT - Update resource allocation for a service
router.put('/resource-allocation/:serviceId', async (req, res) => {
  const { serviceId } = req.params;
  const { resources, service_name } = req.body;

  console.log(`External System: Updating resource allocation for serviceId: ${serviceId}`);
  console.log("Received payload:", JSON.stringify(req.body, null, 2));

  try {
    // Extract values from resources
    const { users, products, tills, outlets } = resources;

    console.log("Extracted values:", { users, products, tills, outlets });

    // Convert unlimited (true/false) to limit values (0 for unlimited)
    const usersLimit = users?.unlimited ? 0 : (users?.count || 0);
    const productsLimit = products?.unlimited ? 0 : (products?.count || 0);
    const tillsLimit = tills?.unlimited ? 0 : (tills?.count || 0);
    const outletsLimit = outlets?.unlimited ? 0 : (outlets?.count || 0);

    console.log(`Converting to limits - Users: ${usersLimit}, Products: ${productsLimit}, Tills: ${tillsLimit}, Outlets: ${outletsLimit}`);

    // Check if system_settings exists
    const checkResult = await pool.query(
      `SELECT id FROM system_settings LIMIT 1`
    );

    if (checkResult.rows.length > 0) {
      // Update existing record - DO NOT update billing_servise_id
      await pool.query(
        `UPDATE system_settings 
         SET users_limit = $1,
             products_limit = $2,
             tills_limit = $3,
             outlets_limit = $4,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = 1`,
        [usersLimit, productsLimit, tillsLimit, outletsLimit]
      );
      console.log("External System: Updated existing system settings");
    } else {
      // Insert new record - Include billing_servise_id only on insert
      await pool.query(
        `INSERT INTO system_settings (
          users_limit, 
          products_limit, 
          tills_limit, 
          outlets_limit, 
          billing_servise_id,
          created_at,
          updated_at
        ) VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        [usersLimit, productsLimit, tillsLimit, outletsLimit, serviceId]
      );
      console.log("External System: Created new system settings with billing_servise_id: ${serviceId}");
    }

    // Fetch the updated values
    const result = await pool.query(
      `SELECT users_limit, products_limit, tills_limit, outlets_limit 
       FROM system_settings WHERE id = 1`
    );

    const updatedData = {
      users: {
        unlimited: result.rows[0].users_limit === 0,
        count: result.rows[0].users_limit === 0 ? null : result.rows[0].users_limit
      },
      products: {
        unlimited: result.rows[0].products_limit === 0,
        count: result.rows[0].products_limit === 0 ? null : result.rows[0].products_limit
      },
      tills: {
        unlimited: result.rows[0].tills_limit === 0,
        count: result.rows[0].tills_limit === 0 ? null : result.rows[0].tills_limit
      },
      outlets: {
        unlimited: result.rows[0].outlets_limit === 0,
        count: result.rows[0].outlets_limit === 0 ? null : result.rows[0].outlets_limit
      }
    };

    console.log(`External System: Resource allocation updated for service ${serviceId}`);
    console.log("Returning data:", updatedData);

    return res.status(200).json({
      success: true,
      data: updatedData,
      message: "Resource allocation updated successfully"
    });

  } catch (error) {
    console.error("External System Error:", error.message);
    console.error("Error stack:", error.stack);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message
    });
  }
});




module.exports = router;
