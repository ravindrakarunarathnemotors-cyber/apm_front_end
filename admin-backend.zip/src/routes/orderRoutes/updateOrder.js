const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
// const { formatPhoneNumber } = require("../models/authModels");
const { adminUserDeatils, systemSettings, getDeliveryFee, oneCountry, updateLoyaltySuctomer, checkLoyalty, brandingSettings, addLoyalty } = require("../../models/commonModels");
// ADD THIS import (fix the path as needed)
const { insertNotification } = require("../../models/notificationsUpdater");
const { insertAdminLog } = require("../../models/userLogs");
const { customhook } = require("../../models/smsnotificationmodel");
const updateTransactionRecord = require("../transactionsUpdater/transactionsUpdater");

const useMeasurementConverter = (amount, measurement_id) => {

  // Only convert when measurement is grams (id = 3)
  if (measurement_id !== 3) {
    return amount; // return original amount
  }

  // Keep as grams
  return (amount / 1000).toFixed(2)
};


//update order save
router.put('/edit-order/:order_id', authenticateToken, async (req, res) => {
  try {
    const { order_id } = req.params;
    const { products, client, clientDetails, billingaddressSame, billingaddress, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountType, selected, discountDetails, loyaltiPoints, bankSlipUrl, lastSubTotal, fastAmount, transactionFee } = req.body

    console.log(req.user?.merchant_id, "req.user?.merchant_id");

    // ✅ take from token instead of hardcoding
    const user = req.user
    const user_id = user.user_id
    const merchant_id = req.user?.merchant_id;
    const branch_id = req.user?.outlet_id || 1;

    const orderDetailsQuery = `SELECT order_id, customer_id, order_status, loyalty_points_spent, loyalty_points_earned, payment_status FROM orders WHERE order_id = $1`;

    const [system_settings, orderDetails] = await Promise.all([
      systemSettings(),
      pool.query(orderDetailsQuery, [order_id])
    ]);

    if (orderDetails.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const order = orderDetails.rows[0];

    if (order.order_status !== "pending") {
      return res.status(400).json({ message: "Order is not in pending status" });
    }

    const previousLoyaltyPoint = Number(order.loyalty_points_spent)
    const previousEarnedLoyaltyPoint = Number(order.loyalty_points_earned)

    //reset to previous value to loyality poins
    const updateLoyalityQuery = `UPDATE customer 
            SET loyalty_point = loyalty_point + $1 WHERE customer_id = $2`

    const updateLoyalityResult = await pool.query(updateLoyalityQuery, [(previousLoyaltyPoint - previousEarnedLoyaltyPoint), order.customer_id])

    if (updateLoyalityResult.rowCount === 0) {
      return res.status(404).json({ message: "loyalty not found" });
    }

    const customerLoyalty = await checkLoyalty(clientDetails.value)

    const type = discountDetails && discountDetails.type ? discountDetails.type : null

    const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

    const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

    //calculate corrct ponit to reduce from customer
    const totalLoyalPoynt = Number(customerLoyalty)

    if ((totalLoyalPoynt) < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })


    // check COD or not
    let cod = false
    if (selectedPaymentMethod.value == 3) {
      cod = true
    }

    const totalAmount = lastSubTotal

    const totalWeight = products.reduce((total, item) => {
      if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
      return total + parseFloat(item.weight * item.selectedQty)
    }, 0);

    const totalQuantity = products.reduce((total, item) => {
      return total + item.selectedQty
    }, 0);

    const totalDiscount = parseFloat(discount) || 0;

    let parsedDeliveryFee = 0
    const roundedWeight = Math.ceil(parseFloat(totalWeight))
    let sender_country = 'Sri Lanka'
    let delivery_country = 'Sri Lanka'

    if (selected == 'same_as_billing') {
      const [deliveryFeeDetails, sCountry] = await Promise.all([
        getDeliveryFee(clientDetails.country),
        oneCountry(clientDetails.country)
      ])

      sender_country = sCountry
      if (roundedWeight > 1) {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
      } else {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
      }
    } else if (selected == 'default') {
      const [deliveryFeeDetails, sCountry, dCountry] = await Promise.all([
        getDeliveryFee(billingaddress.country),
        oneCountry(clientDetails.country),
        oneCountry(billingaddress.country)
      ])

      sender_country = sCountry
      delivery_country = dCountry

      if (roundedWeight > 1) {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
      } else {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
      }
    } else if (selected == 'store_pickup') {
      sender_country = await oneCountry(clientDetails.country)
      parsedDeliveryFee = 0
    }

    // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  billingaddressSame - tax add on off
    let grandtax = null;
    if (system_settings.tax && billingaddressSame) {
      grandtax = totalTax;
    }

    console.log(system_settings)

    const fullAmount = fastAmount


    // update customer Details
    if (clientDetails.saveInfo === true) {
      let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
      let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

      if (clientDetails.email) {
        customerQuery += `, email = $${customerParams.length + 1}`
        customerParams.push(clientDetails.email)
      }

      if (clientDetails.apartment) {
        customerQuery += `, apartment = $${customerParams.length + 1}`
        customerParams.push(clientDetails.apartment)
      }

      if (clientDetails.postal_code) {
        customerQuery += `, postal_code = $${customerParams.length + 1}`
        customerParams.push(clientDetails.state)
      }

      customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
      customerParams.push(client.value)

      const customerResult = await pool.query(customerQuery, customerParams)

      if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

    }

    let storepickup = 'No'

    //set shipping details
    let shipping_first_name = ''
    let shipping_last_name = ''
    let shipping_address = ''
    let shipping_city = ''
    let shipping_postal_code = ''
    let shipping_apartment = ''
    let shipping_country = 'Sri Lanka'
    let shipping_contact_number_1 = ''
    let shipping_email = ''

    if (selected == 'same_as_billing') {
      shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
      shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
      shipping_address = clientDetails.address ? clientDetails.address : ''
      shipping_city = clientDetails.city ? clientDetails.city : ''
      shipping_postal_code = clientDetails.postal_code ? clientDetails.postal_code : ''
      shipping_apartment = clientDetails.apartment ? clientDetails.apartment : ''
      shipping_contact_number_1 = clientDetails.contact_number_1 ? clientDetails.contact_number_1 : ''
      shipping_email = clientDetails.email ? clientDetails.email : ''
      shipping_country = sender_country ? sender_country : ''
    } else if (selected == 'default') {
      shipping_first_name = billingaddress.first_name ? billingaddress.first_name : ''
      shipping_last_name = billingaddress.last_name ? billingaddress.last_name : ''
      shipping_address = billingaddress.address ? billingaddress.address : ''
      shipping_city = billingaddress.city ? billingaddress.city : ''
      shipping_postal_code = billingaddress.postal_code ? billingaddress.postal_code : ''
      shipping_apartment = billingaddress.apartment ? billingaddress.apartment : ''
      shipping_contact_number_1 = billingaddress.contact_number_1 ? billingaddress.contact_number_1 : ''
      shipping_email = billingaddress.email ? billingaddress.email : ''
      shipping_country = delivery_country ? delivery_country : ''
    } else if (selected == 'store_pickup') {
      const shopDetails = await brandingSettings()
      shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
      shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
      shipping_address = shopDetails.address_1 ? shopDetails.address_1 : ''
      shipping_city = shopDetails.address_2 ? shopDetails.address_2 : ''
      shipping_postal_code = ''
      shipping_apartment = ''
      shipping_contact_number_1 = shopDetails.hotline ? shopDetails.hotline : ''
      shipping_email = shopDetails.support_email ? shopDetails.support_email : ''
      shipping_country = sender_country ? sender_country : ''
      storepickup = 'Yes'
    }

    const delivery_partner_id = selected == 'store_pickup' ? 1 : null

    let loyalty_points_earned = 0
    const loyalty_point = system_settings.loyalty_point
    const points_given = parseFloat(system_settings.points_given) || 0
    const amount_spend = parseFloat(system_settings.amount_spend) || 0

    if (loyalty_point && order.payment_status == "paid") {
      const orderPerPoint = fullAmount / amount_spend

      loyalty_points_earned = orderPerPoint * points_given
    }

    const orderQuery = `
          UPDATE orders 
            SET 
              user_id = $1,
              customer_id = $2,
              merchant_id = $3,
              payment_method_id = $4,
              order_status = $5,
              total_value = $6,
              amount_paid = $7,
              total_item = $8,
              total_weight = $9,
              cod = $10,
              currency = $11,
              sender_address = $12,
              recipient_name = $13,
              recipient_contact = $14,
              recipient_email = $15,
              recipient_address = $16,
              recipient_city = $17,
              recipient_postal_code = $18,
              recipient_country = $19,
              payment_reference = $20,
              order_module = $21,
              delivery_fee = $22,
              discount = $23,
              tax_percentage = $24,
              tax = $25,
              storepickup = $26,
              sender_name = $27,
              sender_city = $28,
              sender_phone = $29,
              sender_email = $30,
              sender_country = $31,
              recipient_contact_two = $32,
              full_amount = $33,
              delivery_partner_id = $34,
              discount_type = $35,
              loyalty_points_spent = $36,
              bank_slip = $37,
              loyalty_points_earned = $38,
              transaction_fee = $39
            WHERE order_id = $40
            RETURNING order_id;

        `;


    const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod.value, 'pending', totalAmount, 0, totalQuantity, totalWeight, cod, system_settings.currency, clientDetails.address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, refference, 'admin', parseFloat(deliveryFee) || 0, parseFloat(totalDiscount ? totalDiscount : 0) || 0, taxValue, grandtax, storepickup, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.city, clientDetails.contact_number_1, clientDetails.email, sender_country, billingaddress.contact_number_2, fullAmount, delivery_partner_id, type, typeLoyaltyPoint, bankSlipUrl, loyalty_points_earned, transactionFee, order_id]

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0) {
      return res.status(400).json({ message: "Order not found" });
    }

    const deleteItemsQuery = pool.query(
      `DELETE FROM order_items WHERE order_id = $1`,
      [order_id]
    );

    const deleteDiscountQuery = pool.query(
      `DELETE FROM discount_usage WHERE order_id = $1 AND type = 'order'`,
      [order_id]
    );

    const [deleteItemsResult, deleteDiscountResult] = await Promise.all([
      deleteItemsQuery,
      deleteDiscountQuery,
    ]);

    if (deleteItemsResult.rowCount === 0) {
      return res.status(400).json({ message: "Order not found" });
    }

    const orderItemParams = []
    const values = []

    products.forEach((product, i) => {

      let is_free = false;
      let free_quantity = 0;
      let discount = 0;

      // Check if discount applies
      if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
        const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
        if (match) {
          is_free = true;
          free_quantity = match.free_count || 0;
        }
      }

      if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
        const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
        if (match) {
          discount = match.discount_value || 0;
        }
      }

      const baseIndex = 10 * i;

      values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

      const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

      orderItemParams.push(
        order_id,
        product.product_id,
        product.variant_id,
        product.selectedQty,
        product.price,
        product.price * product.selectedQty,
        real_weight,
        is_free,
        free_quantity,
        discount
      );
    });

    const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`


    const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

    if (orderItemResult.rowCount === 0) {
      return res.status(400).json({ message: "Order item not added" })
    }

    if (discountDetails && discountDetails?.discount_id && type != 'manual') {
      //discount useage table
      const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

      const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value, 'order'])

      if (discountUsageResult.rowCount === 0) {
        return res.status(400).json({ message: "Discount usage not added" })
      }
    }

    const module = "Orders";
    const logMessage = `Order #${order_id} has been updated by user ${user_id}.`;

    const [notification] = await Promise.all([
      insertNotification(user_id, 'Order Management', 'Update Order', `Order #${order_id} has been updated by user ${user_id}.`, 'admin', 'Unread'),
      insertAdminLog(user_id, module, logMessage),
      updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty)

    ])


    if (loyalty_point && order.payment_status == "paid") {
      await addLoyalty(clientDetails.value, loyalty_points_earned)
    }


    return res.status(200).json({
      message: "Order updated successfully",
    });

  } catch (err) {
    console.error('Error updating order:', err);
    return res.status(500).json({ message: "Server error", error: err.message });
  }
});

//upddate order paid status
router.put('/edit-order-paid/:order_id', authenticateToken, async (req, res) => {
  try {
    const { order_id } = req.params;
    const { products, client, clientDetails, billingaddressSame, billingaddress, selectedPaymentMethod, refference, deliveryFee, discountvalue, taxValue, totalTax, discountType, selected, discountDetails, loyaltiPoints, bankSlipUrl, lastSubTotal, fastAmount, transactionFee, subPaymentMethod } = req.body

    console.log(req.user?.merchant_id, "req.user?.merchant_id");

    // ✅ take from token instead of hardcoding
    const user = req.user
    const user_id = user.user_id
    const merchant_id = req.user?.merchant_id;
    const branch_id = req.user?.outlet_id || 1;

    const orderDetailsQuery = `SELECT order_id, customer_id, order_status, loyalty_points_spent, loyalty_points_earned FROM orders WHERE order_id = $1`;

    const [system_settings, orderDetails] = await Promise.all([
      systemSettings(),
      pool.query(orderDetailsQuery, [order_id])
    ]);

    if (orderDetails.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const order = orderDetails.rows[0];

    if (order.order_status !== "pending") {
      return res.status(400).json({ message: "Order is not in pending status" });
    }

    const previousLoyaltyPoint = Number(order.loyalty_points_spent)
    const prevEarnPoint = Number(order.loyalty_points_earned)
    const previousEarnedLoyaltyPoint = Number(order.loyalty_points_earned)

    //reset to previous value to loyality poins
    const updateLoyalityQuery = `UPDATE customer 
            SET loyalty_point = loyalty_point + $1 WHERE customer_id = $2`

    const updateLoyalityResult = await pool.query(updateLoyalityQuery, [(previousLoyaltyPoint - previousEarnedLoyaltyPoint), order.customer_id])

    if (updateLoyalityResult.rowCount === 0) {
      return res.status(404).json({ message: "Customer not found" });
    }

    const customerLoyalty = await checkLoyalty(clientDetails.value)

    const type = discountDetails && discountDetails.type ? discountDetails.type : null

    const discount = type == 'buyx' ? 0 : parseFloat(discountvalue || 0)

    const typeLoyaltyPoint = loyaltiPoints ? parseFloat(loyaltiPoints) : 0

    //calculate corrct ponit to reduce from customer
    const totalLoyalPoynt = Number(customerLoyalty)

    if ((totalLoyalPoynt) < typeLoyaltyPoint) return res.status(400).json({ message: "You don't have enough loyalty points" })


    // check COD or not
    let cod = false
    if (selectedPaymentMethod.value == 3) {
      cod = true
    }

    const totalAmount = lastSubTotal

    const totalWeight = products.reduce((total, item) => {
      if (item.measurement_needed && (item.measurement_id == 2 || item.measurement_id == 3)) return total + parseFloat(useMeasurementConverter(item.count, item.measurement_id))
      return total + parseFloat(item.weight * item.selectedQty)
    }, 0);

    const totalQuantity = products.reduce((total, item) => {
      return total + item.selectedQty
    }, 0);

    const totalDiscount = parseFloat(discount) || 0;

    let parsedDeliveryFee = 0
    const roundedWeight = Math.ceil(parseFloat(totalWeight))
    let sender_country = 'Sri Lanka'
    let delivery_country = 'Sri Lanka'

    if (selected == 'same_as_billing') {
      const [deliveryFeeDetails, sCountry] = await Promise.all([
        getDeliveryFee(clientDetails.country),
        oneCountry(clientDetails.country)
      ])

      sender_country = sCountry
      if (roundedWeight > 1) {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
      } else {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
      }
    } else if (selected == 'default') {
      const [deliveryFeeDetails, sCountry, dCountry] = await Promise.all([
        getDeliveryFee(billingaddress.country),
        oneCountry(clientDetails.country),
        oneCountry(billingaddress.country)
      ])

      sender_country = sCountry
      delivery_country = dCountry

      if (roundedWeight > 1) {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee) + (parseFloat(deliveryFeeDetails.additional_fee) * (roundedWeight - 1))
      } else {
        parsedDeliveryFee = parseFloat(deliveryFeeDetails.fee)
      }
    } else if (selected == 'store_pickup') {
      sender_country = await oneCountry(clientDetails.country)
      parsedDeliveryFee = 0
    }

    // Tax logic: assume system_settings.tax = { enabled: true, key: 'Tax', value: '20' }  billingaddressSame - tax add on off
    let grandtax = null;
    if (system_settings.tax && billingaddressSame) {

      grandtax = totalTax;
    }

    console.log(system_settings)

    const fullAmount = fastAmount

    let loyalty_points_earned = 0
    const loyalty_point = system_settings.loyalty_point
    const points_given = parseFloat(system_settings.points_given) || 0
    const amount_spend = parseFloat(system_settings.amount_spend) || 0

    if (loyalty_point) {
      const orderPerPoint = fullAmount / amount_spend

      loyalty_points_earned = orderPerPoint * points_given
    }

    // update customer Details
    if (clientDetails.saveInfo === true) {
      let customerQuery = `UPDATE customer SET first_name = $1, last_name = $2, contact_number_1 = $3, address = $4, city = $5, country = $6`
      let customerParams = [clientDetails.first_name, clientDetails.last_name, clientDetails.contact_number_1, clientDetails.address, clientDetails.city, clientDetails.country]

      if (clientDetails.email) {
        customerQuery += `, email = $${customerParams.length + 1}`
        customerParams.push(clientDetails.email)
      }

      if (clientDetails.apartment) {
        customerQuery += `, apartment = $${customerParams.length + 1}`
        customerParams.push(clientDetails.apartment)
      }

      if (clientDetails.postal_code) {
        customerQuery += `, postal_code = $${customerParams.length + 1}`
        customerParams.push(clientDetails.state)
      }

      customerQuery += `WHERE customer_id = $${customerParams.length + 1}`
      customerParams.push(client.value)

      const customerResult = await pool.query(customerQuery, customerParams)

      if (customerResult.rowCount === 0) return res.status(400).json({ message: "customer not found" })

    }

    let storepickup = 'No'

    //set shipping details
    let shipping_first_name = ''
    let shipping_last_name = ''
    let shipping_address = ''
    let shipping_city = ''
    let shipping_postal_code = ''
    let shipping_apartment = ''
    let shipping_country = 'Sri Lanka'
    let shipping_contact_number_1 = ''
    let shipping_email = ''

    if (selected == 'same_as_billing') {
      shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
      shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
      shipping_address = clientDetails.address ? clientDetails.address : ''
      shipping_city = clientDetails.city ? clientDetails.city : ''
      shipping_postal_code = clientDetails.postal_code ? clientDetails.postal_code : ''
      shipping_apartment = clientDetails.apartment ? clientDetails.apartment : ''
      shipping_contact_number_1 = clientDetails.contact_number_1 ? clientDetails.contact_number_1 : ''
      shipping_email = clientDetails.email ? clientDetails.email : ''
      shipping_country = sender_country ? sender_country : ''
    } else if (selected == 'default') {
      shipping_first_name = billingaddress.first_name ? billingaddress.first_name : ''
      shipping_last_name = billingaddress.last_name ? billingaddress.last_name : ''
      shipping_address = billingaddress.address ? billingaddress.address : ''
      shipping_city = billingaddress.city ? billingaddress.city : ''
      shipping_postal_code = billingaddress.postal_code ? billingaddress.postal_code : ''
      shipping_apartment = billingaddress.apartment ? billingaddress.apartment : ''
      shipping_contact_number_1 = billingaddress.contact_number_1 ? billingaddress.contact_number_1 : ''
      shipping_email = billingaddress.email ? billingaddress.email : ''
      shipping_country = delivery_country ? delivery_country : ''
    } else if (selected == 'store_pickup') {
      const shopDetails = await brandingSettings()
      shipping_first_name = clientDetails.first_name ? clientDetails.first_name + ' ' + clientDetails.last_name : ''
      shipping_last_name = clientDetails.last_name ? clientDetails.last_name : ''
      shipping_address = shopDetails.address_1 ? shopDetails.address_1 : ''
      shipping_city = shopDetails.address_2 ? shopDetails.address_2 : ''
      shipping_postal_code = ''
      shipping_apartment = ''
      shipping_contact_number_1 = shopDetails.hotline ? shopDetails.hotline : ''
      shipping_email = shopDetails.support_email ? shopDetails.support_email : ''
      shipping_country = sender_country ? sender_country : ''
      storepickup = 'Yes'
    }

    const delivery_partner_id = selected == 'store_pickup' ? 1 : null

    const orderQuery = `
          UPDATE orders 
          SET 
            user_id = $1,
            customer_id = $2,
            merchant_id = $3,
            payment_method_id = $4,
            order_status = $5,
            total_value = $6,
            amount_paid = $7,
            total_item = $8,
            total_weight = $9,
            cod = $10,
            payment_status = $11,
            currency = $12,
            sender_address = $13,
            recipient_name = $14,
            recipient_contact = $15,
            recipient_email = $16,
            recipient_address = $17,
            recipient_city = $18,
            recipient_postal_code = $19,
            recipient_country = $20,
            payment_reference = $21,
            order_module = $22,
            delivery_fee = $23,
            discount = $24,
            tax_percentage = $25,
            tax = $26,
            storepickup = $27,
            sender_name = $28,
            sender_city = $29,
            sender_phone = $30,
            sender_email = $31,
            sender_country = $32,
            recipient_contact_two = $33,
            full_amount = $34,
            delivery_partner_id = $35,
            discount_type = $36,
            loyalty_points_spent = $37,
            loyalty_points_earned = $38,
            bank_slip = $39,
            transaction_fee = $40
          WHERE order_id = $41
          RETURNING order_id
        `;


    const OrderParms = [user_id, client.value, merchant_id, selectedPaymentMethod.value, 'pending', totalAmount, 0, totalQuantity, totalWeight, cod, 'paid', system_settings.currency, clientDetails.address, shipping_first_name, shipping_contact_number_1, shipping_email, shipping_address, shipping_city, shipping_postal_code, shipping_country, refference, 'admin', parseFloat(deliveryFee) || 0, parseFloat(totalDiscount ? totalDiscount : 0) || 0, taxValue, grandtax, storepickup, clientDetails.first_name + ' ' + clientDetails.last_name, clientDetails.city, clientDetails.contact_number_1, clientDetails.email, sender_country, billingaddress.contact_number_2, fullAmount, delivery_partner_id, type, typeLoyaltyPoint, loyalty_points_earned, bankSlipUrl, transactionFee, order_id]

    const orderResult = await pool.query(orderQuery, OrderParms);

    if (orderResult.rowCount === 0) {
      return res.status(400).json({ message: "Order not found" });
    }

    const deleteItemsQuery = pool.query(
      `DELETE FROM order_items WHERE order_id = $1`,
      [order_id]
    );

    const deleteDiscountQuery = pool.query(
      `DELETE FROM discount_usage WHERE order_id = $1 AND type = 'order'`,
      [order_id]
    );

    const [deleteItemsResult, deleteDiscountResult] = await Promise.all([
      deleteItemsQuery,
      deleteDiscountQuery,
    ]);

    if (deleteItemsResult.rowCount === 0) {
      return res.status(400).json({ message: "Order not found" });
    }

    const orderItemParams = []
    const values = []

    products.forEach((product, i) => {

      let is_free = false;
      let free_quantity = 0;
      let discount = 0;

      // Check if discount applies
      if (type === 'buyx' && Array.isArray(discountDetails.discount_value)) {
        const match = discountDetails.discount_value.find(d => d.product_id === product.product_id);
        if (match) {
          is_free = true;
          free_quantity = match.free_count || 0;
        }
      }


      if (type === 'product' && Array.isArray(discountDetails.discont_product)) {
        const match = discountDetails.discont_product.find(d => d.product_id === product.product_id);
        if (match) {
          discount = match.discount_value || 0;
        }
      }

      const baseIndex = 10 * i;

      values.push(`($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4}, $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8}, $${baseIndex + 9}, $${baseIndex + 10})`);

      const real_weight = product.measurement_needed && (product.measurement_id == 2 || product.measurement_id == 3) ? parseFloat(useMeasurementConverter(product.amount_per_unit, product.measurement_id)) : product.weight

      orderItemParams.push(
        order_id,
        product.product_id,
        product.variant_id,
        product.selectedQty,
        product.price,
        product.price * product.selectedQty,
        real_weight,
        is_free,
        free_quantity,
        discount
      );
    });

    const orderItemQuery = `INSERT INTO order_items (order_id, product_id, variant_id, quantity, unit_price, total_price, item_weght, is_free, free_quantity, discount) VALUES ${values.join(',')}`


    const orderItemResult = await pool.query(orderItemQuery, orderItemParams)

    if (orderItemResult.rowCount === 0) {
      return res.status(400).json({ message: "Order item not added" })
    }

    if (discountDetails && discountDetails?.discount_id && type != 'manual') {
      //discount useage table
      const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

      const discountUsageResult = await pool.query(discountUsageQuery, [orderResult.rows[0].order_id, discountDetails.discount_id, client.value, 'order'])

      if (discountUsageResult.rowCount === 0) {
        return res.status(400).json({ message: "Discount usage not added" })
      }
    }

    const module = "Orders";
    const logMessage = `Order #${order_id} has been updated by user ${user_id}.`;

    const paymentHistoryQuery = `INSERT INTO invoice_payment_history (order_invoice_id, user_id, method_id, amount, module, transaction_fee, loyalty_points_earned, acc_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`

    const [notification] = await Promise.all([
      insertNotification(user_id, 'Order Management', 'Update Order', `Order #${order_id} has been updated by user ${user_id}.`, 'admin', 'Unread'),
      insertAdminLog(user_id, module, logMessage),
      updateLoyaltySuctomer(clientDetails.value, typeLoyaltyPoint, customerLoyalty),
      pool.query(paymentHistoryQuery, [
        order_id, user_id, selectedPaymentMethod.value, fullAmount, 'order', transactionFee, loyalty_points_earned, subPaymentMethod
      ]),
      updateTransactionRecord({
        client: pool,
        amount: fullAmount,
        account_id: subPaymentMethod,
        category_id: 1,
        transaction_type: "income",
        note: `Order payment for order #${order_id}`,
        by_user_id: user_id,
        payer_payee_id: null,
        outlet_id: null,
        log_module: "Order Payment",
        log_message: `Order payment of ${fullAmount} received for order #${order_id} by user ${user_id}. Status: paid`,
      })
    ])

    if (loyalty_point) {
      await addLoyalty(clientDetails.value, loyalty_points_earned)
    }

    return res.status(200).json({
      message: "Order updated successfully",
    });

  } catch (err) {
    console.error('Error updating order:', err);
    return res.status(500).json({ message: "Server error", error: err.message });
  }
});

// fetch/ get products / variants by order_id

router.get('/get-products-by-order/:order_id', async (req, res) => {
  const { order_id } = req.params;

  if (!order_id) {
    return res.status(400).json({ message: "order_id is required" });
  }

  const query = `
    SELECT
      o.order_id,
      o.order_status,
      o.payment_status,
      o.customer_id,
      o.payment_method_id,
      o.sender_name,
      o.sender_city,	
      o.sender_phone,
      o.sender_email,	
      o.sender_phone_two,	
      o.sender_address,
      sender_co.id AS sender_country_id,
      sender_country AS sender_country_name,
      o.recipient_name,
      o.recipient_contact,
      o.recipient_email,
      o.recipient_address,
      o.recipient_postal_code,
      o.recipient_city,
      recipient_co.id AS recipient_country_id,
      recipient_country AS recipient_country_name,
      o.recipient_contact_two,
      o.payment_reference,
      o.loyalty_points_spent,
      o.loyalty_points_earned,
      cu.loyalty_point,
      o.bank_slip,
      o.discount,
      o.discount_type,
      json_agg(
        json_build_object(
          'variant_id', v.variant_id,
          'variant_value', v.variant_value,
          'count', CASE WHEN p.amount_per_unit IS NULL THEN NULL ELSE oi.quantity * p.amount_per_unit END,
          'price', v.price,
          'product_id', v.product_id,
          'weight', v.weight,
          'quantity', i.new_quantity,
          'selectedQty', oi.quantity,
          'unit_price', oi.unit_price,
          'total_price', oi.total_price,
          'measurement_needed', CASE WHEN p.measurement_id = 1 THEN false ELSE true END,
          'measurement_id', p.measurement_id,
          'measurement_value', m.measurement_value,
          'amount_per_unit', p.amount_per_unit,
          'main_img', pm.media_url,
          'first_extra_img', pmd_first.media_url,
          'title', p.title
        )
        ORDER BY v.variant_value
      ) AS variants
    FROM orders o
    INNER JOIN order_items oi ON oi.order_id = o.order_id
    INNER JOIN products p ON p.product_id = oi.product_id
    INNER JOIN product_variants v ON v.variant_id = oi.variant_id
    INNER JOIN customer cu ON cu.customer_id = o.customer_id
    LEFT JOIN measurements m ON p.measurement_id	= m.measurement_id
    LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL
    LEFT JOIN countries sender_co ON LOWER(sender_co.country_name) = LOWER(o.sender_country)
    LEFT JOIN countries recipient_co ON LOWER(recipient_co.country_name) = LOWER(o.recipient_country)
    LEFT JOIN LATERAL (
      SELECT media_url
      FROM product_media
      WHERE product_id = p.product_id AND main = true AND variant_id IS NOT NULL
      ORDER BY created_at ASC
      LIMIT 1
    ) pmd_first ON true
    LEFT JOIN LATERAL (
      SELECT new_quantity
      FROM inventory
      WHERE variant_id = v.variant_id
      ORDER BY inventory_id DESC
      LIMIT 1
    ) i ON true
    WHERE o.order_id = $1
    GROUP BY o.order_id, sender_co.id, recipient_co.id, cu.loyalty_point
  `;

  try {
    const result = await pool.query(query, [order_id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }
    return res.status(200).json({ message: "success", result: result.rows[0] });
  } catch (err) {
    console.error("Error fetching products by order ID:", err);
    return res.status(500).json({ message: "Server error", error: err.message });
  }
});


// fetch billing and delivery section




router.get('/delivery-details/:order_id', async (req, res) => {
  const { order_id } = req.params;

  try {
    const orderQuery = `
      SELECT 
        o.order_id,
        o.customer_id,
        o.sender_address AS billing_address,
        o.recipient_name,
        o.recipient_email,
        o.recipient_contact,
        o.recipient_address,
        o.recipient_city,
        o.recipient_postal_code,
        o.recipient_country
      FROM orders o
      WHERE o.order_id = $1
    `;
    const orderResult = await pool.query(orderQuery, [order_id]);
    if (orderResult.rowCount === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }

    const order = orderResult.rows[0];

    const customerQuery = `
      SELECT 
        customer_id AS value,
        first_name,
        last_name,
        email,
        contact_number_1,
        address,
        city,
        postal_code,
        country
      FROM customer
      WHERE customer_id = $1
    `;
    const customerResult = await pool.query(customerQuery, [order.customer_id]);
    const customer = customerResult.rows[0] || null;

    return res.status(200).json({
      message: 'success',
      billingDetails: customer,
      deliveryDetails: {
        name: order.recipient_name,
        email: order.recipient_email,
        contact: order.recipient_contact,
        address: order.recipient_address,
        city: order.recipient_city,
        postal_code: order.recipient_postal_code,
        country: order.recipient_country,
      },
      billing_address: order.billing_address
    });
  } catch (error) {
    console.error('Error fetching delivery details:', error);
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
});






module.exports = router;
