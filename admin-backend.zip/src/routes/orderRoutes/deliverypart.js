const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");



router.get('/delivery_partners', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
          dp.partner_id,
          dp.name, 
          dp.logo, 
          dp.type,
          dp.title, 
          dp.status,
          dp.description,
          dp.api_status,
          dp.email,
          dp.password,
          dp.contact_number,
          dp.customer_id,
          dp.api_key,
          dp.tracking_url,
          dp.two_way_url,
          dp.two_way_status,
          COUNT(CASE WHEN w.status = 'use' THEN 1 END) AS used_count,
          COUNT(CASE WHEN w.status = 'unuse' THEN 1 END) AS unused_count
        FROM delivery_partners dp
          LEFT JOIN waybills w ON dp.partner_id = w.d_partner_id
           GROUP BY dp.partner_id, dp.name, dp.logo, dp.title, dp.status, dp.description
           ORDER BY dp.partner_id ASC
    `);

    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error('Error fetching delivery partners:', err.message);
    res.status(500).json({ success: false, message: 'Failed to fetch delivery partners' });
  }
});

router.post('/waybills', authenticateToken, async (req, res) => {

   const user = req.user;
  const user_id = user.user_id;
  const { rows } = req.body;

  console.log("rows",rows);

  if (!Array.isArray(rows) || rows.length === 0) {
    return res.status(400).json({ message: 'No waybill data provided' });
  }

  const client = await pool.connect();

  try {
    const insertList = [];
    const skippedList = [];

   
    const waybillPairs = rows.map(row => `('${row.d_partner_id}', '${row.waybill}')`).join(',');

    
    const { rows: existing } = await client.query(`
      SELECT d_partner_id, waybill 
      FROM waybills 
      WHERE (d_partner_id, waybill) IN (${waybillPairs})
    `);

    
    const existingSet = new Set(existing.map(e => `${e.d_partner_id}|${e.waybill}`));

    
    for (const row of rows) {
      const key = `${row.d_partner_id}|${row.waybill}`;
      if (existingSet.has(key)) {
        skippedList.push({ d_partner_id: row.d_partner_id, waybill: row.waybill });
      } else {
        insertList.push(row);
      }
    }

    for (const row of insertList) {
      await client.query(
        `INSERT INTO waybills (d_partner_id, waybill, status, import_by)
         VALUES ($1, $2, $3, $4)`,
        [row.d_partner_id, row.waybill, row.status, user_id]
      );
    }


if (insertList.length > 0) {
  const user = req.user
  const user_id = user.user_id
  const module = "Waybills";
  const logMessage = `Imported ${insertList.length} waybill(s) by user ${user_id}`;
  await insertAdminLog(user_id, module, logMessage);    
}
      res.status(200).json({
      message: `${insertList.length} new waybills inserted.`,
      inserted: insertList.length,
      skipped: skippedList.length,
      skippedWaybills: skippedList,
    });
  } catch (error) {
    console.error('Upload Error:', error);
    res.status(500).json({ message: 'Internal server error' });
  } finally {
    client.release();
  }
});

router.post("/getunusewaybills", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      d_partner_id,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [`status = 'unuse'`];

    if (d_partner_id) {
      queryParams.push(d_partner_id);
      whereConditions.push(`d_partner_id = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const dataQuery = `
      SELECT waybill_id, waybill, upload_date, import_by, status
      FROM waybills
      ${whereClause}
      ORDER BY upload_date DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const countQuery = `
      SELECT COUNT(*)::int AS total
      FROM waybills
      ${whereClause}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const result = await pool.query(dataQuery, paginatedParams);
    const countResult = await pool.query(countQuery, queryParams);

    const total = countResult.rows[0].total;

    res.json({
      waybills: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching unuse waybills:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/getusewaybills", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      d_partner_id 
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    const queryParams = [];
    let whereClause = "WHERE status = 'use'";
    
    if (d_partner_id) {
      queryParams.push(d_partner_id);
      whereClause += ` AND d_partner_id = $${queryParams.length}`;
    }

    // const collectionsQuery = `
    //   SELECT *
    //   FROM waybills
    //   ${whereClause}
    //   , waybill_id DESC
    //   LIMIT $${queryParams.length + 1}
    //   OFFSET $${queryParams.length + 2}
    // `;

    const collectionsQuery = `
  SELECT *
  FROM waybills
  ${whereClause}
  ORDER BY waybill_id DESC
  LIMIT $${queryParams.length + 1}
  OFFSET $${queryParams.length + 2}
`;


    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM waybills
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      usewaybills: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
      
    });
  } catch (error) {
    console.error("Error fetching unuse waybills:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});



router.post('/deliverystatus', authenticateToken, async (req, res) => {
  const { partner_id, status } = req.body;
   console.log("partner_id",partner_id);
   console.log("status",status);

  if (!partner_id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ success: false, message: 'Invalid partner ID or status value' });
  }

  try {
    await pool.query(
      'UPDATE delivery_partners SET status = $1 WHERE partner_id = $2',
      [status, partner_id]
    );
    res.json({ success: true, message: 'Status updated successfully', partner_id, status });
  } catch (err) {
    console.error('Error updating status:', err.message);
    res.status(500).json({ success: false, message: 'Failed to update partner status' });
  }
});




router.put('/api-configupdate',authenticateToken, async (req, res) => {
  const { partner_id, api_key, customer_id, api_status, webhook_url, two_way_status,email,password,contact_number } = req.body


  try {
    const result = await pool.query(
      `UPDATE delivery_partners
       SET api_key = $1, customer_id = $2, api_status = $3, two_way_url = $5, two_way_status = $6, email = $7, password = $8, contact_number = $9
       WHERE partner_id = $4 RETURNING *`,
      [api_key, customer_id, api_status, partner_id,webhook_url,two_way_status, email,password,contact_number]
    )

    if (result.rowCount === 0) {
      return res.status(404).json({ message: 'Partner not found' })
    }

    res.json({ message: 'API config updated successfully', data: result.rows[0] })
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

router.put('/delivery-partners/:partner_id',authenticateToken, async (req, res) => {
    const { partner_id } = req.params

    const {
      name,
      title,
      description,
      tracking_url,
      logo,
      api_status,
      status,
      type,
      contact_number,
    } = req.body

    try {
      const result = await pool.query(
        `UPDATE delivery_partners
         SET
           name = $1,
           title = $2,
           description = $3,
           tracking_url = $4,
           logo = $5,
           api_status = $6,
           status = $7,
           type = $8,
           contact_number = $9
         WHERE partner_id = $10
         RETURNING *`,
        [
          name,
          title,
          description,
          tracking_url,
          logo,
          api_status,
          status,
          type,
          contact_number,
          partner_id,
        ]
      )

      if (result.rowCount === 0) {
        return res.status(404).json({
          message: 'Delivery partner not found',
        })
      }

      res.json({
        message: 'Delivery partner updated successfully',
        data: result.rows[0],
      })
    } catch (err) {
      console.error(err)

      res.status(500).json({
        message: 'Internal server error',
      })
    }
  }
)

module.exports = router;
