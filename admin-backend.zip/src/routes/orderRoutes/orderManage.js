const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const qs = require("qs");
const { insertAdminLog } = require("../../models/userLogs");
const { insertSystemLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");
const updateTransactionRecord = require("../transactionsUpdater/transactionsUpdater");

const axios = require("axios");
const {
  sendsmstemp,
  sendemailtemp,
  customhook,
} = require("../../models/smsnotificationmodel");
const { encryptId } = require("../../util/orderEncrypt");
const { transexpress,citypak } = require("../../models/deliverypatner");
require("dotenv").config();

const formatPhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]+$/; // Ensure only numbers are allowed
  if (!phoneRegex.test(phone)) {
    return { error: "Invalid phone number. Only digits are allowed." };
  }
  if (phone.startsWith("07") && phone.length === 10) {
    return { formatted: "94" + phone.substring(1) }; // Convert 07xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("+94") && phone.length === 12) {
    return { formatted: phone.substring(1) }; // Remove "+" to make it 94xxxxxxxxxx
  } else if (phone.startsWith("7") && phone.length === 9) {
    return { formatted: "94" + phone }; // Convert 7xxxxxxxx to 947xxxxxxxx
  } else if (phone.startsWith("94") && phone.length === 11) {
    return { formatted: phone }; // Keep as is
  }
  return { error: "Invalid phone number format." };
};

router.post("/allorders", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      payment_status,
      date,
      todate,
      keyword,
      order_status,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.payment_status = $${queryParams.length}`);
    }

    // if (Array.isArray(order_status) && order_status.length > 0) {
    //   queryParams.push(order_status);
    //   whereConditions.push(`o.order_status = ANY($${queryParams.length})`);
    // }

    // Handle order_status logic
    if (Array.isArray(order_status)) {
      if (order_status.length > 0) {
        queryParams.push(order_status);
        whereConditions.push(
          `o.order_status = ANY($${queryParams.length}::text[])`
        );

        // If cancelled is NOT selected → exclude it
        if (!order_status.includes("cancelled")) {
          queryParams.push("cancelled");
          whereConditions.push(`o.order_status != $${queryParams.length}`);
        }
      } else {
        // Empty array → exclude cancelled always
        queryParams.push("cancelled");
        whereConditions.push(`o.order_status != $${queryParams.length}`);
      }
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const ordersQuery = `
      SELECT 
        o.order_id,
        o.created_at,
        o.order_status,
        o.payment_status,
        o.total_value,
        o.tracking_id,
        o.recipient_city,
        o.storepickup,
        o.payment_method_id,
        o.bank_slip,
        o.delivery_fee,
        o.discount,
        o.amount_paid,
        o.tax,
        o.tax_percentage,
        o.transaction_fee,
        o.full_amount,
        o.delivery_partner_id,
        c.first_name AS customer_name,
        o.recipient_contact AS contact_number,
        dp.name AS delivery_partner_name,
        py.method_name AS method_name,
        ss.currency AS currency,
        ss.tax_value As tax_value
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN payment_methods py ON o.payment_method_id = py.payment_method_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/recipientname", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT recipient_name FROM orders WHERE recipient_name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/pendingorders", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      todate,
      payment_status,
      paymentMethod,
      date,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    whereConditions.push(`o.order_status = 'pending'`);

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.payment_status = $${queryParams.length}`);
    }

    if (paymentMethod) {
      queryParams.push(paymentMethod);
      whereConditions.push(`p.method_name = $${queryParams.length}`);
    }
    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const ordersQuery = `
      SELECT 
        o.order_id,
        o.created_at,
        o.payment_status,
        o.total_value,
        o.recipient_name,
        o.recipient_contact,
        o.recipient_address,
        o.recipient_city,
        o.total_weight,
        o.order_note,
        o.total_value,
        o.storepickup,
        o.delivery_partner_id,
        o.payment_method_id,
        o.bank_slip,
        o.full_amount,
        c.first_name AS customer_name,
        c.contact_number_1 AS contact_number,
        p.method_name AS payment_method_id2,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN payment_methods p ON o.payment_method_id = p.payment_method_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN payment_methods p ON o.payment_method_id = p.payment_method_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      pendingorders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/comfirmedorders", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      order_id,
      recipient_name,
      mobile,
      payment_status,
      keyword,
      paymentMethod,
      date,
      todate,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    whereConditions.push(`o.order_status = 'confirmed'`);

    // if (order_id) {
    //   queryParams.push(order_id);
    //   whereConditions.push(`o.order_id = $${queryParams.length}`);
    // }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.confirmed_date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    // if (recipient_name) {
    //   queryParams.push(`%${recipient_name}%`);
    //   whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
    // }

    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.payment_status = $${queryParams.length}`);
    }

    // if (mobile) {
    //   queryParams.push(mobile);
    //   whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
    // }

    if (paymentMethod) {
      queryParams.push(paymentMethod);
      whereConditions.push(`p.method_name = $${queryParams.length}`);
    }

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const ordersQuery = `
      SELECT 
        o.order_id,
        o.created_at,
        o.payment_status,
        o.confirmed_date,
        o.confiremed_by,
        o.total_value,
        c.first_name AS customer_name,
        o.storepickup,
        o.payment_method_id,
        o.full_amount,
        o.bank_slip,
        c.contact_number_1 AS contact_number,
        dp.name AS delivery_partner_name,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
       LEFT JOIN payment_methods p ON o.payment_method_id = p.payment_method_id
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
       LEFT JOIN payment_methods p ON o.payment_method_id = p.payment_method_id
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      confirmedOrders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/delivery-partners", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT partner_id AS value, name AS label,api_status, logo
       FROM delivery_partners 
       WHERE status = 'active'`
    );
    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching delivery partners:", err);
    res.status(500).json({ error: "Failed to fetch delivery partners" });
  }
});

router.post("/cancel-order", authenticateToken, async (req, res) => {
  const { order_id, status, custom_reason } = req.body;
  const user = req.user;
  const user_id = user.user_id;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // ✅ Step 1: Update order status
    const result = await client.query(
      `UPDATE orders 
       SET order_status = $1,
           cancelled_by = $2,
           cancelled_date = NOW(),
           reason_id = $4
       WHERE order_id = $3 
       RETURNING *`,
      [status, user_id, order_id, custom_reason]
    );

    if (result.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found." });
    }

    // ✅ Step 2: Get user info (for outlet & merchant)
    const userRes = await client.query(
      `SELECT username, outlet_id, merchant_id FROM users WHERE user_id = $1`,
      [user_id]
    );
    if (userRes.rowCount === 0) throw new Error("User not found");
    const { username, outlet_id, merchant_id } = userRes.rows[0];

    // ✅ Step 3: Fetch order items
    const itemsRes = await client.query(
      `
  SELECT
    oi.variant_id,
    oi.quantity,
    COALESCE(oi.free_quantity, 0) AS free_quantity,
    p.measurement_id,
    p.amount_per_unit
  FROM order_items oi
  JOIN products p ON p.product_id = oi.product_id
  WHERE oi.order_id = $1
  `,
      [order_id]
    );

    const orderItems = itemsRes.rows;
    const insufficientStockItems = [];

    for (const item of orderItems) {
      // ✅ define everything ONCE
      const {
        variant_id,
        quantity,
        free_quantity,
        measurement_id,
        amount_per_unit,
      } = item;

      // base units to restore
      const totalUnits =
        Math.abs(Number(quantity || 0)) + Math.abs(Number(free_quantity || 0));

      let totalAdd;

      // ✅ measurement-based restore
      if (
        measurement_id !== null &&
        measurement_id !== 1 &&
        amount_per_unit !== null
      ) {
        totalAdd = totalUnits * Number(amount_per_unit);
      } else {
        // ✅ fallback to original behavior
        totalAdd = totalUnits;
      }

      const system_module = "stock in";
      const comment = `{${user_id}, cancel-order}`;
      const updated_by = username;

      // previous stock
      const prevRes = await client.query(
        `SELECT COALESCE(new_quantity, 0) AS new_quantity
     FROM inventory
     WHERE variant_id = $1 AND outlet_id = $2
     ORDER BY inventory_id DESC
     LIMIT 1`,
        [variant_id, outlet_id]
      );

      const previous_quantity = Number(prevRes.rows[0]?.new_quantity || 0);
      const new_quantity = previous_quantity + totalAdd;

      if (totalAdd > 0) {
        // optional log — remove if you don't want logging
        // console.log(
        //   `Restoring ${totalAdd} (qty:${add_main} + free:${add_free}) for variant ${variant_id}`
        // );
      }

      // insert inventory ledger row (structure unchanged)
      await client.query(
        `INSERT INTO inventory (
      variant_id, outlet_id, merchant_id, user_id,
      updated_by, comment, system_module,
      previous_quantity, adjust_quantity, new_quantity, status
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'active')`,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          totalAdd, // adjust_quantity now holds combined qty+free to restore
          new_quantity,
        ]
      );
    }

    await client.query("COMMIT");

    // 📨 Notifications (after successful TX)
    await insertNotification(
      user_id,
      "Order Management",
      "Order Cancelled",
      `Order #${order_id} has been cancelled and inventory restored.`,
      "Website Notification",
      "Unread"
    );

    // 🧾 Admin log
    const module = "Orders";
    const logMessage = `Cancelled order ${order_id} by user ${user_id} and restored inventory`;
    await insertAdminLog(user_id, module, logMessage);

    // 🔔 Fire-and-forget notifications AFTER response is flushed
    // Only when actually cancelled
    try {
      const updatedStatus = result?.rows?.[0]?.order_status || status;
      if (String(updatedStatus).toLowerCase() === "cancelled") {
        res.on("finish", () => {
          setImmediate(() => {
            try {
              const ACTION_ID = 5; // 📝 Order Cancelled (CHANGE if your template uses a different id)
              sendsmstemp(ACTION_ID, order_id).catch((e) =>
                console.error("sendsmstemp error:", e)
              );
              sendemailtemp(ACTION_ID, order_id).catch((e) =>
                console.error("sendemailtemp error:", e)
              );
            } catch (err) {
              console.error("Notification scheduling error:", err);
            }
          });
        });
      }
    } catch (e) {
      console.error("Post-response notifier setup failed:", e);
    }

    res.status(200).json({
      success: true,
      message: `Order ${order_id} cancelled and inventory restored.`,
      data: result.rows[0],
    });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Cancel error:", err);

    res.status(500).json({ message: "Server error while cancelling order." });
  } finally {
    client.release();
  }
});

// assign order

router.post("/assign-order", authenticateToken, async (req, res) => {
  const { order_id, status, delivery_partner_id, assignment_type, partnerId } =
    req.body;
 console.log("delivery_partner_idmain",delivery_partner_id)
  const user = req.user;
  const user_id = user.user_id;
  const user_merchant_id = user.merchant_id
  const user_outlet_id = user.outlet_id

  if (!order_id || !user_id || !status) {
    return res
      .status(400)
      .json({ success: false, message: "Missing required fields" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // --- Get order + customer + module ---
    const orderRes = await client.query(
      `SELECT customer_id, order_module, payment_status, payment_method_id FROM orders WHERE order_id = $1`,
      [order_id]
    );
    if (orderRes.rowCount === 0) throw new Error("Order not found");

    const { customer_id, order_module, payment_method_id, payment_status } =
      orderRes.rows[0];

    let waybill = null;

    // ==========================================================
    // 1) STORE PICKUP BRANCH: set CONFIRMED and continue
    // ==========================================================
    if (assignment_type === "storepickup") {
      await client.query(
        `UPDATE orders
           SET order_status = 'confirmed',
               confiremed_by = $1,
               confirmed_date = COALESCE(confirmed_date, NOW()),
               storepickup = 'Yes',
               delivery_partner_id = $3
               WHERE order_id = $2`,
        [user_id, order_id, partnerId]
      );

      // continue to inventory deduction below (no early return)
    } else {
      // ==========================================================
      // 2) DELIVERY BRANCH (existing behavior) + partner creds
      // ==========================================================
      // Pull partner API status **and** credentials
      const partnerRes = await client.query(
        `SELECT api_status, api_key, customer_id
         FROM delivery_partners
         WHERE partner_id = $1`,
        [delivery_partner_id]
      );
      if (partnerRes.rowCount === 0)
        throw new Error("Delivery Partner not found");

      const {
        api_status: apiStatus,
        api_key,
        customer_id: partner_customer_id,
      } = partnerRes.rows[0] ?? {};

      if (delivery_partner_id === 4 && apiStatus === "enable") {
        // Fetch live order/recipient info
        const infoRes = await client.query(
          `
          SELECT 
            recipient_name,
            recipient_contact,
            recipient_address,
            recipient_city,
            total_weight::numeric AS parcel_weight,
            order_note AS parcel_description,
            order_id,
            full_amount
          FROM orders WHERE order_id = $1
        `,
          [order_id]
        );

        if (infoRes.rowCount === 0)
          throw new Error("Order or recipient info not found");
        const info = infoRes.rows[0];

        const formatphoneNmber = formatPhoneNumber(info.recipient_contact);
        if (formatphoneNmber.error) {
          return res.status(400).json({
            success: false,
            error_from: "Format Function",
            message: formatphoneNmber.error,
          });
        }



        // Build payload from DB (only 'exchange' is hard-coded as requested).
        // client_id & api_key come from delivery_partners table.
        const payload = {
          client_id: Number(partner_customer_id), // from delivery_partners.customer_id
          api_key: api_key, // from delivery_partners.api_key
          partner_id: delivery_partner_id, // optional — set for traceability
          recipient_name: info.recipient_name?.trim() || "",
          recipient_contact_no: formatphoneNmber.formatted,
          recipient_address: info.recipient_address?.trim() || "",
          recipient_city: info.recipient_city?.trim() || "",
          //recipient_city: "ABC",
          parcel_weight:
            Number(info.parcel_weight) > 0 ? Number(info.parcel_weight) : 1,
          parcel_description:
            info.parcel_description?.toString().trim() || "General Merchandise",
          order_id: order_id,
          cod_amount:
            payment_method_id === 3 && payment_status === "unpaid"
              ? Number(info.full_amount) || 0
              : 0,
          exchange: "0", // hard-coded as per your instruction
        };
        try {
          const response = await axios.post(
            "https://api.simpleexpress.lk/v1/pickup-request",
            //"http://scsapi.sparkglobalsolutions.net/v1/pickup-request",
            payload
          );
          console.log("response", response.data);
          // throw new Error("External API failed to generate waybill");
          if (!response.data?.waybill_no) return;

          const module = "Transer-Simple Express";
          const codAmount =
            payment_method_id === 3 && payment_status === "unpaid"
              ? Number(info.full_amount) || 0
              : 0;
          const logMessage = `✨ Order #${order_id} is being prepared for Simple Express delivery.
                            Payment method is ${payment_method_id} (${payment_status}),
                            with a Cash-on-Delivery amount of LKR ${codAmount}.`;
          await insertAdminLog(user_id, module, logMessage);
          waybill = response.data.waybill_no;
        }


        catch (error) {
          console.log("error", error.response.status);
          if (error.response && error.response.status === 400) {
            if (error.response.data) {
              const { status, message } = error.response.data;
              const logMessage = `Order ${order_id} Delivery API error (code: ${status}) - ${message}`;

              await insertSystemLog(
                user_id,
                "Assign Courier Partner",
                logMessage
              );
              // Optional: log it
              console.error("🚨 API Error:", { status, message });
              return res.status(400).json({
                success: false,
                error_from: "External API",
                status_code: status,
                message: message,
              });
            } else {
              const logMessage = `Order ${order_id} Delivery API 400 error - No message received`;

              await insertSystemLog(
                user_id,
                "Assign Courier Partner",
                logMessage
              );
              return res.status(400).json({
                success: false,
                error_from: "External API",
                status_code: status,
                message: message || "Unknown error from delivery partner",
              });
            }

            // Return the API's error message to the client
          } else {
            const fallbackMsg = error?.message || "Unknown error occurred";
            await insertSystemLog(
              user_id,
              "Assign Courier Partner",
              `Unexpected error: ${fallbackMsg}`
            );
            // Fallback for unexpected errors (like no response, network failure, etc.)
            console.error("❌ Unexpected error:", error.message);
            return res.status(500).json({
              success: false,
              message: "An unexpected error occurred. Please contact admin.",
            });
          }
        }

        // console.log("response MAdu",payload);
      }
      else if (delivery_partner_id === 2 && apiStatus === "enable") {

        const infoRes = await client.query(
          `
    SELECT 
      recipient_name,
      recipient_contact,
      recipient_address,
      recipient_city,
      total_weight::numeric AS parcel_weight,
      order_note AS parcel_description,
      order_id,
      full_amount
    FROM orders WHERE order_id = $1
    `,
          [order_id]
        );

        if (infoRes.rowCount === 0)
          throw new Error("Order or recipient info not found");

        const info = infoRes.rows[0];

        const formatphoneNmber = formatPhoneNumber(info.recipient_contact);
        if (formatphoneNmber.error) {
          return res.status(400).json({
            success: false,
            error_from: "Format Function",
            message: formatphoneNmber.error,
          });
        }

        // 🔹 EXACT MATCH TO PHP cURL ARRAY
        const payload = {
          api_key: api_key,
          client_id: String(partner_customer_id),
          order_id: String(order_id),
          parcel_weight:
            Number(info.parcel_weight) > 0 ? Number(info.parcel_weight) : 1,
          parcel_description:
            info.parcel_description?.toString().trim() || "api sample",
          recipient_name: info.recipient_name?.trim() || "",
          recipient_contact_1: formatphoneNmber.formatted || "",
          recipient_contact_2: "",
          recipient_address: info.recipient_address?.trim() || "",
          recipient_city: info.recipient_city?.trim() || "",
          amount:
            payment_method_id === 3 && payment_status === "unpaid"
              ? String(info.full_amount || 0)
              : "0",
          exchange: "0",
        };

        // console.log("📦 FDE PAYLOAD:", payload);

        try {
          const response = await axios.post(
            "https://www.fdedomestic.com/api/parcel/new_api_v1.php",

            // 🔥 THIS IS THE KEY FIX
            qs.stringify(payload),

            {
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
              },
              timeout: 15000,
            }
          );

          console.log("📦 FDE RESPONSE:", response.data);

          const fdeStatus = response.data?.status;
          const waybillNo = response.data?.waybill_no?.trim();

          // ❌ DO NOT THROW — HANDLE BUSINESS FAILURE
          if (!waybillNo) {
            await insertSystemLog(
              user_id,
              "Assign Courier Partner",
              `Order ${order_id} FDE API error (${fdeStatus}) - Waybill not generated`
            );

            return res.status(400).json({
              success: false,
              error_from: "External API",
              status_code: fdeStatus,
              message: "FDE did not generate waybill",
            });
          }
          const module = "Transer-FARDER";
          const codAmount =
            payment_method_id === 3 && payment_status === "unpaid"
              ? Number(info.full_amount) || 0
              : 0;
          const logMessage = `✨ Order #${order_id} is being prepared for FARDER delivery.
                            Payment method is ${payment_method_id} (${payment_status}),
                            with a Cash-on-Delivery amount of LKR ${codAmount}.`;
          await insertAdminLog(user_id, module, logMessage);
          // ✅ SUCCESS
          waybill = waybillNo;

        } catch (error) {

          const message =
            error?.response?.data ||
            error?.message ||
            "FDE API error";

          await insertSystemLog(
            user_id,
            "Assign Courier Partner",
            `Order ${order_id} FDE API exception - ${JSON.stringify(message)}`
          );

          return res.status(400).json({
            success: false,
            error_from: "External API",
            message: "FDE request failed",
          });
        }
      }
      // else if (delivery_partner_id === 8 && apiStatus === "enable") {
      //   const result = await transexpress(client, order_id, user_id, delivery_partner_id);
      //   console.log("Transexpress Result:", result);

      //   if (result?.waybill) {
      //     waybill = result.waybill;
      //   }
      // }
      else if (delivery_partner_id === 8 && apiStatus === "enable") {

  const result = await transexpress(
    client,
    order_id,
    user_id,
    delivery_partner_id
  );

  console.log("Transexpress Result:", result);

  // ❌ STOP IF FAILED
  if (!result.success || !result.waybill) {

    await insertSystemLog(
      user_id,
      "Assign Courier Partner",
      `Order ${order_id} Transexpress API failed - Waybill not generated`
    );

    return res.status(400).json({
      success: false,
      error_from: "Transexpress API",
      message:
        result.error || "Transexpress failed to generate waybill",
    });
  }

  // ✅ SUCCESS ONLY
  waybill = result.waybill;
}
      //  else if (delivery_partner_id === 9 && apiStatus === "enable") {
      //   const result = await citypak(client, order_id, delivery_partner_id);
      //   console.log("citypak Result:", result);

      //   if (result?.waybill) {
      //     waybill = result.waybill;
      //   }
      // }
      else if (delivery_partner_id === 9 && apiStatus === "enable") {

  const result = await citypak(
    client,
    order_id,
    delivery_partner_id
  );

  console.log("Citypak Result:", result);

  // ❌ If waybill not generated stop everything
  if (!result?.waybill) {

    await insertSystemLog(
      user_id,
      "Assign Courier Partner",
      `Order ${order_id} Citypak API failed - Waybill not generated`
    );

    return res.status(400).json({
      success: false,
      error_from: "Citypak API",
      message:
        result?.error || "Waybill not generated",
    });
  }

  // ✅ Success only
  waybill = result.waybill;
}
      else {
        // Reserve waybill from pool
        const waybillRes = await client.query(
          `SELECT waybill FROM waybills 
             WHERE d_partner_id = $1 AND status = 'unuse'
             LIMIT 1 FOR UPDATE`,
          [delivery_partner_id]
        );
        if (waybillRes.rowCount === 0)
          throw new Error("No available waybills for this delivery partner");

        waybill = waybillRes.rows[0].waybill;

        await client.query(
          `UPDATE waybills
              SET status = 'use', order_id = $1, customer_id = $2, upload_date = NOW()
            WHERE waybill = $3`,
          [order_id, customer_id, waybill]
        );
      }

      // Update order and tracking for delivery flow
      await client.query(
        `UPDATE orders
           SET order_status = $1,
               confiremed_by = $2,
               confirmed_date = NOW(),
               delivery_partner_id = $3
         WHERE order_id = $4`,
        [status || "confirmed", user_id, delivery_partner_id || null, order_id]
      );

      if (waybill) {
        await client.query(
          `UPDATE orders SET tracking_id = $1 WHERE order_id = $2`,
          [waybill, order_id]
        );
      }
    }

    const update_outlet_for_order = await client.query(
      `UPDATE orders SET outlet_id = $1, merchant_id = $2 WHERE order_id = $3`,
      [user_outlet_id, user_merchant_id, order_id]
    )
    console.log("user_merchant_id", user_merchant_id)
    if (update_outlet_for_order.rowCount === 0) throw new Error("Update failed for order outlet");

    // --- Verify current status to decide on inventory deduction ---
    const statusRes = await client.query(
      `SELECT order_status FROM orders WHERE order_id = $1`,
      [order_id]
    );
    const currentStatus = statusRes.rows[0]?.order_status;

    if (currentStatus !== "confirmed") {
      await client.query("COMMIT");

      const module = "Orders";
      const logMessage = `Order ${order_id} updated but not confirmed. No stock updated.`;
      await insertAdminLog(user_id, module, logMessage);

      await insertNotification(
        user_id,
        "Orders",
        "Order Updated",
        `Order #${order_id} updated but not confirmed. Inventory unchanged.`,
        "Website Notification",
        "Unread"
      );

      return res.json({
        success: true,
        message:
          "Order assigned/updated, but inventory unchanged (status not confirmed).",
        data: { order_id, customer_id, status: currentStatus },
      });
    }

    // --- Fetch user for outlet/merchant context (needed for inventory rows) ---
    const userRes = await client.query(
      `SELECT username, first_name, last_name, outlet_id, merchant_id
     FROM users WHERE user_id = $1`,
      [user_id]
    );
    if (userRes.rowCount === 0) throw new Error("User not found");

    const { username, first_name, last_name, outlet_id, merchant_id } =
      userRes.rows[0];

    const token_role_id_raw = req.user?.role_id;
    if (token_role_id_raw === undefined || token_role_id_raw === null) {
      throw new Error("role_id missing in token");
    }
    const token_role_id = Number(token_role_id_raw);

    const roleRes = await client.query(
      `SELECT role_name FROM role_list WHERE id = $1`,
      [token_role_id]
    );
    const role_name = roleRes.rows[0]?.role_name ?? "Unknown";

    // --- Get order items ---
    const orderItemsRes = await client.query(
      `
SELECT
  oi.variant_id,
  pv.variant_value,
  oi.quantity,
  COALESCE(oi.free_quantity, 0) AS free_quantity,
  p.measurement_id,
  p.amount_per_unit,
  pv.continue_selling_oos
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN product_variants pv ON pv.variant_id = oi.variant_id
WHERE oi.order_id = $1


  `,
      [order_id]
    );

    const orderItems = orderItemsRes.rows;
    const insufficientStockItems = [];

    for (const item of orderItems) {
      const {
        variant_id,
        quantity,
        free_quantity,
        measurement_id,
        amount_per_unit,
        continue_selling_oos,
      } = item;

      // --- read free_quantity from the same order_items table for this order+variant ---
      //   const freeQtyRes = await client.query(
      //     `SELECT COALESCE(free_quantity, 0) AS free_quantity
      //  FROM order_items
      //  WHERE order_id = $1 AND variant_id = $2
      //  LIMIT 1`,
      //     [order_id, variant_id]
      //   );
      // const freeQty = Number(freeQtyRes.rows[0]?.free_quantity || 0);

      // total to deduct = ordered quantity + free_quantity (both from order_items)
      // free_quantity already comes from orderItems query
      const totalUnits =
        Math.abs(Number(quantity || 0)) + Math.abs(Number(free_quantity || 0));

      let adjust_quantity;

      // ✅ Measurement-based deduction
      if (
        measurement_id !== null &&
        measurement_id !== 1 &&
        amount_per_unit !== null
      ) {
        adjust_quantity = -1 * totalUnits * Number(amount_per_unit);
      } else {
        // ✅ Fallback to old behavior
        adjust_quantity = -1 * totalUnits;
      }

      const system_module = "stock out";
      const comment = `${first_name} ${last_name} | ${role_name} | order:${order_id} | assign-order`;
      const updated_by = username;

      // read previous known stock from inventory ledger (unchanged)
      const prevQtyRes = await client.query(
        `SELECT new_quantity, batch_number
   FROM inventory
   WHERE variant_id = $1 AND outlet_id = $2
   ORDER BY inventory_id DESC
   LIMIT 1`,
        [variant_id, outlet_id]
      );


      const previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity || 0);
      const new_quantity = previous_quantity + adjust_quantity;
      const latest_batch_number = prevQtyRes.rows[0]?.batch_number ?? null;

      if (!continue_selling_oos && new_quantity < 0) {
        insufficientStockItems.push({
          variant_id,
          variant_value: item.variant_value,
          current_stock: previous_quantity,
          required: Math.abs(adjust_quantity),
        });

        continue; // skip inventory insert for this item
      }

      // insert same inventory ledger row (unchanged structure)
      await client.query(
        `INSERT INTO inventory (
    variant_id, outlet_id, merchant_id, user_id,
    updated_by, comment, system_module,
    previous_quantity, adjust_quantity, new_quantity,
    batch_number, status
  ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')`,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          latest_batch_number, // ✅ preserved batch number
        ]
      );

    }

    if (insufficientStockItems.length > 0) {
      await client.query("ROLLBACK");

      return res.status(400).json({
        success: false,
        error_code: "INSUFFICIENT_STOCK",
        continue_selling: false,
        items: insufficientStockItems,
      });
    }

    await client.query("COMMIT");

    const module = "Orders";
    const logMessage =
      assignment_type === "storepickup"
        ? `Store pickup confirmed for order ${order_id} by user ${user_id}; inventory reduced.`
        : `Order ${order_id} confirmed & assigned by user ${user_id}; inventory reduced.`;
    await insertAdminLog(user_id, module, logMessage);

    if (assignment_type === "storepickup") {
      await insertNotification(
        user_id,
        "Order Management",
        "Store Pickup Confirmed",
        `Order #${order_id} marked as CONFIRMED (store pickup). Inventory updated.`,
        "Website Notification",
        "Unread"
      );
    } else {
      await insertNotification(
        user_id,
        "Order Management",
        "Order Confirmed & Assigned",
        `Order #${order_id} confirmed and assigned. Waybill: ${waybill || "N/A"
        }. Inventory updated.`,
        "Website Notification",
        "Unread"
      );
    }

    if (currentStatus === "confirmed") {
      res.on("finish", () => {
        setImmediate(async () => {
          try {
            const ACTION_ID = 2;
            const resnotify = await customhook(ACTION_ID, order_id);
            console.log("📨 customhook results:", resnotify);
          } catch (err) {
            console.error("customhook error:", err);
          }
        });
      });
    }

    return res.json({
      success: true,
      message:
        assignment_type === "storepickup"
          ? "Store pickup confirmed and inventory reduced."
          : "Order confirmed, waybill handled (if applicable), and inventory reduced.",
      data: {
        order_id,
        customer_id,
        status: currentStatus,
        waybill: waybill || null,
      },
    });
  } catch (err) {
    await client.query("ROLLBACK");
    // console.error("❌ Assignment error:", err);
    return res.status(500).json({ success: false, message: err.message });
  } finally {
    client.release();
  }
});


router.post("/processing-order", authenticateToken, async (req, res) => {
  const { order_id, status } = req.body;
  const user_id = req.user?.user_id;

  try {
    // Only allow valid transitions
    if (!["processing", "completed"].includes(status)) {
      return res.status(400).json({
        message: 'Invalid status. Use "processing" or "completed".',
      });
    }

    const result = await pool.query(
      `UPDATE orders
          SET order_status = $1
        WHERE order_id = $2
      RETURNING *`,
      [status, order_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order not found." });
    }

    // Admin log only (NO inventory)
    const module = "Orders";
    const logMessage =
      status === "completed"
        ? `Completed order ${order_id} by user ${user_id}`
        : `Processing order ${order_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    return res.status(200).json({
      success: true,
      message:
        status === "completed"
          ? `Order ${order_id} marked as completed.`
          : `Order ${order_id} marked as processing.`,
      data: result.rows[0],
    });
  } catch (err) {
    console.error("❌ Processing error:", err);
    return res
      .status(500)
      .json({ message: "Server error while processing order." });
  }
});



// dispatch orders
router.post("/dispatchedorders", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      payment_status,
      date,
      todate,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    whereConditions.push(`o.order_status = 'dispatched'`);

    // keyword filter
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    // date filter
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.confirmed_date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
      );
    }

    // payment status filter
    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.payment_status = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const ordersQuery = `
      SELECT 
        o.order_id,
        o.created_at,
        o.order_status,
        o.confirmed_date,
        o.confiremed_by,

        o.payment_status,
        o.total_value,
        o.full_amount,

        o.recipient_name,
        o.recipient_contact,
        o.recipient_address,
        o.recipient_city,

        o.total_weight,
        o.order_note,

        o.storepickup,
        o.delivery_type,

        o.delivery_partner_id,
        dp.name AS delivery_partner_name,

        o.payment_method_id,
        p.method_name AS payment_method_id2,

        o.bank_slip,
        o.tracking_id,

        c.first_name AS customer_name,
        c.contact_number_1 AS contact_number,

        ss.currency AS currency

      FROM orders o

      LEFT JOIN delivery_partners dp 
        ON o.delivery_partner_id = dp.partner_id

      LEFT JOIN customer c 
        ON o.customer_id = c.customer_id

      LEFT JOIN payment_methods p 
        ON o.payment_method_id = p.payment_method_id

      LEFT JOIN system_settings ss 
        ON ss.id = 1

      ${whereClause}

      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o

      LEFT JOIN delivery_partners dp 
        ON o.delivery_partner_id = dp.partner_id

      LEFT JOIN customer c 
        ON o.customer_id = c.customer_id

      LEFT JOIN payment_methods p 
        ON o.payment_method_id = p.payment_method_id

      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      dispatchedOrders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching dispatched orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
router.post("/deliverd-statsorder", authenticateToken, async (req, res) => {
  const { order_id, status } = req.body;

  const user = req.user;
  const user_id = user.user_id;

  try {
    const result = await pool.query(
      `UPDATE orders 
       SET order_status = $1
       WHERE order_id = $2 
       RETURNING *`,
      [status, order_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order not found." });
    }

    const module = "Orders";
    const logMessage = `Deliverd order ${order_id} by user ${user_id}`;
    await insertAdminLog(user_id, module, logMessage);

    const ACTION_ID = 4;
    let resnotify = null;
    try {
      resnotify = await customhook(ACTION_ID, order_id);
      console.log("Notification sent:", resnotify);
    } catch (hookErr) {
      console.error("Notification hook error:", hookErr);
    }

    res.status(200).json({
      success: true,
      message: `Order ${order_id} deliverd successfully.`,
      data: result.rows[0],
      notify: resnotify,
    });
  } catch (err) {
    console.error("Error deliverd order:", err);
    res.status(500).json({ message: "Server error while deliverd order." });
  }
});

router.put("/update-order", async (req, res) => {
  const { order_id, order_status, payment_status, total_value } = req.body;

  if (!order_id) {
    return res.status(400).json({ error: "Order ID is required" });
  }

  console.log("order_id", order_id);
  console.log("order_status", order_status);
  console.log("payment_status", payment_status);
  console.log("total_value", total_value);

  try {
    const updateQuery = `
      UPDATE orders
      SET
        order_status = $1,
        payment_status = $2,
        total_value = $3,
        
        updated_at = NOW()
      WHERE order_id = $4
      RETURNING *;
    `;
    const values = [order_status, payment_status, total_value, order_id];

    const result = await pool.query(updateQuery, values);

    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    res.json({ message: "Order updated successfully", order: result.rows[0] });
  } catch (err) {
    console.error("Error updating order:", err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/allpaymentmethods", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 25 } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    const paymentMethodsQuery = `
      SELECT 
        payment_method_id,
        method_name,
        payment_type,
        logo,
        payment_intraduction,
        api_array,
        commission_status,
        transaction_fee,
        transaction_fixed_fee,
        status
      FROM payment_methods
      ORDER BY payment_method_id ASC
      LIMIT $1 OFFSET $2
    `;

    const paymentMethods = await pool.query(paymentMethodsQuery, [
      parsedLimit,
      offset,
    ]);

    const processedPaymentMethods = paymentMethods.rows.map((method) => {
      let introList = [];

      try {
        // Try parsing as JSON array (if stored correctly)
        const parsed = JSON.parse(method.payment_intraduction);
        if (Array.isArray(parsed)) {
          introList = parsed.map((item) => `'${item}'`);
        } else {
          // Fallback: try splitting manually if it's malformed
          introList = method.payment_intraduction
            .replace(/[{}"]/g, "") // Remove braces and quotes
            .split(",")
            .map((entry) => `'${entry.trim()}'`);
        }
      } catch (err) {
        // Handle invalid JSON gracefully
        introList = method.payment_intraduction
          ?.replace(/[{}"]/g, "")
          .split(",")
          .map((entry) => `'${entry.trim()}'`);
      }

      return {
        ...method,
        payment_intraduction: introList,
      };
    });

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM payment_methods
    `;
    const countResult = await pool.query(countQuery);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      paymentMethods: processedPaymentMethods,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching payment methods:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/payment-status", authenticateToken, async (req, res) => {
  const { payment_method_id, status } = req.body;
  const user_id = req.user.user_id;

  if (!payment_method_id || !["active", "inactive"].includes(status)) {
    return res.status(400).json({ message: "Invalid input" });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const { rows } = await client.query(
      `SELECT payment_type 
       FROM payment_methods 
       WHERE payment_method_id = $1`,
      [payment_method_id]
    );

    if (rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Payment method not found" });
    }

    const payment_type = rows[0].payment_type;

    // 🔥 Only enforce rule for IDs 1 & 2
    if (
      payment_type === "online" &&
      status === "active" &&
      [1, 2].includes(payment_method_id)
    ) {
      await client.query(
        `UPDATE payment_methods
         SET status = 'inactive'
         WHERE payment_method_id IN (1, 2)
         AND payment_method_id != $1`,
        [payment_method_id]
      );
    }

    const result = await client.query(
      `UPDATE payment_methods 
       SET status = $1 
       WHERE payment_method_id = $2`,
      [status, payment_method_id]
    );

    if (result.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Payment method not found" });
    }

    await insertAdminLog(
      user_id,
      "Payment Methods",
      `Updated payment method ${payment_method_id} to '${status}'`
    );

    await client.query("COMMIT");

    res.status(200).json({ message: "Status updated successfully" });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    res.status(500).json({ message: "Server error" });
  } finally {
    client.release();
  }
});

router.post("/update-payment-method", async (req, res) => {
  const { payment_method_id, api_array, account_number, commission } = req.body;

  try {
    await pool.query("BEGIN");

    if (api_array && typeof api_array === "object") {
      await pool.query(
        `UPDATE payment_methods
         SET api_array = $1::jsonb
         WHERE payment_method_id = $2`,
        [JSON.stringify(api_array), payment_method_id]
      );
    }
    if (commission && typeof commission === "object") {
      await pool.query(
        `UPDATE payment_methods
     SET commission_status = $1,
         transaction_fixed_fee = $2,
         transaction_fee = $3
     WHERE payment_method_id = $4`,
        [
          commission.enabled,
          commission.transaction_fixed_fee,
          commission.transaction_fee,
          payment_method_id,
        ]
      );
    }

    if (!api_array && account_number) {
      await pool.query(
        `UPDATE payment_methods
         SET payment_intraduction = $1
         WHERE payment_method_id = $2`,
        [account_number, payment_method_id]
      );
    }

    await pool.query("COMMIT");
    res.json({
      success: true,
      message: "Payment method updated successfully.",
    });
  } catch (error) {
    await pool.query("ROLLBACK");
    console.error("Update failed", error);
    res.status(500).json({ success: false, message: "Update failed" });
  }
});

router.post("/update-payment-method2", authenticateToken, async (req, res) => {
  const { payment_method_id, api_array, status, commission } = req.body;

  const user = req.user;
  const user_id = user.user_id;
  if (!payment_method_id) {
    return res.status(400).json({ message: "Missing payment_method_id" });
  }

  try {
    await pool.query("BEGIN");

    if (api_array && typeof api_array === "object") {
      await pool.query(
        `UPDATE payment_methods
         SET api_array = $1::jsonb
         WHERE payment_method_id = $2`,
        [JSON.stringify(api_array), payment_method_id]
      );
    }
    if (commission && typeof commission === "object") {
      await pool.query(
        `UPDATE payment_methods
     SET commission_status = $1,
         transaction_fixed_fee = $2,
         transaction_fee = $3
     WHERE payment_method_id = $4`,
        [
          commission.enabled,
          commission.transaction_fixed_fee,
          commission.transaction_fee,
          payment_method_id,
        ]
      );
    }

    if (status && ["active", "inactive"].includes(status)) {
      const { rows } = await pool.query(
        "SELECT payment_type FROM payment_methods WHERE payment_method_id = $1",
        [payment_method_id]
      );

      if (rows.length === 0) {
        await pool.query("ROLLBACK");
        return res.status(404).json({ message: "Payment method not found" });
      }

      const paymentType = rows[0].payment_type;

      if (paymentType === "online" && status === "active") {
        await pool.query(
          `UPDATE payment_methods
           SET status = 'inactive'
           WHERE payment_type = 'online' AND payment_method_id != $1`,
          [payment_method_id]
        );
      }

      await pool.query(
        "UPDATE payment_methods SET status = $1 WHERE payment_method_id = $2",
        [status, payment_method_id]
      );

      if (user_id) {
        const module = "Payment Methods";
        const logMessage = `Updated payment method ${payment_method_id} status to '${status}'`;
        await insertAdminLog(user_id, module, logMessage);
      }
    }

    await pool.query("COMMIT");
    res.json({
      success: true,
      message: "Payment method updated successfully.",
    });
  } catch (error) {
    await pool.query("ROLLBACK");
    console.error("Update failed", error);
    res.status(500).json({ success: false, message: "Update failed" });
  }
});

router.post("/confirm-order", authenticateToken, async (req, res) => {
  const { order_id, status } = req.body;
  const user = req.user;
  const user_id = user.user_id;
  try {
    const result = await pool.query(
      `UPDATE orders 
       SET order_status = $1
       WHERE order_id = $2 
       RETURNING *`,
      [status, order_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Order not found." });
    }

    const module = "Orders";
    const logMessage = `confirm order ${order_id} by user ${user_id}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({
      success: true,
      message: `Order ${order_id} confirm successfully.`,
      data: result.rows[0],
    });
  } catch (err) {
    console.error("Error confirm order:", err);
    res.status(500).json({ message: "Server error while confirm order." });
  }
});

router.put("/order_payment", authenticateToken, async (req, res) => {
  const { order_id, payment_method_id, reference, bank_slip_url } = req.body;
  const user = req.user;
  const user_id = user.user_id;
  console.log("order_id", order_id);
  console.log("payment_method_id", payment_method_id);

  console.log("bank_slip_url", bank_slip_url);

  if (!order_id || !payment_method_id) {
    return res.status(400).json({
      success: false,
      message: "order_id and payment_method_id are required",
    });
  }
  try {
    // Ensure payment_method_id is number
    const safePaymentMethodId = Number(payment_method_id);
    if (isNaN(safePaymentMethodId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid payment_method_id",
      });
    }
    const isCOD = safePaymentMethodId === 3;
    console.log("Is COD and payment method id", isCOD, safePaymentMethodId)

    const oldPaymentQuery = `
      SELECT payment_method_id 
      FROM orders 
      WHERE order_id = $1
    `;
    const oldPaymentResult = await pool.query(oldPaymentQuery, [order_id]);

    if (oldPaymentResult.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    const oldPaymentMethodId = oldPaymentResult.rows[0].payment_method_id;

    // ✅ 2. GET OLD METHOD NAME
    let oldMethodName = "Unknown";
    if (oldPaymentMethodId) {
      const oldMethodRes = await pool.query(
        `SELECT method_name FROM payment_methods WHERE payment_method_id = $1`,
        [oldPaymentMethodId]
      );

      if (oldMethodRes.rowCount > 0) {
        oldMethodName = oldMethodRes.rows[0].method_name;
      }
    }

    // ✅ 3. GET NEW METHOD NAME
    let newMethodName = "Unknown";
    const newMethodRes = await pool.query(
      `SELECT method_name FROM payment_methods WHERE payment_method_id = $1`,
      [safePaymentMethodId]
    );

    if (newMethodRes.rowCount > 0) {
      newMethodName = newMethodRes.rows[0].method_name;
    }

    // Convert empty bank_slip_url to null
    const safeBankSlipUrl = bank_slip_url === "" ? null : bank_slip_url;
    const updateQuery = `
      UPDATE orders
      SET payment_method_id = $1,
          payment_status = 'paid',
          bank_slip = $4,
          cod = $2
      WHERE order_id = $3
      RETURNING *;
    `;
    const values = [safePaymentMethodId, isCOD, order_id, safeBankSlipUrl];
    const result = await pool.query(updateQuery, values);
    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    const settingsQuery =
      "SELECT loyalty_point, points_given, amount_spend FROM system_settings LIMIT 1";
    const settingsResult = await pool.query(settingsQuery);

    if (settingsResult.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "System settings not found",
      });
    }

    const { loyalty_point, points_given, amount_spend } =
      settingsResult.rows[0];

    if (loyalty_point) {
      const order = result.rows[0];
      const fullAmount = order.full_amount;
      const customerId = order.customer_id;

      if (!fullAmount || !amount_spend || !points_given) {
        throw new Error("Invalid data for calculating loyalty points");
      }

      const loyaltyPoints = (fullAmount / amount_spend) * points_given;

      console.log(`customerId`, customerId);
      const updateCustomerPointsQuery = `
    UPDATE customer
    SET loyalty_point = loyalty_point + $1
    WHERE customer_id = $2
    RETURNING *;
  `;
      await pool.query(updateCustomerPointsQuery, [loyaltyPoints, customerId]);

      const updateOrderPointsQuery = `
      UPDATE orders
      SET loyalty_points_earned = $1
      WHERE order_id = $2
  `;
      await pool.query(updateOrderPointsQuery, [loyaltyPoints, order_id]);

      console.log(`Added ${loyaltyPoints} points to customer ${customerId}`);
      console.log(`Loyalty Points for order ${order_id}:`, loyaltyPoints);
    }

    const module = "Orders";
    const logMessage = `Marked order ${order_id} paid.. Changed payment method for order ${order_id} from ${oldMethodName} to ${newMethodName} by user ${user_id}`;
    await insertAdminLog(user_id, module, logMessage);

    const actionId = 10;
    let hookResponse = null;

    try {
      hookResponse = await customhook(actionId, order_id); // YOUR HOOK
    } catch (hookErr) {
      console.error("Customhook error:", hookErr);
    }

    res.json({
      success: true,
      data: result.rows[0],
      actionId,
      hook: hookResponse,
    });
  } catch (err) {
    console.error("Error updating order payment method:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

router.put("/order_unpaidpayment", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { order_id, payment_status } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    await client.query("BEGIN");

    /* ================= GET ORDER ================= */

    const orderLookup = await client.query(
      `
      SELECT *
      FROM orders
      WHERE order_id = $1
      FOR UPDATE
      `,
      [order_id]
    );

    if (orderLookup.rowCount === 0) {

      await client.query("ROLLBACK");

      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    const order = orderLookup.rows[0];

    const outlet_id = order.outlet_id || null;

    /* ================= GET PAYMENT HISTORY FIRST ================= */

    const paymentHistoryRes = await client.query(
      `
      SELECT
        id,
        amount,
        acc_id,
        reference,
        method_id,
        transaction_fee
      FROM invoice_payment_history
      WHERE order_invoice_id = $1
      AND module = 'order'
      AND status = 'active'
      `,
      [order_id]
    );

    /* ================= DENY IF NO PAYMENT HISTORY ================= */

    if (paymentHistoryRes.rowCount === 0) {

      await client.query("ROLLBACK");

      console.log(
        `No invoice_payment_history records found for order ${order_id}`
      );

      return res.status(400).json({
        success: false,
        message: `No transaction history found for order ${order_id}`,
      });
    }

    /* ================= UPDATE ORDER ================= */

    const orderResult = await client.query(
      `
      UPDATE orders
      SET
        payment_status = $1,
        amount_paid = 0,
        loyalty_points_earned = 0,
        updated_at = NOW()
      WHERE order_id = $2
      RETURNING
        order_id,
        customer_id,
        loyalty_points_earned
      `,
      [payment_status, order_id]
    );

    const {
      customer_id,
      loyalty_points_earned,
    } = orderResult.rows[0];

    /* ================= CREATE REVERSAL DEBIT ENTRIES ================= */

    for (const payment of paymentHistoryRes.rows) {

      const revokeAmount =
        parseFloat(payment.amount) || 0;

      const account_id =
        payment.acc_id || null;

      if (
        revokeAmount > 0 &&
        account_id
      ) {

        try {

          await updateTransactionRecord({
            client,
            amount: revokeAmount,
            account_id,
            category_id: 1,
            transaction_type: "expense",
            note: `Order Payment Reversal | Order #${order_id} | Ref: ${payment.reference || "N/A"}`,
            by_user_id: user_id,
            payer_payee_id: customer_id,
            outlet_id,
            log_module: "ORDER_PAYMENT_REVERSAL",
            log_message: `Order payment reversal transaction created | Order: ${order_id} | Amount: ${revokeAmount}`,
          });

          console.log(
            `Created reversal debit transaction for payment history ID ${payment.id}`
          );

        } catch (trxErr) {

          console.error(
            `Failed reversal transaction for payment history ID ${payment.id}`,
            trxErr
          );

          throw trxErr;
        }

      } else {

        console.log(
          `Skipped reversal transaction for payment history ID ${payment.id} due to invalid amount/account`
        );
      }
    }

    /* ================= REVOKE LOYALTY ================= */

    if (
      parseFloat(loyalty_points_earned) > 0 &&
      customer_id
    ) {

      const customerResult = await client.query(
        `
        SELECT loyalty_point
        FROM customer
        WHERE customer_id = $1
        FOR UPDATE
        `,
        [customer_id]
      );

      if (customerResult.rows.length > 0) {

        const currentPoints =
          parseFloat(customerResult.rows[0].loyalty_point) || 0;

        const deductedPoints =
          parseFloat(loyalty_points_earned) || 0;

        const newPoints = Math.max(
          currentPoints - deductedPoints,
          0
        );

        /* ===== UPDATE CUSTOMER ===== */

        await client.query(
          `
          UPDATE customer
          SET loyalty_point = $1
          WHERE customer_id = $2
          `,
          [newPoints, customer_id]
        );

        console.log(
          `Deducted ${deductedPoints} loyalty points from customer ${customer_id}`
        );

        /* ===== INSERT POINT LOG ===== */

        await client.query(
          `
          INSERT INTO points_logs
          (
            customer_id,
            prev_amount,
            adjust_amount,
            new_amount,
            comment
          )
          VALUES ($1,$2,$3,$4,$5)
          `,
          [
            customer_id,
            currentPoints,
            -deductedPoints,
            newPoints,
            `Order payment reversed | Order #${order_id}`
          ]
        );
      }
    }

    /* ================= INACTIVATE PAYMENT HISTORY ================= */

    const paymentHistoryResult = await client.query(
      `
      UPDATE invoice_payment_history
      SET status = 'inactive'
      WHERE order_invoice_id = $1
      AND module = 'order'
      AND status = 'active'
      `,
      [order_id]
    );

    console.log(
      `Inactivated ${paymentHistoryResult.rowCount} invoice payment history records for order ${order_id}`
    );

    /* ================= ADMIN LOG ================= */

    const module = "Orders";

    const logMessage = `
      Marked order ${order_id} as ${payment_status},
      revoked loyalty points,
      created reversal debit statements,
      and inactivated invoice payment history
    `;

    await insertAdminLog(
      user_id,
      module,
      logMessage
    );

    /* ================= COMMIT ================= */

    await client.query("COMMIT");

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      success: true,
      message:
        "Order marked unpaid successfully. Loyalty revoked, debit reversals created, and payment history inactivated.",
      data: orderResult.rows[0],
    });

  } catch (err) {

    await client.query("ROLLBACK");

    console.error(
      "Error in unpaid order update:",
      err
    );

    return res.status(500).json({
      success: false,
      message: "Server error",
    });

  } finally {

    client.release();
  }
});



router.post("/order_link", authenticateToken, async (req, res) => {
  const { order_id } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  try {
    if (!order_id)
      return res
        .status(400)
        .json({ success: false, message: "order_id is required" });

    const query = `SELECT website_url FROM branding_settings WHERE id = 1`;
    const result = await pool.query(query);
    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Branding settings not found" });
    }
    const { website_url } = result.rows[0];

    const encryptID = encryptId(order_id);

    const url = `${website_url}/order/${encryptID}`;

    return res.status(200).json({
      success: true,
      message: "Order link generated successfully.",
      data: url,
    });
  } catch (error) {
    console.error("Error updating order payment method:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

router.post("/send_order_link", authenticateToken, async (req, res) => {
  const { order_id } = req.body;
  const user = req.user;
  const user_id = user.user_id;
  try {
    const response = await customhook(7, order_id);
    console.log("response", response);
    return res.status(200).json({ message: "success" });
  } catch (error) {
    console.error("Error updating order payment method:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
});

router.get("/payment_methods", async (req, res) => {
  try {
    const query = `
        SELECT 
          payment_method_id AS value,
          method_name AS label,
          transaction_fixed_fee,
          transaction_fee AS transaction_fee_percent,
          logo
        FROM payment_methods
        WHERE status = 'active' AND web_show IS TRUE
    `;

    const { rows } = await pool.query(query);

    res.status(200).json({
      success: true,
      message: "All Payment Methods Found",
      result: rows,
    });
  } catch (err) {
    console.error("Error fetching payment methods:", err.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch payment methods",
    });
  }
});

router.post("/update-commission", authenticateToken, async (req, res) => {
  const { payment_method_id, commission } = req.body;

  try {
    await pool.query("BEGIN");

    if (!payment_method_id || !commission) {
      throw new Error("Missing required fields");
    }

    await pool.query(
      `UPDATE payment_methods
       SET commission_status = $1,
           transaction_fixed_fee = $2,
           transaction_fee = $3
       WHERE payment_method_id = $4`,
      [
        commission.enabled, // ✅ TRUE / FALSE directly
        Number(commission.transaction_fixed_fee || 0),
        Number(commission.transaction_fee || 0),
        payment_method_id,
      ]
    );

    await pool.query("COMMIT");

    res.json({
      success: true,
      message: "Commission updated successfully",
    });
  } catch (error) {
    await pool.query("ROLLBACK");
    console.error(error);

    res.status(500).json({
      success: false,
      message: "Commission update failed",
    });
  }
});
module.exports = router;
