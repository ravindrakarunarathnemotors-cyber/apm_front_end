const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");
const {
  sendsmstemp,
  sendemailtemp,
  customhook,
} = require("../../models/smsnotificationmodel");

// route for processing and dispatch orders
router.post("/processing-orders", authenticateToken, async (req, res) => {
  try {
    const {
      order_id,
      dispatched,
      recipient_name,
      mobile,
      keyword,
      date,
      todate,
      page = 1,
      limit = 25,
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    const { merchant_id } = req.user;
    if (!merchant_id) {
      return res
        .status(400)
        .json({ error: "Merchant ID is missing from token." });
    }

    // ✅ Handle dispatch update if payload includes dispatched: true
    if (order_id && dispatched === true) {
      const updateQuery = `
        UPDATE orders
        SET order_status = 'dispatched'
        WHERE order_id = $1 AND merchant_id = $2
        RETURNING order_id;
      `;
      const updateResult = await pool.query(updateQuery, [
        order_id,
        merchant_id,
      ]);

      if (updateResult.rowCount > 0) {
        const module = "Orders";
        const logMessage = `Order ${order_id} marked as dispatched.`;
        await insertAdminLog(user_id, module, logMessage);

        // NEW: action metadata for the hook
        const ACTION_ID = 3;
        const ACTION_NAME = "Order Dispatched"; // kept for clarity/logging

        // 🔔 Fire-and-forget AFTER response finishes (no awaiting)
        res.on("finish", () => {
          setImmediate(() => {
            try {
              // Replace previous SMS/email calls with your customhook
              // Do not await (non-blocking)
              Promise.resolve()
                .then(() => customhook(ACTION_ID, order_id))
                .catch((err) => console.error("customhook error:", err));

              // Insert in-app notification (non-blocking)
              insertNotification(
                user_id, // who triggered it
                "Order Management", // module
                "Order Dispatched", // event_type
                `Order #${order_id} marked as dispatched.`, // message_template
                "in_app", // channel
                "Unread" // status
              ).catch((e) => console.error("Notification insert failed:", e));
            } catch (err) {
              console.error("Post-dispatch scheduling error:", err);
            }
          });
        });

        // Respond immediately
        return res.json({ success: true, dispatched: "success" });
      } else {
        return res.status(404).json({
          success: false,
          message: "Order not found or not authorized",
        });
      }
    }

    // ⬇️ Default behavior: fetch filtered processing orders
    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [
      `o.merchant_id = $1`,
      `o.order_status = 'processing'`,
    ];

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }
    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const fetchQuery = `
      SELECT
        o.order_id,
        o.recipient_name, 
        o.order_status, 
        o.dimensions,
        o.total_item,
        o.total_weight,
        o.delivery_type,
        o.payment_status,
        o.payment_method_id,
        o.storepickup,
        dp.name AS currier_partner,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      ${whereClause};
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const [dataResult, countResult] = await Promise.all([
      pool.query(fetchQuery, paginatedParams),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      success: true,
      orders: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching processing orders:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// cancelled orders

router.post("/cancelled-orders", authenticateToken, async (req, res) => {
  try {
    const { keyword, date, todate, page = 1, limit = 25 } = req.body;

    const { merchant_id } = req.user;
    // const merchant_id = 20001;

    if (!merchant_id) {
      return res
        .status(400)
        .json({ error: "Merchant ID is missing from token." });
    }

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [
      `o.merchant_id = $1`,
      `o.order_status = 'cancelled'`,
    ];

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.cancelled_date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }
    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const fetchQuery = `
      SELECT
        o.order_id,
        o.recipient_name,
        o.delivery_completed_date,
        o.delivery_type,
        o.total_value,
        o.payment_status,
        o.storepickup,
        o.reason_id,
        o.full_amount,
        o.cancelled_date,
        o.payment_method_id,
        CONCAT(c.first_name, ' ', c.last_name) AS client_name,
        dp.name AS currier_partner,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      ${whereClause};
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const [dataResult, countResult] = await Promise.all([
      pool.query(fetchQuery, paginatedParams),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      success: true,
      orders: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching cancelled orders:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

router.post("/completed-orders", authenticateToken, async (req, res) => {
  try {
    const { date, keyword, page = 1, limit = 25, todate } = req.body;

    // const merchant_id = 20001;

    const { merchant_id } = req.user;

    if (!merchant_id) {
      return res
        .status(400)
        .json({ error: "Merchant ID is missing from token." });
    }

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [
      `o.merchant_id = $1`,
      `o.order_status = 'completed'`,
    ];

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const fetchQuery = `
      SELECT
        o.order_id,
        o.recipient_name,
        o.delivery_completed_date,
        o.delivery_type,
        o.total_value,
        o.payment_status,
        o.storepickup,
        o.full_amount,
        o.payment_method_id,
        CONCAT(c.first_name, ' ', c.last_name) AS client_name,
        dp.name AS currier_partner,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      ${whereClause};
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const [dataResult, countResult] = await Promise.all([
      pool.query(fetchQuery, paginatedParams),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      success: true,
      orders: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching completed orders:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// returned orders

router.post("/returned-orders", authenticateToken, async (req, res) => {
  try {
    const { keyword, date, page = 1, limit = 25, todate } = req.body;

    const { merchant_id } = req.user;

    // const merchant_id = 20001;

    if (!merchant_id) {
      return res
        .status(400)
        .json({ error: "Merchant ID is missing from token." });
    }

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`o.merchant_id = $1`, `o.order_status = 'returned'`];

    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.order_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
      }
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.returned_date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const fetchQuery = `
      SELECT
        o.order_id,
        o.returned_person,
        o.returned_date,
        o.payment_status,
        o.total_value,
        o.reason_id,
        o.storepickup,
        o.full_amount,
        o.payment_method_id,
        o.bank_slip,
        ss.currency AS currency
      FROM orders o
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.order_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      ${whereClause};
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const [dataResult, countResult] = await Promise.all([
      pool.query(fetchQuery, paginatedParams),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      success: true,
      orders: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching returned orders:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// orders view modal fetch - order details
// REPLACEMENT: paste this whole handler over your existing router.get("/order-details/:order_id", ...)
router.get("/order-details/:order_id", authenticateToken, async (req, res) => {
  const { order_id } = req.params;

  try {
    const orderDetailsQuery = `
      SELECT 
        o.order_id,
        o.total_value,
        o.amount_paid,
        o.discount,
        o.discount_type,
        o.delivery_fee,
        o.total_weight,
        o.currency,
        o.recipient_contact,
        o.recipient_contact_two,
        o.recipient_email,
        o.recipient_name,
        o.recipient_address,
        o.recipient_postal_code,
        o.recipient_city,
        o.recipient_country,
        o.recipient_addrees_2,
        o.payment_status,
        o.cod,
        o.created_at,
        o.tracking_id,
        o.order_status,
        o.tax,
        o.payment_reference,
            o.loyalty_points_earned,
        o.loyalty_points_spent,
         o.full_amount,
         o.transaction_fee,

        -- only the sender fields you asked for (from orders table)
        o.sender_address,
        o.sender_city,
        o.sender_country,
        o.sender_phone,
        o.sender_phone_two,
        o.sender_email,
        o.sender_addrees_2,

        dp.logo AS partner_logo,
        dp.contact_number AS partner_contact,
        dp.name AS delivery_partner_name,

        cu.customer_id,
        cu.first_name,
        cu.last_name,
        cu.contact_number_1,
        cu.contact_number_2,
        cu.address,
        cu.city,
        cu.postal_code,
        cu.apartment,
        cu.country AS customer_country_code,
        cu.country AS customer_country_id,
        c.country_name AS customer_country,
        py.method_name,
        cu.email
      FROM orders o
      INNER JOIN customer cu ON o.customer_id = cu.customer_id
      LEFT JOIN countries c ON CAST(cu.country AS INTEGER) = c.id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN payment_methods py ON o.payment_method_id = py.payment_method_id
      WHERE o.order_id = $1
    `;

    const orderResult = await pool.query(orderDetailsQuery, [order_id]);

    const brandingQuery = `
      SELECT 
        logo_url_white,
        company_name,
        address_1,
        address_2,
        hotline
      FROM branding_settings
      LIMIT 1
    `;

    const brandingResult = await pool.query(brandingQuery);
    const brand_logo = brandingResult.rows[0]?.logo_url_white || null;

    const fromdetails = {
      company_name: brandingResult.rows[0]?.company_name || null,
      address_1: brandingResult.rows[0]?.address_1 || null,
      address_2: brandingResult.rows[0]?.address_2 || null,
      hotline: brandingResult.rows[0]?.hotline || null,
    };

    // Fetch system settings (explicit column name)
    const settingsQuery = `
  SELECT terms_conditions
  FROM system_settings
  LIMIT 1
`;
    const settingsResult = await pool.query(settingsQuery);
    const terms_and_conditions =
      settingsResult.rows[0]?.terms_conditions ?? null;

    if (orderResult.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const orderDetails = orderResult.rows[0];

    const itemsQuery = `
      SELECT 
        oi.order_item_id,
        oi.variant_id,
        pv.product_id,
        oi.quantity,
        oi.unit_price,
        oi.total_price,
        oi.discount AS item_discount,

        pv.variant_type,
        pv.variant_value,
        oi.is_free,
        oi.free_quantity,
        pv.sku,
        p.amount_per_unit,
        p.title AS product_title,
        p.measurement_id AS product_measurement_id,
        m.measurement_value,
        pm.media_url
      FROM order_items oi
      INNER JOIN product_variants pv ON oi.variant_id = pv.variant_id
      INNER JOIN products p ON pv.product_id = p.product_id
      LEFT JOIN measurements m ON p.measurement_id = m.measurement_id
   LEFT JOIN LATERAL (
  SELECT media_url
  FROM product_media
  WHERE product_id = p.product_id AND main = TRUE AND status = 'active'
  ORDER BY created_at DESC
  LIMIT 1
) pm ON TRUE

      WHERE oi.order_id = $1
      ORDER BY p.title ASC, pv.variant_value ASC
    `;

    const itemsResult = await pool.query(itemsQuery, [order_id]);

    const response = {
      order_details: {
        order_id: orderDetails.order_id,
        total_value: orderDetails.total_value,
        discount: orderDetails.discount,
        discount_type: orderDetails.discount_type,
        delivery_fee: orderDetails.delivery_fee,
        total_weight: orderDetails.total_weight,
        currency: orderDetails.currency,
        tax: orderDetails.tax,
        payment_status: orderDetails.payment_status,
        delivery_partner_logo: orderDetails.partner_logo,
        delivery_partner_contact: orderDetails.partner_contact,
        delivery_partner_name: orderDetails.delivery_partner_name,
        cod: orderDetails.cod,
        created_at: orderDetails.created_at,
        tracking_id: orderDetails.tracking_id,
        order_status: orderDetails.order_status,
        brand_logo: brand_logo,
        payment_reference: orderDetails.payment_reference || null,
        method_name: orderDetails.method_name,
        loyalty_points_earned: orderDetails.loyalty_points_earned ?? 0,
        loyalty_points_spent: orderDetails.loyalty_points_spent ?? 0,
        full_amount: orderDetails.full_amount ?? 0,
           amount_paid: orderDetails.amount_paid ?? 0,
        transaction_fee: orderDetails.transaction_fee > 0
          ? orderDetails.transaction_fee
          : null,
      },

      system_settings: {
        terms_conditions: terms_and_conditions,
      },

      // include recipient_contact_two as requested
      recipient_contact_info: {
        contact: orderDetails.recipient_contact,
        contact_two: orderDetails.recipient_contact_two || null,
        email: orderDetails.recipient_email,
      },

      recipient_address: {
        name: orderDetails.recipient_name,
        address: orderDetails.recipient_address,
        postal_code: orderDetails.recipient_postal_code,
        city: orderDetails.recipient_city,
        country: orderDetails.recipient_country,
        address_2: orderDetails.recipient_addrees_2,
      },

      // customer_address populated from orders.sender_* columns (only the sender columns you specified)
      customer_address: {
        customer_id: orderDetails.customer_id,
        // name: no explicit sender_name provided in your list, keep fallback to customer name
        name:
          orderDetails.sender_email || orderDetails.sender_address // unlikely a name exists; keep as fallback placeholder
            ? orderDetails.first_name || orderDetails.last_name
              ? `${orderDetails.first_name || ""} ${orderDetails.last_name || ""
                }`.trim()
              : null
            : orderDetails.first_name || orderDetails.last_name
              ? `${orderDetails.first_name || ""} ${orderDetails.last_name || ""
                }`.trim()
              : null,
        contact_number_1: orderDetails.sender_phone || null,
        contact_number_2: orderDetails.sender_phone_two || null,
        address: orderDetails.sender_address || null,
        apartment: orderDetails.sender_addrees_2 || null, // not provided in sender_* list
        city: orderDetails.sender_city || null,
        postal_code: null, // sender_postal_code does not exist per your note
        country: orderDetails.sender_country || null,
        country_id: orderDetails.customer_country_id || null,
        email: orderDetails.sender_email || null,
      },

      order_items: itemsResult.rows,

      fromdetails,
    };

    res.status(200).json(response);
  } catch (error) {
    console.error("Error fetching order details:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// date timeline

// GET order timeline (status and timestamps)
// router.get("/timeline/:order_id", authenticateToken, async (req, res) => {
//   const { order_id } = req.params;

//   try {
//     const query = `
//       SELECT
//         order_id,
//         order_status,
//         created_at,  -- include created_at for pending_date
//         confirmed_date,
//         processing_date,
//         dispatched_date,
//         cancelled_date,
//         returned_date,
//         delivery_completed_date
//       FROM orders
//       WHERE order_id = $1
//     `;

//     const { rows } = await pool.query(query, [order_id]);

//     if (rows.length === 0) {
//       return res.status(404).json({ message: "Order not found" });
//     }

//     return res.status(200).json({
//       order_id: rows[0].order_id,
//       order_status: rows[0].order_status,
//       timeline: {
//         pending_date: rows[0].created_at, // renamed from created_at
//         confirmed_date: rows[0].confirmed_date,
//         processing_date: rows[0].processing_date,
//         dispatched_date: rows[0].dispatched_date,
//         cancelled_date: rows[0].cancelled_date,
//         returned_date: rows[0].returned_date,
//         delivery_completed_date: rows[0].delivery_completed_date,
//       },
//     });
//   } catch (err) {
//     console.error("Error fetching order timeline:", err);
//     return res.status(500).json({ message: "Server error" });
//   }
// });

router.get("/timeline/:order_id", authenticateToken, async (req, res) => {
  const { order_id } = req.params;

  const user_id = req.user.user_id;

  try {
    const query = `
      SELECT 
        o.order_id,
        o.order_status,
        o.order_module,
        o.created_at,  -- pending date
        o.confirmed_date,
        o.processing_date,
        o.dispatched_date,
        o.cancelled_date,
        o.returned_person,
        o.returned_date,
        o.delivery_completed_date,
        o.payment_status,
        dp.name AS delivery_partner_name,
        pm.method_name AS payment_method_name,
        us.username AS username,
        o.reason_id,
        cu.first_name AS first_name
      FROM orders o
      LEFT JOIN delivery_partners dp
        ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN payment_methods pm
        ON o.payment_method_id	 = pm.payment_method_id
      LEFT JOIN customer cu
        ON o.	customer_id	 = cu.customer_id	
      LEFT JOIN users us
        ON us.user_id = $2
      WHERE o.order_id = $1
    `;

    const { rows } = await pool.query(query, [order_id, user_id]);

    if (rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    return res.status(200).json({
      user_id,
      order_id: rows[0].order_id,
      username: rows[0].username,
      returned_person: rows[0].returned_person,
      order_status: rows[0].order_status,
      order_module: rows[0].order_module,
      payment_status: rows[0].payment_status,
      delivery_partner: rows[0].delivery_partner_name || null,
      payment_method: rows[0].payment_method_name || null,
      reason_detail: rows[0].reason_id || null,
      first_name: rows[0].first_name || null,
      timeline: {
        pending_date: rows[0].created_at,
        confirmed_date: rows[0].confirmed_date,
        processing_date: rows[0].processing_date,
        dispatched_date: rows[0].dispatched_date,
        cancelled_date: rows[0].cancelled_date,
        returned_date: rows[0].returned_date,
        delivery_completed_date: rows[0].delivery_completed_date,
      },
    });
  } catch (err) {
    console.error("Error fetching order timeline:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// GET order note by order ID
router.get("/note/:orderId", authenticateToken, async (req, res) => {
  const { orderId } = req.params;
  try {
    const result = await pool.query(
      "SELECT order_note FROM orders WHERE order_id = $1",
      [orderId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json({ note: result.rows[0].order_note || "" });
  } catch (error) {
    console.error("Error fetching note:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/deliverydeil/:orderId", authenticateToken, async (req, res) => {
  const { orderId } = req.params;

  try {
    const query = `
      SELECT 
        o.order_note,
        o.tracking_id,
        o.delivery_partner_id,
        dp.name AS partner_name,
        dp.logo AS partner_logo,
        dp.tracking_url AS tracking_url,
        dp.contact_number AS partner_contact
      FROM orders o
      LEFT JOIN delivery_partners dp 
        ON o.delivery_partner_id = dp.partner_id
      WHERE o.order_id = $1
    `;

    const result = await pool.query(query, [orderId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Order not found" });
    }

    const row = result.rows[0];

    res.json({
      order_note: row.order_note || "",
      tracking_id: row.tracking_id || "",
      delivery_partner_id: row.delivery_partner_id || "",
      partner: {
        name: row.partner_name || "",
        logo: row.partner_logo || "",
        tracking_url: row.tracking_url || "",
        contact_number: row.partner_contact || "",
      },
    });
  } catch (error) {
    console.error("Error fetching delivery details:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// PUT (or POST) to update note
router.put("/note/:orderId", authenticateToken, async (req, res) => {
  const { orderId } = req.params;
  const { note } = req.body;
  try {
    const result = await pool.query(
      "UPDATE orders SET order_note = $1, updated_at = NOW() WHERE order_id = $2 RETURNING order_note",
      [note, orderId]
    );
    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json({ success: true, note: result.rows[0].order_note });
  } catch (error) {
    console.error("Error updating note:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// set return for dispatched orders
router.post("/return-dispatched-order", authenticateToken, async (req, res) => {
  const { order_id, reason_id } = req.body;
  console.log("reason_id", reason_id);
  const client = await pool.connect();

  try {
    const user_id = req.user?.user_id ?? req.user?.id ?? req.user?.sub;
    if (!user_id)
      return res
        .status(401)
        .json({ message: "Unauthorized: user missing in token." });

    await client.query("BEGIN");

    // 🔒 Lock the order row to avoid races
    const orderLock = await client.query(
      `SELECT order_id, order_status FROM orders WHERE order_id = $1 FOR UPDATE`,
      [order_id]
    );
    if (orderLock.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found." });
    }
    if (orderLock.rows[0].order_status === "returned") {
      await client.query("ROLLBACK");
      return res
        .status(400)
        .json({ message: "Order already marked as returned." });
    }

    // 👤 User context (unchanged)
    const u = await client.query(
      `SELECT username, outlet_id, merchant_id FROM users WHERE user_id = $1`,
      [user_id]
    );
    if (u.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "User not found." });
    }
    const { username, outlet_id, merchant_id } = u.rows[0];

    // 📦 Items (UPDATED: includes measurement data)
    const itemsRes = await client.query(
      `
      SELECT
        oi.variant_id,
        oi.quantity,
        COALESCE(oi.free_quantity, 0) AS free_quantity,
        p.measurement_id,
        p.amount_per_unit
      FROM order_items oi
      JOIN products p ON p.product_id = oi.product_id
      WHERE oi.order_id = $1
      `,
      [order_id]
    );

    if (itemsRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res
        .status(400)
        .json({ message: "No items found for this order." });
    }

    // ♻️ Restore inventory (MATCHES cancel-order logic)
    for (const item of itemsRes.rows) {
      const {
        variant_id,
        quantity,
        free_quantity,
        measurement_id,
        amount_per_unit,
      } = item;

      // base units to restore
      const totalUnits =
        Math.abs(Number(quantity || 0)) + Math.abs(Number(free_quantity || 0));

      let adjust_quantity;

      // ✅ Measurement-based restore
      if (
        measurement_id !== null &&
        measurement_id !== 1 &&
        amount_per_unit !== null
      ) {
        adjust_quantity = totalUnits * Number(amount_per_unit);
      } else {
        // ✅ Old behavior fallback
        adjust_quantity = totalUnits;
      }

      if (adjust_quantity === 0) continue;

      // previous stock
      const prev = await client.query(
        `SELECT COALESCE(new_quantity, 0) AS new_quantity, batch_number
     FROM inventory
    WHERE variant_id = $1 AND outlet_id = $2
 ORDER BY inventory_id DESC
    LIMIT 1`,
        [variant_id, outlet_id]
      );

      const previous_quantity = Number(prev.rows[0]?.new_quantity || 0);
      const new_quantity = previous_quantity + adjust_quantity;
      const latest_batch_number = prev.rows[0]?.batch_number ?? null;

      // ledger insert (UNCHANGED)
      await client.query(
        `INSERT INTO inventory (
    variant_id, outlet_id, merchant_id, user_id,
    updated_by, comment, system_module,
    previous_quantity, adjust_quantity, new_quantity,
    batch_number, status
  ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')`,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          username,
          `return-order:${order_id}`,
          "stock in",
          previous_quantity,
          adjust_quantity,
          new_quantity,
          latest_batch_number, //  preserved batch
        ]
      );
    }

    //  Mark order as returned (UNCHANGED)
    const orderRes = await client.query(
      `UPDATE orders
          SET order_status    = 'returned',
              returned_person = $1,
              reason_id       = $3,
              returned_date   = NOW(),
              updated_at      = NOW()
        WHERE order_id = $2
      RETURNING *`,
      [username, order_id, reason_id]
    );

    await client.query("COMMIT");

    // 🧾 Admin log (UNCHANGED)
    insertAdminLog(
      user_id,
      "Orders",
      `Returned order ${order_id} and restored inventory`
    ).catch((e) => console.error("Admin log insert failed:", e));

    // 🔔 Notifications (UNCHANGED)
    try {
      const updatedStatus = orderRes?.rows?.[0]?.order_status;
      if (String(updatedStatus).toLowerCase() === "returned") {
        res.on("finish", () => {
          setImmediate(async () => {
            try {
              const ACTION_ID = 6; // Order Returned
              await customhook(ACTION_ID, order_id);
            } catch (err) {
              console.error("customhook error (returned):", err);
            }
          });
        });
      }
    } catch (e) {
      console.error("Post-response notifier setup failed:", e);
    }

    return res.status(200).json({
      success: true,
      message: `Order ${order_id} marked as returned and inventory restored.`,
      data: orderRes.rows[0],
    });
  } catch (err) {
    await client.query("ROLLBACK");

    if (err?.code === "23514") {
      return res
        .status(400)
        .json({ message: `Constraint error: ${err.constraint}` });
    }

    console.error("❌ Return error:", err);
    return res
      .status(500)
      .json({ message: "Server error while returning order." });
  } finally {
    client.release();
  }
});

// cancel and restore inventory on cancel in processing orders

// POST /orders-sub/cancel-order
router.post("/cancel-processing-order", authenticateToken, async (req, res) => {
  const { order_id, custom_reason } = req.body;
  const client = await pool.connect();

  try {
    const user_id = req.user?.user_id ?? req.user?.id ?? req.user?.sub;
    if (!user_id) {
      return res
        .status(401)
        .json({ message: "Unauthorized: user missing in token." });
    }

    await client.query("BEGIN");

    // Lock the order row to avoid concurrent updates
    const lockRes = await client.query(
      `SELECT order_id, order_status
         FROM orders
        WHERE order_id = $1
        FOR UPDATE`,
      [order_id]
    );
    if (lockRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found." });
    }

    const currStatus = lockRes.rows[0].order_status;
    if (["cancelled", "returned", "completed"].includes(currStatus)) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: `Order already ${currStatus}.` });
    }

    // User context
    const u = await client.query(
      `SELECT username, outlet_id, merchant_id
         FROM users
        WHERE user_id = $1`,
      [user_id]
    );
    if (u.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "User not found." });
    }
    const { username, outlet_id, merchant_id } = u.rows[0];

    // 🔥 Fetch order items WITH measurement data
    const itemsRes = await client.query(
      `
      SELECT
        oi.variant_id,
        oi.quantity,
        COALESCE(oi.free_quantity, 0) AS free_quantity,
        p.measurement_id,
        p.amount_per_unit
      FROM order_items oi
      JOIN products p ON p.product_id = oi.product_id
      WHERE oi.order_id = $1
      `,
      [order_id]
    );

    if (itemsRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res
        .status(400)
        .json({ message: "No items found for this order." });
    }

    const SYSTEM_MODULE_CANCEL = "stock in";

    // ✅ Restore inventory
    for (const item of itemsRes.rows) {
      const {
        variant_id,
        quantity,
        free_quantity,
        measurement_id,
        amount_per_unit,
      } = item;

      // Base units
      const totalUnits =
        Math.abs(Number(quantity || 0)) + Math.abs(Number(free_quantity || 0));

      if (totalUnits === 0) continue;

      let adjust_quantity;

      // ✅ Measurement-aware restore
      if (
        measurement_id !== null &&
        measurement_id !== 1 &&
        amount_per_unit !== null
      ) {
        adjust_quantity = totalUnits * Number(amount_per_unit);
      } else {
        // ✅ Old behavior fallback
        adjust_quantity = totalUnits;
      }

      // Previous stock
      const prevRes = await client.query(
        `SELECT COALESCE(new_quantity, 0) AS new_quantity, batch_number
     FROM inventory
    WHERE variant_id = $1 AND outlet_id = $2
 ORDER BY inventory_id DESC
    LIMIT 1`,
        [variant_id, outlet_id]
      );

      const previous_quantity = Number(prevRes.rows[0]?.new_quantity || 0);
      const new_quantity = previous_quantity + adjust_quantity;
      const latest_batch_number = prevRes.rows[0]?.batch_number ?? null;

      // Insert ledger entry
      await client.query(
        `INSERT INTO inventory (
    variant_id, outlet_id, merchant_id, user_id,
    updated_by, comment, system_module,
    previous_quantity, adjust_quantity, new_quantity,
    batch_number, status
  ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')`,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          username,
          `cancel-order:${order_id}`,
          SYSTEM_MODULE_CANCEL,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          latest_batch_number, // ✅ preserved batch
        ]
      );
    }

    // Mark order as cancelled
    const orderRes = await client.query(
      `UPDATE orders
          SET order_status   = 'cancelled',
              cancelled_by   = $1,
              cancelled_date = NOW(),
              updated_at     = NOW(),
              reason_id      = $3
        WHERE order_id = $2
      RETURNING *`,
      [username, order_id, custom_reason]
    );

    await client.query("COMMIT");

    // Admin log
    try {
      await insertAdminLog(
        user_id,
        "Orders",
        `Cancelled order ${order_id} and restored inventory`
      );
    } catch (e) {
      console.error("Admin log insert failed:", e);
    }

    // Fire-and-forget notification
    try {
      const ACTION_ID = 6;
      res.on("finish", () => {
        setImmediate(async () => {
          try {
            const ressms = await customhook(ACTION_ID, order_id);
            console.log("📨 customhook results:", ressms);
          } catch (err) {
            console.error("customhook error:", err);
          }
        });
      });
    } catch (e) {
      console.error("Post-response notifier setup failed:", e);
    }

    return res.status(200).json({
      success: true,
      message: `Order ${order_id} cancelled and inventory restored.`,
      data: orderRes.rows[0],
    });
  } catch (err) {
    await client.query("ROLLBACK");
    if (err?.code === "23514") {
      return res
        .status(400)
        .json({ message: `Constraint error: ${err.constraint}` });
    }
    console.error("❌ Cancel error:", err);
    return res
      .status(500)
      .json({ message: "Server error while cancelling order." });
  } finally {
    client.release();
  }
});

router.get("/reasons", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        reason_id,
        reason_type,
        reason_detail,
        created_at
      FROM reasons
      WHERE reason_type = 'return'
      ORDER BY reason_id ASC
    `);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (err) {
    console.error("Error fetching reasons:", err.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch reasons",
    });
  }
});

router.get("/cancellreasons", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        reason_id,
        reason_type,
        reason_detail,
        created_at
      FROM reasons
      WHERE reason_type = 'cancel'
      ORDER BY reason_id ASC
    `);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (err) {
    console.error("Error fetching reasons:", err.message);
    res.status(500).json({
      success: false,
      message: "Failed to fetch reasons",
    });
  }
});

router.post("/stock-sheet-history", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      sheet_id,
      stock_type,
      date,
      todate,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    // Build dynamic WHERE clauses
    let whereClauses = [];
    let queryParams = [];

    if (sheet_id) {
      queryParams.push(sheet_id);
      whereClauses.push(`s.sheet_id = $${queryParams.length}`);
    }

    if (stock_type) {
      queryParams.push(stock_type);
      whereClauses.push(`s.stock_type = $${queryParams.length}`);
    }

    if (date && todate) {
      queryParams.push(date, todate);
      whereClauses.push(
        `s.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    const whereSQL =
      whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

    // Data query with filters
    const dataQuery = `
      SELECT
        s.sheet_id,
        s.created_at,
        s.stock_type,
        u.username AS created_by,
        s.remark,
        s.user_id,
        s.outlet_id,
        o.name AS outlet_name
      FROM stock_sheet_header s
      LEFT JOIN users u ON s.user_id = u.user_id
      LEFT JOIN outlets o ON s.outlet_id = o.outlet_id
      ${whereSQL}
      ORDER BY s.sheet_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    // Count query with same filters
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM stock_sheet_header s
      LEFT JOIN outlets o ON s.outlet_id = o.outlet_id
      ${whereSQL};
    `;

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataQuery, [...queryParams, parsedLimit, offset]),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      success: true,
      data: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Stock sheet error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

router.post("/stock-sheet-details", authenticateToken, async (req, res) => {
  try {
    const { sheet_id } = req.body;

    if (!sheet_id) {
      return res
        .status(400)
        .json({ success: false, message: "Sheet ID is required" });
    }




    const query = `
      SELECT
        ssd.sheet_details_id,
        ssd.sheet_id,
        ssd.product_id,
        p.title AS product_title,

        ssd.variant_id,
        pv.variant_value,
        pv.variant_type,

        ssd.current_stock,
        ssd.previous_stock,
        ssd.changed_qty,
        ssd.sku,
        ssd.batch_number,
        ssd.barcode,
        ssd.created_at

      FROM stock_sheet_details ssd

      LEFT JOIN products p
        ON p.product_id = ssd.product_id

      LEFT JOIN product_variants pv
        ON pv.variant_id = ssd.variant_id

      WHERE ssd.sheet_id = $1
      ORDER BY ssd.created_at ASC;
    `;

    const result = await pool.query(query, [sheet_id]);

    res.json({
      success: true,
      data: result.rows,
    });
  } catch (error) {
    console.error("Stock sheet details error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


// router.post("/stock-sheet-remark", authenticateToken, async (req, res) => {
//   try {
//     const { sheet_id, remark } = req.body;


module.exports = router;
