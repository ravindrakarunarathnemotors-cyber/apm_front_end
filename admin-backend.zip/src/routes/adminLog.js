const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const bcrypt = require("bcrypt");
const router = express.Router();


const{ sendemailtemp } = require("../models/resetPassword")

router.post("/getalllogs", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      id,
      logname,
      description,
      log_at,
      
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

       let queryParams = [];
    let whereConditions = [];

     if (id) {
      queryParams.push(id);
      whereConditions.push(`id = $${queryParams.length}`);
    }
      if (description) {
     queryParams.push(`%${description}%`);
     whereConditions.push(`log ILIKE $${queryParams.length}`);
    }

    if (logname) {
      queryParams.push(`%${logname}%`);
      whereConditions.push(`module ILIKE $${queryParams.length}`);
    }
    if (log_at) {
      queryParams.push(log_at);
      whereConditions.push(`date::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(" AND ")}` : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM admin_log
      ${whereClause}
      ORDER BY date DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM admin_log
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});
router.get("/adminall", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT module,id FROM admin_log WHERE module ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


// router.post("/getuser", authenticateToken, async (req, res) => {
//   try {
//     const { user_id } = req.body;

//     if (!user_id) {
//       return res.status(400).json({ error: "user_id is required" });
//     }

//     const query = `
//       SELECT user_id, first_name, last_name, username, mobile, status, email, picture
//       FROM users
//       WHERE user_id = $1
//     `;

//     const result = await pool.query(query, [user_id]);

//     if (result.rows.length === 0) {
//       return res.status(404).json({ error: "User not found" });
//     }

//     res.json({ user: result.rows[0] });
//   } catch (error) {
//     console.error("Error fetching user:", error);
//     res.status(500).json({ error: "Internal server error" });
//   }
// });


router.post("/getuser", authenticateToken, async (req, res) => {
  try {
    const { user_id } = req.body;

    if (!user_id) {
      return res.status(400).json({ error: "user_id is required" });
    }

    const query = `
      SELECT 
        u.user_id, 
        u.first_name, 
        u.last_name, 
        u.username, 
        u.mobile, 
        u.status, 
        u.email, 
        u.picture,
        r.role_name,
        o.name AS outlet_name
      FROM users u
      JOIN role_list r ON u.role_id = r.id
      LEFT JOIN outlets o ON u.outlet_id = o.outlet_id
      WHERE u.user_id = $1
    `;

    const result = await pool.query(query, [user_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});




router.post("/updateuser", authenticateToken, async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      mobile,
      picture,   
      password   
    } = req.body || {};

    const user = req.user
  const user_id = user.user_id

   
    
    
    if (!user_id) {
      return res.status(400).json({ error: "user_id is required" });
    }
    

    const sets = [
      `first_name = $1`,
      `last_name = $2`,
      `email = $3`,
      `mobile = $4`,
      `picture = $5`,
      `updated_at = NOW()`
    ];
    const values = [
      String(first_name).trim(),
      String(last_name).trim(),
      String(email).trim(),
      (mobile ?? "").toString().trim(),
      picture ?? null
    ];

    if (password && String(password).trim().length > 0) {
      const hash = await bcrypt.hash(String(password).trim(), 10);
      sets.push(`password = $${values.length + 1}`); 
      values.push(hash);
    }

    values.push(user_id); 

    const query = `
      UPDATE users
         SET ${sets.join(", ")}
       WHERE user_id = $${values.length}
       RETURNING user_id, first_name, last_name, username, mobile, status, email, picture
    `;

    const result = await pool.query(query, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


// router.post("/send-reset-otp", async (req, res) => {
//   try {
//     const { identifier } = req.body || {};

//     if (!identifier || String(identifier).trim().length === 0) {
//       return res.status(400).json({ error: "Email or username is required" });
//     }

//     const id = String(identifier).trim();
//     const isEmail = id.includes("@");

//     let query, values;

//     if (isEmail) {
//       query = `
//         SELECT user_id, username, email
//         FROM users
//         WHERE email = $1
//         LIMIT 1
//       `;
//       values = [id];
//     } else {
//       query = `
//         SELECT user_id, username, email
//         FROM users
//         WHERE username = $1
//         LIMIT 1
//       `;
//       values = [id];
//     }

//     const result = await pool.query(query, values);

//     if (result.rows.length === 0) {
//       return res.status(404).json({
//         error: isEmail ? "Email does not exist" : "Username does not exist"
//       });
//     }

//     const user = result.rows[0];

//     return res.json({
//       success: true,
//       message: "User found",
//     });

//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: "Internal server error" });
//   }
// });


router.post("/send-reset-otp", async (req, res) => {
  try {
    const { identifier } = req.body || {};

    if (!identifier || String(identifier).trim().length === 0) {
      return res.status(400).json({ error: "Email or username is required" });
    }

    const id = String(identifier).trim();
    const isEmail = id.includes("@");

    let query, values;

    if (isEmail) {
      query = `
        SELECT user_id, username, email
        FROM users
        WHERE email = $1
        LIMIT 1
      `;
      values = [id];
    } else {
      query = `
        SELECT user_id, username, email
        FROM users
        WHERE username = $1
        LIMIT 1
      `;
      values = [id];
    }

    const result = await pool.query(query, values);

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: isEmail ? "Email does not exist" : "Username does not exist"
      });
    }

    const user = result.rows[0];

    // ------------------------------------
    //           ADD OTP LOGIC
    // ------------------------------------

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 mins

    await pool.query(
      `
      UPDATE users
      SET otp = $1,
          otp_expires_at = $2
      WHERE user_id = $3
      `,
      [otp, expiresAt, user.user_id]
    );

    const subject = 'Password Reset OTP';

await sendemailtemp( user.user_id, otp, subject);

    return res.json({
      success: true,
      message: "User found",
      user_id: user.user_id,
      email:user.email,

     
    });

  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post('/otp-verify', async (req, res) => {
  try {
    const { otp, user_id } = req.body;

    console.log("otp:", otp);
    console.log("user_id:", user_id);

    if (!otp || !user_id) {
      return res.status(400).json({
        success: false,
        message: "OTP and user_id are required"
      });
    }

    // PostgreSQL query (CORRECT)
    const result = await pool.query(
      'SELECT otp FROM users WHERE user_id = $1',
      [user_id]
    );

    // In PostgreSQL, use rowCount & rows
    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "User not found"
      });
    }

    const storedOtp = result.rows[0].otp;

    if (otp === storedOtp) {

      // Clear OTP after successful verification (PostgreSQL syntax)
      await pool.query(
        'UPDATE users SET otp = NULL WHERE user_id = $1',
        [user_id]
      );

      return res.json({
        success: true,
        message: "OTP verified successfully"
      });

    } else {
      return res.status(400).json({
        success: false,
        message: "Incorrect OTP"
      });
    }

  } catch (err) {
    console.error('OTP verify error:', err);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});


router.post('/password-reset', async (req, res) => {
  try {
    const { user_id, new_password } = req.body;

    console.log("user_id",user_id)
    console.log("new_password",new_password)

    if (!user_id || !new_password) {
      return res.status(400).json({
        success: false,
        message: "user_id and new_password are required"
      });
    }

    // hash new password
    const hashedPassword = await bcrypt.hash(new_password.trim(), 10);

    // update password + clear otp
    const update = await pool.query(
      `
      UPDATE users
      SET password = $1,
          otp = NULL,
          otp_expires_at = NULL,
          updated_at = NOW()
      WHERE user_id = $2
      RETURNING user_id, email
      `,
      [hashedPassword, user_id]
    );

    return res.json({
      success: true,
      message: "Password reset successful",
      user: update.rows[0]
    });

  } catch (err) {
    console.error("Password reset error:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
});

//add admin log
router.post('/createlog', async (req, res) => {
  try {
    const { module, description, user_id, log_at } = req.body

    await pool.query(
     `INSERT INTO admin_log (module, log, user_id, date) 
       VALUES ($1, $2, $3, $4)`,
      [module, description, user_id || 1, log_at || new Date()]
    )

    res.status(201).json({ message: 'EMS Log created successfully' })
  } catch (err) {
    console.error('Create log error:', err)
    res.status(500).json({ message: 'Failed to create EMS log' })
  }
})





module.exports = router;