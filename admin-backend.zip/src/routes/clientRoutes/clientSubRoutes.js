const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const axios = require('axios');

// GET /product-reviews?page=1&product_id=123&status=active
router.get('/all-product-reviews', authenticateToken, async (req, res) => {
  try {
    const pageSize = 25;
    const pageRaw = Number(req.query.page ?? 1);
    const page = Number.isInteger(pageRaw) && pageRaw > 0 ? pageRaw : 1;

    const { product_id, status } = req.query;

    const where = [];
    const params = [];

    if (product_id !== undefined) {
      const pid = Number(product_id);
      if (!Number.isInteger(pid)) return res.status(400).json({ error: 'Invalid product_id' });
      params.push(pid);
      where.push(`product_id = $${params.length}`);
    }

    if (status !== undefined) {
      params.push(String(status));
      where.push(`status = $${params.length}`);
    }

    const whereSQL = where.length ? `WHERE ${where.join(' AND ')}` : '';

    // Count total
    const countSQL = `SELECT COUNT(*)::int AS count FROM product_reviews ${whereSQL};`;
    const { rows: countRows } = await pool.query(countSQL, params);
    const total = countRows[0]?.count ?? 0;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    const safePage = Math.min(Math.max(page, 1), totalPages);
    const offset = (safePage - 1) * pageSize;

    // Most recent on top: prefer updated_at, fallback to created_at
    const dataSQL = `
      SELECT *
      FROM product_reviews
      ${whereSQL}
      ORDER BY COALESCE(updated_at, created_at) DESC, review_id DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2};
    `;
    const dataParams = [...params, pageSize, offset];
    const { rows } = await pool.query(dataSQL, dataParams);

    return res.json({
      page: safePage,
      pageSize,
      total,
      totalPages,
      reviews: rows,
    });
  } catch (err) {
    console.error('Error fetching product reviews:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// reviews search


// GET /product-reviews/search?q=...&page=1&status=active
router.get('/search', authenticateToken, async (req, res) => {
  try {
    const pageSize = 25;
    const q = (req.query.q ?? '').trim();
    const pageRaw = Number(req.query.page ?? 1);
    const page = Number.isInteger(pageRaw) && pageRaw > 0 ? pageRaw : 1;
    const status = req.query.status; // optional (e.g., "active")

    if (!q) {
      return res.status(400).json({ error: 'Missing q (search query)' });
    }

    const where = [];
    const params = [];
    const isNumeric = /^\d+$/.test(q);

    // IDs must match exactly; name is partial (case-insensitive)
    if (isNumeric) {
      params.push(Number(q));
      where.push(`(review_id = $${params.length} OR product_id = $${params.length})`);
    } else {
      params.push(`%${q}%`);
      where.push(`customer_name ILIKE $${params.length}`);
    }

    if (status) {
      params.push(String(status));
      where.push(`status = $${params.length}`);
    }

    const whereSQL = `WHERE ${where.join(' AND ')}`;

    // Count total
    const countSQL = `SELECT COUNT(*)::int AS count FROM product_reviews ${whereSQL};`;
    const { rows: countRows } = await pool.query(countSQL, params);
    const total = countRows[0]?.count ?? 0;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));

    const safePage = Math.min(Math.max(page, 1), totalPages);
    const offset = (safePage - 1) * pageSize;

    // Most recent first (prefer updated_at, fallback created_at)
    const dataSQL = `
      SELECT *
      FROM product_reviews
      ${whereSQL}
      ORDER BY COALESCE(updated_at, created_at) DESC, review_id DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2};
    `;
    const dataParams = [...params, pageSize, offset];
    const { rows } = await pool.query(dataSQL, dataParams);

    return res.json({
      query: q,
      page: safePage,
      pageSize,
      total,
      totalPages,
      reviews: rows,
    });
  } catch (err) {
    console.error('Error searching product reviews:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});






module.exports = router;