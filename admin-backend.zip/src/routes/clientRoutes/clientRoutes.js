const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const axios = require('axios');

require('dotenv').config();



router.get("/customername", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `
      SELECT DISTINCT 
        TRIM(first_name || ' ' || last_name) || ' - ' || contact_number_1 AS first_name
      FROM customer
      WHERE first_name ILIKE $1 
         OR last_name ILIKE $1
         OR contact_number_1 ILIKE $1
      LIMIT 10
    `;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching customer names:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.get("/customer-points/:customer_id", authenticateToken, async (req, res) => {
  try {

    const { customer_id } = req.params;

    const query = `
      SELECT
        id,
        prev_amount,
        adjust_amount,
        new_amount,
        date
      FROM points_logs
      WHERE customer_id = $1
      ORDER BY id DESC
    `;

    const result = await pool.query(query, [customer_id]);

    res.json(result.rows);

  } catch (error) {

    console.error("Error fetching loyalty points logs:", error);

    res.status(500).json({
      message: "Internal Server Error",
    });

  }
});


router.post("/activeclients", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      payment_status,
      paymentMethod,
      date
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];


    whereConditions.push(`c.status = 'active'`);


    if (keyword) {
      const trimmedKeyword = keyword.trim();

      // Detect format: "Name - Phone"
      if (trimmedKeyword.includes("-")) {
        const [namePart, phonePart] = trimmedKeyword.split("-").map(s => s.trim());

        // Search by phone if exists
        if (phonePart && /^\d+$/.test(phonePart)) {
          queryParams.push(phonePart);
          whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
        }

        // Search by name if exists
        if (namePart) {
          const words = namePart.split(" ").filter(w => w);

          if (words.length >= 2) {
            queryParams.push(`%${words[0]}%`);
            const idx1 = queryParams.length;

            queryParams.push(`%${words[1]}%`);
            const idx2 = queryParams.length;

            whereConditions.push(`(
          c.first_name ILIKE $${idx1}
          AND c.last_name ILIKE $${idx2}
        )`);
          } else {
            queryParams.push(`%${namePart}%`);
            const idx = queryParams.length;

            whereConditions.push(`(
          c.first_name ILIKE $${idx}
          OR c.last_name ILIKE $${idx}
        )`);
          }
        }
      }

      // ✅ OLD LOGIC (fallback if no "-")
      else if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      }

      else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.customer_id = $${queryParams.length}`);
      }

      else if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.email ILIKE $${queryParams.length}`);
      }

      else {
        const words = trimmedKeyword.split(" ").filter(w => w);

        if (words.length === 2) {
          queryParams.push(`%${words[0]}%`);
          const idx1 = queryParams.length;

          queryParams.push(`%${words[1]}%`);
          const idx2 = queryParams.length;

          whereConditions.push(`(
        c.first_name ILIKE $${idx1}
        AND c.last_name ILIKE $${idx2}
      )`);
        } else {
          queryParams.push(`%${trimmedKeyword}%`);
          const idx = queryParams.length;

          whereConditions.push(`(
        c.first_name ILIKE $${idx}
        OR c.last_name ILIKE $${idx}
      )`);
        }
      }
    }



    if (date) {
      queryParams.push(date);
      whereConditions.push(`c.created_at::date = $${queryParams.length}`);
    }


    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`c.status = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;


    const ordersQuery = `
      SELECT 
        c.customer_id,
        c.first_name,
        c.last_name,
        c.contact_number_1,
        c.contact_number_2,
        c.company_name,
        c.city,
        c.picture,
        c.postal_code,
        c.country,
        c.address,
        c.email,
        c.created_at,
        c.status,
        c.loyalty_point,
        COUNT(o.order_id) AS order_count,
        COUNT(o.order_id) FILTER (WHERE o.order_status = 'returned') AS returned_count,
        COUNT(o.order_id) FILTER (WHERE o.order_status = 'completed') AS completed_count,
        COUNT(o.order_id) FILTER (WHERE o.order_status = 'pending') AS pending_count,
        COUNT(o.order_id) FILTER (WHERE o.order_status = 'cancelled') AS cancelled_count,
        COALESCE(SUM(o.total_value) FILTER (WHERE o.payment_status = 'paid'), 0) AS paid_total,
        COALESCE(SUM(o.total_value) FILTER (WHERE o.payment_status = 'unpaid'), 0) AS unpaid_total,
        ss.currency AS currency
      FROM customer c 
      LEFT JOIN orders o ON o.customer_id = c.customer_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      GROUP BY 
        c.customer_id,
        c.first_name,
        c.contact_number_1,
        c.contact_number_2,
        c.company_name,
        c.city,
        c.picture,
        c.postal_code,
        c.country,
        c.address,
        c.email,
        c.created_at,
        c.status,
        c.loyalty_point,
        ss.currency
      ORDER BY c.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);


    const countQuery = `
      SELECT COUNT(*) AS total
      FROM customer c
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);


    const customerIds = rows.map(c => c.customer_id);
    let ordersByCustomerId = {};

    if (customerIds.length > 0) {
      const placeholders = customerIds.map((_, i) => `$${i + 1}`).join(', ');
      const ordersDetailsQuery = `
        SELECT 
          order_id, 
          customer_id, 
          created_at, 
          payment_status, 
          total_value,
          recipient_name,
          recipient_address,
          order_status 
        FROM orders 
        WHERE customer_id IN (${placeholders})
        ORDER BY created_at DESC
      `;
      const ordersResult = await pool.query(ordersDetailsQuery, customerIds);


      const orderIds = ordersResult.rows.map(o => o.order_id);
      let productTitlesByOrderId = {};

      if (orderIds.length > 0) {
        const orderIdPlaceholders = orderIds.map((_, i) => `$${i + 1}`).join(', ');
        const orderItemsQuery = `
          SELECT 
            oi.order_id, 
            p.title AS product_title
          FROM order_items oi
          JOIN products p ON p.product_id = oi.product_id
          WHERE oi.order_id IN (${orderIdPlaceholders})
        `;
        const orderItemsResult = await pool.query(orderItemsQuery, orderIds);

        orderItemsResult.rows.forEach(row => {
          if (!productTitlesByOrderId[row.order_id]) {
            productTitlesByOrderId[row.order_id] = [];
          }
          productTitlesByOrderId[row.order_id].push(row.product_title);
        });
      }


      ordersResult.rows.forEach(order => {
        const products = productTitlesByOrderId[order.order_id] || [];
        const orderWithProducts = {
          ...order,
          product_titles: products
        };

        if (!ordersByCustomerId[order.customer_id]) {
          ordersByCustomerId[order.customer_id] = [];
        }
        ordersByCustomerId[order.customer_id].push(orderWithProducts);
      });
    }

    let invoicesByCustomerId = {};
    if (customerIds.length > 0) {
      const placeholders = customerIds.map((_, i) => `$${i + 1}`).join(',');
      // const invoicesQuery = `
      //   SELECT 
      //     id AS invoice_id,
      //     customer_id,
      //     created_at,
      //     payment_status,
      //     total_value,
      //     amount_paid,
      //     order_status
      //   FROM invoice_header
      //   WHERE customer_id IN (${placeholders})
      //   ORDER BY created_at DESC
      // `;

      const invoicesQuery = `
    SELECT 
      i.id,
      i.customer_id,
      c.first_name AS customer_name,
      i.created_at,
      i.payment_status,
      i.total_value,
      i.amount_paid,
      i.order_status,
        i.payment_method_id,
        i.total_item,
        i.total_weight,
        i.currency,
        i.sender_name,
        i.sender_phone,
        i.sender_email,
        i.sender_address,
        i.sender_city,
        i.sender_postal_code,
        i.sender_country,
        i.sender_addrees_2,
        i.recipient_contact_two,
        i.delivery_fee,
        i.discount,
        i.created_at,
        i.tax_percentage,
        i.tax,
        i.full_amount,
        i.loyalty_points_earned,
        i.loyalty_points_spent,
        i.discount_type,
        i.interface,
        i.balance,
        i.add_to_points,
        i.interface,
        COALESCE(i.payments, '[]'::jsonb) AS payments,
        i.user_id
    FROM invoice_header i
    LEFT JOIN customer c ON i.customer_id = c.customer_id
    WHERE i.customer_id IN (${placeholders})
    ORDER BY i.id DESC
  `
      const invoicesResult = await pool.query(invoicesQuery, customerIds);

      invoicesResult.rows.forEach(invoice => {
        if (!invoicesByCustomerId[invoice.customer_id]) {
          invoicesByCustomerId[invoice.customer_id] = [];
        }
        invoicesByCustomerId[invoice.customer_id].push(invoice);
      });
    }


    const enrichedCustomers = rows.map(customer => ({
      ...customer,
      orders: ordersByCustomerId[customer.customer_id] || [],
      invoices: invoicesByCustomerId[customer.customer_id] || []
    }));

    res.json({
      pendingorders: enrichedCustomers,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.put('/client_update', async (req, res) => {
  const {
    customer_id,
    first_name,
    last_name,
    avatar,
    email,
    contact_number_1,
    contact_number_2,
    company_name,
    city,
    postal_code,
    country,
    address,
    picture,

  } = req.body

  // console.log("company_name",company_name);
  // console.log('phone number',contact_number_2);

  if (!customer_id) {
    return res.status(400).json({ success: false, message: 'customer_id is required' })
  }
  // console.log("avatar",avatar);

  try {
    const updateQuery = `
      UPDATE customer
      SET
        first_name = $1,
        last_name = $2,
        email = $3,
        contact_number_1 = $4,
        city = $5,
        address = $6,
        postal_code = $8,
        country = $9,
        picture= $10,
        contact_number_2 = $11,
        company_name = $12
      WHERE customer_id = $7
      RETURNING *
    `

    const values = [first_name, last_name, email, contact_number_1, city, address, customer_id, postal_code, country, avatar, contact_number_2, company_name]
    const result = await pool.query(updateQuery, values)

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Customer not found' })
    }

    res.json({ success: true, data: result.rows[0] })
  } catch (err) {
    console.error('Error updating customer:', err)
    res.status(500).json({ success: false, message: 'Server error' })
  }
})


router.put('/client_status', async (req, res) => {
  const { customer_id, status } = req.body
  console.log("customer_id", customer_id)
  console.log("status", status)

  if (!customer_id || !status) {
    return res.status(400).json({ success: false, message: 'customer_id and status are required' })
  }

  try {
    const updateQuery = `
      UPDATE customer
      SET status = $1
      WHERE customer_id = $2
      RETURNING *
    `

    const values = [status, customer_id]
    const result = await pool.query(updateQuery, values)

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Customer not found' })
    }

    res.json({ success: true, data: result.rows[0] })
  } catch (err) {
    console.error('Error updating status:', err)
    res.status(500).json({ success: false, message: 'Server error' })
  }
})
router.post("/inactiveclients", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      payment_status,
      paymentMethod,
      date
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];


    whereConditions.push(`c.status = 'inactive'`);


      if (keyword) {
      const trimmedKeyword = keyword.trim();

      // Detect format: "Name - Phone"
      if (trimmedKeyword.includes("-")) {
        const [namePart, phonePart] = trimmedKeyword.split("-").map(s => s.trim());

        // Search by phone if exists
        if (phonePart && /^\d+$/.test(phonePart)) {
          queryParams.push(phonePart);
          whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
        }

        // Search by name if exists
        if (namePart) {
          const words = namePart.split(" ").filter(w => w);

          if (words.length >= 2) {
            queryParams.push(`%${words[0]}%`);
            const idx1 = queryParams.length;

            queryParams.push(`%${words[1]}%`);
            const idx2 = queryParams.length;

            whereConditions.push(`(
          c.first_name ILIKE $${idx1}
          AND c.last_name ILIKE $${idx2}
        )`);
          } else {
            queryParams.push(`%${namePart}%`);
            const idx = queryParams.length;

            whereConditions.push(`(
          c.first_name ILIKE $${idx}
          OR c.last_name ILIKE $${idx}
        )`);
          }
        }
      }

      // ✅ OLD LOGIC (fallback if no "-")
      else if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      }

      else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.customer_id = $${queryParams.length}`);
      }

      else if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.email ILIKE $${queryParams.length}`);
      }

      else {
        const words = trimmedKeyword.split(" ").filter(w => w);

        if (words.length === 2) {
          queryParams.push(`%${words[0]}%`);
          const idx1 = queryParams.length;

          queryParams.push(`%${words[1]}%`);
          const idx2 = queryParams.length;

          whereConditions.push(`(
        c.first_name ILIKE $${idx1}
        AND c.last_name ILIKE $${idx2}
      )`);
        } else {
          queryParams.push(`%${trimmedKeyword}%`);
          const idx = queryParams.length;

          whereConditions.push(`(
        c.first_name ILIKE $${idx}
        OR c.last_name ILIKE $${idx}
      )`);
        }
      }
    }


    if (date) {
      queryParams.push(date);
      whereConditions.push(`c.created_at::date = $${queryParams.length}`);
    }


    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`c.status = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;


    const ordersQuery = `
      SELECT 
        c.customer_id,
        c.first_name,
        c.last_name,
        c.contact_number_1,
        c.contact_number_2,
        c.company_name,
        c.city,
        c.picture,
        c.postal_code,
        c.country,
        c.address,
        c.email,
        c.created_at,
        c.status,
        c.loyalty_point,
        COUNT(o.order_id) AS order_count,
        COUNT(o.order_id) FILTER (WHERE o.order_status = 'returned') AS returned_count,
        COALESCE(SUM(o.total_value) FILTER (WHERE o.payment_status = 'paid'), 0) AS paid_total,
        COALESCE(SUM(o.total_value) FILTER (WHERE o.payment_status = 'unpaid'), 0) AS unpaid_total
      FROM customer c 
      LEFT JOIN orders o ON o.customer_id = c.customer_id
      ${whereClause}
      GROUP BY 
        c.customer_id,
        c.first_name,
        c.contact_number_1,
        c.contact_number_2,
        c.company_name,
        c.city,
        c.picture,
        c.postal_code,
        c.country,
        c.address,
        c.email,
        c.created_at,
        c.status,
        c.loyalty_point
      ORDER BY c.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);


    const countQuery = `
      SELECT COUNT(*) AS total
      FROM customer c
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);


    const customerIds = rows.map(c => c.customer_id);
    let ordersByCustomerId = {};

    if (customerIds.length > 0) {
      const placeholders = customerIds.map((_, i) => `$${i + 1}`).join(', ');
      const ordersDetailsQuery = `
        SELECT 
          order_id, 
          customer_id, 
          created_at, 
          payment_status, 
          total_value,
          recipient_name,
          recipient_address,
          order_status 
        FROM orders 
        WHERE customer_id IN (${placeholders})
        ORDER BY created_at DESC
      `;
      const ordersResult = await pool.query(ordersDetailsQuery, customerIds);


      const orderIds = ordersResult.rows.map(o => o.order_id);
      let productTitlesByOrderId = {};

      if (orderIds.length > 0) {
        const orderIdPlaceholders = orderIds.map((_, i) => `$${i + 1}`).join(', ');
        const orderItemsQuery = `
          SELECT 
            oi.order_id, 
            p.title AS product_title
          FROM order_items oi
          JOIN products p ON p.product_id = oi.product_id
          WHERE oi.order_id IN (${orderIdPlaceholders})
        `;
        const orderItemsResult = await pool.query(orderItemsQuery, orderIds);

        orderItemsResult.rows.forEach(row => {
          if (!productTitlesByOrderId[row.order_id]) {
            productTitlesByOrderId[row.order_id] = [];
          }
          productTitlesByOrderId[row.order_id].push(row.product_title);
        });
      }


      ordersResult.rows.forEach(order => {
        const products = productTitlesByOrderId[order.order_id] || [];
        const orderWithProducts = {
          ...order,
          product_titles: products
        };

        if (!ordersByCustomerId[order.customer_id]) {
          ordersByCustomerId[order.customer_id] = [];
        }
        ordersByCustomerId[order.customer_id].push(orderWithProducts);
      });
    }

    let invoicesByCustomerId = {};
    if (customerIds.length > 0) {
      const placeholders = customerIds.map((_, i) => `$${i + 1}`).join(',');
      // const invoicesQuery = `
      //   SELECT 
      //     id AS invoice_id,
      //     customer_id,
      //     created_at,
      //     payment_status,
      //     total_value,
      //     amount_paid,
      //     order_status
      //   FROM invoice_header
      //   WHERE customer_id IN (${placeholders})
      //   ORDER BY created_at DESC
      // `;

      const invoicesQuery = `
    SELECT 
      i.id,
      i.customer_id,
      c.first_name AS customer_name,
      i.created_at,
      i.payment_status,
      i.total_value,
      i.amount_paid,
      i.order_status,
        i.payment_method_id,
        i.total_item,
        i.total_weight,
        i.currency,
        i.sender_name,
        i.sender_phone,
        i.sender_email,
        i.sender_address,
        i.sender_city,
        i.sender_postal_code,
        i.sender_country,
        i.sender_addrees_2,
        i.recipient_contact_two,
        i.delivery_fee,
        i.discount,
        i.created_at,
        i.tax_percentage,
        i.tax,
        i.full_amount,
        i.loyalty_points_earned,
        i.loyalty_points_spent,
        i.discount_type,
        i.interface,
        i.balance,
        i.add_to_points,
        i.interface,
        COALESCE(i.payments, '[]'::jsonb) AS payments,
        i.user_id
    FROM invoice_header i
    LEFT JOIN customer c ON i.customer_id = c.customer_id
    WHERE i.customer_id IN (${placeholders})
    ORDER BY i.id DESC
  `
      const invoicesResult = await pool.query(invoicesQuery, customerIds);

      invoicesResult.rows.forEach(invoice => {
        if (!invoicesByCustomerId[invoice.customer_id]) {
          invoicesByCustomerId[invoice.customer_id] = [];
        }
        invoicesByCustomerId[invoice.customer_id].push(invoice);
      });
    }


    const enrichedCustomers = rows.map(customer => ({
      ...customer,
      orders: ordersByCustomerId[customer.customer_id] || [],
      invoices: invoicesByCustomerId[customer.customer_id] || []
    }));

    res.json({
      pendingorders: enrichedCustomers,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;