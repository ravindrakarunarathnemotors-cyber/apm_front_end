const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");

// GET /api/reorder-levels/search?query=...
router.get("/search", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;

  const {
    query,
    fromDate,
    toDate,
    page = 1,
    limit = 25,
    reorderlevel, // 'reached' | 'near to reach' (unchanged)
  } = req.query;

  const queryParams = [merchant_id]; // $1
  let searchCondition = "";

  // Search: by product_id, product title, variant_id, variant_value
  if (query && query.trim() !== "") {
    queryParams.push(query.trim());
    const qIdx = queryParams.length;
    searchCondition = `
      AND (
        CAST(p.product_id AS TEXT) = $${qIdx}
        OR LOWER(p.title) LIKE LOWER('%' || $${qIdx} || '%')
        OR CAST(pv.variant_id AS TEXT) = $${qIdx}
        OR LOWER(pv.variant_value) LIKE LOWER('%' || $${qIdx} || '%')
      )
    `;
  }

  try {
    const parsedPage = parseInt(page, 10);
    const parsedLimit = parseInt(limit, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    // Base FROM/JOINs:
    // - products + product_variants
    // - LATERAL subquery to get the latest inventory row per variant (for this merchant) → current_stock, last_updated, outlet_id
    // - join outlets via that outlet_id
    // - measurements as before
    let baseSQL = `
      FROM products p
      JOIN product_variants pv ON pv.product_id = p.product_id
      LEFT JOIN LATERAL (
        SELECT i.outlet_id,
               i.new_quantity AS current_stock,
               i.last_updated
        FROM inventory i
        WHERE i.variant_id = pv.variant_id
          AND i.merchant_id = p.merchant_id
          AND i.status = 'active'
        ORDER BY i.last_updated DESC NULLS LAST, i.inventory_id DESC
        LIMIT 1
      ) inv ON true
      LEFT JOIN outlets o ON o.outlet_id = inv.outlet_id
      LEFT JOIN measurements m ON m.measurement_id = p.measurement_id
      WHERE p.merchant_id = $1
      ${searchCondition}
    `;

    // Reorder-level buckets using pv.reorder_level and inv.current_stock
    // Treat NULLs as 0 for comparisons
    let reorderLevelCondition = "";
    if (reorderlevel === "reached") {
      reorderLevelCondition = `
        AND COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0)
      `;
    } else if (reorderlevel === "near to reach") {
      reorderLevelCondition = `
        AND COALESCE(inv.current_stock, 0) >  COALESCE(pv.reorder_level, 0)
        AND COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) * 2
      `;
    }

    // Date filter uses latest inventory row timestamp
    let dateCondition = "";
    if (fromDate && toDate) {
      dateCondition = ` AND inv.last_updated::date BETWEEN $${queryParams.length + 1} AND $${queryParams.length + 2}`;
      queryParams.push(fromDate, toDate);
    } else if (fromDate) {
      dateCondition = ` AND inv.last_updated::date >= $${queryParams.length + 1}`;
      queryParams.push(fromDate);
    } else if (toDate) {
      dateCondition = ` AND inv.last_updated::date <= $${queryParams.length + 1}`;
      queryParams.push(toDate);
    }

    // Pagination params come last
    const limitIndex = queryParams.length + 1;
    const offsetIndex = queryParams.length + 2;
    const paginatedParams = [...queryParams, parsedLimit, offset];

    // Data query
    const dataSQL = `
        SELECT
          p.product_id,
          p.title AS product_title,
          pv.variant_id,
          pv.variant_value,
          pv.reorder_level,                              -- same name as before
          COALESCE(inv.current_stock, 0) AS current_stock, -- same name as before
          inv.last_updated AS updated_at,                -- ✅ back to old name
          o.name AS outlet_name,
          inv.outlet_id,
          m.measurement_value,
          CASE
            WHEN COALESCE(inv.current_stock, 0) <= 0 THEN 'out_of_stock'
            WHEN COALESCE(inv.current_stock, 0) > 0
            AND COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) THEN 'reorder_level_reached'
            WHEN COALESCE(inv.current_stock, 0) > COALESCE(pv.reorder_level, 0)
            AND COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) * 2 THEN 'low_stock'
            ELSE 'in_stock'
          END AS stock_status

      ${baseSQL + dateCondition + reorderLevelCondition}
      ORDER BY
        CASE
          WHEN COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) THEN 1
          WHEN COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) * 2 THEN 2
          ELSE 3
        END,
        COALESCE(inv.current_stock, 0) ASC,
        pv.variant_id ASC
      LIMIT $${limitIndex} OFFSET $${offsetIndex}
    `;

    // Count query
    const countSQL = `
      SELECT COUNT(*) FROM (
        SELECT 1
        ${baseSQL + dateCondition + reorderLevelCondition}
      ) AS subquery
    `;

    const [dataResult, countResult] = await Promise.all([
      pool.query(dataSQL, paginatedParams),
      pool.query(countSQL, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].count, 10) || 0;

    res.json({
      success: true,
      results: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching inventory-based search:", error);

    if (error.code === "42501") {
      return res.status(403).json({
        success: false,
        message: "Permission denied to access inventory data.",
      });
    }

    if (error.code === "22P02") {
      return res
        .status(400)
        .json({ success: false, message: "Invalid query input format." });
    }

    res.status(500).json({ success: false, message: "Internal server error" });
  }
});


module.exports = router;
