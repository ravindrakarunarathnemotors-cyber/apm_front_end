const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");

// create a new batch
router.post("/create-batch", authenticateToken, async (req, res) => {
  const {
    product_id,
    variant_id,
    batch_number,
    cost_price = 0,
    selling_price = 0,
    expiry_date = null,
    manufacture_date = null,
    supplier_id = null,
    status = "active",
  } = req.body;

  const created_by = req.user?.user_id ?? req.user?.id ?? null;

  /* ================= BASIC VALIDATION ================= */

  if (!product_id || !variant_id || !batch_number) {
    return res.status(400).json({
      message: "product_id, variant_id and batch_number are required",
    });
  }

  if (batch_number.length > 50) {
    return res.status(400).json({
      message: "Batch number cannot exceed 50 characters",
    });
  }

  try {
    /* ================= INSERT BATCH ================= */

    const insertQuery = `
      INSERT INTO batch_management (
        product_id,
        variant_id,
        batch_number,
        cost_price,
        selling_price,
        expiry_date,
        manufacture_date,
        supplier_id,
        status,
        created_by
      )
      VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10
      )
      RETURNING *
    `;

    const values = [
      product_id,
      variant_id,
      batch_number,
      cost_price,
      selling_price,
      expiry_date,
      manufacture_date,
      supplier_id,
      status,
      created_by,
    ];

    const { rows } = await pool.query(insertQuery, values);
    const createdBatch = rows[0];

    /* ================= ADMIN LOG ================= */

    try {
      await insertAdminLog(
        created_by,
        "Batch Management",
        `Created new batch [Batch No: ${batch_number}] for Variant ID ${variant_id}`,
      );
    } catch (logError) {
      console.error("Admin log failed:", logError.message);
    }

    /* ================= NOTIFICATION ================= */

    try {
      await insertNotification(
        created_by, // user_id
        "Batch Management", // module
        "New Batch Created", // event_type
        `New batch (${batch_number}) has been successfully created.`,
        "Website Notification", // channel
        "Unread", // status
      );
    } catch (notifyError) {
      console.error("Notification failed:", notifyError.message);
    }

    /* ================= RESPONSE ================= */

    return res.status(201).json({
      message: "Batch created successfully",
      batch: createdBatch,
    });
  } catch (err) {
    console.error("Error creating batch:", err.message);

    if (err.code === "23505") {
      return res.status(409).json({
        message: "Duplicate batch number",
      });
    }

    return res.status(500).json({ message: "Internal server error" });
  }
});

// batch product search
router.get("/batch-product-search", authenticateToken, async (req, res) => {
  const { query, page = 1 } = req.query;

  if (!query || query.trim() === "") {
    return res.status(400).json({ message: "Search query is required." });
  }

  const { merchant_id } = req.user;
  const trimmedQuery = query.trim();
  const searchTerm = `%${trimmedQuery.toLowerCase()}%`;

  const PAGE_SIZE = 20;
  const currentPage = Math.max(parseInt(page, 10) || 1, 1);
  const offset = (currentPage - 1) * PAGE_SIZE;

  try {
    /* =====================================================
         1️⃣ Check if query matches a VARIANT ID (highest priority)
      ====================================================== */
    const variantIdMatch = await pool.query(
      `
        SELECT product_id
        FROM product_variants
        WHERE variant_id::text = $1
          AND status = 'active'
        LIMIT 1
        `,
      [trimmedQuery],
    );

    let productCondition = "";
    let params = [merchant_id];

    if (variantIdMatch.rowCount > 0) {
      // 🔹 Exact variant_id → only that product
      productCondition = `p.product_id = $2`;
      params.push(variantIdMatch.rows[0].product_id);
    } else {
      // 🔹 General product + variant search
      productCondition = `
  (
    LOWER(p.title) ILIKE $2 OR
    p.product_id::text = $3 OR
    LOWER(pv.variant_value) ILIKE $2 OR
    LOWER(pv.sku) ILIKE $2 OR
    LOWER(pv.barcode) ILIKE $2 OR
    EXISTS (
      SELECT 1
      FROM unnest(p.similar_keywords) kw
      WHERE LOWER(kw) ILIKE $2
    )
  )
`;

      params.push(searchTerm, trimmedQuery);
    }

    /* =====================================================
         2️⃣ TOTAL COUNT (for pagination)
      ====================================================== */
    const countQuery = `
        SELECT COUNT(DISTINCT p.product_id) AS total
        FROM products p
        LEFT JOIN product_variants pv
          ON pv.product_id = p.product_id
         AND pv.status = 'active'
        WHERE p.merchant_id = $1
          AND p.status = 'active'
          AND ${productCondition}
      `;

    const countResult = await pool.query(countQuery, params);
    const totalRecords = parseInt(countResult.rows[0].total, 10);
    const totalPages = Math.ceil(totalRecords / PAGE_SIZE);

    /* =====================================================
         3️⃣ FETCH PRODUCTS + MAIN IMAGE + VARIANTS
      ====================================================== */
    const dataQuery = `
        SELECT
          p.product_id,
          p.title AS product_title,
          p.description,
          p.status AS product_status,
          p.price,

          pm.media_url AS product_image,

          json_agg(
            json_build_object(
              'variant_id', pv.variant_id,
              'variant_value', pv.variant_value,
              'sku', pv.sku,
              'barcode', pv.barcode,
              'price', pv.price,
              'status', pv.status
            )
            ORDER BY pv.variant_id
          ) FILTER (WHERE pv.variant_id IS NOT NULL) AS variants

        FROM products p

        /* ===== MAIN PRODUCT IMAGE ===== */
        LEFT JOIN LATERAL (
          SELECT media_url
          FROM product_media
          WHERE product_id = p.product_id
            AND variant_id IS NULL
            AND main = TRUE
            AND status = 'active'
          ORDER BY media_id DESC
          LIMIT 1
        ) pm ON TRUE

        LEFT JOIN product_variants pv
          ON pv.product_id = p.product_id
         AND pv.status = 'active'

        WHERE p.merchant_id = $1
          AND p.status = 'active'
          AND ${productCondition}

        GROUP BY p.product_id, pm.media_url
        ORDER BY p.product_id DESC
        LIMIT ${PAGE_SIZE}
        OFFSET ${offset}
      `;

    const { rows } = await pool.query(dataQuery, params);

    return res.json({
      results: rows,
      pagination: {
        page: currentPage,
        page_size: PAGE_SIZE,
        total_records: totalRecords,
        total_pages: totalPages,
      },
    });
  } catch (err) {
    console.error("Error in /batch-product-search:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});
// batch validation
router.post("/validate-batch-number", authenticateToken, async (req, res) => {
  const { variant_id, batch_number } = req.body;

  if (!variant_id || !batch_number) {
    return res.status(400).json({
      valid: false,
      message: "variant_id and batch_number are required",
    });
  }

  try {
    const checkQuery = `
      SELECT 1
      FROM batch_management
      WHERE variant_id = $1
        AND batch_number = $2
        AND status != 'inactive'
      LIMIT 1
    `;

    const { rowCount } = await pool.query(checkQuery, [
      variant_id,
      batch_number.trim(),
    ]);

    if (rowCount > 0) {
      return res.status(409).json({
        valid: false,
        message:
          "This batch number already exists for this variant and is currently active.",
      });
    }

    return res.json({
      valid: true,
      message: "Batch number is available for this variant.",
    });
  } catch (err) {
    console.error("Batch number validation error:", err.message);
    return res
      .status(500)
      .json({ valid: false, message: "Internal server error" });
  }
});

// batch list
router.get("/batch-list-fetch", authenticateToken, async (req, res) => {
  const {
    product_id,
    variant_id,
    outlet_id,
    from_date,
    to_date,
    status = "active",
    page = 1,
    page_size = 20,
  } = req.query;

  const { merchant_id } = req.user;

  const limit = Math.min(parseInt(page_size, 10) || 20, 100);
  const currentPage = Math.max(parseInt(page, 10) || 1, 1);
  const offset = (currentPage - 1) * limit;

  const conditions = [];
  const params = [];
  let idx = 1;

  /* ================= BASE CONDITIONS ================= */
  conditions.push(`bm.status = $${idx++}`);
  params.push(status);

  conditions.push(`p.merchant_id = $${idx++}`);
  params.push(merchant_id);

  /* ================= OPTIONAL FILTERS ================= */
  if (product_id) {
    conditions.push(`bm.product_id = $${idx++}`);
    params.push(product_id);
  }

  if (variant_id) {
    conditions.push(`bm.variant_id = $${idx++}`);
    params.push(variant_id);
  }

  if (from_date) {
    conditions.push(`bm.created_at::date >= $${idx++}`);
    params.push(from_date);
  }

  if (to_date) {
    conditions.push(`bm.created_at::date <= $${idx++}`);
    params.push(to_date);
  }

  const whereClause = conditions.length
    ? `WHERE ${conditions.join(" AND ")}`
    : "";

  try {
    /* ================= TOTAL COUNT ================= */
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM batch_management bm
      JOIN products p ON p.product_id = bm.product_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, params);
    const totalRecords = Number(countResult.rows[0].total);
    const totalPages = Math.ceil(totalRecords / limit);

    /* ================= DATA QUERY ================= */
    const dataQuery = `
      SELECT
        bm.batch_management_id,
        bm.batch_number,
        bm.cost_price,
        bm.selling_price,
        bm.expiry_date,
        bm.manufacture_date,
        bm.status,
        bm.created_at,

        p.product_id,
        p.title AS product_title,

        pv.variant_id,
        pv.variant_value,
        pv.sku,

        /* ===== OUTLET BATCH CURRENT STOCK ===== */
        bcs.outlet_id,
        COALESCE(bcs.batch_current_stock, 0) AS batch_current_stock,

        /* ===== FINAL IMAGE (variant → product fallback) ===== */
        COALESCE(vpm.media_url, ppm.media_url) AS image_url

      FROM batch_management bm

      JOIN products p 
        ON p.product_id = bm.product_id

      JOIN product_variants pv 
        ON pv.variant_id = bm.variant_id
       AND pv.status = 'active'

      /* ===== CURRENT STOCK OF THIS BATCH FOR OUTLET ===== */
      LEFT JOIN LATERAL (
        SELECT
          inv.outlet_id,
          inv.new_quantity AS batch_current_stock
        FROM inventory inv
        WHERE inv.variant_id = bm.variant_id
          AND inv.merchant_id = $${idx}
          AND inv.status = 'active'
          AND COALESCE(inv.batch_number, '') = COALESCE(bm.batch_number, '')
          ${outlet_id ? `AND inv.outlet_id = $${idx + 1}` : ""}
        ORDER BY inv.last_updated DESC NULLS LAST, inv.inventory_id DESC
        LIMIT 1
      ) bcs ON TRUE

      /* ===== VARIANT MAIN IMAGE ===== */
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
          AND variant_id = pv.variant_id
          AND main = TRUE
          AND status = 'active'
        ORDER BY media_id DESC
        LIMIT 1
      ) vpm ON TRUE

      /* ===== PRODUCT MAIN IMAGE (fallback) ===== */
      LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
          AND variant_id IS NULL
          AND main = TRUE
          AND status = 'active'
        ORDER BY media_id DESC
        LIMIT 1
      ) ppm ON TRUE

      ${whereClause}

      ORDER BY bm.created_at DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `;

    const dataParams = outlet_id
      ? [...params, merchant_id, outlet_id]
      : [...params, merchant_id];

    const [{ rows }, currencyResult] = await Promise.all([
      pool.query(dataQuery, dataParams),
      pool.query(`
        SELECT currency
        FROM system_settings
        LIMIT 1
      `),
    ]);

    const currency = currencyResult.rows[0]?.currency || null;

    return res.json({
      results: rows,
      currency: {
        currency,
      },
      pagination: {
        page: currentPage,
        page_size: limit,
        total_records: totalRecords,
        total_pages: totalPages,
      },
    });
  } catch (err) {
    console.error("Error fetching batch list:", err.message);
    return res.status(500).json({ message: "Failed to fetch batch list" });
  }
});

// batch status management

router.post("/update-batch-status", authenticateToken, async (req, res) => {
  const { batch_management_id, status } = req.body;

  const user_id = req.user?.user_id ?? req.user?.id ?? null;

  /* ================= VALIDATION ================= */

  if (!batch_management_id || !status) {
    return res.status(400).json({
      message: "batch_management_id and status are required",
    });
  }

  if (!["active", "inactive"].includes(status)) {
    return res.status(400).json({
      message: "Invalid status value",
    });
  }

  try {
    /* ================= FETCH BATCH INFO ================= */

    const batchQuery = `
        SELECT batch_number, status
        FROM batch_management
        WHERE batch_management_id = $1
        LIMIT 1
      `;

    const batchResult = await pool.query(batchQuery, [batch_management_id]);

    if (batchResult.rowCount === 0) {
      return res.status(404).json({
        message: "Batch not found",
      });
    }

    const { batch_number, status: currentStatus } = batchResult.rows[0];

    if (currentStatus === status) {
      return res.status(200).json({
        message: `Batch is already ${status}`,
      });
    }

    /* ================= UPDATE STATUS ================= */

    const updateQuery = `
        UPDATE batch_management
        SET status = $1,
            updated_at = NOW()
        WHERE batch_management_id = $2
        RETURNING *
      `;

    const { rows } = await pool.query(updateQuery, [
      status,
      batch_management_id,
    ]);

    /* ================= ADMIN LOG ================= */

    try {
      await insertAdminLog(
        user_id,
        "Batch Management",
        `Updated batch status to '${status}' (Batch ID: ${batch_management_id}, Batch No: ${batch_number})`,
      );
    } catch (logErr) {
      console.error("Admin log failed:", logErr.message);
    }

    /* ================= RESPONSE ================= */

    return res.json({
      message: "Batch status updated successfully",
      batch: rows[0],
    });
  } catch (err) {
    console.error("Error updating batch status:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// fetch inventory strategies on system settings
router.get("/inventory-strategies", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `
      SELECT inventory_strategy_id, name, status
      FROM inventory_strategy
      ORDER BY inventory_strategy_id ASC
      `,
    );

    return res.json({
      success: true,
      data: result.rows,
    });
  } catch (err) {
    console.error("Error fetching inventory strategies:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch inventory strategies",
    });
  }
});

module.exports = router;
