const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");


// inventory search route
router.post("/inventory-search", authenticateToken, async (req, res) => {
  const { id, product_name, product_id, outlet_name, page = 1 } = req.body;
  const { merchant_id } = req.user;

  const productId = product_id || id;
  const pageSize = 25;
  const offset = (page - 1) * pageSize;

  if (!merchant_id) {
    return res
      .status(400)
      .json({ success: false, error: "Merchant ID is required." });
  }

  if (typeof page !== "number" || page < 1) {
    return res
      .status(400)
      .json({ success: false, error: "Page must be a positive number." });
  }

  try {
    const queryParams = [merchant_id];
    const whereConditions = ["p.merchant_id = $1", `p.status = 'active'`];

    if (productId) {
      queryParams.push(productId);
      whereConditions.push(`p.product_id = $${queryParams.length}`);
    }

    if (
      outlet_name &&
      outlet_name.toString().trim() !== "" &&
      outlet_name.toString().toLowerCase() !== "all"
    ) {
      queryParams.push(outlet_name);
      whereConditions.push(`o.outlet_id = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const query = `
      SELECT
        p.product_id,
        p.title AS product_name,
        p.status,
        p.created_at AS product_created_at,
        m.measurement_value, -- ✅ ADDED

        (
          SELECT media_url
          FROM product_media pm
          WHERE pm.product_id = p.product_id
            AND pm.variant_id IS NULL
            AND pm.main = TRUE
            AND pm.status = 'active'
          LIMIT 1
        ) AS main_image_url,

        COUNT(DISTINCT pv.variant_id) AS variants_count,
        COALESCE(SUM(i.new_quantity), 0) AS total_quantity,

        json_agg(
          DISTINCT jsonb_build_object(
            'outlet_name', o.name,
            'variants', COALESCE((
              SELECT json_agg(
                jsonb_build_object(
                  'variant_id', pv2.variant_id,
                  'variant_type', pv2.variant_type,
                  'variant_value', pv2.variant_value,
                  'sku', pv2.sku,
                  'quantity', COALESCE(latest_inventory.new_quantity, 0),
                  'measurement_value', m.measurement_value, -- ✅ ADDED
                  'last_updated', latest_inventory.last_updated
                )
              )
              FROM product_variants pv2
              LEFT JOIN LATERAL (
                SELECT new_quantity, last_updated
                FROM inventory
                WHERE variant_id = pv2.variant_id
                  AND outlet_id = o.outlet_id
                  AND status = 'active'
                ORDER BY last_updated DESC
                LIMIT 1
              ) AS latest_inventory ON true
              WHERE pv2.product_id = p.product_id
            ), '[]'::json)
          )
        ) AS outlet_variants

      FROM products p
      LEFT JOIN measurements m ON p.measurement_id = m.measurement_id -- ✅ ADDED
      LEFT JOIN product_variants pv ON pv.product_id = p.product_id
      LEFT JOIN inventory i ON i.variant_id = pv.variant_id AND i.status = 'active'
      LEFT JOIN outlets o ON o.outlet_id = i.outlet_id
      ${whereClause}
      GROUP BY
        p.product_id,
        p.title,
        p.status,
        p.created_at,
        m.measurement_value -- ✅ ADDED
      ORDER BY p.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    queryParams.push(pageSize, offset);

    const { rows } = await pool.query(query, queryParams);

    const filteredRows = rows.filter((row) => row.product_id);

    if (filteredRows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No matching inventory found for product "${product_name}" in outlet "${outlet_name}". Please check both fields.`,
      });
    }

    return res.json({ success: true, data: filteredRows });
  } catch (err) {
    console.error("❌ Inventory Search Error:", err);

    return res.status(500).json({
      success: false,
      error: "Unexpected server error. Please try again later.",
    });
  }
});

// inventory products search route
router.get("/inventory-product-search", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;

  const raw = (req.query.q || req.query.search || "").toString();
  const search = raw.trim();

  if (search.length < 2) {
    return res.status(400).json({
      success: false,
      error: "Search query must be at least 2 characters long.",
    });
  }

  try {
    /**
     * 1️⃣ Exact numeric search:
     *    product_id OR variant_id
     */
    if (/^\d+$/.test(search)) {
      const exactSql = `
        SELECT DISTINCT
          p.product_id,
          p.title,
          pv.variant_id AS matched_variant_id,
          pv.barcode AS matched_barcode
        FROM products p
        LEFT JOIN product_variants pv
          ON pv.product_id = p.product_id
        WHERE p.merchant_id = $1
          AND p.status = 'active'
          AND (
            p.product_id = $2
            OR pv.variant_id = $2
          )
        LIMIT 20;
      `;

      const exactResult = await pool.query(exactSql, [
        merchant_id,
        Number(search),
      ]);

      if (exactResult.rows.length > 0) {
        return res.json({
          success: true,
          products: exactResult.rows,
        });
      }
    }

    /**
     * 2️⃣ Fuzzy search:
     *    - title
     *    - product_id
     *    - variant_id
     *    - barcode
     *    - similar_keywords
     */
    const fuzzySql = `
      SELECT DISTINCT
        p.product_id,
        p.title,
        pv.variant_id AS matched_variant_id,
        pv.barcode AS matched_barcode
      FROM products p
      LEFT JOIN product_variants pv
        ON pv.product_id = p.product_id
      WHERE p.merchant_id = $1
        AND p.status = 'active'
        AND (
          LOWER(p.title) LIKE '%' || LOWER($2) || '%'
          OR CAST(p.product_id AS TEXT) LIKE '%' || $2 || '%'
          OR CAST(pv.variant_id AS TEXT) LIKE '%' || $2 || '%'
          OR LOWER(pv.barcode) LIKE '%' || LOWER($2) || '%'
          OR EXISTS (
            SELECT 1
            FROM unnest(p.similar_keywords) kw
            WHERE LOWER(kw) LIKE '%' || LOWER($2) || '%'
          )
        )
      ORDER BY p.title ASC
      LIMIT 20;
    `;

    const { rows } = await pool.query(fuzzySql, [merchant_id, search]);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No active products found matching "${search}".`,
      });
    }

    return res.json({
      success: true,
      products: rows,
    });
  } catch (error) {
    console.error("Inventory product search error:", error);
    return res.status(500).json({
      success: false,
      error: "Server error while searching products.",
    });
  }
});



// get/fetch outlet names -is available true and matching merchant

router.get("/active-outlets", authenticateToken, async (req, res) => {
  

  try {
    const query = `
      SELECT outlet_id, name
      FROM outlets
      WHERE is_active = true
      ORDER BY name ASC
    `;
     const { rows } = await pool.query(query);

    res.json({
      success: true,
      outlets: rows,
    });
  } catch (err) {
    console.error("❌ Error fetching active outlets:", err);
    res.status(500).json({
      success: false,
      error: "Failed to fetch active outlets.",
    });
  }
});
// get product/variants by outlets (keeps original behavior; adds optional ?product_id=)
router.get(
  "/products-by-outlet/:outlet_id",
  authenticateToken,
  async (req, res) => {
    const outlet_id = parseInt(req.params.outlet_id, 10);
    const { merchant_id } = req.user;
    const { product_id } = req.query;

    if (Number.isNaN(outlet_id)) {
      return res.status(400).json({ error: "Invalid outlet ID" });
    }

    // build WHERE and params to match original behavior
    const where = ["inv.merchant_id = $1"];
    const params = [merchant_id];

    // original: 0 = all branches; else restrict to outlet
    if (outlet_id !== 0) {
      where.push(`inv.outlet_id = $${params.length + 1}`);
      params.push(outlet_id);
    }

    // optional product filter only if provided and numeric
    if (product_id !== undefined && String(product_id).trim() !== "") {
      const pidStr = String(product_id).trim();
      if (!/^\d+$/.test(pidStr)) {
        return res.status(400).json({ error: "Invalid product_id" });
      }
      where.push(`p.product_id = $${params.length + 1}`);
      params.push(Number(pidStr));
    }

    try {
      const query = `
   SELECT
  p.product_id,
  p.title AS product_title,
  p.description AS product_description,
  p.status AS product_status,
  p.measurement_id,
  m.measurement_value AS measurement_value,

  pv.variant_id,
  pv.variant_type,
  pv.variant_value,
  pv.sku,
  pv.barcode,
  pv.price,
  pv.compare_at_price,
  pv.cost_per_item,
  pv.reorder_level,

  inv.outlet_id,
  o.name AS outlet_name,

  COALESCE(SUM(CASE WHEN inv.adjust_quantity > 0 THEN inv.adjust_quantity ELSE 0 END), 0) AS stock_in,
  COALESCE(SUM(CASE WHEN inv.adjust_quantity < 0 THEN inv.adjust_quantity ELSE 0 END), 0) AS stock_out,

  latest.current_stock,
  latest.last_updated AS current_last_updated,

  pm.media_url,
  pm.media_type,

  c.category_id,
  c.name AS category_name

FROM inventory inv
INNER JOIN product_variants pv ON inv.variant_id = pv.variant_id
INNER JOIN products p ON pv.product_id = p.product_id
LEFT JOIN measurements m ON p.measurement_id = m.measurement_id
LEFT JOIN outlets o ON inv.outlet_id = o.outlet_id

-- pick a single media per product
LEFT JOIN LATERAL (
  SELECT media_url, media_type
  FROM product_media
  WHERE product_id = p.product_id AND status = 'active'
  ORDER BY main DESC, created_at ASC
  LIMIT 1
) pm ON TRUE

LEFT JOIN product_category pc ON p.product_id = pc.product_id
LEFT JOIN categories c ON pc.category_id = c.category_id

-- latest inventory row per (merchant, outlet, variant)
LEFT JOIN LATERAL (
  SELECT i.new_quantity AS current_stock,
         i.last_updated
  FROM inventory i
  WHERE i.merchant_id = inv.merchant_id
    AND i.outlet_id   = inv.outlet_id
    AND i.variant_id  = pv.variant_id
    AND i.status = 'active'
  ORDER BY i.last_updated DESC NULLS LAST, i.inventory_id DESC
  LIMIT 1
) latest ON TRUE

WHERE ${where.join(" AND ")}

GROUP BY
  p.product_id, p.title, p.description, p.status, p.measurement_id, m.measurement_value,
  pv.variant_id, pv.variant_type, pv.variant_value, pv.sku, pv.barcode, pv.price,
  pv.compare_at_price, pv.cost_per_item, pv.reorder_level,
  inv.outlet_id, o.name,
  pm.media_url, pm.media_type,
  c.category_id, c.name,
  latest.current_stock, latest.last_updated

ORDER BY p.product_id, pv.variant_id;
      `;

      const result = await pool.query(query, params);

      // Group by product (unchanged)
      const productsMap = {};
      for (const row of result.rows) {
        const pid = row.product_id;
        if (!productsMap[pid]) {
          productsMap[pid] = {
            product_id: pid,
            title: row.product_title,
            description: row.product_description,
            status: row.product_status,
            measurement_id: row.measurement_id,
            measurement_value: row.measurement_value,
            media_url: row.media_url,
            media_type: row.media_type,
            category_id: row.category_id,
            category_name: row.category_name,
            variants: [],
          };
        }
        const current_stock = parseInt(row.current_stock);
        const reorder_level =
          row.reorder_level !== null ? parseInt(row.reorder_level) : null;

        let stock_status = "in stock";
        if (current_stock <= 0) stock_status = "out of stock";
        else if (reorder_level !== null && current_stock <= reorder_level)
          stock_status = "reorder_level_reached";
        else if (reorder_level !== null && current_stock <= 2 * reorder_level)
          stock_status = "low_stock";

        productsMap[pid].variants.push({
          variant_id: row.variant_id,
          variant_type: row.variant_type,
          variant_value: row.variant_value,
          sku: row.sku,
          barcode: row.barcode,
          price: row.price,
          compare_at_price: row.compare_at_price,
          cost_per_item: row.cost_per_item,
          reorder_level,
          outlet_id: row.outlet_id,
          outlet_name: row.outlet_name,
          stock_in: parseInt(row.stock_in),
          stock_out: parseInt(row.stock_out),
          current_stock,
          stock_status,
          measurement_value: row.measurement_value,
        });
      }

      // Prioritize by most critical variant (unchanged)
      const statusPriority = {
        "out of stock": 0,
        reorder_level_reached: 1,
        low_stock: 2,
        "in stock": 3,
      };
      const allVariants = [];
      Object.values(productsMap).forEach((product) => {
        product.variants.forEach((variant) => {
          allVariants.push({
            ...variant,
            product,
            __priority: statusPriority[variant.stock_status] ?? 3,
          });
        });
      });
      allVariants.sort((a, b) => a.__priority - b.__priority);

      const seen = new Set();
      const finalProductsMap = new Map();
      for (const v of allVariants) {
        const key = `${v.product.product_id}_${v.variant_id}`;
        if (seen.has(key)) continue;
        if (!finalProductsMap.has(v.product.product_id)) {
          finalProductsMap.set(v.product.product_id, {
            ...v.product,
            variants: [],
          });
        }
        finalProductsMap.get(v.product.product_id).variants.push({
          variant_id: v.variant_id,
          variant_type: v.variant_type,
          variant_value: v.variant_value,
          sku: v.sku,
          barcode: v.barcode,
          price: v.price,
          compare_at_price: v.compare_at_price,
          cost_per_item: v.cost_per_item,
          reorder_level: v.reorder_level,
          outlet_id: v.outlet_id,
          outlet_name: v.outlet_name,
          stock_in: v.stock_in,
          stock_out: v.stock_out,
          current_stock: v.current_stock,
          stock_status: v.stock_status,
          measurement_value: v.measurement_value,
        });
        seen.add(key);
      }

      const sortedProducts = Array.from(finalProductsMap.values());
      return res.json({ results: sortedProducts });
    } catch (err) {
      console.error("Error fetching products by outlet:", err.message);
      res.status(500).json({ error: "Internal server error" });
    }
  }
);

router.get("/product-search-global", authenticateToken, async (req, res) => {
  try {
    // support both 'search' and 'q' query param names
    const raw = (req.query.search || req.query.q || "").toString();
    const search = raw.trim();

    if (!search) {
      return res.json([]); // keep behavior: no input → empty array
    }

    // If the search is an integer (only digits), first try an exact product_id lookup
    if (/^\d+$/.test(search)) {
      const exactQuery = `
        SELECT DISTINCT title, product_id
        FROM products
        WHERE product_id = $1
        LIMIT 10
      `;
      const exactResult = await pool.query(exactQuery, [Number(search)]);
      if (exactResult.rows.length > 0) {
        return res.json(exactResult.rows);
      }
      // if no exact match, fallthrough to fuzzy search below
    }

    // Fuzzy search: match title ILIKE or product_id::text ILIKE
const fuzzyQuery = `
  SELECT DISTINCT
    p.title,
    p.product_id
  FROM products p
  WHERE
    p.title ILIKE $1
    OR CAST(p.product_id AS TEXT) ILIKE $1
    OR EXISTS (
      SELECT 1
      FROM unnest(p.similar_keywords) kw
      WHERE kw ILIKE $1
    )
  LIMIT 10
`;

    const likeParam = `%${search}%`;
    const fuzzyResult = await pool.query(fuzzyQuery, [likeParam]);

    return res.json(fuzzyResult.rows);
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

module.exports = router;
