const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { insertAdminLog } = require("../../models/userLogs");

// const { v4: uuidv4 } = require("uuid");

// search products (variants/products names and id's on inventory movement )
router.get("/search-product-variants", authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query || query.trim().length < 2) {
    return res
      .status(400)
      .json({ message: "Search query must be at least 2 characters." });
  }

  const { merchant_id } = req.user;

  const trimmedQuery = query.trim();
  const lowerQuery = trimmedQuery.toLowerCase();
  const searchTerm = `%${lowerQuery}%`;

  try {
    const searchQuery = `
      SELECT
        p.product_id,
        p.title,
        pv.variant_id,
        pv.variant_type,
        pv.variant_value
      FROM products p
      LEFT JOIN product_variants pv ON p.product_id = pv.product_id
      WHERE
        p.merchant_id = $1 AND (
          LOWER(p.title) ILIKE $2 OR
          LOWER(pv.variant_value) ILIKE $2 OR
          p.product_id::text = $3 OR
          pv.variant_id::text = $3
        )
      ORDER BY p.product_id, pv.variant_id;
    `;

    const result = await pool.query(searchQuery, [
      merchant_id,
      searchTerm,
      trimmedQuery,
    ]);

    const productsMap = {};

    for (const row of result.rows) {
      const pid = row.product_id;

      const matchedByProductId = pid.toString() === trimmedQuery;
      const matchedByTitle = row.title?.toLowerCase().includes(lowerQuery);
      const matchedByVariant = row.variant_value
        ?.toLowerCase()
        .includes(lowerQuery);
      const matchedByVariantId = row.variant_id?.toString() === trimmedQuery;

      if (
        !matchedByProductId &&
        !matchedByTitle &&
        !matchedByVariant &&
        !matchedByVariantId
      )
        continue;

      if (!productsMap[pid]) {
        productsMap[pid] = {
          product_id: pid,
          title: row.title,
          variants: [],
        };
      }

      if (row.variant_id) {
        const alreadyIncluded = productsMap[pid].variants.some(
          (v) => v.variant_id === row.variant_id,
        );
        if (
          !alreadyIncluded &&
          (matchedByProductId ||
            matchedByTitle ||
            matchedByVariant ||
            matchedByVariantId)
        ) {
          productsMap[pid].variants.push({
            variant_id: row.variant_id,
            variant_type: row.variant_type,
            variant_value: row.variant_value,
          });
        }
      }
    }

    const products = Object.values(productsMap);

    if (!products.length) {
      return res
        .status(404)
        .json({ message: "No matching products or variants found." });
    }

    return res.json({ results: products });
  } catch (err) {
    console.error("Error searching product variants:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// add outlet

router.post("/add-outlet", authenticateToken, async (req, res) => {
  const {
    name,
    address,
    geocode,
    hotline,
    email,
    opening_hours_from,
    opening_hours_to,
    tel_number,
    is_active = true,
  } = req.body;

  const { merchant_id, user_id } = req.user;

  if (!name || !opening_hours_from || !opening_hours_to) {
    return res.status(400).json({ error: "Required fields are missing." });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Check duplicate outlet
    const checkQuery = `
      SELECT outlet_id 
      FROM outlets
      WHERE merchant_id = $1 AND name = $2 AND address = $3
    `;

    const checkResult = await client.query(checkQuery, [
      merchant_id,
      name,
      address,
    ]);

    if (checkResult.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Outlet already exists." });
    }

    // Insert outlet
    const insertOutletQuery = `
      INSERT INTO outlets (
        merchant_id,
        name,
        address,
        geocode,
        hotline,
        email,
        opening_hours_from,
        opening_hours_to,
        tel_number,
        is_active
      )
      VALUES (
        $1,$2,$3,$4,$5,
        $6,$7,$8,$9,$10
      )
      RETURNING *;
    `;

    const outletValues = [
      merchant_id,
      name,
      address || null,
      geocode || null,
      hotline || null,
      email || null,
      opening_hours_from,
      opening_hours_to,
      tel_number || null,
      is_active,
    ];

    const outletResult = await client.query(insertOutletQuery, outletValues);
    const newOutlet = outletResult.rows[0];
    const outlet_id = newOutlet.outlet_id;

    // Create Default Cash account
    const insertAccountQuery = `
      INSERT INTO accounts (
        name,
        type,
        p_method_id,
        description,
        status,
        balance,
        outlet_id,
        bank_account,
        is_default,
        by
      )
      VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10
      )
    `;

    await client.query(insertAccountQuery, [
      `${name} Cash`,
      "offline",
      5,
      "Default cash account for outlet",
      "active",
      0,
      outlet_id,
      false,
      true,
      user_id,
    ]);

    // Admin Log
    const logQuery = `
      INSERT INTO admin_log (user_id, module, log, date)
      VALUES ($1,$2,$3,NOW())
    `;

    await client.query(logQuery, [
      user_id,
      "Outlet",
      `New outlet created: ${name} (ID: ${outlet_id})`,
    ]);

    await client.query("COMMIT");

    res.status(201).json({
      message: "Outlet created successfully.",
      outlet: newOutlet,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error creating outlet:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release();
  }
});

// get outlets

router.get("/get-outlets", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;
  console.log("merchant id is: ", merchant_id);
  try {
    const result = await pool.query(
      `SELECT * FROM outlets WHERE merchant_id = $1 ORDER BY created_at DESC`,
      [merchant_id],
    );

    // console.log("Fetched outlets:", result.rows);

    res.status(200).json({ outlets: result.rows });
  } catch (error) {
    console.error("Error fetching outlets:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ✅ Update outlet status
router.put("/update-outlet-status", authenticateToken, async (req, res) => {
  const { outlet_id, is_active, user_id } = req.body;

  console.log("outlet_id", outlet_id);
  console.log("is_active", is_active);
  console.log("user_id", user_id);
  try {
    const result = await pool.query(
      `
      UPDATE outlets
      SET is_active = $1,
          updated_at = NOW()
      WHERE outlet_id = $2
      RETURNING outlet_id, is_active, updated_at;
      `,
      [is_active, outlet_id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        error: "Outlet not found or does not belong to this merchant",
      });
    }

    res.status(200).json({
      message: "Outlet status updated successfully",
      outlet: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating outlet status:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
