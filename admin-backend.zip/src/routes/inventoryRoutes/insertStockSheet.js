// /**
//  * Ensure stock_sheet_header has ONLY ONE row.
//  * - If exists → UPDATE it
//  * - If not → INSERT first row
//  */
// async function upsertStockSheetHeader(client, {
//   user_id,
//   stock_type,
//   remark = null,
// }) {
//   // Check if a row already exists
//   const existing = await client.query(
//     `SELECT sheet_id FROM stock_sheet_header LIMIT 1`
//   );

//   if (existing.rowCount === 0) {
//     // INSERT FIRST RECORD
//     await client.query(
//       `
//       INSERT INTO stock_sheet_header (user_id, stock_type, remark)
//       VALUES ($1, $2, $3)
//       `,
//       [user_id, stock_type, remark]
//     );
//   } else {
//     // UPDATE EXISTING SINGLE RECORD
//     await client.query(
//       `
//       UPDATE stock_sheet_header
//       SET
//         user_id = $1,
//         stock_type = $2,
//         remark = $3,
//         created_at = NOW()
//       WHERE sheet_id = $4
//       `,
//       [user_id, stock_type, remark, existing.rows[0].sheet_id]
//     );
//   }
// }

// module.exports = { upsertStockSheetHeader };
