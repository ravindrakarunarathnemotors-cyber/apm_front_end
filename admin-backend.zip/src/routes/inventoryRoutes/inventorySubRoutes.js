const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { insertAdminLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");
const multer = require("multer");
const { parse } = require("csv-parse/sync");

const csvStockUpload = multer({
  storage: multer.memoryStorage(),

  limits: {
    fileSize: 5 * 1024 * 1024,
  },

  fileFilter: (req, file, callback) => {
    const fileName = String(file.originalname || "").toLowerCase();

    if (!fileName.endsWith(".csv")) {
      return callback(new Error("Only CSV files are allowed"));
    }

    callback(null, true);
  },
});

// GET /search-product-variants?query=blue
router.get("/search-product-variants", authenticateToken, async (req, res) => {
  const { query, outlet_id } = req.query;

  if (!query || query.trim() === "") {
    return res.status(400).json({ message: "Search query is required." });
  }

  const { merchant_id, user_id } = req.user; // Securely from token

  const searchTerm = `%${query.trim().toLowerCase()}%`;
  const trimmedQuery = query.trim();

  try {
    let field_config = {
      barcode: true,
      sku: true,
      batch_no: true,
    };

    const systemConfigRes = await pool.query(
      `
  SELECT field_config
  FROM system_settings
  LIMIT 1
  `,
    );

    if (systemConfigRes.rowCount > 0 && systemConfigRes.rows[0].field_config) {
      field_config = systemConfigRes.rows[0].field_config;
    }

    // 🔹 Fetch default outlet for logged-in user
    const userOutletRes = await pool.query(
      `
  SELECT outlet_id
  FROM users
  WHERE user_id = $1
    AND merchant_id = $2
  LIMIT 1
  `,
      [user_id, merchant_id],
    );

    const default_outlet =
      userOutletRes.rowCount > 0 ? userOutletRes.rows[0].outlet_id : null;

    // First: check if query matches a variant_id
    const variantMatchRes = await pool.query(
      `SELECT product_id FROM product_variants WHERE variant_id::text = $1 AND status = 'active'`,
      [trimmedQuery],
    );

    let productCondition = "";
    let queryParams = [merchant_id, outlet_id];

    if (variantMatchRes.rowCount > 0) {
      const productId = variantMatchRes.rows[0].product_id;
      productCondition = `p.product_id::text = $3`;
      queryParams.push(productId);
    } else {
      // Regular title / variant_value / product_id match
      productCondition = `
(
  LOWER(p.title) ILIKE $3 OR
  LOWER(pv.variant_value) ILIKE $3 OR
  LOWER(pv.sku) ILIKE $3 OR
  LOWER(pv.barcode) ILIKE $3 OR
  p.product_id::text = $4 OR
  EXISTS (
    SELECT 1
    FROM unnest(p.similar_keywords) kw
    WHERE LOWER(kw) LIKE $3
  )
)
`;

      queryParams.push(searchTerm, trimmedQuery);
    }

    const searchQuery = `
      SELECT
        p.product_id,
        p.title,
        p.description,
        p.status,
        p.publishing_online,
        p.publishing_pos,
        p.price,
        p.measurement_id,
        m.measurement_value,

        pv.variant_id,
        pv.variant_value,
        pv.variant_type,
        pv.price AS variant_price,
        pv.sku,
        pv.barcode,
        pv.continue_selling_oos,
        pv.reorder_level,                         -- from product_variants

   inv.total_qty AS current_stock,
inv.outlet_id AS outlet_id,
bm_batches.batch_numbers AS batch_numbers

      FROM products p

       LEFT JOIN product_variants pv
    ON p.product_id = pv.product_id
   AND pv.status = 'active'

LEFT JOIN LATERAL (
  SELECT
    COALESCE(SUM(latest_stock.new_quantity), 0) AS total_qty,
    $2::int AS outlet_id
  FROM (
    SELECT DISTINCT ON (i.batch_number)
      i.batch_number,
      i.new_quantity
    FROM inventory i
    WHERE i.variant_id = pv.variant_id
      AND i.status = 'active'
      AND i.merchant_id = p.merchant_id
      AND i.outlet_id = $2
    ORDER BY
      i.batch_number,
      i.last_updated DESC NULLS LAST,
      i.inventory_id DESC
  ) latest_stock
) inv ON true

LEFT JOIN LATERAL (
  SELECT
    ARRAY_AGG(DISTINCT bm.batch_number ORDER BY bm.batch_number) AS batch_numbers
  FROM batch_management bm
  WHERE bm.variant_id = pv.variant_id
    AND bm.status = 'active'
) bm_batches ON true


      LEFT JOIN measurements m
        ON p.measurement_id = m.measurement_id
    WHERE p.merchant_id = $1
  AND p.status = 'active'
  AND ${productCondition}

      ORDER BY p.product_id, pv.variant_id;


`;

    const result = await pool.query(searchQuery, queryParams);

    // Group by product
    const productsMap = {};

    for (const row of result.rows) {
      const pid = row.product_id;

      if (!productsMap[pid]) {
        productsMap[pid] = {
          product_id: pid,
          title: row.title,
          description: row.description,
          status: row.status,
          publishing_online: row.publishing_online,
          publishing_pos: row.publishing_pos,
          price: row.price,
          measurement_id: row.measurement_id,
          measurement_value: row.measurement_value,
          variants: [],
        };
      }

      if (row.variant_id) {
        productsMap[pid].variants.push({
          variant_id: row.variant_id,
          variant_value: row.variant_value,
          variant_type: row.variant_type,
          price: row.variant_price,
          sku: row.sku,
          barcode: row.barcode,
          reorder_level: row.reorder_level, // ← from reorder_level table
          current_stock: row.current_stock, // ← from reorder_level table
          continue_selling: row.continue_selling_oos,
          measurement_value: row.measurement_value,
          outlet_id: row.outlet_id || null,
          batch_numbers: row.batch_numbers || [],
        });
      }
    }

    const products = Object.values(productsMap);

    if (!products.length) {
      return res
        .status(404)
        .json({ message: "No products or variants found." });
    }

    return res.json({
      field_config,
      default_outlet,
      results: products,
    });
  } catch (err) {
    console.error("Error searching product variants:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// search items route (no stock feature.)

// GET /search-products?query=blue
router.get("/stock-in-out-search", authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query || query.trim() === "") {
    return res.status(400).json({ message: "Search query is required." });
  }

  const { merchant_id } = req.user;
  const searchTerm = `%${query.trim().toLowerCase()}%`;
  const trimmedQuery = query.trim();

  try {
    // 1️⃣ Check if query is a variant_id (highest priority)
    const variantMatchRes = await pool.query(
      `
      SELECT product_id
      FROM product_variants
      WHERE variant_id::text = $1
        AND status = 'active'
      LIMIT 1
      `,
      [trimmedQuery],
    );

    let productCondition = "";
    let queryParams = [merchant_id];

    if (variantMatchRes.rowCount > 0) {
      // 🔹 Variant ID → fetch its product only
      productCondition = `p.product_id::text = $2`;
      queryParams.push(variantMatchRes.rows[0].product_id);
    } else {
      // 🔹 General search across product + variants
      productCondition = `
  (
    LOWER(p.title) ILIKE $2 OR
    LOWER(pv.variant_value) ILIKE $2 OR
    LOWER(pv.sku) ILIKE $2 OR
    LOWER(pv.barcode) ILIKE $2 OR
    p.product_id::text = $3 OR
    EXISTS (
      SELECT 1
      FROM unnest(p.similar_keywords) kw
      WHERE LOWER(kw) ILIKE $2
    )
  )
`;

      queryParams.push(searchTerm, trimmedQuery);
    }

    // 2️⃣ Product-focused query (NO inventory joins)
    const searchQuery = `
      SELECT DISTINCT
        p.product_id,
        p.title,
        p.description,
        p.status,
        p.publishing_online,
        p.publishing_pos,
        p.price,
        p.measurement_id,
          pv.variant_id,
        m.measurement_value
      FROM products p
      LEFT JOIN product_variants pv
        ON p.product_id = pv.product_id
       AND pv.status = 'active'
      LEFT JOIN measurements m
        ON p.measurement_id = m.measurement_id
      WHERE p.merchant_id = $1
        AND p.status = 'active'
        AND ${productCondition}
    ORDER BY pv.variant_id, p.product_id DESC
      LIMIT 50
    `;

    const result = await pool.query(searchQuery, queryParams);

    if (!result.rows.length) {
      return res.status(404).json({
        message: "No products found.",
      });
    }

    return res.json({
      results: result.rows,
    });
  } catch (err) {
    console.error("Error searching products:", err.message);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/Allpro", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user; // ✅ Securely from token
  try {
    const {
      page = 1,
      limit = 25,
      ToDate,
      created_at,
      variant_id,
      product_id,
      inventory_name,
      // merchant_id = "20001",
      stockType, // 👈 NEW: expect "stock in" or "stock out" (spaces)
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`i.merchant_id = $1`];

    if (variant_id) {
      queryParams.push(variant_id);
      whereConditions.push(`i.variant_id = $${queryParams.length}`);
    }

    if (product_id) {
      queryParams.push(product_id);
      whereConditions.push(`pv.product_id = $${queryParams.length}`);
    }

    // 🔎 NEW: filter by system_module with space ("stock in" / "stock out")
    if (stockType) {
      // allow "stock-in" / "stock_out" too, normalize to "stock in"
      const normalized = String(stockType)
        .toLowerCase()
        .replace(/[-_]+/g, " ")
        .trim();
      queryParams.push(normalized);
      whereConditions.push(`i.system_module = $${queryParams.length}`);
    }

    let from = created_at;
    let to = ToDate;

    if (created_at && ToDate && new Date(created_at) > new Date(ToDate)) {
      from = ToDate;
      to = created_at;
    }

    if (from && to) {
      queryParams.push(from);
      queryParams.push(to);
      whereConditions.push(
        `i.last_updated::date BETWEEN $${queryParams.length - 1} AND $${
          queryParams.length
        }`,
      );
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const productQuery = `
      SELECT 
        i.inventory_id,
        i.previous_quantity,
        i.adjust_quantity,
        i.new_quantity,
        i.last_updated,
        i.comment,
        i.system_module,
        i.variant_id,
        pv.product_id,
        m.measurement_value
      FROM inventory i
      INNER JOIN product_variants pv ON i.variant_id = pv.variant_id
      LEFT JOIN products p ON pv.product_id = p.product_id
      LEFT JOIN measurements m ON p.measurement_id = m.measurement_id
      ${whereClause}
      ORDER BY i.inventory_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(productQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM inventory i
      INNER JOIN product_variants pv ON i.variant_id = pv.variant_id
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      products: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching product list:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// update stock in/out route (inventory-only)
router.put("/update-stockinout", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { session_user_id, outlet_id, stock_type } = req.body;

    const isWastage =
      String(stock_type || "").toLowerCase() === "wastage" ||
      String(stock_type || "").toLowerCase() === "stock wastage";
    if (!outlet_id) {
      throw new Error("outlet_id is required for stock update");
    }

    //  Normalize input → always an array
    const items = Array.isArray(req.body.items) ? req.body.items : [req.body];

    if (!items.length) {
      throw new Error("No items provided for stock update");
    }

    // Auth context
    const { user_id, merchant_id } = req.user;

    // Admin log
    const parsed_session_user_id = parseInt(session_user_id, 10);
    if (!parsed_session_user_id) {
      throw new Error(
        "Session user ID is missing or invalid. Cannot insert admin log.",
      );
    }

    const totalVariants = items.length;

    const totalQty = items.reduce(
      (sum, i) => sum + Math.abs(Number(i.adjust_quantity || i.quantity || 0)),
      0,
    );

    const stockType = isWastage
      ? "stock wastage"
      : items.some((i) => Number(i.adjust_quantity) < 0)
        ? "stock out"
        : "stock in";

    const remark = isWastage
      ? `Bulk stock wastage | Variants: ${totalVariants} | Qty: ${totalQty}`
      : `Bulk ${stockType} | Variants: ${totalVariants} | Qty: ${totalQty}`;

    let sheet_id = null;
    let wastage_id = null;
    let wastage_no = null;

    /* =====================================================
   STOCK SHEET HEADER
   Always insert one header row for stock in / stock out / wastage
===================================================== */
    const headerRes = await client.query(
      `
  INSERT INTO stock_sheet_header (
    user_id,
    outlet_id,
    stock_type,
    remark
  ) VALUES ($1, $2, $3, $4)
  RETURNING sheet_id
  `,
      [user_id, outlet_id, stockType, remark],
    );

    sheet_id = headerRes.rows[0].sheet_id;

    /* =====================================================
   STOCK WASTAGE HEADER
   Only for wastage, linked to stock_sheet_header.sheet_id
===================================================== */
    if (isWastage) {
      const wastageHeaderRes = await client.query(
        `
    INSERT INTO stock_wastage_header (
      sheet_id,
      user_id,
      merchant_id,
      outlet_id,
      total_qty,
      item_count,
      remark,
      status
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, 'active')
    RETURNING wastage_id
    `,
        [
          sheet_id,
          user_id,
          merchant_id,
          outlet_id,
          totalQty,
          totalVariants,
          remark,
        ],
      );

      wastage_id = wastageHeaderRes.rows[0].wastage_id;
      wastage_no = `WST-${String(wastage_id).padStart(6, "0")}`;

      await client.query(
        `
    UPDATE stock_wastage_header
    SET wastage_no = $1,
        updated_at = NOW()
    WHERE wastage_id = $2
    `,
        [wastage_no, wastage_id],
      );
    }

    const results = [];

    for (const item of items) {
      const {
        variant_id,
        sku,
        barcode,
        continue_selling_oos,
        reorder_level,
        batch_number,
        note,
        adjust_quantity: rawAdjustQty,
      } = item;

      // Validate required
      if (!variant_id) {
        throw new Error("variant_id is required for each item");
      }

      // Parse adjust_quantity (optional)
      const rawStr =
        rawAdjustQty !== undefined && rawAdjustQty !== null
          ? String(rawAdjustQty).trim()
          : "";
      const hasAdjustQty = rawStr !== "";
      let adjust_quantity = hasAdjustQty ? Number(rawStr) : null;

      if (isWastage && hasAdjustQty) {
        adjust_quantity = -Math.abs(adjust_quantity);
      }
      if (
        hasAdjustQty &&
        (!Number.isFinite(adjust_quantity) ||
          !Number.isInteger(adjust_quantity))
      ) {
        throw new Error("adjust_quantity must be an integer when provided");
      }

      // Should we write to inventory? only if provided AND not zero
      const shouldWriteInventory = hasAdjustQty && adjust_quantity !== 0;

      // Ensure variant exists (and capture product_id for response/log)

      const variantCheck = await client.query(
        `SELECT variant_id, product_id, continue_selling_oos
   FROM product_variants
   WHERE variant_id = $1`,
        [variant_id],
      );
      if (variantCheck.rowCount === 0) {
        throw new Error(`Variant ID ${variant_id} not found`);
      }
      const { product_id, continue_selling_oos: current_continue_selling_oos } =
        variantCheck.rows[0];

      // if (shouldWriteInventory && batch_number) {
      //   // 🔎 Get LAST batch used for this product + variant
      //   const lastBatchRes = await client.query(
      //     `
      //     SELECT batch_number
      //     FROM batch_management
      //     WHERE product_id = $1
      //       AND variant_id = $2
      //     ORDER BY created_at DESC, batch_management_id DESC
      //     LIMIT 1
      //     `,
      //     [product_id, variant_id]
      //   );

      //   const lastBatchNumber = lastBatchRes.rows[0]?.batch_number || null;

      //   // ✅ Insert ONLY if batch has changed
      //   if (lastBatchNumber !== batch_number) {
      //     await client.query(
      //       `
      //   INSERT INTO batch_management (product_id, variant_id, batch_number)
      //   VALUES ($1, $2, $3)
      //   `,
      //       [product_id, variant_id, batch_number]
      //     );
      //   }
      // }

      // 🔎 Get user / outlet context (for audit)
      const userRes = await client.query(
        `SELECT username, first_name, last_name, role_id
   FROM users
   WHERE user_id = $1`,
        [user_id],
      );

      if (userRes.rowCount === 0) throw new Error("User not found");

      const { username, first_name, last_name, role_id } = userRes.rows[0];
      // Build display name for comment (no username in comment)
      const displayName =
        [first_name, last_name].filter(Boolean).join(" ").trim() ||
        "Unknown User";

      // Role + outlet
      const [roleRes, outletRes] = await Promise.all([
        client.query(`SELECT role_name FROM role_list WHERE id = $1`, [
          role_id,
        ]),
        client.query(`SELECT name FROM outlets WHERE outlet_id = $1`, [
          outlet_id,
        ]),
      ]);
      const role_name = roleRes.rows[0]?.role_name || "Unknown Role";
      const outlet_name = outletRes.rows[0]?.name || "Unknown Outlet";

      // system_module
      const system_module = shouldWriteInventory
        ? adjust_quantity > 0
          ? "stock in"
          : "stock out"
        : "no-change"; // keep inventory behavior same

      const adminLogModule = isWastage ? "stock wastage" : system_module;

      // Comment: "First Last | Role | v:<id> | stock in/out/no-change"
      const commentRaw = isWastage
        ? `${displayName} | ${role_name} | v:${variant_id} | stock wastage${note ? ` | ${note}` : ""}`
        : `${displayName} | ${role_name} | v:${variant_id} | ${system_module}`;
      // allow up to 250 chars since DB column supports it
      const comment =
        commentRaw.length > 250 ? commentRaw.slice(0, 250) : commentRaw;

      // Update product_variants fields if provided (and always touch updated_at)
      const parsedReorder =
        reorder_level === undefined || reorder_level === null
          ? null
          : Number(reorder_level);

      if (
        parsedReorder !== null &&
        (!Number.isFinite(parsedReorder) || parsedReorder < 0)
      ) {
        throw new Error(
          "reorder_level must be a non-negative number when provided",
        );
      }

      await client.query(
        `
      UPDATE product_variants
      SET
        sku = COALESCE($1, sku),
        barcode = COALESCE($2, barcode),
        continue_selling_oos = COALESCE($3, continue_selling_oos),
        reorder_level = COALESCE($4, reorder_level),
        updated_at = NOW()
      WHERE variant_id = $5
      `,
        [
          sku || null,
          barcode ?? null,
          continue_selling_oos ?? null,
          parsedReorder,
          variant_id,
        ],
      );

      let previous_quantity = null;
      let new_quantity = null;

      if (shouldWriteInventory) {
        // Get previous_quantity from latest inventory for SAME merchant/outlet/variant
        const prevQtyRes = await client.query(
          `
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = $1
          AND outlet_id = $2
          AND merchant_id = $3
          AND status = 'active'
        ORDER BY last_updated DESC NULLS LAST, inventory_id DESC
        LIMIT 1
        `,
          [variant_id, outlet_id, merchant_id],
        );

        previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity ?? 0);
        new_quantity = previous_quantity + adjust_quantity;

        // NEW RULE: allow negative only if PREVIOUS continue_selling_oos = true
        // --- RULE: decide using payload continue_selling_oos when provided; otherwise fallback to DB value ---
        const payloadContinueFlag =
          continue_selling_oos !== undefined && continue_selling_oos !== null
            ? Boolean(continue_selling_oos)
            : current_continue_selling_oos;

        // If the effective flag is false (do not allow OOS selling) and new qty would be negative → block
        if (!payloadContinueFlag && new_quantity < 0) {
          throw new Error(
            `Cannot reduce stock below zero. Current: ${previous_quantity}, Change: ${adjust_quantity}`,
          );
        }
        // if payloadContinueFlag === true => allow negative balances

        // else: continue_selling_oos = true → allow below zero

        // Insert inventory transaction
        await client.query(
          `
        INSERT INTO inventory (
          variant_id, outlet_id, merchant_id, user_id, batch_number,
          updated_by, comment, system_module,
          previous_quantity, adjust_quantity, new_quantity, status
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')
        `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            username, // keep username (typo fixed)
            comment,
            system_module, // 'stock in' | 'stock out' | 'no-change'
            previous_quantity,
            adjust_quantity,
            new_quantity,
          ],
        );

        // =====================================================
        //  STOCK SHEET DETAILS (ONE PER VARIANT)
        // =====================================================
        if (isWastage) {
          await client.query(
            `
    INSERT INTO stock_wastage_details (
      sheet_id,
      wastage_id,
      product_id,
      variant_id,
      outlet_id,
      batch_number,
      previous_qty,
      wastage_qty,
      current_qty,
      note
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    `,
            [
              sheet_id,
              wastage_id,
              product_id,
              variant_id,
              outlet_id,
              batch_number || null,
              previous_quantity,
              Math.abs(adjust_quantity),
              new_quantity,
              note || null,
            ],
          );
        } else {
          await client.query(
            `
    INSERT INTO stock_sheet_details (
      sheet_id,
      product_id,
      variant_id,
      previous_stock,
      current_stock,
      changed_qty,
      sku,
      batch_number,
      barcode
    ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    `,
            [
              sheet_id,
              product_id,
              variant_id,
              previous_quantity,
              new_quantity,
              adjust_quantity,
              sku || null,
              batch_number || null,
              barcode || null,
            ],
          );
        }
      }

      const logMessage = shouldWriteInventory
        ? isWastage
          ? `STOCK WASTAGE - Wastage No: ${wastage_no}, Variant ID: ${variant_id}, Wastage Qty: ${Math.abs(adjust_quantity)}, Previous Qty: ${previous_quantity}, New Qty: ${new_quantity}${note ? `, Note: ${note}` : ""}`
          : `${system_module.toUpperCase()} - Variant ID: ${variant_id}, Adjust Qty: ${adjust_quantity}, New Qty: ${new_quantity}`
        : `NO INVENTORY CHANGE - Variant ID: ${variant_id} (fields updated: ${
            [
              sku !== undefined ? "sku" : null,
              barcode !== undefined ? "barcode" : null,
              continue_selling_oos !== undefined
                ? "continue_selling_oos"
                : null,
              parsedReorder !== null ? "reorder_level" : null,
            ]
              .filter(Boolean)
              .join(", ") || "none"
          })`;

      await insertAdminLog(parsed_session_user_id, adminLogModule, logMessage);

      // Read back variant fields for response
      const updatedFieldsRes = await client.query(
        `SELECT sku, barcode, continue_selling_oos, reorder_level, updated_at
       FROM product_variants WHERE variant_id = $1`,
        [variant_id],
      );

      //  collect result for this item
      results.push({
        variant_id,
        inventory_written: shouldWriteInventory,
        previous_quantity,
        adjust_quantity,
        new_quantity,
        system_module,
        is_wastage: isWastage,
        wastage_id,
        wastage_no,
        sheet_id,
        note: note || null,
        displayName,
        role_name,
        outlet_name,
      });
    } //  THIS closes: for (const item of items)

    await client.query("COMMIT");
    for (const r of results) {
      try {
        const moduleName = "Inventory";

        if (r.inventory_written) {
          const eventType = r.is_wastage
            ? "Stock Wastage"
            : r.adjust_quantity > 0
              ? "Stock In"
              : "Stock Out";
          const notifMsg =
            `${r.is_wastage ? "Stock wastage recorded" : "Stock updated"} for variant id ${r.variant_id}, ` +
            `${r.system_module} | Δ ${r.adjust_quantity} ` +
            `(prev ${r.previous_quantity} → new ${r.new_quantity}) — ` +
            `by ${r.displayName} (${r.role_name} @ ${r.outlet_name}).`;

          await insertNotification(
            parsed_session_user_id,
            moduleName,
            eventType,
            notifMsg,
            "Admin Notification",
            "Unread",
          );
        }
      } catch (err) {
        console.error("Notification error:", err);
      }
    }

    res.json({
      message: isWastage
        ? "Stock wastage completed successfully"
        : "Bulk stock update completed successfully",
      wastage_id,
      wastage_no,
      count: results.length,
      results,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error updating stock:", error.message);
    res.status(500).json({ error: error.message });
  } finally {
    client.release();
  }
});

router.post("/csv-stock-update", authenticateToken, csvStockUpload.single("file"),
 async (req, res) => {
    const client = await pool.connect();

    let transactionStarted = false;
    let transactionCompleted = false;

    try {
      const {
        outlet_id,
        stock_type,
      } = req.body || {};

      const {
        user_id,
        merchant_id,
      } = req.user || {};

      // =====================================================
      // REQUEST VALIDATION
      // =====================================================

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "CSV file is required",
        });
      }

      const parsedOutletId =
        Number(outlet_id);

      if (
        !Number.isFinite(parsedOutletId) ||
        !Number.isInteger(parsedOutletId) ||
        parsedOutletId <= 0
      ) {
        return res.status(400).json({
          success: false,
          message:
            "A valid outlet_id is required",
        });
      }

      const normalizedStockType =
        String(stock_type || "")
          .trim()
          .toLowerCase();

      const isStockIn = [
        "in",
        "stock in",
        "stock_in",
      ].includes(normalizedStockType);

      const isStockOut = [
        "out",
        "stock out",
        "stock_out",
      ].includes(normalizedStockType);

      if (!isStockIn && !isStockOut) {
        return res.status(400).json({
          success: false,
          message:
            "stock_type must be either Stock In or Stock Out",
        });
      }



      // =====================================================
      // CSV PARSING
      // =====================================================

      let csvRows;

      try {
        const csvText = req.file.buffer
          .toString("utf8")
          .replace(/^\uFEFF/, "");

        csvRows = parse(csvText, {
          columns: (headers) =>
            headers.map((header) =>
              String(header || "")
                .trim()
                .toLowerCase(),
            ),

          skip_empty_lines: true,
          trim: true,
          relax_column_count: true,
        });
      } catch (parseError) {
        return res.status(400).json({
          success: false,
          message: `Invalid CSV file: ${parseError.message}`,
        });
      }

      if (
        !Array.isArray(csvRows) ||
        csvRows.length === 0
      ) {
        return res.status(400).json({
          success: false,
          message:
            "The CSV file contains no data rows",
        });
      }

      const firstRow =
        csvRows[0] || {};

      const missingColumns = [
        "variant_id",
        "stock_quantity",
      ].filter(
        (columnName) =>
          !Object.prototype.hasOwnProperty.call(
            firstRow,
            columnName,
          ),
      );

      if (missingColumns.length > 0) {
        return res.status(400).json({
          success: false,
          message:
            `Missing required CSV column(s): ` +
            missingColumns.join(", "),
        });
      }

      // =====================================================
      // HELPERS
      // =====================================================

      const createIdValidationError = (
        message,
        errorType = "invalid_variant",
      ) => {
        const error =
          new Error(message);

        error.code =
          "PRODUCT_VARIANT_NOT_EXISTING";

        error.error_type =
          errorType;

        return error;
      };

      const createBatchValidationError = (
        message,
        errorType = "invalid_batch",
      ) => {
        const error =
          new Error(message);

        error.code =
          "BATCH_VALIDATION_FAILED";

        error.error_type =
          errorType;

        return error;
      };

      const parseRequiredId = (
        rawValue,
        fieldName,
      ) => {
        const normalizedValue =
          String(rawValue ?? "").trim();

        if (!normalizedValue) {
          throw createIdValidationError(
            `${fieldName} is required.`,
            `missing_${fieldName}`,
          );
        }

        const parsedValue =
          Number(normalizedValue);

        if (
          !Number.isFinite(parsedValue) ||
          !Number.isInteger(parsedValue) ||
          parsedValue <= 0
        ) {
          throw createIdValidationError(
            `${fieldName} must be a valid positive integer.`,
            `invalid_${fieldName}`,
          );
        }

        return parsedValue;
      };

      const parseRequiredPositiveInteger = (
        rawValue,
        fieldName,
      ) => {
        const normalizedValue =
          String(rawValue ?? "").trim();

        if (!normalizedValue) {
          throw new Error(
            `${fieldName} is required`,
          );
        }

        const parsedValue =
          Number(normalizedValue);

        if (
          !Number.isFinite(parsedValue) ||
          !Number.isInteger(parsedValue) ||
          parsedValue <= 0
        ) {
          throw new Error(
            `${fieldName} must be a positive integer`,
          );
        }

        return parsedValue;
      };

      const parseOptionalBoolean = (
        rawValue,
        fieldName,
      ) => {
        if (
          rawValue === undefined ||
          rawValue === null ||
          String(rawValue).trim() === ""
        ) {
          return null;
        }

        const normalizedValue =
          String(rawValue)
            .trim()
            .toLowerCase();

        if (
          [
            "true",
            "1",
            "yes",
            "y",
          ].includes(normalizedValue)
        ) {
          return true;
        }

        if (
          [
            "false",
            "0",
            "no",
            "n",
          ].includes(normalizedValue)
        ) {
          return false;
        }

        throw new Error(
          `${fieldName} must be true or false`,
        );
      };

      const parseOptionalNonNegativeNumber = (
        rawValue,
        fieldName,
      ) => {
        const normalizedValue =
          String(rawValue ?? "").trim();

        if (!normalizedValue) {
          return null;
        }

        const parsedValue =
          Number(normalizedValue);

        if (
          !Number.isFinite(parsedValue) ||
          parsedValue < 0
        ) {
          throw new Error(
            `${fieldName} must be a non-negative number`,
          );
        }

        return parsedValue;
      };

      const getRejectedRowData = (
        row,
        csvRowNumber,
        reason,
      ) => ({
        row_number: csvRowNumber,

        variant_id:
          String(
            row.variant_id ?? "",
          ).trim() || null,

        batch_number:
          String(
            row.batch_number ?? "",
          ).trim() || null,

        stock_quantity:
          String(
            row.stock_quantity ?? "",
          ).trim() || null,

        continue_selling:
          String(
            row.continue_selling ?? "",
          ).trim() || null,

        reorder_level:
          String(
            row.reorder_level ?? "",
          ).trim() || null,

        reason:
          reason ||
          "Unable to process this row",
      });

      // =====================================================
      // USER, ROLE AND OUTLET CONTEXT
      // =====================================================

      const userResult =
        await client.query(
          `
            SELECT
              username,
              first_name,
              last_name,
              role_id
            FROM users
            WHERE user_id = $1
          `,
          [user_id],
        );

      if (
        userResult.rowCount === 0
      ) {
        return res.status(404).json({
          success: false,
          message:
            "Authenticated user was not found",
        });
      }

      const {
        username,
        first_name,
        last_name,
        role_id,
      } = userResult.rows[0];

      const [
        roleResult,
        outletResult,
      ] = await Promise.all([
        client.query(
          `
            SELECT role_name
            FROM role_list
            WHERE id = $1
          `,
          [role_id],
        ),

        client.query(
          `
            SELECT name
            FROM outlets
            WHERE outlet_id = $1
          `,
          [parsedOutletId],
        ),
      ]);

      if (
        outletResult.rowCount === 0
      ) {
        return res.status(404).json({
          success: false,
          message:
            "Selected outlet was not found",
        });
      }

      const displayName =
        [first_name, last_name]
          .filter(Boolean)
          .join(" ")
          .trim() ||
        "Unknown User";

      const roleName =
        roleResult.rows[0]
          ?.role_name ||
        "Unknown Role";

      const outletName =
        outletResult.rows[0]?.name ||
        "Unknown Outlet";

      const systemModule =
        isStockIn
          ? "stock in"
          : "stock out";

      const stockMethod =
        "CSV Upload";

      const stockSheetRemark =
        isStockIn
          ? "Stock In"
          : "Stock Out";

      // =====================================================
      // RESULT COLLECTIONS
      // =====================================================

      const successfulRows = [];

      const notExistingRows = [];

      const failedRows = [];

      const pendingAdminLogs = [];

      const pendingNotifications = [];

      /*
       * Keeps one stock-sheet header per batch.
       *
       * Example:
       * BATCH-001 -> sheet_id 10
       * BATCH-002 -> sheet_id 11
       * NO_BATCH  -> sheet_id 12
       */
      const stockSheetByBatch =
        new Map();

      // =====================================================
      // PROCESS CSV ROWS
      // =====================================================

      await client.query("BEGIN");

      transactionStarted = true;

      for (
        let rowIndex = 0;
        rowIndex < csvRows.length;
        rowIndex += 1
      ) {
        const row =
          csvRows[rowIndex] || {};

        const csvRowNumber =
          rowIndex + 2;

        const savepointName =
          `csv_stock_row_${rowIndex + 1}`;

        await client.query(
          `SAVEPOINT ${savepointName}`,
        );

        try {
          // =================================================
          // REQUIRED VALUES
          // =================================================

          const variantId =
            parseRequiredId(
              row.variant_id,
              "variant_id",
            );

          const stockQuantity =
            parseRequiredPositiveInteger(
              row.stock_quantity,
              "stock_quantity",
            );

          const adjustQuantity =
            isStockOut
              ? -Math.abs(
                  stockQuantity,
                )
              : Math.abs(
                  stockQuantity,
                );

          const batchNumber =
            String(
              row.batch_number ?? "",
            ).trim() || null;

          const continueSelling =
            parseOptionalBoolean(
              row.continue_selling,
              "continue_selling",
            );

          const reorderLevel =
            parseOptionalNonNegativeNumber(
              row.reorder_level,
              "reorder_level",
            );

          // =================================================
          // VARIANT VALIDATION
          // =================================================

          const variantResult =
            await client.query(
              `
                SELECT
                  pv.variant_id,
                  pv.product_id,
                  pv.sku,
                  pv.barcode,
                  pv.continue_selling_oos,
                  p.title AS product_title
                FROM product_variants pv
                LEFT JOIN products p
                  ON p.product_id =
                     pv.product_id
                WHERE pv.variant_id = $1
              `,
              [variantId],
            );

          if (
            variantResult.rowCount === 0
          ) {
            throw createIdValidationError(
              `Variant ID ${variantId} does not exist in the system.`,
              "variant_not_found",
            );
          }

          const variantRecord =
            variantResult.rows[0];

          const productId =
            Number(
              variantRecord.product_id,
            );

          const productTitle =
            variantRecord
              .product_title || "";

          const variantSku =
            variantRecord.sku || null;

          const variantBarcode =
            variantRecord.barcode ||
            null;

          const currentContinueSelling =
            Boolean(
              variantRecord
                .continue_selling_oos,
            );

          // =================================================
          // BATCH VALIDATION
          // =================================================

          if (batchNumber) {
            const batchResult =
              await client.query(
                `
                  SELECT
                    product_id,
                    variant_id,
                    batch_number,
                    status
                  FROM batch_management
                  WHERE batch_number = $1
                  LIMIT 1
                `,
                [batchNumber],
              );

            if (
              batchResult.rowCount === 0
            ) {
              throw createBatchValidationError(
                `Batch number ${batchNumber} does not exist in batch management.`,
                "batch_not_found",
              );
            }

            const batchRecord =
              batchResult.rows[0];

            const batchVariantId =
              Number(
                batchRecord.variant_id,
              );

            const batchProductId =
              Number(
                batchRecord.product_id,
              );

            if (
              batchVariantId !==
              variantId
            ) {
              throw createBatchValidationError(
                `Batch number ${batchNumber} belongs to Variant ID ${batchVariantId}, not Variant ID ${variantId}.`,
                "batch_variant_mismatch",
              );
            }

            if (
              batchProductId !==
              productId
            ) {
              throw createBatchValidationError(
                `Batch number ${batchNumber} does not belong to Product ID ${productId}.`,
                "batch_product_mismatch",
              );
            }

            const batchStatus =
              String(
                batchRecord.status ||
                  "",
              )
                .trim()
                .toLowerCase();

            if (
              batchStatus !== "active"
            ) {
              throw createBatchValidationError(
                `Batch number ${batchNumber} is not active.`,
                "batch_inactive",
              );
            }
          }

          // =================================================
          // CURRENT STOCK
          // =================================================

          const previousQuantityResult =
            await client.query(
              `
                SELECT new_quantity
                FROM inventory
                WHERE variant_id = $1
                  AND outlet_id = $2
                  AND merchant_id = $3
                  AND status = 'active'
                ORDER BY
                  last_updated
                    DESC NULLS LAST,
                  inventory_id DESC
                LIMIT 1
              `,
              [
                variantId,
                parsedOutletId,
                merchant_id,
              ],
            );

          const previousQuantity =
            Number(
              previousQuantityResult
                .rows[0]
                ?.new_quantity ?? 0,
            );

          const newQuantity =
            previousQuantity +
            adjustQuantity;

          const effectiveContinueSelling =
            continueSelling !== null
              ? continueSelling
              : currentContinueSelling;

          if (
            !effectiveContinueSelling &&
            newQuantity < 0
          ) {
            throw new Error(
              `Cannot reduce stock below zero. Current quantity: ${previousQuantity}, requested stock out: ${stockQuantity}`,
            );
          }

          // =================================================
          // UPDATE VARIANT SETTINGS
          // =================================================

          await client.query(
            `
              UPDATE product_variants
              SET
                continue_selling_oos =
                  COALESCE(
                    $1,
                    continue_selling_oos
                  ),

                reorder_level =
                  COALESCE(
                    $2,
                    reorder_level
                  ),

                updated_at = NOW()

              WHERE variant_id = $3
            `,
            [
              continueSelling,
              reorderLevel,
              variantId,
            ],
          );

          // =================================================
          // STOCK SHEET HEADER
          // One header per batch.
          // =================================================

          const batchSheetKey =
            batchNumber ||
            "__NO_BATCH__";

          let sheetSummary =
            stockSheetByBatch.get(
              batchSheetKey,
            );

          let sheetId =
            sheetSummary?.sheet_id;

          let createdNewSheet =
            false;

          if (!sheetId) {
            const headerResult =
              await client.query(
                `
                  INSERT INTO
                    stock_sheet_header (
                      user_id,
                      outlet_id,
                      stock_type,
                      stock_method,
                      remark
                    )
                  VALUES (
                    $1,
                    $2,
                    $3,
                    $4,
                    $5
                  )
                  RETURNING sheet_id
                `,
                [
                  user_id,
                  parsedOutletId,
                  systemModule,
                  stockMethod,
                  `${stockSheetRemark} | Variant Count: 0 | Total Quantity: 0`,
                ],
              );

            sheetId =
              headerResult.rows[0]
                .sheet_id;

            createdNewSheet = true;
          }

          // =================================================
          // INVENTORY TRANSACTION
          // =================================================

          const commentRaw =
            `${displayName} | ` +
            `${roleName} | ` +
            `p:${productId} | ` +
            `v:${variantId} | ` +
            `${systemModule} | ` +
            `CSV upload`;

          const comment =
            commentRaw.length > 250
              ? commentRaw.slice(
                  0,
                  250,
                )
              : commentRaw;

          await client.query(
            `
              INSERT INTO inventory (
                variant_id,
                outlet_id,
                merchant_id,
                user_id,
                batch_number,
                updated_by,
                comment,
                system_module,
                previous_quantity,
                adjust_quantity,
                new_quantity,
                status
              )
              VALUES (
                $1,
                $2,
                $3,
                $4,
                $5,
                $6,
                $7,
                $8,
                $9,
                $10,
                $11,
                'active'
              )
            `,
            [
              variantId,
              parsedOutletId,
              merchant_id,
              user_id,
              batchNumber,
              username,
              comment,
              systemModule,
              previousQuantity,
              adjustQuantity,
              newQuantity,
            ],
          );

          // =================================================
          // STOCK SHEET DETAILS
          // Linked to the correct batch-wise sheet.
          // =================================================

          await client.query(
            `
              INSERT INTO
                stock_sheet_details (
                  sheet_id,
                  product_id,
                  variant_id,
                  previous_stock,
                  current_stock,
                  changed_qty,
                  sku,
                  batch_number,
                  barcode
                )
              VALUES (
                $1,
                $2,
                $3,
                $4,
                $5,
                $6,
                $7,
                $8,
                $9
              )
            `,
            [
              sheetId,
              productId,
              variantId,
              previousQuantity,
              newQuantity,
              adjustQuantity,
              variantSku,
              batchNumber,
              variantBarcode,
            ],
          );

          // =================================================
          // UPDATE STOCK SHEET SUMMARY
          // Remark contains unique variant count and total qty.
          // =================================================

          const currentVariantIds =
            new Set(
              sheetSummary?.variant_ids ||
                [],
            );

          currentVariantIds.add(
            variantId,
          );

          const updatedSheetSummary = {
            sheet_id:
              sheetId,

            variant_ids:
              Array.from(
                currentVariantIds,
              ),

            variant_count:
              currentVariantIds.size,

            total_quantity:
              Number(
                sheetSummary
                  ?.total_quantity || 0,
              ) +
              Math.abs(
                stockQuantity,
              ),
          };

          const updatedSheetRemark =
            `${stockSheetRemark} | ` +
            `Variant Count: ${updatedSheetSummary.variant_count} | ` +
            `Total Quantity: ${updatedSheetSummary.total_quantity}`;

          await client.query(
            `
              UPDATE stock_sheet_header
              SET
                stock_method = $1,
                remark = $2
              WHERE sheet_id = $3
            `,
            [
              stockMethod,
              updatedSheetRemark,
              sheetId,
            ],
          );

          // =================================================
          // LOG AND NOTIFICATION DATA
          // =================================================

          const logMessage =
            `${systemModule.toUpperCase()} CSV - ` +
            `Sheet ID: ${sheetId}, ` +
            `Product ID: ${productId}, ` +
            `Variant ID: ${variantId}, ` +
            `Batch: ${batchNumber || "N/A"}, ` +
            `Adjust Qty: ${adjustQuantity}, ` +
            `Previous Qty: ${previousQuantity}, ` +
            `New Qty: ${newQuantity}, ` +
            `Outlet: ${outletName}`;

          pendingAdminLogs.push({
            module: systemModule,
            message: logMessage,
          });

          const notificationMessage =
            `Stock updated through CSV for ` +
            `product id ${productId}, ` +
            `variant id ${variantId}, ` +
            `batch ${batchNumber || "N/A"}, ` +
            `${systemModule} | ` +
            `Δ ${adjustQuantity} ` +
            `(prev ${previousQuantity} → ` +
            `new ${newQuantity}) — ` +
            `by ${displayName} ` +
            `(${roleName} @ ${outletName}).`;

          pendingNotifications.push({
            eventType:
              isStockIn
                ? "Stock In"
                : "Stock Out",

            message:
              notificationMessage,
          });

          successfulRows.push({
            row_number:
              csvRowNumber,

            sheet_id:
              sheetId,

            product_id:
              productId,

            product_title:
              productTitle,

            variant_id:
              variantId,

            batch_number:
              batchNumber,

            stock_quantity:
              stockQuantity,

            adjust_quantity:
              adjustQuantity,

            previous_quantity:
              previousQuantity,

            new_quantity:
              newQuantity,

            continue_selling:
              effectiveContinueSelling,

            reorder_level:
              reorderLevel,
          });

          await client.query(
            `RELEASE SAVEPOINT ${savepointName}`,
          );

          /*
           * Only save the sheet in the map after
           * the complete row succeeds.
           *
           * This prevents storing a sheet_id that
           * was rolled back by the savepoint.
           */
          stockSheetByBatch.set(
            batchSheetKey,
            updatedSheetSummary,
          );
        } catch (rowError) {
          await client.query(
            `ROLLBACK TO SAVEPOINT ${savepointName}`,
          );

          await client.query(
            `RELEASE SAVEPOINT ${savepointName}`,
          );

          const rejectedRow =
            getRejectedRowData(
              row,
              csvRowNumber,
              rowError.message,
            );

          if (
            rowError.code ===
            "PRODUCT_VARIANT_NOT_EXISTING"
          ) {
            notExistingRows.push({
              ...rejectedRow,

              error_type:
                rowError.error_type ||
                "invalid_variant",

              category:
                "PRODUCT_OR_VARIANT_NOT_EXISTING",
            });
          } else if (
            rowError.code ===
            "BATCH_VALIDATION_FAILED"
          ) {
            failedRows.push({
              ...rejectedRow,

              error_type:
                rowError.error_type ||
                "invalid_batch",

              category:
                "BATCH_VALIDATION_FAILED",
            });
          } else {
            failedRows.push({
              ...rejectedRow,

              error_type:
                "FAILED_TO_UPDATE",

              category:
                "STOCK_UPDATE_FAILED",
            });
          }
        }
      }

      await client.query("COMMIT");

      transactionCompleted = true;

      // =====================================================
      // ADMIN LOGS
      // =====================================================

      for (
        const logEntry of
        pendingAdminLogs
      ) {
        try {
          await insertAdminLog(
            user_id,
            logEntry.module,
            logEntry.message,
          );
        } catch (logError) {
          console.error(
            "CSV stock admin log error:",
            logError,
          );
        }
      }

      // =====================================================
      // NOTIFICATIONS
      // =====================================================

      for (
        const notification of
        pendingNotifications
      ) {
        try {
          await insertNotification(
            user_id,
            "Inventory",
            notification.eventType,
            notification.message,
            "Admin Notification",
            "Unread",
          );
        } catch (
          notificationError
        ) {
          console.error(
            "CSV stock notification error:",
            notificationError,
          );
        }
      }

      // =====================================================
      // FINAL COUNTS
      // =====================================================

      const totalRows =
        csvRows.length;

      const successfulRowsCount =
        successfulRows.length;

      const notExistingRowsCount =
        notExistingRows.length;

      const failedRowsCount =
        failedRows.length;

      const batchFailedRowsCount =
        failedRows.filter(
          (row) =>
            row.category ===
            "BATCH_VALIDATION_FAILED",
        ).length;

      const stockFailedRowsCount =
        failedRowsCount -
        batchFailedRowsCount;

      const rejectedRowsCount =
        notExistingRowsCount +
        failedRowsCount;

      const stockSheetHeaders =
        Array.from(
          stockSheetByBatch.entries(),
        ).map(
          ([
            batchKey,
            sheetSummary,
          ]) => ({
            sheet_id:
              sheetSummary.sheet_id,

            batch_number:
              batchKey ===
              "__NO_BATCH__"
                ? null
                : batchKey,

            stock_type:
              systemModule,

            stock_method:
              stockMethod,

            variant_count:
              sheetSummary.variant_count,

            total_quantity:
              sheetSummary.total_quantity,

            remark:
              `${stockSheetRemark} | ` +
              `Variant Count: ${sheetSummary.variant_count} | ` +
              `Total Quantity: ${sheetSummary.total_quantity}`,
          }),
        );

      // =====================================================
      // RESPONSE
      // =====================================================

      return res.status(200).json({
        success:
          rejectedRowsCount === 0,

        message:
          rejectedRowsCount === 0
            ? `All ${successfulRowsCount} stock row(s) were updated successfully`
            : `${successfulRowsCount} row(s) updated, ${notExistingRowsCount} row(s) contained missing, invalid, or non-existing variant IDs, ${batchFailedRowsCount} row(s) failed batch validation, and ${stockFailedRowsCount} row(s) failed to update`,

        stock_type:
          systemModule,

        stock_method:
          stockMethod,

        stock_sheet_remark:
          stockSheetRemark,

        outlet_id:
          parsedOutletId,

        outlet_name:
          outletName,

        total_rows:
          totalRows,

        successful_rows:
          successfulRowsCount,

        not_existing_rows_count:
          notExistingRowsCount,

        batch_failed_rows_count:
          batchFailedRowsCount,

        stock_failed_rows_count:
          stockFailedRowsCount,

        failed_rows_count:
          failedRowsCount,

        rejected_rows_count:
          rejectedRowsCount,

        stock_sheet_updated:
          successfulRowsCount > 0,

        stock_sheet_count:
          stockSheetHeaders.length,

        stock_sheet_headers:
          stockSheetHeaders,

        not_existing_rows:
          notExistingRows,

        failed_rows:
          failedRows,

        results:
          successfulRows,
      });
    } catch (error) {
      if (
        transactionStarted &&
        !transactionCompleted
      ) {
        try {
          await client.query(
            "ROLLBACK",
          );
        } catch (
          rollbackError
        ) {
          console.error(
            "CSV stock rollback error:",
            rollbackError,
          );
        }
      }

      console.error(
        "CSV stock update error:",
        error,
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Failed to process CSV stock update",
      });
    } finally {
      client.release();
    }
  },
);



// update outlets
// PUT /outlets/:outlet_id

router.put("/update-outlet/:outlet_id", authenticateToken, async (req, res) => {
  const outletId = Number(req.params.outlet_id);
  const merchantId = Number(req.user?.merchant_id); // ← only from token

  if (!Number.isInteger(outletId)) {
    return res.status(400).json({ message: "Invalid outlet_id" });
  }
  if (!Number.isInteger(merchantId)) {
    // token present but no merchant_id inside
    return res
      .status(401)
      .json({ message: "Unauthorized: merchant_id missing in token" });
  }

  // Whitelist of updatable columns
  const UPDATABLE_FIELDS = new Set([
    "product_id",
    "name",
    "address",
    "geocode",
    "hotline",
    "email",
    "opening_hours_from",
    "opening_hours_to",
    "tel_number",
    "is_active",
  ]);

  // Normalizers
  const norm = (v) => {
    if (v === undefined) return undefined;
    if (v === null) return null;
    if (typeof v === "string") {
      const t = v.trim();
      return t === "" ? null : t;
    }
    return v;
  };
  const normTime = (v) => {
    if (v === undefined || v === null) return v;
    const m = String(v)
      .trim()
      .match(/^(\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (!m) return v; // let DB validate
    const [_, hh, mm, ss = "00"] = m;
    return `${hh}:${mm}:${ss}`;
  };

  // Build sanitized payload
  const raw = req.body || {};
  const payload = {};
  for (const key of Object.keys(raw)) {
    if (!UPDATABLE_FIELDS.has(key)) continue;
    payload[key] =
      key === "opening_hours_from" || key === "opening_hours_to"
        ? normTime(raw[key])
        : norm(raw[key]);
  }

  if (Object.keys(payload).length === 0) {
    return res.status(400).json({ message: "No updatable fields provided" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Lock row
    const { rows } = await client.query(
      `SELECT * FROM outlets WHERE outlet_id = $1 AND merchant_id = $2 FOR UPDATE`,
      [outletId, merchantId],
    );
    if (rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Outlet not found" });
    }
    const current = rows[0];

    // Diffs
    const setClauses = [];
    const values = [];
    const changedFields = {};
    const unchangedFields = [];

    for (const [key, desiredRaw] of Object.entries(payload)) {
      const desired =
        key === "is_active"
          ? desiredRaw === true || desiredRaw === "true"
          : desiredRaw;

      const currentVal =
        key === "opening_hours_from" || key === "opening_hours_to"
          ? current[key]
            ? String(current[key])
            : current[key]
          : current[key];

      const same =
        (desired === null && currentVal === null) ||
        desired === currentVal ||
        (typeof desired === "string" &&
          typeof currentVal === "string" &&
          desired.trim() === currentVal.trim());

      if (!same) {
        setClauses.push(`${key} = $${values.length + 1}`);
        values.push(desired);
        changedFields[key] = { from: currentVal, to: desired };
      } else {
        unchangedFields.push(key);
      }
    }

    if (setClauses.length === 0) {
      await client.query("ROLLBACK");
      return res.status(200).json({
        message: "No changes detected",
        outlet: current,
        changed_fields: {},
        unchanged_fields: unchangedFields,
      });
    }

    setClauses.push(`updated_at = NOW()`);

    const sql = `
      UPDATE outlets
      SET ${setClauses.join(", ")}
      WHERE outlet_id = $${values.length + 1} AND merchant_id = $${
        values.length + 2
      }
      RETURNING *;
    `;
    values.push(outletId, merchantId);

    const updated = await client.query(sql, values);
    await client.query("COMMIT");

    return res.status(200).json({
      message: "Outlet updated successfully",
      outlet: updated.rows[0],
      changed_fields: changedFields,
      unchanged_fields: unchangedFields,
    });
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch (_) {}
    console.error("Update outlet failed:", err);
    return res
      .status(500)
      .json({ message: "Internal server error", error: err.message });
  } finally {
    client.release();
  }
});

// GET /inventory-sub/fetch-outlets
router.get("/fetch-outlets", authenticateToken, async (req, res) => {
  try {
    const { user_id } = req.user;

    const userRes = await pool.query(
      `
      SELECT outlet_id
      FROM users
      WHERE user_id = $1
      LIMIT 1
      `,
      [user_id],
    );

    const default_outlet = userRes.rows[0]?.outlet_id || null;

    const { rows } = await pool.query(
      `
      SELECT outlet_id, name
      FROM outlets
      WHERE is_active = true
      ORDER BY name ASC
      `,
    );

    res.json({
      success: true,
      default_outlet,
      results: rows,
    });
  } catch (err) {
    console.error("Failed to fetch outlets:", err);
    res.status(500).json({
      success: false,
      error: "Failed to fetch outlets",
    });
  }
});

// batch wise inventory fetch
// GET /inventory/variant-batch-stock
router.get("/batch-inventory-fetch", authenticateToken, async (req, res) => {
  const { variant_id, outlet_id, batch_number } = req.query;
  const { merchant_id } = req.user;

  if (!variant_id || !outlet_id) {
    return res.status(400).json({
      message: "variant_id and outlet_id are required",
    });
  }

  const selectedBatch =
    typeof batch_number === "string" && batch_number.trim() !== ""
      ? batch_number.trim()
      : null;

  try {
    const stockQuery = `
        SELECT
          $1::int AS variant_id,
          $2::int AS outlet_id,
          $3::text AS batch_number,
          COALESCE(SUM(i.adjust_quantity), 0) AS current_stock,
          MAX(i.last_updated) AS last_updated
        FROM inventory i
        WHERE i.variant_id = $1
          AND i.outlet_id = $2
          AND i.merchant_id = $4
          AND i.status = 'active'
          AND (
            $3::text IS NULL
            OR i.batch_number = $3
          )
      `;

    const result = await pool.query(stockQuery, [
      variant_id,
      outlet_id,
      selectedBatch,
      merchant_id,
    ]);

    return res.json({
      variant_id: Number(variant_id),
      outlet_id: Number(outlet_id),
      batch_number: selectedBatch,
      current_stock: Number(result.rows[0].current_stock),
      last_updated: result.rows[0].last_updated,
    });
  } catch (err) {
    console.error("Error fetching variant batch stock:", err.message);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

module.exports = router;
