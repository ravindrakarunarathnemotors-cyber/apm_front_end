const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const bcrypt = require("bcrypt");
const router = express.Router();

router.post("/getalllogs", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      id,
      logname,
      description,
      log_at,
      
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

       let queryParams = [];
    let whereConditions = [];

     if (id) {
      queryParams.push(id);
      whereConditions.push(`id = $${queryParams.length}`);
    }
      if (description) {
     queryParams.push(`%${description}%`);
     whereConditions.push(`log ILIKE $${queryParams.length}`);
    }

    if (logname) {
      queryParams.push(`%${logname}%`);
      whereConditions.push(`title ILIKE $${queryParams.length}`);
    }
    if (log_at) {
      queryParams.push(log_at);
      whereConditions.push(`date::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length ? `WHERE ${whereConditions.join(" AND ")}` : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM logs
      ${whereClause}
      ORDER BY date DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM logs
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/adminall", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT title,id FROM logs WHERE title ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


// router.post("/getuser", authenticateToken, async (req, res) => {
//   try {
//     const { user_id } = req.body;

//     if (!user_id) {
//       return res.status(400).json({ error: "user_id is required" });
//     }

//     const query = `
//       SELECT user_id, first_name, last_name, username, mobile, status, email, picture
//       FROM users
//       WHERE user_id = $1
//     `;

//     const result = await pool.query(query, [user_id]);

//     if (result.rows.length === 0) {
//       return res.status(404).json({ error: "User not found" });
//     }

//     res.json({ user: result.rows[0] });
//   } catch (error) {
//     console.error("Error fetching user:", error);
//     res.status(500).json({ error: "Internal server error" });
//   }
// });


router.post("/getuser", authenticateToken, async (req, res) => {
  try {
    const { user_id } = req.body;

    if (!user_id) {
      return res.status(400).json({ error: "user_id is required" });
    }

    const query = `
      SELECT 
        u.user_id, 
        u.first_name, 
        u.last_name, 
        u.username, 
        u.mobile, 
        u.status, 
        u.email, 
        u.picture,
        r.role_name,
        o.name AS outlet_name
      FROM users u
      JOIN role_list r ON u.role_id = r.id
      LEFT JOIN outlets o ON u.outlet_id = o.outlet_id
      WHERE u.user_id = $1
    `;

    const result = await pool.query(query, [user_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});




router.post("/updateuser", authenticateToken, async (req, res) => {
  try {
    const {
      first_name,
      last_name,
      email,
      mobile,
      picture,   
      password   
    } = req.body || {};

    const user = req.user
  const user_id = user.user_id

   
    
    
    if (!user_id) {
      return res.status(400).json({ error: "user_id is required" });
    }
    

    const sets = [
      `first_name = $1`,
      `last_name = $2`,
      `email = $3`,
      `mobile = $4`,
      `picture = $5`,
      `updated_at = NOW()`
    ];
    const values = [
      String(first_name).trim(),
      String(last_name).trim(),
      String(email).trim(),
      (mobile ?? "").toString().trim(),
      picture ?? null
    ];

    if (password && String(password).trim().length > 0) {
      const hash = await bcrypt.hash(String(password).trim(), 10);
      sets.push(`password = $${values.length + 1}`); 
      values.push(hash);
    }

    values.push(user_id); 

    const query = `
      UPDATE users
         SET ${sets.join(", ")}
       WHERE user_id = $${values.length}
       RETURNING user_id, first_name, last_name, username, mobile, status, email, picture
    `;

    const result = await pool.query(query, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


module.exports = router;