const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const { insertAdminLog } = require("../models/userLogs");
const { allCountry } = require("../controllers/commonController");
const {
  sendsmstemp,
  sendemailtemp,
  customhook,
} = require("../models/smsnotificationmodel");

const router = express.Router();

// PUT /system/settings - Update system settings
// put these helpers ABOVE router.put
const intervalStrToMinutes = (s) => {
  if (!s) return 0;
  const parts = String(s).split(":").map(Number);
  if (parts.length === 3) {
    const [h, m, sec] = parts;
    return (h || 0) * 60 + (m || 0) + Math.floor((sec || 0) / 60);
  }
  if (parts.length === 2) {
    const [m, sec] = parts;
    return (m || 0) + Math.floor((sec || 0) / 60);
  }
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
};

const normalizeIncomingMinutes = (raw) => {
  if (raw && typeof raw === "object" && raw.minutes != null)
    return Number(raw.minutes) || 0;
  return Number(raw) || 0;
};

// NEW: normalize any incoming "terms_conditions" into a JSON string (array) for jsonb
const normalizeTermsJson = (raw) => {
  if (raw == null) return JSON.stringify([]);
  // already an array from UI
  if (Array.isArray(raw)) {
    return JSON.stringify(raw.map((s) => String(s).trim()).filter(Boolean));
  }
  if (typeof raw === "string") {
    // try JSON first
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return JSON.stringify(
          parsed.map((s) => String(s).trim()).filter(Boolean)
        );
      }
    } catch {
      // fall through to newline split
    }
    // treat as newline-separated points
    return JSON.stringify(
      raw
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean)
    );
  }
  // any other type -> wrap as single element
  return JSON.stringify([String(raw)]);
};

// (optional) stable compare
const equalish = (a, b) => {
  if (a == null && b == null) return true;
  const norm = (x) =>
    typeof x === "object" && x !== null ? JSON.stringify(x) : String(x);
  return norm(a) === norm(b);
};

// router.put("/settings", authenticateToken, async (req, res) => {
//   try {
//     const id = 1;
//     const incoming = req.body;

//     const allowed = new Set([
//       "default_timezone",
//       "date_format",
//       "currency",
//       "auto_logout_time",
//       "sms_gateway_name",
//       "default_country",
//       "sms_user_id",
//       "sms_sender_id",
//       "sms_api_endpoint",
//       "sms_api_key",
//       "sms_notification_status",
//       "billing_email",
//       "system_email",
//       "support_email",
//       "email_notification_status",
//       "postmark_server_token",
//       "smtp_host",
//       "smtp_port",
//       "smtp_username",
//       "smtp_password",
//       "smtp_encryption",
//       "new_client_sms_status",
//       "new_client_email_status",
//       "new_client_activation_sms_status",
//       "new_client_activation_email_status",
//       "backoffice_maintenance_status",
//       "backoffice_maintenance_msg",
//       "webstore_maintenance_status",
//       "webstore_maintenance_msg",
//       "pos_maintenance_status",
//       "pos_maintenance_msg",
//       "full_maintenance_status",
//       "full_maintenance_msg",
//       "terms_conditions",
//       "terms_conditions_quotations", // jsonb
//     ]);

//     const currentRes = await pool.query(
//       "SELECT * FROM system_settings WHERE id = $1 LIMIT 1",
//       [id]
//     );
//     if (currentRes.rowCount === 0) {
//       return res
//         .status(404)
//         .json({ success: false, message: "Settings row not found" });
//     }

//     const current = currentRes.rows[0];

//     const payload = Object.fromEntries(
//       Object.entries(incoming).filter(
//         ([k, v]) => allowed.has(k) && v !== undefined
//       )
//     );



//     // auto-logout normalize
//     let incomingMinutes = null;
//     if (Object.prototype.hasOwnProperty.call(payload, "auto_logout_time")) {
//       incomingMinutes = normalizeIncomingMinutes(payload.auto_logout_time);
//     }

//     // ✅ ALWAYS normalize terms_conditions to a valid JSON string (array) for jsonb column
//     if (Object.prototype.hasOwnProperty.call(payload, "terms_conditions")) {
//       payload.terms_conditions = normalizeTermsJson(payload.terms_conditions);
//     }

//     const setClauses = [];
//     const values = [];
//     let idx = 1;

//     for (const [key, nextValRaw] of Object.entries(payload)) {
//       const prevVal = current[key];

//       if (key === "auto_logout_time") {
//         const prevMinutes = intervalStrToMinutes(prevVal);
//         const minutes = incomingMinutes ?? 0;

//         if (minutes === 0) {
//           if (prevVal !== null) setClauses.push(`auto_logout_time = NULL`);
//         } else if (minutes !== prevMinutes) {
//           setClauses.push(
//             `auto_logout_time = make_interval(mins => $${idx++})`
//           );
//           values.push(minutes);
//         }
//         continue;
//       }

//       if (key === "terms_conditions") {
//         // prevVal is json/jsonb in DB; stringify both sides for compare
//         const prevJson =
//           prevVal == null
//             ? "[]"
//             : typeof prevVal === "string"
//             ? prevVal
//             : JSON.stringify(prevVal);
//         const nextJson = String(nextValRaw); // we normalized to string JSON
//         if (prevJson !== nextJson) {
//           // cast parameter to jsonb
//           setClauses.push(`terms_conditions = $${idx++}::jsonb`);
//           values.push(nextJson);
//         }
//         continue;
//       }

//       // default compare/update
//       if (!equalish(nextValRaw, prevVal)) {
//         setClauses.push(`${key} = $${idx++}`);
//         values.push(nextValRaw);
//       }
//     }

//     if (setClauses.length === 0) {
//       return res.json({
//         success: true,
//         data: current,
//         message: "No changes detected",
//       });
//     }

//     setClauses.push(`updated_at = NOW()`);

//     const updateSql = `
//       UPDATE system_settings
//       SET ${setClauses.join(", ")}
//       WHERE id = $${idx}
//       RETURNING *;
//     `;
//     const updateRes = await pool.query(updateSql, [...values, id]);
//     return res.json({ success: true, data: updateRes.rows[0] });
//   } catch (err) {
//     console.error("Error updating system settings:", err);
//     return res
//       .status(500)
//       .json({ success: false, message: "Failed to update system settings" });
//   }
// });

// GET /system/settings - Fetch system settings




router.put("/settings", authenticateToken, async (req, res) => {
  try {
    const id = 1;
    const incoming = req.body;

    const allowed = new Set([
      "default_timezone",
      "date_format",
      "currency",
      "auto_logout_time",
      "sms_gateway_name",
      "default_country",
      "sms_user_id",
      "sms_sender_id",
      "sms_api_endpoint",
      "sms_api_key",
      "sms_notification_status",
      "billing_email",
      "system_email",
      "support_email",
      "email_notification_status",
      "postmark_server_token",
      "smtp_host",
      "smtp_port",
      "smtp_username",
      "smtp_password",
      "smtp_encryption",
      "new_client_sms_status",
      "new_client_email_status",
      "new_client_activation_sms_status",
      "new_client_activation_email_status",
      "backoffice_maintenance_status",
      "backoffice_maintenance_msg",
      "webstore_maintenance_status",
      "webstore_maintenance_msg",
      "pos_maintenance_status",
      "pos_maintenance_msg",
      "full_maintenance_status",
      "full_maintenance_msg",
      "terms_conditions",              // jsonb
      "terms_conditions_quotations",   // jsonb
      "field_config", // jsonb
      "inventory_strategy_id",
      "s3_access_key",
      "s3_bucket_name",
      "s3_endpoint",
      "s3_public_key",
      "s3_region",
      "s3_secret_key",
    ]);

    const currentRes = await pool.query(
      "SELECT * FROM system_settings WHERE id = $1 LIMIT 1",
      [id]
    );

    if (currentRes.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Settings row not found" });
    }

    const current = currentRes.rows[0];

    const payload = Object.fromEntries(
      Object.entries(incoming).filter(
        ([k, v]) => allowed.has(k) && v !== undefined
      )
    );

    /* ------------------ Normalization ------------------ */

    let incomingMinutes = null;
    if (Object.prototype.hasOwnProperty.call(payload, "auto_logout_time")) {
      incomingMinutes = normalizeIncomingMinutes(payload.auto_logout_time);
    }

    if (Object.prototype.hasOwnProperty.call(payload, "terms_conditions")) {
      payload.terms_conditions = normalizeTermsJson(
        payload.terms_conditions
      );
    }

    if (
      Object.prototype.hasOwnProperty.call(
        payload,
        "terms_conditions_quotations"
      )
    ) {
      payload.terms_conditions_quotations = normalizeTermsJson(
        payload.terms_conditions_quotations
      );
    }

    /* ------------------ Build UPDATE ------------------ */

    const setClauses = [];
    const values = [];
    let idx = 1;

    for (const [key, nextValRaw] of Object.entries(payload)) {


      /* ---- field_config (jsonb) ---- */
if (key === "field_config") {
  setClauses.push(`field_config = $${idx++}::jsonb`);
  values.push(JSON.stringify(nextValRaw));
  continue;
}

      const prevVal = current[key];

      /* ---- auto logout ---- */
      if (key === "auto_logout_time") {
        const prevMinutes = intervalStrToMinutes(prevVal);
        const minutes = incomingMinutes ?? 0;

        if (minutes === 0) {
          if (prevVal !== null) {
            setClauses.push(`auto_logout_time = NULL`);
          }
        } else if (minutes !== prevMinutes) {
          setClauses.push(
            `auto_logout_time = make_interval(mins => $${idx++})`
          );
          values.push(minutes);
        }
        continue;
      }

      /* ---- terms_conditions ---- */
      if (key === "terms_conditions") {
        const prevJson =
          prevVal == null
            ? "[]"
            : typeof prevVal === "string"
            ? prevVal
            : JSON.stringify(prevVal);

        const nextJson = String(nextValRaw);

        if (prevJson !== nextJson) {
          setClauses.push(`terms_conditions = $${idx++}::jsonb`);
          values.push(nextJson);
        }
        continue;
      }

      /* ---- terms_conditions_quotations ---- */
      if (key === "terms_conditions_quotations") {
        const prevJson =
          prevVal == null
            ? "[]"
            : typeof prevVal === "string"
            ? prevVal
            : JSON.stringify(prevVal);

        const nextJson = String(nextValRaw);

        if (prevJson !== nextJson) {
          setClauses.push(
            `terms_conditions_quotations = $${idx++}::jsonb`
          );
          values.push(nextJson);
        }
        continue;
      }

      

      /* ---- default fields ---- */
      if (!equalish(nextValRaw, prevVal)) {
        setClauses.push(`${key} = $${idx++}`);
        values.push(nextValRaw);
      }
    }

    if (setClauses.length === 0) {
      return res.json({
        success: true,
        data: current,
        message: "No changes detected",
      });
    }

    setClauses.push(`updated_at = NOW()`);

    const updateSql = `
      UPDATE system_settings
      SET ${setClauses.join(", ")}
      WHERE id = $${idx}
      RETURNING *;
    `;

    const updateRes = await pool.query(updateSql, [...values, id]);

    return res.json({ success: true, data: updateRes.rows[0] });
  } catch (err) {
    console.error("Error updating system settings:", err);
    return res.status(500).json({
      success: false,
      message: "Failed to update system settings",
    });
  }
});

router.get("/settings", authenticateToken, async (req, res) => {
  try {
    const id = 1;
    const result = await pool.query(
      `
      SELECT
        to_jsonb(system_settings)
          - 's3_access_key'
          - 's3_secret_key' AS data
      FROM system_settings
      WHERE id = $1
      `,
      [id]
    );

    res.json({ success: true, data: result.rows[0].data });
  } catch (err) {
    console.error("Error fetching system settings:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch system settings" });
  }
});


router.post("/tax-enable", authenticateToken, async (req, res) => {
  try {
    const { enabled } = req.body;

    console.log(enabled);

    const result = await pool.query(
      "UPDATE system_settings SET tax = $1, tax_on_web = false WHERE id = $2 RETURNING *",
      [enabled, 1]
    );

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "System settings not found" });
    }

    res.json({ success: true });
  } catch (err) {
    console.error("Error updating system settings:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to update system settings" });
  }
});

router.post("/tax-value", authenticateToken, async (req, res) => {
  try {
    const { tax_data, enabled, tax_on_web } = req.body;

    console.log(tax_data);

    const result = await pool.query(
      "UPDATE system_settings SET tax_value = $1, tax = $2, tax_on_web = $3 WHERE id = $4 RETURNING *",
      [tax_data, enabled, tax_on_web, 1]
    );

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "System settings not found" });
    }

    res.status(200).json({ success: true });
  } catch (err) {
    console.error("Error updating system settings:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to update system settings" });
  }
});

router.post(
  "/update-tracking-settings",
  authenticateToken,
  async (req, res) => {
    const {
      enabled_google,
      enabled_google_tag,
      gtm_container_id,
      ga4_measurement_id,
      enabled_meta,
      meta_pixel_id,
    } = req.body;

    try {
      const query = `
      UPDATE system_settings
      SET
        enabled_google = $1,
        gtm_container_id = $2,
        ga4_measurement_id = $3,
        enabled_meta = $4,
        meta_pixel_id = $5,
        enabled_google_tag  = $6
       
    `;

      const values = [
        enabled_google,
        gtm_container_id,
        ga4_measurement_id,
        enabled_meta,
        meta_pixel_id,
        enabled_google_tag,
      ];

      await pool.query(query, values);

      return res
        .status(200)
        .json({ message: "Tracking settings updated successfully" });
    } catch (err) {
      console.error("Error updating tracking settings:", err);
      return res
        .status(500)
        .json({ error: "Failed to update tracking settings" });
    }
  }
);

router.get("/get-tracking-settings", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        enabled_google,
        gtm_container_id,
        ga4_measurement_id,
        enabled_meta,
        meta_pixel_id,
        enabled_google_tag
      FROM system_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Settings not found" });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching tracking settings:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/get-delivery-fee", async (req, res) => {
  try {
    const { country } = req.body;

    if (!country) return res.status(400).json({ message: "country not found" });

    const deliverQuery = `SELECT fee, additional_fee FROM delivery_fee WHERE country_id = $1`;
    const defaultCountry = `SELECT fee, additional_fee FROM delivery_fee WHERE id = 1`;

    const [deliveryFee, defaultFee] = await Promise.all([
      pool.query(deliverQuery, [parseFloat(country)]),
      pool.query(defaultCountry),
    ]);

    if (defaultFee.rows.length === 0)
      return res.status(400).json({ message: "delivery fee not found" });

    if (deliveryFee.rows.length === 0)
      return res
        .status(200)
        .json({ message: "delivery fee", result: defaultFee.rows[0] });

    return res
      .status(200)
      .json({ message: "Update successful", result: deliveryFee.rows[0] });
  } catch (error) {
    console.error("Error fetching templates:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/all-country", allCountry);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MOBILE_RE = /^\d{7,15}$/;

// === SET THESE to match your enum labels ===
const ENUM_ON = "active"; // or 'enabled' (etc.)
const ENUM_OFF = "inactive"; // or 'disabled' / 'deactive' (etc.)
// ===========================================

const toStringArray = (val) => {
  if (Array.isArray(val))
    return val
      .map(String)
      .map((s) => s.trim())
      .filter(Boolean);
  if (typeof val === "string")
    return val
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  return [];
};

router.get("/notifications", authenticateToken, async (req, res) => {
  try {
    // Ensure at least one row
    await pool.query(
      `
      INSERT INTO system_settings (
        new_client_sms_status,
        new_client_email_status,
        new_client_activation_sms_status,
        new_client_activation_email_status,
        admin_alert_sms_status,
        admin_alert_email_status,
        notification_mobile_numbers,
        notification_emails
      )
      SELECT $1::status_enum,$1::status_enum,$1::status_enum,$1::status_enum,$1::status_enum,$1::status_enum,'{}'::text[],'{}'::text[]
      WHERE NOT EXISTS (SELECT 1 FROM system_settings)
    `,
      [ENUM_OFF]
    );

    // Compare to your "ON" label
    const params = [ENUM_ON, ENUM_ON, ENUM_ON, ENUM_ON, ENUM_ON, ENUM_ON];
    const result = await pool.query(
      `
      SELECT
        (new_client_sms_status               = $1::status_enum) AS new_client_sms_status,
        (new_client_email_status             = $2::status_enum) AS new_client_email_status,
        (new_client_activation_sms_status    = $3::status_enum) AS new_client_activation_sms_status,
        (new_client_activation_email_status  = $4::status_enum) AS new_client_activation_email_status,
        (admin_alert_sms_status              = $5::status_enum) AS admin_alert_sms_status,
        (admin_alert_email_status            = $6::status_enum) AS admin_alert_email_status,
        notification_mobile_numbers,
        notification_emails,
        updated_at
      FROM system_settings
      ORDER BY updated_at DESC NULLS LAST
      LIMIT 1
    `,
      params
    );

    if (!result.rows.length)
      return res.status(404).json({ message: "Settings not found" });
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Error fetching notification settings:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.put("/notifications", authenticateToken, async (req, res) => {
  try {
    const {
      new_client_sms_status = false,
      new_client_email_status = false,
      new_client_activation_sms_status = false,
      new_client_activation_email_status = false,
      admin_alert_sms_status = false,
      admin_alert_email_status = false,
      notification_mobile_numbers = [],
      notification_emails = [],
    } = req.body || {};

    const mobilesArr = toStringArray(notification_mobile_numbers);
    const emailsArr = toStringArray(notification_emails);

    if (mobilesArr.length && !mobilesArr.every((n) => MOBILE_RE.test(n))) {
      return res.status(400).json({
        message: "Invalid mobile number. Use 7–15 digits per number.",
      });
    }
    if (emailsArr.length && !emailsArr.every((e) => EMAIL_RE.test(e))) {
      return res
        .status(400)
        .json({ message: "One or more email addresses are invalid." });
    }

    const on = ENUM_ON;
    const off = ENUM_OFF;

    const params = [
      new_client_sms_status ? on : off,
      new_client_email_status ? on : off,
      new_client_activation_sms_status ? on : off,
      new_client_activation_email_status ? on : off,
      admin_alert_sms_status ? on : off,
      admin_alert_email_status ? on : off,
      mobilesArr,
      emailsArr,
    ];

    const { rows } = await pool.query(
      `
      WITH target AS (
        SELECT ctid FROM system_settings
        ORDER BY updated_at DESC NULLS LAST
        LIMIT 1
      )
      UPDATE system_settings s
      SET
        new_client_sms_status               = $1::status_enum,
        new_client_email_status             = $2::status_enum,
        new_client_activation_sms_status    = $3::status_enum,
        new_client_activation_email_status  = $4::status_enum,
        admin_alert_sms_status              = $5::status_enum,
        admin_alert_email_status            = $6::status_enum,
        notification_mobile_numbers         = $7::text[],
        notification_emails                 = $8::text[],
        updated_at                          = now()
      FROM target
      WHERE s.ctid = target.ctid
      RETURNING
        (new_client_sms_status              = $9::status_enum) AS new_client_sms_status,
        (new_client_email_status            = $9::status_enum) AS new_client_email_status,
        (new_client_activation_sms_status   = $9::status_enum) AS new_client_activation_sms_status,
        (new_client_activation_email_status = $9::status_enum) AS new_client_activation_email_status,
        (admin_alert_sms_status             = $9::status_enum) AS admin_alert_sms_status,
        (admin_alert_email_status           = $9::status_enum) AS admin_alert_email_status,
        notification_mobile_numbers,
        notification_emails,
        updated_at
    `,
      [...params, on]
    );

    res.json(rows[0]);
  } catch (err) {
    console.error("Error updating notification settings:", err);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.post("/get-smsaction", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, name FROM sms_action WHERE status = 'Active' ORDER BY id DESC"
    );
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching SMS actions:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/add-sms-template", authenticateToken, async (req, res) => {
  const { sms, action, Admin, Client, status } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  if (!user_id) {
    return res.status(400).json({ message: "User ID is required" });
  }

  try {
    const adminValue = Admin ? "Yes" : "";
    const clientValue = Client ? "Yes" : "";
    const actionValue = parseInt(action, 10);

    const result = await pool.query(
      `INSERT INTO sms_template 
       (msg, action, admin, client, "user", status, addby, createddate)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
       RETURNING *`,
      [sms, actionValue, adminValue, clientValue, user_id, status, user_id]
    );

    res.status(201).json({
      message: "SMS Template Added Successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error inserting SMS template:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/get-sms-template", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const actionParam = req.query.action?.trim();
    const offset = (page - 1) * limit;

    let searchCondition = "";
    let queryParams = [];

    if (actionParam) {
      const actionId = parseInt(actionParam, 10);
      if (!isNaN(actionId)) {
        searchCondition = `WHERE st.action = $1`;
        queryParams.push(actionId);
      }
    }

    const queryText = `
      SELECT 
        st.id, 
        st.msg, 
        sa.name AS action_name, 
        st.admin,   -- updated from vendor
        st.client,  -- updated from recipient
        st."user", 
        st.status, 
        st.addby, 
        st.createddate
      FROM sms_template st
      LEFT JOIN sms_action sa ON st.action = sa.id
      ${searchCondition}
      ORDER BY st.id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    queryParams.push(limit, offset);

    const result = await pool.query(queryText, queryParams);

    const totalCountQuery = `
      SELECT COUNT(*) FROM sms_template st
      ${searchCondition}
    `;

    // Slice params for count query (without limit/offset)
    const countParams = queryParams.slice(0, queryParams.length - 2);
    const totalResult = await pool.query(totalCountQuery, countParams);

    const totalTemplates = parseInt(totalResult.rows[0].count, 10);

    res.json({
      smsTemplates: result.rows,
      totalPages: Math.ceil(totalTemplates / limit),
      currentPage: page,
      totalTemplates,
    });
  } catch (error) {
    console.error("Error in /get-sms-template:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

router.post("/sms-template-status", authenticateToken, async (req, res) => {
  const { tempid, status } = req.body; // ✅ Use `tempid` instead of `roleId`
  const user = req.user;
  const user_id = user.user_id;

  try {
    // Begin a transaction
    await pool.query("BEGIN");

    // ✅ Update status in `sms_template` table
    const result = await pool.query(
      "UPDATE sms_template SET status = $1, updateddate = NOW() WHERE id = $2 RETURNING *",
      [status, tempid]
    );

    // If no rows were affected, return an error
    if (result.rowCount === 0) {
      await pool.query("ROLLBACK");
      return res.status(404).json({ message: "SMS Template not found" });
    }

    // ✅ Insert log entry
    // const logMessage = `SMS Template ID ${tempid} was marked as ${status}`;
    // await insertAdminLog(user_id, "SMS Management", logMessage);

    // Commit the transaction
    await pool.query("COMMIT");

    const re = await customhook(1, 130);
    console.log("sms result", re);

    res.json({
      message: "SMS Template status updated successfully",
      data: result.rows[0],
    });
  } catch (error) {
    await pool.query("ROLLBACK"); // Rollback transaction on error
    console.error("Error updating SMS template status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/email-template-status", authenticateToken, async (req, res) => {
  const { tempid, status } = req.body; // ✅ Use `tempid` instead of `roleId`

  const user = req.user;
  const user_id = user.user_id;

  try {
    // Begin a transaction
    await pool.query("BEGIN");

    // ✅ Update status in `sms_template` table
    const result = await pool.query(
      "UPDATE email_template SET status = $1, updateddate = NOW() WHERE id = $2 RETURNING *",
      [status, tempid]
    );

    // If no rows were affected, return an error
    if (result.rowCount === 0) {
      await pool.query("ROLLBACK");
      return res.status(404).json({ message: "SMS Template not found" });
    }

    // ✅ Insert log entry
    // const logMessage = `SMS Template ID ${tempid} was marked as ${status}`;
    // await insertAdminLog(user_id, "SMS Management", logMessage);

    // Commit the transaction
    await pool.query("COMMIT");

    res.json({
      message: "SMS Template status updated successfully",
      data: result.rows[0],
    });
  } catch (error) {
    await pool.query("ROLLBACK"); // Rollback transaction on error
    console.error("Error updating SMS template status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.put("/update-sms-template", authenticateToken, async (req, res) => {
  const { id, sms, action, admin, client, status } = req.body;

  const user = req.user;
  const user_id = user.user_id;

  if (!id || !user_id) {
    return res
      .status(400)
      .json({ message: "Template ID and User ID are required" });
  }

  try {
    const adminValue = admin === "Yes" ? "Yes" : "No"; // Ensure "Yes" or "No"
    const clientValue = client === "Yes" ? "Yes" : "No"; // Ensure "Yes" or "No"
    const actionValue = parseInt(action, 10);

    const result = await pool.query(
      `UPDATE sms_template 
         SET msg = $1, action = $2, admin = $3, client = $4, "user" = $5, status = $6, updateddate = NOW()
         WHERE id = $7 RETURNING *`,
      [sms, actionValue, adminValue, clientValue, user_id, status, id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "SMS Template not found" });
    }

    // Log the update action
    // const logMessage = `SMS Template ID: ${id} updated with new message "${sms}" and action ID: ${action} by User ID: ${user_id}`;
    // await insertAdminlogs("SMS Management", logMessage, user_id);

    res.status(200).json({
      message: "SMS Template Updated Successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating SMS template:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/get-sms-temp-log", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const action = req.query.action?.trim() || null;
    const mobileNo = req.query.mobileNo?.trim() || null;
    const status = req.query.status?.trim() || null;
    const startDate = req.query.startDate
      ? new Date(req.query.startDate)
      : null;
    const endDate = req.query.endDate ? new Date(req.query.endDate) : null;
    const offset = (page - 1) * limit;

    let searchConditions = [];
    let queryParams = [];

    // ✅ Filtering by action
    if (action) {
      searchConditions.push(`st.action = $${queryParams.length + 1}`);
      queryParams.push(action);
    }

    // ✅ Filtering by mobile number
    if (mobileNo) {
      searchConditions.push(`st.mobileno ILIKE $${queryParams.length + 1}`);
      queryParams.push(`%${mobileNo}%`);
    }

    // ✅ Filtering by status
    if (status) {
      searchConditions.push(`st.status = $${queryParams.length + 1}`);
      queryParams.push(status);
    }

    // ✅ Filtering by date range
    if (startDate) {
      searchConditions.push(`st.date >= $${queryParams.length + 1}`);
      queryParams.push(startDate);
    }
    if (endDate) {
      searchConditions.push(`st.date <= $${queryParams.length + 1}`);
      queryParams.push(endDate);
    }

    let whereClause =
      searchConditions.length > 0
        ? `WHERE ${searchConditions.join(" AND ")}`
        : "";

    // ✅ Main Query with Pagination
    const queryText = `
            SELECT 
                st.id, 
                st.mobileno, 
                st.msg, 
                st.status, 
                st.date, 
                st.sentdate, 
                st.batche_id
            FROM send_sms_temp_log st
            ${whereClause}
            ORDER BY st.id DESC
            LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
        `;

    queryParams.push(limit, offset);

    const result = await pool.query(queryText, queryParams);

    // ✅ Total Count Query for Pagination
    const totalCountQuery = `
            SELECT COUNT(*) FROM send_sms_temp_log st
            ${whereClause}
        `;
    const totalResult = await pool.query(
      totalCountQuery,
      queryParams.slice(0, -2)
    );
    const totalTemplates = parseInt(totalResult.rows[0].count, 10);

    res.json({
      smsTemplates: result.rows,
      totalPages: Math.ceil(totalTemplates / limit),
      currentPage: page,
      totalTemplates,
    });
  } catch (error) {
    console.error("Error in /get-sms-temp-log:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

router.post("/add-email-template", authenticateToken, async (req, res) => {
  const { sms, action, Admin, Client, status, subject } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  if (!user_id) {
    return res.status(400).json({ message: "User ID is required" });
  }

  try {
    const adminValue = Admin ? "Yes" : "";
    const clientValue = Client ? "Yes" : "";
    const actionValue = parseInt(action, 10);

    const result = await pool.query(
      `INSERT INTO email_template 
       (msg, action, admin, client, "user", status, addby, createddate,subject)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), $8)
       RETURNING *`,
      [
        sms,
        actionValue,
        adminValue,
        clientValue,
        user_id,
        status,
        user_id,
        subject,
      ]
    );

    res.status(201).json({
      message: "Email Template Added Successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error inserting Email template:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/get-email-template", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const actionParam = req.query.action?.trim();
    const offset = (page - 1) * limit;

    let searchCondition = "";
    let queryParams = [];

    // If 'action' is passed, add it to the WHERE clause
    if (actionParam) {
      const actionId = parseInt(actionParam, 10);
      if (!isNaN(actionId)) {
        searchCondition = `WHERE et.action = $1`;
        queryParams.push(actionId);
      }
    }

    // Main query to get email templates
    const queryText = `
      SELECT 
        et.id, 
        et.subject,
        et.msg, 
        sa.name AS action_name, 
        et.admin, 
        et.client, 
        et."user", 
        et.status, 
        et.addby, 
        et.createddate
      FROM email_template et
      LEFT JOIN sms_action sa ON et.action = sa.id
      ${searchCondition}
      ORDER BY et.id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    queryParams.push(limit, offset);

    const result = await pool.query(queryText, queryParams);

    // Query to get total count for pagination
    const totalCountQuery = `
      SELECT COUNT(*) FROM email_template et
      ${searchCondition}
    `;
    const countParams = queryParams.slice(0, queryParams.length - 2);
    const totalResult = await pool.query(totalCountQuery, countParams);

    const totalTemplates = parseInt(totalResult.rows[0].count, 10);

    // Respond with paginated data
    res.json({
      emailTemplates: result.rows,
      totalPages: Math.ceil(totalTemplates / limit),
      currentPage: page,
      totalTemplates,
    });
  } catch (error) {
    console.error("Error in /get-email-template:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

router.put("/update-email-template", authenticateToken, async (req, res) => {
  const { id, sms, action, admin, client, status, subject } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  if (!id || !user_id) {
    return res
      .status(400)
      .json({ message: "Template ID and User ID are required" });
  }

  try {
    const adminValue = admin === "Yes" ? "Yes" : "No"; // Ensure "Yes" or "No"
    const clientValue = client === "Yes" ? "Yes" : "No"; // Ensure "Yes" or "No"
    const actionValue = parseInt(action, 10);

    const result = await pool.query(
      `UPDATE email_template 
         SET msg = $1, action = $2, admin = $3, client = $4, "user" = $5, status = $6, updateddate = NOW(), subject = $8
         WHERE id = $7 RETURNING *`,
      [sms, actionValue, adminValue, clientValue, user_id, status, id, subject]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Email Template not found" });
    }

    // Log the update action
    // const logMessage = `SMS Template ID: ${id} updated with new message "${sms}" and action ID: ${action} by User ID: ${user_id}`;
    // await insertAdminlogs("SMS Management", logMessage, user_id);

    res.status(200).json({
      message: "Email Template Updated Successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error updating Email template:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.get("/get-email-temp-log", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 25;
    const action = req.query.action?.trim() || null;
    const email = req.query.email?.trim() || null;
    const status = req.query.status?.trim() || null;
    const startDate = req.query.startDate
      ? new Date(req.query.startDate)
      : null;
    const endDate = req.query.endDate ? new Date(req.query.endDate) : null;
    const offset = (page - 1) * limit;

    let searchConditions = [];
    let queryParams = [];

    // ✅ Filtering by action
    if (action) {
      searchConditions.push(`st.action = $${queryParams.length + 1}`);
      queryParams.push(action);
    }

    // ✅ Filtering by mobile number
    if (email) {
      searchConditions.push(`st.email ILIKE $${queryParams.length + 1}`);
      queryParams.push(`%${email}%`);
    }

    // ✅ Filtering by status
    if (status) {
      searchConditions.push(`st.status = $${queryParams.length + 1}`);
      queryParams.push(status);
    }

    // ✅ Filtering by date range
    if (startDate) {
      searchConditions.push(`st.date >= $${queryParams.length + 1}`);
      queryParams.push(startDate);
    }
    if (endDate) {
      searchConditions.push(`st.date <= $${queryParams.length + 1}`);
      queryParams.push(endDate);
    }

    let whereClause =
      searchConditions.length > 0
        ? `WHERE ${searchConditions.join(" AND ")}`
        : "";

    // ✅ Main Query with Pagination
    const queryText = `
            SELECT 
                st.id, 
                st.email, 
                st.msg, 
                st.status, 
                st.date, 
                st.sentdate, 
                                st.subject, 

                st.batche_id
            FROM send_email_temp_log st
            ${whereClause}
            ORDER BY st.id DESC
            LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
        `;

    queryParams.push(limit, offset);

    const result = await pool.query(queryText, queryParams);

    // ✅ Total Count Query for Pagination
    const totalCountQuery = `
            SELECT COUNT(*) FROM send_email_temp_log st
            ${whereClause}
        `;
    const totalResult = await pool.query(
      totalCountQuery,
      queryParams.slice(0, -2)
    );
    const totalTemplates = parseInt(totalResult.rows[0].count, 10);

    res.json({
      smsTemplates: result.rows,
      totalPages: Math.ceil(totalTemplates / limit),
      currentPage: page,
      totalTemplates,
    });
  } catch (error) {
    console.error("Error in /get-email-temp-log:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// GET /system/reminder
router.get("/reminder", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT suspend_date FROM system_settings LIMIT 1`
    );

    if (result.rows.length === 0) {
      return res.json({ unpaidInvoicesCount: 0, dueDate: null });
    }

    res.json({
      unpaidInvoicesCount: 1, // 🔹 you can compute this separately or set 1 if suspend_date exists
      dueDate: result.rows[0].suspend_date,
    });
  } catch (err) {
    console.error("Error fetching suspend_date:", err);
    res.status(500).json({ message: "Failed to fetch suspend date" });
  }
});

router.get("/suspend-status", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT suspend_status, suspend_reason FROM system_settings LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.json({ suspended: false, reason: null });
    }

    res.json({
      suspended: result.rows[0].suspend_status === true,
      reason: result.rows[0].suspend_reason || null
    });
  } catch (err) {
    console.error("Error fetching suspend_status:", err);
    res.status(500).json({ message: "Failed to fetch suspend status" });
  }
});

router.post("/loyalty-value", authenticateToken, async (req, res) => {
  try {
    const { loyalty_point, points_given, amount_spend } = req.body;

    

    const result = await pool.query(
      "UPDATE system_settings SET loyalty_point = $1, points_given = $2, amount_spend = $3 WHERE id = $4 RETURNING *",
      [
        loyalty_point === true || loyalty_point === "true",
        Number(points_given),
        Number(amount_spend),
        1
      ]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "System settings not found"
      });
    }

    const user = req.user;
    const user_id = user.user_id;

    const module = "System Settings";
    const logMessage = `Updated loyalty settings: 
Loyalty program ${loyalty_point ? "enabled" : "disabled"}, 
${points_given} points awarded for every ${amount_spend} spent.`;

    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ success: true });

  } catch (err) {
    console.error("Error updating system settings:", err);
    res.status(500).json({
      success: false,
      message: "Failed to update system settings"
    });
  }
});

router.get("/loyalty_point", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        loyalty_point,
        points_given,
        amount_spend,
        currency	
      FROM system_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Loyalty Points not found" });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error("Error fetching Loyalty Points:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});



// GET email template by ID with action name
router.get("/email-template/:id", async (req, res) => {
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ message: "Missing template ID" });
  }

  try {
    const result = await pool.query(
      `SELECT 
          e.id,
          e.subject,
          e.msg,
          e.admin,
          e.client,
          e.status,
          a.name AS action_name
        FROM email_template e
        LEFT JOIN sms_action a ON e.action = a.id
        WHERE e.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Template not found" });
    }

    res.status(200).json(result.rows[0]);
  } catch (err) {
    console.error("Error fetching email template:", err);
    res.status(500).json({ message: "Server error" });
  }
});

router.get('/currency', async (req, res) => {
  try {
     const result = await pool.query('SELECT currency FROM system_settings WHERE id = $1', [1]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Currency not found' });
    }

    res.status(200).json(result.rows[0].currency);
  } catch (err) {
    console.error('Error fetching currency:', err);
    res.status(500).json({ message: 'Failed to fetch currency' });
  }
});


module.exports = router;
