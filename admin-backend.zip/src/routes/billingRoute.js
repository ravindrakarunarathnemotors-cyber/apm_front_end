// In your admin-backend router file
const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const router = express.Router();

// GET endpoint to fetch system suspend status
router.get("/suspend-status", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT 
        id,
        suspend_status,
        suspend_reason,
        suspend_date,
        updated_at
       FROM system_settings 
       WHERE id = 1`
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        message: 'System settings not found'
      });
    }

    return res.status(200).json({
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Error fetching system settings:', error);
    return res.status(500).json({
      message: 'Internal Server Error',
      error: error.message
    });
  }
});

router.put("/suspend-status", authenticateToken, async (req, res) => {
  try {
    const { serviceId, reason, status, action } = req.body;
    const updatedBy = req.user?.user_id || 'system';

    // Validate input
    if (!serviceId || !reason) {
      return res.status(400).json({
        message: 'Service ID and reason are required'
      });
    }

    console.log(`Processing service suspension for service ID: ${serviceId}`);
    console.log(`Reason: ${reason}`);
    console.log(`Action: ${action}`);
    console.log(`Updated by: ${updatedBy}`);

    // 🔹 Update system_settings table
    // Since system_settings typically has only one row (id=1), we update that
    const updateQuery = `
      UPDATE system_settings
      SET
        suspend_status = true,
        suspend_reason = $1,
        suspend_date = CURRENT_DATE,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
      RETURNING 
        id,
        suspend_status,
        suspend_reason,
        suspend_date,
        updated_at
    `;

    const updateResult = await pool.query(updateQuery, [reason]);

    if (updateResult.rowCount === 0) {
      // If no row was updated, insert a new row with id=1
      const insertQuery = `
        INSERT INTO system_settings (id, suspend_status, suspend_reason, suspend_date, updated_at)
        VALUES (1, true, $1, CURRENT_DATE, CURRENT_TIMESTAMP)
        RETURNING id, suspend_status, suspend_reason, suspend_date, updated_at
      `;
      
      const insertResult = await pool.query(insertQuery, [reason]);
      console.log('✅ New system settings record created with suspension');
    } else {
      console.log('✅ System settings updated with suspension');
    }

    // Log this action in system_log table
    const logMessage = `
Service Suspension Notification Processed
Service ID: ${serviceId}
Reason: ${reason}
Status: ${status}
Action: ${action}
System Settings Updated: suspend_status=true
    `.trim();

    await pool.query(
      `INSERT INTO system_log (module, log, user_id, date)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
      ['Service Suspension', logMessage, updatedBy]
    );

    // Return success response
    return res.status(200).json({
      message: 'Service suspension processed and system settings updated successfully',
      data: {
        serviceId,
        status: 'processed',
        systemSuspended: true,
        suspendReason: reason,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('❌ Error processing service suspension:', error);
    
    // Log error to system_log
    try {
      await pool.query(
        `INSERT INTO system_log (module, log, user_id, date)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
        ['Service Suspension Error', 
         `Error processing suspension: ${error.message}`, 
         req.user?.user_id || 'system']
      );
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }

    return res.status(500).json({
      message: 'Internal Server Error',
      error: error.message
    });
  }
});

// In your admin-backend billingRoute.js
// In your admin-backend billingRoute.js
router.put("/activate-status", authenticateToken, async (req, res) => {
  try {
    const { serviceId, status, action, previousStatus } = req.body;
    const updatedBy = req.user?.user_id || 'system';

    // Validate input
    if (!serviceId) {
      return res.status(400).json({
        message: 'Service ID is required'
      });
    }

    console.log(`Processing service activation for service ID: ${serviceId}`);
    console.log(`Previous Status: ${previousStatus}`);
    console.log(`New Status: ${status}`);
    console.log(`Action: ${action}`);
    console.log(`Updated by: ${updatedBy}`);

    // 🔹 Update system_settings to unsuspend the system
    const updateQuery = `
      UPDATE system_settings
      SET
        suspend_status = false,
        suspend_reason = NULL,
        suspend_date = NULL,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
      RETURNING 
        id,
        suspend_status,
        suspend_reason,
        suspend_date,
        updated_at
    `;

    const updateResult = await pool.query(updateQuery);

    if (updateResult.rowCount === 0) {
      // If no row was updated, insert a new row with id=1 (unsuspended)
      const insertQuery = `
        INSERT INTO system_settings (id, suspend_status, suspend_reason, suspend_date, updated_at)
        VALUES (1, false, NULL, NULL, CURRENT_TIMESTAMP)
        RETURNING id, suspend_status, suspend_reason, suspend_date, updated_at
      `;
      
      const insertResult = await pool.query(insertQuery);
      console.log('✅ New system settings record created (active state)');
    } else {
      console.log('✅ System settings updated to active state');
    }

    // Check if suspended_services column exists and remove this service if needed
    try {
      const columnCheck = await pool.query(
        `SELECT column_name 
         FROM information_schema.columns 
         WHERE table_name='system_settings' AND column_name='suspended_services'`
      );

      if (columnCheck.rowCount > 0) {
        // Remove this service from suspended_services array
        const removeServiceQuery = `
          UPDATE system_settings
          SET
            suspended_services = (
              SELECT COALESCE(
                jsonb_agg(elem),
                '[]'::jsonb
              )
              FROM jsonb_array_elements(suspended_services) AS elem
              WHERE elem->>'serviceId' != $1::text
            ),
            updated_at = CURRENT_TIMESTAMP
          WHERE id = 1
          RETURNING suspended_services
        `;
        
        await pool.query(removeServiceQuery, [serviceId.toString()]);
        console.log(`✅ Service ${serviceId} removed from suspended_services`);
      }
    } catch (err) {
      // Column doesn't exist or other error, just log and continue
      console.log('Note: suspended_services column not found or error:', err.message);
    }

    // Log this action in system_log table
    const logMessage = `
Service Activation Notification Processed
Service ID: ${serviceId}
Previous Status: ${previousStatus || 'unknown'}
New Status: ${status}
Action: ${action}
System Settings Updated: suspend_status=false
    `.trim();

    await pool.query(
      `INSERT INTO system_log (module, log, user_id, date)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
      ['Service Activation', logMessage, updatedBy]
    );

    // Return success response
    return res.status(200).json({
      message: 'Service activation processed and system settings updated successfully',
      data: {
        serviceId,
        status: 'activated',
        systemSuspended: false,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('❌ Error processing service activation:', error);
    
    // Log error to system_log
    try {
      await pool.query(
        `INSERT INTO system_log (module, log, user_id, date)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
        ['Service Activation Error', 
         `Error processing activation: ${error.message}`, 
         req.user?.user_id || 'system']
      );
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }

    return res.status(500).json({
      message: 'Internal Server Error',
      error: error.message
    });
  }
});

// In your admin-backend billingRoute.js
router.put("/inactive-status", authenticateToken, async (req, res) => {
  try {
    const { serviceId, reason, status, action, previousStatus } = req.body;
    const updatedBy = req.user?.user_id || 'system';

    // Validate input
    if (!serviceId) {
      return res.status(400).json({
        message: 'Service ID is required'
      });
    }

    console.log(`Processing service inactivation for service ID: ${serviceId}`);
    console.log(`Previous Status: ${previousStatus}`);
    console.log(`New Status: ${status}`);
    console.log(`Reason: ${reason}`);
    console.log(`Action: ${action}`);
    console.log(`Updated by: ${updatedBy}`);

    // 🔹 OPTION A: Update system_settings the same way as suspend
    // This will set suspend_status = true, store reason and date
    const updateQuery = `
      UPDATE system_settings
      SET
        suspend_status = true,
        suspend_reason = $1,
        suspend_date = CURRENT_DATE,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
      RETURNING 
        id,
        suspend_status,
        suspend_reason,
        suspend_date,
        updated_at
    `;

    const updateResult = await pool.query(updateQuery, [reason]);

    if (updateResult.rowCount === 0) {
      // If no row was updated, insert a new row with id=1
      const insertQuery = `
        INSERT INTO system_settings (id, suspend_status, suspend_reason, suspend_date, updated_at)
        VALUES (1, true, $1, CURRENT_DATE, CURRENT_TIMESTAMP)
        RETURNING id, suspend_status, suspend_reason, suspend_date, updated_at
      `;
      
      const insertResult = await pool.query(insertQuery, [reason]);
      console.log('✅ New system settings record created with inactive state');
    } else {
      console.log('✅ System settings updated to inactive state (suspend_status=true)');
    }

    // Log this action in system_log table
    const logMessage = `
Service Inactivation Notification Processed (Option A)
Service ID: ${serviceId}
Previous Status: ${previousStatus || 'unknown'}
New Status: ${status}
Reason: ${reason}
Action: ${action}
System Settings Updated: suspend_status=true (treating inactive as suspended)
    `.trim();

    await pool.query(
      `INSERT INTO system_log (module, log, user_id, date)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
      ['Service Inactivation', logMessage, updatedBy]
    );

    // Return success response
    return res.status(200).json({
      message: 'Service inactivation processed successfully (treated as suspend)',
      data: {
        serviceId,
        status: 'inactivated',
        systemSuspended: true,
        suspendReason: reason,
        suspendDate: new Date().toISOString().split('T')[0],
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('❌ Error processing service inactivation:', error);
    
    // Log error to system_log
    try {
      await pool.query(
        `INSERT INTO system_log (module, log, user_id, date)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP)`,
        ['Service Inactivation Error', 
         `Error processing inactivation: ${error.message}`, 
         req.user?.user_id || 'system']
      );
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }

    return res.status(500).json({
      message: 'Internal Server Error',
      error: error.message
    });
  }
});


router.get('/saas-features', async (req, res) => {
  try {
    const result = await pool.query(
      `
      SELECT 
        id,
        parent_id,
        name,
        route,
        icon,
        sidebar_order,
        package_show
      FROM uimenudata
      ORDER BY sidebar_order ASC
      `
    );

    res.json({
      success: true,
      features: result.rows,
      total: result.rowCount
    });

  } catch (error) {
    console.error('Error fetching features:', error);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});

router.patch('/update-package-show-batch', async (req, res) => {
  try {
    const { features } = req.body;

    if (!features || !Array.isArray(features) || features.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Features array is required'
      });
    }

    const results = [];
    
    for (const feature of features) {
      const { featureId, package_show } = feature;
      
      if (!featureId || typeof package_show !== 'boolean') {
        continue;
      }
      
      const result = await pool.query(
        `
        UPDATE uimenudata 
        SET 
          package_show = $1,
          show = $1
        WHERE id = $2
        RETURNING id, name, package_show, show
        `,
        [package_show, featureId]
      );
      
      if (result.rowCount > 0) {
        results.push(result.rows[0]);
        console.log(`✅ Feature ${featureId} (${result.rows[0].name}): package_show = ${package_show}, show = ${package_show}`);
      }
    }

    res.json({
      success: true,
      message: `${results.length} feature(s) updated successfully`,
      updated_features: results
    });

  } catch (error) {
    console.error('Error batch updating package_show:', error);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
});



module.exports = router;