const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");

/**
 * POST /api/vouchers/create-range
 */

router.post(
  "/check-voucher-range-availability",
  authenticateToken,
  async (req, res) => {
    try {
      const { from, to } = req.body;

      // ---------- Validation ----------
      if (!from || !to) {
        return res.status(400).json({
          message: "from and to are required",
        });
      }

      if (to <= from) {
        return res.status(400).json({
          message: "Invalid range",
        });
      }

      if (to - from > 500) {
        return res.status(400).json({
          message: "Maximum voucher range limit is 500",
        });
      }

      // ---------- Generate range ----------
      const voucherIds = [];
      for (let i = from; i <= to; i++) {
        voucherIds.push(i.toString());
      }

      // ---------- Check existing vouchers ----------
      const existingQuery = `
        SELECT voucher_id
        FROM voucher
        WHERE voucher_id = ANY($1)
      `;
      const existingResult = await pool.query(existingQuery, [voucherIds]);
      const usedVoucherIds = existingResult.rows.map((row) => row.voucher_id);

      // ---------- Response ----------
      return res.json({
        status: usedVoucherIds.length ? "USED_FOUND" : "AVAILABLE",
        range: `${from}-${to}`,
        totalRequested: voucherIds.length,
        usedCount: usedVoucherIds.length,
        availableCount: voucherIds.length - usedVoucherIds.length,
        usedVoucherIds,
      });
    } catch (error) {
      console.error("Voucher availability check error:", error);
      return res.status(500).json({
        message: "Internal server error",
      });
    }
  },
);

// router.post('/create-voucher-range', authenticateToken, async (req, res) => {
//   const client = await pool.connect()

//   try {
//     const userId = req.user.user_id
//     const { from, to, amount, skipIds = [] } = req.body

//     // ---------- Validation ----------
//     if (!from || !to || !amount) {
//       return res.status(400).json({ message: 'from, to and amount are required' })
//     }

//     if (to <= from) {
//       return res.status(400).json({ message: 'Invalid range' })
//     }

//     if (to - from > 500) {
//       return res.status(400).json({ message: 'Maximum range limit is 500' })
//     }

//     // ---------- Generate range ----------
//     const voucherIds = []
//     for (let i = from; i <= to; i++) {
//       voucherIds.push(i.toString())
//     }

//     // ---------- Check existing vouchers ----------
//     const existingQuery = `
//       SELECT voucher_id
//       FROM voucher
//       WHERE voucher_id = ANY($1)
//     `
//     const existingResult = await pool.query(existingQuery, [voucherIds])
//     const existingIds = existingResult.rows.map(r => r.voucher_id)

//     // ---------- If frontend is only checking ----------
//     if (!skipIds.length && existingIds.length) {
//       return res.json({
//         status: 'USED_FOUND',
//         usedVoucherIds: existingIds,
//         usedCount: existingIds.length
//       })
//     }

//     // ---------- Filter insertable IDs ----------
//     const finalInsertIds = voucherIds.filter(
//       id => !existingIds.includes(id) && !skipIds.includes(id)
//     )

//     if (!finalInsertIds.length) {
//       return res.status(400).json({
//         message: 'No vouchers to insert after skipping'
//       })
//     }

//     // ---------- Insert vouchers ----------
//     await client.query('BEGIN')

//     const insertQuery = `
//       INSERT INTO voucher (voucher_id, amount, by)
//       VALUES ($1, $2, $3)
//     `

//     for (const vid of finalInsertIds) {
//       await client.query(insertQuery, [
//         vid,
//         amount,
//         userId
//       ])
//     }

//     // ---------- Admin Log ----------
//     const ignoredIds = [...existingIds, ...skipIds]
//     const logPayload = {
//       range: `${from}-${to}`,
//       inserted_count: finalInsertIds.length,
//       ignored_count: ignoredIds.length,
//       ignored_ids: ignoredIds
//     }

//     await insertAdminLog(
//       userId,
//       'POS',
//       `Voucher batch created: ${JSON.stringify(logPayload)}`
//     )

//     await client.query('COMMIT')

//     return res.json({
//       status: 'SUCCESS',
//       insertedCount: finalInsertIds.length,
//       ignoredCount: ignoredIds.length,
//       ignoredIds
//     })

//   } catch (error) {
//     await client.query('ROLLBACK')
//     console.error('Voucher creation error:', error)
//     return res.status(500).json({ message: 'Internal server error' })
//   } finally {
//     client.release()
//   }
// })

// create voucher range
router.post("/create-voucher-range", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const userId = req.user.user_id;
    const { from, to, amount, skipIds = [] } = req.body;

    // ---------- Validation ----------
    if (!from || !to || !amount) {
      return res.status(400).json({
        message: "from, to and amount are required",
      });
    }

    // ✅ allow equal (needed for logic)
    if (to < from) {
      return res.status(400).json({
        message: "Invalid range",
      });
    }

    if (to - from > 500) {
      return res.status(400).json({
        message: "Maximum voucher range limit is 500",
      });
    }

    // ---------- Generate range (SKIP "from") ----------
    const voucherIds = [];
    for (let i = Number(from) + 1; i <= Number(to); i++) {
      voucherIds.push(i.toString());
    }

    // ✅ handle case like 10 → 10
    if (!voucherIds.length) {
      return res.status(400).json({
        message: "No vouchers to create",
      });
    }

    // ---------- Check existing vouchers ----------
    const existingQuery = `
      SELECT voucher_id
      FROM voucher
      WHERE voucher_id = ANY($1)
    `;
    const existingResult = await client.query(existingQuery, [voucherIds]);
    const alreadyUsedIds = existingResult.rows.map((row) => row.voucher_id);

    // ---------- Final skip set ----------
    const finalSkippedIds = Array.from(
      new Set([...skipIds, ...alreadyUsedIds]),
    );

    // ---------- Final insertable IDs ----------
    const insertIds = voucherIds.filter((id) => !finalSkippedIds.includes(id));

    if (!insertIds.length) {
      return res.status(400).json({
        message: "No vouchers to insert after skipping",
        skippedIds: finalSkippedIds,
      });
    }

    // ---------- Insert vouchers ----------
    await client.query("BEGIN");

    const insertQuery = `
      INSERT INTO voucher (voucher_id, amount, by)
      VALUES ($1, $2, $3)
    `;

    for (const vid of insertIds) {
      await client.query(insertQuery, [vid, amount, userId]);
    }

    // ---------- Admin Log ----------
    const logPayload = {
      action: "CREATE_VOUCHER_RANGE",
      range: `${from}-${to}`,
      amount,
      inserted_count: insertIds.length,
      skipped_count: finalSkippedIds.length,
      skipped_ids: finalSkippedIds,
      created_by: userId,
    };

    await insertAdminLog(userId, "POS", JSON.stringify(logPayload));

    await client.query("COMMIT");

    // ✅ return inserted IDs also
    return res.json({
      status: "SUCCESS",
      range: `${from}-${to}`,
      amount,
      insertedCount: insertIds.length,
      insertedIds: insertIds,
      skippedCount: finalSkippedIds.length,
      skippedIds: finalSkippedIds,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Voucher creation error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// voucher summary/history

router.get("/voucher-history", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      page = 1,
      limit,
      voucher_id,
      from,
      to,
      usage,
      date_from,
      date_to,
      amount_from,
      amount_to,
    } = req.query;

    
    const offset = (Number(page) - 1) * limit;

    const where = [];
    const values = [];

    /* ---------------- Voucher ID filters ---------------- */
    if (voucher_id) {
      values.push(voucher_id);
      where.push(`v.voucher_id = $${values.length}`);
    }

    if (from && to) {
      values.push(from, to);
      where.push(
        `v.voucher_id BETWEEN $${values.length - 1} AND $${values.length}`,
      );
    }

    /* ---------------- Usage filters ---------------- */
    if (usage && usage !== "all") {
      if (usage === "used") {
        where.push(`v.used_amount = v.amount`);
      }

      if (usage === "in-use") {
        where.push(`v.used_amount > 0 AND v.used_amount < v.amount`);
      }

      if (usage === "to-be-used") {
        where.push(`v.used_amount = 0`);
      }
    }

    /* ---------------- Date filters ---------------- */
    if (date_from && date_to) {
      values.push(date_from, date_to);
      where.push(`v.date BETWEEN $${values.length - 1} AND $${values.length}`);
    }

    /* ---------------- Amount filters ---------------- */
    if (amount_from && amount_to) {
      values.push(amount_from, amount_to);
      where.push(
        `v.amount BETWEEN $${values.length - 1} AND $${values.length}`,
      );
    }

    const whereSQL = where.length ? `WHERE ${where.join(" AND ")}` : "";

    /* ---------------- Currency ---------------- */
    const settingsResult = await client.query(
      `SELECT currency FROM system_settings LIMIT 1`,
    );
    const currency = settingsResult.rows[0]?.currency || null;

    /* ---------------- Total count (FILTERED) ---------------- */
    const countQuery = `
      SELECT COUNT(*)::INT AS total
      FROM voucher v
      ${whereSQL}
    `;
    const countResult = await client.query(countQuery, values);
    const total = countResult.rows[0].total;

    /* ---------------- Unique amounts (UNFILTERED) ---------------- */
    const amountQuery = `
      SELECT DISTINCT amount
      FROM voucher
      ORDER BY amount ASC
    `;
    const amountResult = await client.query(amountQuery);
    const uniqueAmounts = amountResult.rows.map((r) => r.amount);

    /* ---------------- Main paginated data ---------------- */
    const dataQuery = `
      SELECT
        v.*,
        u.first_name,
        u.last_name
      FROM voucher v
      LEFT JOIN users u
        ON u.user_id = v.by
      ${whereSQL}
      ORDER BY v.id DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `;

    const dataResult = await client.query(dataQuery, values);

    return res.json({
      status: "SUCCESS",
      currency,
      pagination: {
        page: Number(page),
        pageSize: limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      uniqueAmounts,
      data: dataResult.rows,
    });
  } catch (error) {
    console.error("Voucher history fetch error:", error);
    return res.status(500).json({
      status: "ERROR",
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// voucher stats
router.get("/voucher-stats", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT
        MAX(voucher_id::BIGINT) AS max_voucher_id,
        COUNT(*) AS total_voucher_count,

        -- vouchers partially used
        COUNT(*) FILTER (
          WHERE used_amount > 0
            AND used_amount < amount
        ) AS in_use_count,

        -- vouchers not used at all
        COUNT(*) FILTER (
          WHERE used_amount = 0
        ) AS to_be_used_count,

        -- vouchers fully used
        COUNT(*) FILTER (
          WHERE used_amount = amount
        ) AS used_count

      FROM voucher
    `;

    const { rows } = await pool.query(query);

    return res.json({
      status: "SUCCESS",
      data: {
        max_voucher_id: rows[0].max_voucher_id,
        total_voucher_count: rows[0].total_voucher_count,
        in_use_count: rows[0].in_use_count,
        to_be_used_count: rows[0].to_be_used_count,
        used_count: rows[0].used_count,
      },
    });
  } catch (error) {
    console.error("Voucher stats fetch error:", error);
    return res.status(500).json({
      status: "ERROR",
      message: "Internal server error",
    });
  }
});

// voucher status
// voucher status (by voucher_id)
// voucher status (payload uses id, DB uses voucher_id)
router.put("/vouchers-status", authenticateToken, async (req, res) => {
  const { id, status } = req.body;

  // validation
  if (!id || !status) {
    return res.status(400).json({
      success: false,
      message: "id and status are required",
    });
  }

  if (!["active", "inactive"].includes(status)) {
    return res.status(400).json({
      success: false,
      message: "status must be 'active' or 'inactive'",
    });
  }

  try {
    const result = await pool.query(
      `
      UPDATE voucher
      SET status = $1
      WHERE voucher_id = $2
      RETURNING voucher_id, status
      `,
      [status, id], //  id maps to voucher_id
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Voucher not found",
      });
    }

    res.json({
      success: true,
      message: "Voucher status updated successfully",
      data: result.rows[0],
    });
  } catch (err) {
    console.error("Voucher status update failed:", err);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

module.exports = router;
