const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();


router.post("/webpage", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    const queryParams = [];
    const whereClause = ""; 

   
    const ordersQuery = `
      SELECT * 
      FROM web_pages
      ${whereClause}  -- No filtering applied
      ORDER BY id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

   
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM web_pages
      ${whereClause}  -- No filtering applied
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      webpage: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.put('/update', async (req, res) => {
  const { id, title, content_html } = req.body;

  try {
    const result = await pool.query(
      'UPDATE web_pages SET title = $1, content_html = $2 WHERE id = $3 RETURNING *',
      [title, content_html, id]
    );
    res.json({ success: true, updated: result.rows[0] });
  } catch (error) {
    console.error('Update error:', error);
    res.status(500).json({ success: false, message: 'Update failed' });
  }
});



router.put('/toggle-status', async (req, res) => {
  const { id, is_homepage } = req.body

  if (typeof id === 'undefined' || typeof is_homepage === 'undefined') {
    return res.status(400).json({ success: false, message: 'Missing required fields' })
  }

  try {
    const result = await pool.query(
      'UPDATE web_pages SET is_homepage = $1 WHERE id = $2 RETURNING *',
      [is_homepage, id]
    )

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Page not found' })
    }

    return res.json({ success: true, updated: result.rows[0] })
  } catch (error) {
    console.error('Error updating page status:', error)
    return res.status(500).json({ success: false, message: 'Server error' })
  }
})


router.get("/plugins", authenticateToken, async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT 
        plugin_id,
        plugin_name,
        information,
        logo,
        status
      FROM plugins
      ORDER BY plugin_id ASC
    `);

    if (!rows.length) {
      return res.status(404).json({ message: "No plugins found" });
    }

    res.status(200).json(rows);
  } catch (error) {
    console.error("Error fetching plugins:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});


router.post('/phone', authenticateToken, async (req, res) => {
  try {
    const { plugin_id, phone_number } = req.body
    if (!plugin_id || !phone_number) {
      return res.status(400).json({ message: 'Missing plugin_id or phone_number' })
    }

    await pool.query(
      'UPDATE plugins SET information = $1 WHERE plugin_id = $2',
      [phone_number, plugin_id]
    )

    res.json({ message: 'Phone number updated successfully' })
  } catch (error) {
    console.error('Error updating phone number:', error)
    res.status(500).json({ message: 'Internal server error' })
  }
})

router.post('/save-active', authenticateToken, async (req, res) => {
  try {
    const { plugin_id, phone_number } = req.body
    if (!plugin_id || !phone_number) {
      return res.status(400).json({ message: 'Missing plugin_id or phone_number' })
    }

    await pool.query(
      'UPDATE plugins SET information = $1, status = $2 WHERE plugin_id = $3',
      [phone_number, 'active', plugin_id]
    )

    res.json({ message: 'Plugin updated and activated successfully' })
  } catch (error) {
    console.error('Error saving and activating:', error)
    res.status(500).json({ message: 'Internal server error' })
  }
})


router.post('/status', authenticateToken, async (req, res) => {
  try {
    const { plugin_id, status } = req.body

    if (!plugin_id || !status) {
      return res.status(400).json({ message: 'Missing plugin_id or status' })
    }

    await pool.query(
      'UPDATE plugins SET status = $1 WHERE plugin_id = $2',
      [status, plugin_id]
    )

    res.json({ message: 'Status updated successfully' })
  } catch (error) {
    console.error('Error updating status:', error)
    res.status(500).json({ message: 'Internal server error' })
  }
})






module.exports = router;