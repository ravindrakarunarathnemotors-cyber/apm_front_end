const express = require("express");
const multer = require("multer");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
require("dotenv").config();
const { uploadToS3 } = require("../FileUploader/file_uploader");

const router = express.Router();

// ✅ Multer memory storage
const storage = multer.memoryStorage();
const upload = multer({ storage });

// ✅ S3 client initialization
const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

//  Public URL prefix for files
const PUBLIC_URL_PREFIX = process.env.CONVERT_S3_URL;

router.post("/upload-staging", upload.array("files", 50), async (req, res) => {
  const files = req.files;

  if (!files || files.length === 0) {
    return res.status(400).json({ error: "At least one file is required." });
  }

  try {
    const results = await uploadToS3({
      files,
      folderPath: "Web_Media", // ✅ same folder as before
      useDate: true, // ✅ keeps YYYY-MM-DD structure
    });

    // 🔁 Match your existing response format
    const uploadResults = results.map((r) => ({
      file_name: r.original_name,
      media_url: r.url,
      media_type: r.type,
    }));

    return res.status(200).json({
      message: "Staging upload successful",
      uploaded_count: uploadResults.length,
      media: uploadResults,
    });
  } catch (err) {
    console.error("Upload staging error:", err);
    return res.status(500).json({ error: "Staging upload failed" });
  }
});

module.exports = router;
