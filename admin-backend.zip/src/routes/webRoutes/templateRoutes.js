const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
// const { getTemplate, getPages, getPage, createPage, updatePage, deletePage, updatetempleteID, gettempleteID } = require("../../controllers/webController");


// router.get("/get-templates", authenticateToken, getTemplate);

// router.get("/pages", getPages);

// router.get("/pages/:id", getPage);

// router.post("/pages", createPage);

// router.put("/pages/:id", updatePage);

// router.delete("/pages/:id", deletePage);

// router.post("/update_template", updatetempleteID);
 
// router.get("/gettempleteID", gettempleteID);


const { getTemplate, getPages, getPage, createPage, updatePage, deletePage, getTemplateSections, getSalesChannelTemplate, setSelectedTemplate, getSelectedSections, setSelectedSections, getComponents, createComponent, updateComponent, deleteComponent, getPageComponents, createPageComponent, updatePageComponent, deletePageComponent, updateTemplateSections, getCategoriesWithCount, getFeaturedProducts, getBestSellingProducts, getCollections, getCollectionProducts, getSpecialProducts } = require("../../controllers/webController");


router.get("/get-templates", authenticateToken, getTemplate);
router.get("/pages", getPages);
router.get("/pages/:id", getPage); 
router.post("/add_page", createPage);
router.put("/update_page/:id", updatePage);
router.delete("/delete_page/:id", deletePage);

router.get('/page-components', getPageComponents);
router.post('/page-components', createPageComponent);
router.put('/page-components/:id', updatePageComponent);
router.delete('/page-components/:id', deletePageComponent);


// New API for template builder
router.get("/template-sections/:templateId",  getTemplateSections);      // List sections for a template
router.post("/selected-template",  setSelectedTemplate);                // Set current template
router.get("/selected-sections",  getSelectedSections);                 // Get selected sections
router.post("/selected-sections",  setSelectedSections);                // Set selected sections/order

// Webstore builder component CRUD
router.get("/components", getComponents);
router.post("/components", createComponent);
router.put("/components/:id", updateComponent);
router.delete("/components/:id", deleteComponent);

router.get("/selected-template",  getSalesChannelTemplate);                 // Get current template
router.put("/web_templates/:templateId/sections", updateTemplateSections)
router.get("/categories-with-count", getCategoriesWithCount)
router.get("/featured_products", getFeaturedProducts)
router.get("/bestselling_products", getBestSellingProducts)
router.get("/getallcollections", getCollections)
router.get("/collections/:collection_id/products", getCollectionProducts)
router.get("/special_products", getSpecialProducts) 




module.exports = router;
