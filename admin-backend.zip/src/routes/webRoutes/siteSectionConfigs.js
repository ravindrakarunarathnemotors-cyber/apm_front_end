const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const {getCategoriesWithCount} = require("../../controllers/webController");


// POST /api/site-section-configs/bootstrap
// Creates one row per section for a merchant+template by copying defaults
router.post('/bootstrap', async (req, res) => {
  const { merchant_id, template_id, includeHidden = false } = req.body;

  if (!merchant_id || !template_id) {
    return res.status(400).json({ error: 'merchant_id and template_id are required' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const insertSql = `
      INSERT INTO public.site_section_configs
        (merchant_id, template_id, template_section_id, sort_order, enabled, config)
      SELECT
        $1,
        s.template_id,
        s.id,
        COALESCE(s."order", 0),
        COALESCE(s.display, true),
        COALESCE(s.default_config, '{}'::jsonb)
      FROM public.web_template_sections s
      WHERE s.template_id = $2
        ${includeHidden ? '' : 'AND COALESCE(s.display, true) = true'}
      ON CONFLICT (merchant_id, template_section_id) DO NOTHING
      RETURNING template_section_id;
    `;

    const r = await client.query(insertSql, [merchant_id, template_id]);
    await client.query('COMMIT');

    return res.json({
      created: r.rowCount,
      section_ids: r.rows.map(x => x.template_section_id),
      message: r.rowCount ? 'Bootstrapped' : 'Already initialized'
    });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('bootstrap error', e);
    return res.status(500).json({ error: 'Internal server error' });
  } finally {
    client.release();
  }
});



// GET: fetch site section config
router.get('/', async (req, res) => {
  const { merchant_id, template_section_id } = req.query;

  if (!merchant_id || !template_section_id) {
    return res.status(400).json({ error: 'Missing required params' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM site_section_configs WHERE merchant_id = $1 AND template_section_id = $2 LIMIT 1',
      [merchant_id, template_section_id]
    );
    console.log(result.rows); 
    res.json(result.rows[0] || null);
  } catch (err) {
    console.error('Error fetching site section config:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});



// PUT: insert/update config
router.put('/upsert', async (req, res) => {
  try {
    let { merchant_id, template_id, template_section_id, config, enabled } = req.body;

    // coerce to numbers and validate
    const mId = Number(merchant_id);
    const tId = Number(template_id);
    const sId = Number(template_section_id);
    console.log(req.body, mId, tId, sId)
    if (!Number.isFinite(mId) || !Number.isFinite(tId) || !Number.isFinite(sId)) {
      return res.status(400).json({ error: 'merchant_id, template_id, template_section_id must be numbers' });
    }
    if (config == null || typeof config !== 'object') {
      return res.status(400).json({ error: 'config must be a JSON object' });
    }
    if (enabled === undefined) enabled = true; // keep previous default

    const { rows } = await pool.query(
      `
      INSERT INTO public.site_section_configs
        (merchant_id, template_id, template_section_id, enabled, config)
      VALUES ($1, $2, $3, $4, $5::jsonb)
      ON CONFLICT (merchant_id, template_section_id)
      DO UPDATE SET
        template_id = EXCLUDED.template_id,
        enabled     = EXCLUDED.enabled,
        config      = EXCLUDED.config,
        updated_at  = now()
      RETURNING id, merchant_id, template_id, template_section_id, sort_order, enabled, config, created_at, updated_at;
      `,
      [mId, tId, sId, !!enabled, JSON.stringify(config)]
    );

    return res.json(rows[0]);
  } catch (err) {
    console.error('Error saving site section config:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


router.get('/categories-with-count', getCategoriesWithCount)

module.exports = router;
