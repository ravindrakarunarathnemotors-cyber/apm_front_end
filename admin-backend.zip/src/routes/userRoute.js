const express = require("express");
const { login } = require("../controllers/userController");
const createRateLimiter = require("../middleware/rateLimiter");
const { ipKeyGenerator } = require("express-rate-limit");
const router = express.Router();
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");

// 1. IP-based limiter
const loginIpLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: "Too many login attempts from this IP",
});

// 2. Username-based limiter
const loginUserLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: "Too many login attempts for this user",
  keyGenerator: (req) => {
    const email = req.body?.email?.toLowerCase()?.trim();
    return email ? `user:${email}` : `ip:${ipKeyGenerator(req.ip)}`;
  },
});

// LOGIN ROUTE (SMART PROTECTION)
router.post("/login", loginIpLimiter, loginUserLimiter, login);

router.get("/main_menu", async (req, res) => {
  try {
    const query = `SELECT id, name,sidebar_order as order_index FROM uimenudata WHERE parent_id IS NULL AND show = true ORDER BY sidebar_order ASC`;
    const result = await pool.query(query);
    res.status(200).json({ message: " success", result: result.rows });
  } catch (error) {
    console.error("Error retrieving main menu:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/save_main_menu", async (req, res) => {
  const { menus } = req.body;
  if (!Array.isArray(menus))
    return res.status(400).json({ error: "menus must be an array" });
  console.log(menus);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const sql = `
      UPDATE uimenudata SET sidebar_order = $1
      WHERE id = $2
    `;

    for (const menu of menus) {
      // <-- for...of here
      const id = Number(menu.id);
      const orderIndex = Number(menu.order);
      if (!Number.isFinite(id) || !Number.isFinite(orderIndex)) {
        throw new Error(`Invalid id/order_index: ${JSON.stringify(menu)}`);
      }
      const result = await client.query(sql, [orderIndex, id]); // await is fine here
      if (result.rowCount === 0)
        return res.status(404).json({ error: "Menu not found" });
    }

    await client.query("COMMIT");
    res.json({ message: "success" });
  } catch (e) {
    await client.query("ROLLBACK");
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    client.release();
  }
});

router.get("/main_menu_dropdown", async (req, res) => {
  try {
    const query = `SELECT id as value, name as label FROM uimenudata WHERE parent_id IS NULL AND show = true ORDER BY sidebar_order ASC`;
    const result = await pool.query(query);
    res.status(200).json({ message: " success", result: result.rows });
  } catch (error) {
    console.error("Error retrieving main menu:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/sub_menu", async (req, res) => {
  const { menu_id } = req.body;
  try {
    const query = `SELECT id, name,sidebar_order as order_index FROM uimenudata WHERE  parent_id = $1 ORDER BY sidebar_order ASC`;
    const result = await pool.query(query, [menu_id]);
    res.status(200).json({ message: " success", result: result.rows });
  } catch (error) {
    console.error("Error retrieving main menu:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/get_employee", authenticateToken, async (req, res) => {

  try {
    const query = `SELECT
    e.employee_id,
    e.first_name,
    e.last_name,
    e.email,
    e.contact_no
FROM employees e
WHERE NOT EXISTS (
    SELECT 1
    FROM users u
    WHERE u.employee_id = e.employee_id
);`;
    const result = await pool.query(query);
    return res.status(200).json({ message: " success", result: result.rows });

  } catch (error) {
    console.error("Error retrieving employee:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/all_get_employee", authenticateToken, async (req, res) => {

  try {
    const query = `SELECT
    e.employee_id,
    e.first_name,
    e.last_name,
    e.email,
    e.contact_no
FROM employees e;`;
    const result = await pool.query(query);
    return res.status(200).json({ message: " success", result: result.rows });

  } catch (error) {
    console.error("Error retrieving employee:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/password-reminder", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.user_id;

    const result = await pool.query(
      `
      SELECT is_first_time, password_reminder_shown_at
      FROM users
      WHERE user_id = $1
      `,
      [userId]
    );

    const user = result.rows[0];

    let showReminder = false;

    if (user.is_first_time) {
      const today = new Date().toISOString().split("T")[0];

      const lastShown = user.password_reminder_shown_at
        ? user.password_reminder_shown_at.toISOString().split("T")[0]
        : null;

      if (lastShown !== today) {
        showReminder = true;

        await pool.query(
          `
          UPDATE users
          SET password_reminder_shown_at = NOW()
          WHERE user_id = $1
          `,
          [userId]
        );
      }
    }

    res.json({
      showReminder,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
});

module.exports = router;
