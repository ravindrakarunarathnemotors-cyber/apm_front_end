const express = require("express");
const { login } = require("../controllers/userController");
const router = express.Router();
const pool = require("../config/db");

router.post("/login", login);

router.get('/main_menu', async (req, res) => {
  try {
    const query = `SELECT id, name,sidebar_order as order_index FROM uimenudata WHERE parent_id IS NULL AND show = true ORDER BY sidebar_order ASC`;
    const result = await pool.query(query)
    res.status(200).json({ message: " success", result: result.rows })

  } catch (error) {
    console.error('Error retrieving main menu:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


router.post('/save_main_menu', async (req, res) => {
  const { menus } = req.body;
  if (!Array.isArray(menus)) return res.status(400).json({ error: 'menus must be an array' });
  console.log(menus)
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const sql = `
      UPDATE uimenudata SET sidebar_order = $1
      WHERE id = $2
    `;

    for (const menu of menus) {                // <-- for...of here
      const id = Number(menu.id);
      const orderIndex = Number(menu.order);
      if (!Number.isFinite(id) || !Number.isFinite(orderIndex)) {
        throw new Error(`Invalid id/order_index: ${JSON.stringify(menu)}`);
      }
      const result = await client.query(sql, [orderIndex, id]); // await is fine here
      if (result.rowCount === 0) return res.status(404).json({ error: 'Menu not found' });
    }

    await client.query('COMMIT');
    res.json({ message: 'success' });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).json({ error: 'Internal server error' });
  } finally {
    client.release();
  }
});


router.get('/main_menu_dropdown', async (req, res) => {
  try {
    const query = `SELECT id as value, name as label FROM uimenudata WHERE parent_id IS NULL AND show = true ORDER BY sidebar_order ASC`;
    const result = await pool.query(query)
    res.status(200).json({ message: " success", result: result.rows })

  } catch (error) {
    console.error('Error retrieving main menu:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/sub_menu', async (req, res) => {
  const { menu_id } = req.body
  try {
    const query = `SELECT id, name,sidebar_order as order_index FROM uimenudata WHERE  parent_id = $1 ORDER BY sidebar_order ASC`;
    const result = await pool.query(query, [menu_id])
    res.status(200).json({ message: " success", result: result.rows })

  } catch (error) {
    console.error('Error retrieving main menu:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


module.exports = router;
