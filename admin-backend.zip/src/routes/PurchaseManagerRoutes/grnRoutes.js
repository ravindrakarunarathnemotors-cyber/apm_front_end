const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

router.post("/create-grn", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { po_id, supplier_id, remark, received_by, items } = req.body;

    const { user_id, merchant_id, outlet_id } = req.user;

    if (!outlet_id) {
      throw new Error("outlet_id missing from authentication context");
    }

    // ============================
    // Basic Validation
    // ============================

    if (!po_id || !supplier_id || !received_by) {
      return res.status(400).json({
        message: "Missing required fields",
      });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        message: "GRN items required",
      });
    }

    await client.query("BEGIN");

    // ============================
    // Calculate Header Totals
    // ============================

    let total_received_qty = 0;
    let total_amount = 0;
    let isPartial = false;

    for (const item of items) {
      const receivedQty = Number(item.received_qty || 0);
      const orderedQty = Number(item.ordered_qty || 0);
      const unitCost = Number(item.unit_cost || 0);
      const per = Number(item.amount_per_unit || 0);

      if (receivedQty < 0 || unitCost < 0) {
        throw new Error("Invalid quantity or cost");
      }

      if (receivedQty < orderedQty) {
        isPartial = true;
      }

      const rowTotal = receivedQty * unitCost;

      total_received_qty += receivedQty;
      total_amount += rowTotal;
    }

    const status = isPartial ? "partial" : "received";

    // ============================
    // Insert GRN Header
    // ============================

    const headerResult = await client.query(
      `
      INSERT INTO grn_header (
        po_id,
        supplier_id,
        status,
        total_received_qty,
        total_amount,
        remark,
        received_by,
        received_date
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
      RETURNING grn_id
      `,
      [
        po_id,
        supplier_id,
        status,
        total_received_qty,
        Number(total_amount.toFixed(2)),
        remark || null,
        received_by,
      ],
    );

    const grn_id = headerResult.rows[0].grn_id;

    // ============================
    // Insert GRN Items
    // ============================

    for (const item of items) {
      const {
        po_item_id,
        product_id,
        variant_id,
        batch_number,
        ordered_qty,
        received_qty,
        unit_cost,
        measurement_unit,
        amount_per_unit,
      } = item;

      const qty = Number(received_qty || 0);
      const unitCost = Number(unit_cost || 0);
      const per = Number(amount_per_unit || 0);

      /*
       * Empty string becomes NULL.
       * A real batch number is trimmed and used for batch-wise inventory.
       */
      const selectedBatch =
        typeof batch_number === "string" && batch_number.trim() !== ""
          ? batch_number.trim()
          : null;

      const calculatedLineTotal = qty * unitCost;
      const finalLineTotal = Number(calculatedLineTotal.toFixed(2));

      await client.query(
        `
        INSERT INTO grn_items (
          grn_id,
          po_id,
          po_item_id,
          product_id,
          variant_id,
          batch_number,
          ordered_qty,
          received_qty,
          unit_cost,
          measurement_unit,
          amount_per_unit,
          line_total
        )
        VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10, $11, $12
        )
        `,
        [
          grn_id,
          po_id,
          po_item_id,
          product_id,
          variant_id || null,
          selectedBatch,
          ordered_qty,
          qty,
          unitCost,
          measurement_unit || null,
          per || null,
          finalLineTotal,
        ],
      );

      // ============================
      // BATCH-WISE STOCK INTEGRATION
      // ============================

      if (variant_id && qty > 0) {
        /*
         * If selectedBatch has a value:
         * Get the latest inventory balance for that exact batch.
         *
         * If selectedBatch is null:
         * Get the latest non-batch inventory balance only.
         */
        const prevStockRes = await client.query(
          `
          SELECT
            new_quantity
          FROM inventory
          WHERE variant_id = $1
            AND outlet_id = $2
            AND merchant_id = $3
            AND status = 'active'
            AND batch_number IS NOT DISTINCT FROM $4::text
          ORDER BY
            last_updated DESC NULLS LAST,
            inventory_id DESC
          LIMIT 1
          `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            selectedBatch,
          ],
        );

        const previous_quantity = Number(
          prevStockRes.rows[0]?.new_quantity ?? 0,
        );

        const adjust_quantity = qty;
        const new_quantity = previous_quantity + adjust_quantity;

        const batchLabel = selectedBatch || "No Batch";

        const comment =
          `GRN STOCK IN | GRN ID: ${grn_id}` +
          ` | PO: ${po_id}` +
          ` | Variant: ${variant_id}` +
          ` | Batch: ${batchLabel}`;

        await client.query(
          `
          INSERT INTO inventory (
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            updated_by,
            comment,
            system_module,
            previous_quantity,
            adjust_quantity,
            new_quantity,
            status
          )
          VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, 'stock in', $8, $9, $10, 'active'
          )
          `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            selectedBatch,
            user_id,
            comment,
            previous_quantity,
            adjust_quantity,
            new_quantity,
          ],
        );

        // ============================
        // Batch-wise Inventory Admin Log
        // ============================

        await client.query(
          `
          INSERT INTO admin_log (
            user_id,
            module,
            log,
            date
          )
          VALUES ($1, 'Inventory', $2, NOW())
          `,
          [
            received_by,
            `GRN STOCK IN | GRN: ${grn_id}` +
              ` | PO: ${po_id}` +
              ` | Variant: ${variant_id}` +
              ` | Batch: ${batchLabel}` +
              ` | Prev: ${previous_quantity}` +
              ` | +${adjust_quantity}` +
              ` | New: ${new_quantity}`,
          ],
        );
      }

      // ============================
      // Detailed GRN Item Log
      // ============================

      const itemBatchLabel = selectedBatch || "No Batch";

      await client.query(
        `
        INSERT INTO admin_log (
          user_id,
          module,
          log,
          date
        )
        VALUES ($1, 'GRN ITEM', $2, NOW())
        `,
        [
          received_by,
          `GRN ITEM | GRN: ${grn_id}` +
            ` | PO Item: ${po_item_id}` +
            ` | Variant: ${variant_id || "N/A"}` +
            ` | Batch: ${itemBatchLabel}` +
            ` | Qty: ${qty}` +
            ` | Per: ${per || 1}` +
            ` | Unit Cost: ${unitCost}` +
            ` | Line Total: ${finalLineTotal}`,
        ],
      );
    }

    // ============================
    // GRN Header Admin Log
    // ============================

    await client.query(
      `
      INSERT INTO admin_log (
        user_id,
        module,
        log,
        date
      )
      VALUES ($1, 'GRN', $2, NOW())
      `,
      [
        received_by,
        `Created GRN ID: ${grn_id}` +
          ` | PO: ${po_id}` +
          ` | Supplier: ${supplier_id}` +
          ` | Total Qty: ${total_received_qty}` +
          ` | Total Amount: ${Number(total_amount.toFixed(2))}` +
          ` | Status: ${status}`,
      ],
    );

    await client.query("COMMIT");

    return res.status(201).json({
      success: true,
      message: "GRN created and batch-wise stock updated successfully",
      grn_id,
    });
  } catch (error) {
    await client.query("ROLLBACK");

    console.error("GRN Creation Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Server error while creating GRN",
    });
  } finally {
    client.release();
  }
});

// fetch po details to add grn

router.get("/grn-received-summary/:po_id", authenticateToken, async (req, res) => {
  
    const { po_id } = req.params;

    if (!po_id) {
      return res.status(400).json({
        message: "po_id is required",
      });
    }

    const client = await pool.connect();

    try {
      const query = `
        SELECT
          pi.po_item_id,
          pi.product_id,
          pi.variant_id,
          pi.req_qty AS ordered_qty,

          -- Total received across all GRNs
          COALESCE(SUM(gi.received_qty), 0) AS total_received_qty,

          -- Remaining qty
          (pi.req_qty - COALESCE(SUM(gi.received_qty), 0)) AS remaining_qty

        FROM po_items pi

        LEFT JOIN grn_items gi
          ON gi.po_item_id = pi.po_item_id

        LEFT JOIN grn_header gh
          ON gh.grn_id = gi.grn_id
          AND gh.status != 'cancelled'

        WHERE pi.po_id = $1

        GROUP BY
          pi.po_item_id,
          pi.product_id,
          pi.variant_id,
          pi.req_qty

        ORDER BY pi.po_item_id ASC
      `;

      const result = await client.query(query, [po_id]);

      return res.status(200).json({
        message: "success",
        data: result.rows,
      });
    } catch (error) {
      console.error("Fetch GRN Received Summary Error:", error);

      return res.status(500).json({
        message: "Internal server error",
      });
    } finally {
      client.release();
    }
  },
);

// approved po list
router.get("/approved-po-list", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { search } = req.query;

    let query = `
      SELECT
        ph.po_id,
        ph.supplier_id,
        s.business_name,

        /* GRN EXISTS FLAG */
        EXISTS (
          SELECT 1
          FROM grn_header gh
          WHERE gh.po_id = ph.po_id
        ) AS grn

      FROM po_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

        WHERE 1=1
        AND LOWER(ph.status) = 'approved'
    `;

    const values = [];

    // 🔎 Search filter
    if (search && search.trim() !== "") {
      query += `
        AND (
          CAST(ph.po_id AS TEXT) ILIKE $1
          OR s.business_name ILIKE $1
        )
      `;
      values.push(`%${search}%`);
    }

    query += `
      ORDER BY ph.po_id DESC
      LIMIT 20
    `;

    const result = await client.query(query, values);

    return res.status(200).json({
      message: "success",
      data: result.rows, // structure unchanged
    });
  } catch (error) {
    console.error("Fetch PO List Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// grn details fetch

router.get("/grn-details/:grn_id", authenticateToken, async (req, res) => {
  const { grn_id } = req.params;

  if (!grn_id) {
    return res.status(400).json({
      message: "grn_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= FETCH GRN HEADER ================= */

    const headerQuery = `
      SELECT
        gh.grn_id,
        gh.po_id,
        gh.grn_date,
        gh.status,
        gh.total_received_qty,
        gh.total_amount,
        gh.remark,
        gh.received_date,
        gh.authorized_date,
        gh.created_at,

        s.supplier_id,
        s.business_name,
        s.address,
        s.mobile_no,
        s.contact_no,
        s.email,

        CONCAT(u.first_name, ' ', u.last_name) AS received_user_name,
        CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name

      FROM grn_header gh
      LEFT JOIN suppliers s ON s.supplier_id = gh.supplier_id
      LEFT JOIN users u ON u.user_id = gh.received_by
      LEFT JOIN users au ON au.user_id = gh.authorized_by

      WHERE gh.grn_id = $1
    `;

    const headerResult = await client.query(headerQuery, [grn_id]);

    if (headerResult.rows.length === 0) {
      return res.status(404).json({
        message: "GRN not found",
      });
    }

    const headers = headerResult.rows;

    /* ================= FETCH CURRENCY ================= */

    const systemSettingsResult = await client.query(`
      SELECT currency
      FROM system_settings
      LIMIT 1
    `);

    const currency =
      systemSettingsResult.rows.length > 0
        ? systemSettingsResult.rows[0].currency
        : null;

    /* ================= FETCH BRANDING ================= */

    const brandingResult = await client.query(`
  SELECT company_name, logo_url_white
  FROM branding_settings
  LIMIT 1
`);

    const company_name =
      brandingResult.rows.length > 0
        ? brandingResult.rows[0].company_name
        : null;

    const logo_url_white =
      brandingResult.rows.length > 0
        ? brandingResult.rows[0].logo_url_white
        : null;

    /* ================= FETCH GRN ITEMS (UPDATED) ================= */

    const itemsQuery = `
      SELECT
        gi.grn_item_id,
        gi.grn_id,
        gi.product_id,
        gi.variant_id,
        gi.ordered_qty,
        gi.received_qty,
        gi.returned_qty,
        gi.unit_cost,
        gi.batch_number,
        gi.measurement_unit,      -- FROM GRN TABLE
        gi.amount_per_unit,       -- FROM GRN TABLE
        gi.line_total,            -- GENERATED COLUMN
        gi.created_at,

        p.title AS product_title,

        m.measurement_value,      -- join using grn measurement_unit

        pv.variant_value,
        pv.price AS variant_price,
        pv.weight,
        pv.barcode,

        inv.current_stock,
        pm.media_url AS main_image,
        vimg.variant_image

      FROM grn_items gi

      LEFT JOIN products p
        ON p.product_id = gi.product_id

      LEFT JOIN product_variants pv
        ON pv.variant_id = gi.variant_id

      --  IMPORTANT: JOIN USING gi.measurement_unit
      LEFT JOIN measurements m
        ON m.measurement_id = gi.measurement_unit
        AND m.status = 'active'

      LEFT JOIN product_media pm
        ON pm.product_id = p.product_id
        AND pm.main = true
        AND pm.variant_id IS NULL

      LEFT JOIN LATERAL (
        SELECT i.new_quantity AS current_stock
        FROM inventory i
        WHERE i.variant_id = gi.variant_id
        ORDER BY i.inventory_id DESC
        LIMIT 1
      ) inv ON true

      LEFT JOIN LATERAL (
        SELECT media_url AS variant_image
        FROM product_media
        WHERE product_id = gi.product_id
          AND variant_id = gi.variant_id
          AND main = true
        ORDER BY created_at ASC
        LIMIT 1
      ) vimg ON true

      WHERE gi.grn_id = $1

      ORDER BY p.title ASC
    `;

    const itemsResult = await client.query(itemsQuery, [grn_id]);

    return res.status(200).json({
      message: "success",
      data: {
        headers,
        items: itemsResult.rows,
        currency,
        logo_url_white,
        company_name,
      },
    });
  } catch (error) {
    console.error("Fetch GRN Details Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// grn list

router.get("/grn-list", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    let {
      supplier_id,
      status,
      date_from,
      date_to,
      page = 1,
      limit = 25,
    } = req.query;

    page = parseInt(page);
    limit = parseInt(limit);
    const offset = (page - 1) * limit;

    let conditions = [];
    let values = [];
    let index = 1;

    /* ================= FILTER: SUPPLIER ================= */
    if (supplier_id && supplier_id !== "all") {
      conditions.push(`gh.supplier_id = $${index++}`);
      values.push(supplier_id);
    }

    /* ================= FILTER: STATUS ================= */
    if (status && status !== "all") {
      conditions.push(`gh.status = $${index++}`);
      values.push(status);
    }

    /* ================= FILTER: DATE RANGE ================= */
    if (date_from) {
      conditions.push(`gh.received_date >= $${index++}`);
      values.push(date_from);
    }

    if (date_to) {
      conditions.push(`gh.received_date <= $${index++}`);
      values.push(date_to);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    /* ================= COUNT QUERY ================= */

    const countQuery = `
      SELECT COUNT(*) 
      FROM grn_header gh
      ${whereClause}
    `;

    const countResult = await client.query(countQuery, values);
    const totalRecords = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalRecords / limit);

    /* ================= MAIN QUERY ================= */

    const mainQuery = `
      SELECT
        gh.grn_id,
        gh.po_id,
        gh.status,
        gh.total_received_qty,
        gh.total_amount,
        gh.received_date,
        gh.authorized_date,
        gh.created_at,

        s.business_name,
        s.supplier_id,

        CONCAT(u.first_name, ' ', u.last_name) AS received_user_name

      FROM grn_header gh

      LEFT JOIN suppliers s
        ON s.supplier_id = gh.supplier_id

      LEFT JOIN users u
        ON u.user_id = gh.received_by

      ${whereClause}

      ORDER BY gh.grn_id DESC
      LIMIT $${index++}
      OFFSET $${index++}
    `;

    const finalValues = [...values, limit, offset];

    const result = await client.query(mainQuery, finalValues);

    return res.status(200).json({
      success: true,
      message: "GRN list fetched successfully",
      data: {
        records: result.rows,
        pagination: {
          current_page: page,
          per_page: limit,
          total_records: totalRecords,
          total_pages: totalPages,
        },
      },
    });
  } catch (error) {
    console.error("Fetch GRN List Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// grn totals modal summary
router.get("/grn-totals/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= FETCH GRN LIST ================= */

    const grnQuery = `
      SELECT
        gh.grn_id,
        gh.grn_date,
        gh.po_id,

        gh.supplier_id,
        s.business_name,

        gh.status,
        gh.total_received_qty,
        gh.total_amount,

        gh.received_by,
        gh.authorized_by,
        gh.authorized_date,

        COUNT(*) OVER () AS total_grns
      FROM grn_header gh
      LEFT JOIN suppliers s
        ON s.supplier_id = gh.supplier_id
      WHERE gh.po_id = $1
      ORDER BY gh.grn_id DESC
    `;

    const grnResult = await client.query(grnQuery, [po_id]);

    /* ================= FETCH TOTAL RETURN QTY ================= */

    const prnTotalsQuery = `
      SELECT
        COALESCE(SUM(ph.total_return_qty), 0) AS total_return_qty
      FROM prn_header ph
      WHERE ph.po_id = $1
    `;

    const prnTotalsResult = await client.query(prnTotalsQuery, [po_id]);

    /* ================= FETCH RETURNED ITEM COUNT ================= */

    const returnedItemCountQuery = `
      SELECT
        COUNT(DISTINCT pi.po_item_id) AS returned_item_count
      FROM prn_items pi
      JOIN prn_header ph
        ON ph.prn_id = pi.prn_id
      WHERE ph.po_id = $1
    `;

    const returnedItemCountResult = await client.query(returnedItemCountQuery, [
      po_id,
    ]);

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      message: "success",
      data: {
        total_grns: grnResult.rows[0]?.total_grns || 0,

        // ✅ NEW FIELDS
        total_return_qty: prnTotalsResult.rows[0]?.total_return_qty || 0,

        returned_item_count:
          returnedItemCountResult.rows[0]?.returned_item_count || 0,

        rows: grnResult.rows,
      },
    });
  } catch (error) {
    console.error("Fetch GRN Totals By PO Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// grn summary

router.get("/grn-summary/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    const query = `
        SELECT
          gh.grn_id,
          gh.grn_date,
          gh.po_id,
          gh.supplier_id,
          s.business_name,

          gh.status,
          gh.total_received_qty,
          gh.total_amount,
          gh.remark,

          gh.received_by,
          CONCAT(u.first_name, ' ', u.last_name) AS received_user_name,
          gh.received_date,

          gh.authorized_by,
          CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name,
          gh.authorized_date,

          gh.created_at
        FROM grn_header gh
        LEFT JOIN suppliers s
          ON s.supplier_id = gh.supplier_id
        LEFT JOIN users u
          ON u.user_id = gh.received_by
        LEFT JOIN users au
          ON au.user_id = gh.authorized_by
        WHERE gh.po_id = $1
        ORDER BY gh.grn_id DESC
      `;

    const result = await client.query(query, [po_id]);

    return res.status(200).json({
      message: "success",
      data: result.rows,
    });
  } catch (error) {
    console.error("Fetch GRNs by PO Error:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// grn overview summary

router.get("/grn-overview-po/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= FETCH GRN HEADERS (UNCHANGED) ================= */

    const headerQuery = `
      SELECT
        gh.grn_id,
        gh.po_id,
        gh.grn_date,
        gh.status,
        gh.total_received_qty,
        gh.total_amount,
        gh.remark,
        gh.received_date,
        gh.authorized_date,
        gh.created_at,

        s.supplier_id,
        s.business_name,
        s.address,
        s.mobile_no,
        s.contact_no,
        s.email,

        CONCAT(u.first_name, ' ', u.last_name) AS received_user_name,
        CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name

      FROM grn_header gh
      LEFT JOIN suppliers s ON s.supplier_id = gh.supplier_id
      LEFT JOIN users u ON u.user_id = gh.received_by
      LEFT JOIN users au ON au.user_id = gh.authorized_by
      WHERE gh.po_id = $1
      ORDER BY gh.grn_id DESC
    `;

    const headerResult = await client.query(headerQuery, [po_id]);

    if (headerResult.rows.length === 0) {
      return res.status(200).json({
        message: "success",
        data: {
          headers: [],
          items: [],
          currency: null,
          logo_url_white: null,
        },
      });
    }

    const headers = headerResult.rows;

    /* ================= FETCH CURRENCY ================= */

    const systemSettingsResult = await client.query(`
      SELECT currency FROM system_settings LIMIT 1
    `);

    const currency =
      systemSettingsResult.rows.length > 0
        ? systemSettingsResult.rows[0].currency
        : null;

    /* ================= FETCH BRANDING LOGO ================= */

    const brandingResult = await client.query(`
      SELECT logo_url_white FROM branding_settings LIMIT 1
    `);

    const logo_url_white =
      brandingResult.rows.length > 0
        ? brandingResult.rows[0].logo_url_white
        : null;

    /* ================= AGGREGATE ITEMS FOR ENTIRE PO ================= */

    const itemsQuery = `
      SELECT
        gi.variant_id,
        gi.product_id,

        SUM(COALESCE(gi.ordered_qty, 0))::numeric   AS ordered_qty,
        SUM(COALESCE(gi.received_qty, 0))::numeric  AS received_qty,

        /* ✅ Returned Qty From PRN Tables */
        COALESCE(SUM(DISTINCT prn_totals.return_qty), 0)::numeric AS returned_qty,

        SUM(COALESCE(gi.line_total, 0))::numeric    AS line_total,
        MAX(gi.unit_cost)::numeric                  AS unit_cost,

        p.title AS product_title,
        p.amount_per_unit,
        p.measurement_id,
        m.measurement_value,

        pv.variant_value,
        pv.price AS variant_price,
        pv.weight,
        pv.barcode,

        inv.current_stock,
        pm.media_url AS main_image,
        vimg.variant_image

      FROM grn_items gi
      JOIN grn_header gh ON gh.grn_id = gi.grn_id

      /* ✅ JOIN PRN HEADER (by PO) */
      LEFT JOIN prn_header ph
        ON ph.po_id = gh.po_id

      /* ✅ JOIN PRN ITEMS (by product + variant) */
      LEFT JOIN LATERAL (
        SELECT
          SUM(pi.return_qty) AS return_qty
        FROM prn_items pi
        WHERE pi.prn_id = ph.prn_id
          AND pi.product_id = gi.product_id
          AND (
                (pi.variant_id IS NULL AND gi.variant_id IS NULL)
                OR pi.variant_id = gi.variant_id
              )
      ) prn_totals ON true

      LEFT JOIN products p ON p.product_id = gi.product_id
      LEFT JOIN product_variants pv ON pv.variant_id = gi.variant_id
      LEFT JOIN measurements m
        ON m.measurement_id = p.measurement_id
        AND m.status = 'active'

      LEFT JOIN product_media pm
        ON pm.product_id = p.product_id
        AND pm.main = true
        AND pm.variant_id IS NULL

      LEFT JOIN LATERAL (
        SELECT i.new_quantity AS current_stock
        FROM inventory i
        WHERE i.variant_id = gi.variant_id
        ORDER BY i.inventory_id DESC
        LIMIT 1
      ) inv ON true

      LEFT JOIN LATERAL (
        SELECT media_url AS variant_image
        FROM product_media
        WHERE product_id = gi.product_id
          AND variant_id = gi.variant_id
          AND main = true
        ORDER BY created_at ASC
        LIMIT 1
      ) vimg ON true

      WHERE gh.po_id = $1

      GROUP BY
        gi.variant_id,
        gi.product_id,
        p.title,
        p.amount_per_unit,
        p.measurement_id,
        m.measurement_value,
        pv.variant_value,
        pv.price,
        pv.weight,
        pv.barcode,
        inv.current_stock,
        pm.media_url,
        vimg.variant_image

      ORDER BY p.title ASC, pv.variant_value ASC
    `;

    const itemsResult = await client.query(itemsQuery, [po_id]);

    return res.status(200).json({
      message: "success",
      data: {
        headers,
        items: itemsResult.rows, // ✅ structure unchanged
        currency,
        logo_url_white,
      },
    });
  } catch (error) {
    console.error("Fetch GRN Overview Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

module.exports = router;
