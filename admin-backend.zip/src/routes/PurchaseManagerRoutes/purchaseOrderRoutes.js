const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

router.get("/item-search", authenticateToken, async (req, res) => {
  const { search } = req.query;

  if (!search) {
    return res.status(400).json({
      message: "Search query is required",
    });
  }

  const productQuery = `
    SELECT
        p.product_id,
        p.title,
        pm.media_url AS main_img,
        pmd_first.media_url AS first_extra_img,
        p.amount_per_unit,
        p.measurement_id,
        CASE 
            WHEN p.measurement_id = 1 THEN false 
            ELSE true 
        END AS measurement_needed,
        m.measurement_value,

        json_agg(
          vs.variant
          ORDER BY vs.variant->>'variant_value'
        ) AS variants

    FROM products p

    LEFT JOIN LATERAL (
        SELECT DISTINCT
            jsonb_build_object(
                'variant_id', v.variant_id,
                'variant_value', v.variant_value,
               'price', v.cost_per_item,
                'product_id', v.product_id,
                'weight', v.weight,
                'quantity', i.new_quantity,
                'barcode', v.barcode
            ) AS variant
        FROM product_variants v
        LEFT JOIN LATERAL (
            SELECT new_quantity
            FROM inventory
            WHERE variant_id = v.variant_id
            ORDER BY inventory_id DESC
            LIMIT 1
        ) i ON true
        WHERE v.product_id = p.product_id
    ) vs ON true

    LEFT JOIN product_media pm 
        ON pm.product_id = p.product_id
        AND pm.main = true
        AND pm.variant_id IS NULL

    LEFT JOIN measurements m
        ON m.measurement_id = p.measurement_id
        AND m.status = 'active'

    LEFT JOIN LATERAL (
        SELECT media_url
        FROM product_media
        WHERE product_id = p.product_id
          AND main = true
          AND variant_id IS NOT NULL
        ORDER BY created_at ASC
        LIMIT 1
    ) pmd_first ON true

    WHERE p.status = 'active'
      AND (
            p.title ILIKE '%' || $1 || '%'
            OR ($1 ~ '^[0-9]+$' AND p.product_id = $1::INT)
            OR ($1 ~ '^[0-9]+$' AND vs.variant->>'variant_id' = $1)
            OR vs.variant->>'barcode' ILIKE $1
            OR EXISTS (
                SELECT 1
                FROM unnest(p.similar_keywords) kw
                WHERE kw ILIKE '%' || $1 || '%'
            )
          )

    GROUP BY
        p.product_id,
        pm.media_url,
        pmd_first.media_url,
        m.measurement_value

    ORDER BY p.created_at DESC
    LIMIT 10 OFFSET 0
  `;

  try {
    // 🔹 Fetch products
    const { rows } = await pool.query(productQuery, [search.toLowerCase()]);

    // 🔹 Fetch currency from system_settings
    const currencyResult = await pool.query(`
      SELECT currency
      FROM system_settings
      LIMIT 1
    `);

    const currency = currencyResult.rows[0]?.currency || null;

    return res.status(200).json({
      message: "success",
      currency, //  Added once here
      result: rows,
    });
  } catch (error) {
    console.error("Product search error:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

/* ================= CREATE PURCHASE ORDER ================= */

router.post("/create-po", authenticateToken, async (req, res) => {
  const { supplier_id, expected_date, remark, supplier_instructions, items } =
    req.body;

  const generated_user = req.user?.user_id;

  /* ================= VALIDATIONS ================= */

  if (!supplier_id) {
    return res.status(400).json({
      message: "supplier_id is required",
    });
  }

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      message: "At least one PO item is required",
    });
  }

  if (!generated_user) {
    return res.status(401).json({
      message: "Unauthorized user",
    });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    /* ================= CALCULATE TOTALS ================= */

    const po_qty = items.reduce((sum, i) => sum + Number(i.req_qty), 0);

    const po_total_amount = items.reduce(
      (sum, i) => sum + Number(i.line_total || 0),
      0,
    );

    /* ================= INSERT PO HEADER ================= */

    const insertHeaderQuery = `
      INSERT INTO po_header (
        expected_date,
        status,
        supplier_id,
        po_qty,
        remark,
        supplier_instructions,
        po_total_amount,
        generated_user
      )
      VALUES (
        $1, 'pending', $2, $3, $4, $5, $6, $7
      )
      RETURNING po_id
    `;

    const headerValues = [
      expected_date || null,
      supplier_id,
      po_qty,
      remark || null,
      supplier_instructions || null,
      po_total_amount,
      generated_user,
    ];

    const headerResult = await client.query(insertHeaderQuery, headerValues);

    const po_id = headerResult.rows[0].po_id;

    /* ================= INSERT PO ITEMS ================= */

    const insertItemQuery = `
    INSERT INTO po_items (
  po_id,
  variant_id,
  product_id,
  batch_number,
  unit_cost,
  req_qty,
  measurement_unit,
  amount_per_unit,
  line_total
)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `;

    for (const item of items) {
      const itemValues = [
        po_id,
        item.variant_id,
        item.product_id,
        item.batch_number || null,
        item.unit_cost,
        item.req_qty,
        item.measurement_unit || null,
        item.amount_per_unit || null,
        item.line_total || 0,
      ];

      await client.query(insertItemQuery, itemValues);
    }

    await client.query("COMMIT");

    /* ================= ADMIN LOG ================= */

    const logMessage = `
      Created Purchase Order:
      PO ID: ${po_id}
      Supplier ID: ${supplier_id}
      Items: ${items.length}
      Total Qty: ${po_qty}
      Total Amount: ${po_total_amount}
    `;

    await insertAdminLog(generated_user, "PURCHASE_ORDER", logMessage.trim());

    return res.status(201).json({
      message: "Purchase Order created successfully",
      data: { po_id },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create PO Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch active suppliers

router.get("/active-suppliers", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        supplier_id,
        business_name,
        address,
        status,
        created_at
      FROM suppliers
      WHERE status = 'active'
      ORDER BY business_name ASC
    `;

    const result = await pool.query(query);

    return res.status(200).json({
      message: "Active suppliers fetched successfully",
      result: result.rows,
    });
  } catch (error) {
    console.error("Fetch Active Suppliers Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  }
});

// purchase order history / list

router.get("/po-history", authenticateToken, async (req, res) => {
  const {
    supplier_id,
    status,
    date_from,
    date_to,
    page = 1,
    limit = 10,
  } = req.query;

  const pageNumber = Number(page);
  const limitNumber = Number(limit);
  const offset = (pageNumber - 1) * limitNumber;

  const client = await pool.connect();

  try {
    let whereConditions = [];
    let values = [];
    let index = 1;

    /* ================= FILTERS ================= */

    if (supplier_id) {
      whereConditions.push(`ph.supplier_id = $${index}`);
      values.push(supplier_id);
      index++;
    }

    if (status && status !== "all") {
      whereConditions.push(`ph.status = $${index}`);
      values.push(status);
      index++;
    }

    if (date_from) {
      whereConditions.push(`ph.po_date >= $${index}`);
      values.push(date_from);
      index++;
    }

    if (date_to) {
      whereConditions.push(`ph.po_date <= $${index}`);
      values.push(date_to);
      index++;
    }

    const whereClause =
      whereConditions.length > 0
        ? `WHERE ${whereConditions.join(" AND ")}`
        : "";

    /* ================= MAIN QUERY ================= */

    const query = `
      SELECT
        ph.po_id,   -- ✅ FIXED HERE
        ph.po_date,
        ph.expected_date,
        ph.status,
        ph.supplier_id,

        -- Supplier Business Name
        s.business_name,

        ph.po_qty,
        ph.po_total_amount,

        ph.generated_user,

        -- Generated User Full Name
        CONCAT(u.first_name, ' ', u.last_name) AS generated_user_name,

        ph.authorized_by,

        -- Authorized User Full Name
        CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name,

        ph.authorized_date,
        ph.created_at

      FROM po_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

      LEFT JOIN users u
        ON u.user_id = ph.generated_user

      LEFT JOIN users au
        ON au.user_id = ph.authorized_by

      ${whereClause}

      ORDER BY ph.po_id DESC   -- ✅ FIXED HERE
      LIMIT $${index} OFFSET $${index + 1}
    `;

    values.push(limitNumber);
    values.push(offset);

    const result = await client.query(query, values);

    /* ================= COUNT QUERY ================= */

    const countQuery = `
      SELECT COUNT(*)
      FROM po_header ph
      ${whereClause}
    `;

    const countResult = await client.query(
      countQuery,
      values.slice(0, index - 1),
    );

    return res.status(200).json({
      message: "success",
      data: result.rows,
      pagination: {
        total: Number(countResult.rows[0].count),
        page: pageNumber,
        limit: limitNumber,
      },
    });
  } catch (error) {
    console.error("Fetch PO List Error:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch view details from header and items tables

router.get("/po-details/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= FETCH PO HEADER ================= */

    const headerQuery = `
      SELECT
        ph.po_id,
        ph.po_date,
        ph.expected_date,
        ph.status,
        ph.po_qty,
        ph.po_total_amount,
        ph.remark,
        ph.supplier_instructions,
        ph.created_at,

        -- Supplier
        s.supplier_id,
        s.business_name,
        s.address,
        s.mobile_no,
        s.contact_no,
        s.email,

        -- Generated User
        CONCAT(u.first_name, ' ', u.last_name) AS generated_user_name,

        -- Authorized User
        CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name,
        ph.authorized_date

      FROM po_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

      LEFT JOIN users u
        ON u.user_id = ph.generated_user

      LEFT JOIN users au
        ON au.user_id = ph.authorized_by

      WHERE ph.po_id = $1
    `;

    const headerResult = await client.query(headerQuery, [po_id]);

    if (headerResult.rows.length === 0) {
      return res.status(404).json({
        message: "Purchase Order not found",
      });
    }

    const header = headerResult.rows[0];

    /* ================= FETCH BRANDING SETTINGS ================= */

    const brandingQuery = `
      SELECT
        company_name,
        slogan,
        address_1,
        address_2,
        hotline,
        customer_support_phone,
        support_email,
        info_email,
        logo_url_white,
        billing_email,
        website_url
      FROM branding_settings
      WHERE id = 1
    `;

    const brandingResult = await client.query(brandingQuery);
    const branding_settings = brandingResult.rows;

    /* ================= FETCH SYSTEM SETTINGS ================= */

    const systemSettingsQuery = `
      SELECT currency
      FROM system_settings
      LIMIT 1
    `;

    const systemSettingsResult = await client.query(systemSettingsQuery);

    const currency =
      systemSettingsResult.rows.length > 0
        ? systemSettingsResult.rows[0].currency
        : null;

    /* ================= FETCH PO ITEMS ================= */

    const itemsQuery = `
      SELECT
        pi.po_item_id,
        pi.product_id,
        pi.variant_id,
        pi.batch_number,
        pi.unit_cost,
        pi.req_qty,

        -- Fields from po_items
        pi.measurement_unit,
        pi.amount_per_unit,
        pi.line_total,

        -- Product
        p.title AS product_title,

        -- Measurement
        m.measurement_value,

        -- Variant
        pv.variant_value,
        pv.price AS variant_price,
        pv.weight,
        pv.barcode,

   -- All active batches belonging to this variant
COALESCE(
  bm_batches.batch_numbers,
  ARRAY[]::text[]
) AS batch_numbers,

-- Batch number with its cost price
COALESCE(
  bm_batches.batch_details,
  '[]'::jsonb
) AS batch_details,

        -- Latest Inventory Quantity
        (
          SELECT i.new_quantity
          FROM inventory i
          WHERE i.variant_id = pv.variant_id
          ORDER BY i.inventory_id DESC
          LIMIT 1
        ) AS current_stock,

        -- Main Product Image
        pm.media_url AS main_image,

        -- First Variant Image
        (
          SELECT media_url
          FROM product_media
          WHERE product_id = p.product_id
            AND variant_id = pv.variant_id
            AND main = true
          ORDER BY created_at ASC
          LIMIT 1
        ) AS variant_image

      FROM po_items pi

      LEFT JOIN products p
        ON p.product_id = pi.product_id

      LEFT JOIN product_variants pv
        ON pv.variant_id = pi.variant_id

      /* ================= FETCH VARIANT BATCHES ================= */

    LEFT JOIN LATERAL (
  SELECT
    ARRAY_AGG(
      bm.batch_number
      ORDER BY bm.batch_number
    ) AS batch_numbers,

    JSONB_AGG(
      JSONB_BUILD_OBJECT(
        'batch_number', bm.batch_number,
        'cost_price', bm.cost_price
      )
      ORDER BY bm.batch_number
    ) AS batch_details

        FROM (
          SELECT DISTINCT ON (batch_number)
            batch_number,
            cost_price
          FROM batch_management
          WHERE variant_id = pi.variant_id
            AND status = 'active'
            AND batch_number IS NOT NULL
            AND TRIM(batch_number) <> ''
          ORDER BY batch_number
        ) bm
      ) bm_batches ON true

      LEFT JOIN product_media pm
        ON pm.product_id = p.product_id
        AND pm.main = true
        AND pm.variant_id IS NULL

      LEFT JOIN measurements m
        ON m.measurement_id = pi.measurement_unit

      WHERE pi.po_id = $1

      ORDER BY pi.po_item_id ASC
    `;

    const itemsResult = await client.query(itemsQuery, [po_id]);

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      message: "success",
      data: {
        header,
        items: itemsResult.rows,
        branding_settings,
        currency,
      },
    });
  } catch (error) {
    console.error("Fetch PO Details Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// set status

router.put("/update-po-status/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;
  const { status } = req.body;

  const user_id = req.user?.user_id;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const allowedStatuses = ["active", "inactive", "approved", "rejected"];

  if (!status || !allowedStatuses.includes(status)) {
    return res.status(400).json({
      message: "Invalid status value",
    });
  }

  if (!user_id) {
    return res.status(401).json({
      message: "Unauthorized user",
    });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    /* ================= CHECK PO EXISTS ================= */
    const checkQuery = `
        SELECT po_id, status
        FROM po_header
        WHERE po_id = $1
      `;

    const checkResult = await client.query(checkQuery, [po_id]);

    if (checkResult.rows.length === 0) {
      return res.status(404).json({
        message: "Purchase Order not found",
      });
    }

    const oldStatus = checkResult.rows[0].status;

    /* ================= UPDATE STATUS ================= */
    const updateQuery = `
        UPDATE po_header
        SET status = $1,
            authorized_by = $2,
            authorized_date = NOW()
        WHERE po_id = $3
        RETURNING *
      `;

    const updateResult = await client.query(updateQuery, [
      status,
      user_id,
      po_id,
    ]);

    await client.query("COMMIT");

    /* ================= ADMIN LOG ================= */
    const logMessage = `
        Updated Purchase Order Status:
        PO ID: ${po_id}
        Old Status: ${oldStatus}
        New Status: ${status}
      `;

    await insertAdminLog(user_id, "PURCHASE_ORDER", logMessage.trim());

    return res.status(200).json({
      message: "Purchase Order status updated successfully",
      data: updateResult.rows[0],
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update PO Status Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// po search filter on PO List

router.get("/po-search", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { search } = req.query;

    let query = `
      SELECT
        ph.po_id,
        ph.supplier_id,
        s.business_name
      FROM po_header ph
      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id
      WHERE 1 = 1
    `;

    const values = [];

    //  Search by PO ID or Supplier Name
    if (search && search.trim() !== "") {
      query += `
        AND (
          CAST(ph.po_id AS TEXT) ILIKE $1
          OR s.business_name ILIKE $1
        )
      `;
      values.push(`%${search}%`);
    }

    query += `
      ORDER BY ph.po_id DESC
      LIMIT 20
    `;

    const result = await client.query(query, values);

    return res.status(200).json({
      message: "success",
      data: result.rows,
    });
  } catch (error) {
    console.error("PO Search Error:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// update po

router.put("/update-po/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  const { supplier_id, expected_date, remark, supplier_instructions, items } =
    req.body;

  const updated_user = req.user?.user_id;

  /* ================= VALIDATIONS ================= */

  if (!po_id) {
    return res.status(400).json({ message: "po_id is required" });
  }

  if (!supplier_id) {
    return res.status(400).json({ message: "supplier_id is required" });
  }

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      message: "At least one PO item is required",
    });
  }

  if (!updated_user) {
    return res.status(401).json({ message: "Unauthorized user" });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    /* ================= CHECK STATUS ================= */

    const existingPO = await client.query(
      `SELECT status FROM po_header WHERE po_id = $1`,
      [po_id],
    );

    if (existingPO.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "PO not found" });
    }

    if (existingPO.rows[0].status === "approved") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: "Approved PO cannot be updated",
      });
    }

    /* ================= CALCULATE TOTALS ================= */

    const po_qty = items.reduce((sum, i) => sum + Number(i.req_qty), 0);

    const po_total_amount = items.reduce(
      (sum, i) => sum + Number(i.line_total || 0),
      0,
    );

    /* ================= UPDATE HEADER ================= */

    const updateHeaderQuery = `
      UPDATE po_header
      SET
        supplier_id = $1,
        expected_date = $2,
        remark = $3,
        supplier_instructions = $4,
        po_qty = $5,
        po_total_amount = $6
      WHERE po_id = $7
    `;

    await client.query(updateHeaderQuery, [
      supplier_id,
      expected_date || null,
      remark || null,
      supplier_instructions || null,
      po_qty,
      po_total_amount,
      po_id,
    ]);

    /* ================= DELETE OLD ITEMS ================= */

    await client.query(`DELETE FROM po_items WHERE po_id = $1`, [po_id]);

    /* ================= INSERT NEW ITEMS ================= */

    const insertItemQuery = `
      INSERT INTO po_items (
        po_id,
        variant_id,
        product_id,
        batch_number,
        unit_cost,
        req_qty,
        measurement_unit,
        amount_per_unit,
        line_total
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    `;

    for (const item of items) {
      const values = [
        po_id,
        item.variant_id,
        item.product_id,
        item.batch_number || null,
        item.unit_cost,
        item.req_qty,
        item.measurement_unit || null,
        item.amount_per_unit || null,
        item.line_total || 0,
      ];

      await client.query(insertItemQuery, values);
    }

    await client.query("COMMIT");

    /* ================= ADMIN LOG ================= */

    const logMessage = `
      Updated Purchase Order:
      PO ID: ${po_id}
      Supplier ID: ${supplier_id}
      Items: ${items.length}
      Total Qty: ${po_qty}
      Total Amount: ${po_total_amount}
    `;

    await insertAdminLog(
      updated_user,
      "PURCHASE_ORDER_UPDATE",
      logMessage.trim(),
    );

    return res.status(200).json({
      message: "Purchase Order updated successfully",
      data: { po_id },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update PO Error:", error);

    return res.status(500).json({
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch po details by id

router.get("/purchase-orders/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= HEADER ================= */

    const headerQuery = `
      SELECT 
        h.po_id,
        h.supplier_id,
        s.business_name AS supplier_name,
        h.expected_date,
        h.remark,
        h.supplier_instructions,
        h.po_qty,
        h.po_total_amount,
        h.status,
        h.generated_user,
        u.username AS generated_user_name,
        h.created_at
      FROM po_header h
      LEFT JOIN suppliers s ON s.supplier_id = h.supplier_id
      LEFT JOIN users u ON u.user_id = h.generated_user
      WHERE h.po_id = $1
    `;

    const headerResult = await client.query(headerQuery, [po_id]);

    if (headerResult.rows.length === 0) {
      return res.status(404).json({
        message: "Purchase Order not found",
      });
    }

    const header = headerResult.rows[0];

    /* ================= ITEMS ================= */

    const itemsQuery = `
      SELECT
        i.po_item_id,
        i.product_id,
        p.title AS product_name,
        i.variant_id,
        v.variant_value,
        v.variant_type,
        i.unit_cost,
        i.req_qty,
        i.measurement_unit,
        i.amount_per_unit,
        i.line_total
      FROM po_items i
      LEFT JOIN products p ON p.product_id = i.product_id
      LEFT JOIN product_variants v ON v.variant_id = i.variant_id
      WHERE i.po_id = $1
      ORDER BY i.po_item_id ASC
    `;

    const itemsResult = await client.query(itemsQuery, [po_id]);

    /* ================= SYSTEM SETTINGS ================= */

    const settingsQuery = `
      SELECT currency
      FROM system_settings
      LIMIT 1
    `;

    const settingsResult = await client.query(settingsQuery);

    const currency = settingsResult.rows[0]?.currency || "";

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      message: "Purchase Order fetched successfully",
      result: {
        ...header,
        items: itemsResult.rows,
      },
      currency,
    });
  } catch (error) {
    console.error("Get PO Error:", error);

    return res.status(500).json({
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});
module.exports = router;
