const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");


// add supplier

router.post('/create-supplier',authenticateToken, async (req, res) => {
    
  const client = await pool.connect()

  try {
    const {
      business_name,
      address,
      status,
      responsible_person,
      mobile_no,
      contact_no,
      email,
      credit_limit,
      credit,
      reg_date,
      reg_by,
      account_no,
      bank,
      branch,
      country,
      city,
      acc_holders_name,
    } = req.body
 
    

    /* ================= VALIDATION ================= */

    if (!business_name) {
      return res.status(400).json({
        success: false,
        message: 'Business name is required',
      })
    }

    await client.query('BEGIN')

    /* ================= INSERT SUPPLIER ================= */

    const insertQuery = `
      INSERT INTO suppliers (
        business_name,
        address,
        status,
        responsible_person,
        mobile_no,
        contact_no,
        email,
        credit_limit,
        credit,
        reg_date,
        reg_by,
        account_no,
        bank,
        branch,
        acc_holders_name,
        country,
        city
      )
       VALUES (
    $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17
  )
      RETURNING supplier_id
    `

    const values = [
      business_name,
      address || null,
      status || 'active',
      responsible_person || null,
      mobile_no || null,
      contact_no || null,
      email || null,
      Number(credit_limit) || 0,
      Number(credit) || 0,
      reg_date || null,
      reg_by || null,
      account_no || null,
      bank || null,
      branch || null,
      acc_holders_name || null,
      country || null,
      city || null,
    ]

    const result = await client.query(insertQuery, values)

    const newSupplierId = result.rows[0].supplier_id

    /* ================= ADMIN LOG ================= */

    await insertAdminLog(
      reg_by,
      'SUPPLIER',
      `Created new supplier (#${newSupplierId}) - ${business_name}`
    )

    await client.query('COMMIT')

    return res.status(201).json({
      success: true,
      message: 'Supplier created successfully',
      supplier_id: newSupplierId,
    })
  } catch (error) {
    await client.query('ROLLBACK')

    console.error('Error creating supplier:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to create supplier',
    })
  } finally {
    client.release()
  }
})


router.get("/suppliersname", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT business_name FROM suppliers WHERE business_name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});



router.post("/allsuppliers", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      status,
      date,
      todate
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

   // 🔎 Keyword Search
if (keyword) {
  const trimmedKeyword = keyword.trim();
  queryParams.push(`%${trimmedKeyword}%`);

  whereConditions.push(`
    (
       s.business_name ILIKE $${queryParams.length}
      OR s.responsible_person ILIKE $${queryParams.length}
      OR s.email ILIKE $${queryParams.length}
      OR s.mobile_no ILIKE $${queryParams.length}
      OR s.supplier_id::text ILIKE $${queryParams.length}
    )
  `);
}

// ✅ Status Filter
if (status) {
  queryParams.push(status);
  whereConditions.push(`s.status = $${queryParams.length}`);
}

// 📅 Date Range Filter
if (date && todate) {
  queryParams.push(date);
  queryParams.push(todate);

  whereConditions.push(`
    s.created_at::date BETWEEN $${queryParams.length - 1}
    AND $${queryParams.length}
  `);
}

const whereClause = whereConditions.length
  ? `WHERE ${whereConditions.join(" AND ")}`
  : "";


   const suppliersQuery = `
  SELECT 
    s.supplier_id,
    s.business_name,
    s.address,
    s.status,
    s.created_at,
    s.responsible_person,
    s.mobile_no,
    s.contact_no,
    s.email,
    s.credit_limit,
    s.credit,
    s.reg_date,
    s.reg_by,
    s.account_no,
    s.bank,
    s.branch,
    s.city,
    s.note,
    s.country,
    s.acc_holders_name,
    c.country_name
  FROM suppliers s
  LEFT JOIN countries c 
    ON s.country::integer = c.id
  ${whereClause}
  ORDER BY s.created_at DESC
  LIMIT $${queryParams.length + 1}
  OFFSET $${queryParams.length + 2}
`;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(suppliersQuery, paginatedParams);

     const countQuery = `
      SELECT COUNT(*) AS total
      FROM suppliers s
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      suppliers: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (err) {
    console.error("Error fetching suppliers:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.post("/update-supplier-status", authenticateToken, async (req, res) => {
  const { supplier_id, status } = req.body;

  const user = req.user;
  const user_id = user.user_id;

  // ✅ Validate Input
  if (!supplier_id || !["active", "inactive"].includes(status)) {
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    // 🔄 Update Supplier Status
    const result = await pool.query(
      "UPDATE suppliers SET status = $1 WHERE supplier_id = $2",
      [status, supplier_id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Supplier not found" });
    }

    // 📝 Admin Log
    const module = "Suppliers";
    const logMessage = `Updated supplier ${supplier_id} status to '${status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Supplier status updated successfully" });

  } catch (error) {
    console.error("Error updating supplier status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.put("/update/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const {
      business_name,
      address,
      responsible_person,
      mobile_no,
      contact_no,
      email,
      bank,
      branch,
      account_no,
      acc_holders_name,
      country,
      note,
      city,
    } = req.body;

    const query = `
      UPDATE suppliers SET
        business_name = $1,
        address = $2,
        responsible_person = $3,
        mobile_no = $4,
        contact_no = $5,
        email = $6,
        bank = $7,
        branch = $8,
        account_no = $9,
        acc_holders_name = $10,
        country = $11,
        city = $12,
        note = $14
      WHERE supplier_id = $13
      RETURNING *
    `;

    const values = [
      business_name,
      address,
      responsible_person,
      mobile_no,
      contact_no,
      email,
      bank,
      branch,
      account_no,
      acc_holders_name,
      country,
      city,
      id,
      note,
    ];

    const result = await pool.query(query, values);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Supplier not found" });
    }

    res.json({
      message: "Supplier updated successfully",
      supplier: result.rows[0],
    });

  } catch (error) {
    console.error("Update Supplier Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});



module.exports = router;