const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

// PRN Details Fetch

router.get("/po-prn-details/:po_id", authenticateToken, async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ================= CHECK IF PRN EXISTS FOR THIS PO ================= */

    const prnExistsQuery = `
      SELECT EXISTS (
        SELECT 1
        FROM prn_header
        WHERE po_id = $1
      ) AS has_prn
    `;

    const prnExistsResult = await client.query(prnExistsQuery, [po_id]);
    const has_prn = prnExistsResult.rows[0].has_prn;

    /* ================= FETCH PO HEADER ================= */

    const headerQuery = `
      SELECT
        ph.po_id,
        ph.po_date,
        ph.expected_date,
        ph.status,
        ph.po_qty,
        ph.po_total_amount,
        ph.remark,
        ph.supplier_instructions,
        ph.created_at,

        s.supplier_id,
        s.business_name,
        s.address,
        s.mobile_no,
        s.contact_no,
        s.email,

        CONCAT(u.first_name, ' ', u.last_name) AS generated_user_name,
        CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name,
        ph.authorized_date

      FROM po_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

      LEFT JOIN users u
        ON u.user_id = ph.generated_user

      LEFT JOIN users au
        ON au.user_id = ph.authorized_by

      WHERE ph.po_id = $1
    `;

    const headerResult = await client.query(headerQuery, [po_id]);

    if (headerResult.rows.length === 0) {
      return res.status(404).json({
        message: "Purchase Order not found",
      });
    }

    const header = headerResult.rows[0];

    /* ================= FETCH TOTAL PRN SUMMARY ================= */

    const prnSummaryQuery = `
      SELECT
        COALESCE(SUM(total_return_qty),0) AS total_return_qty,
        COALESCE(SUM(total_return_amount),0) AS total_return_amount
      FROM prn_header
      WHERE po_id = $1
    `;

    const prnSummaryResult = await client.query(prnSummaryQuery, [po_id]);
    const prn_summary = prnSummaryResult.rows[0];

    /* ================= FETCH PO ITEMS WITH MEASUREMENT ================= */

    const itemsQuery = `
      SELECT
        pi.po_item_id,
        pi.product_id,
        pi.variant_id,
        pi.batch_number,
        pi.unit_cost,
        pi.req_qty,

        /* NEW FIELDS */
        pi.measurement_unit,
        pi.amount_per_unit,
        m.measurement_value,

        p.title AS product_title,
        pv.variant_value,

        /* TOTAL RECEIVED FROM GRN */
        COALESCE(SUM(DISTINCT gi.received_qty), 0) AS total_received_qty,

        /* TOTAL RETURNED */
        COALESCE(SUM(DISTINCT prni.return_qty), 0) AS total_returned_qty

      FROM po_items pi

      LEFT JOIN products p
        ON p.product_id = pi.product_id

      LEFT JOIN product_variants pv
        ON pv.variant_id = pi.variant_id

      /* JOIN MEASUREMENTS */
      LEFT JOIN measurements m
        ON m.measurement_id = pi.measurement_unit

      /* JOIN GRN TABLES */
      LEFT JOIN grn_items gi
        ON gi.po_item_id = pi.po_item_id

      LEFT JOIN grn_header gh
        ON gh.grn_id = gi.grn_id
        AND gh.po_id = pi.po_id

      /* JOIN PRN ITEMS */
      LEFT JOIN prn_items prni
        ON prni.po_item_id = pi.po_item_id

      WHERE pi.po_id = $1

      GROUP BY
        pi.po_item_id,
        pi.product_id,
        pi.variant_id,
        pi.batch_number,
        pi.unit_cost,
        pi.req_qty,
        pi.measurement_unit,
        pi.amount_per_unit,
        m.measurement_value,
        p.title,
        pv.variant_value
    `;

    const itemsResult = await client.query(itemsQuery, [po_id]);

    /* ================= FETCH SYSTEM SETTINGS ================= */

    const currencyQuery = `
      SELECT currency
      FROM system_settings
      LIMIT 1
    `;

    const currencyResult = await client.query(currencyQuery);

    const currency =
      currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : null;

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      message: "success",
      data: {
        header,
        items: itemsResult.rows,
        prn_summary: {
          total_return_qty: prn_summary?.total_return_qty || 0,
          total_return_amount: prn_summary?.total_return_amount || 0,
        },
        has_prn,
        currency,
      },
    });
  } catch (error) {
    console.error("Fetch PO PRN Details Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});
// create PRN

router.post("/create-prn", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { po_id, supplier_id, remark, returned_by, items } = req.body;

    const { user_id, merchant_id, outlet_id } = req.user;

    if (!outlet_id) {
      throw new Error("outlet_id missing from authentication context");
    }

    /* ================= VALIDATION ================= */

    if (!po_id || !supplier_id || !returned_by) {
      return res.status(400).json({
        message: "Missing required fields",
      });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        message: "PRN items are required",
      });
    }

    const validItems = items.filter((item) => Number(item.return_qty) > 0);

    if (validItems.length === 0) {
      return res.status(400).json({
        message: "At least one valid return item is required",
      });
    }

    await client.query("BEGIN");

    /* ================= CALCULATE TOTALS ================= */

    let total_return_qty = 0;
    let total_return_amount = 0;

    for (const item of validItems) {
      total_return_qty += Number(item.return_qty);
      total_return_amount += Number(item.return_qty) * Number(item.unit_cost);
    }

    /* ================= GET LATEST GRN ID (FOR HEADER ONLY) ================= */

    const grnResult = await client.query(
      `
      SELECT grn_id
      FROM grn_header
      WHERE po_id = $1
      ORDER BY grn_id DESC
      LIMIT 1
      `,
      [po_id],
    );

    if (grnResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: "No GRN found for this PO",
      });
    }

    const grn_id = grnResult.rows[0].grn_id;

    /* ================= INSERT PRN HEADER ================= */

    const headerResult = await client.query(
      `
      INSERT INTO prn_header (
        grn_id,
        po_id,
        supplier_id,
        status,
        total_return_qty,
        total_return_amount,
        remark,
        returned_by
      )
      VALUES ($1,$2,$3,'pending',$4,$5,$6,$7)
      RETURNING prn_id
      `,
      [
        grn_id,
        Number(po_id),
        Number(supplier_id),
        total_return_qty,
        total_return_amount,
        remark || null,
        Number(returned_by),
      ],
    );

    const prn_id = headerResult.rows[0].prn_id;

    /* ================= PROCESS ITEMS ================= */

    for (const item of validItems) {
      /* 🔹 1. TOTAL RECEIVED FROM ALL GRNs FOR THIS PO ITEM */
      const receivedResult = await client.query(
        `
        SELECT COALESCE(SUM(received_qty),0) AS total_received
        FROM grn_items gi
        JOIN grn_header gh ON gh.grn_id = gi.grn_id
        WHERE gi.po_item_id = $1
          AND gh.po_id = $2
        `,
        [item.po_item_id, po_id],
      );

      const totalReceived = Number(receivedResult.rows[0].total_received);

      if (totalReceived <= 0) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: `No received quantity found for item ${item.po_item_id}`,
        });
      }

      /* 🔹 2. TOTAL ALREADY RETURNED */
      const returnedResult = await client.query(
        `
        SELECT COALESCE(SUM(return_qty),0) AS total_returned
        FROM prn_items
        WHERE po_item_id = $1
        `,
        [item.po_item_id],
      );

      const totalAlreadyReturned = Number(
        returnedResult.rows[0].total_returned,
      );

      const remainingAllowed = totalReceived - totalAlreadyReturned;

      /* 🔹 3. VALIDATION */
      if (Number(item.return_qty) > remainingAllowed) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: `Return quantity exceeds remaining for item ${item.po_item_id}. Allowed: ${remainingAllowed}`,
        });
      }

      /* 🔹 4. GET ONE GRN ITEM (FOR FK PURPOSE ONLY) */
      const grnItemResult = await client.query(
        `
        SELECT gi.grn_item_id,
               gi.variant_id
        FROM grn_items gi
        JOIN grn_header gh ON gh.grn_id = gi.grn_id
        WHERE gi.po_item_id = $1
          AND gh.po_id = $2
        ORDER BY gi.grn_item_id DESC
        LIMIT 1
        `,
        [item.po_item_id, po_id],
      );

      const { grn_item_id, variant_id } = grnItemResult.rows[0];

      /* ================= INSERT PRN ITEM ================= */

      await client.query(
        `
        INSERT INTO prn_items (
          prn_id,
          grn_item_id,
          po_item_id,
          product_id,
          variant_id,
          batch_number,
          ordered_qty,
          received_qty,
          return_qty,
          unit_cost,
          reason
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
        `,
        [
          prn_id,
          grn_item_id,
          Number(item.po_item_id),
          Number(item.product_id),
          variant_id || null,
          item.batch_number || null,
          Number(item.ordered_qty),
          totalReceived,
          Number(item.return_qty),
          Number(item.unit_cost),
          item.reason || null,
        ],
      );

      /* ================= STOCK OUT LOGIC (UNCHANGED) ================= */

      if (variant_id && Number(item.return_qty) > 0) {
        const prevStockRes = await client.query(
          `
          SELECT new_quantity
          FROM inventory
          WHERE variant_id = $1
            AND outlet_id = $2
            AND merchant_id = $3
            AND status = 'active'
          ORDER BY inventory_id DESC
          LIMIT 1
          `,
          [variant_id, outlet_id, merchant_id],
        );

        const previous_quantity = Number(
          prevStockRes.rows[0]?.new_quantity ?? 0,
        );

        const adjust_quantity = Number(item.return_qty);
        const new_quantity = previous_quantity - adjust_quantity;

        if (new_quantity < 0) {
          await client.query("ROLLBACK");
          return res.status(400).json({
            message: `Insufficient stock for variant ${variant_id}`,
          });
        }

        const comment = `PRN STOCK OUT | PRN ID: ${prn_id} | PO: ${po_id} | v:${variant_id}`;

        await client.query(
          `
          INSERT INTO inventory (
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            updated_by,
            comment,
            system_module,
            previous_quantity,
            adjust_quantity,
            new_quantity,
            status
          )
          VALUES ($1,$2,$3,$4,$5,$6,$7,'stock out',$8,$9,$10,'active')
          `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            item.batch_number || null,
            user_id,
            comment,
            previous_quantity,
            -adjust_quantity,
            new_quantity,
          ],
        );
      }
    }

    await client.query("COMMIT");

    await insertAdminLog(
      returned_by,
      "PRN",
      `Created PRN #${prn_id} for PO #${po_id} | Total Qty: ${total_return_qty}`,
    );

    return res.status(201).json({
      message: "PRN created successfully with stock out",
      po_id: Number(po_id),
      grn_id: Number(grn_id),
      prn_id: Number(prn_id),
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create PRN Error:", error);

    return res.status(500).json({
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch prn list
router.get("/prn-list", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    let {
      supplier_id,
      status,
      date_from,
      date_to,
      po_id,
      grn_id,
      page = 1,
      limit = 25,
    } = req.query;

    /* ================= PAGINATION ================= */
    page = parseInt(page) || 1;
    limit = parseInt(limit) || 25;
    const offset = (page - 1) * limit;

    let conditions = [];
    let values = [];
    let index = 1;

    /* ================= OR FILTER BLOCK (IDs) ================= */
    let idConditions = [];

    if (supplier_id && supplier_id !== "all" && supplier_id !== "") {
      idConditions.push(`ph.supplier_id = $${index++}`);
      values.push(parseInt(supplier_id));
    }

    if (po_id && po_id !== "") {
      idConditions.push(`ph.po_id = $${index++}`);
      values.push(parseInt(po_id));
    }

    if (grn_id && grn_id !== "") {
      idConditions.push(`ph.grn_id = $${index++}`);
      values.push(parseInt(grn_id));
    }

    // If any ID filter exists, wrap them with OR
    if (idConditions.length > 0) {
      conditions.push(`(${idConditions.join(" OR ")})`);
    }

    /* ================= STATUS FILTER (AND) ================= */
    if (status && status !== "all" && status !== "") {
      conditions.push(`ph.status = $${index++}`);
      values.push(status);
    }

    /* ================= DATE FILTERS (AND) ================= */
    if (date_from && date_from !== "") {
      conditions.push(`ph.prn_date >= $${index++}`);
      values.push(date_from);
    }

    if (date_to && date_to !== "") {
      conditions.push(`ph.prn_date <= $${index++}`);
      values.push(date_to);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    console.log("WHERE:", whereClause);
    console.log("VALUES:", values);

    /* ================= COUNT QUERY ================= */
    const countQuery = `
      SELECT COUNT(*)
      FROM prn_header ph
      ${whereClause}
    `;

    const countResult = await client.query(countQuery, values);
    const totalRecords = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalRecords / limit);

    /* ================= MAIN QUERY ================= */
    const mainQuery = `
      SELECT
        ph.prn_id,
        ph.prn_date,
        ph.po_id,
        ph.grn_id,
        ph.status,
        ph.total_return_qty,
        ph.total_return_amount,
        ph.returned_date,
        ph.authorized_date,
        ph.created_at,

        s.business_name,
        s.supplier_id,

        CONCAT(u.first_name, ' ', u.last_name) AS returned_user_name

      FROM prn_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

      LEFT JOIN users u
        ON u.user_id = ph.returned_by

      ${whereClause}

      ORDER BY ph.prn_id DESC
      LIMIT $${index++}
      OFFSET $${index++}
    `;

    const finalValues = [...values, limit, offset];
    const result = await client.query(mainQuery, finalValues);

    /* ================= FETCH CURRENCY ================= */
    const currencyResult = await client.query(`
      SELECT currency
      FROM system_settings
      LIMIT 1
    `);

    const currency =
      currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : null;

    return res.status(200).json({
      success: true,
      message: "PRN list fetched successfully",
      data: {
        records: result.rows,
        pagination: {
          current_page: page,
          per_page: limit,
          total_records: totalRecords,
          total_pages: totalPages,
        },
        currency,
      },
    });
  } catch (error) {
    console.error("Fetch PRN List Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  } finally {
    client.release();
  }
});

// prn view

router.get(
  "/prn-details-by-grn/:grn_id",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const { grn_id } = req.params;

      if (!grn_id) {
        return res.status(400).json({
          message: "grn_id is required",
        });
      }

      /* ================= FETCH PRN HEADER ================= */

      const headerQuery = `
        SELECT
          ph.prn_id,
          ph.prn_date,
          ph.po_id,
          ph.grn_id,
          ph.status,
          ph.total_return_qty,
          ph.total_return_amount,
          ph.remark,
          ph.returned_date,
          ph.authorized_date,
          ph.created_at,

          -- Supplier
          s.supplier_id,
          s.business_name,
          s.address,
          s.mobile_no,
          s.contact_no,
          s.email,

          -- Returned User
          CONCAT(u.first_name, ' ', u.last_name) AS returned_user_name,

          -- Authorized User
          CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name

        FROM prn_header ph

        LEFT JOIN suppliers s
          ON s.supplier_id = ph.supplier_id

        LEFT JOIN users u
          ON u.user_id = ph.returned_by

        LEFT JOIN users au
          ON au.user_id = ph.authorized_by

        WHERE ph.grn_id = $1
        ORDER BY ph.prn_id DESC
        LIMIT 1
      `;

      const headerResult = await client.query(headerQuery, [grn_id]);

      if (headerResult.rows.length === 0) {
        return res.status(404).json({
          message: "PRN not found for this GRN",
        });
      }

      const header = headerResult.rows[0];

      /* ================= FETCH PRN ITEMS ================= */

      const itemsQuery = `
  SELECT
    pi.prn_item_id,
    pi.grn_item_id,
    pi.po_item_id,
    pi.product_id,
    pi.variant_id,
    pi.batch_number,
    pi.ordered_qty,
    pi.received_qty,
    pi.return_qty,
    pi.unit_cost,
    pi.line_total,
    pi.reason,

    -- Product
    p.title AS product_title,

    -- Variant
    pv.variant_value,
    pv.barcode,
    pv.weight,

    -- From GRN Items
    gi.amount_per_unit,
    gi.line_total AS grn_line_total,

    -- Measurement Value
    m.measurement_value

  FROM prn_items pi

  LEFT JOIN grn_items gi
    ON gi.grn_item_id = pi.grn_item_id

  LEFT JOIN measurements m
    ON m.measurement_id = gi.measurement_unit

  LEFT JOIN products p
    ON p.product_id = pi.product_id

  LEFT JOIN product_variants pv
    ON pv.variant_id = pi.variant_id

  WHERE pi.prn_id = $1
`;

      const itemsResult = await client.query(itemsQuery, [header.prn_id]);

      /* ================= FETCH CURRENCY ================= */

      const currencyQuery = `
        SELECT currency
        FROM system_settings
        LIMIT 1
      `;
      const currencyResult = await client.query(currencyQuery);

      const currency =
        currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : null;

      /* ================= FETCH BRANDING ================= */

      const brandingQuery = `
  SELECT company_name, logo_url_white
  FROM branding_settings
  LIMIT 1
`;
      const brandingResult = await client.query(brandingQuery);

      const company_name =
        brandingResult.rows.length > 0
          ? brandingResult.rows[0].company_name
          : null;

      const logo_url_white =
        brandingResult.rows.length > 0
          ? brandingResult.rows[0].logo_url_white
          : null;
      /* ================= RESPONSE ================= */

      return res.status(200).json({
        success: true,
        message: "PRN details fetched successfully",
        data: {
          header,
          items: itemsResult.rows,
          currency,
          logo_url_white,
          company_name,
        },
      });
    } catch (error) {
      console.error("Fetch PRN Details Error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    } finally {
      client.release();
    }
  },
);
module.exports = router;
