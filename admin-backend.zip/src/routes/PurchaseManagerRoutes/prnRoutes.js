const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

// PRN Details Fetch

router.get(
  "/po-prn-details/:po_id",
  authenticateToken,
  async (req, res) => {
    const { po_id } = req.params;

    if (!po_id) {
      return res.status(400).json({
        message: "po_id is required",
      });
    }

    const client = await pool.connect();

    try {
      /* ================= CHECK IF PRN EXISTS FOR THIS PO ================= */

      const prnExistsQuery = `
        SELECT EXISTS (
          SELECT 1
          FROM prn_header
          WHERE po_id = $1
        ) AS has_prn
      `;

      const prnExistsResult = await client.query(prnExistsQuery, [po_id]);
      const has_prn = prnExistsResult.rows[0].has_prn;

      /* ================= FETCH PO HEADER ================= */

      const headerQuery = `
        SELECT
          ph.po_id,
          ph.po_date,
          ph.expected_date,
          ph.status,
          ph.po_qty,
          ph.po_total_amount,
          ph.remark,
          ph.supplier_instructions,
          ph.created_at,

          s.supplier_id,
          s.business_name,
          s.address,
          s.mobile_no,
          s.contact_no,
          s.email,

          CONCAT(u.first_name, ' ', u.last_name) AS generated_user_name,
          CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name,
          ph.authorized_date

        FROM po_header ph

        LEFT JOIN suppliers s
          ON s.supplier_id = ph.supplier_id

        LEFT JOIN users u
          ON u.user_id = ph.generated_user

        LEFT JOIN users au
          ON au.user_id = ph.authorized_by

        WHERE ph.po_id = $1
      `;

      const headerResult = await client.query(headerQuery, [po_id]);

      if (headerResult.rows.length === 0) {
        return res.status(404).json({
          message: "Purchase Order not found",
        });
      }

      const header = headerResult.rows[0];

      /* ================= FETCH TOTAL PRN SUMMARY ================= */

      const prnSummaryQuery = `
        SELECT
          COALESCE(SUM(total_return_qty), 0) AS total_return_qty,
          COALESCE(SUM(total_return_amount), 0) AS total_return_amount
        FROM prn_header
        WHERE po_id = $1
      `;

      const prnSummaryResult = await client.query(prnSummaryQuery, [po_id]);
      const prn_summary = prnSummaryResult.rows[0];

      /* ================= FETCH PO ITEMS WITH BATCH SUMMARY ================= */

      const itemsQuery = `
        SELECT
          pi.po_item_id,
          pi.product_id,
          pi.variant_id,
          pi.batch_number,
          pi.unit_cost,
          pi.req_qty,

          pi.measurement_unit,
          pi.amount_per_unit,
          m.measurement_value,

          p.title AS product_title,
          pv.variant_value,

          /* Total received across every batch */
          COALESCE(
            grn_summary.total_received_qty,
            0
          ) AS total_received_qty,

          /* Total returned across every batch */
          COALESCE(
            prn_item_summary.total_returned_qty,
            0
          ) AS total_returned_qty,

          /* All batches available for this variant */
          COALESCE(
            batch_summary.batch_numbers,
            ARRAY[]::text[]
          ) AS batch_numbers,

          /*
            Batch-wise quantities:

            [
              {
                "batch_number": "BATCH001",
                "total_received_qty": 10,
                "total_returned_qty": 3,
                "remaining_returnable": 7
              }
            ]
          */
          COALESCE(
            batch_summary.batch_details,
            '[]'::jsonb
          ) AS batch_details

        FROM po_items pi

        LEFT JOIN products p
          ON p.product_id = pi.product_id

        LEFT JOIN product_variants pv
          ON pv.variant_id = pi.variant_id

        LEFT JOIN measurements m
          ON m.measurement_id = pi.measurement_unit

        /* ================= TOTAL GRN QTY FOR PO ITEM ================= */

        LEFT JOIN LATERAL (
          SELECT
            COALESCE(SUM(gi.received_qty), 0) AS total_received_qty
          FROM grn_items gi
          WHERE gi.po_item_id = pi.po_item_id
        ) grn_summary ON true

        /* ================= TOTAL PRN QTY FOR PO ITEM ================= */

        LEFT JOIN LATERAL (
          SELECT
            COALESCE(SUM(prni.return_qty), 0) AS total_returned_qty
          FROM prn_items prni
          WHERE prni.po_item_id = pi.po_item_id
        ) prn_item_summary ON true

        /* ================= BATCH-WISE RECEIVED / RETURNED ================= */

        LEFT JOIN LATERAL (
          WITH available_batches AS (
            /* Active batches created for the variant */
            SELECT bm.batch_number
            FROM batch_management bm
            WHERE bm.variant_id = pi.variant_id
              AND bm.status = 'active'
              AND bm.batch_number IS NOT NULL
              AND TRIM(bm.batch_number) <> ''

            UNION

            /* Batches previously received for this PO item */
            SELECT gi.batch_number
            FROM grn_items gi
            WHERE gi.po_item_id = pi.po_item_id
              AND gi.batch_number IS NOT NULL
              AND TRIM(gi.batch_number) <> ''

            UNION

            /* Batches previously returned for this PO item */
            SELECT prni.batch_number
            FROM prn_items prni
            WHERE prni.po_item_id = pi.po_item_id
              AND prni.batch_number IS NOT NULL
              AND TRIM(prni.batch_number) <> ''
          ),

          received_by_batch AS (
            SELECT
              gi.batch_number,
              COALESCE(SUM(gi.received_qty), 0) AS total_received_qty
            FROM grn_items gi
            WHERE gi.po_item_id = pi.po_item_id
              AND gi.batch_number IS NOT NULL
              AND TRIM(gi.batch_number) <> ''
            GROUP BY gi.batch_number
          ),

          returned_by_batch AS (
            SELECT
              prni.batch_number,
              COALESCE(SUM(prni.return_qty), 0) AS total_returned_qty
            FROM prn_items prni
            WHERE prni.po_item_id = pi.po_item_id
              AND prni.batch_number IS NOT NULL
              AND TRIM(prni.batch_number) <> ''
            GROUP BY prni.batch_number
          )

          SELECT
            ARRAY_AGG(
              ab.batch_number
              ORDER BY ab.batch_number
            ) AS batch_numbers,

            JSONB_AGG(
              JSONB_BUILD_OBJECT(
                'batch_number',
                ab.batch_number,

                'total_received_qty',
                COALESCE(rb.total_received_qty, 0),

                'total_returned_qty',
                COALESCE(rtb.total_returned_qty, 0),

                'remaining_returnable',
                GREATEST(
                  COALESCE(rb.total_received_qty, 0)
                  -
                  COALESCE(rtb.total_returned_qty, 0),
                  0
                )
              )
              ORDER BY ab.batch_number
            ) AS batch_details

          FROM available_batches ab

          LEFT JOIN received_by_batch rb
            ON rb.batch_number = ab.batch_number

          LEFT JOIN returned_by_batch rtb
            ON rtb.batch_number = ab.batch_number
        ) batch_summary ON true

        WHERE pi.po_id = $1

        ORDER BY pi.po_item_id ASC
      `;

      const itemsResult = await client.query(itemsQuery, [po_id]);

      /* ================= FETCH SYSTEM SETTINGS ================= */

      const currencyQuery = `
        SELECT currency
        FROM system_settings
        LIMIT 1
      `;

      const currencyResult = await client.query(currencyQuery);

      const currency =
        currencyResult.rows.length > 0
          ? currencyResult.rows[0].currency
          : null;

      /* ================= RESPONSE ================= */

      return res.status(200).json({
        message: "success",
        data: {
          header,
          items: itemsResult.rows,
          prn_summary: {
            total_return_qty: prn_summary?.total_return_qty || 0,
            total_return_amount: prn_summary?.total_return_amount || 0,
          },
          has_prn,
          currency,
        },
      });
    } catch (error) {
      console.error("Fetch PO PRN Details Error:", error);

      return res.status(500).json({
        message: "Internal server error",
      });
    } finally {
      client.release();
    }
  },
);
// create PRN

router.post("/create-prn", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { po_id, supplier_id, remark, returned_by, items } = req.body;

    const { user_id, merchant_id, outlet_id } = req.user;

    if (!outlet_id) {
      throw new Error("outlet_id missing from authentication context");
    }

    /* ================= VALIDATION ================= */

    if (!po_id || !supplier_id || !returned_by) {
      return res.status(400).json({
        message: "Missing required fields",
      });
    }

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        message: "PRN items are required",
      });
    }

    const validItems = items.filter(
      (item) => Number(item.return_qty) > 0,
    );

    if (validItems.length === 0) {
      return res.status(400).json({
        message: "At least one valid return item is required",
      });
    }

    await client.query("BEGIN");

    /* ================= CALCULATE TOTALS ================= */

    let total_return_qty = 0;
    let total_return_amount = 0;

    for (const item of validItems) {
      total_return_qty += Number(item.return_qty);

      total_return_amount +=
        Number(item.return_qty) * Number(item.unit_cost);
    }

    /* ================= GET LATEST GRN ID FOR HEADER ================= */

    const grnResult = await client.query(
      `
      SELECT grn_id
      FROM grn_header
      WHERE po_id = $1
      ORDER BY grn_id DESC
      LIMIT 1
      `,
      [po_id],
    );

    if (grnResult.rows.length === 0) {
      await client.query("ROLLBACK");

      return res.status(400).json({
        message: "No GRN found for this PO",
      });
    }

    const grn_id = grnResult.rows[0].grn_id;

    /* ================= INSERT PRN HEADER ================= */

    const headerResult = await client.query(
      `
      INSERT INTO prn_header (
        grn_id,
        po_id,
        supplier_id,
        status,
        total_return_qty,
        total_return_amount,
        remark,
        returned_by
      )
      VALUES ($1, $2, $3, 'pending', $4, $5, $6, $7)
      RETURNING prn_id
      `,
      [
        grn_id,
        Number(po_id),
        Number(supplier_id),
        total_return_qty,
        total_return_amount,
        remark || null,
        Number(returned_by),
      ],
    );

    const prn_id = headerResult.rows[0].prn_id;

    /* ================= PROCESS ITEMS ================= */

    for (const item of validItems) {
      const selectedBatch =
        typeof item.batch_number === "string" &&
        item.batch_number.trim() !== ""
          ? item.batch_number.trim()
          : null;

      const returnQty = Number(item.return_qty);

      /* =====================================================
         1. TOTAL RECEIVED FOR SELECTED PO ITEM + BATCH
      ===================================================== */

      const receivedResult = await client.query(
        `
        SELECT
          COALESCE(SUM(gi.received_qty), 0) AS total_received
        FROM grn_items gi

        INNER JOIN grn_header gh
          ON gh.grn_id = gi.grn_id

        WHERE gi.po_item_id = $1
          AND gh.po_id = $2
          AND gi.batch_number IS NOT DISTINCT FROM $3::text
        `,
        [item.po_item_id, po_id, selectedBatch],
      );

      const totalReceived = Number(
        receivedResult.rows[0]?.total_received || 0,
      );

      if (totalReceived <= 0) {
        await client.query("ROLLBACK");

        return res.status(400).json({
          message: selectedBatch
            ? `No received quantity found for item ${item.po_item_id} in batch ${selectedBatch}`
            : `No non-batch received quantity found for item ${item.po_item_id}`,
        });
      }

      /* =====================================================
         2. TOTAL PREVIOUSLY RETURNED FOR ITEM + BATCH
      ===================================================== */

      const returnedResult = await client.query(
        `
        SELECT
          COALESCE(SUM(return_qty), 0) AS total_returned
        FROM prn_items
        WHERE po_item_id = $1
          AND batch_number IS NOT DISTINCT FROM $2::text
        `,
        [item.po_item_id, selectedBatch],
      );

      const totalAlreadyReturned = Number(
        returnedResult.rows[0]?.total_returned || 0,
      );

      const remainingAllowed =
        totalReceived - totalAlreadyReturned;

      /* ================= RETURN VALIDATION ================= */

      if (returnQty > remainingAllowed) {
        await client.query("ROLLBACK");

        return res.status(400).json({
          message: selectedBatch
            ? `Return quantity exceeds remaining quantity for item ${item.po_item_id}, batch ${selectedBatch}. Allowed: ${remainingAllowed}`
            : `Return quantity exceeds remaining quantity for item ${item.po_item_id}. Allowed: ${remainingAllowed}`,
        });
      }

      /* =====================================================
         3. GET MATCHING GRN ITEM FOR FK AND COST
      ===================================================== */

      const grnItemResult = await client.query(
        `
        SELECT
          gi.grn_item_id,
          gi.variant_id,
          gi.unit_cost,
          gi.batch_number,
          gi.received_qty
        FROM grn_items gi

        INNER JOIN grn_header gh
          ON gh.grn_id = gi.grn_id

        WHERE gi.po_item_id = $1
          AND gh.po_id = $2
          AND gi.batch_number IS NOT DISTINCT FROM $3::text

        ORDER BY gi.grn_item_id DESC
        LIMIT 1
        `,
        [item.po_item_id, po_id, selectedBatch],
      );

      if (grnItemResult.rows.length === 0) {
        await client.query("ROLLBACK");

        return res.status(400).json({
          message: selectedBatch
            ? `No GRN item found for PO item ${item.po_item_id} and batch ${selectedBatch}`
            : `No non-batch GRN item found for PO item ${item.po_item_id}`,
        });
      }

      const {
        grn_item_id,
        variant_id,
        unit_cost: grnUnitCost,
      } = grnItemResult.rows[0];

      const finalUnitCost = Number(
        grnUnitCost ?? item.unit_cost ?? 0,
      );

      /* ================= INSERT PRN ITEM ================= */

      await client.query(
        `
        INSERT INTO prn_items (
          prn_id,
          grn_item_id,
          po_item_id,
          product_id,
          variant_id,
          batch_number,
          ordered_qty,
          received_qty,
          return_qty,
          unit_cost,
          reason
        )
        VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10, $11
        )
        `,
        [
          prn_id,
          grn_item_id,
          Number(item.po_item_id),
          Number(item.product_id),
          variant_id || null,
          selectedBatch,
          Number(item.ordered_qty),
          totalReceived,
          returnQty,
          finalUnitCost,
          item.reason || null,
        ],
      );

      /* =====================================================
         4. BATCH-WISE STOCK OUT
      ===================================================== */

      if (variant_id && returnQty > 0) {
        /*
          When selectedBatch has a value:
            fetch latest inventory balance for that exact batch.

          When selectedBatch is null:
            fetch latest non-batch inventory balance.
        */

        const prevStockRes = await client.query(
          `
          SELECT
            new_quantity
          FROM inventory
          WHERE variant_id = $1
            AND outlet_id = $2
            AND merchant_id = $3
            AND status = 'active'
            AND batch_number IS NOT DISTINCT FROM $4::text

          ORDER BY
            last_updated DESC NULLS LAST,
            inventory_id DESC

          LIMIT 1
          `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            selectedBatch,
          ],
        );

        const previous_quantity = Number(
          prevStockRes.rows[0]?.new_quantity ?? 0,
        );

        const adjust_quantity = returnQty;
        const new_quantity =
          previous_quantity - adjust_quantity;

        if (new_quantity < 0) {
          await client.query("ROLLBACK");

          return res.status(400).json({
            message: selectedBatch
              ? `Insufficient stock for variant ${variant_id} in batch ${selectedBatch}. Available: ${previous_quantity}`
              : `Insufficient non-batch stock for variant ${variant_id}. Available: ${previous_quantity}`,
          });
        }

        const comment = selectedBatch
          ? `PRN STOCK OUT | PRN ID: ${prn_id} | PO: ${po_id} | v:${variant_id} | Batch: ${selectedBatch}`
          : `PRN STOCK OUT | PRN ID: ${prn_id} | PO: ${po_id} | v:${variant_id}`;

        /* ================= INSERT INVENTORY TRANSACTION ================= */

        await client.query(
          `
          INSERT INTO inventory (
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            updated_by,
            comment,
            system_module,
            previous_quantity,
            adjust_quantity,
            new_quantity,
            status
          )
          VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, 'stock out', $8, $9, $10, 'active'
          )
          `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            selectedBatch,
            user_id,
            comment,
            previous_quantity,
            -adjust_quantity,
            new_quantity,
          ],
        );
      }
    }

    await client.query("COMMIT");

    await insertAdminLog(
      returned_by,
      "PRN",
      `Created PRN #${prn_id} for PO #${po_id} | Total Qty: ${total_return_qty}`,
    );

    return res.status(201).json({
      message: "PRN created successfully with batch-wise stock out",
      po_id: Number(po_id),
      grn_id: Number(grn_id),
      prn_id: Number(prn_id),
    });
  } catch (error) {
    await client.query("ROLLBACK");

    console.error("Create PRN Error:", error);

    return res.status(500).json({
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch prn list
router.get("/prn-list", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    let {
      supplier_id,
      status,
      date_from,
      date_to,
      po_id,
      grn_id,
      page = 1,
      limit = 25,
    } = req.query;

    /* ================= PAGINATION ================= */
    page = parseInt(page) || 1;
    limit = parseInt(limit) || 25;
    const offset = (page - 1) * limit;

    let conditions = [];
    let values = [];
    let index = 1;

    /* ================= OR FILTER BLOCK (IDs) ================= */
    let idConditions = [];

    if (supplier_id && supplier_id !== "all" && supplier_id !== "") {
      idConditions.push(`ph.supplier_id = $${index++}`);
      values.push(parseInt(supplier_id));
    }

    if (po_id && po_id !== "") {
      idConditions.push(`ph.po_id = $${index++}`);
      values.push(parseInt(po_id));
    }

    if (grn_id && grn_id !== "") {
      idConditions.push(`ph.grn_id = $${index++}`);
      values.push(parseInt(grn_id));
    }

    // If any ID filter exists, wrap them with OR
    if (idConditions.length > 0) {
      conditions.push(`(${idConditions.join(" OR ")})`);
    }

    /* ================= STATUS FILTER (AND) ================= */
    if (status && status !== "all" && status !== "") {
      conditions.push(`ph.status = $${index++}`);
      values.push(status);
    }

    /* ================= DATE FILTERS (AND) ================= */
    if (date_from && date_from !== "") {
      conditions.push(`ph.prn_date >= $${index++}`);
      values.push(date_from);
    }

    if (date_to && date_to !== "") {
      conditions.push(`ph.prn_date <= $${index++}`);
      values.push(date_to);
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    console.log("WHERE:", whereClause);
    console.log("VALUES:", values);

    /* ================= COUNT QUERY ================= */
    const countQuery = `
      SELECT COUNT(*)
      FROM prn_header ph
      ${whereClause}
    `;

    const countResult = await client.query(countQuery, values);
    const totalRecords = parseInt(countResult.rows[0].count);
    const totalPages = Math.ceil(totalRecords / limit);

    /* ================= MAIN QUERY ================= */
    const mainQuery = `
      SELECT
        ph.prn_id,
        ph.prn_date,
        ph.po_id,
        ph.grn_id,
        ph.status,
        ph.total_return_qty,
        ph.total_return_amount,
        ph.returned_date,
        ph.authorized_date,
        ph.created_at,

        s.business_name,
        s.supplier_id,

        CONCAT(u.first_name, ' ', u.last_name) AS returned_user_name

      FROM prn_header ph

      LEFT JOIN suppliers s
        ON s.supplier_id = ph.supplier_id

      LEFT JOIN users u
        ON u.user_id = ph.returned_by

      ${whereClause}

      ORDER BY ph.prn_id DESC
      LIMIT $${index++}
      OFFSET $${index++}
    `;

    const finalValues = [...values, limit, offset];
    const result = await client.query(mainQuery, finalValues);

    /* ================= FETCH CURRENCY ================= */
    const currencyResult = await client.query(`
      SELECT currency
      FROM system_settings
      LIMIT 1
    `);

    const currency =
      currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : null;

    return res.status(200).json({
      success: true,
      message: "PRN list fetched successfully",
      data: {
        records: result.rows,
        pagination: {
          current_page: page,
          per_page: limit,
          total_records: totalRecords,
          total_pages: totalPages,
        },
        currency,
      },
    });
  } catch (error) {
    console.error("Fetch PRN List Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  } finally {
    client.release();
  }
});

// prn view

router.get(
  "/prn-details-by-grn/:grn_id",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const { grn_id } = req.params;

      if (!grn_id) {
        return res.status(400).json({
          message: "grn_id is required",
        });
      }

      /* ================= FETCH PRN HEADER ================= */

      const headerQuery = `
        SELECT
          ph.prn_id,
          ph.prn_date,
          ph.po_id,
          ph.grn_id,
          ph.status,
          ph.total_return_qty,
          ph.total_return_amount,
          ph.remark,
          ph.returned_date,
          ph.authorized_date,
          ph.created_at,

          -- Supplier
          s.supplier_id,
          s.business_name,
          s.address,
          s.mobile_no,
          s.contact_no,
          s.email,

          -- Returned User
          CONCAT(u.first_name, ' ', u.last_name) AS returned_user_name,

          -- Authorized User
          CONCAT(au.first_name, ' ', au.last_name) AS authorized_user_name

        FROM prn_header ph

        LEFT JOIN suppliers s
          ON s.supplier_id = ph.supplier_id

        LEFT JOIN users u
          ON u.user_id = ph.returned_by

        LEFT JOIN users au
          ON au.user_id = ph.authorized_by

        WHERE ph.grn_id = $1
        ORDER BY ph.prn_id DESC
        LIMIT 1
      `;

      const headerResult = await client.query(headerQuery, [grn_id]);

      if (headerResult.rows.length === 0) {
        return res.status(404).json({
          message: "PRN not found for this GRN",
        });
      }

      const header = headerResult.rows[0];

      /* ================= FETCH PRN ITEMS ================= */

      const itemsQuery = `
  SELECT
    pi.prn_item_id,
    pi.grn_item_id,
    pi.po_item_id,
    pi.product_id,
    pi.variant_id,
    pi.batch_number,
    pi.ordered_qty,
    pi.received_qty,
    pi.return_qty,
    pi.unit_cost,
    pi.line_total,
    pi.reason,

    -- Product
    p.title AS product_title,

    -- Variant
    pv.variant_value,
    pv.barcode,
    pv.weight,

    -- From GRN Items
    gi.amount_per_unit,
    gi.line_total AS grn_line_total,

    -- Measurement Value
    m.measurement_value

  FROM prn_items pi

  LEFT JOIN grn_items gi
    ON gi.grn_item_id = pi.grn_item_id

  LEFT JOIN measurements m
    ON m.measurement_id = gi.measurement_unit

  LEFT JOIN products p
    ON p.product_id = pi.product_id

  LEFT JOIN product_variants pv
    ON pv.variant_id = pi.variant_id

  WHERE pi.prn_id = $1
`;

      const itemsResult = await client.query(itemsQuery, [header.prn_id]);

      /* ================= FETCH CURRENCY ================= */

      const currencyQuery = `
        SELECT currency
        FROM system_settings
        LIMIT 1
      `;
      const currencyResult = await client.query(currencyQuery);

      const currency =
        currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : null;

      /* ================= FETCH BRANDING ================= */

      const brandingQuery = `
  SELECT company_name, logo_url_white
  FROM branding_settings
  LIMIT 1
`;
      const brandingResult = await client.query(brandingQuery);

      const company_name =
        brandingResult.rows.length > 0
          ? brandingResult.rows[0].company_name
          : null;

      const logo_url_white =
        brandingResult.rows.length > 0
          ? brandingResult.rows[0].logo_url_white
          : null;
      /* ================= RESPONSE ================= */

      return res.status(200).json({
        success: true,
        message: "PRN details fetched successfully",
        data: {
          header,
          items: itemsResult.rows,
          currency,
          logo_url_white,
          company_name,
        },
      });
    } catch (error) {
      console.error("Fetch PRN Details Error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    } finally {
      client.release();
    }
  },
);
module.exports = router;
