const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const updateTransactionRecord = require("../../routes/transactionsUpdater/transactionsUpdater");
const multer = require("multer");
const {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} = require("@aws-sdk/client-s3");
require("dotenv").config();

const storage = multer.memoryStorage();
const upload = multer({ storage });

/* ================= S3 CLIENT ================= */

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

const PUBLIC_URL_PREFIX = process.env.CONVERT_S3_URL;

/* ================= UPLOAD PAYMENT SLIP ================= */

router.post("/upload-payment-slip", upload.single("file"), async (req, res) => {
  const { po_id, supplier_id } = req.body;
  const file = req.file;

  if (!file || !po_id || !supplier_id) {
    return res.status(400).json({
      error: "File, po_id and supplier_id are required.",
    });
  }

  try {
    const timestamp = Date.now();
    const cleanName = file.originalname.replace(/\s+/g, "_");

    //  NEW PATH FOR PAYMENT SLIPS
    const newFileName = `Payment_Slips/Purchasing_Manager/PO_${po_id}/${timestamp}-${cleanName}`;

    const params = {
      Bucket: process.env.S3_BUCKET_NAME,
      Key: newFileName,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: "public-read",
    };

    await s3.send(new PutObjectCommand(params));

    const publicUrl = `${PUBLIC_URL_PREFIX}/${newFileName}`;

    return res.status(200).json({
      message: "Payment slip uploaded successfully",
      data: {
        po_id,
        supplier_id,
        slip_url: publicUrl,
        uploaded_at: new Date(),
      },
    });
  } catch (err) {
    console.error("Payment Slip Upload Error:", err);
    return res.status(500).json({ error: "File upload failed" });
  }
});

router.get("/po-total-after-returns/:po_id", async (req, res) => {
  const { po_id } = req.params;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* CHECK IF ANY GRN EXISTS */
    const grnCheckQuery = `
      SELECT EXISTS (
        SELECT 1
        FROM grn_header
        WHERE po_id = $1
      ) AS has_grn
    `;

    const grnCheckResult = await client.query(grnCheckQuery, [po_id]);
    const hasGRN = grnCheckResult.rows[0].has_grn;

    /* ORIGINAL TOTAL QUERY (UNCHANGED) */
    const totalQuery = `
      WITH grn_totals AS (
        SELECT
          gh.po_id,

          SUM(COALESCE(gi.received_qty, 0))::numeric AS total_received_qty,

          COALESCE(SUM(prn_totals.return_qty), 0)::numeric AS total_returned_qty,

          (
            SUM(COALESCE(gi.received_qty, 0))
            -
            COALESCE(SUM(prn_totals.return_qty), 0)
          )::numeric AS total_actual_received_qty,

          SUM(
            (
              COALESCE(gi.received_qty, 0)
              -
              COALESCE(prn_totals.return_qty, 0)
            ) * gi.unit_cost
          )::numeric AS total_after_returns

        FROM grn_items gi
        JOIN grn_header gh ON gh.grn_id = gi.grn_id

      

LEFT JOIN LATERAL (
  SELECT
    SUM(pi.return_qty) AS return_qty
  FROM prn_items pi
  JOIN prn_header ph2 ON ph2.prn_id = pi.prn_id
  WHERE ph2.po_id = gh.po_id
    AND pi.product_id = gi.product_id
    AND (
      (pi.variant_id IS NULL AND gi.variant_id IS NULL)
      OR pi.variant_id = gi.variant_id
    )
) prn_totals ON true

        WHERE gh.po_id = $1
        GROUP BY gh.po_id
      ),

      payment_totals AS (
        SELECT
          po_id,
          COALESCE(SUM(paid_amount), 0)::numeric AS total_paid_amount
        FROM supplier_payments
        WHERE po_id = $1
        GROUP BY po_id
      )

      SELECT
        COALESCE(g.po_id, $1::int) AS po_id,
        COALESCE(g.total_received_qty, 0) AS total_received_qty,
        COALESCE(g.total_returned_qty, 0) AS total_returned_qty,
        COALESCE(g.total_actual_received_qty, 0) AS total_actual_received_qty,
        COALESCE(g.total_after_returns, 0) AS total_after_returns,
        COALESCE(p.total_paid_amount, 0) AS total_paid_amount,

  CASE
  WHEN COALESCE(g.total_actual_received_qty, 0) = 0
  THEN 0
  ELSE (
    COALESCE(g.total_after_returns, 0)
    -
    COALESCE(p.total_paid_amount, 0)
  )
END::numeric AS total_payable_amount,

        CASE
          WHEN (
            COALESCE(g.total_after_returns, 0)
            -
            COALESCE(p.total_paid_amount, 0)
          ) <= 0
          THEN true
          ELSE false
        END AS is_fully_paid

      FROM grn_totals g
      FULL OUTER JOIN payment_totals p
        ON g.po_id = p.po_id
    `;

    const result = await client.query(totalQuery, [po_id]);

    /* IF NO ROW */
    if (result.rows.length === 0) {
      return res.status(200).json({
        message: "success",
        data: {
          po_id: Number(po_id),
          total_received_qty: 0,
          total_returned_qty: 0,
          total_actual_received_qty: 0,
          total_after_returns: 0,
          total_paid_amount: 0,
          total_payable_amount: 0,
          is_fully_paid: false,
          grns_available: hasGRN,
        },
      });
    }

    const row = result.rows[0];

    return res.status(200).json({
      message: "success",
      data: {
        po_id: Number(row.po_id),
        total_received_qty: Number(row.total_received_qty),
        total_returned_qty: Number(row.total_returned_qty),
        total_actual_received_qty: Number(row.total_actual_received_qty),
        total_after_returns: Number(row.total_after_returns),
        total_paid_amount: Number(row.total_paid_amount),
        total_payable_amount: Number(row.total_payable_amount),
        is_fully_paid: hasGRN ? row.is_fully_paid : false,

        // NEW FIELD
        grns_available: hasGRN,
      },
    });
  } catch (error) {
    console.error("Fetch PO Total After Returns Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

/* ================= CREATE SUPPLIER PAYMENT ================= */

router.post("/add-supplier-payment", async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      paid_amount,
      po_id,
      supplier_id,
      payment_note,
      slip_url,
      voucher_id,
      grn_id,
      po_amount,
      due_amount,
      by_user_id,
      account_id,
    } = req.body;

    /* ================= VALIDATION ================= */

    if (!paid_amount || !po_id || !supplier_id || !by_user_id || !account_id) {
      return res.status(400).json({
        message:
          "paid_amount, po_id, supplier_id, account_id, by_user_id are required",
      });
    }

    if (Number(paid_amount) <= 0) {
      return res.status(400).json({
        message: "Paid amount must be greater than zero",
      });
    }

    await client.query("BEGIN");

    /* ================= DETERMINE STATUS ================= */

    let status = "PENDING";

    if (due_amount !== null && due_amount !== undefined) {
      if (Number(due_amount) - Number(paid_amount) <= 0) {
        status = "PAID";
      } else {
        status = "PARTIAL";
      }
    }

    /* ================= INSERT SUPPLIER PAYMENT ================= */

    const insertQuery = `
      INSERT INTO supplier_payments (
        paid_amount,
        po_id,
        supplier_id,
        payment_note,
        slip_url,
        voucher_id,
        status,
        grn_id,
        po_amount,
        due_amount,
        by_user_id
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      RETURNING *
    `;

    const values = [
      paid_amount,
      po_id,
      supplier_id,
      payment_note || null,
      slip_url || null,
      voucher_id || null,
      status,
      grn_id || null,
      po_amount || null,
      due_amount || null,
      by_user_id,
    ];

    const result = await client.query(insertQuery, values);
    const insertedPayment = result.rows[0];

    /* ================= CREATE TRANSACTION + ACCOUNT STATEMENT ================= */

    const transactionResult = await updateTransactionRecord({
      client,
      amount: paid_amount,
      account_id,
      category_id: 3, // ✅ Supplier Payment category
      transaction_type: "expense",
      note: payment_note || `Supplier payment for PO #${po_id}`,
      by_user_id,
      payer_payee_id: supplier_id,
      log_module: "SUPPLIER_PAYMENT_TRANSACTION",
      log_message: `Supplier payment transaction | PO #${po_id} | Amount: ${paid_amount}`,
    });

    const newTransaction = transactionResult.transaction;

    /* ================= ADMIN LOG ================= */

    console.log("Logging supplier payment...");

    const supplierPaymentLogModule = "SUPPLIER_PAYMENT";
    const supplierPaymentLogMessage = `Supplier payment added | PO #${po_id} | Payment ID: ${insertedPayment.payment_id} | Amount: ${paid_amount}`;

    await insertAdminLog(
      by_user_id,
      supplierPaymentLogModule,
      supplierPaymentLogMessage,
    );

    const transactionLogModule = "Supplier Payment";
    const transactionLogMessage = `Transaction created from supplier payment | TX ID: ${newTransaction.transaction_id} | Amount: ${paid_amount}`;

    await insertAdminLog(
      by_user_id,
      transactionLogModule,
      transactionLogMessage,
    );

    await client.query("COMMIT");

    return res.status(201).json({
      message: "Supplier payment created successfully",
      data: insertedPayment,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create Supplier Payment Error:", error);

    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch

router.get("/supplier-payment-list/:po_id", async (req, res) => {
  const { po_id } = req.params;
  const page = parseInt(req.query.page) || 1;
  const limit = 10;
  const offset = (page - 1) * limit;

  if (!po_id) {
    return res.status(400).json({
      message: "po_id is required",
    });
  }

  const client = await pool.connect();

  try {
    /* ===== Get Total Count ===== */
    const countQuery = `
      SELECT COUNT(*) 
      FROM supplier_payments 
      WHERE po_id = $1
    `;
    const countResult = await client.query(countQuery, [po_id]);
    const totalRecords = parseInt(countResult.rows[0].count);

    /* ===== Get Paginated Data ===== */
    const dataQuery = `
      SELECT
        sp.payment_id,
        sp.paid_amount,
        sp.po_id,
        sp.supplier_id,
        sp.payment_note,
        sp.slip_url,
        sp.voucher_id,
        sp.status,
        sp.grn_id,
        sp.po_amount,
        sp.due_amount,
        sp.by_user_id,
        sp.created_at,

        s.business_name AS supplier_name,
        CONCAT(u.first_name, ' ', u.last_name) AS created_by_name

      FROM supplier_payments sp
      LEFT JOIN suppliers s ON s.supplier_id = sp.supplier_id
      LEFT JOIN users u ON u.user_id = sp.by_user_id

      WHERE sp.po_id = $1
      ORDER BY sp.payment_id DESC
      LIMIT $2 OFFSET $3
    `;

    const result = await client.query(dataQuery, [po_id, limit, offset]);

    /* ================= FETCH BRANDING SETTINGS ================= */

    const brandingQuery = `
      SELECT
        company_name,
        slogan,
        address_1,
        address_2,
        hotline,
        customer_support_phone,
        support_email,
        info_email,
        logo_url_white,
        billing_email,
        website_url
      FROM branding_settings
      WHERE id = 1
    `;

    const brandingResult = await client.query(brandingQuery);
    const branding_settings =
      brandingResult.rows.length > 0 ? brandingResult.rows[0] : null;

    /* ================= FETCH SYSTEM SETTINGS (CURRENCY) ================= */

    const systemSettingsQuery = `
      SELECT currency
      FROM system_settings
      LIMIT 1
    `;

    const systemSettingsResult = await client.query(systemSettingsQuery);

    const currency =
      systemSettingsResult.rows.length > 0
        ? systemSettingsResult.rows[0].currency
        : null;

    /* ================= RESPONSE ================= */

    return res.status(200).json({
      message: "success",
      pagination: {
        totalRecords,
        totalPages: Math.ceil(totalRecords / limit),
        currentPage: page,
        perPage: limit,
      },
      data: result.rows,
      branding_settings, // added
      currency, // added
    });
  } catch (error) {
    console.error("Fetch Supplier Payments Error:", error);
    return res.status(500).json({
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

module.exports = router;
