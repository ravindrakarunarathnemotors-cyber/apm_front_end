const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertNotification } = require("../../models/notificationsUpdater");

router.get("/system-config", authenticateToken, async (req, res) => {
  try {

    const systemSettingsQuery = `
      SELECT currency, date_format, default_timezone
      FROM system_settings
      LIMIT 1
    `;

    const brandingSettingsQuery = `
      SELECT logo_url_white, address_1, address_2, logo_url, company_name, slogan
      FROM branding_settings
      LIMIT 1
    `;

    const [systemResult, brandingResult] = await Promise.all([
      pool.query(systemSettingsQuery),
      pool.query(brandingSettingsQuery)
    ]);

    res.json({
      system_settings: systemResult.rows?.[0] || {},
      branding_settings: brandingResult.rows?.[0] || {}
    });

  } catch (err) {
    console.error("System config fetch error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
