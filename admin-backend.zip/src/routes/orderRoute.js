const express = require("express");
const { getProductSearch, addOrder, createCustomer, addOrderpaid } = require("../controllers/orderController");
const router = express.Router();
const authenticateToken = require("../middleware/authMiddleware");
const pool = require("../config/db");

const { createInvoice, partiallyPayment, oneInvoiceUpdateDetails, updateInvoice, deleteInvoice, deleteBackOfficeInvoice } = require("../controllers/InvoiceController");

// const { createInvoice, partiallyPayment, oneInvoiceUpdateDetails, updateInvoice } = require("../controllers/InvoiceController");
const { createQuotation, oneQuotationUpdateDetails, updateQuotation, createCustomerQuo } = require("../controllers/quotationController");





router.get("/getProductSearch", authenticateToken, getProductSearch);

router.post("/addOrder", authenticateToken, addOrder);

router.post("/createCustomer", authenticateToken, createCustomer);

router.post("/addOrderpaid", authenticateToken, addOrderpaid);

// router.post("/register", register);




//invoice section 
router.post("/addInvoice", authenticateToken, createInvoice);
router.post("/addQuotation", authenticateToken, createQuotation);
router.post("/createCustomerQuo", authenticateToken, createCustomerQuo);
router.get("/oneQuotationUpdateDetails/:order_id", authenticateToken, oneQuotationUpdateDetails);
router.post("/partiallyPayment", authenticateToken, partiallyPayment);

router.post("/deleteInvoice", authenticateToken, deleteInvoice);

router.post("/deleteBackOfficeInvoice", authenticateToken, deleteBackOfficeInvoice);


router.get("/oneInvoiceUpdateDetails/:order_id", authenticateToken, oneInvoiceUpdateDetails);

router.put("/updateInvoice/:order_id", authenticateToken, updateInvoice);

router.put("/updateQuotation/:order_id", authenticateToken, updateQuotation);


router.post("/print-catelog", async (req, res) => {
    const { id } = req.body

    try {
        const quotationHeader = `SELECT * FROM quotation_header WHERE id = $1`
        const quotationDetails = `SELECT q.product_id, p.title, p.description, pm.media_url AS main_img
                              FROM invoice_details q
                              LEFT JOIN products p ON p.product_id = q.product_id
                              LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL 
                              WHERE q.invoice_id = $1 AND q.is_custom = false`

        const quotationDetailsResult = await pool.query(quotationDetails, [id])

        if (quotationDetailsResult.rows.length === 0) {
            return res.status(404).json({ message: "Quotation not found" })
        }

        const details = quotationDetailsResult.rows

        return res.status(200).json({ message: "success", details });
    } catch (error) {
       
        console.log(error)
        return res.status(500).json({ message: error.message || "Internal server error" })
    }
})

module.exports = router;