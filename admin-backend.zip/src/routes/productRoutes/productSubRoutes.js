const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");
const { insertAdminLog } = require("../../models/userLogs");

router.get("/variants", authenticateToken, async (req, res) => {
  try {
    const query = "SELECT id, option_name, values FROM variants";
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching variants:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/variants_barcodes", authenticateToken, async (req, res) => {
  const { page = 1, limit = 10, keyword = "", created_at } = req.body;

  const { merchant_id } = req.user;

  try {
    const parsedPage = parseInt(page, 10);
    const parsedLimit = parseInt(limit, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    /* ------------------ WHERE CONDITIONS ------------------ */
    let whereConditions = ["p.merchant_id = $1"];
    let params = [merchant_id];

    // Date filter
    if (created_at) {
      params.push(created_at);
      whereConditions.push(`p.created_at::date = $${params.length}`);
    }

    // Keyword filter (ID or Name)
    if (keyword && keyword.trim() !== "") {
      const trimmed = keyword.trim();

      if (/^\d+$/.test(trimmed)) {
        // numeric → product_id
        params.push(parseInt(trimmed, 10));
        whereConditions.push(`p.product_id = $${params.length}`);
      } else {
        // text → product title
        params.push(`%${trimmed}%`);
        whereConditions.push(`p.title ILIKE $${params.length}`);
      }
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    /* ------------------ MAIN QUERY ------------------ */
    const dataQuery = `
        SELECT
          v.variant_id,
          v.variant_value,
          v.barcode,
          v.product_id,
          p.title,
          p.created_at
        FROM product_variants v
        INNER JOIN products p ON p.product_id = v.product_id
        ${whereClause}
        ORDER BY p.created_at DESC
        LIMIT $${params.length + 1}
        OFFSET $${params.length + 2}
      `;

    /* ------------------ COUNT QUERY ------------------ */
    const countQuery = `
        SELECT COUNT(*) AS total
        FROM product_variants v
        INNER JOIN products p ON p.product_id = v.product_id
        ${whereClause}
      `;

    /* ------------------ PROMISE.ALL ------------------ */
    const [dataResult, countResult] = await Promise.all([
      pool.query(dataQuery, [...params, parsedLimit, offset]),
      pool.query(countQuery, params),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      products: dataResult.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Variants & Barcodes error:", error);
    res.status(500).json({
      message: "Failed to fetch variants & barcodes",
    });
  }
});

router.post("/add-variants", authenticateToken, async (req, res) => {
  try {
    const { option_name, values } = req.body;
    const user = req.user;
    const user_id = user?.user_id;

    // ---------------------------
    // 🔧 Helper: sanitize text
    // ---------------------------
    const sanitizeText = (text) => {
      if (typeof text !== "string") return "";
      return text.trim().replace(/\s+/g, " ");
    };

    // ---------------------------
    // 1. Validate input
    // ---------------------------
    if (!option_name || typeof option_name !== "string") {
      return res.status(400).json({
        error: "option_name is required and must be a string",
      });
    }

    if (!Array.isArray(values) || values.length === 0) {
      return res.status(400).json({
        error: "values must be a non-empty array",
      });
    }

    // ---------------------------
    // 2. Sanitize input
    // ---------------------------
    const cleanOptionName = sanitizeText(option_name);

    let cleanValues = values
      .map((v) => sanitizeText(v))
      .filter((v) => v.length > 0); // remove empty

    // remove duplicates (case-insensitive)
    cleanValues = Array.from(
      new Map(cleanValues.map((v) => [v.toLowerCase(), v])).values(),
    );

    if (cleanValues.length === 0) {
      return res.status(400).json({
        error: "values cannot be empty after sanitization",
      });
    }

    // ---------------------------
    // 3. Check duplicate option_name (case + trim safe)
    // ---------------------------
    const existing = await pool.query(
      `
      SELECT id 
      FROM variants 
      WHERE LOWER(TRIM(option_name)) = LOWER(TRIM($1))
      `,
      [cleanOptionName],
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({
        error: "Option name already exists",
      });
    }

    // ---------------------------
    // 4. Insert into DB
    // ---------------------------
    const insertQuery = `
      INSERT INTO variants (option_name, values)
      VALUES ($1, $2)
      RETURNING id, option_name, values
    `;

    const { rows } = await pool.query(insertQuery, [
      cleanOptionName,
      cleanValues,
    ]);

    const created = rows[0];

    // ---------------------------
    // 5. Logging (safe + clean)
    // ---------------------------
    const module = "Variant";
    const logMessage = `User ${user_id} added variant option '${cleanOptionName}' with values [${cleanValues.join(", ")}]`;

    insertAdminLog(user_id, module, logMessage).catch((e) =>
      console.warn("Admin log failed:", e.message),
    );

    // ---------------------------
    // 6. Response
    // ---------------------------
    return res.status(201).json(created);
  } catch (err) {
    console.error("Error inserting variant:", err);
    return res.status(500).json({
      error: "Internal server error",
    });
  }
});

// ....................update variants

// PUT /variants/:id
router.put("/variants/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { option_name, values } = req.body;
  const user = req.user;
  const user_id = user?.user_id;

  try {
    // ---------------------------
    // 🔧 Helper: sanitize text (NO lowercase)
    // ---------------------------
    const sanitizeText = (text) => {
      if (typeof text !== "string") return "";
      return text.trim().replace(/\s+/g, " ");
    };

    // ---------------------------
    // 1. Validate ID
    // ---------------------------
    if (!id) {
      return res.status(400).json({ error: "ID is required" });
    }

    // ---------------------------
    // 2. Prepare updates
    // ---------------------------
    const updates = [];
    const valuesArray = [];
    let paramIndex = 1;

    let cleanOptionName;
    let cleanValues;

    // ---------------------------
    // 3. Sanitize option_name
    // ---------------------------
    if (option_name !== undefined) {
      cleanOptionName = sanitizeText(option_name);

      if (!cleanOptionName) {
        return res.status(400).json({
          error: "option_name cannot be empty",
        });
      }

      // Check duplicate (ignore current ID)
      const existing = await pool.query(
        `
        SELECT id FROM variants 
        WHERE LOWER(TRIM(option_name)) = LOWER(TRIM($1))
        AND id != $2
        `,
        [cleanOptionName, id],
      );

      if (existing.rows.length > 0) {
        return res.status(409).json({
          error: "Option name already exists",
        });
      }

      updates.push(`option_name = $${paramIndex++}`);
      valuesArray.push(cleanOptionName);
    }

    // ---------------------------
    // 4. Sanitize values
    // ---------------------------
    if (values !== undefined) {
      if (!Array.isArray(values)) {
        return res.status(400).json({
          error: "values must be an array",
        });
      }

      cleanValues = values
        .map((v) => sanitizeText(v))
        .filter((v) => v.length > 0);

      // remove duplicates (case-insensitive, keep original casing)
      cleanValues = Array.from(
        new Map(cleanValues.map((v) => [v.toLowerCase(), v])).values(),
      );

      if (cleanValues.length === 0) {
        return res.status(400).json({
          error: "values cannot be empty after sanitization",
        });
      }

      updates.push(`values = $${paramIndex++}`);
      valuesArray.push(cleanValues);
    }

    // ---------------------------
    // 5. No fields check
    // ---------------------------
    if (updates.length === 0) {
      return res.status(400).json({ error: "No fields to update" });
    }

    // ---------------------------
    // 6. Execute update
    // ---------------------------
    valuesArray.push(id);

    const query = `
      UPDATE variants
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING id, option_name, values
    `;

    const result = await pool.query(query, valuesArray);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Variant not found" });
    }

    const updated = result.rows[0];

    // ---------------------------
    // 7. Admin Log
    // ---------------------------
    const module = "Variant";

    let logMessage = `User ${user_id} updated variant ID ${id}`;

    if (cleanOptionName !== undefined) {
      logMessage += ` | Name: '${cleanOptionName}'`;
    }

    if (cleanValues !== undefined) {
      logMessage += ` | Values: [${cleanValues.join(", ")}]`;
    }

    insertAdminLog(user_id, module, logMessage).catch((e) =>
      console.warn("Admin log failed:", e.message),
    );

    // ---------------------------
    // 8. Response
    // ---------------------------
    return res.json(updated);
  } catch (err) {
    console.error("Error updating variant:", err);
    return res.status(500).json({
      error: "Internal server error",
    });
  }
});

// fetch categories parent / children categorization / lineage
router.get(
  "/product-category-lineage/:productId",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();
    const { productId } = req.params;

    try {
      // Step 1: Get the category_id for this product
      const catRes = await client.query(
        `SELECT category_id FROM product_category WHERE product_id = $1 LIMIT 1`,
        [productId],
      );

      if (catRes.rows.length === 0) {
        return res
          .status(404)
          .json({ error: "No category linked to this product" });
      }

      let currentId = catRes.rows[0].category_id;
      const lineage = [];

      // Step 2: Trace up to the main category
      while (currentId) {
        const { rows } = await client.query(
          `SELECT * FROM categories WHERE category_id = $1`,
          [currentId],
        );

        if (rows.length === 0) break;

        const current = rows[0];
        lineage.push(current);

        if (!current.category_under || current.category_under === 0) break;

        currentId = current.category_under;
      }

      res.json({ category_lineage: lineage.reverse() }); // Root → Assigned
    } catch (err) {
      console.error("Error fetching category lineage:", err);
      res.status(500).json({ error: "Internal Server Error" });
    } finally {
      client.release();
    }
  },
);
// fetch / get categories all where status=active

router.get("/get-categories", authenticateToken, async (req, res) => {
  try {
    const { level } = req.query;
    let query = `
      SELECT 
        category_id, merchant_id, name, description, created_at,
        category_under, related_ui, mobile_url, desktop_url, show_on_main_menu
      FROM categories
      WHERE status = 'active'
    `;
    let values = [];

    if (level === "0") {
      // Main categories (no parent)
      query += ` AND (category_under IS NULL OR category_under = 0)`;
    } else if (level === "1") {
      // Sub categories (parent is main)
      query += ` AND category_under IN (
        SELECT category_id FROM categories 
        WHERE (category_under IS NULL OR category_under = 0) AND status = 'active'
      )`;
    } else if (level === "2") {
      // Child categories (parent is sub)
      query += ` AND category_under IN (
        SELECT category_id FROM categories 
        WHERE category_under IN (
          SELECT category_id FROM categories 
          WHERE (category_under IS NULL OR category_under = 0) AND status = 'active'
        ) AND status = 'active'
      )`;
    }

    const { rows } = await pool.query(query, values);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// add categories
router.post("/add-category", authenticateToken, async (req, res) => {
  try {
    const {
      name,
      description,
      category_under,
      related_ui,
      mobile_url,
      desktop_url,
      show_on_main_menu,
    } = req.body;

    const { merchant_id, user_id } = req.user; // ✅ From token

    if (!name || typeof name !== "string") {
      return res
        .status(400)
        .json({ error: "Category name is required and must be a string" });
    }

    // ✅ Check if category with same name exists for this merchant
    const existing = await pool.query(
      "SELECT category_id FROM categories WHERE name = $1 AND merchant_id = $2",
      [name, merchant_id],
    );

    if (existing.rows.length > 0) {
      return res
        .status(400)
        .json({ error: "A category with this name already exists." });
    }

    // ✅ INSERT new category only
    const insertQuery = `
      INSERT INTO categories (
        merchant_id, name, description, category_under, related_ui,
        mobile_url, desktop_url, show_on_main_menu
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *;
    `;

    const values = [
      merchant_id,
      name,
      description || null,
      category_under || null,
      related_ui || null,
      mobile_url || null,
      desktop_url || null,
      show_on_main_menu ?? false,
    ];

    const inserted = await pool.query(insertQuery, values);
    const newCategory = inserted.rows[0];
    const module = "Category";
    const logMessage = `User ${user_id} created category ${newCategory.category_id} with name '${name}'`;
    await insertAdminLog(user_id, module, logMessage);
    return res
      .status(201)
      .json({ message: "New category created", data: inserted.rows[0] });
  } catch (err) {
    console.error("Error handling category:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// const MERCHANT_ID = '20001';

router.get("/get-collections", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user; // ✅ Securely from token
  try {
    const result = await pool.query(
      `SELECT * FROM collections WHERE merchant_id = $1 ORDER BY created_at DESC`,
      [merchant_id],
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching collections:", err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/getallcollections", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user; // ✅ Securely from token
  try {
    const {
      page = 1,
      limit = 25,
      collectname,
      created_at,
      keyword,
      collect_state,
      id,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];

    // if (id) {
    //   queryParams.push(id);
    //   whereConditions.push(`collection_id = $${queryParams.length}`);
    // }
    // if (collectname) {
    //   queryParams.push(`%${collectname}%`);
    //   whereConditions.push(`name ILIKE $${queryParams.length}`);
    // }

    if (keyword && keyword.trim() !== "") {
      const trimmed = keyword.trim();

      if (/^\d+$/.test(trimmed)) {
        queryParams.push(parseInt(trimmed, 10));
        whereConditions.push(`collection_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmed}%`);
        whereConditions.push(`name ILIKE $${queryParams.length}`);
      }
    } else {
      if (id) {
        queryParams.push(id);
        whereConditions.push(`collection_id = $${queryParams.length}`);
      }
      if (collectname) {
        queryParams.push(`%${collectname}%`);
        whereConditions.push(`name ILIKE $${queryParams.length}`);
      }
    }

    if (collect_state) {
      queryParams.push(collect_state);
      whereConditions.push(`status = $${queryParams.length}`);
    }
    if (created_at) {
      queryParams.push(created_at);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const collectionsQuery = `
      SELECT 
        *
      FROM collections
      ${whereClause}
      ORDER BY collection_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(collectionsQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM collections
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      collections: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching collections:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/getallcategories", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user; // ✅ Securely from token

  try {
    const {
      page = 1,
      limit = 25,
      categorystate,
      category_name,
      description,
      collectdate,
      keyword,
      id,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [`merchant_id = $1`];

    // if (id) {
    //   queryParams.push(id);
    //   whereConditions.push(`category_id = $${queryParams.length}`);
    // }
    // if (category_name) {
    //   queryParams.push(`%${category_name}%`);
    //   whereConditions.push(`name ILIKE $${queryParams.length}`);
    // }

    if (keyword && keyword.trim() !== "") {
      const trimmed = keyword.trim();

      if (/^\d+$/.test(trimmed)) {
        queryParams.push(parseInt(trimmed, 10));
        whereConditions.push(`category_id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmed}%`);
        whereConditions.push(`name ILIKE $${queryParams.length}`);
      }
    } else {
      if (id) {
        queryParams.push(id);
        whereConditions.push(`category_id = $${queryParams.length}`);
      }
      if (category_name) {
        queryParams.push(`%${category_name}%`);
        whereConditions.push(`name ILIKE $${queryParams.length}`);
      }
    }
    if (categorystate) {
      queryParams.push(categorystate);
      whereConditions.push(`status = $${queryParams.length}`);
    }
    if (collectdate) {
      queryParams.push(collectdate);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    if (description) {
      queryParams.push(`%${description}%`);
      whereConditions.push(`description ILIKE $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const categoriesQuery = `
      SELECT 
        category_id, merchant_id, name, description, created_at,status,
        category_under, related_ui, mobile_url, desktop_url, show_on_main_menu
      FROM categories
      ${whereClause}
      ORDER BY category_id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(categoriesQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM categories
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      categories: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/variantsall", authenticateToken, async (req, res) => {
  try {
    const {
      variantname,
      variantstate,
      id,
      keyword,
      page = 1,
      limit = 25,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // if (id) {
    //   queryParams.push(id);
    //   whereConditions.push(`id = $${queryParams.length}`);
    // }
    // if (variantname) {
    //   queryParams.push(`%${variantname}%`);
    //   whereConditions.push(`option_name ILIKE $${queryParams.length}`);
    // }

    if (keyword && keyword.trim() !== "") {
      const trimmed = keyword.trim();

      if (/^\d+$/.test(trimmed)) {
        queryParams.push(parseInt(trimmed, 10));
        whereConditions.push(`id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmed}%`);
        whereConditions.push(`option_name ILIKE $${queryParams.length}`);
      }
    } else {
      if (id) {
        queryParams.push(id);
        whereConditions.push(`id = $${queryParams.length}`);
      }
      if (variantname) {
        queryParams.push(`%${variantname}%`);
        whereConditions.push(`option_name ILIKE $${queryParams.length}`);
      }
    }

    if (variantstate) {
      queryParams.push(variantstate);
      whereConditions.push(`status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const query = `
      SELECT id, option_name, values, status
      FROM variants
      ${whereClause}
      ORDER BY id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(query, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM variants
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      variants: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching variants:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/updateCategory", authenticateToken, async (req, res) => {
  try {
    const {
      category_id,
      name,
      description,
      show_on_main_menu,
      desktop_url = null,
      mobile_url = null,
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    if (!category_id || !name) {
      return res
        .status(400)
        .json({ error: "category_id and name are required." });
    }

    const result = await pool.query(
      "SELECT name, description, desktop_url, mobile_url FROM categories WHERE category_id = $1",
      [category_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Category not found." });
    }

    const current = result.rows[0];

    const isNameChanged = current.name !== name;
    const isDescriptionChanged = current.description !== description;
    const isDesktopUrlChanged = current.desktop_url !== desktop_url;
    const isMobileUrlChanged = current.mobile_url !== mobile_url;

    // ✅ Only skip update if *nothing* has changed
    if (
      !isNameChanged &&
      !isDescriptionChanged &&
      !isDesktopUrlChanged &&
      !isMobileUrlChanged
    ) {
      return res.status(200).json({ message: "No changes detected." });
    }

    await pool.query(
      `UPDATE categories 
       SET name = $1, description = $2, desktop_url = $3, mobile_url = $4, show_on_main_menu = $6
       WHERE category_id = $5`,
      [
        name,
        description,
        desktop_url,
        mobile_url,
        category_id,
        show_on_main_menu,
      ],
    );

    const module = "Category";
    const changes = [];
    if (isNameChanged) changes.push(`name: '${current.name}' → '${name}'`);
    if (isDescriptionChanged)
      changes.push(`description: '${current.description}' → '${description}'`);
    if (isDesktopUrlChanged)
      changes.push(`desktop_url: '${current.desktop_url}' → '${desktop_url}'`);
    if (isMobileUrlChanged)
      changes.push(`mobile_url: '${current.mobile_url}' → '${mobile_url}'`);

    const logMessage = `Updated Category ${category_id}: ${changes.join(", ")}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Category updated successfully." });
  } catch (error) {
    console.error("Error updating category:", error);
    res.status(500).json({ error: "Internal server error." });
  }
});

router.post("/updateCollections", authenticateToken, async (req, res) => {
  try {
    const {
      collection_id,
      name,
      description,
      desktop_url = null,
      mobile_url = null,
    } = req.body;

   const user = req.user;
   const user_id = user.user_id;

    if (!collection_id || !name) {
      return res
        .status(400)
        .json({ error: "collection_id and name are required." });
    }

    // Include desktop_url and mobile_url in SELECT so we can compare
    const result = await pool.query(
      "SELECT name, description, desktop_url, mobile_url FROM collections WHERE collection_id = $1",
      [collection_id],
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Collection not found." });
    }

    const current = result.rows[0];

    // Detect changes
    const isNameChanged = current.name !== name;
    const isDescriptionChanged = current.description !== description;
    const isDesktopUrlChanged = current.desktop_url !== desktop_url;
    const isMobileUrlChanged = current.mobile_url !== mobile_url;

    if (
      !isNameChanged &&
      !isDescriptionChanged &&
      !isDesktopUrlChanged &&
      !isMobileUrlChanged
    ) {
      return res.status(200).json({ message: "No changes detected." });
    }

    // Perform the update
    await pool.query(
      `UPDATE collections 
       SET name = $1, description = $2, desktop_url = $3, mobile_url = $4
       WHERE collection_id = $5`,
      [name, description, desktop_url, mobile_url, collection_id],
    );

    // Logging
    const module = "Collection";
    const changes = [];
    if (isNameChanged) changes.push(`name: '${current.name}' → '${name}'`);
    if (isDescriptionChanged)
      changes.push(`description: '${current.description}' → '${description}'`);
    if (isDesktopUrlChanged)
      changes.push(`desktop_url: '${current.desktop_url}' → '${desktop_url}'`);
    if (isMobileUrlChanged)
      changes.push(`mobile_url: '${current.mobile_url}' → '${mobile_url}'`);

    const logMessage = `Updated Collection ${collection_id}: ${changes.join(", ")}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Collection updated successfully." });
  } catch (error) {
    console.error("Error updating collections:", error);
    res.status(500).json({ error: "Internal server error." });
  }
});

router.post("/updatevariant", authenticateToken, async (req, res) => {
  try {
    const { id, option_name, values } = req.body;
    const user = req.user;
    const user_id = user.user_id;

    if (!id) {
      return res.status(400).json({ error: "Variant ID is required" });
    }

    if (!option_name || typeof option_name !== "string") {
      return res
        .status(400)
        .json({ error: "option_name is required and must be a string" });
    }

    if (
      !Array.isArray(values) ||
      values.length === 0 ||
      values.some((v) => typeof v !== "string")
    ) {
      return res
        .status(400)
        .json({ error: "values must be a non-empty array of strings" });
    }

    const existing = await pool.query(
      "SELECT option_name, values FROM variants WHERE id = $1",
      [id],
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({ error: "Variant not found" });
    }

    const current = existing.rows[0];
    const module = "Variant";
    const logMessage = `Updated Variant ${id}: option_name='${option_name}', values=${JSON.stringify(
      values,
    )}`;
    await insertAdminLog(user_id, module, logMessage);

    const isOptionNameChanged = current.option_name !== option_name;
    const areValuesChanged =
      JSON.stringify(current.values.sort()) !== JSON.stringify(values.sort());

    if (!isOptionNameChanged && !areValuesChanged) {
      return res.status(200).json({ message: "No changes detected" });
    }

    const updateQuery = `
      UPDATE variants
      SET option_name = $1,
          values = $2
      WHERE id = $3
      RETURNING id, option_name, values
    `;

    const { rows } = await pool.query(updateQuery, [option_name, values, id]);

    res.status(200).json({
      message: "Variant updated successfully",
      variant: rows[0],
    });
  } catch (err) {
    console.error("Error updating variant:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/collectstatus", async (req, res) => {
  const { collection_id, status } = req.body;

  const user = req.user;
  const user_id = user.user_id;
  if (!collection_id || !["active", "inactive"].includes(status)) {
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    const result = await pool.query(
      "UPDATE collections SET status = $1 WHERE collection_id = $2",
      [status, collection_id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Collection not found" });
    }

    const module = "Collections";
    const logMessage = `Updated collection ${collection_id} status to '${status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Error updating status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/categorystatus", authenticateToken, async (req, res) => {
  const { category_id, status } = req.body;

  const user = req.user;
  const user_id = user.user_id;

  if (!category_id || !["active", "inactive"].includes(status)) {
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    const result = await pool.query(
      "UPDATE categories SET status = $1 WHERE category_id = $2",
      [status, category_id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "category not found" });
    }

    const module = "Category";
    const logMessage = `Updated Category ${category_id} status to '${status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Error updating status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.post("/variantsstatus", authenticateToken, async (req, res) => {
  const { id } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  const status = req.body.status?.toLowerCase();

  console.log("status", status);

  try {
    const result = await pool.query(
      "UPDATE variants SET status = $1 WHERE id = $2",
      [status, id],
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "variant not found" });
    }

    const module = "Variant";
    const logMessage = `Updated Variant ${id} status to '${status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: "Status updated successfully" });
  } catch (error) {
    console.error("Error updating status:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// ......................................... Collections temporary route ..............................................

// TEMPORARY: hardcoded merchant_id (replace later with token-based value)
// const MERCHANT_ID = "20001"; // Replace with real UUID

router.post("/add-collection", authenticateToken, async (req, res) => {
  const user = req.user;
  const user_id = user.user_id;
  
  const {
    name,
    description,
    product_ids,
    status = "active",
    mobile_url,
    desktop_url,
  } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Collection name is required" });
  }

  try {
    const { merchant_id } = req.user; // ✅ Securely from token
    const result = await pool.query(
      `INSERT INTO collections (merchant_id, name, description, created_at, status,	product_id,mobile_url,desktop_url)
       VALUES ($1, $2, $3, NOW(), $4, $5, $6, $7)
       RETURNING *`,
      [
        merchant_id,
        name,
        description,
        status,
        product_ids,
        mobile_url,
        desktop_url,
      ],
    );

    // res.status(201).json(result.rows[0]);
    const collection = result.rows[0];
    const module = "Collections";
    const logMessage = `User ${user_id} created collection ${collection.collection_id} with name '${collection.name}' and status '${collection.status}'`;
    await insertAdminLog(user_id, module, logMessage);
    res.status(201).json(collection);
  } catch (err) {
    console.error("Error creating collection:", err);
    res.status(500).json({ error: "Server error" });
  }
});

// GET /collections - Get all collections for the merchant
router.get("/get-collections", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM collections WHERE merchant_id = $1 ORDER BY created_at DESC`,
      [MERCHANT_ID],
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Error fetching collections:", err);
    res.status(500).json({ error: "Server error" });
  }
});

router.post("/variantsall", authenticateToken, async (req, res) => {
  try {
    const { variantname, page = 1, limit = 25 } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    if (variantname) {
      queryParams.push(`%${variantname}%`);
      whereConditions.push(`option_name ILIKE $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const query = `
      SELECT id, option_name, values
      FROM variants
      ${whereClause}
      ORDER BY id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(query, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM variants
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      variants: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching variants:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
// GET /measurements-active
router.get("/measurements-active", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT measurement_id, measurement_value
      FROM measurements
      WHERE status = 'active'
      ORDER BY measurement_id
    `;
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching active measurements:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// fetch measurement by product

// GET measurement info by product ID and merchant_id
router.get(
  "/get-measurement-by-product",
  authenticateToken,
  async (req, res) => {
    const { product_id } = req.query;
    const { merchant_id } = req.user; // ✅ Securely from token
    if (!product_id) {
      return res.status(400).json({ message: "product_id is required" });
    }

    try {
      const result = await pool.query(
        `SELECT 
         m.measurement_id,
         m.measurement_type,
         m.measurement_value
       FROM products p
       LEFT JOIN measurements m ON p.measurement_id = m.measurement_id
       WHERE p.product_id = $1 AND p.merchant_id = $2`,
        [product_id, merchant_id],
      );

      if (result.rows.length === 0) {
        return res
          .status(404)
          .json({ message: "Measurement not found for this product" });
      }

      res.status(200).json(result.rows[0]);
    } catch (error) {
      console.error("Error fetching measurement by product ID:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  },
);

module.exports = router;
