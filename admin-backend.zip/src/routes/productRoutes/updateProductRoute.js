const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");
const { v4: uuidv4 } = require("uuid");

router.get("/", async (req, res) => {
  const client = await pool.connect();
  try {
    const { product_id } = req.query;
     console.log("payload coming is ", req.query);

    if (!product_id) {
      return res.status(400).json({ message: "Missing product_id in query params" });
    }

    const productQuery = `SELECT * FROM products WHERE product_id = $1`;
    const productResult = await client.query(productQuery, [product_id]);

    if (productResult.rows.length === 0) {
      return res.status(404).json({ message: "Product not found" });
    }

    const product = productResult.rows[0];

    // Fetch variants (only active)
    const variantQuery = `
      SELECT * FROM product_variants
      WHERE product_id = $1 AND status = 'active'
    `;
    const variantResult = await client.query(variantQuery, [product_id]);
    product.variants = variantResult.rows;

    // Fetch media
    const mediaQuery = `
      SELECT * FROM product_media
      WHERE product_id = $1 AND status = 'active'
      ORDER BY created_at ASC
    `;
    const mediaResult = await client.query(mediaQuery, [product_id]);
    const media = mediaResult.rows;

    // Map variant info
    const variantMap = {};
    for (const v of product.variants) {
      variantMap[v.variant_id] = {
        variant_type: v.variant_type,
        variant_value: v.variant_value,
      };
    }

    // Group product-level media
    const product_main = media.find((m) => m.variant_id === null && m.main === true);
    const product_sub = media.filter((m) => m.variant_id === null && m.main === false);

    // Group variant-level media
    const variant_media = {};
    for (const m of media) {
      if (m.variant_id !== null) {
        const vId = m.variant_id;
        if (!variant_media[vId]) {
          variant_media[vId] = {
            main: null,
            sub: [],
            variant_type: variantMap[vId]?.variant_type || null,
            variant_value: variantMap[vId]?.variant_value || null,
          };
        }

        if (m.main) {
          variant_media[vId].main = m;
        } else {
          variant_media[vId].sub.push(m);
        }
      }
    }

    // Inject media fields into each variant
    product.variants = product.variants.map((variant) => {
      const mainMedia = variant_media[variant.variant_id]?.main;
      return {
        ...variant,
        media_url: mainMedia?.media_url || null,
        media_id: mainMedia?.media_id || null,
        media_type: mainMedia?.media_type || null,
      };
    });

    return res.status(200).json({
      product,
      media: {
        product_main,
        product_sub,
        variant_media,
      },
    });
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ message: "Internal server error" });
  } finally {
    client.release();
  }
});


module.exports = router;