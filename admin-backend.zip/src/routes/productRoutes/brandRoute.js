const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

router.post("/add-brand", authenticateToken, async (req, res) => {
  try {
    const {
      name,
      brand_tagline,
      logo_url,
      logo_title_url,
      status = 'active'
    } = req.body;

    console.log("name",name);

     const checkQuery = `SELECT name FROM brand WHERE LOWER(name) = LOWER($1);`;
    const checkResult = await pool.query(checkQuery, [name]);

    if (checkResult.rows.length > 0) {
      return res.status(400).json({
        message: "Brand name already exists. Please choose a different name."
      });
    }

    const { user_id } = req.user; 

    const query = `
      INSERT INTO brand (
        name,
        brand_tagline,
        logo_url,
        logo_tile_url,
        status,
        created_at,
        updated_at
      )
      VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
      RETURNING *;
    `;

    const values = [
      name,
      brand_tagline,
      logo_url,
      logo_title_url, 
      status
    ];

    const result = await pool.query(query, values);
    const brand = result.rows[0];
    const module = "Brands";
    const logMessage = `User ${user_id} created brand ${brand.id} with name '${brand.name}' and status '${brand.status}'`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({
      message: "Brand created successfully",
      result: result.rows[0]
    });
  } catch (err) {
    console.error("Error inserting brand:", err);
    res.status(500).json({
      message: "Failed to create brand",
      error: err.message
    });
  }
});

router.post("/getallbrands", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      brand_id,
      brandstate,
      description,
      name,
      keyword,
      date,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    const queryParams = [];
    const whereConditions = [];

    // if (brand_id) {
    //   queryParams.push(brand_id);
    //   whereConditions.push(`brand_id = $${queryParams.length}`);
    // }

    // if (name) {
    //   queryParams.push(`%${name}%`);
    //   whereConditions.push(`name ILIKE $${queryParams.length}`);
    // }

    if (keyword && keyword.trim() !== "") {
  const trimmed = keyword.trim();

  if (/^\d+$/.test(trimmed)) {
    queryParams.push(parseInt(trimmed, 10));
    whereConditions.push(`brand_id = $${queryParams.length}`);
  } else {
    queryParams.push(`%${trimmed}%`);
    whereConditions.push(`name ILIKE $${queryParams.length}`);
  }
} else {
  if (brand_id) {
    queryParams.push(brand_id);
    whereConditions.push(`brand_id = $${queryParams.length}`);
  }
  if (name) {
    queryParams.push(`%${name}%`);
    whereConditions.push(`name ILIKE $${queryParams.length}`);
  }
}


    if (description) {
      queryParams.push(`%${description}%`);
      whereConditions.push(`description ILIKE $${queryParams.length}`);
    }

    if (brandstate) {
      queryParams.push(brandstate);
      whereConditions.push(`status = $${queryParams.length}`);
    }

    if (date) {
      queryParams.push(date);
      whereConditions.push(`created_at::date = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const categoriesQuery = `
      SELECT 
        brand_id, name, logo_url, logo_tile_url, brand_tagline,
        status, description, website_url, created_at
      FROM brand
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    queryParams.push(parsedLimit, offset);
    const { rows } = await pool.query(categoriesQuery, queryParams);

    const countQuery = `
      SELECT COUNT(*) AS total FROM brand ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams.slice(0, queryParams.length - 2));
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      categories: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching brands:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/brandname", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT name, brand_id FROM brand WHERE name ILIKE $1 LIMIT 10`


    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.post('/brandstatus',authenticateToken, async (req, res) => {
  const { brand_id, status } = req.body
  const user = req.user;
  const user_id = user.user_id;


  if (!brand_id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Invalid input' })
  }

  try {
    const result = await pool.query(
      'UPDATE brand SET status = $1 WHERE brand_id = $2',
      [status, brand_id]
    )

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'category not found' })
    }

    const module = 'Brand';
     const logMessage = `Updated brand ${brand_id} status to '${status}'`;
     await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({ message: 'Status updated successfully' })
  } catch (error) {
    console.error('Error updating status:', error)
    res.status(500).json({ message: 'Server error' })
  }
});


router.put("/edit-brand", authenticateToken, async (req, res) => {
  try {
    const { brand_id, name, brand_tagline,description, logo_url, logo_tile_url } = req.body
    const { user_id } = req.user; 

    if (!brand_id) {
      return res.status(400).json({ message: "brand_id is required" })
    }

    // Build dynamic update parts
    const fields = []
    const values = []
    let index = 1

    if (name !== undefined) {
      fields.push(`name = $${index++}`)
      values.push(name)
    }

    if (description !== undefined) {
      fields.push(`description = $${index++}`)
      values.push(description)
    }

    if (brand_tagline !== undefined) {
      fields.push(`brand_tagline = $${index++}`)
      values.push(brand_tagline)
    }

    if (logo_url !== undefined) {
      fields.push(`logo_url = $${index++}`)
      values.push(logo_url)
    }

    if (logo_tile_url !== undefined) {
      fields.push(`logo_tile_url = $${index++}`)
      values.push(logo_tile_url)
    }

    
    fields.push(`updated_at = NOW()`)

    if (fields.length === 1) {
      return res.status(400).json({ message: "No valid fields provided to update." })
    }

    const query = `
      UPDATE brand
      SET ${fields.join(', ')}
      WHERE brand_id = $${index}
      RETURNING *;
    `

    values.push(brand_id)

    const result = await pool.query(query, values)

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Brand not found" })
    }

    const module = "Brands";
    const logMessage = `User ${user_id} edited brand ${brand_id}`;
    await insertAdminLog(user_id, module, logMessage);

    res.status(200).json({
      message: "Brand updated successfully",
      result: result.rows[0],
    })
  } catch (err) {
    console.error("Error updating brand:", err)
    res.status(500).json({
      message: "Failed to update brand",
      error: err.message,
    })
  }
})




module.exports = router;
