const express = require('express');
const multer = require('multer');

const { S3Client, PutObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const { uploadToS3 } = require("../FileUploader/file_uploader");
const pool = require("../../config/db");
require('dotenv').config();

const router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage });

// S3 client config
const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

const PUBLIC_URL_PREFIX = process.env.CONVERT_S3_URL;

// Support single or multiple file uploads
router.post('/upload', upload.array('files', 100), async (req, res) => {
  const { product_id, target, variant_id } = req.body;
  const files = req.files;

  if (!files || files.length === 0 || !product_id) {
    return res
      .status(400)
      .json({ error: 'At least one file and product_id are required.' });
  }

  // Validate target if provided
  if (target && !['product', 'variant'].includes(String(target))) {
    return res
      .status(400)
      .json({ error: "Field 'target' must be 'product' or 'variant'." });
  }

  try {
    const uploadResults = [];

    for (const file of files) {
      const timestamp = Date.now();
      const originalName = file.originalname;
      const newFileName = `Product_Media/${timestamp}-${originalName}`;

      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: newFileName,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'public-read',
      };

      await s3.send(new PutObjectCommand(params));

      // detect type
      let mediaType = 'image';
      if (file.mimetype.startsWith('video')) {
        mediaType = 'video';
      } else if (originalName.toLowerCase().endsWith('.glb')) {
        mediaType = '3d';
      }

      const publicUrl = `${PUBLIC_URL_PREFIX}/${newFileName}`;

      uploadResults.push({
        product_id,
        variant_id: target === 'variant' ? variant_id || null : null,
        target: target || 'product',
        media_url: publicUrl,
        media_type: mediaType,
        uploaded_at: new Date(),
      });
    }

    return res.status(200).json({
      message: 'Upload successful',
      media: uploadResults,
    });
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ error: 'File upload failed' });
  }
});

// PATCH instead of DELETE for soft delete
router.patch('/:product_id/:media_id', async (req, res) => {
  const { product_id, media_id } = req.params;
  const { status } = req.body;

  if (!status || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ error: 'Invalid or missing status' });
  }

  try {
    const result = await pool.query(
      `UPDATE product_media SET status = $1 WHERE media_id = $2 AND product_id = $3 RETURNING *`,
      [status, media_id, product_id]
    )

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Media not found or not updated' })
    }

    res.status(200).json({ message: 'Media status updated', updated: result.rows[0] })
  } catch (err) {
    console.error('Error soft deleting media:', err)
    res.status(500).json({ error: 'Failed to update media status' })
  }
})


// GET product media by product_id
router.get('/:product_id', async (req, res) => {
  const { product_id } = req.params;

  if (!product_id) {
    return res.status(400).json({ error: 'Product ID is required' });
  }

  try {
    // 1. Fetch all active media entries
    const mediaResult = await pool.query(
      `SELECT * FROM product_media
       WHERE product_id = $1 AND status = 'active'
       ORDER BY created_at ASC`,
      [product_id]
    );

    const media = mediaResult.rows;

    // 2. Fetch variant names (type + value)
    const variantResult = await pool.query(
      `SELECT variant_id, variant_type, variant_value
       FROM product_variants
       WHERE product_id = $1 AND status = 'active'`,
      [product_id]
    );

    const variantMap = {};
    for (const row of variantResult.rows) {
      variantMap[row.variant_id] = {
        variant_type: row.variant_type,
        variant_value: row.variant_value
      };
    }

    // 3. Separate product-level media
    const product_main = media.find(m => m.variant_id === null && m.main === true);
    const product_sub = media.filter(m => m.variant_id === null && m.main === false);

    // 4. Structure variant media with extra info
    const variant_media = {};

    for (const m of media) {
      if (m.variant_id !== null) {
        const vId = m.variant_id;

        if (!variant_media[vId]) {
          variant_media[vId] = {
            main: null,
            sub: [],
            variant_type: variantMap[vId]?.variant_type || null,
            variant_value: variantMap[vId]?.variant_value || null
          };
        }

        if (m.main) {
          variant_media[vId].main = m;
        } else {
          variant_media[vId].sub.push(m);
        }
      }
    }

    return res.status(200).json({
      product_main,
      product_sub,
      variant_media
    });
  } catch (err) {
    console.error('Error fetching media and variants:', err);
    return res.status(500).json({ error: 'Failed to fetch media and variants' });
  }
});


// staging..

// ✅ STAGING UPLOAD ROUTE – Uploads to S3 only, no DB insert
router.post("/upload-staging", upload.array("files", 100), async (req, res) => {
  const files = req.files;

  if (!files || files.length === 0) {
    return res.status(400).json({ error: "At least one file is required." });
  }

  try {
    const now = new Date();

    const results = await uploadToS3({
      files,
      folderPath: "Product_Media", // ✅ same logical folder
      useDate: true,               // ✅ keeps date folder
      debug: false,
    });

    // 🔁 Keep SAME response structure as before
    const formatted = results.map((r) => ({
      media_url: r.url,
      media_type: r.type,
      uploaded_date: now.toISOString().split("T")[0],
      uploaded_at: now.toISOString(),
    }));

    return res.status(200).json({
      message: "Staging upload successful",
      media: formatted,
    });

  } catch (err) {
    console.error("Upload staging error:", err);
    return res.status(500).json({ error: "Staging upload failed" });
  }
});


router.post("/upload-stagingQU", upload.array("files", 100), async (req, res) => {
  const files = req.files;

  if (!files || files.length === 0) {
    return res.status(400).json({ error: "At least one file is required." });
  }

  try {
    const results = await uploadToS3({
      files,
      folderPath: "Quotations_Files",
      useDate: true,                  
      debug: false,
    });

    // 🔁 Transform response to match your existing API format
    const formatted = results.map((r) => ({
      media_url: r.url,
      media_type: r.type,
      uploaded_date: new Date().toISOString().split("T")[0],
      uploaded_at: new Date().toISOString(),
    }));

    return res.status(200).json({
      message: "Staging upload successful",
      media: formatted,
    });
  } catch (err) {
    console.error("Upload staging error:", err);
    return res.status(500).json({ error: "Staging upload failed" });
  }
});


module.exports = router;
