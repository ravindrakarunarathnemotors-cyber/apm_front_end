const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const bcrypt = require("bcrypt");


router.get("/fetch-prod/:product_id", authenticateToken, async (req, res) => {
  const productId = Number(req.params.product_id);
  if (!Number.isInteger(productId)) {
    return res.status(400).json({ error: "Invalid product_id" });
  }

  const sql = `
    WITH prod AS (
      SELECT
        p.product_id,
        p.title,
        p.description,
        p.status,
        p.price,
        p.compare_at_price,
        p.profit,
        p.margin,
        p.measurement_id,
        p.view_count,
        m.measurement_value,
        p.amount_per_unit
      FROM products p
      LEFT JOIN measurements m ON m.measurement_id = p.measurement_id
      WHERE p.product_id = $1
    ),

    -- ✅ PURCHASE COUNT: sum of quantity for all matching orders
    purchase_cte AS (
      SELECT COALESCE(SUM(oi.quantity), 0)::bigint AS purchase_count
      FROM order_items oi
      JOIN orders o ON o.order_id = oi.order_id
      WHERE oi.product_id = $1
        AND LOWER(o.order_status) = ANY(ARRAY['confirmed','completed','dispatched','processing'])
    ),

    -- ✅ RETURNS (orders + items)
    returns_cte AS (
      SELECT
        COUNT(DISTINCT o.order_id)::bigint AS returned_orders_count,
        COALESCE(SUM(oi.quantity), 0)::bigint AS returned_items_count
      FROM order_items oi
      JOIN orders o ON o.order_id = oi.order_id
      WHERE oi.product_id = $1
        AND (LOWER(o.order_status) = 'returned' OR o.returned_date IS NOT NULL)
    )

    SELECT
      prod.product_id,
      prod.title,
      prod.description,
      prod.status,
      prod.price,
      prod.compare_at_price,
      prod.profit,
      prod.margin,
      prod.measurement_id,
      prod.measurement_value,
      prod.view_count,
       prod.amount_per_unit,  

      COALESCE(pc.purchase_count, 0) AS purchase_count,
      COALESCE(rc.returned_orders_count, 0) AS returned_orders_count,
      COALESCE(rc.returned_items_count, 0) AS returned_items_count,

      COALESCE(
        JSON_AGG(
          JSON_BUILD_OBJECT(
            'variant_id', v.variant_id,
            'variant_type', v.variant_type,
            'variant_value', v.variant_value,
            'sku', v.sku,
            'cost_per_item', v.cost_per_item,
            'reorder_level', v.reorder_level,
            'status', v.status,
            'weight', v.weight,
            'new_quantity', li.new_quantity
          )
          ORDER BY v.variant_id
        ) FILTER (WHERE v.variant_id IS NOT NULL),
        '[]'::json
      ) AS variants,

      (
        SELECT row_to_json(x) FROM (
          SELECT pm.media_id, pm.media_url, pm.media_type
          FROM product_media pm
          WHERE pm.product_id = prod.product_id
            AND pm.variant_id IS NULL
            AND pm.main = TRUE
            AND pm.status = 'active'
          ORDER BY pm.media_id DESC
          LIMIT 1
        ) x
      ) AS product_media_main,

      COALESCE((
        SELECT json_agg(json_build_object('media_id',pm.media_id,'media_url',pm.media_url,'media_type',pm.media_type) ORDER BY pm.media_id)
        FROM product_media pm
        WHERE pm.product_id = prod.product_id
          AND pm.variant_id IS NULL
          AND (pm.main = FALSE OR pm.main IS NULL)
          AND pm.status = 'active'
      ), '[]'::json) AS product_media_sub,

      COALESCE((
        SELECT json_agg(
          json_build_object(
            'variant_id', v2.variant_id,
            'main', (
              SELECT row_to_json(mx) FROM (
                SELECT pm2.media_id, pm2.media_url, pm2.media_type
                FROM product_media pm2
                WHERE pm2.variant_id = v2.variant_id
                  AND pm2.main = TRUE
                  AND pm2.status = 'active'
                ORDER BY pm2.media_id DESC
                LIMIT 1
              ) mx
            ),
            'sub', COALESCE((
              SELECT json_agg(json_build_object('media_id',pm3.media_id,'media_url',pm3.media_url,'media_type',pm3.media_type) ORDER BY pm3.media_id)
              FROM product_media pm3
              WHERE pm3.variant_id = v2.variant_id
                AND (pm3.main = FALSE OR pm3.main IS NULL)
                AND pm3.status = 'active'
            ), '[]'::json)
          )
          ORDER BY v2.variant_id
        )
        FROM product_variants v2
        WHERE v2.product_id = prod.product_id
      ), '[]'::json) AS variant_media

    FROM prod
    CROSS JOIN purchase_cte pc
    CROSS JOIN returns_cte rc
    LEFT JOIN product_variants v
      ON v.product_id = prod.product_id
    LEFT JOIN LATERAL (
      SELECT i.new_quantity
      FROM inventory i
      WHERE i.variant_id = v.variant_id
      ORDER BY i.last_updated DESC, i.inventory_id DESC
      LIMIT 1
    ) li ON TRUE
    GROUP BY
      prod.product_id, prod.title, prod.description, prod.status,
      prod.price, prod.compare_at_price, prod.profit, prod.margin,
      prod.measurement_id, prod.measurement_value,
        prod.measurement_id, prod.measurement_value, prod.amount_per_unit,

      prod.view_count,
      pc.purchase_count,
      rc.returned_orders_count,
      rc.returned_items_count
  `;

  try {
    const { rows } = await pool.query(sql, [productId]);
    if (!rows.length) return res.status(404).json({ error: "Product not found" });

    const row = rows[0];

    return res.json({
      product_id: row.product_id,
      title: row.title,
      description: row.description,
      status: row.status,
      price: row.price,
      compare_at_price: row.compare_at_price,
      profit: row.profit,
      margin: row.margin,
      measurement_id: row.measurement_id,
      measurement_value: row.measurement_value,
      amount_per_unit: row.amount_per_unit !== null ? Number(row.amount_per_unit) : null, // <<< ADDED

      view_count: Number(row.view_count) || 0,
      purchase_count: Number(row.purchase_count) || 0, // ✅ sum of quantities
      returned_orders_count: Number(row.returned_orders_count) || 0,
      returned_items_count: Number(row.returned_items_count) || 0,
      variants: row.variants,
      product_media: {
        main: row.product_media_main || null,
        sub: row.product_media_sub || [],
      },
      variant_media: row.variant_media || [],
    });
  } catch (err) {
    console.error("Error fetching product details:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});




// fetch from reviews table

router.get(
  "/product-reviews-active/:product_id",
  authenticateToken,
  async (req, res) => {
    const productId = Number(req.params.product_id);
    if (!Number.isInteger(productId)) {
      return res.status(400).json({ error: "Invalid product_id" });
    }

    const sql = `
    SELECT
      review_id,
      customer_name,
      user_id,
      review,
      comment,
      status,
      product_id,
      created_at,
      updated_at
    FROM product_reviews
    WHERE product_id = $1
      AND status = 'active'
    ORDER BY created_at DESC
  `;

    try {
      const { rows } = await pool.query(sql, [productId]);
      return res.json({ product_id: productId, reviews: rows });
    } catch (err) {
      console.error("Error fetching product reviews:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  }
);

// product review status update
router.put("/set-review-status", authenticateToken, async (req, res) => {
  try {
    const { review_id, status } = req.body;

    if (!review_id || !Number.isInteger(Number(review_id))) {
      return res.status(400).json({ message: "Valid review_id is required" });
    }
    if (!["active", "inactive"].includes(String(status))) {
      return res
        .status(400)
        .json({ message: "status must be 'active' or 'inactive'" });
    }

    const sql = `
      UPDATE product_reviews
      SET status = $1,
          updated_at = NOW()
      WHERE review_id = $2
      RETURNING review_id, product_id, status, updated_at
    `;
    const params = [status, Number(review_id)];

    const { rows } = await pool.query(sql, params);
    if (rows.length === 0) {
      return res.status(404).json({ message: "Review not found" });
    }

    return res.json({
      message: "Status updated successfully",
      review: rows[0],
    });
  } catch (err) {
    console.error("Update review status error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
