const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();


router.post("/allemployees", authenticateToken, async (req, res) => {
    try {
        const {
            page = 1,
            limit = 25,
            keyword,
            status,
            date,
            todate,
        } = req.body;

        const parsedLimit = parseInt(limit, 10);
        const parsedPage = parseInt(page, 10);
        const offset = (parsedPage - 1) * parsedLimit;

        let queryParams = [];
        let whereConditions = [];

        // 🔍 Keyword Search
        if (keyword) {
            const trimmedKeyword = keyword.trim();

            // If numeric → search employee_id
            if (/^\d+$/.test(trimmedKeyword)) {
                queryParams.push(trimmedKeyword);
                whereConditions.push(`e.employee_id = $${queryParams.length}`);
            } else {
                queryParams.push(`%${trimmedKeyword}%`);
                whereConditions.push(`
      (
        CONCAT_WS(' ', e.first_name, e.middle_name, e.last_name) ILIKE $${queryParams.length}
        OR e.email ILIKE $${queryParams.length}
        OR e.nic ILIKE $${queryParams.length}
        OR e.mobile_number ILIKE $${queryParams.length}
      )
    `);
            }
        }


        if (date && todate) {
            queryParams.push(date, todate);
            whereConditions.push(
                `e.joined_date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
            );
        }


        if (status) {
            queryParams.push(status);
            whereConditions.push(`e.employment_status = $${queryParams.length}`);
        }
        const whereClause = whereConditions.length
            ? `WHERE ${whereConditions.join(" AND ")}`
            : "";

       
        const employeesQuery = `
      SELECT *
      FROM public.employees e
      ${whereClause}
      ORDER BY e.created_at DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

        const paginatedParams = [...queryParams, parsedLimit, offset];
        const { rows } = await pool.query(employeesQuery, paginatedParams);

        
        const countQuery = `
      SELECT COUNT(*) AS total
      FROM public.employees e
      ${whereClause}
    `;

        const countResult = await pool.query(countQuery, queryParams);
        const total = parseInt(countResult.rows[0].total, 10);

        res.json({
            employees: rows,
            total,
            totalPages: Math.ceil(total / parsedLimit),
            currentPage: parsedPage,
        });
    } catch (err) {
        console.error("Error fetching employees:", err);
        res.status(500).json({ error: "Internal server error" });
    }
});

router.get("/employeename", authenticateToken, async (req, res) => {
    try {
        const { search } = req.query;

        const query = `
      SELECT DISTINCT
        CONCAT(first_name, ' ', middle_name, ' ', last_name) AS full_name
      FROM employees
      WHERE 
        CONCAT(first_name, ' ', middle_name, ' ', last_name) ILIKE $1
      LIMIT 10
    `;

        const result = await pool.query(query, [`%${search}%`]);

        res.json(result.rows);
    } catch (error) {
        console.error("Error fetching employees:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});




module.exports = router;