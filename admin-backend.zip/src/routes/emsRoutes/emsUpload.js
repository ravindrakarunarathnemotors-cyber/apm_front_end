const express = require('express');
const multer = require('multer');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
require('dotenv').config();

const router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage });

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

const PUBLIC_URL_PREFIX = 'https://d8y1.c2.e2-9.dev/ozonefiles';


router.post('/upload-ems', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });

  const { file_type } = req.body;

  try {
   const sanitizedName = req.file.originalname
  .replace(/[^a-zA-Z0-9._-]/g, '_')  // replace anything not alphanumeric/dot/dash/underscore with _
  .replace(/_{2,}/g, '_')             // collapse multiple underscores
  .replace(/^_+|_+$/g, '')           // trim leading/trailing underscores

  const fileName = `EMS_FILES/${file_type || 'misc'}/${Date.now()}-${sanitizedName}`;

    const params = {
      Bucket: process.env.S3_BUCKET_NAME,
      Key: fileName,
      Body: req.file.buffer,
      ContentType: req.file.mimetype,
      ACL: 'public-read',
    };

    await s3.send(new PutObjectCommand(params));

    const publicUrl = `${PUBLIC_URL_PREFIX}/${fileName}`;

    return res.status(200).json({ url: publicUrl });

  } catch (err) {
    console.error('EMS Upload error:', err);
    return res.status(500).json({ error: 'File upload failed' });
  }
});

module.exports = router;