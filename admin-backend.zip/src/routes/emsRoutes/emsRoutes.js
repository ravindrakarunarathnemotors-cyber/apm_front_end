const express = require("express");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();

const { getEms,getDesignations,createDesignation,updateDesignation,getShifts,getShiftById,createShift,updateShift,//getAllEmployeeOnboarding,getEmployeeOnboardingById,/
  updateEmployeeShift,createAttendance, getAllAttendance,getAttendanceByEmployee,getAttendanceByDate,updateClockOut,updateClockIn,createEarningDeduction,
  getAllEarningsDeductions, getOnlyEarnings,getOnlyDeductions,getActiveEarningsDeductions,updateEarningDeduction,getEarningDeductionById, 
  createPayrollTemplate,getAllPayrollTemplates,getPayrollTemplateById,updatePayrollTemplate,createPayrollTemplateDetail,getAllPayrollTemplateDetails,getDetailsByPayrollTemplateId,
  getPayrollTemplateDetailById,updatePayrollTemplateDetail,createEmployee,getAllEmployees,getEmployeeById,updateEmployee,createDepartment,getAllDepartments,getDepartmentById,
  updateDepartment,createLeave,getAllLeaves,getLeavesByEmployee,updateLeaveStatus,getLeaveTypes,getOutlets,createEmployeeDocument,getDocumentsByEmployee,getDocumentById,createAppreciation,
  getAllAppreciations,getAppreciationById, createHoliday,getAllHolidays,getHolidayById,updateHoliday,createShiftRoster,getAllShiftRosters,getShiftRosterById,
  updateShiftRoster,getRosterByMonth,markAttendance,getAllEmployeeLogs,getEmployeeLogsById,getLeaveBalanceByEmployee,generatePaysheet,getAllPaysheets,
  getPaysheetById,addPaysheetDetail,getPaysheetDetails,updatePaysheetStatus,getPaysheetsByEmployee,deleteDetailsByTemplateId,createPaysheetInvoice,getAllPaysheetInvoices,
  getInvoiceByPaysheetDetail,updatePaysheetInvoice, updatePaysheet,getPaymentMethods,getBankAccounts ,createEmployeeRemark,getAllEmployeeRemarks,getRemarksByEmployee,
  updateEmployeeRemark,updateEmployeeGenerationType,updateEmployeeSalaryDate,createincrements,getAllincrements,getincrementsByEmployeeid,
  updateincrements,getPayrollTemplateNames,getHolidayNameSuggestions,getLeavesByQuery,checkDuplicateEmployee,checkUsernameAvailability,getRoles,verifyUserAccount,cancelLeave,} = require("../../controllers/ems/emsController");


const {
  getAllPayCycleGroups,
  getPayCycleGroupById,
  createPayCycleGroup,
  updatePayCycleGroup,
  previewPayCycleGroup,
} = require('../../controllers/ems/payCycleGroupController');

  // ADD these two imports below the existing require() lines
const { validate } = require('../../middleware/validate');
const {
  createEmployeeSchema, updateEmployeeSchema,
  createLeaveSchema,    updateLeaveStatusSchema,
  createDesignationSchema,
  createShiftSchema,
  createDepartmentSchema,
  createAttendanceSchema,
  createEarningDeductionSchema,
  generatePaysheetSchema,
  createShiftRosterSchema,
  createHolidaySchema,
  createEmployeeRemarkSchema,
  cancelLeaveSchema
} = require('../../validators/emsValidators');

router.get('/ems/verify-account', verifyUserAccount);
//addbysenesh11
// Payment methods from DB (add to emsRouter.js)
router.get("/payment-methods", authenticateToken, getPaymentMethods);
router.get("/bank-accounts", authenticateToken, getBankAccounts);

//designation 
router.get("/designations", authenticateToken,getDesignations);
router.post('/designation',    authenticateToken, validate(createDesignationSchema), createDesignation);
router.put('/designation/:id', authenticateToken, validate(createDesignationSchema), updateDesignation);

//shift
router.get("/shifts", authenticateToken, getShifts);
router.get("/shifts/:id", authenticateToken,getShiftById);
router.post('/shift',    authenticateToken, validate(createShiftSchema), createShift);
router.put('/shift/:id', authenticateToken, validate(createShiftSchema), updateShift);

//onboarding
//router.get("/employee-onboarding", authenticateToken, getAllEmployeeOnboarding);
//router.get("/employee-onboarding/:id", getEmployeeOnboardingById);
router.put("/employee-shift/:id", authenticateToken,updateEmployeeShift);

//attendance
router.post('/attendance', authenticateToken,validate(createAttendanceSchema), createAttendance);
router.get("/attendance",authenticateToken,getAllAttendance);
router.get("/attendance/:employee_id",authenticateToken,getAttendanceByEmployee);
router.get("/attendance/:date",authenticateToken,getAttendanceByDate);
router.put("/attendance/:attendance_id/clock-out",authenticateToken,updateClockOut);
router.put("/attendance/:attendance_id/clock-in",authenticateToken,updateClockIn);
router.post('/attendance',authenticateToken, markAttendance);

//earnings-deductions
router.post('/earnings-deductions', authenticateToken, validate(createEarningDeductionSchema), createEarningDeduction);
router.get("/earnings-deductions", authenticateToken,getAllEarningsDeductions);
router.get("/earnings-deductions/earnings", authenticateToken,getOnlyEarnings);
router.get("/earnings-deductions/deductions",authenticateToken, getOnlyDeductions);
router.get("/earnings-deductions/active", authenticateToken,getActiveEarningsDeductions);
router.put("/earnings-deductions/:id", authenticateToken,updateEarningDeduction);
router.get("/earnings-deductions/:id", authenticateToken,getEarningDeductionById);

//payroll-templates
router.post("/payroll-templates",authenticateToken,createPayrollTemplate);
//router.get("/payroll-templates", getAllPayrollTemplates);
router.get("/payroll-templates/:id", authenticateToken,getPayrollTemplateById);
router.put("/payroll-templates/:id", authenticateToken,updatePayrollTemplate);
router.post("/all-payroll-templates", authenticateToken,getAllPayrollTemplates);
router.get("/payrolltemplatename", authenticateToken, getPayrollTemplateNames);

// new route for template details
// router.get("/payroll-templates/:id/details", getPayrollTemplateDetails);


//Payroll-templates-details

router.post("/payroll-template-details",authenticateToken,createPayrollTemplateDetail);
router.get("/payroll-template-details", authenticateToken,getAllPayrollTemplateDetails);
router.get("/payroll-template/:templateId", authenticateToken,getDetailsByPayrollTemplateId);
router.get("/payroll-template-details/:id", authenticateToken,getPayrollTemplateDetailById);
router.put("/payroll-template-details/:id", authenticateToken,updatePayrollTemplateDetail);

//Departments

router.post('/departments',    authenticateToken, validate(createDepartmentSchema), createDepartment);
router.put('/departments/:id', authenticateToken, validate(createDepartmentSchema), updateDepartment);
router.get("/departments",authenticateToken,getAllDepartments);
router.get("/departments/:id",authenticateToken,getDepartmentById);


// employees
router.post('/employees',    authenticateToken, validate(createEmployeeSchema), createEmployee);
router.put('/employees/:id', authenticateToken, validate(updateEmployeeSchema), updateEmployee);
router.get("/employees", authenticateToken,getAllEmployees);
router.get("/employees/:id", authenticateToken,getEmployeeById);



//leaves
//leaves
router.post('/leaves',authenticateToken, validate(createLeaveSchema),createLeave);
router.put('/leaves/:leave_id', authenticateToken, validate(updateLeaveStatusSchema),  updateLeaveStatus);
router.post("/leavess", authenticateToken, getAllLeaves);
router.get("/leaves/query", authenticateToken, getLeavesByQuery);  // ← named route MUST be before /:param
router.get('/leaves', authenticateToken, getLeavesByQuery);
router.get("/leaves/:employee_id", authenticateToken, getLeavesByEmployee);
router.patch('/leaves/:leave_id/cancel', authenticateToken, cancelLeave);





//leave types
router.get("/leave-types",authenticateToken,getLeaveTypes);

//outlets
router.get("/outlets",authenticateToken, getOutlets);


//employee document
router.post("/documents",authenticateToken,createEmployeeDocument);
router.get("/documents/:employee_id",authenticateToken,getDocumentsByEmployee);
router.get("/documents/:id",authenticateToken,getDocumentById);


//appreciations
router.post("/appreciations",authenticateToken,createAppreciation);
router.get("/appreciations",authenticateToken,getAllAppreciations);
router.get("/appreciations/:id",authenticateToken,getAppreciationById);


//holidays
router.post('/holidays',    authenticateToken, validate(createHolidaySchema), createHoliday);
router.put('/holidays/:id', authenticateToken, validate(createHolidaySchema), updateHoliday);
router.get('/holidays', authenticateToken,getAllHolidays);
router.get('/holidays/suggestions', getHolidayNameSuggestions)
router.get('/holidays/:id', authenticateToken,getHolidayById);




//shift roster
router.post('/shift-roster', authenticateToken, validate(createShiftRosterSchema), createShiftRoster);
router.get('/shift-roster',authenticateToken,getAllShiftRosters);
router.get('/shift-roster/:id',authenticateToken,getShiftRosterById);
router.put('/shift-roster/:id',authenticateToken,updateShiftRoster);
router.get('/shift-roster', authenticateToken,getRosterByMonth);

router.get('/employee-logs',authenticateToken,getAllEmployeeLogs);
//add by senesh
router.get('/employee-logs/:employeeId', authenticateToken,getEmployeeLogsById);
router.get("/employees/:employee_id/leave-balance",authenticateToken, getLeaveBalanceByEmployee); 


//Paysheets
router.post('/paysheet', authenticateToken, validate(generatePaysheetSchema), generatePaysheet);
router.get("/paysheet",authenticateToken, getAllPaysheets);
router.get("/paysheet/:paysheet_id",authenticateToken, getPaysheetById);
//router.put('/paysheet/:paysheet_id', authenticateToken, updatePaysheetStatus);
router.put("/paysheet/:paysheet_id", authenticateToken, updatePaysheet);
// In your router file, add this route:
router.put('/paysheet/:paysheet_id/status', authenticateToken, updatePaysheetStatus);



//Paysheet details
router.post("/paysheet-details", authenticateToken,addPaysheetDetail);
router.get("/paysheet-details/:paysheet_id",authenticateToken, getPaysheetDetails);
// ADD this line with the other paysheet routes
router.get("/paysheets/:employee_id", authenticateToken, getPaysheetsByEmployee);
// In router file — add:
router.delete('/payroll-template-details/:templateId', authenticateToken, deleteDetailsByTemplateId)

//paysheet invoice
router.post("/paysheet-invoices",authenticateToken,createPaysheetInvoice);
router.get("/paysheet-invoices", authenticateToken,getAllPaysheetInvoices);
router.get("/paysheet-invoices/:paysheet_detail_id",authenticateToken,getInvoiceByPaysheetDetail);
router.put("/paysheet-invoices/:paysheet_invoice_id",authenticateToken,updatePaysheetInvoice);


//employee remarks
router.post('/employee-remark', authenticateToken, validate(createEmployeeRemarkSchema), createEmployeeRemark);
router.get("/employee-remark",authenticateToken,getAllEmployeeRemarks);
router.get("/employee-remark/:employee_id", authenticateToken,getRemarksByEmployee);
router.put("/employee-remark/:id",authenticateToken,updateEmployeeRemark);


//paysheet new by senesh
router.put("/employees/:id/generation-type", authenticateToken, updateEmployeeGenerationType);
// emsRouter.js — add after the generation-type route:
router.put("/employees/:id/salary-date", authenticateToken, updateEmployeeSalaryDate);

const { runPayrollCron } = require('../../cron/cronjob');  // ✅ correct path

router.post('/dev/run-payroll-cron',  async (req, res) => {
  try {
    console.log('🔧 Manual cron trigger by user:', req.user?.user_id);
    const results = await runPayrollCron();
    res.status(200).json({
      message: 'Cron executed',
      summary: {
        processed: results.processed.length,
        skipped:   results.skipped.length,
        errors:    results.errors.length,
      },
      details: results,
    });
  } catch (error) {
    console.error('Cron trigger error:', error);
    res.status(500).json({ message: 'Cron failed', error: error.message });
  }
})

router.post('/increments', authenticateToken,createincrements);
router.get('/increments', authenticateToken,getAllincrements);
router.get('/increments/:employee_id',authenticateToken,getincrementsByEmployeeid);
router.put('/increments/:id', authenticateToken,updateincrements);
router.post('/check-duplicate', authenticateToken, checkDuplicateEmployee);

router.get('/check-username', authenticateToken, checkUsernameAvailability);
router.get('/roles', authenticateToken, getRoles);

router.get('/pay-cycle-groups',       getAllPayCycleGroups);
router.get('/pay-cycle-groups/preview',   previewPayCycleGroup);
router.get('/pay-cycle-groups/:id',      getPayCycleGroupById);
router.post('/pay-cycle-groups',         createPayCycleGroup);
router.put('/pay-cycle-groups/:id',    updatePayCycleGroup);

module.exports = router;
