const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const updateTransactionRecord = require("../transactionsUpdater/transactionsUpdater");

// GET: Fetch Active Account Categories
router.get(
  "/active-account-categories",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const query = `
        SELECT 
          category_id,
          name,
          note,
          status,
          is_default,
          created_at,
          updated_at,
          created_by
        FROM account_categories
        WHERE status = 'active'
        ORDER BY name ASC
      `;

      const { rows } = await client.query(query);

      return res.status(200).json({
        success: true,
        count: rows.length,
        data: rows,
      });
    } catch (error) {
      console.error("Error fetching active account categories:", error);

      return res.status(500).json({
        success: false,
        message: "Failed to fetch active account categories",
      });
    } finally {
      client.release();
    }
  },
);

// ADD ACCOUNT CATEGORY
// ==============================
router.post("/add-account-category", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const user_id = req.user.user_id; // From JWT
    const { name, note, status } = req.body;

    // ==============================
    // Validation
    // ==============================
    if (!name || name.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "Category name is required",
      });
    }

    const validStatus = ["active", "inactive"];
    const categoryStatus = status ? status.toLowerCase() : "active";

    if (!validStatus.includes(categoryStatus)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status value. Allowed values: active, inactive",
      });
    }

    await client.query("BEGIN");

    // ==============================
    // Insert Query
    // ==============================
    const insertQuery = `
      INSERT INTO account_categories
        (name, note, status, created_by)
      VALUES
        ($1, $2, $3, $4)
      RETURNING *;
    `;

    const result = await client.query(insertQuery, [
      name.trim(),
      note || null,
      categoryStatus,
      user_id,
    ]);

    const newCategory = result.rows[0];

    // ==============================
    // Insert Admin Log
    // ==============================
    await insertAdminLog(
      user_id,
      "Accounts Categories",
      `Created account category: ${newCategory.name} (ID: ${newCategory.category_id})`,
    );

    await client.query("COMMIT");

    return res.status(201).json({
      success: true,
      message: "Account category created successfully",
      data: newCategory,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Add Account Category Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

// fetch account details
router.get("/fetch-account-categories", authenticateToken, async (req, res) => {
  try {
    const user_id = req.user.user_id;

    let { name, status, from_date, to_date, page = 1, limit = 25 } = req.query;

    page = parseInt(page) || 1;
    limit = parseInt(limit) || 25;

    if (limit > 100) limit = 100; // safety cap

    const offset = (page - 1) * limit;

    let conditions = [];
    let values = [];
    let index = 1;

    // ==========================
    // Filters
    // ==========================

    // Name filter (ILIKE search)
    if (name) {
      conditions.push(`ac.name ILIKE $${index}`);
      values.push(`%${name}%`);
      index++;
    }

    // Status filter
    if (status && ["active", "inactive"].includes(status)) {
      conditions.push(`ac.status = $${index}`);
      values.push(status);
      index++;
    }

    // Date range filter (created_at)
    if (from_date) {
      conditions.push(`DATE(ac.created_at) >= $${index}`);
      values.push(from_date);
      index++;
    }

    if (to_date) {
      conditions.push(`DATE(ac.created_at) <= $${index}`);
      values.push(to_date);
      index++;
    }

    const whereClause =
      conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    // ==========================
    // Total Count Query
    // ==========================

    const countQuery = `
  SELECT COUNT(*)
  FROM account_categories ac
  LEFT JOIN users u ON u.user_id = ac.created_by
  ${whereClause}
`;
    const countResult = await pool.query(countQuery, values);
    const totalRecords = parseInt(countResult.rows[0].count);

    // ==========================
    // Main Data Query
    // ==========================

    const dataQuery = `
  SELECT 
    ac.*,
    u.first_name
  FROM account_categories ac
  LEFT JOIN users u ON u.user_id = ac.created_by
  ${whereClause}
  ORDER BY ac.category_id DESC
  LIMIT $${index}
  OFFSET $${index + 1}
`;

    const dataValues = [...values, limit, offset];

    const result = await pool.query(dataQuery, dataValues);

    // ==========================
    // Optional Admin Log
    // ==========================
    /*
      await insertAdminLog(
        user_id,
        "Accounts Categories",
        "Fetched account categories list"
      );
      */

    return res.status(200).json({
      success: true,
      pagination: {
        totalRecords,
        totalPages: Math.ceil(totalRecords / limit),
        currentPage: page,
        limit,
      },
      data: result.rows,
    });
  } catch (error) {
    console.error("Fetch Account Categories Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

router.patch(
  "/update-account-category-status",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const user_id = req.user.user_id;
      const { category_id, status } = req.body;

      if (!category_id) {
        return res.status(400).json({
          success: false,
          message: "Category ID is required",
        });
      }

      if (!["active", "inactive"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid status value",
        });
      }

      await client.query("BEGIN");

      const updateQuery = `
        UPDATE account_categories
        SET status = $1,
            updated_at = CURRENT_TIMESTAMP
        WHERE category_id = $2
        RETURNING *;
      `;

      const result = await client.query(updateQuery, [status, category_id]);

      if (result.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({
          success: false,
          message: "Category not found",
        });
      }

      const updatedCategory = result.rows[0];

      // ✅ Admin Log
      await insertAdminLog(
        user_id,
        "Accounts Categories",
        `Updated status of category ID ${category_id} to ${status}`,
      );

      await client.query("COMMIT");

      return res.status(200).json({
        success: true,
        message: "Status updated successfully",
        data: updatedCategory,
      });
    } catch (error) {
      await client.query("ROLLBACK");
      console.error("Update Status Error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    } finally {
      client.release();
    }
  },
);

// ==============================
// UPDATE ACCOUNT CATEGORY
// ==============================
router.put("/update-account-category", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const user_id = req.user.user_id;
    const { category_id, name, note, status } = req.body;

    // ==============================
    // Validation
    // ==============================
    if (!category_id) {
      return res.status(400).json({
        success: false,
        message: "Category ID is required",
      });
    }

    if (!name || name.trim() === "") {
      return res.status(400).json({
        success: false,
        message: "Category name is required",
      });
    }

    const validStatus = ["active", "inactive"];
    const categoryStatus = status ? status.toLowerCase() : "active";

    if (!validStatus.includes(categoryStatus)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status value. Allowed values: active, inactive",
      });
    }

    await client.query("BEGIN");

    // ==============================
    // Check if Exists
    // ==============================
    const checkQuery = `
        SELECT * FROM account_categories
        WHERE category_id = $1
      `;
    const checkResult = await client.query(checkQuery, [category_id]);

    if (checkResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        success: false,
        message: "Account category not found",
      });
    }

    // ==============================
    // Update Query
    // ==============================
    const updateQuery = `
        UPDATE account_categories
        SET
          name = $1,
          note = $2,
          status = $3,
          updated_at = CURRENT_TIMESTAMP
        WHERE category_id = $4
        RETURNING *;
      `;

    const result = await client.query(updateQuery, [
      name.trim(),
      note || null,
      categoryStatus,
      category_id,
    ]);

    const updatedCategory = result.rows[0];

    // ==============================
    // Admin Log
    // ==============================
    await insertAdminLog(
      user_id,
      "Accounts Categories",
      `Updated account category: ${updatedCategory.name} (ID: ${updatedCategory.category_id})`,
    );

    await client.query("COMMIT");

    return res.status(200).json({
      success: true,
      message: "Account category updated successfully",
      data: updatedCategory,
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update Account Category Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  } finally {
    client.release();
  }
});

router.post("/fetch-account-statement", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { account_id, page = 1, limit = 25, from_date, to_date } = req.body;

    if (!account_id) {
      return res.status(400).json({
        success: false,
        message: "Account ID is required",
      });
    }

    const offset = (page - 1) * limit;

    // ================= FETCH ACCOUNT DETAILS =================
    const accountResult = await client.query(
      `
      SELECT 
        a.*,
        CONCAT(u.first_name, ' #', u.user_id) AS account_created_by
      FROM accounts a
      LEFT JOIN users u ON u.user_id = a.by
      WHERE a.id = $1
      `,
      [account_id],
    );

    const account =
      accountResult.rows.length > 0 ? accountResult.rows[0] : null;

    // ================= BUILD DATE FILTER =================
    // Date filter is built separately so the CTE can compute
    // running_balance over ALL rows first, then we filter by date.
    // This ensures running_balance is always chronologically correct
    // regardless of the date range requested.
    let dateFilter = "";
    let dateParams = [];
    let dateParamIndex = 2;

    if (from_date) {
      dateFilter += ` AND created_at >= $${dateParamIndex}`;
      dateParams.push(from_date);
      dateParamIndex++;
    }

    if (to_date) {
      dateFilter += ` AND created_at <= $${dateParamIndex}`;
      dateParams.push(to_date);
      dateParamIndex++;
    }

    const limitIndex = dateParamIndex;
    const offsetIndex = dateParamIndex + 1;

    // ================= FETCH STATEMENT RECORDS =================
    const transactionsQuery = `
      WITH full_statement AS (
        SELECT
          t.acc_statement_id,
          t.account_id,
          t.transaction_type,
          t.amount,
          t.reference,
          t.prev_balance,
          t.balance,
          t.status,
          t.created_at,
          CONCAT(u.first_name, ' #', u.user_id) AS by,
          CASE WHEN t.transaction_type = 'debit'  THEN t.amount ELSE 0 END AS debit,
          CASE WHEN t.transaction_type = 'credit' THEN t.amount ELSE 0 END AS credit,
          SUM(
            CASE
              WHEN t.transaction_type = 'credit' THEN  t.amount
              WHEN t.transaction_type = 'debit'  THEN -t.amount
              ELSE 0
            END
          ) OVER (
            PARTITION BY t.account_id
            ORDER BY t.created_at ASC, t.acc_statement_id ASC
          ) AS running_balance
        FROM account_statement t
        LEFT JOIN users u ON u.user_id = t."by"
        WHERE t.account_id = $1
      )
      SELECT * FROM full_statement
      WHERE 1=1 ${dateFilter}
      ORDER BY created_at DESC, acc_statement_id DESC
      LIMIT $${limitIndex}
      OFFSET $${offsetIndex}
    `;

    const transactionsResult = await client.query(transactionsQuery, [
      account_id,
      ...dateParams,
      limit,
      offset,
    ]);

    // ================= TOTAL COUNT =================
    const countQuery = `
      SELECT COUNT(*)
      FROM account_statement t
      WHERE t.account_id = $1 ${dateFilter}
    `;

    const countResult = await client.query(countQuery, [
      account_id,
      ...dateParams,
    ]);
    const totalRecords = Number(countResult.rows[0].count);

    // ================= FETCH CURRENCY =================
    const currencyResult = await client.query(`
      SELECT currency 
      FROM system_settings 
      LIMIT 1
    `);

    const currency =
      currencyResult.rows.length > 0 ? currencyResult.rows[0].currency : "Rs";

    return res.status(200).json({
      success: true,
      currency,
      account,
      transactions: transactionsResult.rows,
      totalRecords,
      currentPage: Number(page),
      totalPages: Math.ceil(totalRecords / limit),
    });
  } catch (error) {
    console.error("Fetch Account Statement Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  } finally {
    client.release();
  }
});

/* ================= UPDATE TRANSACTION PAYMENT STATUS ================= */

router.patch("/update-payment-status", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const user_id = req.user?.user_id || req.user?.id;
    const { transaction_id, payment_status, transaction_type } = req.body;

    console.log("Incoming:", {
      transaction_id,
      payment_status,
      transaction_type,
      user_id,
    });

    if (!transaction_id || !payment_status || !transaction_type) {
      return res.status(400).json({
        success: false,
        message: "Transaction ID, status and type required",
      });
    }

    await client.query("BEGIN");

    /* =========================
       1️⃣ GET ORIGINAL TX
    ========================= */

    const txRes = await client.query(
      `SELECT *
       FROM transactions
       WHERE transaction_id = $1`,
      [transaction_id],
    );

    if (txRes.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        success: false,
        message: "Transaction not found",
      });
    }

    const tx = txRes.rows[0];
    const oldStatus = tx.payment_status;

    /* =========================
       2️⃣ PREVENT SAME STATUS
    ========================= */

    if (oldStatus === payment_status) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        success: false,
        message: "Payment status already set",
      });
    }

    /* =========================
       3️⃣ APPLY PAYMENT
    ========================= */

    if (payment_status === "approved" && oldStatus !== "approved") {
      await updateTransactionRecord({
        client,
        amount: tx.amount,
        account_id: tx.account_id,
        category_id: tx.category_id,
        transaction_type: transaction_type,
        note: `Payment approved TX:${transaction_id}`,
        by_user_id: user_id,
        payer_payee_id: tx.payer_payee_id,
        log_module: "PAYMENT_APPROVED",
        log_message: `Payment approved TX:${transaction_id}`,
      });
    }

    /* =========================
       4️⃣ REJECT PAYMENT
    ========================= */

    if (payment_status === "rejected" && oldStatus !== "rejected") {
      const reverseType = transaction_type === "income" ? "expense" : "income";

      await updateTransactionRecord({
        client,
        amount: tx.amount,
        account_id: tx.account_id,
        category_id: tx.category_id,
        transaction_type: reverseType,
        note: `Payment rejected TX:${transaction_id}`,
        by_user_id: user_id,
        payer_payee_id: tx.payer_payee_id,
        log_module: "PAYMENT_REJECTED",
        log_message: `Payment rejected TX:${transaction_id}`,
      });
    }

    /* =========================
       5️⃣ UPDATE STATUS
    ========================= */

    await client.query(
      `UPDATE transactions
       SET payment_status = $1,
           updated_at = NOW()
       WHERE transaction_id = $2`,
      [payment_status, transaction_id],
    );

    await client.query("COMMIT");

    return res.status(200).json({
      success: true,
      message: "Payment status updated successfully",
    });
  } catch (error) {
    await client.query("ROLLBACK");

    console.error("Route Error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error",
    });
  } finally {
    client.release();
  }
});

// account balance adjustment

router.post("/adjust-account-balance", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { account_id, new_balance, reason } = req.body;
    const by_user_id = req.user.user_id;

    if (!account_id || new_balance === undefined || !reason) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields",
      });
    }

    await client.query("BEGIN");

    /* ================= GET ACCOUNT ================= */

    const accountResult = await client.query(
      `SELECT id, name, balance, status
       FROM accounts
       WHERE id = $1`,
      [account_id],
    );

    if (accountResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        success: false,
        message: "Account not found",
      });
    }

    const account = accountResult.rows[0];

    if (account.status === "inactive") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        success: false,
        message: "Cannot adjust an inactive account",
      });
    }

    const prev_balance = Number(account.balance);
    const newBalance = Number(new_balance);

    /* ================= TRANSACTION TYPE ================= */

    let transaction_type = "credit";
    if (newBalance < 0) transaction_type = "debit";

    /* ================= UPDATE ACCOUNT ================= */

    await client.query(
      `UPDATE accounts
       SET balance = $1,
           updated_at = NOW()
       WHERE id = $2`,
      [newBalance, account_id],
    );

    /* ================= INSERT ACCOUNT STATEMENT ================= */

    await client.query(
      `INSERT INTO account_statement
      (account_id, transaction_type, amount, reference, "by", prev_balance, balance, status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        account_id,
        transaction_type,
        newBalance,
        reason,
        by_user_id,
        prev_balance,
        newBalance,
        "Adjusted",
      ],
    );

    /* ================= ADMIN LOG ================= */

    await insertAdminLog(
      by_user_id,
      "Accounts",
      `Adjusted account "${account.name}" balance from ${prev_balance.toFixed(2)} to ${newBalance.toFixed(2)}. Reason: ${reason}`,
    );

    await client.query("COMMIT");

    res.status(200).json({
      success: true,
      message: "Account balance adjusted successfully",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Adjust balance error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to adjust account balance",
    });
  } finally {
    client.release();
  }
});
module.exports = router;
