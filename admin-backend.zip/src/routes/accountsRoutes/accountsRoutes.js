const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

router.get("/accountsname", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name FROM accounts WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/allaccounts", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      todate,
      date,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // Keyword filter
    if (keyword) {
      const trimmedKeyword = keyword.trim();
      queryParams.push(`%${trimmedKeyword}%`);

      whereConditions.push(`
        (
          r.name ILIKE $${queryParams.length}
          OR r.id::text ILIKE $${queryParams.length}
        )
      `);
    }

    // Date filter
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `r.date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
      );
    }

    // Status filter
    if (status) {
      queryParams.push(status);
      whereConditions.push(`r.status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // Main query with outlet name
    const rawMaterialQuery = `
      SELECT
        r.id,
        r.date,
        r.name,
        r.type,
        r.balance,
        r.status,
        r.is_default,
        r.bank_account,
        r.outlet_id,
        o.name AS outlet_name,
        r.description
      FROM accounts r
      LEFT JOIN outlets o ON o.outlet_id = r.outlet_id
      ${whereClause}
      ORDER BY r.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(rawMaterialQuery, paginatedParams);

    // Count query
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM accounts r
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // Currency
    const currencyResult = await pool.query(
      "SELECT currency FROM system_settings LIMIT 1"
    );

    const currency = currencyResult.rows[0]?.currency || null;

    res.json({
      accounts: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
      currency
    });

  } catch (err) {
    console.error("Error fetching accounts:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
router.post("/create-account", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      name,
      type,
      p_method_id,
      description,
      status,
      balance,
      outlet_id,
      bank_account
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    /* ================= VALIDATION ================= */

    if (!name) {
      return res.status(400).json({
        success: false,
        message: "Account name is required",
      });
    }

     if (!outlet_id) {
      return res.status(400).json({
        success: false,
        message: "Outlet is required",
      });
    }

    await client.query("BEGIN");

    /* ================= INSERT ACCOUNT ================= */

    const insertQuery = `
      INSERT INTO accounts (
        name,
        type,
        p_method_id,
        description,
        status,
        balance,
        by,
        outlet_id,
        bank_account	
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      RETURNING id
    `;

    const values = [
      name,
      type || null,
      p_method_id || null,
      description || null,
      status || "active",
      Number(balance) || 0,
      user_id,
      outlet_id,
      bank_account,
    ];

    const result = await client.query(insertQuery, values);
    const newAccountId = result.rows[0].id;

    await insertAdminLog(
      user_id,
      "ACCOUNT",
      `Created new account (#${newAccountId}) - ${name}`
    );

    await client.query("COMMIT");

    res.status(201).json({
      success: true,
      message: "Account created successfully",
      account_id: newAccountId,
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create Account Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create account",
    });
  } finally {
    client.release();
  }
});

router.post("/update-account-status", authenticateToken, async (req, res) => {
  const { id, status } = req.body;
  console.log("id",id)
  console.log("status",status)

  const user = req.user;
  const user_id = user.user_id;

  if (!id || !["active", "inactive"].includes(status)) {
    return res.status(400).json({ message: "Invalid input" });
  }

  try {
    const result = await pool.query(
      "UPDATE accounts SET status = $1 WHERE id = $2",
      [status, id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Account not found" });
    }

    await insertAdminLog(
      user_id,
      "ACCOUNT",
      `Updated account ${id} status to '${status}'`
    );

    res.json({ message: "Account status updated successfully" });

  } catch (error) {
    console.error("Update account status error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.put("/update-account/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const {
      name,
      type,
      p_method_id,
      description,
      status,
      bank_account,
      outlet_id
    } = req.body;

    const query = `
      UPDATE accounts SET
        name = $1,
        type = $2,
        p_method_id = $3,
        description = $4,
        status = $5,
        outlet_id = $7,
        bank_account = $8
      WHERE id = $6
      RETURNING *
    `;

    const values = [
      name,
      type,
      p_method_id,
      description,
      status,
      id,
      outlet_id,
      bank_account
    ];

    const result = await pool.query(query, values);

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Account not found" });
    }

    res.json({
      message: "Account updated successfully",
      account: result.rows[0],
    });

  } catch (error) {
    console.error("Update Account Error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/payer-payee-names", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;


    const query = `SELECT DISTINCT name FROM accounts_payer_payee WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching payer/payee names:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/all-payer-payee", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 25, keyword, status, type, todate, date } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    if (keyword) {
      queryParams.push(`%${keyword.trim()}%`);
      whereConditions.push(`
        (
          p.name ILIKE $${queryParams.length}
          OR p.id::text ILIKE $${queryParams.length}
        )
      `);
    }

    if (type) {
      queryParams.push(type);
      whereConditions.push(`p.type = $${queryParams.length}`);
    }

      if (status) {
      queryParams.push(status);
      whereConditions.push(`p.status = $${queryParams.length}`);
    }

     if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `p.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length
        }`
      );
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const dataQuery = `
      SELECT 
        p.id,
        p.name,
        p.type,
        p.status,
        p.add_by,
        u.first_name AS add_byname, 
        p.created_at
      FROM accounts_payer_payee p
      LEFT JOIN users u ON p.add_by = u.user_id
      ${whereClause}
      ORDER BY p.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const dataParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(dataQuery, dataParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM accounts_payer_payee p
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      data: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (error) {
    console.error("Error fetching payer/payee:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/create-payer-payee", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { name, type, status } = req.body;
    const user_id = req.user.user_id;

    if (!name || !type) {
      return res.status(400).json({
        success: false,
        message: "Name and type are required",
      });
    }

    await client.query("BEGIN");

    const insertQuery = `
      INSERT INTO accounts_payer_payee (
        name,
        type,
        add_by,
        status
      )
      VALUES ($1, $2, $3, $4)
      RETURNING id
    `;

    const values = [
      name.trim(),
      type,
      user_id,
      status || "active",
    ];

    const result = await client.query(insertQuery, values);
    const newId = result.rows[0].id;

    /* ✅ INSERT ADMIN LOG */
    await insertAdminLog(
      user_id,
      "PAYER_PAYEE",
      `Created new payer/payee (#${newId}) - ${name}`
    );

    await client.query("COMMIT");

    res.status(201).json({
      success: true,
      message: "Created successfully",
      id: newId,
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create payer/payee error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create",
    });
  } finally {
    client.release();
  }
});

router.post("/toggle-payer-payee-status", authenticateToken, async (req, res) => {
  const { id, status } = req.body;
  const user_id = req.user.user_id;

  try {
    const result = await pool.query(
      "UPDATE accounts_payer_payee SET status = $1 WHERE id = $2",
      [status, id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ message: "Record not found" });
    }

    await insertAdminLog(
      user_id,
      "PAYER_PAYEE",
      `Changed status of payer/payee (#${id}) to '${status}'`
    );

    res.json({ message: "Status updated successfully" });

  } catch (error) {
    console.error("Update status error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

router.put("/update-payer-payee/:id", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const { id } = req.params;
    const { name, type, status } = req.body;
    const user_id = req.user.user_id;

    await client.query("BEGIN");

    // ✅ Get existing record (for logging old values)
    const existingResult = await client.query(
      "SELECT * FROM accounts_payer_payee WHERE id = $1",
      [id]
    );

    if (existingResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Record not found" });
    }

    const oldData = existingResult.rows[0];

    // ✅ Update record
    const updateQuery = `
      UPDATE accounts_payer_payee SET
        name = $1,
        type = $2,
        status = $3
      WHERE id = $4
      RETURNING *
    `;

    const values = [name, type, status, id];

    const updateResult = await client.query(updateQuery, values);
    const updatedData = updateResult.rows[0];

    // ✅ Insert Admin Log
    await insertAdminLog(
      client,
      user_id,
      "PAYER_PAYEE",
      `Updated payer/payee (#${id}) 
       Name: '${oldData.name}' → '${updatedData.name}', 
       Type: '${oldData.type}' → '${updatedData.type}', 
       Status: '${oldData.status}' → '${updatedData.status}'`
    );

    await client.query("COMMIT");

    res.json({
      message: "Updated successfully",
      data: updatedData,
    });

  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Update error:", error);
    res.status(500).json({ message: "Internal Server Error" });
  } finally {
    client.release();
  }
});

router.get("/active-bank-accounts", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        id,
        name
      FROM public.accounts
      WHERE status = 'active'
        AND bank_account = true
      ORDER BY id DESC
    `;

    const result = await pool.query(query);

    res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows,
    });

  } catch (error) {
    console.error("Error fetching active bank accounts:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


module.exports = router;