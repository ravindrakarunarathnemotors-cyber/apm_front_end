const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const multer = require("multer");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
require("dotenv").config();
const { uploadToS3 } = require("../FileUploader/file_uploader");

/* ================= MULTER ================= */

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 20 },
  fileFilter: (req, file, cb) => {
    const allowed = [
      "image/png",
      "image/jpeg",
      "image/jpg",
      "application/pdf",
      "application/zip",
      "application/x-zip-compressed",
    ];

    if (!allowed.includes(file.mimetype)) {
      return cb(
        new Error("Only JPG, JPEG, PNG, PDF and ZIP files are allowed"),
        false,
      );
    }

    cb(null, true);
  },
});

/* ================= S3 ================= */

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

const PUBLIC_URL_PREFIX = process.env.CONVERT_S3_URL;

/* ================= ROUTE ================= */
/**
 * POST /accounts/upload-transaction-files
 * body:
 *  - transaction_id
 * files:
 *  - files[]
 */

router.post(
  "/upload-transaction-files",
  upload.array("files", 20),
  async (req, res) => {
    const { transaction_id } = req.body;
    const files = req.files;

    if (!transaction_id) {
      return res.status(400).json({
        success: false,
        message: "transaction_id is required",
      });
    }

    if (!files || files.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one file is required",
      });
    }

    try {
      const results = await uploadToS3({
        files,
        folderPath: `Accounts_Management/Transaction_Files/${transaction_id}`, // ✅ dynamic per transaction
        useDate: false, // ❗ original didn't use date
        debug: false,
      });

      // 🔁 Match your original response format
      const uploadedFiles = results.map((r) => ({
        url: r.url,
        type: r.type,
        name: r.original_name,
      }));

      return res.status(200).json({
        success: true,
        message: "Transaction files uploaded successfully",
        data: uploadedFiles,
      });
    } catch (error) {
      console.error("TRANSACTION FILE UPLOAD ERROR:", error);

      return res.status(500).json({
        success: false,
        message: "File upload failed",
      });
    }
  },
);
router.post("/add-transaction", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const {
      transaction_type,
      category_id,
      account_id,
      to_account_id,
      deduct_fee,
      deduct_fee_account_id,
      transaction_date,
      payer_payee_id,
      amount,
      transaction_fee,
      note,
      status,
      file_url,
      outlet_id,
    } = req.body;

    const userId = req.user.user_id;

    if (
      !transaction_type ||
      !category_id ||
      !account_id ||
      !transaction_date ||
      !amount ||
      !outlet_id
    ) {
      return res.status(400).json({
        success: false,
        message: "Required fields are missing",
      });
    }

    if (transaction_type !== "transfer" && !payer_payee_id) {
      return res.status(400).json({
        success: false,
        message: "Payer/Payee is required",
      });
    }

    if (Number(amount) <= 0) {
      return res.status(400).json({
        success: false,
        message: "Amount must be greater than 0",
      });
    }

    if (transaction_type === "transfer" && account_id === to_account_id) {
      return res.status(400).json({
        success: false,
        message: "From and To account cannot be the same",
      });
    }

    await client.query("BEGIN");

    const amt = Number(amount);
    const fee = Number(transaction_fee) || 0;

    let mainTransaction;

    // Validate account exists
    const accountCheck = await client.query(
      `SELECT id FROM accounts WHERE id=$1`,
      [account_id],
    );

    if (accountCheck.rowCount === 0) {
      throw new Error("Account not found");
    }

    // Get account info (name + id)
    const accountInfoRes = await client.query(
      `SELECT id, name FROM accounts WHERE id = $1`,
      [account_id],
    );

    const accountInfo = accountInfoRes.rows[0];

    // Build formatted note
    const formattedNote = note
      ? `[${accountInfo.name} (#${accountInfo.id})] ${note}`
      : `[${accountInfo.name} (#${accountInfo.id})]`;

    // ====================================================
    // INCOME
    // ====================================================
    if (transaction_type === "income") {
      const prevBalanceResult = await client.query(
        `SELECT balance FROM accounts WHERE id=$1`,
        [account_id],
      );

      const prevBalance = Number(prevBalanceResult.rows[0].balance);

      await client.query(
        `UPDATE accounts SET balance = balance + $1 WHERE id=$2`,
        [amt, account_id],
      );

      const newBalance = prevBalance + amt;

      await client.query(
        `INSERT INTO account_statement
        (account_id, transaction_type, amount, reference, payer_payee, "by", prev_balance, balance)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          account_id,
          "credit",
          amt,
          formattedNote || null,
          payer_payee_id,
          userId,
          prevBalance,
          newBalance,
        ],
      );

      const result = await client.query(
        `INSERT INTO transactions
        (transaction_type, category_id, account_id, outlet_id, transaction_date,
        payer_payee_id, amount, transaction_fee, note, file_url, "by", status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
        RETURNING *`,
        [
          "income",
          category_id,
          account_id,
          outlet_id,
          transaction_date,
          payer_payee_id,
          amt,
          fee,
          formattedNote || null,
          file_url || null,
          userId,
          status || "active",
        ],
      );

      mainTransaction = result.rows[0];
    }

    // ====================================================
    // EXPENSE
    // ====================================================
    if (transaction_type === "expense") {
      const prevBalanceResult = await client.query(
        `SELECT balance FROM accounts WHERE id=$1`,
        [account_id],
      );

      const prevBalance = Number(prevBalanceResult.rows[0].balance);

      await client.query(
        `UPDATE accounts SET balance = balance - $1 WHERE id=$2`,
        [amt, account_id],
      );

      const newBalance = prevBalance - amt;

      await client.query(
        `INSERT INTO account_statement
        (account_id, transaction_type, amount, reference, payer_payee, "by", prev_balance, balance)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          account_id,
          "debit",
          amt,
          formattedNote || null,
          payer_payee_id,
          userId,
          prevBalance,
          newBalance,
        ],
      );

      const result = await client.query(
        `INSERT INTO transactions
        (transaction_type, category_id, account_id, outlet_id, transaction_date,
        payer_payee_id, amount, transaction_fee, note, file_url, "by", status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
        RETURNING *`,
        [
          "expense",
          category_id,
          account_id,
          outlet_id,
          transaction_date,
          payer_payee_id,
          amt,
          fee,
          formattedNote || null,
          file_url || null,
          userId,
          status || "active",
        ],
      );

      mainTransaction = result.rows[0];
    }

    // ====================================================
    // TRANSFER
    // ====================================================
    if (transaction_type === "transfer") {
      // Get TO account info
      const toAccountInfoRes = await client.query(
        `SELECT id, name FROM accounts WHERE id = $1`,
        [to_account_id],
      );

      const toAccountInfo = toAccountInfoRes.rows[0];

      const formattedToNote = note
        ? `[${toAccountInfo.name} (#${toAccountInfo.id})] ${note}`
        : `[${toAccountInfo.name} (#${toAccountInfo.id})]`;

      const fromBalanceRes = await client.query(
        `SELECT balance FROM accounts WHERE id=$1`,
        [account_id],
      );

      const toBalanceRes = await client.query(
        `SELECT balance FROM accounts WHERE id=$1`,
        [to_account_id],
      );

      const fromPrev = Number(fromBalanceRes.rows[0].balance);
      const toPrev = Number(toBalanceRes.rows[0].balance);

      await client.query(
        `UPDATE accounts SET balance = balance - $1 WHERE id=$2`,
        [amt, account_id],
      );

      await client.query(
        `UPDATE accounts SET balance = balance + $1 WHERE id=$2`,
        [amt, to_account_id],
      );

      await client.query(
        `INSERT INTO account_statement
        (account_id, transaction_type, amount, reference, payer_payee, "by", prev_balance, balance)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          account_id,
          "debit",
          amt,
          formattedNote || null,
          payer_payee_id,
          userId,
          fromPrev,
          fromPrev - amt,
        ],
      );

      await client.query(
        `INSERT INTO account_statement
        (account_id, transaction_type, amount, reference, payer_payee, "by", prev_balance, balance)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          to_account_id,
          "credit",
          amt,
          formattedToNote || null,
          payer_payee_id,
          userId,
          toPrev,
          toPrev + amt,
        ],
      );

      const result = await client.query(
        `INSERT INTO transactions
        (transaction_type, category_id, account_id, outlet_id, transaction_date,
        payer_payee_id, amount, note, file_url, "by", status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
        RETURNING *`,
        [
          "transfer",
          category_id,
          account_id,
          outlet_id,
          transaction_date,
          null,
          amt,
          formattedNote || null,
          file_url || null,
          userId,
          status || "active",
        ],
      );

      mainTransaction = result.rows[0];
    }

    await client.query("COMMIT");

    // ====================================================
    // TRANSACTION FEE
    // ====================================================
    if (fee > 0) {
      const feeAccountId = deduct_fee_account_id || account_id;

      const feeBalanceRes = await client.query(
        `SELECT balance FROM accounts WHERE id=$1`,
        [feeAccountId],
      );

      const feePrevBalance = Number(feeBalanceRes.rows[0].balance);

      await client.query(
        `UPDATE accounts SET balance = balance - $1 WHERE id=$2`,
        [fee, feeAccountId],
      );

      const feeNewBalance = feePrevBalance - fee;

      await client.query(
        `INSERT INTO account_statement
        (account_id, transaction_type, amount, reference, payer_payee, "by", prev_balance, balance)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          feeAccountId,
          "debit",
          fee,
          `Transaction Fee`,
          payer_payee_id || null,
          userId,
          feePrevBalance,
          feeNewBalance,
        ],
      );

      await client.query(
        `INSERT INTO transactions
        (transaction_type, category_id, account_id, outlet_id, transaction_date,
        payer_payee_id, amount, transaction_fee, note, "by", status, reference_id)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [
          "expense",
          category_id,
          feeAccountId,
          outlet_id,
          transaction_date,
          payer_payee_id || null,
          fee,
          0,
          `Transaction Fee`,
          userId,
          status || "active",
          mainTransaction.transaction_id,
        ],
      );
    }

    await insertAdminLog(
      userId,
      "TRANSACTION",
      `Created ${transaction_type} transaction | Ref ID: ${mainTransaction.transaction_id}`,
    );

    return res.status(201).json({
      success: true,
      message: "Transaction processed successfully",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Create Transaction Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  } finally {
    client.release();
  }
});

router.get("/fetch-transactions-list", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      from,
      to,
      transaction_type,
      category_id,
      account_id,
      payer_payee,
      status,
    } = req.query;

    const limit = 25;
    const offset = (page - 1) * limit;

    let whereClauses = [];
    let values = [];
    let index = 1;

    // =========================
    // Dynamic Filters
    // =========================

    if (from) {
      whereClauses.push(`t.transaction_date >= $${index++}`);
      values.push(from);
    }

    if (to) {
      whereClauses.push(`t.transaction_date <= $${index++}`);
      values.push(to);
    }

    if (transaction_type) {
      whereClauses.push(`t.transaction_type = $${index++}`);
      values.push(transaction_type);
    }

    if (category_id) {
      whereClauses.push(`t.category_id = $${index++}`);
      values.push(category_id);
    }

    if (account_id) {
      whereClauses.push(`t.account_id = $${index++}`);
      values.push(account_id);
    }

    if (payer_payee) {
      whereClauses.push(`t.payer_payee ILIKE $${index++}`);
      values.push(`%${payer_payee}%`);
    }

    if (status) {
      whereClauses.push(`t.status = $${index++}`);
      values.push(status);
    }

    const whereSQL =
      whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

    // =========================
    // Count Query
    // =========================
    const countQuery = `
      SELECT COUNT(*) 
      FROM public.transactions t
      ${whereSQL}
    `;

    const countResult = await pool.query(countQuery, values);
    const totalRecords = parseInt(countResult.rows[0].count);

    // =========================
    // Main Data Query (WITH USERS + ACCOUNTS JOIN)
    // =========================
    // =========================
    // Fetch Currency (Global Setting)
    // =========================
    const currencyQuery = `
  SELECT currency 
  FROM public.system_settings
  LIMIT 1
`;

    const currencyResult = await pool.query(currencyQuery);
    const currency = currencyResult.rows[0]?.currency || null;
    const dataQuery = `
  SELECT 
    t.*,                     -- existing (kept)
    t.note AS note,          -- ✅ explicitly ensure note
    ss.currency,             -- ✅ currency added

    u.first_name,
    u.last_name,
    (u.first_name || ' ' || u.last_name) AS created_by_name,
   a.name AS account_name,
ac.name AS category_name,
app.name AS payer_payee

  FROM public.transactions t

  LEFT JOIN public.users u
    ON t."by" = u.user_id

  LEFT JOIN public.accounts a
    ON t.account_id = a.id

  LEFT JOIN public.account_categories ac
    ON t.category_id = ac.category_id
    LEFT JOIN public.accounts_payer_payee app
  ON t.payer_payee_id = app.id

  CROSS JOIN public.system_settings ss   -- ✅ currency source

  ${whereSQL}

  ORDER BY t.transaction_id DESC
  LIMIT ${limit}
  OFFSET ${offset}
`;

    const dataResult = await pool.query(dataQuery, values);

    return res.status(200).json({
      success: true,
      page: Number(page),
      per_page: limit,
      total_records: totalRecords,
      total_pages: Math.ceil(totalRecords / limit),
      currency: currency, // ✅ added here (outside rows)
      data: dataResult.rows,
    });
  } catch (error) {
    console.error("Fetch Transactions Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
});

// fetch active accounts

router.get("/fetch-active-accounts", authenticateToken, async (req, res) => {
  try {
    const { outlet_id } = req.query;

    let query = `
      SELECT 
        a.id,
        a.name,
        a.outlet_id,
        o.name AS outlet_name
      FROM public.accounts a
      LEFT JOIN public.outlets o 
        ON o.outlet_id = a.outlet_id
      WHERE LOWER(a.status) = 'active'
    `;

    const params = [];

    // Optional outlet filter
    if (outlet_id) {
      query += ` AND a.outlet_id = $1`;
      params.push(outlet_id);
    }

    query += ` ORDER BY a.name ASC`;

    const result = await pool.query(query, params);

    return res.status(200).json({
      success: true,
      count: result.rowCount,
      data: result.rows,
    });
  } catch (error) {
    console.error("Fetch Active Accounts Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
});
// fetch active payer and payees

router.get("/fetch-payer-payees", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    const result = await client.query(`
      SELECT 
        id,
        name,
        type,
        created_at
      FROM accounts_payer_payee
      WHERE status = 'active'
      ORDER BY name ASC
    `);

    return res.status(200).json({
      success: true,
      payer_payees: result.rows,
    });
  } catch (error) {
    console.error("Fetch Payer Payees Error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  } finally {
    client.release();
  }
});

// fetch report details

router.get(
  "/fetch-transactions-list-report",
  authenticateToken,
  async (req, res) => {
    try {
      const {
        page = 1,
        from,
        to,
        transaction_type,
        category_id,
        account_id,
        payer_payee_id,
        status,
      } = req.query;

      const limit = 25;
      const offset = (page - 1) * limit;

      let whereClauses = [];
      let values = [];
      let index = 1;

      // =========================
      // Date Filters
      // =========================

      if (from) {
        whereClauses.push(`t.transaction_date >= $${index++}`);
        values.push(from);
      }

      if (to) {
        whereClauses.push(`t.transaction_date <= $${index++}`);
        values.push(to);
      }

      // =========================
      // Multi Transaction Types
      // =========================

      if (transaction_type) {
        const types = transaction_type.split(",");
        whereClauses.push(`t.transaction_type = ANY($${index++})`);
        values.push(types);
      }

      // =========================
      // Multi Categories
      // =========================

      if (category_id) {
        const categories = category_id.split(",").map(Number);
        whereClauses.push(`t.category_id = ANY($${index++})`);
        values.push(categories);
      }

      // =========================
      // Multi Accounts
      // =========================

      if (account_id) {
        const accounts = account_id.split(",").map(Number);
        whereClauses.push(`t.account_id = ANY($${index++})`);
        values.push(accounts);
      }

      // =========================
      // Multi Payer/Payee
      // =========================

      if (payer_payee_id) {
        const parties = payer_payee_id.split(",").map(Number);
        whereClauses.push(`t.payer_payee_id = ANY($${index++})`);
        values.push(parties);
      }

      // =========================
      // Status Filter
      // =========================

      if (status) {
        whereClauses.push(`t.status = $${index++}`);
        values.push(status);
      }

      const whereSQL =
        whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

      // =========================
      // Count Query
      // =========================

      const countQuery = `
      SELECT COUNT(*) 
      FROM public.transactions t
      ${whereSQL}
    `;

      const countResult = await pool.query(countQuery, values);
      const totalRecords = parseInt(countResult.rows[0].count);

      // =========================
      // Fetch Currency
      // =========================

      const currencyQuery = `
      SELECT currency 
      FROM public.system_settings
      LIMIT 1
    `;

      const currencyResult = await pool.query(currencyQuery);
      const currency = currencyResult.rows[0]?.currency || null;

      // =========================
      // Main Data Query
      // =========================

      const dataQuery = `
      SELECT 
        t.*,
        t.note AS note,
        ss.currency,

        u.first_name,
        u.last_name,
        (u.first_name || ' ' || u.last_name) AS created_by_name,

        a.name AS account_name,
        ac.name AS category_name,
        app.name AS payer_payee

      FROM public.transactions t

      LEFT JOIN public.users u
        ON t."by" = u.user_id

      LEFT JOIN public.accounts a
        ON t.account_id = a.id

      LEFT JOIN public.account_categories ac
        ON t.category_id = ac.category_id

      LEFT JOIN public.accounts_payer_payee app
        ON t.payer_payee_id = app.id

      CROSS JOIN public.system_settings ss

      ${whereSQL}

      ORDER BY t.transaction_id DESC
      LIMIT ${limit}
      OFFSET ${offset}
    `;

      const dataResult = await pool.query(dataQuery, values);

      return res.status(200).json({
        success: true,
        page: Number(page),
        per_page: limit,
        total_records: totalRecords,
        total_pages: Math.ceil(totalRecords / limit),
        currency: currency,
        data: dataResult.rows,
      });
    } catch (error) {
      console.error("Fetch Transactions Error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  },
);

// fetch approved transactions summary/totals

router.get(
  "/fetch-approved-transactions-summary",
  authenticateToken,
  async (req, res) => {
    try {
      const summaryQuery = `
        SELECT
          COALESCE(SUM(
            CASE
              WHEN t.transaction_type = 'income'
              AND t.payment_status = 'approved'
              THEN t.amount
              ELSE 0
            END
          ),0) AS total_income,

          COALESCE(SUM(
            CASE
              WHEN t.transaction_type = 'expense'
              AND t.payment_status = 'approved'
              THEN t.amount
              ELSE 0
            END
          ),0) AS total_expense

        FROM public.transactions t
      `;

      const summaryResult = await pool.query(summaryQuery);

      const currencyQuery = `
        SELECT currency
        FROM public.system_settings
        LIMIT 1
      `;

      const currencyResult = await pool.query(currencyQuery);

      const currency = currencyResult.rows[0]?.currency || null;

      return res.status(200).json({
        success: true,
        currency,
        total_income: Number(summaryResult.rows[0].total_income),
        total_expense: Number(summaryResult.rows[0].total_expense),
      });
    } catch (error) {
      console.error("Approved Transactions Summary Error:", error);

      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  },
);
module.exports = router;
