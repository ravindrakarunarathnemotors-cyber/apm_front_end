const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const pool = require("../config/db");
const {formatPhoneNumber} = require("../models/authModels")

const bcrypt = require("bcrypt");


const router = express.Router();

router.post('/register_merchant', async (req, res) => {
  const { email, firstname, lastname, password, mobile } = req.body;

  // ✅ 1. Validate input
  if (!email || !firstname || !lastname || !password || !mobile) {
    return res
      .status(400)
      .setHeader('Content-Type', 'application/json')
      .json({ field: null, message: 'All fields are required' });
  }

  try {
    // ✅ 2. Check for duplicate email
    const userExists = await pool.query(
      'SELECT email FROM admin_user WHERE email = $1',
      [email]
    );

    if (userExists.rows.length > 0) {
      return res
        .status(409)
        .setHeader('Content-Type', 'application/json')
        .json({ field: 'email', message: 'An account with this email already exists. Please use a different email or try logging in.' });
    }

    // ✅ 3. (Optional) Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);
    // const hashedPassword = password; // Use plain for now (not recommended in production)

    // ✅ 4. Insert merchant into DB
await pool.query(
  `INSERT INTO admin_user (
    first_name, last_name, username, password, mobile,
    role_id, status, email, branch_id, created_at, updated_at
  ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW(), NOW())`,
  [
    firstname,
    lastname,
    email,
    hashedPassword,
    mobile,
    1,
    'Active',
    email,
    1
  ]
);



    // ✅ 5. Return success
   return res
  .status(201)
  .setHeader('Content-Type', 'application/json')
  .json({
    message: 'Merchant registered successfully',
    // username: email,              // or a generated username
    // password: password            // or return hashedPassword if needed (not recommended)
  });

  } catch (err) {
    console.error('❌ Error registering merchant:', err);
    return res
      .status(500)
      .setHeader('Content-Type', 'application/json')
      .json({ field: null, message: 'Server error. Please try again later.' });
  }
});





module.exports = router;
