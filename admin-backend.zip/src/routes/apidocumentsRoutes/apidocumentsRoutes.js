const express = require("express");
const router  = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");

const {
  toggleApiStatus,
  regenerateApiKey,
  updateClientId,
  getApiLogs,
  loyaltyPointRequest,
  checkCustomerByEmailOrMobile,
  getApiDetails,
} = require("../../controllers/apiDocuments/apiDocumentsController");

// ── Internal admin routes (protected) ─────────────────────────────────────────
//router.get("/api-settings",               authenticateToken, getApiDetails);
router.patch("/api-settings/toggle",      authenticateToken, toggleApiStatus);
router.post("/api-settings/regenerate-key", authenticateToken, regenerateApiKey);
router.patch("/api-settings/client-id",   authenticateToken, updateClientId);
router.get("/api-logs",                   authenticateToken, getApiLogs);

// ── Public external endpoint (called by the clothing shop) ────────────────────
router.post("/loyalty-point-request", loyaltyPointRequest);
router.post("/check-customer", checkCustomerByEmailOrMobile);
router.get('/api-details', getApiDetails);
router.post("/loyalty", checkCustomerByEmailOrMobile);

module.exports = router;