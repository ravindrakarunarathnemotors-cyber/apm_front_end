const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const multer = require('multer');
const upload = multer();

router.post('/Simple_Express', async (req, res) => {
    console.log("req",req);
    try {
        const { waybill_id, delivery_status, last_update_time } = req.body;

        if (![5, 7].includes(Number(delivery_status))) {
            return res.status(400).json({ message: "Invalid delivery_status" });
        }

        const orderResult = await pool.query(
            "SELECT * FROM orders WHERE tracking_id = $1",
            [waybill_id]
        );

        if (orderResult.rows.length === 0) {
            return res.status(404).json({ message: "Order not found" });
        }

        if (delivery_status === 5) {
            await pool.query(
                "UPDATE orders SET order_status = 'completed', delivery_completed_date = $1 WHERE tracking_id = $2",
                [last_update_time, waybill_id]
            );
            return res.status(200).json({ message: "Order marked as Completed" });
        }

        if (delivery_status === 7) {
            await pool.query(
                "UPDATE orders SET order_status = 'returned', returned_date = $1 WHERE tracking_id = $2",
                [last_update_time, waybill_id]
            );
            return res.status(200).json({ message: "Order marked as Returned" });
        }

    } catch (error) {
        console.error("Webhook error:", error);
        res.status(500).json({ message: "Server error" });
    }
});


// router.post('/FARDER', upload.none(), async (req, res) => {
//     try {
//         console.log("req.body:", req.body);

//         const { waybill_id, current_status, last_update_time } = req.body;

//         console.log(waybill_id);       // :white_check_mark: works
//         console.log(current_status);   // :white_check_mark: works

//         if (!waybill_id || !current_status) {
//             return res.status(400).json({
//                 message: "Missing required fields"
//             });
//         }

//         console.log("waybill_id:", waybill_id);
//         console.log("delivery_status:", current_status);
//         console.log("last_update_time:", last_update_time);

//         const orderResult = await pool.query(
//             "SELECT * FROM orders WHERE tracking_id = $1",
//             [waybill_id]
//         );

//          if (orderResult.rows.length === 0) {
//             return res.status(404).json({
//                 message: "Order not found"
//             });
//         }

//         await pool.query(
//             `UPDATE orders 
//              SET order_status = $1,
//                  last_update_time = $2
//              WHERE tracking_id = $3`,
//             [current_status, last_update_time, waybill_id]
//         );

//         return res.status(200).json({
//             message: "Order status updated successfully"
//         });

//     } catch (error) {
//         console.error("Callback error:", error);

//         return res.status(500).json({
//             message: "Server error"
//         });
//     }
// });
router.post('/FARDER', upload.none(), async (req, res) => {
    try {
        console.log("req.body:", req.body);

        const { waybill_id, current_status, last_update_time } = req.body;

        if (!waybill_id || !current_status) {
            return res.status(400).json({
                message: "Missing required fields"
            });
        }

        // ✅ get order
        const orderResult = await pool.query(
            "SELECT * FROM orders WHERE tracking_id = $1",
            [waybill_id]
        );

        if (orderResult.rows.length === 0) {
            return res.status(404).json({
                message: "Order not found"
            });
        }

        const order = orderResult.rows[0]

        // ✅ update order
        await pool.query(
            `UPDATE orders 
             SET order_status = $1,
                 last_update_time = $2
             WHERE tracking_id = $3`,
            [current_status, last_update_time, waybill_id]
        );

        // ✅ INSERT LOG (NEW)
        await pool.query(
            `INSERT INTO farder_webhook_logs 
            (delivery_partner_id, waybill_id, ref_url, response)
            VALUES ($1, $2, $3, $4)`,
            [
                order.delivery_partner_id, // from orders table
                waybill_id,
                '/FARDER',
                req.body // full JSON
            ]
        );

        return res.status(200).json({
            message: "Order status updated & logged"
        });

    } catch (error) {
        console.error("Callback error:", error);

        return res.status(500).json({
            message: "Server error"
        });
    }
});

module.exports = router;
