const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");



router.get("/rawmaterialsname", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name FROM raw_material WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.post("/allrawmaterial", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];


    if (keyword) {
      const trimmedKeyword = keyword.trim();
      queryParams.push(`%${trimmedKeyword}%`);

      whereConditions.push(`
        (
          r.name ILIKE $${queryParams.length}
          OR r.id::text ILIKE $${queryParams.length}
        )
      `);
    }


    if (status) {
      queryParams.push(status);
      whereConditions.push(`r.status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";


    const rawMaterialQuery = `
      SELECT
        r.id,
        r.name,
        r.weight,
        r.reorder_level,
        r.measurement_unit,
        m.measurement_value,
        r.status
      FROM raw_material r
      LEFT JOIN measurements m ON r.measurement_unit = m.measurement_id
      ${whereClause}
      ORDER BY r.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(rawMaterialQuery, paginatedParams);


    const countQuery = `
      SELECT COUNT(*) AS total
      FROM raw_material r
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      raw_materials: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (err) {
    console.error("Error fetching raw materials:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put('/toggle-rawmaterial-status/:id', authenticateToken, async (req, res) => {
  const { id } = req.params
  const { status } = req.body
  const user_id = req.user.user_id

  const client = await pool.connect()

  try {
    if (!id || !status) {
      return res.status(400).json({
        success: false,
        message: 'ID and status are required',
      })
    }

    await client.query('BEGIN')

    // 🔎 Get current data for logging
    const existingResult = await client.query(
      `SELECT name, status FROM raw_material WHERE id = $1`,
      [id]
    )

    if (existingResult.rowCount === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({
        success: false,
        message: 'Raw material not found',
      })
    }

    const { name, status: oldStatus } = existingResult.rows[0]

    // 🔄 Update status
    const updateQuery = `
      UPDATE raw_material
      SET status = $1
      WHERE id = $2
      RETURNING id, status
    `

    const result = await client.query(updateQuery, [status, id])

    await client.query('COMMIT')

    // ✅ Insert log AFTER commit
    await insertAdminLog(
      user_id,
      'Raw Material',
      `Changed Status Raw Material (#${id}) - ${name} from ${oldStatus} to ${status}`
    )

    return res.json({
      success: true,
      message: 'Raw material status updated successfully',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error updating raw material status:', error)

    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    })
  } finally {
    client.release()
  }
})

router.post('/create-rawmaterial', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id

    const {
      name,
      reorder_level,
      measurement_unit,
      status,
    } = req.body


    if (!name || !reorder_level || !measurement_unit) {
      return res.status(400).json({
        success: false,
        message: 'All required fields must be provided',
      })
    }

    await client.query('BEGIN')

    const insertQuery = `
      INSERT INTO raw_material (
        name,
        reorder_level,
        measurement_unit,
        status
      )
      VALUES ($1, $2, $3, $4)
      RETURNING id, name
    `

    const values = [
      name,
      Number(reorder_level),
      Number(measurement_unit),
      status || 'Active',
    ]

    const result = await client.query(insertQuery, values)
    const newRawMaterial = result.rows[0]

    await client.query('COMMIT')


    await insertAdminLog(
      user_id,
      'Raw Material',
      `Created Raw Material (#${newRawMaterial.id}) - ${newRawMaterial.name}`
    )

    return res.status(201).json({
      success: true,
      message: 'Raw material created successfully',

    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error creating raw material:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to create raw material',
    })
  } finally {
    client.release()
  }
})

router.put('/update-rawmaterial/:id', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id
    const { id } = req.params

    const {
      name,
      weight,
      reorder_level,
      measurement_unit,
      status,
    } = req.body

    if (!name || !weight || !reorder_level || !measurement_unit) {
      return res.status(400).json({
        success: false,
        message: 'All required fields must be provided',
      })
    }

    await client.query('BEGIN')


    const oldDataResult = await client.query(
      `SELECT name FROM raw_material WHERE id = $1`,
      [id]
    )

    if (oldDataResult.rows.length === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({
        success: false,
        message: 'Raw material not found',
      })
    }

    const oldName = oldDataResult.rows[0].name


    const updateQuery = `
      UPDATE raw_material
      SET
        name = $1,
        weight = $2,
        reorder_level = $3,
        measurement_unit = $4,
        status = $5
      WHERE id = $6
      RETURNING *
    `

    const values = [
      name,
      Number(weight),
      Number(reorder_level),
      Number(measurement_unit),
      status || 'Active',
      id,
    ]

    const result = await client.query(updateQuery, values)

    await client.query('COMMIT')


    await insertAdminLog(
      user_id,
      'Raw Material',
      `Updated Raw Material (#${id}) - ${oldName}`
    )

    return res.status(200).json({
      success: true,
      message: 'Raw material updated successfully',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error updating raw material:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to update raw material',
    })
  } finally {
    client.release()
  }
})

router.get("/kitchennames", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name FROM kitchen WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/allkitchen", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔎 Keyword filter
    if (keyword) {
      const trimmedKeyword = keyword.trim();
      queryParams.push(`%${trimmedKeyword}%`);

      whereConditions.push(`
        (
          k.name ILIKE $${queryParams.length}
          OR k.display_id ILIKE $${queryParams.length}
          OR k.id::text ILIKE $${queryParams.length}
        )
      `);
    }

    // 🔎 Status filter
    if (status) {
      queryParams.push(status);
      whereConditions.push(`k.status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const kitchenQuery = `
      SELECT
        k.id,
        k.name,
        k.display_id,
        k.outlet_id,
        k.kot_printer_id,
        o.name AS outlet_name,
        k.status
      FROM kitchen k
      LEFT JOIN outlets o ON k.outlet_id = o.outlet_id
      ${whereClause}
      ORDER BY k.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(kitchenQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM kitchen k
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      kitchens: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (err) {
    console.error("Error fetching kitchens:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put('/toggle-kitchen-status/:id', authenticateToken, async (req, res) => {
  const { id } = req.params
  const { status } = req.body
  const user_id = req.user.user_id

  const client = await pool.connect()

  try {
    if (!id || !status) {
      return res.status(400).json({
        success: false,
        message: 'ID and status are required',
      })
    }

    await client.query('BEGIN')

    const existingResult = await client.query(
      `SELECT name, status FROM kitchen WHERE id = $1`,
      [id]
    )

    if (existingResult.rowCount === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({
        success: false,
        message: 'Kitchen not found',
      })
    }

    const { name, status: oldStatus } = existingResult.rows[0]

    const updateQuery = `
      UPDATE kitchen
      SET status = $1
      WHERE id = $2
      RETURNING id, status
    `

    const result = await client.query(updateQuery, [status, id])

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Kitchen',
      `Changed Status Kitchen (#${id}) - ${name} from ${oldStatus} to ${status}`
    )

    return res.json({
      success: true,
      message: 'Kitchen status updated successfully',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error updating kitchen status:', error)

    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    })
  } finally {
    client.release()
  }
})

router.post('/create-kitchen', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id
    const { name, display_id, outlet_id, status, kot_printer_id } = req.body

    if (!name || !outlet_id) {
      return res.status(400).json({
        success: false,
        message: 'Name and Outlet are required',
      })
    }

    await client.query('BEGIN')

    const insertQuery = `
      INSERT INTO kitchen (
        name,
        display_id,
        outlet_id,
        status,
        kot_printer_id
      )
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name
    `

    const values = [
      name,
      display_id || null,
      Number(outlet_id),
      status || 'Active',
      kot_printer_id || null
    ]

    const result = await client.query(insertQuery, values)
    const newKitchen = result.rows[0]

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Kitchen',
      `Created Kitchen (#${newKitchen.id}) - ${newKitchen.name}`
    )

    return res.status(201).json({
      success: true,
      message: 'Kitchen created successfully',
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error creating kitchen:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to create kitchen',
    })
  } finally {
    client.release()
  }
})

router.put('/update-kitchen/:id', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id
    const { id } = req.params
    const { name, display_id, outlet_id, status, kot_printer_id } = req.body

    if (!name || !outlet_id) {
      return res.status(400).json({
        success: false,
        message: 'Name and Outlet are required',
      })
    }

    await client.query('BEGIN')

    const oldData = await client.query(
      `SELECT name FROM kitchen WHERE id = $1`,
      [id]
    )

    if (oldData.rows.length === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({
        success: false,
        message: 'Kitchen not found',
      })
    }

    const updateQuery = `
      UPDATE kitchen
      SET
        name = $1,
        display_id = $2,
        outlet_id = $3,
        kot_printer_id = $6,
        status = $4
      WHERE id = $5
      RETURNING *
    `

    const values = [
      name,
      display_id || null,
      Number(outlet_id),
      status || 'Active',
      id,
      kot_printer_id || null, 
    ]

    const result = await client.query(updateQuery, values)

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Kitchen',
      `Updated Kitchen (#${id}) - ${oldData.rows[0].name}`
    )

    return res.status(200).json({
      success: true,
      message: 'Kitchen updated successfully',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error updating kitchen:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to update kitchen',
    })
  } finally {
    client.release()
  }
})

router.get("/restauranttablesnames", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name FROM restaurant_tables WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/allrestauranttables", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔎 Keyword filter
    if (keyword) {
      const trimmedKeyword = keyword.trim();
      queryParams.push(`%${trimmedKeyword}%`);

      whereConditions.push(`
        (
          t.name ILIKE $${queryParams.length}
          OR t.table_id ILIKE $${queryParams.length}
          OR t.id::text ILIKE $${queryParams.length}
        )
      `);
    }

    // 🔎 Status filter
    if (status) {
      queryParams.push(status);
      whereConditions.push(`t.status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const tableQuery = `
      SELECT
        t.id,
        t.name,
        t.table_id,
        t.note,
        t.seats,
        t.outlet_id,
        o.name AS outlet_name,
        t.status
      FROM restaurant_tables t
      LEFT JOIN outlets o ON t.outlet_id = o.outlet_id
      ${whereClause}
      ORDER BY t.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(tableQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM restaurant_tables t
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      restaurant_tables: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (err) {
    console.error("Error fetching restaurant tables:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.put('/toggle-restaurant-table-status/:id', authenticateToken, async (req, res) => {
  const { id } = req.params
  const { status } = req.body
  const user_id = req.user.user_id

  const client = await pool.connect()

  try {
    if (!id || !status) {
      return res.status(400).json({ success: false, message: 'ID and status required' })
    }

    await client.query('BEGIN')

    const existing = await client.query(
      `SELECT name, status FROM restaurant_tables WHERE id = $1`,
      [id]
    )

    if (existing.rowCount === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ success: false, message: 'Table not found' })
    }

    const { name, status: oldStatus } = existing.rows[0]

    const result = await client.query(
      `UPDATE restaurant_tables SET status = $1 WHERE id = $2 RETURNING id, status`,
      [status, id]
    )

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Restaurant Table',
      `Changed Status Table (#${id}) - ${name} from ${oldStatus} to ${status}`
    )

    return res.json({
      success: true,
      message: 'Restaurant table status updated',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error(error)
    return res.status(500).json({ success: false, message: 'Internal server error' })
  } finally {
    client.release()
  }
})

router.post('/create-restaurant-table', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id
    const { name, table_id, note, seats, outlet_id, status } = req.body

    if (!name || !outlet_id) {
      return res.status(400).json({
        success: false,
        message: 'Name and Outlet are required',
      })
    }

    await client.query('BEGIN')

    const insertQuery = `
      INSERT INTO restaurant_tables (
        name,
        table_id,
        note,
        seats,
        outlet_id,
        status
      )
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, name
    `

    const values = [
      name,
      table_id || null,
      note || null,
      seats ? Number(seats) : 1,
      Number(outlet_id),
      status || 'Active',
    ]

    const result = await client.query(insertQuery, values)
    const newTable = result.rows[0]

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Restaurant Table',
      `Created Restaurant Table (#${newTable.id}) - ${newTable.name}`
    )

    return res.status(201).json({
      success: true,
      message: 'Restaurant table created successfully',
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error creating table:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to create restaurant table',
    })
  } finally {
    client.release()
  }
})

router.put('/update-restaurant-table/:id', authenticateToken, async (req, res) => {
  const client = await pool.connect()

  try {
    const user_id = req.user.user_id
    const { id } = req.params
    const { name, table_id, note, seats, outlet_id, status } = req.body

    if (!name || !outlet_id) {
      return res.status(400).json({
        success: false,
        message: 'Name and Outlet are required',
      })
    }

    await client.query('BEGIN')

    const existing = await client.query(
      `SELECT name FROM restaurant_tables WHERE id = $1`,
      [id]
    )

    if (existing.rowCount === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({
        success: false,
        message: 'Restaurant table not found',
      })
    }

    const oldName = existing.rows[0].name

    const updateQuery = `
      UPDATE restaurant_tables
      SET
        name = $1,
        table_id = $2,
        note = $3,
        seats = $4,
        outlet_id = $5,
        status = $6,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $7
      RETURNING *
    `

    const values = [
      name,
      table_id || null,
      note || null,
      seats ? Number(seats) : 1,
      Number(outlet_id),
      status || 'Active',
      id,
    ]

    const result = await client.query(updateQuery, values)

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Restaurant Table',
      `Updated Restaurant Table (#${id}) - ${oldName}`
    )

    return res.status(200).json({
      success: true,
      message: 'Restaurant table updated successfully',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error('Error updating table:', error)

    return res.status(500).json({
      success: false,
      message: 'Failed to update restaurant table',
    })
  } finally {
    client.release()
  }
})

router.get("/available-kot-displays", authenticateToken, async (req, res) => {
  try {

    const query = `
      SELECT device_id, till_name
      FROM device_management
      WHERE type = 'kot_display'
      AND status = 'Active'
      AND device_id NOT IN (
        SELECT display_id::bigint
        FROM kitchen
        WHERE display_id IS NOT NULL
      )
      ORDER BY till_name ASC
    `

    const { rows } = await pool.query(query)

    res.json({
      success: true,
      displays: rows
    })

  } catch (error) {

    console.error("Error fetching KOT displays:", error)

    res.status(500).json({
      success: false,
      message: "Failed to fetch KOT displays"
    })
  }
})


router.get("/active-kot-printers", authenticateToken, async (req, res) => {
  try {

    const query = `
      SELECT device_id, till_name
      FROM device_management
      WHERE type = 'kot_printer'
      AND status = 'Active'
      AND device_id NOT IN (
        SELECT kot_printer_id
        FROM kitchen
        WHERE kot_printer_id IS NOT NULL
      )
      ORDER BY till_name ASC
    `

    const { rows } = await pool.query(query)

    res.json({
      success: true,
      printers: rows
    })

  } catch (error) {
    console.error("Error fetching KOT printers:", error)

    res.status(500).json({
      success: false,
      message: "Failed to fetch KOT printers"
    })
  }
})

router.post("/materialInventory", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      fromDate,
      toDate,
      material_id,
      keyword,
      outlet_id,
      stockType,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔎 Keyword filter (ID or Material Name)
    if (keyword && keyword.trim() !== "") {
      const trimmed = keyword.trim();

      if (!isNaN(trimmed)) {
        // search by ID
        queryParams.push(parseInt(trimmed, 10));
        whereConditions.push(`mi.id = $${queryParams.length}`);
      } else {
        // search by material name
        queryParams.push(`%${trimmed}%`);
        whereConditions.push(`LOWER(rm.name) LIKE LOWER($${queryParams.length})`);
      }
    }

    // 🔎 Filter by material_id (exact match)
    if (material_id) {
      queryParams.push(material_id);
      whereConditions.push(`mi.material_id = $${queryParams.length}`);
    }

    // 🔎 Filter by outlet
    if (outlet_id) {
      queryParams.push(outlet_id);
      whereConditions.push(`mi.outlet_id = $${queryParams.length}`);
    }

    // 🔥 Stock Type Filter
    if (stockType) {
      const normalized = String(stockType)
        .toLowerCase()
        .replace(/[-_]+/g, " ")
        .trim();

      if (normalized === "stock in") {
        whereConditions.push(`mi.adjust_stock > 0`);
      } else if (normalized === "stock out") {
        whereConditions.push(`mi.adjust_stock < 0`);
      }
    }

    // 📅 Date filter
    let from = fromDate;
    let to = toDate;

    if (from && to && new Date(from) > new Date(to)) {
      [from, to] = [to, from];
    }

    if (from && to) {
      queryParams.push(from);
      queryParams.push(to);
      whereConditions.push(
        `mi.date::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
      );
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // ✅ MAIN DATA QUERY
    const dataQuery = `
      SELECT 
        mi.id,
        mi.material_id,
        rm.name AS material_name,
        mi.prev_stock,
        mi.adjust_stock,
        mi.current_stock,
        mi.date,
        mi.module,
        mi.outlet_id,
        o.name AS outlet_name,
        mi.by,
        u.first_name AS by_name,
        mi.note,
        CASE 
          WHEN mi.adjust_stock > 0 THEN 'stock in'
          WHEN mi.adjust_stock < 0 THEN 'stock out'
        END AS stock_type
      FROM material_inventory mi
      LEFT JOIN raw_material rm 
        ON mi.material_id = rm.id
      LEFT JOIN outlets o 
        ON mi.outlet_id = o.outlet_id
      LEFT JOIN users u 
        ON mi.by = u.user_id
      ${whereClause}
      ORDER BY mi.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const dataParams = [...queryParams, parsedLimit, offset];
    const result = await pool.query(dataQuery, dataParams);

    // ✅ FIXED COUNT QUERY (IMPORTANT 🔥)
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM material_inventory mi
      LEFT JOIN raw_material rm 
        ON mi.material_id = rm.id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      data: result.rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (error) {
    console.error("Error fetching material inventory:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/materialnames", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `
      SELECT id, name 
      FROM raw_material 
      WHERE name ILIKE $1 
      LIMIT 10
    `;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching materials:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.get("/available-kot-display", authenticateToken, async (req, res) => {
  try {
    // cast query param to number
    const kitchen_id = req.query.kitchen_id ? Number(req.query.kitchen_id) : null

    const query = `
      SELECT device_id, till_name
      FROM device_management
      WHERE type = 'kot_display'
      AND status = 'Active'
      AND (
        device_id NOT IN (
          SELECT display_id::bigint
          FROM kitchen
          WHERE display_id IS NOT NULL
          ${kitchen_id ? "AND id != $1" : ""}
        )
        ${kitchen_id ? "OR device_id = (SELECT display_id::bigint FROM kitchen WHERE id = $1)" : ""}
      )
      ORDER BY till_name ASC
    `

    const values = kitchen_id ? [kitchen_id] : []

    const { rows } = await pool.query(query, values)

    res.json({
      success: true,
      displays: rows
    })
  } catch (error) {
    console.error("Error fetching KOT displays:", error)
    res.status(500).json({
      success: false,
      message: "Failed to fetch KOT displays"
    })
  }
})

router.get("/active-kot-printer", authenticateToken, async (req, res) => {
  try {
    const { kitchen_id } = req.query

    const query = `
      SELECT device_id, till_name
      FROM device_management
      WHERE type = 'kot_printer'
      AND status = 'Active'
      AND (
        device_id NOT IN (
          SELECT kot_printer_id
          FROM kitchen
          WHERE kot_printer_id IS NOT NULL
          ${kitchen_id ? "AND id != $1" : ""}
        )
        ${kitchen_id ? "OR device_id = (SELECT kot_printer_id FROM kitchen WHERE id = $1)" : ""}
      )
      ORDER BY till_name ASC
    `

    const values = kitchen_id ? [kitchen_id] : []

    const { rows } = await pool.query(query, values)

    res.json({
      success: true,
      printers: rows
    })

  } catch (error) {
    console.error("Error fetching KOT printers:", error)

    res.status(500).json({
      success: false,
      message: "Failed to fetch KOT printers"
    })
  }
})

module.exports = router;