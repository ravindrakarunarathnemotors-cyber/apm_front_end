const express = require("express");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();

const {
  searchProducts, createJob, getAllJobs, getJobById, updateJobStatus, updateJob,
  deleteJob, searchCustomers, createCustomer, searchUsers, assignUsersToJob,
  getJobLogs, updateJobNote, getDeletedJobs, restoreJob, convertJobToInvoice,
  getJobInvoice, getJobQuotation, convertJobToQuotation,  updateQuotationLink
} = require("../../controllers/service/serviceController");

router.get("/products/search",       authenticateToken, searchProducts);
router.get("/users/search",          authenticateToken, searchUsers);
router.get("/customers/search",      authenticateToken, searchCustomers);
router.post("/customers",            authenticateToken, createCustomer);

router.post("/jobs",                 authenticateToken, createJob);
router.get("/jobs",                  authenticateToken, getAllJobs);

router.get("/jobs/deleted/list",     authenticateToken, getDeletedJobs);
router.get("/jobs/invoice/:id",      authenticateToken, getJobInvoice);
router.get("/jobs/quotation/:id",    authenticateToken, getJobQuotation); 

// ✅ Dynamic :id routes
router.get("/jobs/:id",              authenticateToken, getJobById);
router.put("/jobs/:id",              authenticateToken, updateJob);
router.put("/jobs/:id/status",       authenticateToken, updateJobStatus);
router.put("/jobs/:id/assign",       authenticateToken, assignUsersToJob);
router.put("/jobs/:id/note",         authenticateToken, updateJobNote);
router.put("/jobs/:id/restore",      authenticateToken, restoreJob);
router.delete("/jobs/:id",           authenticateToken, deleteJob);
router.get("/jobs/:id/logs",         authenticateToken, getJobLogs);
router.post("/jobs/:id/invoice",     authenticateToken, convertJobToInvoice);
router.post("/jobs/:id/quotation",   authenticateToken, convertJobToQuotation);
router.patch('/jobs/quotation/:id/link', authenticateToken, updateQuotationLink);

module.exports = router;