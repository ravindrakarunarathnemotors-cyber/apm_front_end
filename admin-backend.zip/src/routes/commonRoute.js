const express = require("express");
const { getAllCustomer, getAllPaymentMethod, Notification, getAllCustomerUpdate, getAllAccount, saveCustomer, getPermissionforuser, getPermissionforuseremployee } = require("../controllers/commonController");
const router = express.Router();
const authenticateToken = require("../middleware/authMiddleware");


router.get("/getAllCustomer", authenticateToken, getAllCustomer);

router.get("/getAllPaymentMethod", authenticateToken, getAllPaymentMethod);

router.post("/Notification",  Notification);

router.get("/getAllCustomerUpdate", authenticateToken, getAllCustomerUpdate);

router.get("/getAllAccount", authenticateToken, getAllAccount);

router.post("/saveCustomer", authenticateToken, saveCustomer);

router.get("/getPermissionforuser", authenticateToken, getPermissionforuser);

router.get("/getPermissionforuseremployee", authenticateToken, getPermissionforuseremployee);


module.exports = router;