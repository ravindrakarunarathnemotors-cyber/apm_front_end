const express = require("express");
const router  = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const {
  getFingerprintApiDetails,
  receiveFingerprintEvents,
  getFingerprintLogs,
  syncFingerprintLogs,
  getEmployeeList, 
} = require("../../controllers/fingerprint/fingerprintcontroller");

// Protected (dashboard)
router.get("/api-details", authenticateToken, getFingerprintApiDetails);
router.get("/logs",        authenticateToken, getFingerprintLogs);

// Public (called by HikSync desktop app)
router.post("/events", receiveFingerprintEvents);
router.get("/employees",   getEmployeeList); 

router.post("/sync", authenticateToken, syncFingerprintLogs);

module.exports = router;