const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const {
  getsystemSettings,
  getPosSettings,
  updatePosSettings,
  getProductSearch,
  createTemporyInvoice,
  getDraftInvoice,
  addItemsToInvoice,
  onebatchaddItemsToInvoice,
  onebatchcreateTemporyInvoice,
  getbatchDetails,
  FIFOaddItemsToInvoice,
  FIFOcreateTemporyInvoice,
  getmanualbatchDetails,
  manualaddItemsToInvoice,
  getHoldInvoice,
  deleteiItemsFromInvoice,
  updateiItemsFromInvoice,
  draftToHoldInvoice,
  discardInvoice,
  holdtoDraftInvoice,
  releaseTill,
  saveCookistillid,
  getCookistillid,
  CreateInvoiceID,
  getsystemSettingsDisplay,
  getwelcome
} = require("../../controllers/pos/PosController");

router.get("/getsystemSettings", authenticateToken, getsystemSettings);
router.get("/getposSettings", authenticateToken, getPosSettings);
router.post("/updateposSettings", authenticateToken, updatePosSettings);

router.get("/getProductSearch", authenticateToken, getProductSearch);

// create invoce add add product
router.post("/createTemporyInvoice", authenticateToken, createTemporyInvoice);

router.post("/addItemsToInvoice", authenticateToken, addItemsToInvoice);

//batch

router.post(
  "/onebatchaddItemsToInvoice",
  authenticateToken,
  onebatchaddItemsToInvoice,
);

router.post(
  "/onebatchcreateTemporyInvoice",
  authenticateToken,
  onebatchcreateTemporyInvoice,
);

router.post("/FIFOaddItemsToInvoice", authenticateToken, FIFOaddItemsToInvoice);

router.post(
  "/FIFOcreateTemporyInvoice",
  authenticateToken,
  FIFOcreateTemporyInvoice,
);

router.post(
  "/manualaddItemsToInvoice",
  authenticateToken,
  manualaddItemsToInvoice,
);

router.post("/getbatchDetails", authenticateToken, getbatchDetails);

router.post("/getmanualbatchDetails", authenticateToken, getmanualbatchDetails);

router.get("/getDraftInvoice", authenticateToken, getDraftInvoice);

router.get("/getHoldInvoice", authenticateToken, getHoldInvoice);

router.post(
  "/deleteiItemsFromInvoice",
  authenticateToken,
  deleteiItemsFromInvoice,
);

router.post(
  "/updateiItemsFromInvoice",
  authenticateToken,
  updateiItemsFromInvoice,
);

router.post("/draftToHoldInvoice", authenticateToken, draftToHoldInvoice);

router.post("/discardInvoice", authenticateToken, discardInvoice);

router.post("/holdtoDraftInvoice", authenticateToken, holdtoDraftInvoice);

router.post("/saveCookistillid", authenticateToken, saveCookistillid);

router.post('/releaseTill', authenticateToken, releaseTill);

router.get("/getCookistillid", getCookistillid)

router.post("/createInvoice_id", authenticateToken, CreateInvoiceID)





// common api with no security
router.get("/getsystemSettingsDisplay",  getsystemSettingsDisplay);

router.get("/welcome",  getwelcome);

module.exports = router;
