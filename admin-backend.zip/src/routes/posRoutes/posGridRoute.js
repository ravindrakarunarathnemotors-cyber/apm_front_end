const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const {fetchCategories, fetchProducts, fetchTables, saveTableForInvoice, selectTableInvoice, sendToKitchen, getKitchenHistory,getPendingKitchenOrders, completeKitchenOrders, processKitchenOrders, completeAllKitchenInvoice, getfindkitchen, updateInvoiceKitchen, addInvoiceItemNote} = require("../../controllers/pos/posGridController")


router.get("/fetchCategories", authenticateToken, fetchCategories);

router.post("/fetchProducts", authenticateToken, fetchProducts);

router.get("/fetchTables", authenticateToken, fetchTables);

router.post("/saveTableForInvoice", authenticateToken, saveTableForInvoice);

router.post("/selectTableInvoice", authenticateToken, selectTableInvoice);

router.post("/sendToKitchen", authenticateToken, sendToKitchen);

router.get("/getKitchenHistory",  getKitchenHistory);

router.get("/getPendingKitchenOrders",  getPendingKitchenOrders);

router.post("/completeKitchenOrders",  completeKitchenOrders);

router.post("/processKitchenOrders",  processKitchenOrders);

router.post("/completeAllKitchenInvoice",  completeAllKitchenInvoice);

router.post("/getfindkitchen",  getfindkitchen);

router.post("/updateInvoiceKitchen",  updateInvoiceKitchen);

router.post("/addInvoiceItemNote",  addInvoiceItemNote);

module.exports = router;