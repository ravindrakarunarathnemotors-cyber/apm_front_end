const express = require("express");
const router = express.Router();

router.use("/", require("./posRoutes"));

router.use("/", require("./posDiscountRoute"));

router.use("/", require("./posOtherRoute"));

router.use("/", require("./posReportRouter"));

router.use("/", require("./posGridRoute"));

module.exports = router;
