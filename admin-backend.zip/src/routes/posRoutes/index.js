const express = require("express");
const router = express.Router();

router.use("/", require("./posRoutes"));

router.use("/", require("./posDiscountRoute"));

router.use("/", require("./posOtherRoute"));

router.use("/", require("./posReportRouter"));

router.use("/", require("./posGridRoute"));

router.use("/", require("./posNewRoutes"));

module.exports = router;
