const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const { getVoucherById } = require("../../controllers/pos/posNewController");

router.get("/voucher/:voucherId", authenticateToken, getVoucherById);

module.exports = router;
