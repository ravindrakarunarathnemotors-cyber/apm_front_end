const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const {  getAllCustomer, saveCustomer, savepayments, getCardTypes, getTerminal, getoneToken, getoneVoucher, getCustomerPoint, completeInvoice, savesales, getTill, newCustomer, ReprintInvoiceDeatils, getSalesPersons, getoneCustomer, getOneInvoice, getAllAccount, resetDeviceInfo} = require("../../controllers/pos/posotherController");



router.post("/getAllCustomer", authenticateToken, getAllCustomer)

router.post("/saveCustomer", authenticateToken, saveCustomer)

router.post("/savepayments",  savepayments)

router.get("/getCardTypes", authenticateToken, getCardTypes)

router.get("/getTerminal", authenticateToken, getTerminal)

router.post("/getoneToken", authenticateToken, getoneToken)

router.post("/getoneVoucher", authenticateToken, getoneVoucher)

router.post("/getCustomerPoint", authenticateToken, getCustomerPoint)

router.post("/completeInvoice", authenticateToken, completeInvoice)

router.post("/savesales", authenticateToken, savesales)

router.get("/getTill", authenticateToken, getTill)

router.post("/newCustomer", authenticateToken, newCustomer)

router.post("/ReprintInvoiceDeatils", authenticateToken, ReprintInvoiceDeatils)

router.get("/getSalesPersons", authenticateToken, getSalesPersons)

router.post("/getoneCustomer", getoneCustomer)

router.post("/getOneInvoice",  getOneInvoice)

router.get("/getAllAccount", authenticateToken, getAllAccount)

router.post("/resetDeviceInfo", authenticateToken, resetDeviceInfo)




module.exports = router;