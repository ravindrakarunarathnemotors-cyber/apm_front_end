const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const { autodiscountCheck, autodpmethoddiscountCheck, autodbuyxdiscountCheck, addProductautodiscountCheck, addProductbuyxdiscountCheck  } = require("../../controllers/pos/PosDiscountController");


router.post("/autodiscountcheck", authenticateToken, autodiscountCheck)

router.post("/autodpmethoddiscount", authenticateToken, autodpmethoddiscountCheck)

router.post("/autodbuyxdiscount", authenticateToken, autodbuyxdiscountCheck)

router.post("/addProductautodiscountCheck", authenticateToken, addProductautodiscountCheck)

router.post("/addProductbuyxdiscountCheck", authenticateToken, addProductbuyxdiscountCheck)

module.exports = router;