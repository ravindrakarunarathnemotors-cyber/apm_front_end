const express = require("express");
const router = express.Router();
const authenticateToken = require("../../middleware/authMiddleware");
const { getDailyCashierReport, getSalesSummaryReport, getAllTillId  } = require("../../controllers/pos/posReportController");

router.get("/getDailyCashierReport/:tillId", authenticateToken, getDailyCashierReport);

router.post("/getSalesSummaryReport", authenticateToken, getSalesSummaryReport);

router.get("/getAllTillId", authenticateToken, getAllTillId);



module.exports = router;