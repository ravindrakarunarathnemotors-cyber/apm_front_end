const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");
const { insertNotification } = require("../../models/notificationsUpdater");
const multer = require("multer");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { addLoyalty } = require("../../models/commonModels");
require("dotenv").config();

/**
 * CREATE DEVICE (TILL / DISPLAY)
 */
router.post("/create-device", authenticateToken, async (req, res) => {
  const {
    till_name,
    display_id,
    device_model,
    type,
    enable_customer_input, // may be true / false / undefined
  } = req.body;

  const user_id = req.user?.user_id || null;

  /* ===== BASIC VALIDATION ===== */
  if (!till_name || !type) {
    return res.status(400).json({
      success: false,
      message: "Required fields are missing",
    });
  }

  if (!Array.isArray(display_id)) {
    return res.status(400).json({
      success: false,
      message: "display_id must be an array",
    });
  }

  if (
    enable_customer_input !== undefined &&
    typeof enable_customer_input !== "boolean"
  ) {
    return res.status(400).json({
      success: false,
      message: "enable_customer_input must be a boolean",
    });
  }

  try {
    const insertQuery = `
      INSERT INTO device_management (
        till_name,
        display_id,
        device_model,
        type,
        enable_customer_input,
        current_user_id
      )
      VALUES ($1, $2::jsonb, $3, $4, $5, $6)
      RETURNING *
    `;

    const insertValues = [
      till_name,
      JSON.stringify(display_id), // JSONB array
      device_model || null,
      type,
      enable_customer_input ?? null, // STORE ONLY WHAT IS SENT
      user_id,
    ];

    const { rows } = await pool.query(insertQuery, insertValues);
    const createdDevice = rows[0];

    /* ===== FIRE & FORGET (NON-BLOCKING) ===== */
    setImmediate(async () => {
      try {
        await insertAdminLog(
          user_id,
          "Device Management",
          `User ${user_id} created ${type.toUpperCase()} "${till_name}" (Device ID: ${createdDevice.device_id})`,
        );

        await insertNotification(
          user_id,
          "Device Management",
          "Device Created",
          `New ${type} "${till_name}" has been created successfully.`,
          "Website Notification",
          "Unread",
        );
      } catch (err) {
        console.error("Async log/notification error:", err);
      }
    });

    return res.status(201).json({
      success: true,
      message: "Device created successfully",
      data: createdDevice,
    });
  } catch (error) {
    console.error("CREATE DEVICE ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// fetch devices

router.get("/fetch-devices", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT
        type,
        json_agg(
          json_build_object(
            'device_id', device_id,
            'till_name', till_name,
            'status', status,
            'display_id', display_id,
            'device_model', device_model,
            'enable_customer_input', enable_customer_input,
            'created_at', created_at,
            'updated_at', updated_at
          )
          ORDER BY created_at DESC
        ) AS devices
      FROM device_management
      GROUP BY type
    `;

    const { rows } = await pool.query(query);

    // Normalize result into object
    const groupedDevices = rows.reduce((acc, row) => {
      acc[row.type] = row.devices;
      return acc;
    }, {});

    return res.json({
      success: true,
      data: groupedDevices,
    });
  } catch (error) {
    console.error("FETCH DEVICES ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// UPDATE DEVICE STATUS (ACTIVE / INACTIVE)

router.post("/update-device-status", authenticateToken, async (req, res) => {
  const { device_id, status } = req.body;

  const user_id = req.user?.user_id || null;

  if (!device_id || !status) {
    return res.status(400).json({
      success: false,
      message: "device_id and status are required",
    });
  }

  if (!["Active", "Inactive"].includes(status)) {
    return res.status(400).json({
      success: false,
      message: "Invalid status value",
    });
  }

  try {
    const updateQuery = `
      UPDATE device_management
      SET status = $1,
          updated_at = NOW()
      WHERE device_id = $2
      RETURNING *
    `;

    const { rows } = await pool.query(updateQuery, [status, device_id]);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Device not found",
      });
    }

    const updatedDevice = rows[0];

    /*  FIRE & FORGET — ADMIN LOG ONLY */
    setImmediate(async () => {
      try {
        await insertAdminLog(
          user_id,
          "Device Management",
          `User ${user_id} set device "${updatedDevice.till_name}" (ID: ${device_id}) to ${status}`,
        );
      } catch (err) {
        console.error("Async admin log error:", err);
      }
    });

    return res.json({
      success: true,
      message: `Device status updated to ${status}`,
      data: updatedDevice,
    });
  } catch (error) {
    console.error("UPDATE DEVICE STATUS ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// update device / edit route

/**
 * UPDATE DEVICE (TILL / DISPLAY)
 */
router.put("/update-device/:device_id", authenticateToken, async (req, res) => {
  const { device_id } = req.params;
  const {
    till_name,
    display_id,
    device_model,
    type,
    enable_customer_input, // ✅ NEW
  } = req.body;

  const user_id = req.user?.user_id || null;

  if (!device_id) {
    return res.status(400).json({
      success: false,
      message: "Device ID is required",
    });
  }

  /* ================= BUILD DYNAMIC UPDATE ================= */

  const fields = [];
  const values = [];
  let index = 1;

  if (till_name !== undefined) {
    fields.push(`till_name = $${index++}`);
    values.push(till_name);
  }

  if (Array.isArray(display_id)) {
    fields.push(`display_id = $${index++}::jsonb`);
    values.push(JSON.stringify(display_id));
  }

  if (device_model !== undefined) {
    fields.push(`device_model = $${index++}`);
    values.push(device_model);
  }

  if (type !== undefined) {
    fields.push(`type = $${index++}`);
    values.push(type);
  }

  // ✅ ADD THIS BLOCK (no logic change elsewhere)
  if (enable_customer_input !== undefined) {
    fields.push(`enable_customer_input = $${index++}`);
    values.push(enable_customer_input);
  }

  if (fields.length === 0) {
    return res.status(400).json({
      success: false,
      message: "No fields provided to update",
    });
  }

  // always update timestamp
  fields.push(`updated_at = NOW()`);

  const updateQuery = `
      UPDATE device_management
      SET ${fields.join(", ")}
      WHERE device_id = $${index}
      RETURNING *
    `;

  values.push(device_id);

  try {
    const { rows } = await pool.query(updateQuery, values);

    if (!rows.length) {
      return res.status(404).json({
        success: false,
        message: "Device not found",
      });
    }

    const updatedDevice = rows[0];

    /* ============ FIRE & FORGET LOG ============ */
    setImmediate(async () => {
      try {
        await insertAdminLog(
          user_id,
          "Device Management",
          `User ${user_id} updated ${updatedDevice.type.toUpperCase()} "${updatedDevice.till_name}" (Device ID: ${device_id})`,
        );
      } catch (err) {
        console.error("Admin log error:", err);
      }
    });

    return res.json({
      success: true,
      message: "Device updated successfully",
      data: updatedDevice,
    });
  } catch (error) {
    console.error("UPDATE DEVICE ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// get active devices by type

router.get("/active-devices-by-type", authenticateToken, async (req, res) => {
  try {
    const query = `
        SELECT 
          type,
          device_id,
          till_name
        FROM device_management
        WHERE status = 'Active'
        ORDER BY type, till_name
      `;

    const { rows } = await pool.query(query);

    // normalize response
    const result = {
      till: [],
      display: [],
      kot_display: [],
      kot_printer: [],
    };

    rows.forEach((row) => {
      if (row.type === "till") {
        result.till.push({
          device_id: row.device_id,
          till_name: row.till_name,
        });
      }

      if (row.type === "display") {
        result.display.push({
          device_id: row.device_id,
          till_name: row.till_name,
        });
      }
       if (row.type === "kot_display") {
        result.kot_display.push({
          device_id: row.device_id,
          till_name: row.till_name,
        });
      }

      if (row.type === "kot_printer") {
        result.kot_printer.push({
          device_id: row.device_id,
          till_name: row.till_name,
        });
      }

    });

    return res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("FETCH ACTIVE DEVICES ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});
 
// POS Device Banner Uploader

/* ================= MULTER ================= */
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 50 },
  fileFilter: (req, file, cb) => {
    const allowed = ["image/png", "image/jpeg", "image/jpg", "video/mp4"];

    if (!allowed.includes(file.mimetype)) {
      return cb(
        new Error("Only JPG, JPEG, PNG images and MP4 videos are allowed"),
        false,
      );
    }
    cb(null, true);
  },
});

/* ================= S3 ================= */
const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
});

const PUBLIC_URL_PREFIX = process.env.CONVERT_S3_URL;

/* ================= UPLOAD ROUTE ================= */
/**
 * POST /pos-sub/upload-device-banners
 * body:
 *  - device_id
 * files:
 *  - files[]
 */
const { uploadToS3 } = require("../FileUploader/file_uploader"); // adjust path if needed

router.post(
  "/upload-device-banners",
  upload.array("files", 50),
  async (req, res) => {
    const { device_id } = req.body;
    const files = req.files;

    if (!device_id) {
      return res.status(400).json({
        success: false,
        message: "device_id is required",
      });
    }

    if (!files || files.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one file is required",
      });
    }

    try {
      const results = await uploadToS3({
        files,
        folderPath: `POS_FILES/${device_id}`, // ✅ per-device isolation
        useDate: false, // keep original behavior
      });

      // 🔁 Match your original response format exactly
      const uploadedMedia = results.map((r) => ({
        url: r.url,
        type: r.type === "video" ? "video" : "image",
      }));

      return res.status(200).json({
        success: true,
        message: "POS banner upload successful",
        data: uploadedMedia,
      });

    } catch (error) {
      console.error("POS BANNER UPLOAD ERROR:", error);

      return res.status(500).json({
        success: false,
        message: "File upload failed",
      });
    }
  }
);

// fetch active device banners
router.get("/active-device-banners", async (req, res) => {
  try {
    const query = `
        SELECT
          device_id,
          type,
          display_id,
          enable_customer_input,
          banner_files
        FROM device_management
        WHERE status = 'Active'
      `;

    const { rows } = await pool.query(query);

    const result = {
      till: [],
      display: [],
    };

    rows.forEach((row) => {
      if (row.type === "till") {
        result.till.push({
          device_id: row.device_id,
          assigned_display: row.display_id, // 👈 renamed
          enable_customer_input: row.enable_customer_input,
        });
      }

      if (row.type === "display") {
        result.display.push({
          device_id: row.device_id,
          assigned_till: row.display_id, // 👈 renamed
          enable_customer_input: row.enable_customer_input,
          banner_files: row.banner_files || [],
        });
      }
    });

    return res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("FETCH ACTIVE DEVICE BANNERS ERROR:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// save banner to the device

router.put("/add-banner-files", async (req, res) => {
  const { device_id, files } = req.body;

  if (!device_id) {
    return res.status(400).json({
      success: false,
      message: "device_id is required",
    });
  }

  if (!Array.isArray(files)) {
    return res.status(400).json({
      success: false,
      message: "files must be an array",
    });
  }

  try {
    const query = `
      UPDATE device_management
      SET banner_files = $1::jsonb,
          updated_at = NOW()
      WHERE device_id = $2
      RETURNING device_id, banner_files;
    `;

    const values = [JSON.stringify(files), device_id];

    const { rows } = await pool.query(query, values);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Device not found",
      });
    }

    return res.json({
      success: true,
      message: "Banner files updated successfully",
      data: rows[0],
    });
  } catch (error) {
    console.error("Banner update error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// fetch banners on modal

// GET DISPLAY BANNERS (device_id + banner_files)

router.get("/display-banners", authenticateToken, async (req, res) => {
  const { device_id } = req.query;

  if (!device_id) {
    return res.status(400).json({
      success: false,
      message: "device_id is required",
    });
  }

  try {
    const query = `
        SELECT
          device_id,
          banner_files
        FROM device_management
        WHERE type = 'display'
          AND device_id = $1
        LIMIT 1
      `;

    const { rows } = await pool.query(query, [device_id]);

    if (!rows.length) {
      return res.status(404).json({
        success: false,
        message: "Display not found",
      });
    }

    return res.json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("FETCH DISPLAY BANNERS ERROR:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// pos return token routes
// --------------------------------------------------------------------------
router.post("/invoice-items-search", authenticateToken, async (req, res) => {
  try {
    let { invoice_id } = req.body;

    /*
      DEFENSIVE HANDLING
      ------------------
      Frontend might send:
      - invoice_id: 100
      - invoice_id: "100"
      - invoice_id: { billNo: "100", items: [...] }
    */

    // If invoice_id is an object, extract billNo
    if (typeof invoice_id === "object" && invoice_id !== null) {
      invoice_id = invoice_id.billNo;
    }

    // Convert to number
    invoice_id = Number(invoice_id);

    if (!invoice_id || Number.isNaN(invoice_id)) {
      return res.status(400).json({
        success: false,
        message: "Valid invoice_id is required",
      });
    }

    const query = `
      SELECT
        idt.id,
        idt.invoice_id,
        idt.product_id,
        idt.variant_id,
        idt.quantity,
        idt.unit_price,
        idt.discount,
        idt.free_quantity,
        idt.total_price,
        idt.amount_per_unit,
        idt.batch_no,
        idt.return_qty,


        -- product + variant names (correct schema)
        COALESCE(p.title, idt.name) AS product_title,
        pv.variant_value

      FROM invoice_details idt

      LEFT JOIN products p
        ON p.product_id = idt.product_id

      LEFT JOIN product_variants pv
        ON pv.variant_id = idt.variant_id

      WHERE idt.invoice_id = $1
      ORDER BY idt.id ASC
    `;

    const { rows } = await pool.query(query, [invoice_id]);

    return res.status(200).json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("Fetch invoice items error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// return token creation - invoice

router.post("/return-invoice-token", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    // ✅ SAFELY RESOLVE USER ID
    const user_id = req.user?.id ?? req.user?.user_id ?? req.user?.uid ?? null;

    const { merchant_id, outlet_id } = req.user;

    if (!user_id) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: user not found",
      });
    }

    if (!outlet_id) {
      return res.status(400).json({
        success: false,
        message: "Outlet context missing from token",
      });
    }

    const { old_invoice_id, items } = req.body;

    if (!old_invoice_id || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid payload",
      });
    }

    await client.query("BEGIN");

    let totalReturnAmount = 0;
    let totalReturnQty = 0;
    const returnedItemsDetailed = [];

    /* -------------------------------------------
     * USER CONTEXT (FOR INVENTORY COMMENT)
     * ------------------------------------------- */
    const userRes = await client.query(
      `
      SELECT u.username, u.first_name, u.last_name, r.role_name
      FROM users u
      LEFT JOIN role_list r ON r.id = u.role_id
      WHERE u.user_id = $1
      `,
      [user_id],
    );

    const { username, first_name, last_name, role_name } =
      userRes.rows[0] || {};

    const displayName =
      [first_name, last_name].filter(Boolean).join(" ") || "Unknown User";

    /* -------------------------------------------
     * PROCESS RETURN ITEMS (ORIGINAL LOGIC + UPDATED STOCK)
     * ------------------------------------------- */
    for (const row of items) {
      const { invoice_detail_id, return_qty } = row;

      if (!invoice_detail_id || Number(return_qty) <= 0) continue;

      // 1️⃣ Lock invoice detail row
      const detailRes = await client.query(
        `
        SELECT
          quantity,
          total_price,
          COALESCE(return_qty, 0) AS return_qty,
          variant_id,
          product_id,
          batch_no
        FROM invoice_details
        WHERE id = $1
        FOR UPDATE
        `,
        [invoice_detail_id],
      );

      if (detailRes.rowCount === 0) {
        throw new Error(`Invoice detail not found: ${invoice_detail_id}`);
      }

      const detail = detailRes.rows[0];

      const soldQty = Number(detail.quantity);
      const prevReturned = Number(detail.return_qty);
      const newReturned = prevReturned + Number(return_qty);

      if (newReturned > soldQty) {
        throw new Error(
          `Return qty exceeds sold qty for invoice_detail_id ${invoice_detail_id}`,
        );
      }

      const unitPrice = Number(detail.total_price) / soldQty;
      const lineReturnAmount = unitPrice * Number(return_qty);

      totalReturnAmount += lineReturnAmount;
      totalReturnQty += Number(return_qty);

      // 2️⃣ Update invoice_details return_qty (UNCHANGED)
      await client.query(
        `
        UPDATE invoice_details
        SET return_qty = $1
        WHERE id = $2
        `,
        [newReturned, invoice_detail_id],
      );

      /* -------------------------------------------
       * FETCH amount_per_unit FROM PRODUCTS
       * ------------------------------------------- */
      const productRes = await client.query(
        `
        SELECT amount_per_unit
        FROM products
        WHERE product_id = $1
        `,
        [detail.product_id],
      );

      if (productRes.rowCount === 0) {
        throw new Error(
          `Product not found for product_id ${detail.product_id}`,
        );
      }

      const amount_per_unit = Number(productRes.rows[0].amount_per_unit ?? 0);

      /* -------------------------------------------
       * STOCK BACK IN (amount based)
       * ------------------------------------------- */
      const variant_id = detail.variant_id;
      const batch_number = detail.batch_no || null;

      // ✅ KEY CHANGE
      const adjust_quantity = Number(return_qty) * amount_per_unit;

      let prevQtyQuery = `
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = $1
          AND outlet_id = $2
          AND merchant_id = $3
          AND status = 'active'
      `;

      const params = [variant_id, outlet_id, merchant_id];

      if (batch_number) {
        prevQtyQuery += ` AND batch_number = $4`;
        params.push(batch_number);
      }

      prevQtyQuery += `
        ORDER BY last_updated DESC NULLS LAST, inventory_id DESC
        LIMIT 1
      `;

      const prevQtyRes = await client.query(prevQtyQuery, params);

      const previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity ?? 0);

      const new_quantity = previous_quantity + adjust_quantity;
      const system_module = "stock in";

      const commentRaw = `${displayName} | ${role_name || "Role"} | v:${variant_id} | invoice return stock in`;
      const comment =
        commentRaw.length > 250 ? commentRaw.slice(0, 250) : commentRaw;

      await client.query(
        `
        INSERT INTO inventory (
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          status
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')
        `,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          username,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
        ],
      );

      /* INVENTORY ADMIN LOG (ADDED) */
      await insertAdminLog(
        user_id,
        "Inventory",
        `INVOICE RETURN STOCK IN | Variant ${variant_id} | Qty +${adjust_quantity} (return_qty ${return_qty} × ${amount_per_unit}) | Prev ${previous_quantity} → New ${new_quantity} | Outlet ${outlet_id}${batch_number ? ` | Batch ${batch_number}` : ""
        }`,
      );

      /* Collect detailed returned_items */
      returnedItemsDetailed.push({
        invoice_detail_id,
        variant_id,
        product_id: detail.product_id,
        return_qty: Number(return_qty),
        amount_per_unit,
        stock_in_amount: adjust_quantity,
        batch_number,
        outlet_id,
        previous_quantity,
        new_quantity,
      });
    }

    /* -------------------------------------------
     * INSERT RETURN TOKEN (WITH returned_items)
     * ------------------------------------------- */
    const tokenRes = await client.query(
      `
      INSERT INTO return_token (
        date,
        by,
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        returned_items,
        status
      )
      VALUES (
        NOW(),
        $1,
        $2,
        $3,
        0,
        '[]'::jsonb,
        $4::jsonb,
        'active'
      )
      RETURNING id
      `,
      [
        user_id,
        totalReturnAmount,
        old_invoice_id,
        JSON.stringify(returnedItemsDetailed),
      ],
    );

    const returnTokenId = tokenRes.rows[0].id;

    /* POS ADMIN LOG (UNCHANGED) */
    await insertAdminLog(
      user_id,
      "POS",
      `Returned invoice ${old_invoice_id} | Qty: ${totalReturnQty} | Amount: LKR ${totalReturnAmount.toFixed(
        2,
      )} | Token ID: ${returnTokenId}`,
    );

    await client.query("COMMIT");

    return res.status(200).json({
      success: true,
      message: "Return processed successfully",
      data: {
        return_token_id: returnTokenId,
        total_return_qty: totalReturnQty,
        total_return_amount: totalReturnAmount,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Return invoice error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});

router.post("/return-invoice-token_transfer_points", authenticateToken, async (req, res) => {
  const client = await pool.connect();


  try {
    // ✅ SAFELY RESOLVE USER ID
    const user_id = req.user?.id ?? req.user?.user_id ?? req.user?.uid ?? null;

    const { merchant_id, outlet_id } = req.user;

    if (!user_id) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: user not found",
      });
    }

    if (!outlet_id) {
      return res.status(400).json({
        success: false,
        message: "Outlet context missing from token",
      });
    }

    const { old_invoice_id, items, selectedCustomer } = req.body;

    if (!old_invoice_id || !Array.isArray(items) || items.length === 0 || !selectedCustomer) {
      return res.status(400).json({
        success: false,
        message: "Invalid payload",
      });
    }

    await client.query("BEGIN");

    let totalReturnAmount = 0;
    let totalReturnQty = 0;
    const returnedItemsDetailed = [];

    /* -------------------------------------------
     * USER CONTEXT (FOR INVENTORY COMMENT)
     * ------------------------------------------- */
    const userRes = await client.query(
      `
      SELECT u.username, u.first_name, u.last_name, r.role_name
      FROM users u
      LEFT JOIN role_list r ON r.id = u.role_id
      WHERE u.user_id = $1
      `,
      [user_id],
    );

    const { username, first_name, last_name, role_name } =
      userRes.rows[0] || {};

    const displayName =
      [first_name, last_name].filter(Boolean).join(" ") || "Unknown User";

    /* -------------------------------------------
     * PROCESS RETURN ITEMS (ORIGINAL LOGIC + UPDATED STOCK)
     * ------------------------------------------- */
    for (const row of items) {
      const { invoice_detail_id, return_qty } = row;

      if (!invoice_detail_id || Number(return_qty) <= 0) continue;

      // 1️⃣ Lock invoice detail row
      const detailRes = await client.query(
        `
        SELECT
          quantity,
          total_price,
          COALESCE(return_qty, 0) AS return_qty,
          variant_id,
          product_id,
          batch_no
        FROM invoice_details
        WHERE id = $1
        FOR UPDATE
        `,
        [invoice_detail_id],
      );

      if (detailRes.rowCount === 0) {
        throw new Error(`Invoice detail not found: ${invoice_detail_id}`);
      }

      const detail = detailRes.rows[0];

      const soldQty = Number(detail.quantity);
      const prevReturned = Number(detail.return_qty);
      const newReturned = prevReturned + Number(return_qty);

      if (newReturned > soldQty) {
        throw new Error(
          `Return qty exceeds sold qty for invoice_detail_id ${invoice_detail_id}`,
        );
      }

      const unitPrice = Number(detail.total_price) / soldQty;
      const lineReturnAmount = unitPrice * Number(return_qty);

      totalReturnAmount += lineReturnAmount;
      totalReturnQty += Number(return_qty);

      // 2️⃣ Update invoice_details return_qty (UNCHANGED)
      await client.query(
        `
        UPDATE invoice_details
        SET return_qty = $1
        WHERE id = $2
        `,
        [newReturned, invoice_detail_id],
      );

      /* -------------------------------------------
       * FETCH amount_per_unit FROM PRODUCTS
       * ------------------------------------------- */
      const productRes = await client.query(
        `
        SELECT amount_per_unit
        FROM products
        WHERE product_id = $1
        `,
        [detail.product_id],
      );

      if (productRes.rowCount === 0) {
        throw new Error(
          `Product not found for product_id ${detail.product_id}`,
        );
      }

      const amount_per_unit = Number(productRes.rows[0].amount_per_unit ?? 0);

      /* -------------------------------------------
       * STOCK BACK IN (amount based)
       * ------------------------------------------- */
      const variant_id = detail.variant_id;
      const batch_number = detail.batch_no || null;

      // ✅ KEY CHANGE
      const adjust_quantity = Number(return_qty) * amount_per_unit;

      let prevQtyQuery = `
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = $1
          AND outlet_id = $2
          AND merchant_id = $3
          AND status = 'active'
      `;

      const params = [variant_id, outlet_id, merchant_id];

      if (batch_number) {
        prevQtyQuery += ` AND batch_number = $4`;
        params.push(batch_number);
      }

      prevQtyQuery += `
        ORDER BY last_updated DESC NULLS LAST, inventory_id DESC
        LIMIT 1
      `;

      const prevQtyRes = await client.query(prevQtyQuery, params);

      const previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity ?? 0);

      const new_quantity = previous_quantity + adjust_quantity;
      const system_module = "stock in";

      const commentRaw = `${displayName} | ${role_name || "Role"} | v:${variant_id} | invoice return stock in`;
      const comment =
        commentRaw.length > 250 ? commentRaw.slice(0, 250) : commentRaw;

      await client.query(
        `
        INSERT INTO inventory (
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          status
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')
        `,
        [
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          username,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
        ],
      );

      /* INVENTORY ADMIN LOG (ADDED) */
      await insertAdminLog(
        user_id,
        "Inventory",
        `INVOICE RETURN STOCK IN | Variant ${variant_id} | Qty +${adjust_quantity} (return_qty ${return_qty} × ${amount_per_unit}) | Prev ${previous_quantity} → New ${new_quantity} | Outlet ${outlet_id}${batch_number ? ` | Batch ${batch_number}` : ""
        }`,
      );

      /* Collect detailed returned_items */
      returnedItemsDetailed.push({
        invoice_detail_id,
        variant_id,
        product_id: detail.product_id,
        return_qty: Number(return_qty),
        amount_per_unit,
        stock_in_amount: adjust_quantity,
        batch_number,
        outlet_id,
        previous_quantity,
        new_quantity,
      });
    }

    /* -------------------------------------------
     * INSERT RETURN TOKEN (WITH returned_items)
     * ------------------------------------------- */
    const tokenRes = await client.query(
      `
      INSERT INTO return_token (
        date,
        by,
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        returned_items,
        status,
        comment,
        type
      )
      VALUES (
        NOW(),
        $1,
        $2,
        $3,
        $6,
        '[]'::jsonb,
        $4::jsonb,
        'active',
        $5,
        'points'
      )
      RETURNING id
      `,
      [
        user_id,
        totalReturnAmount,
        old_invoice_id,
        JSON.stringify(returnedItemsDetailed),
        `Returned invoice ${old_invoice_id} for customer ${selectedCustomer.id} with transfer amount LKR ${totalReturnAmount.toFixed(2)}`,
        totalReturnAmount
      ],
    );

    if (tokenRes.rowCount === 0) {
      throw new Error("Failed to insert return token");
    }

    const returnTokenId = tokenRes.rows[0].id;

    /* POS ADMIN LOG (UNCHANGED) */
    const [logsAdminResult, loyaltyResult] = await Promise.all([
      insertAdminLog(
        user_id,
        "POS",
        `Returned invoice ${old_invoice_id} | Qty: ${totalReturnQty} | Amount: LKR ${totalReturnAmount.toFixed(
          2,
        )} | Token ID: ${returnTokenId}`,
      ),
      addLoyalty(selectedCustomer.id, totalReturnAmount, `Returned invoice ${old_invoice_id} for customer ${selectedCustomer.id} with transfer amount LKR ${totalReturnAmount.toFixed(2)}`)
    ])


    await client.query("COMMIT");

    return res.status(200).json({
      success: true,
      message: "Return processed successfully",
      data: {
        return_token_id: returnTokenId,
        total_return_qty: totalReturnQty,
        total_return_amount: totalReturnAmount,
      },
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Return invoice error:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Internal server error",
    });
  } finally {
    client.release();
  }
});

// created invoice token fetch (active ones with currency + pagination)

router.get("/return-tokens-fetch", authenticateToken, async (req, res) => {
  try {
    const limit = Number(req.query.limit) || 10;
    const todayPage = Number(req.query.todayPage) || 1;
    const pastPage = Number(req.query.pastPage) || 1;

    const todayOffset = (todayPage - 1) * limit;
    const pastOffset = (pastPage - 1) * limit;

    /* ---------------- GET CURRENCY ---------------- */
    const settingsResult = await pool.query(`
      SELECT currency
      FROM system_settings
      LIMIT 1
    `);

    const currency = settingsResult.rows[0]?.currency || "LKR";

    /* ---------------- TODAY TOKENS ---------------- */
    const todayQuery = `
      SELECT
        id,
        date,
        "by",
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        status
      FROM return_token
      WHERE
        status = 'active'
        AND DATE(date) = CURRENT_DATE
      ORDER BY date DESC
      LIMIT $1 OFFSET $2
    `;

    const todayCountQuery = `
      SELECT COUNT(*)::int AS count
      FROM return_token
      WHERE
        status = 'active'
        AND DATE(date) = CURRENT_DATE
    `;

    /* ---------------- PAST TOKENS ---------------- */
    const pastQuery = `
      SELECT
        id,
        date,
        "by",
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        status
      FROM return_token
      WHERE
        status = 'active'
        AND DATE(date) <> CURRENT_DATE
      ORDER BY date DESC
      LIMIT $1 OFFSET $2
    `;

    const pastCountQuery = `
      SELECT COUNT(*)::int AS count
      FROM return_token
      WHERE
        status = 'active'
        AND DATE(date) <> CURRENT_DATE
    `;

    const [todayResult, todayCountResult, pastResult, pastCountResult] =
      await Promise.all([
        pool.query(todayQuery, [limit, todayOffset]),
        pool.query(todayCountQuery),
        pool.query(pastQuery, [limit, pastOffset]),
        pool.query(pastCountQuery),
      ]);

    return res.status(200).json({
      success: true,
      currency,
      data: {
        today: {
          rows: todayResult.rows,
          page: todayPage,
          limit,
          total: todayCountResult.rows[0].count,
          totalPages: Math.ceil(todayCountResult.rows[0].count / limit),
        },
        past: {
          rows: pastResult.rows,
          page: pastPage,
          limit,
          total: pastCountResult.rows[0].count,
          totalPages: Math.ceil(pastCountResult.rows[0].count / limit),
        },
      },
    });
  } catch (error) {
    console.error("Fetch active return tokens error:", error);

    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
});

// item return token search
// GET /return-token-item-search?query=VARIANT_ID
router.get("/return-token-item-search", authenticateToken, async (req, res) => {
  const { query } = req.query;

  if (!query || !query.trim()) {
    return res.status(400).json({ message: "Variant ID is required." });
  }

  const { merchant_id } = req.user;
  const variantId = query.trim();

  try {
    /* --------------------------------------------------
     * 1️⃣ Fetch product + variant by VARIANT ID ONLY
     * -------------------------------------------------- */
    const searchQuery = `
        SELECT
          p.product_id,
          p.title AS product_title,
          p.description,

          /* product price (fallback) */
          p.price AS product_price,

          /* variant */
          pv.variant_id,
          pv.variant_value,
          pv.price AS variant_price,
          pv.sku,
          pv.barcode,

          /* measurement */
          p.measurement_id,
          m.measurement_value,

          /* currency (GLOBAL) */
          (SELECT currency FROM system_settings LIMIT 1) AS currency

        FROM product_variants pv
        INNER JOIN products p
          ON p.product_id = pv.product_id
         AND p.status = 'active'
         AND p.merchant_id = $1

        LEFT JOIN measurements m
          ON p.measurement_id = m.measurement_id

        WHERE pv.status = 'active'
          AND pv.variant_id::text = $2

        LIMIT 1
      `;

    const { rows } = await pool.query(searchQuery, [merchant_id, variantId]);

    if (!rows.length) {
      return res.status(404).json({ message: "Variant not found." });
    }

    const variant = rows[0];

    /* --------------------------------------------------
     * 2️⃣ Fetch UNIQUE active batches WITH prices
     * -------------------------------------------------- */
    const batchQuery = `
        SELECT DISTINCT
          batch_number,
          cost_price,
          selling_price
        FROM batch_management
        WHERE status = 'active'
          AND variant_id = $1
        ORDER BY batch_number
      `;

    const batchRes = await pool.query(batchQuery, [variant.variant_id]);

    const batches = batchRes.rows.map((b) => ({
      batch_number: b.batch_number,
      cost_price: Number(b.cost_price),
      selling_price: Number(b.selling_price),
    }));

    /* --------------------------------------------------
     * 3️⃣ Final response
     * -------------------------------------------------- */
    return res.json({
      success: true,
      result: {
        ...variant,
        batches, // ✅ [{ batch_number, cost_price, selling_price }]
      },
    });
  } catch (error) {
    console.error("Return token item search error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// return items token creation

router.post(
  "/return-items-token-create",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const { amount, returned_items } = req.body;
      const { user_id, merchant_id, outlet_id } = req.user;

      console.log("payload is : ", req.body);

      if (!outlet_id) {
        return res.status(400).json({
          message: "Outlet context missing from token",
        });
      }

      if (!Array.isArray(returned_items) || returned_items.length === 0) {
        return res.status(400).json({
          message: "returned_items is required and must be a non-empty array",
        });
      }

      await client.query("BEGIN");

      /* -------------------------------------------
       * INSERT RETURN TOKEN (UNCHANGED)
       * ------------------------------------------- */
      const insertQuery = `
      INSERT INTO return_token (
        by,
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        returned_items,
        status,
        date
      )
      VALUES (
        $1,
        $2,
        NULL,
        0,
        '[]'::jsonb,
        $3::jsonb,
        'active',
        NOW()
      )
      RETURNING id
    `;

      const insertRes = await client.query(insertQuery, [
        user_id,
        amount,
        JSON.stringify(returned_items),
      ]);

      const returnTokenId = insertRes.rows[0].id;

      /* -------------------------------------------
       * USER CONTEXT (FOR LOGS)
       * ------------------------------------------- */
      const userRes = await client.query(
        `
      SELECT u.username, u.first_name, u.last_name, r.role_name
      FROM users u
      LEFT JOIN role_list r ON r.id = u.role_id
      WHERE u.user_id = $1
      `,
        [user_id],
      );

      const { username, first_name, last_name, role_name } =
        userRes.rows[0] || {};

      const displayName =
        [first_name, last_name].filter(Boolean).join(" ") || "Unknown User";

      /* -------------------------------------------
       * STOCK BACK IN (UPDATED: amount_per_unit AWARE)
       * ------------------------------------------- */
      for (const item of returned_items) {
        const { variant_id, return_qty, batch_number = null } = item;

        if (
          !variant_id ||
          !Number.isInteger(Number(return_qty)) ||
          Number(return_qty) <= 0
        ) {
          throw new Error(
            "Each returned item must have variant_id and positive return_qty",
          );
        }

        /* --------- Fetch variant → product --------- */
        const variantRes = await client.query(
          `
        SELECT product_id
        FROM product_variants
        WHERE variant_id = $1
        `,
          [variant_id],
        );

        if (variantRes.rowCount === 0) {
          throw new Error(`Variant ${variant_id} not found`);
        }

        const { product_id } = variantRes.rows[0];

        /* --------- Fetch amount_per_unit (optional) --------- */
        const productRes = await client.query(
          `
        SELECT amount_per_unit
        FROM products
        WHERE product_id = $1
        `,
          [product_id],
        );

        const amount_per_unit = Number(
          productRes.rows[0]?.amount_per_unit ?? 0,
        );

        // ✅ ONLY CHANGE HERE
        const adjust_quantity =
          amount_per_unit > 0
            ? Number(return_qty) * amount_per_unit
            : Number(return_qty);

        /* --------- Fetch previous stock --------- */
        let prevQtyQuery = `
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = $1
          AND outlet_id = $2
          AND merchant_id = $3
          AND status = 'active'
      `;

        const params = [variant_id, outlet_id, merchant_id];

        if (batch_number) {
          prevQtyQuery += ` AND batch_number = $4`;
          params.push(batch_number);
        }

        prevQtyQuery += `
        ORDER BY last_updated DESC NULLS LAST, inventory_id DESC
        LIMIT 1
      `;

        const prevQtyRes = await client.query(prevQtyQuery, params);

        const previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity ?? 0);

        const new_quantity = previous_quantity + adjust_quantity;

        /* --------- Inventory insert (STOCK IN) --------- */
        const system_module = "stock in";

        const commentRaw = `${displayName} | ${role_name || "Role"} | v:${variant_id} | return stock in`;
        const comment =
          commentRaw.length > 250 ? commentRaw.slice(0, 250) : commentRaw;

        await client.query(
          `
        INSERT INTO inventory (
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          status
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')
        `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            username,
            comment,
            system_module,
            previous_quantity,
            adjust_quantity,
            new_quantity,
          ],
        );

        /* --------- ADMIN LOG (STOCK IN DETAIL) --------- */
        await insertAdminLog(
          user_id,
          "Inventory",
          `RETURN STOCK IN | Variant ${variant_id} | Qty +${adjust_quantity}${amount_per_unit > 0
            ? ` (return_qty ${return_qty} × ${amount_per_unit})`
            : ""
          } | Prev ${previous_quantity} → New ${new_quantity} | Outlet ${outlet_id}${batch_number ? ` | Batch ${batch_number}` : ""
          }`,
        );
      }

      /* -------------------------------------------
       * ORIGINAL ADMIN LOG (UNCHANGED)
       * ------------------------------------------- */
      await insertAdminLog(
        user_id,
        "POS",
        `Created return token ID ${returnTokenId} with amount ${amount}`,
      );

      await client.query("COMMIT");

      return res.status(201).json({
        message: "Return token created and stock updated successfully",
        return_token_id: returnTokenId,
      });
    } catch (error) {
      await client.query("ROLLBACK");
      console.error("Create return token error:", error);

      return res.status(500).json({
        message: error.message || "Failed to create return token",
      });
    } finally {
      client.release();
    }
  },
);


router.post(
  "/return-items-token-Transfer",
  authenticateToken,
  async (req, res) => {
    const client = await pool.connect();

    try {
      const { amount, returned_items, selectedCustomer } = req.body;
      const { user_id, merchant_id, outlet_id } = req.user;

      console.log("payload is : ", req.body);

      if (!outlet_id) {
        return res.status(400).json({
          message: "Outlet context missing from token",
        });
      }

      if (!Array.isArray(returned_items) || returned_items.length === 0 || !selectedCustomer) {
        return res.status(400).json({
          message: "returned_items is required and must be a non-empty array",
        });
      }

      await client.query("BEGIN");

      /* -------------------------------------------
       * INSERT RETURN TOKEN (UNCHANGED)
       * ------------------------------------------- */
      const insertQuery = `
      INSERT INTO return_token (
        by,
        amount,
        old_inv_id,
        used_amount,
        used_inv_id,
        returned_items,
        status,
        date,
        comment,
        type
      )
      VALUES (
        $1,
        $2,
        NULL,
        $4,
        '[]'::jsonb,
        $3::jsonb,
        'active',
        NOW(),
        $5,
        'points'
      )
      RETURNING id
    `;

      const insertRes = await client.query(insertQuery, [
        user_id,
        amount,
        JSON.stringify(returned_items),
        amount,
        `Returned item for customer ${selectedCustomer.id} with transfer amount LKR ${Number(amount).toFixed(2)}`,
      ]);

      const returnTokenId = insertRes.rows[0].id;

      /* -------------------------------------------
       * USER CONTEXT (FOR LOGS)
       * ------------------------------------------- */
      const userRes = await client.query(
        `
      SELECT u.username, u.first_name, u.last_name, r.role_name
      FROM users u
      LEFT JOIN role_list r ON r.id = u.role_id
      WHERE u.user_id = $1
      `,
        [user_id],
      );

      const { username, first_name, last_name, role_name } =
        userRes.rows[0] || {};

      const displayName =
        [first_name, last_name].filter(Boolean).join(" ") || "Unknown User";

      /* -------------------------------------------
       * STOCK BACK IN (UPDATED: amount_per_unit AWARE)
       * ------------------------------------------- */
      for (const item of returned_items) {
        const { variant_id, return_qty, batch_number = null } = item;

        if (
          !variant_id ||
          !Number.isInteger(Number(return_qty)) ||
          Number(return_qty) <= 0
        ) {
          throw new Error(
            "Each returned item must have variant_id and positive return_qty",
          );
        }

        /* --------- Fetch variant → product --------- */
        const variantRes = await client.query(
          `
        SELECT product_id
        FROM product_variants
        WHERE variant_id = $1
        `,
          [variant_id],
        );

        if (variantRes.rowCount === 0) {
          throw new Error(`Variant ${variant_id} not found`);
        }

        const { product_id } = variantRes.rows[0];

        /* --------- Fetch amount_per_unit (optional) --------- */
        const productRes = await client.query(
          `
        SELECT amount_per_unit
        FROM products
        WHERE product_id = $1
        `,
          [product_id],
        );

        const amount_per_unit = Number(
          productRes.rows[0]?.amount_per_unit ?? 0,
        );

        // ✅ ONLY CHANGE HERE
        const adjust_quantity =
          amount_per_unit > 0
            ? Number(return_qty) * amount_per_unit
            : Number(return_qty);

        /* --------- Fetch previous stock --------- */
        let prevQtyQuery = `
        SELECT new_quantity
        FROM inventory
        WHERE variant_id = $1
          AND outlet_id = $2
          AND merchant_id = $3
          AND status = 'active'
      `;

        const params = [variant_id, outlet_id, merchant_id];

        if (batch_number) {
          prevQtyQuery += ` AND batch_number = $4`;
          params.push(batch_number);
        }

        prevQtyQuery += `
        ORDER BY last_updated DESC NULLS LAST, inventory_id DESC
        LIMIT 1
      `;

        const prevQtyRes = await client.query(prevQtyQuery, params);

        const previous_quantity = Number(prevQtyRes.rows[0]?.new_quantity ?? 0);

        const new_quantity = previous_quantity + adjust_quantity;

        /* --------- Inventory insert (STOCK IN) --------- */
        const system_module = "stock in";

        const commentRaw = `${displayName} | ${role_name || "Role"} | v:${variant_id} | return stock in`;
        const comment =
          commentRaw.length > 250 ? commentRaw.slice(0, 250) : commentRaw;

        await client.query(
          `
        INSERT INTO inventory (
          variant_id,
          outlet_id,
          merchant_id,
          user_id,
          batch_number,
          updated_by,
          comment,
          system_module,
          previous_quantity,
          adjust_quantity,
          new_quantity,
          status
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'active')
        `,
          [
            variant_id,
            outlet_id,
            merchant_id,
            user_id,
            batch_number,
            username,
            comment,
            system_module,
            previous_quantity,
            adjust_quantity,
            new_quantity,
          ],
        );

        /* --------- ADMIN LOG (STOCK IN DETAIL) --------- */
        await insertAdminLog(
          user_id,
          "Inventory",
          `RETURN STOCK IN | Variant ${variant_id} | Qty +${adjust_quantity}${amount_per_unit > 0
            ? ` (return_qty ${return_qty} × ${amount_per_unit})`
            : ""
          } | Prev ${previous_quantity} → New ${new_quantity} | Outlet ${outlet_id}${batch_number ? ` | Batch ${batch_number}` : ""
          }`,
        );
      }

      /* -------------------------------------------
       * ORIGINAL ADMIN LOG (UNCHANGED)
       * ------------------------------------------- */

      const [logsAdminResult, loyaltyResult] = await Promise.all([
        await insertAdminLog(
          user_id,
          "POS",
          `Created return token ID ${returnTokenId} with amount ${amount}`,
        ),
        addLoyalty(selectedCustomer.id, amount, `Returned item for customer ${selectedCustomer.id} with transfer amount LKR ${Number(amount).toFixed(2)}`)
      ])

      await client.query("COMMIT");

      return res.status(201).json({
        message: "Return token created and stock updated successfully",
        return_token_id: returnTokenId,
      });
    } catch (error) {
      await client.query("ROLLBACK");
      console.error("Create return token error:", error);

      return res.status(500).json({
        message: error.message || "Failed to create return token",
      });
    } finally {
      client.release();
    }
  },
);

// pos settings media uploader

router.post('/upload-media', upload.array('files', 50), async (req, res) => {

  const files = req.files

  if (!files || files.length === 0) {
    return res.status(400).json({
      success: false,
      message: 'At least one file is required',
    })
  }

  try {
    /* ================= PARALLEL UPLOAD ================= */

    const uploadPromises = files.map((file) => {
      const timestamp = Date.now()
      const cleanName = file.originalname.replace(/\s+/g, '_')

      // Generic path (no device dependency)
      const key = `POS_FILES/${timestamp}-${cleanName}`

      const params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'public-read',
      }

      return s3.send(new PutObjectCommand(params)).then(() => ({
        url: `${PUBLIC_URL_PREFIX}/${key}`,
        type: file.mimetype.startsWith('video') ? 'video' : 'image',
        name: cleanName,
        size: file.size,
      }))
    })

    // 🚀 Upload ALL files concurrently
    const uploadedMedia = await Promise.all(uploadPromises)

    return res.status(200).json({
      success: true,
      message: 'Media upload successful',
      data: uploadedMedia,
    })
  } catch (error) {
    console.error('MEDIA UPLOAD ERROR:', error)

    return res.status(500).json({
      success: false,
      message: 'File upload failed',
    })
  }
}
)
router.post("/card-terminal", authenticateToken, async (req, res) => {
  const { account_id, account_name, ip, mac_address, name, outlet_id, status } = req.body;

  const user_id = req.user?.user_id || null;
  try {

    const query = `
      INSERT INTO public.card_terminal
      (mac_address, ip, name, account_name, account_id, status, outlet_id)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *;
    `;

    const values = [
      mac_address,
      ip,
      name,
      account_name,
      account_id,
      status,
      outlet_id
    ];
    const result = await pool.query(query, values);
    const terminal = result.rows[0];
    await insertAdminLog(
      user_id,
      "CARD TERMINAL",
      `Created card terminal ${terminal.name} (ID ${terminal.id}) with IP ${terminal.ip}`
    );

    res.status(201).json({
      message: "Card terminal created successfully",
      data: terminal
    });

  } catch (error) {
    console.error("Insert error:", error);
    res.status(500).json({
      error: "Failed to insert card terminal"
    });
  }
});

router.post("/getallcard-terminal", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      keyword,
      status
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    if (keyword) {
      const trimmedKeyword = keyword.trim();
      queryParams.push(`%${trimmedKeyword}%`);

      whereConditions.push(`
        (
          t.name ILIKE $${queryParams.length}
          OR t.id::text ILIKE $${queryParams.length}
        )
      `);
    }


    if (status) {
      queryParams.push(status);
      whereConditions.push(`t.status = $${queryParams.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const tableQuery = `
      SELECT
        t.id,
        t.name,
        t.account_name,
        t.outlet_id,
        t.mac_address,
        o.name AS outlet_name,
        t.status
      FROM card_terminal t
      LEFT JOIN outlets o ON t.outlet_id = o.outlet_id
      ${whereClause}
      ORDER BY t.id DESC
      LIMIT $${queryParams.length + 1}
      OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(tableQuery, paginatedParams);

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM card_terminal t
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    res.json({
      restaurant_tables: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });

  } catch (err) {
    console.error("Error fetching restaurant tables:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/card_terminalnames", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT name FROM card_terminal WHERE name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.put('/toggle-card_terminstatus/:id', authenticateToken, async (req, res) => {
  const { id } = req.params
  const { status } = req.body
  const user_id = req.user.user_id

  const client = await pool.connect()

  try {
    if (!id || !status) {
      return res.status(400).json({ success: false, message: 'ID and status required' })
    }

    await client.query('BEGIN')

    const existing = await client.query(
      `SELECT name, status FROM card_terminal WHERE id = $1`,
      [id]
    )

    if (existing.rowCount === 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ success: false, message: 'Table not found' })
    }

    const { name, status: oldStatus } = existing.rows[0]

    const result = await client.query(
      `UPDATE card_terminal SET status = $1 WHERE id = $2 RETURNING id, status`,
      [status, id]
    )

    await client.query('COMMIT')

    await insertAdminLog(
      user_id,
      'Card_terminal',
      `Changed Status Table (#${id}) - ${name} from ${oldStatus} to ${status}`
    )

    return res.json({
      success: true,
      message: 'Card Terminal table status updated',
      data: result.rows[0],
    })

  } catch (error) {
    await client.query('ROLLBACK')
    console.error(error)
    return res.status(500).json({ success: false, message: 'Internal server error' })
  } finally {
    client.release()
  }
})


module.exports = router;
