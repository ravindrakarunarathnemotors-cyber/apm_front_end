// routes/admin-categories.js
router.get('/categories/with-count', async (req, res) => {
  try {
    // If multi-tenant: const merchantId = req.user.merchant_id
    const q = `
      SELECT
        c.category_id,
        c.name,
        COALESCE(COUNT(p.product_id), 0) AS product_count,
        (c.name || ' (' || COALESCE(COUNT(p.product_id), 0) || ')') AS name_with_count
      FROM categories c
      LEFT JOIN product_category pc ON pc.category_id = c.category_id
      LEFT JOIN products p ON p.product_id = pc.product_id AND p.status = 'active'
      WHERE c.status = 'active'
      GROUP BY c.category_id, c.name
      ORDER BY product_count DESC, c.name ASC;
    `;
    const { rows } = await pool.query(q);
    return res.json(rows); // <-- array, not rows[0]
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'Internal server error' });
  }
});
