const express = require("express");
const { login, register } = require("../controllers/AuthController");
const router = express.Router();
const jwt = require("jsonwebtoken");

// router.post("/login", login);

// router.post("/register", register);

router.post("/refresh-token", async (req, res) => {
  const refreshToken = req.cookies.refresh_token;

  // No refresh token
  if (!refreshToken) {
    return res.status(401).json({
      message: "Refresh token required",
    });
  }

  jwt.verify(
    refreshToken,
    process.env.REFRESH_TOKEN_SECRET,
    (err, user) => {
      // Invalid or expired refresh token
      if (err) {
        return res.status(403).json({
          message: "Invalid refresh token",
        });
      }

      // Generate new access token
      const newAccessToken = jwt.sign(
        {
          user_id: user.user_id,
          role_id: user.role_id,
          merchant_id: user.merchant_id,
          outlet_id: user.outlet_id,
        },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: "5m" }
      );

      // 🔥 Set new access token cookie
      res.cookie("access_token", newAccessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "none",
        maxAge: 5 * 60 * 1000, // 5 minutes
      });

      return res.status(200).json({
        message: "Access token refreshed",
      });
    }
  );
});

router.post('/logout', (req, res) => {

  res.clearCookie('access_token', {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
  })

  res.clearCookie('refresh_token', {
    httpOnly: true,
    secure: true,
    sameSite: 'strict',
  })

  return res.status(200).json({
    message: 'Logged out successfully'
  })
})

module.exports = router;
