const express = require("express");
const { login, register } = require("../controllers/AuthController");
const router = express.Router();
const jwt = require("jsonwebtoken");

// router.post("/login", login);

// router.post("/register", register);

router.post("/refresh-token", async (req, res) => {
  const { refresh_token } = req.body;

  if (!refresh_token)
    return res.status(401).json({ message: "Refresh token required" });

  jwt.verify(refresh_token, process.env.REFRESH_TOKEN_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: "Invalid refresh token" });

    // Generate a new access token
    const newAccessToken = jwt.sign(
      {
        user_id: user.user_id,
        role_id: user.role_id,
        merchant_id: user.merchant_id,
        outlet_id: user.outlet_id,
      },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: "24h" }
    );

    res.json({ access_token: newAccessToken });
  });
});

module.exports = router;
