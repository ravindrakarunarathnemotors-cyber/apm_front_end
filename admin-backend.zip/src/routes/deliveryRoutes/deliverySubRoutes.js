const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

// GET active delivery partners
router.get("/active-delivery-partners",authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT name, partner_id
      FROM delivery_partners
      WHERE status = 'active'
    `;
    const result = await pool.query(query);
    res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching active delivery partners:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// fetch orders by partners with tracking ids
router.post("/partner-order-details",authenticateToken, async (req, res) => {
  const { partner_id } = req.body;

  if (!partner_id) {
    return res
      .status(400)
      .json({ error: "partner_id is required." });
  }

  try {
    const query = `
      SELECT 
        o.order_id,
        o.created_at,
        o.recipient_city,
        o.tracking_id,
        o.order_status,
        o.customer_id,
        o.cod,
        o.total_value,
        o.currency,
        c.first_name AS customer_first_name,
        c.last_name AS customer_last_name,
        dp.name AS partner_name
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      WHERE o.order_status = 'processing'
        AND o.delivery_partner_id = $1
          AND o.tracking_id IS NOT NULL
      ORDER BY o.created_at DESC
    `;

    const result = await pool.query(query, [partner_id]);
    return res.status(200).json(result.rows);
  } catch (error) {
    console.error("Error fetching orders by partner:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});


// generate the bulk dispatched orders

router.post("/generate-bulk-dispatch",authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const { partner_id, order_ids } = req.body;
    const user = req.user
  const user_id = user.user_id// Replace with req.user?.user_id

    if (!Array.isArray(order_ids) || order_ids.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "No order IDs provided." });
    }

    // Step 1: Insert into bulk_dispatched_history
    const insertHistoryQuery = `
      INSERT INTO bulk_dispatched_history (generated_by, order_count, partner_id)
      VALUES ($1, $2, $3)
      RETURNING bulk_id
    `;
    const { rows: historyRows } = await client.query(insertHistoryQuery, [
      user_id,
      order_ids.length,
      partner_id,
    ]);
    const bulk_id = historyRows[0].bulk_id;

    // Step 2: Update orders with bulk_dispatched_id and status
    const updateOrdersQuery = `
      UPDATE orders
      SET 
        bulk_dispatched_id = $1,
        order_status = 'dispatched'
      WHERE order_id = ANY($2::int[])
    `;
    const updateResult = await client.query(updateOrdersQuery, [
      bulk_id,
      order_ids,
    ]);

    // Optional: Confirm that all orders were updated
    if (updateResult.rowCount !== order_ids.length) {
      throw new Error("Mismatch in updated order count. Rolling back.");
    }

    // Step 3: Fetch final order details
    const fetchOrderDetailsQuery = `
      SELECT 
        o.order_id AS id,
        dp.name AS courier_partner,
        o.recipient_city,
        o.order_status,
        o.tracking_id,
        o.created_at
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      WHERE o.order_id = ANY($1::int[])
    `;
    const { rows: orderData } = await client.query(fetchOrderDetailsQuery, [
      order_ids,
    ]);

    await client.query("COMMIT");

    res.status(200).json({
      success: true,
      bulk_id,
      order_count: order_ids.length,
      orders: orderData,
      message: `${order_ids.length} orders marked as dispatched and grouped.`,
    });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("🔴 Error in /generate-bulk-dispatch:", err);
    res
      .status(500)
      .json({ success: false, message: "Failed to generate bulk dispatch." });
  } finally {
    client.release();
  }
});


// bulk dispatched history table fetch

router.get("/bulk-dispatched-history",authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 25;
    const offset = (page - 1) * limit;

    const client = await pool.connect();

    try {
      const bulkQuery = `
        SELECT 
          bdh.*, 
          u.first_name, 
          u.last_name,
          dp.name AS partner_name
        FROM bulk_dispatched_history bdh
        LEFT JOIN users u ON bdh.generated_by = u.user_id
        LEFT JOIN delivery_partners dp ON bdh.partner_id = dp.partner_id
        ORDER BY bdh.generated_at DESC
        LIMIT $1 OFFSET $2
      `;

      const countQuery = `SELECT COUNT(*) FROM bulk_dispatched_history`;

      const [bulkResult, countResult] = await Promise.all([
        client.query(bulkQuery, [limit, offset]),
        client.query(countQuery),
      ]);

      const totalCount = parseInt(countResult.rows[0].count);

      res.status(200).json({
        data: bulkResult.rows,
        page,
        totalPages: Math.ceil(totalCount / limit),
        totalItems: totalCount,
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Error fetching bulk dispatched history:", error);
    res.status(500).json({ message: "Server error fetching dispatch history." });
  }
});


// fetch print dispatched orders list for bulk id

router.post('/orders-by-bulk',authenticateToken, async (req, res) => {
  const { bulk_id } = req.body;


  if (!bulk_id) {
    return res.status(400).json({ success: false, message: 'bulk_id is required.' });
  }

  try {
    // Step 1: Get the bulk dispatch record (optional, for verification/logging)
    const bulkQuery = 'SELECT * FROM bulk_dispatched_history WHERE bulk_id = $1';
    const bulkResult = await pool.query(bulkQuery, [bulk_id]);

    if (bulkResult.rowCount === 0) {
      return res.status(404).json({ success: false, message: 'Bulk dispatch not found.' });
    }

    // Step 2: Get brand logo from branding_settings (assuming single row config)
    const brandingQuery = 'SELECT logo_url_white FROM branding_settings LIMIT 1';
    const brandingResult = await pool.query(brandingQuery);
    const brand_logo = brandingResult.rows[0]?.logo_url_white || null;

    // Step 3: Get orders joined with delivery_partners
    const ordersQuery = `
      SELECT 
        o.order_id,
        o.tracking_id,
        dp.logo AS partner_logo
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      WHERE o.bulk_dispatched_id = $1
    `;

    const ordersResult = await pool.query(ordersQuery, [bulk_id]);

    const orders = ordersResult.rows.map(order => ({
      order_id: order.order_id,
      tracking_id: order.tracking_id,
      partner_logo: order.partner_logo,
      // brand_logo: brand_logo
    }));
//updated
    return res.json({
      success: true,
      bulk_id,
      brand_logo,
      orders
    });
  } catch (err) {
    console.error('Error fetching orders by bulk:', err);
    return res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post("/deliveryFee", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);

    if (isNaN(parsedLimit) || isNaN(parsedPage)) {
      return res.status(400).json({ error: "Invalid pagination parameters" });
    }

    const offset = (parsedPage - 1) * parsedLimit;

    // --- Delivery Fee Fetch ---
    let queryParams = [];
    let whereConditions = [];

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    const deliveryFeeQuery = `
      SELECT 
        df.*,
        c.country_name,
        ss.currency AS currency
      FROM delivery_fee df
      LEFT JOIN countries c ON c.id = df.country_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY df.id DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(deliveryFeeQuery, paginatedParams);

    // --- Count Query ---
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM delivery_fee df
      LEFT JOIN countries c ON c.id = df.country_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
    `;
    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // --- Fetch sell_international from system_settings ---
    const settingsQuery = `SELECT sell_international FROM system_settings LIMIT 1`;
    const settingsResult = await pool.query(settingsQuery);
    const sell_international = settingsResult.rows[0]?.sell_international ?? false;

    // --- Final Response ---
    res.json({
      fees: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
      sell_international
    });

  } catch (err) {
    console.error("Error fetching delivery fees:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.put("/updatedeliveryFee", authenticateToken, async (req, res) => {
  try {
    const { id, fee, additional_fee } = req.body;

    if (!id || typeof fee !== "number" || typeof additional_fee !== "number") {
      return res.status(400).json({ error: "Invalid input data" });
    }

    const updateQuery = `
      UPDATE delivery_fee
      SET fee = $1,
          additional_fee = $2
      WHERE id = $3
      RETURNING *
    `;

    const { rows } = await pool.query(updateQuery, [fee, additional_fee, id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: "Delivery fee record not found" });
    }

    res.status(200).json({ message: "Delivery fee updated successfully", data: rows[0] });
  } catch (err) {
    console.error("Error updating delivery fee:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch('/deliveryFeestatus', authenticateToken, async (req, res) => {
  const { id, status } = req.body

  if (!id || !['active', 'inactive'].includes(status)) {
    return res.status(400).json({ error: 'Invalid input' })
  }

  try {
    const updateQuery = `
      UPDATE delivery_fee
      SET status = $1
      WHERE id = $2
      RETURNING *
    `

    const result = await pool.query(updateQuery, [status, id])

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Delivery fee not found' })
    }

    res.status(200).json({ message: 'Status updated successfully', data: result.rows[0] })
  } catch (err) {
    console.error('Error updating status:', err)
    res.status(500).json({ error: 'Internal server error' })
  }
})


router.get("/country", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT id, country_name FROM countries WHERE status = 'active' AND country_name ILIKE $1 ORDER BY country_name ASC LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});


router.post('/insertdeliveryfee', authenticateToken, async (req, res) => {
  const { country_name, fee, additional_fee } = req.body
   try {
  
    const checkQuery = 'SELECT country_id FROM delivery_fee WHERE country_id = $1'
    const checkResult = await pool.query(checkQuery, [country_name])

    if (checkResult.rowCount > 0) {
      return res.status(409).json({ message: 'Delivery fee already exists for this country.' })
    }

    const insertQuery = `
      INSERT INTO delivery_fee (country_id, fee, additional_fee)
      VALUES ($1, $2, $3)
      RETURNING *
    `

    const result = await pool.query(insertQuery, [country_name, fee, additional_fee])

    res.status(201).json({ message: 'Delivery fee added', data: result.rows[0] })
  } catch (error) {
    console.error('Error inserting delivery fee:', error)
    res.status(500).json({ message: 'Internal Server Error' })
  }
})

router.post("/add-delivery-partner", authenticateToken, async (req, res) => {
  const { name, title, description, tracking_url, logo } = req.body;

  try {
    const query = `
      INSERT INTO delivery_partners 
      (name, title, description, tracking_url, logo, status, api_status)
      VALUES ($1, $2, $3, $4, $5, 'active', 'disable')
      RETURNING *;
    `;

    const values = [
      name,
      title || '',
      description || '',
      tracking_url || '',
      logo || null, 
    ];

    const result = await pool.query(query, values);

    console.log(" New Partner Inserted:", result.rows[0]);

    return res.status(201).json({
      message: "Delivery partner added successfully",
      partner: result.rows[0],
    });

  } catch (error) {
    console.error("Error inserting partner:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});













module.exports = router;
