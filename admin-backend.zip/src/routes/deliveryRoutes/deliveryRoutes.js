const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog, insertSystemLog } = require("../../models/userLogs");

router.post("/orderdetails-bulkprint", authenticateToken, async (req, res) => {
  try {
    const {
      order_id,
      recipient_name,
      mobile,
      date,
      from_time,
      to_time,
      page = 1,
      limit = 25,
    } = req.body;

    // const { merchant_id } = req.user;
    const merchant_id = 20001;
    if (!merchant_id) {
      return res
        .status(400)
        .json({ error: "Merchant ID is missing from token." });
    }

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [merchant_id];
    let whereConditions = [
      `o.merchant_id = $1`,
      `o.order_status = 'processing'`,
    ];

    if (order_id) {
      queryParams.push(order_id);
      whereConditions.push(`o.order_id = $${queryParams.length}`);
    }

    if (recipient_name) {
      queryParams.push(`%${recipient_name}%`);
      whereConditions.push(`o.recipient_name ILIKE $${queryParams.length}`);
    }

    if (mobile) {
      queryParams.push(mobile);
      whereConditions.push(`o.recipient_contact = $${queryParams.length}`);
    }

    if (from_time && to_time) {
      queryParams.push(from_time);
      queryParams.push(to_time);
      whereConditions.push(
        `o.created_at BETWEEN $${queryParams.length - 1} AND $${
          queryParams.length
        }`
      );
    } else if (date) {
      queryParams.push(date);
      whereConditions.push(`o.created_at::date = $${queryParams.length}`);
    }

    const whereClause = `WHERE ${whereConditions.join(" AND ")}`;

    const fetchQuery = `
      SELECT
        o.order_id,
        o.order_status,
        o.total_value,
        o.amount_paid AS discount,
        o.delivery_fee,
        o.total_weight,
        o.currency,
        o.recipient_contact,
        o.recipient_email,
        o.recipient_name,
        o.recipient_address,
        o.recipient_postal_code,
        o.recipient_city,
        o.recipient_country,
        o.payment_status,
        o.cod,
        o.tracking_id,
        dp.logo AS partner_logo,
        dp.contact_number AS partner_contact,
        cu.customer_id,
        cu.first_name,
        cu.last_name,
        cu.contact_number_1,
        cu.contact_number_2,
        cu.address,
        cu.city,
        cu.postal_code,
        cu.apartment,
        cu.country AS customer_country,
        cu.email,
        w.waybill
      FROM orders o
      INNER JOIN customer cu ON o.customer_id = cu.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN waybills w ON o.order_id = w.order_id
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      INNER JOIN customer cu ON o.customer_id = cu.customer_id
      ${whereClause};
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];

    const [dataResult, countResult] = await Promise.all([
      pool.query(fetchQuery, paginatedParams),
      pool.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    const formatted = dataResult.rows.map((order) => ({
      order_details: {
        order_id: order.order_id,
        order_status: order.order_status,
        total_value: order.total_value,
        discount: order.discount,
        delivery_fee: order.delivery_fee,
        total_weight: order.total_weight,
        currency: order.currency,
        payment_status: order.payment_status,
        cod: order.cod,
        tracking_id: order.tracking_id,
        waybill: order.waybill,
        delivery_partner_logo: order.partner_logo,
        delivery_partner_contact: order.partner_contact,
      },
      recipient_contact_info: {
        contact: order.recipient_contact,
        email: order.recipient_email,
      },
      recipient_address: {
        name: order.recipient_name,
        address: order.recipient_address,
        postal_code: order.recipient_postal_code,
        city: order.recipient_city,
        country: order.recipient_country,
      },
      customer_address: {
        customer_id: order.customer_id,
        name: `${order.first_name} ${order.last_name}`,
        contact_number_1: order.contact_number_1,
        contact_number_2: order.contact_number_2,
        address: order.address,
        apartment: order.apartment,
        city: order.city,
        postal_code: order.postal_code,
        country: order.customer_country,
        email: order.email,
      },
    }));

    return res.json({
      success: true,
      orders: formatted,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (error) {
    console.error("Error fetching processing order details:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// fetch / get bulk prints history

// 📦 GET paginated bulk print history
router.get("/bulk-generated-history", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 25;
    const offset = (page - 1) * limit;

    const client = await pool.connect();

    try {
      const bulkQuery = `
        SELECT obp.*, u.first_name, u.last_name
        FROM order_bulk_prints obp
        LEFT JOIN users u ON obp.generated_by = u.user_id
        ORDER BY obp.generated_at DESC
        LIMIT $1 OFFSET $2
      `;

      const countQuery = `SELECT COUNT(*) FROM order_bulk_prints`;

      const [bulkResult, countResult] = await Promise.all([
        client.query(bulkQuery, [limit, offset]),
        client.query(countQuery),
      ]);

      const totalCount = parseInt(countResult.rows[0].count);

      res.status(200).json({
        data: bulkResult.rows,
        page,
        totalPages: Math.ceil(totalCount / limit),
        totalItems: totalCount,
      });
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("Error fetching order bulk prints:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// generate order bulk print

router.post("/generate-bulk-print", authenticateToken, async (req, res) => {
  const client = await pool.connect();

  try {
    // pull user_id from token
    const user_id = req.user?.user_id;
    if (!user_id) {
      return res
        .status(401)
        .json({ success: false, message: "Unauthorized: missing user id" });
    }

    await client.query("BEGIN"); // 🚀 Start transaction

    // Step 1: Find all eligible orders
    const fetchOrdersQuery = `
      SELECT order_id
      FROM orders
      WHERE order_status NOT IN ('pending', 'cancelled') AND bulk_id IS NULL
    `;
    const { rows: eligibleOrders } = await client.query(fetchOrdersQuery);
    const orderCount = eligibleOrders.length;

    if (orderCount === 0) {
      await client.query("ROLLBACK"); // Clean exit

      // Log: no eligible orders
      try {
        await insertSystemLog(
          user_id,
          "Bulk Print",
          "No eligible orders to include in bulk print."
        );
      } catch (e) {
        console.error("[SystemLog] failed (no-eligible):", e);
      }

      return res.status(200).json({
        success: true,
        message: "No eligible orders to include in bulk print.",
      });
    }

    // Step 2: Insert into order_bulk_prints
    const insertBulkPrintQuery = `
      INSERT INTO order_bulk_prints (generated_by, order_count)
      VALUES ($1, $2)
      RETURNING bulk_id
    `;
    const { rows: bulkInsertResult } = await client.query(
      insertBulkPrintQuery,
      [user_id, orderCount]
    );
    const bulk_id = bulkInsertResult[0].bulk_id;

    // Step 3: Update orders with the new bulk_id
    const orderIds = eligibleOrders.map((o) => o.order_id);
    const updateOrdersQuery = `
      UPDATE orders
      SET bulk_id = $1
      WHERE order_id = ANY($2::int[])
    `;
    await client.query(updateOrdersQuery, [bulk_id, orderIds]);

    // Step 4: Fetch full order data to return
    const fetchOrderDetailsQuery = `
      SELECT 
        o.order_id AS id,
        dp.name AS courier_partner,
        c.first_name || ' ' || c.last_name AS client,
        o.order_status AS status,
        o.tracking_id AS tracking,
        o.delivery_type AS courier_type,
        o.created_at AS created_at 
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      WHERE o.bulk_id = $1
    `;
    const { rows: finalOrderData } = await client.query(
      fetchOrderDetailsQuery,
      [bulk_id]
    );

    await client.query("COMMIT"); // ✅ Success — persist all changes

    // Build concise log message (cap IDs to avoid huge logs)
    const MAX_IDS = 50;
    const idsForLog = orderIds.slice(0, MAX_IDS).join(", ");
    const moreNote =
      orderIds.length > MAX_IDS ? `, +${orderIds.length - MAX_IDS} more` : "";
    const logMsg = `Bulk Print generated with Bulk ID ${bulk_id}. Total ${orderCount} orders assigned (Order IDs: ${idsForLog}${moreNote}).`;

    // Write system log OUTSIDE the transaction (uses pool, separate connection)
    try {
      await insertSystemLog(user_id, "Bulk Print", logMsg);
      // Optionally also admin log if you want:
      // await insertAdminLog(user_id, 'Bulk Print', logMsg);
    } catch (e) {
      console.error("[SystemLog] failed (success path):", e);
    }

    return res.status(200).json({
      success: true,
      bulk_id,
      order_count: orderCount,
      orders: finalOrderData,
      message: `${orderCount} orders added to bulk print batch.`,
    });
  } catch (err) {
    // Log the failure (best effort, outside txn)
    try {
      const user_id = req.user?.user_id ?? null;
      await insertSystemLog(
        user_id,
        "Bulk Print",
        `Error generating bulk print: ${err.message}`
      );
    } catch (e) {
      console.error("[SystemLog] failed (error path):", e);
    }

    try {
      await client.query("ROLLBACK"); // ❌ Rollback all changes
    } catch (rbErr) {
      console.error("Rollback failed:", rbErr);
    }

    console.error("Error generating bulk print:", err);
    return res
      .status(500)
      .json({ success: false, message: "Server error generating bulk print." });
  } finally {
    client.release(); // 🔚 Always release client
  }
});

// fetch the latest bulk
router.get("/latest-bulk-print", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    // Get latest bulk print record with user details who generated it
    const latestBulkQuery = await client.query(`
      SELECT obp.*, u.first_name, u.last_name
      FROM order_bulk_prints obp
      LEFT JOIN users u ON obp.generated_by = u.user_id
      ORDER BY obp.generated_at DESC
      LIMIT 1
    `);

    if (latestBulkQuery.rows.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "No bulk print records found." });
    }

    const bulk = latestBulkQuery.rows[0];

    // Fetch orders in that bulk_id
    const fetchOrderDetailsQuery = `
      SELECT 
        o.order_id AS id,
        dp.name AS courier_partner,
        c.first_name || ' ' || c.last_name AS client,
        o.order_status AS status,
        o.tracking_id AS tracking,
        o.delivery_type AS courier_type,
        o.created_at
      FROM orders o
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      WHERE o.bulk_id = $1
      ORDER BY o.created_at DESC
    `;

    const { rows: finalOrderData } = await client.query(
      fetchOrderDetailsQuery,
      [bulk.bulk_id]
    );

    if (finalOrderData.length === 0) {
      console.warn(`⚠️ No orders found with bulk_id = ${bulk.bulk_id}`);
    }

    return res.status(200).json({
      success: true,
      bulk_id: bulk.bulk_id,
      order_count: finalOrderData.length,
      orders: finalOrderData,
      first_name: bulk.first_name || "Client",
      last_name: bulk.last_name || "",
      generated_at: bulk.generated_at,
      message: `${finalOrderData.length} orders added to bulk print batch.`,
    });
  } catch (error) {
    console.error("Error fetching latest bulk print:", error);
    return res.status(500).json({ success: false, message: "Server error." });
  } finally {
    client.release();
  }
});

// bulk print order details fetch
router.post("/bulk-labels-by-id", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const { bulk_id } = req.body;
    const merchant_id = 20001;

    if (!bulk_id) {
      return res
        .status(400)
        .json({ success: false, message: "bulk_id is required." });
    }

    await client.query("BEGIN"); // 🟢 Start transaction

    const queryParams = [merchant_id, bulk_id];

    const baseQuery = `
      SELECT DISTINCT ON (o.order_id)
        o.order_id,
        o.order_status,
      o.full_amount,
        o.amount_paid AS discount,
        o.delivery_fee,
        o.total_weight,
        o.currency,
        o.recipient_contact,
        o.recipient_email,
        o.recipient_name,
        o.recipient_address,
        o.recipient_postal_code,
        o.recipient_city,
        o.recipient_country,
        o.payment_status,
        -- o.cod,           -- ❌ no longer used; we'll compute boolean from payment_methods
        o.tracking_id,
        dp.logo AS partner_logo,
        dp.contact_number AS partner_contact,
        cu.customer_id,
        cu.first_name,
        cu.last_name,
        cu.contact_number_1,
        cu.contact_number_2,
        cu.address,
        cu.city,
        cu.postal_code,
        cu.apartment,
        cu.country AS customer_country,
        cu.email,
        w.waybill,
        pm.method_name AS payment_method_name   -- ✅ added
      FROM orders o
      INNER JOIN customer cu ON o.customer_id = cu.customer_id
      LEFT JOIN delivery_partners dp ON o.delivery_partner_id = dp.partner_id
      LEFT JOIN waybills w ON o.order_id = w.order_id
      LEFT JOIN payment_methods pm ON pm.payment_method_id = o.payment_method_id  -- ✅ added
      WHERE o.merchant_id = $1 AND o.bulk_id = $2
      ORDER BY o.order_id, w.waybill DESC
    `;

    const countQuery = `
      SELECT COUNT(*) AS total
      FROM orders o
      INNER JOIN customer cu ON o.customer_id = cu.customer_id
      WHERE o.merchant_id = $1 AND o.bulk_id = $2;
    `;

    const brandingQuery = `SELECT logo_url_white FROM branding_settings LIMIT 1`;
    const brandingResult = await client.query(brandingQuery);
    const brand_logo = brandingResult.rows[0]?.logo_url_white || null;

    const [dataResult, countResult] = await Promise.all([
      client.query(baseQuery, queryParams),
      client.query(countQuery, queryParams),
    ]);

    const total = parseInt(countResult.rows[0].total, 10);

    const formatted = dataResult.rows.map((order) => {
      // ✅ Boolean COD: true if method_name is 'COD' (case-insensitive)
      const isCOD = (order.payment_method_name || '').toLowerCase() === 'cod';

      return {
        order_details: {
          order_id: order.order_id,
          order_status: order.order_status,
        full_amount: order.full_amount,
          discount: order.discount,
          delivery_fee: order.delivery_fee,
          total_weight: order.total_weight,
          currency: order.currency,
          payment_status: order.payment_status,
          cod: isCOD, // ✅ boolean, as requested
          tracking_id: order.tracking_id,
          waybill: order.waybill,
          delivery_partner_logo: order.partner_logo,
          brand_logo: brand_logo,
          delivery_partner_contact: order.partner_contact,
        },
        recipient_contact_info: {
          contact: order.recipient_contact,
          email: order.recipient_email,
        },
        recipient_address: {
          name: order.recipient_name,
          address: order.recipient_address,
          postal_code: order.recipient_postal_code,
          city: order.recipient_city,
          country: order.recipient_country,
        },
        customer_address: {
          customer_id: order.customer_id,
          name: `${order.first_name} ${order.last_name}`,
          contact_number_1: order.contact_number_1,
          contact_number_2: order.contact_number_2,
          address: order.address,
          apartment: order.apartment,
          city: order.city,
          postal_code: order.postal_code,
          country: order.customer_country,
          email: order.email,
        },
      };
    });

    await client.query("COMMIT"); // ✅ Commit if all successful
    res.json({ success: true, orders: formatted, total });
  } catch (error) {
    await client.query("ROLLBACK"); // ❌ Rollback on error
    console.error("Error in bulk-labels-by-id transaction:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  } finally {
    client.release(); // always release client back to pool
  }
});

module.exports = router;
