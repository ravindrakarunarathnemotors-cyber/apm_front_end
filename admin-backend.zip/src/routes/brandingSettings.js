const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");
const router = express.Router();


// Settgs APi


router.put('/settings', authenticateToken, async (req, res) => {
  try {
    const data = req.body;

    // Assuming there's only one row, and it always has id = 1
    const id = 1;

    const fields = [
      'company_name', 'slogan', 'logo_url', 'logo_url_white', 'logo_name_dark', 'logo_name_white',
      'favicon_url', 'app_icon_android', 'app_icon_ios', 'primary_color', 'secondary_color',
      'background_color', 'title_color', 'subtitle_color', 'text_color', 'button_primary_color',
      'button_secondary_color', 'button_success_color', 'button_warning_color', 'button_danger_color','hover_color',
      'border_radius', 'box_shadow', 'font_family', 'font_size', 'hotline', 'customer_support_phone',
      'address_1', 'address_2', 'support_email', 'info_email', 'billing_email', 'website_url',
      'client_portal_url', 'admin_portal_url', 'api_url', 'facebook_url', 'twitter_url',
      'instagram_url', 'linkedin_url', 'youtube_url','tiktok_url', 'terms_url', 'privacy_url', 'copyright_text',
      'seo_meta_title', 'seo_meta_description', 'seo_meta_keywords', 'footer_text','welcome_image','seo_image'
    ];

    const updates = fields.map((field, i) => `${field} = $${i + 1}`);
    const values = fields.map((field) => data[field]);

    const query = `
      UPDATE branding_settings
      SET ${updates.join(', ')}
      WHERE id = $${fields.length + 1}
      RETURNING *
    `;

    const result = await pool.query(query, [...values, id]);

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating branding settings:', err);
    res.status(500).json({ success: false, message: 'Failed to update branding settings' });
  }
});

// GET /branding/settings
router.get('/settings', async (req, res) => {
  try {
    const id = 1
    const result = await pool.query('SELECT * FROM branding_settings WHERE id = $1', [id])
    res.json({ success: true, data: result.rows[0] })
  } catch (err) {
    console.error('Error fetching branding settings:', err)
    res.status(500).json({ success: false, message: 'Failed to fetch branding settings' })
  }
})


router.get("/welcome", authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT welcome_image, company_name, logo_url, logo_url_white, logo_name_white, logo_name_dark, address_1, address_2, hotline, info_email, website_url
      FROM branding_settings
      LIMIT 1
    `);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Welcome image not found" });
    }

    res.status(200).json(result.rows[0]);

  } catch (error) {
    console.error("Error fetching welcome image:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});




module.exports = router;
