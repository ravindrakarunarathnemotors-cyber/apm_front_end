const {
  S3Client,
  PutObjectCommand,
  HeadObjectCommand,
} = require("@aws-sdk/client-s3");

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: `https://${process.env.S3_ENDPOINT}`,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
  },
  maxAttempts: 3,
});

const PUBLIC_URL_PREFIX =
  process.env.CONVERT_S3_URL ||
  `https://${process.env.S3_ENDPOINT}/${process.env.S3_BUCKET_NAME}`;

/**
 * Normalize path
 */
const normalizePath = (path) =>
  path.split("/").filter(Boolean).join("/");

/**
 * Check if root folder exists (via .keep file)
 */
const checkFolderExists = async (rootFolder) => {
  const key = `${normalizePath(rootFolder)}/.keep`;

  try {
    await s3.send(
      new HeadObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
      })
    );
    return true;
  } catch (err) {
    return false;
  }
};

/**
 * Create root folder if not exists
 */
const ensureRootFolder = async (rootFolder) => {
  const exists = await checkFolderExists(rootFolder);

  if (!exists) {
    const key = `${normalizePath(rootFolder)}/.keep`;

    await s3.send(
      new PutObjectCommand({
        Bucket: process.env.S3_BUCKET_NAME,
        Key: key,
        Body: "",
        ContentType: "text/plain",
      })
    );

    console.log(`🆕 Created new S3 root folder: ${rootFolder}`);
  }
};

/**
 * Universal uploader
 */
const uploadToS3 = async ({
  files,
  folderPath,
  useDate = false, // this one creates a new folder using date and insert into it  when useDate=true;
  debug = false,
  customFileName = null, //  NEW PARAM
}) => {
  const ROOT_FOLDER = process.env.S3_FOLDER;

  if (!ROOT_FOLDER) {
    throw new Error("❌ S3_FOLDER is missing in .env");
  }

 // allow empty folderPath → default to 'general'
if (!files) throw new Error("No files provided");

let safeFolderPath = folderPath || 'general';

if (safeFolderPath.includes("..")) {
  throw new Error("Invalid folder path");
}

  const fileArray = Array.isArray(files) ? files : [files];

  //  Ensure root folder exists
  await ensureRootFolder(ROOT_FOLDER);

  const now = new Date();
  const datePart = now.toISOString().split("T")[0];
  const timePart = now.toTimeString().split(" ")[0].replace(/:/g, "-");

  const sanitize = (name) =>
    name
      .replace(/[^a-zA-Z0-9._-]/g, "_")
      .replace(/_{2,}/g, "_")
      .replace(/^_+|_+$/g, "");

  const detectType = (file, cleanName) => {
    if (file.mimetype.startsWith("video")) return "video";
    if (file.mimetype.startsWith("image")) return "image";
    if (cleanName.toLowerCase().endsWith(".glb")) return "3d";
    return "file";
  };

const cleanFolderPath = normalizePath(safeFolderPath);
  const uploadTasks = fileArray.map(async (file, index) => {
    // VALIDATIONS

    if (!file.buffer || !file.originalname || !file.mimetype) {
      throw new Error("Invalid file object");
    }

    if (!file.originalname.trim()) {
      throw new Error("Empty file name");
    }

    const MAX_SIZE = 500 * 1024 * 1024; // 500MB LIMIT

    if (file.size && file.size > MAX_SIZE) {
      throw new Error(`File too large: ${file.originalname}`);
    }

    const cleanName = sanitize(file.originalname);

    // CUSTOM FILE NAME SUPPORT
    let finalName;

    if (customFileName) {
      const safeCustom = sanitize(customFileName);

      // if multiple files → append index
      finalName =
        fileArray.length > 1
          ? `${safeCustom}-${index + 1}`
          : safeCustom;

      // preserve extension
      const ext = cleanName.includes(".")
        ? cleanName.substring(cleanName.lastIndexOf("."))
        : "";

      finalName += ext;
    } else {
      finalName = `${Date.now()}-${Math.random()
        .toString(36)
        .substring(2, 6)}-${cleanName}`;
    }

    //  Build key
    let key = `${normalizePath(ROOT_FOLDER)}/${cleanFolderPath}`;

    if (useDate) key += `/${datePart}`;

    key += `/${timePart}-${finalName}`;
    key = normalizePath(key);

    const params = {
      Bucket: process.env.S3_BUCKET_NAME,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
      ACL: "public-read",
    };

    try {
      if (debug) console.log("Uploading:", key);

      await s3.send(new PutObjectCommand(params));

      return {
        success: true,
        url: `${PUBLIC_URL_PREFIX}/${key}`,
        key,
        type: detectType(file, cleanName),
        original_name: cleanName,
      };
    } catch (err) {
      console.error("Upload failed:", err.message);

      return {
        success: false,
        error: err.message,
        original_name: cleanName,
      };
    }
  });

  return Promise.all(uploadTasks);
};

module.exports = { uploadToS3 };