const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const { autodiscountCheck, autodeliverydiscountCheck, autodpmethoddiscountCheck, autodbuyxdiscountCheck } = require("../controllers/DiscountController");


const router = express.Router();

// register user ..................................

router.post("/autodiscountcheck", authenticateToken, autodiscountCheck)

router.post("/autodeliverdiscount", authenticateToken, autodeliverydiscountCheck)

router.post("/autodpmethoddiscount", authenticateToken, autodpmethoddiscountCheck)

router.post("/autodbuyxdiscount", authenticateToken, autodbuyxdiscountCheck)


module.exports = router