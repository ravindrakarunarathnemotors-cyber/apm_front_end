const express = require("express");
const router = express.Router();
const pool = require("../../config/db"); // adjust path if needed
const authenticateToken = require("../../middleware/authMiddleware");
const { insertAdminLog } = require("../../models/userLogs");
const { encryptId } = require("../../util/orderEncrypt");
const { customhook } = require("../../models/smsnotificationmodel");
const updateTransactionRecord = require("../transactionsUpdater/transactionsUpdater");

router.post("/allorders2", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      payment_status,
      date,
      todate,
      keyword,
      order_status,
      user_id,
      type,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔍 Keyword search
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.sender_name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date range
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`,
      );
    }

    // 💳 Payment status
    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.payment_status = $${queryParams.length}`);
    }

    if (user_id) {
      queryParams.push(user_id);
      whereConditions.push(`o.user_id = $${queryParams.length}`);
    }

    if (type) {
      queryParams.push(type);
      whereConditions.push(`o.interface = $${queryParams.length}`);
    }

    // 📦 Order status logic
    if (Array.isArray(order_status)) {
      if (order_status.length > 0) {
        queryParams.push(order_status);
        whereConditions.push(
          `o.order_status = ANY($${queryParams.length}::text[])`,
        );

        if (!order_status.includes("cancelled")) {
          queryParams.push("cancelled");
          whereConditions.push(`o.order_status != $${queryParams.length}`);
        }
      } else {
        queryParams.push("cancelled");
        whereConditions.push(`o.order_status != $${queryParams.length}`);
      }
    }

    const whereClause = whereConditions.length
      ? `WHERE o.order_status NOT IN ('hold', 'draft', 'delete') AND ${whereConditions.join(" AND ")}`
      : "";

    // 📄 Orders query
    const ordersQuery = `
      SELECT 
        o.id,
        o.customer_id,
        o.payment_method_id,
        o.order_status,
        o.total_value,
        o.amount_paid,
        o.total_item,
        o.total_weight,
        o.payment_status,
        o.currency,
        o.sender_name,
        o.sender_phone,
        o.sender_email,
        o.sender_address,
        o.sender_city,
        o.sender_postal_code,
        o.sender_country,
        o.sender_addrees_2,
        o.recipient_contact_two,
        o.delivery_fee,
        o.discount,
        o.created_at,
        o.tax_percentage,
        o.tax,
        o.full_amount,
        o.loyalty_points_earned,
        o.loyalty_points_spent,
        o.discount_type,
        o.interface,
        o.balance,
        o.add_to_points,
        o.interface,
        o.user_id,
        u.first_name AS user_name,
        COALESCE(o.payments, '[]'::jsonb) AS payments,
        COALESCE(o.salespersons, '[]'::jsonb) AS salespersons,
        c.first_name AS customer_name,
        o.recipient_contact_two AS contact_number,
        py.method_name AS method_name,
        ss.currency AS currency
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN payment_methods py ON o.payment_method_id = py.payment_method_id
      LEFT JOIN users u ON o.user_id = u.user_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    // 🔢 Total count
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // 📝 Admin log (optional)
    // await insertAdminLog(req.user.id, "Viewed all orders");

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/product-details/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;

  try {
    /* ---------------- ORDER ITEMS ---------------- */
    const itemsQuery = `
      SELECT 
        ie.id,
        ie.invoice_id,
        ie.product_id,
        ie.variant_id,
        ie.name,
        ie.description,
        ie.item_weight,
        ie.quantity,
        ie.unit_price,
        ie.discount,
        ie.total_price,
        ie.is_free,
        ie.free_quantity,
        ie.is_custom,
        ie.amount_per_unit,
        ie.unit_type,
        pv.variant_value,
        m.measurement_value
      FROM invoice_details ie
      LEFT JOIN product_variants pv ON ie.variant_id = pv.variant_id
      LEFT JOIN measurements m ON ie.unit_type :: INTEGER = m.measurement_id
      WHERE ie.invoice_id = $1
      ORDER BY ie.id ASC
    `;

    /* ---------------- invoice_payment_history ---------------- */
    const orderPaymentHistoryQuery = `SELECT  
        ip.id,
        ip.date,
        ip.invoice_id,
        ip.amount,
        ip.reference,
        ip.doc,
        ip.method_id,
        ip.status,
        pm.method_name
    FROM invoice_payment_history ip 
    LEFT JOIN payment_methods pm ON ip.method_id = pm.payment_method_id
    WHERE ip.invoice_id = $1`;

    /* ---------------- BRANDING ---------------- */
    const brandingQuery = `
      SELECT logo_url_white, company_name, address_1, address_2, hotline
      FROM branding_settings
      LIMIT 1
    `;

    /* ---------------- SYSTEM SETTINGS ---------------- */
    const settingsQuery = `
      SELECT terms_conditions
      FROM system_settings
      LIMIT 1
    `;

    const [
      itemsResult,
      orderPaymentHistoryResult,
      brandingResult,
      settingsResult,
    ] = await Promise.all([
      pool.query(itemsQuery, [id]),
      pool.query(orderPaymentHistoryQuery, [id]),
      pool.query(brandingQuery),
      pool.query(settingsQuery),
    ]);

    if (
      itemsResult.rows.length === 0 ||
      brandingResult.rows.length === 0 ||
      settingsResult.rows.length === 0
    ) {
      return res.status(404).json({ message: "Order not found" });
    }

    const encryptID = encryptId(id);

    const url = `${process.env.FRONTEND_URL}/ebill/${encryptID}`;

    /* ---------------- RESPONSE ---------------- */
    res.status(200).json({
      order_items: itemsResult.rows,
      order_payment_history: orderPaymentHistoryResult.rows,
      system_settings: {
        terms_conditions: settingsResult.rows[0]?.terms_conditions ?? null,
      },
      fromdetails: brandingResult.rows[0] ?? null,
      url: url,
    });
  } catch (error) {
    console.error("Error fetching product details:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});


// invoice payment revoke 
router.post("/revoke-paid-invoice",authenticateToken, async (req, res) => {
  const { invoice_id, payment_id } = req.body;

  if (!invoice_id || !payment_id) {
    return res.status(400).json({
      message: "invoice_id and payment_id are required",
    });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    /* -------------------------------------------------
       1️⃣ Lock invoice row (SOURCE OF TRUTH)
    ------------------------------------------------- */
    const invoiceRes = await client.query(
      `
      SELECT
        id,
        customer_id,
        amount_paid,
        full_amount,
        loyalty_points_earned,
        loyalty_points_spent
      FROM invoice_header
      WHERE id = $1
      FOR UPDATE
      `,
      [invoice_id],
    );

    if (invoiceRes.rowCount === 0) {
      throw new Error("Invoice not found");
    }

    const { customer_id } = invoiceRes.rows[0];

    /* -------------------------------------------------
       2️⃣ Lock payment row & read values
    ------------------------------------------------- */
    const paymentRes = await client.query(
      `
      SELECT
        id,
        amount,
        acc_id,
        loyalty_points_earned,
        loyalty_points_spent
      FROM invoice_payment_history
      WHERE id = $1
        AND invoice_id = $2
        AND status != 'revoked'
      FOR UPDATE
      `,
      [payment_id, invoice_id],
    );

    if (paymentRes.rowCount === 0) {
      throw new Error("Payment record not found for this invoice");
    }

    const {
      amount,
      acc_id,
      loyalty_points_earned: payment_lp_earned,
      loyalty_points_spent: payment_lp_spent,
    } = paymentRes.rows[0];

    /* -------------------------------------------------
       🚫 HARD STOP if acc_id is missing
    ------------------------------------------------- */
    if (!acc_id) {
      throw new Error("Cannot revoke payment: account reference missing");
    }

    /* -------------------------------------------------
       2️⃣.1 Lock account row
    ------------------------------------------------- */
    await client.query(
      `
      SELECT id, balance
      FROM accounts
      WHERE id = $1
      FOR UPDATE
      `,
      [acc_id],
    );

    /* -------------------------------------------------
       3️⃣ REPLACE MANUAL BALANCE UPDATE WITH TRANSACTION ENGINE
    ------------------------------------------------- */

    const revokeAmount = parseFloat(amount) || 0;

    if (revokeAmount > 0) {
      await updateTransactionRecord({
        client,
        amount: revokeAmount,
        account_id: acc_id,
        category_id: 1, // adjust if you have REVERSAL category
        transaction_type: "expense", // 🔴 DEBIT
        note: `Invoice Payment Revoke | Invoice #${invoice_id} | Payment #${payment_id}`,
        by_user_id: req.user.user_id,
        payer_payee_id: customer_id,
        outlet_id: null,
        log_module: "INVOICE_PAYMENT_REVOKE",
        log_message: `Invoice payment revoke debit | Invoice: ${invoice_id} | Payment: ${payment_id} | Amount: ${revokeAmount}`,
      });
    }

    /* -------------------------------------------------
       4️⃣ Deduct amount from invoice
    ------------------------------------------------- */
    await client.query(
      `
      UPDATE invoice_header
      SET amount_paid = GREATEST(amount_paid - $1, 0)
      WHERE id = $2
      `,
      [amount, invoice_id],
    );

    /* -------------------------------------------------
       4️⃣ Restore loyalty points on invoice_header
    ------------------------------------------------- */
    await client.query(
      `
      UPDATE invoice_header
      SET
        loyalty_points_earned = loyalty_points_earned + $1,
        loyalty_points_spent  = loyalty_points_spent  + $2
      WHERE id = $3
      `,
      [payment_lp_earned || 0, payment_lp_spent || 0, invoice_id],
    );

    /* -------------------------------------------------
       5️⃣ Restore loyalty points on customer table
    ------------------------------------------------- */
    await client.query(
      `
      UPDATE customer
      SET
        loyalty_point = GREATEST(
          loyalty_point + $1 - $2,
          0
        )
      WHERE customer_id = $3
      `,
      [payment_lp_spent || 0, payment_lp_earned || 0, customer_id],
    );

    /* -------------------------------------------------
       6️⃣ Recalculate payment_status
    ------------------------------------------------- */
    await client.query(
      `
      UPDATE invoice_header
      SET payment_status = CASE
        WHEN amount_paid = 0 THEN 'unpaid'
        WHEN amount_paid < full_amount THEN 'partially paid'
        ELSE 'paid'
      END
      WHERE id = $1
      `,
      [invoice_id],
    );

    /* -------------------------------------------------
       7️⃣ Update payment history
    ------------------------------------------------- */
    const historyUpdate = await client.query(
      `
      UPDATE invoice_payment_history
      SET status = 'revoked'
      WHERE id = $1
        AND invoice_id = $2
      `,
      [payment_id, invoice_id],
    );

    if (historyUpdate.rowCount === 0) {
      throw new Error("Failed to update payment history");
    }

    await client.query("COMMIT");

    res.json({
      success: true,
      message: "Payment revoked successfully",
    });

  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);

    res.status(500).json({
      success: false,
      message: err.message || "Failed to revoke payment",
    });

  } finally {
    client.release();
  }
});


// cancel invoice - set status to cancelled
router.post("/cancel-invoice", authenticateToken, async (req, res) => {
  const { invoice_id } = req.body;

  if (!invoice_id) {
    return res.status(400).json({
      success: false,
      message: "invoice_id is required",
    });
  }

  try {
    const result = await pool.query(
      `
      UPDATE invoice_header
      SET order_status = 'cancelled',
          updated_at = NOW()
      WHERE id = $1
      RETURNING id, order_status
      `,
      [invoice_id],
    );

    if (result.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Invoice not found",
      });
    }

    return res.json({
      success: true,
      message: "Invoice cancelled successfully",
      invoice: result.rows[0],
    });
  } catch (error) {
    console.error("Cancel invoice error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to cancel invoice",
    });
  }
});

router.post("/cancelledInvoice", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 25, date, todate, keyword } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔍 Keyword search
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.sender_name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date range
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`,
      );
    }

    queryParams.push("cancelled");
    whereConditions.push(`o.order_status = $${queryParams.length}`);

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // 📄 Orders query
    const ordersQuery = `
      SELECT 
        o.id,
        o.customer_id,
        o.payment_method_id,
        o.order_status,
        o.total_value,
        o.amount_paid,
        o.total_item,
        o.total_weight,
        o.payment_status,
        o.currency,
        o.sender_name,
        o.sender_phone,
        o.sender_email,
        o.sender_address,
        o.sender_city,
        o.sender_postal_code,
        o.sender_country,
        o.recipient_contact_two,
        o.delivery_fee,
        o.discount,
        o.created_at,
        o.tax_percentage,
        o.tax,
        o.full_amount,
        o.loyalty_points_earned,
        o.loyalty_points_spent,
        c.first_name AS customer_name,
        o.recipient_contact_two AS contact_number,
        py.method_name AS method_name,
        ss.currency AS currency
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN payment_methods py ON o.payment_method_id = py.payment_method_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    // 🔢 Total count
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // 📝 Admin log (optional)
    // await insertAdminLog(req.user.id, "Viewed all orders");

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/users", authenticateToken, async (req, res) => {
  try {
    const { search } = req.query;

    const query = `SELECT DISTINCT user_id, first_name, last_name FROM users WHERE first_name ILIKE $1 LIMIT 10`;

    const result = await pool.query(query, [`%${search}%`]);

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

router.post("/deleteInvoice", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 25, date, todate, keyword } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔍 Keyword search
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.sender_name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date range
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`,
      );
    }

    queryParams.push("delete");
    whereConditions.push(`o.order_status = $${queryParams.length}`);

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // 📄 Orders query
    const ordersQuery = `
      SELECT 
        o.id,
        o.customer_id,
        o.payment_method_id,
        o.order_status,
        o.total_value,
        o.amount_paid,
        o.total_item,
        o.total_weight,
        o.payment_status,
        o.currency,
        o.sender_name,
        o.sender_phone,
        o.sender_email,
        o.sender_address,
        o.sender_city,
        o.sender_postal_code,
        o.sender_country,
        o.recipient_contact_two,
        o.delivery_fee,
        o.discount,
        o.created_at,
        o.tax_percentage,
        o.tax,
        o.full_amount,
        o.loyalty_points_earned,
        o.loyalty_points_spent,
        c.first_name AS customer_name,
        o.recipient_contact_two AS contact_number,
        py.method_name AS method_name,
        ss.currency AS currency
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN payment_methods py ON o.payment_method_id = py.payment_method_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    // 🔢 Total count
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // 📝 Admin log (optional)
    // await insertAdminLog(req.user.id, "Viewed all orders");

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/sendinvoice", authenticateToken, async (req, res) => {
  try {
    const { id } = req.body;

    const result = await customhook(13, id);

    return res.json({
      sms: result.invoice_link_sms,
      email: result.invoice_link_email,
      message: "Invoice sent successfully",
    });
  } catch (error) {
    console.error("Error fetching banks:", error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

// order invoice payment
router.post("/order-invoice-payment", authenticateToken, async (req, res) => {
  try {
    const {
      amount,
      invoice_id, // this is order_id from frontend
      file, // bank slip URL
      paymentMethod,
      reference,
      account_id,
    } = req.body;

    const user = req.user;
    const user_id = user.user_id;

    /* ================= VALIDATION ================= */
    const convertAmount = parseFloat(amount);
    if (isNaN(convertAmount) || convertAmount <= 0) {
      return res.status(400).json({ message: "Invalid amount" });
    }

    if (!invoice_id || !paymentMethod || !account_id) {
      return res.status(400).json({
        message: "invoice_id, paymentMethod and account_id are required",
      });
    }

    /* ================= SYSTEM SETTINGS ================= */
    const settingsResult = await pool.query(
      `SELECT * FROM system_settings LIMIT 1`,
    );
    const settings = settingsResult.rows[0] || {};

    /* ================= GET ORDER ================= */
    const orderResult = await pool.query(
      `SELECT order_id, customer_id, full_amount, amount_paid, payment_status, loyalty_points_earned, outlet_id
       FROM orders
       WHERE order_id = $1
       LIMIT 1`,
      [invoice_id],
    );

    if (orderResult.rowCount === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const order = orderResult.rows[0];

    if (order.payment_status === "paid") {
      return res.status(400).json({ message: "Order already paid" });
    }

    const fullAmount = parseFloat(order.full_amount);
    const alreadyPaid = parseFloat(order.amount_paid);
    const remaining = fullAmount - alreadyPaid;

    if (convertAmount > remaining) {
      return res
        .status(400)
        .json({ message: "Amount exceeds remaining balance" });
    }

    /* ================= CALCULATE NEW VALUES ================= */
    const newAmountPaid = alreadyPaid + convertAmount;
    const paymentStatus =
      newAmountPaid >= fullAmount ? "paid" : "partially paid";

    /* ================= LOYALTY ================= */
    let loyalty_points_earned = 0;

    if (settings.loyalty_point) {
      const points_given = parseFloat(settings.points_given) || 0;
      const amount_spend = parseFloat(settings.amount_spend) || 0;

      if (amount_spend > 0) {
        loyalty_points_earned = (convertAmount / amount_spend) * points_given;
      }
    }

    /* ================= DB TRANSACTION ================= */
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      /* ---- UPDATE orders ---- */
      const updateOrderResult = await client.query(
        `UPDATE orders
         SET
           amount_paid           = $1,
           payment_status        = $2,
           loyalty_points_earned = COALESCE(loyalty_points_earned, 0) + $3
         WHERE order_id = $4`,
        [newAmountPaid, paymentStatus, loyalty_points_earned, order.order_id],
      );

      if (updateOrderResult.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(400).json({ message: "Order update failed" });
      }

      /* ---- INSERT invoice_payment_history ---- */
      const paymentHistoryResult = await client.query(
        `INSERT INTO invoice_payment_history
  (invoice_id, order_invoice_id, user_id, method_id, amount, reference, doc, loyalty_points_earned, acc_id, module)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [
          null, // invoice_id = null (as requested)
          order.order_id, // order_invoice_id
          user_id,
          paymentMethod,
          convertAmount,
          reference || null,
          file || null,
          loyalty_points_earned,
          account_id,
          "order",
        ],
      );

      if (paymentHistoryResult.rowCount === 0) {
        await client.query("ROLLBACK");
        return res
          .status(400)
          .json({ message: "Payment history insert failed" });
      }

      /* ---- UPDATE customer loyalty points ---- */
      if (settings.loyalty_point && loyalty_points_earned > 0) {
        await client.query(
          `UPDATE customer
           SET loyalty_point = COALESCE(loyalty_point, 0) + $1
           WHERE customer_id = $2`,
          [loyalty_points_earned, order.customer_id],
        );
      }

      /* ---- TRANSACTION RECORD (handles account balance + statement) ---- */
      await updateTransactionRecord({
        client,
        amount: convertAmount,
        account_id: account_id,
        category_id: paymentMethod,
        transaction_type: "income",
        note: reference || `Invoice payment for order #${order.order_id}`,
        by_user_id: user_id,
        payer_payee_id: order.customer_id || null,
        outlet_id: order.outlet_id || null,
        log_module: "Invoice Payment",
        log_message: `Order invoice payment of ${convertAmount} received for order #${order.order_id} by user ${user_id}. Status: ${paymentStatus}`,
      });

      /* ================= OPTIONAL HOOK ================= */
      let hookResponse = null;
      try {
        hookResponse = await customhook(11, order.order_id);
      } catch (err) {
        console.error("Hook error:", err);
      }

      await client.query("COMMIT");

      return res.status(200).json({
        success: true,
        message: "Payment added successfully",
        payment_status: paymentStatus,
        paid: newAmountPaid,
        remaining: fullAmount - newAmountPaid,
        loyalty_points_earned,
        hook: hookResponse,
      });
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error("order-invoice-payment error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// fetch paid history for order invoice

router.get(
  "/order-invoice-payment-history/:order_id",
  authenticateToken,
  async (req, res) => {
    try {
      const { order_id } = req.params;

      if (!order_id) {
        return res.status(400).json({ message: "order_id is required" });
      }

      /* ================= SYSTEM SETTINGS ================= */
      const settingsResult = await pool.query(
        `SELECT currency FROM system_settings LIMIT 1`,
      );

      const currency = settingsResult.rows[0]?.currency || "";

      /* ================= FETCH ORDER DETAILS ================= */
      const orderResult = await pool.query(
        `SELECT
           order_status,
           payment_status,
           transaction_fee,
           full_amount
         FROM orders
         WHERE order_id = $1
         LIMIT 1`,
        [order_id],
      );

      const orderData = orderResult.rows[0] || {};

      /* ================= FETCH PAYMENT HISTORY ================= */
      const historyResult = await pool.query(
        `SELECT
           iph.id,
           iph.invoice_id,
           iph.user_id,
           iph.method_id,
           iph.amount,
           iph.reference,
           iph.doc,
           iph.loyalty_points_earned,
           iph.loyalty_points_spent,
           iph.acc_id,
           iph.status,
           iph.type,
           iph.date,
           iph.module,
           pm.method_name  AS method_name,
           a.name          AS account_name
         FROM invoice_payment_history iph
         LEFT JOIN payment_methods pm
           ON pm.payment_method_id = iph.method_id
         LEFT JOIN accounts a
           ON a.id = iph.acc_id
         WHERE iph.order_invoice_id = $1
         ORDER BY iph.date DESC`,
        [order_id],
      );

      return res.status(200).json({
        success: true,
        currency,

        order_status: orderData.order_status || null,
        payment_status: orderData.payment_status || null,
        transaction_fee: orderData.transaction_fee || 0,

        rows: historyResult.rows,
        total: historyResult.rowCount,
      });
    } catch (error) {
      console.error("order-invoice-payment-history error:", error);

      return res.status(500).json({
        message: "Internal server error",
      });
    }
  },
);

// --------updated invoice payment route with transaction fee logic..

router.post( "/order-invoice-payment-update", authenticateToken, async (req, res) => {

    const client = await pool.connect();

    try {
      const {
        order_id,
        amount_paid: incomingPaidAmount,
        total_transaction_fee: incomingFee,
        reference,
        account_id,
        payment_method_id,
      } = req.body;

      console.log("payload is: ", req.body);
      const user_id = req.user.user_id;
      const systemSettingsQuery = `
          SELECT
            id,
            currency,
            tax,
            tax_value,
            loyalty_point,
            points_given,
            amount_spend
          FROM system_settings
          WHERE id = 1
        `;

      const systemSettingsResult = await client.query(systemSettingsQuery);

      if (systemSettingsResult.rows.length === 0) {
        return res.status(400).json({
          message: "System settings not found",
        });
      }

      const system_settings = systemSettingsResult.rows[0];
      if (!order_id || incomingPaidAmount == null || incomingFee == null) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const paidAmount = parseFloat(incomingPaidAmount);
      const transactionFee = parseFloat(incomingFee);

      if (isNaN(paidAmount) || isNaN(transactionFee)) {
        return res.status(400).json({ message: "Invalid numeric values" });
      }

      await client.query("BEGIN");

      /* ================= GET ORDER ================= */
      const orderRes = await client.query(
        `SELECT * FROM orders WHERE order_id = $1 FOR UPDATE`,
        [order_id],
      );

      if (orderRes.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Order not found" });
      }

      const order = orderRes.rows[0];

      const fullAmount = parseFloat(order.full_amount);
      const amountPaid = parseFloat(order.amount_paid || 0);
      const existingFee = parseFloat(order.transaction_fee || 0);
      const currentStatus = order.payment_status; // SOURCE OF TRUTH

      let newAmountPaid;
      let newFullAmount;
      let newTransactionFee;

      /* ================= CORE LOGIC ================= */

      if (currentStatus === "unpaid") {
        //  RESET LOGIC

        const baseNetAmount = fullAmount - existingFee;

        newTransactionFee = transactionFee; // overwrite
        newFullAmount = baseNetAmount + transactionFee;

        // overwrite paid
        newAmountPaid = paidAmount + transactionFee;
      } else if (currentStatus === "partially paid") {
        //  ADDITIVE LOGIC

        newTransactionFee = existingFee + transactionFee;

        newFullAmount = fullAmount + transactionFee;

        newAmountPaid = amountPaid + paidAmount + transactionFee;
      } else {
        //  already paid (safe fallback)

        newTransactionFee = existingFee + transactionFee;
        newFullAmount = fullAmount + transactionFee;
        newAmountPaid = amountPaid + paidAmount;
      }

      /* ================= LOYALTY POINTS ================= */

      let loyalty_points_earned = 0;

      const loyalty_point = system_settings.loyalty_point;

      if (paidAmount > 0) {
        const points_given = parseFloat(system_settings.points_given) || 0;
        const amount_spend = parseFloat(system_settings.amount_spend) || 0;

        if (loyalty_point && amount_spend > 0) {
          const orderPerPoint = paidAmount / amount_spend;
          loyalty_points_earned = orderPerPoint * points_given;
        }
      }

      /* ================= PAYMENT STATUS ================= */

      let paymentStatus;

      if (newAmountPaid >= newFullAmount) {
        paymentStatus = "paid";
      } else if (newAmountPaid > 0) {
        paymentStatus = "partially paid";
      } else {
        paymentStatus = "unpaid";
      }

      /* ================= UPDATE ORDERS ================= */

      const updateOrder = await client.query(
        `
            UPDATE orders
        SET
          amount_paid = $1,
          full_amount = $2,
          transaction_fee = $3,
          payment_status = $4,
          loyalty_points_earned = COALESCE(loyalty_points_earned, 0) + $5,
          updated_at = NOW()
        WHERE order_id = $6
      `,
        [
          newAmountPaid,
          newFullAmount,
          newTransactionFee,
          paymentStatus,
          loyalty_points_earned,
          order_id,
        ],
      );

      if (updateOrder.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(400).json({ message: "Order update failed" });
      }

      /* ================= PAYMENT HISTORY ================= */

      // prevent double counting if fee already included in amount
      const finalAmount = paidAmount + transactionFee;

      const selectedAccountId = account_id ? parseInt(account_id) : null;
      const selectedMethodId = payment_method_id
        ? parseInt(payment_method_id)
        : null;

      await client.query(
        `
          INSERT INTO invoice_payment_history
      (
        order_invoice_id,
        user_id,
        amount,
        transaction_fee,
        reference,
        module,
        method_id,
        acc_id,
        loyalty_points_earned
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        `,
        [
          order_id,
          user_id,
          finalAmount,
          transactionFee,
          reference || null,
          "order",
          selectedMethodId,
          selectedAccountId,
          loyalty_points_earned,
        ],
      );
      /* ================= CREATE TRANSACTION ================= */

      const outlet_id = order.outlet_id || null;
      const customer_id = order.customer_id || null;
      if (loyalty_point && customer_id && loyalty_points_earned > 0) {
        // get current loyalty
        const loyaltyResult = await client.query(
                `
          SELECT loyalty_point
          FROM customer
          WHERE customer_id = $1
          `,
          [customer_id],
        );

        if (loyaltyResult.rows.length > 0) {
          const currentPoints =
            parseFloat(loyaltyResult.rows[0].loyalty_point) || 0;

          const newPoints = currentPoints + loyalty_points_earned;

          // update customer loyalty
          await client.query(
            `
            UPDATE customer
            SET loyalty_point = $1
            WHERE customer_id = $2
            `,
            [newPoints, customer_id],
          );

          // optional loyalty log
          await client.query(
            `
            INSERT INTO points_logs
            (
              customer_id,
              prev_amount,
              adjust_amount,
              new_amount,
              comment
            )
            VALUES ($1,$2,$3,$4,$5)
            `,
            [
              customer_id,
              currentPoints,
              loyalty_points_earned,
              newPoints,
              `Order payment loyalty earned | Order #${order_id}`,
            ],
          );
        }
      }
      /*
      Credit transaction
    */

      await updateTransactionRecord({
        client,
        amount: finalAmount,
        account_id: selectedAccountId,
        category_id: 1, // replace with your SALES/ORDER INCOME category id
        transaction_type: "income",
        note: `Order Payment | Order #${order_id} | Ref: ${reference || "N/A"}`,
        by_user_id: user_id,
        payer_payee_id: customer_id,
        outlet_id,
        log_module: "ORDER_PAYMENT_TRANSACTION",
        log_message: `Order payment transaction created | Order: ${order_id} | Amount: ${finalAmount}`,
      });

      /* ================= COMMIT ================= */

      await client.query("COMMIT");

      /* ================= ADMIN LOG ================= */

      try {
        await insertAdminLog(
          user_id,
          "orders",
          `ORDER_PAYMENT_UPDATE | Order: ${order_id} | Paid: ${newAmountPaid} | Fee: ${newTransactionFee} | Status: ${paymentStatus} | Ref: ${reference || "N/A"}`,
        );
      } catch (e) {
        console.error("Admin log failed:", e);
      }

      return res.status(200).json({
        success: true,
        order_id,
        amount_paid: newAmountPaid,
        full_amount: newFullAmount,
        transaction_fee: newTransactionFee,
        payment_status: paymentStatus,
      });
    } catch (error) {
      await client.query("ROLLBACK");
      console.error("order-payment-update error:", error);
      return res.status(500).json({ message: "Internal server error" });
    } finally {
      client.release();
    }
  },
);



module.exports = router;
