const express = require("express");
const router = express.Router();
const pool = require("../../config/db"); // adjust path if needed
const authenticateToken = require("../../middleware/authMiddleware");
const { insertAdminLog } = require("../../models/userLogs");
const { send_sms } = require("../../models/smsnotificationmodel");
const { sendemailtemp } = require("../../models/sendemailtemp");
const { customhookQuotation } = require("../../models/smsnotificationmodel");
const { adminUserDeatils, systemSettings, checkLoyalty, updateLoyaltySuctomer } = require("../../models/commonModels");
const { insertNotification } = require("../../models/notificationsUpdater");

router.post("/getQuotations", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      status,
      date,
      todate,
      keyword,
      order_status,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔍 Keyword search
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.sender_name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date range
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
      );
    }

    // 💳 Payment status
    // 🚫 Default: exclude rejected & cancelled
    if (!status) {
      whereConditions.push(`o.status NOT IN ('rejected', 'cancelled')`);
    }

    if (status) {
      queryParams.push(status);
      whereConditions.push(`o.status = $${queryParams.length}`);
    }




    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // 📄 Orders query
    const ordersQuery = `
      SELECT 
        o.id,
        o.customer_id,
        o.status,
        o.total_value,
        o.total_item,
        o.total_weight,
        o.currency,
        o.sender_name,
        o.sender_phone,
        o.sender_email,
        o.sender_address,
        o.sender_city,
        o.sender_postal_code,
        o.sender_country,
        o.discount,
        o.created_at,
        o.tax_percentage,
        o.tax,
        o.note,
        o.time_period,
        o.quotation_date,
        o.full_amount,
        c.first_name AS customer_name,
        ss.currency AS currency
      FROM quotation_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    // 🔢 Total count
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM quotation_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // 📝 Admin log (optional)
    // await insertAdminLog(req.user.id, "Viewed all orders");

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get("/product-details/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;

  console.log("id", id);

  try {

    /* ---------------- ORDER ITEMS ---------------- */
    const itemsQuery = `
      SELECT 
        ie.id,
        ie.quotation_id,
        ie.product_id,
        ie.variant_id,
        ie.name,
        ie.description,
        ie.item_weight,
        ie.quantity,
        ie.unit_price,
        ie.discount,
        ie.total_price,
        ie.is_free,
        ie.free_quantity,
        ie.is_custom,
        ie.amount_per_unit,
        ie.unit_type,
        pv.variant_value,
        qh.recipent_note,
        qh.note,
        qh.quotation_date,
        qh.discount_type,
        m.measurement_value
      FROM quotation_details ie
      LEFT JOIN product_variants pv ON ie.variant_id = pv.variant_id
      LEFT JOIN quotation_header qh ON qh.id = ie.quotation_id
      LEFT JOIN measurements m ON ie.unit_type :: INTEGER = m.measurement_id
      WHERE ie.quotation_id = $1
      ORDER BY ie.id ASC
    `;


    /* ---------------- invoice_payment_history ---------------- */
    // const orderPaymentHistoryQuery = `SELECT  
    //     ip.id,
    //     ip.date,
    //     ip.invoice_id,
    //     ip.amount,
    //     ip.reference,
    //     ip.doc,
    //     ip.method_id,
    //     ip.status,
    //     pm.method_name
    // FROM invoice_payment_history ip 
    // LEFT JOIN payment_methods pm ON ip.method_id = pm.payment_method_id
    // WHERE ip.invoice_id = $1`;

    /* ---------------- BRANDING ---------------- */
    const brandingQuery = `
      SELECT logo_url_white, company_name, address_1, address_2, hotline
      FROM branding_settings
      LIMIT 1
    `

    /* ---------------- SYSTEM SETTINGS ---------------- */
    const settingsQuery = `
      SELECT terms_conditions_quotations
      FROM system_settings
      LIMIT 1
    `

    const [itemsResult, brandingResult, settingsResult] = await Promise.all([
      pool.query(itemsQuery, [id]),
      //pool.query(orderPaymentHistoryQuery, [id]),
      pool.query(brandingQuery),
      pool.query(settingsQuery)
    ]);

    if (itemsResult.rows.length === 0 || brandingResult.rows.length === 0 || settingsResult.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    /* ---------------- RESPONSE ---------------- */
    res.status(200).json({

      order_items: itemsResult.rows,
      //order_payment_history: orderPaymentHistoryResult.rows,
      system_settings: {
        terms_conditions_quotations: settingsResult.rows[0]?.terms_conditions_quotations ?? null,
      },
      fromdetails: brandingResult.rows[0] ?? null,
    });
  } catch (error) {
    console.error("Error fetching product details:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// router.post("/send-qutationStatus", authenticateToken, async (req, res) => {
//     const {
//       quotation_id,
//       email,
//       phone,
//       send_email,
//       send_mobile,
//       customer_name,
//       quotation_link, // optional
//     } = req.body;

//     const user_id = req.user.user_id;

//     if (!quotation_id) {
//       return res.status(400).json({ message: "quotation_id is required" });
//     }

//     let client;
//     try {
//       client = await pool.connect();

//       /* ===============================
//          1️⃣ UPDATE QUOTATION (ONE QUERY)
//       =============================== */
//       const updateQuery = `
//         UPDATE quotation_header
//         SET
//           status = 'sent',
//           quotation_link = COALESCE($1, quotation_link),
//           updated_at = NOW()
//         WHERE id = $2
//         RETURNING id, quotation_link
//       `;

//       const updateResult = await client.query(updateQuery, [
//         quotation_link || null,
//         quotation_id,
//       ]);

//       if (updateResult.rowCount === 0) {
//         return res.status(404).json({
//           success: false,
//           message: "Quotation not found",
//         });
//       }

//       const finalQuotationLink = updateResult.rows[0].quotation_link;

//       /* ===============================
//          2️⃣ SEND EMAIL
//       =============================== */
//       let emailStatus = "skipped";

//       if (send_email === true && email && finalQuotationLink) {
//         try {
//           await sendemailtemp(
//             customer_name,
//             finalQuotationLink,
//             "Your Quotation Is Ready",
//             email
//           );
//           emailStatus = "sent";
//         } catch (emailError) {
//           emailStatus = "failed";
//           console.error("Email sending failed:", emailError);
//         }
//       }

//       /* ===============================
//          3️⃣ SEND SMS
//       =============================== */
//       let smsStatus = "skipped";

//       if (send_mobile === true && phone && finalQuotationLink) {
//         const smsSettingsResult = await client.query(`
//           SELECT 
//             sms_gateway_name,
//             sms_user_id,
//             sms_sender_id,
//             sms_api_endpoint,
//             sms_api_key
//           FROM system_settings
//           LIMIT 1
//         `);

//         if (smsSettingsResult.rowCount > 0) {
//           const {
//             sms_user_id,
//             sms_sender_id,
//             sms_api_endpoint,
//             sms_api_key,
//           } = smsSettingsResult.rows[0];

//           try {
//             const smsResponse = await send_sms(
//               sms_user_id,
//               sms_api_key,
//               sms_sender_id,
//               finalQuotationLink,
//               phone,
//               sms_api_endpoint
//             );

//             smsStatus = "sent";
//             console.log("SMS sent:", smsResponse);
//           } catch (smsError) {
//             smsStatus = "failed";
//             console.error("SMS sending failed:", smsError);
//           }
//         }
//       }

//       /* ===============================
//          4️⃣ ADMIN LOG
//       =============================== */
//       const module = "Quotations";
//       const logMessage = `Sent quotation ${quotation_id} by user ${user_id}`;
//       await insertAdminLog(user_id, module, logMessage);

//       /* ===============================
//          5️⃣ SUCCESS RESPONSE (CLEAR)
//       =============================== */
//       return res.json({
//         success: true,
//         message: "Quotation sent successfully",
//         // data: {
//         //   quotation_id,
//         //   quotation_link: finalQuotationLink,
//         //   email,
//         //   phone,
//         //   send_email,
//         //   send_mobile,
//         //   email_status: emailStatus,
//         //   sms_status: smsStatus,
//         //   customer_name,
//         // },
//       });

//     } catch (error) {
//       console.error("Error in send-qutationStatus:", error);
//       return res.status(500).json({ message: "Internal server error" });
//     } finally {
//       if (client) client.release();
//     }
//   }
// );

router.post("/send-qutationStatus", authenticateToken, async (req, res) => {
  const {
    quotation_id,
    email,
    phone,
    send_email,
    send_mobile,
    customer_name,
    quotation_link,
  } = req.body;

  const user_id = req.user.user_id;

  if (!quotation_id) {
    return res.status(400).json({ message: "quotation_id is required" });
  }

  let client;

  try {
    client = await pool.connect();

    /* ===============================
       1️⃣ UPDATE QUOTATION
    =============================== */
    const updateQuery = `
      UPDATE quotation_header
      SET
        status = 'sent',
        quotation_link = COALESCE($1, quotation_link),
        updated_at = NOW()
      WHERE id = $2
      RETURNING id, quotation_link
    `;

    const updateResult = await client.query(updateQuery, [
      quotation_link || null,
      quotation_id,
    ]);

    if (updateResult.rowCount === 0) {
      return res.status(404).json({
        success: false,
        message: "Quotation not found",
      });
    }

    /* ===============================
       2️⃣ TRIGGER CUSTOM HOOK
    =============================== */
    let hookResponse = null;

    try {
      hookResponse = await customhookQuotation(
        11, // quotation action id
        quotation_id,
        send_mobile ? phone : null,
        send_email ? email : null
      );
    } catch (hookError) {
      console.error("Custom hook failed:", hookError);
    }

    /* ===============================
       3️⃣ ADMIN LOG
    =============================== */
    const module = "Quotations";
    const logMessage = `Sent quotation ${quotation_id} by user ${user_id}`;
    await insertAdminLog(user_id, module, logMessage);

    /* ===============================
       4️⃣ SUCCESS RESPONSE
    =============================== */
    return res.json({
      success: true,
      message: "Quotation sent successfully",
      hookResponse,
    });

  } catch (error) {
    console.error("Error in send-qutationStatus:", error);
    return res.status(500).json({ message: "Internal server error" });
  } finally {
    if (client) client.release();
  }
});



router.post("/reject-quotation", authenticateToken, async (req, res) => {
  const { quotation_id } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  // Basic validation
  if (!quotation_id) {
    return res.status(400).json({
      message: "quotation_id is required",
    });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // 🔍 Check quotation exists
    const checkQuery = `
        SELECT id, status
        FROM quotation_header
        WHERE id = $1
      `;
    const checkResult = await client.query(checkQuery, [quotation_id]);

    if (checkResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        message: "Quotation not found",
      });
    }

    // ❌ Prevent invalid rejection
    if (checkResult.rows[0].status === "rejected") {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: "Quotation is already rejected",
      });
    }

    // ❌ Only allow rejection from pending or sent
    if (!["pending", "sent"].includes(checkResult.rows[0].status)) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: "Only pending or sent quotations can be rejected",
      });
    }

    // ✅ Update status to rejected
    const updateQuery = `
        UPDATE quotation_header
        SET
          status = 'rejected',
          updated_at = NOW()
        WHERE id = $1
        RETURNING id, status
      `;

    const updateResult = await client.query(updateQuery, [quotation_id]);

    // 📝 Insert admin log
    const module = "Quotations";
    const logMessage = `Rejected quotation ${quotation_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Quotation rejected successfully",
      data: updateResult.rows[0],
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Reject quotation error:", error);

    return res.status(500).json({
      message: "Failed to reject quotation",
    });
  } finally {
    client.release();
  }
}
);

router.post("/approve-qutationStatus", authenticateToken, async (req, res) => {
  const { quotation_id, status } = req.body;
  const user = req.user;
  const user_id = user.user_id;



  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // 🔍 Check quotation
    const checkQuery = `
        SELECT id, status
        FROM quotation_header
        WHERE id = $1
      `;
    const checkResult = await client.query(checkQuery, [quotation_id]);

    if (checkResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        message: "Quotation not found",
      });
    }



    // ✅ Update status
    const updateQuery = `
        UPDATE quotation_header
        SET
          status = $1,
          updated_at = NOW()
        WHERE id = $2
        RETURNING id, status
      `;

    const updateResult = await client.query(updateQuery, [
      status,
      quotation_id,
    ]);

    // 📝 Insert admin log
    const module = "Quotations";
    const logMessage = `Approved quotation ${quotation_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Quotation sent successfully",
      data: updateResult.rows[0],
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Send quotation error:", error);

    return res.status(500).json({
      message: "Failed to send quotation",
    });
  } finally {
    client.release();
  }
}
);

router.post("/cancel-qutationStatus", authenticateToken, async (req, res) => {
  const { order_id, status } = req.body;
  const user = req.user;
  const user_id = user.user_id;



  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // 🔍 Check quotation
    const checkQuery = `
        SELECT id, status
        FROM quotation_header
        WHERE id = $1
      `;
    const checkResult = await client.query(checkQuery, [order_id]);

    if (checkResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({
        message: "Quotation not found",
      });
    }



    // ✅ Update status
    const updateQuery = `
        UPDATE quotation_header
        SET
          status = $1,
          updated_at = NOW()
        WHERE id = $2
        RETURNING id, status
      `;

    const updateResult = await client.query(updateQuery, [
      status,
      order_id,
    ]);

    // 📝 Insert admin log
    const module = "Quotations";
    const logMessage = `Cancelled quotation ${order_id} by user ${user_id}`;

    await insertAdminLog(user_id, module, logMessage);

    await client.query("COMMIT");

    return res.status(200).json({
      message: "Quotation Cancelled successfully",
      data: updateResult.rows[0],
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Send quotation error:", error);

    return res.status(500).json({
      message: "Failed to send quotation",
    });
  } finally {
    client.release();
  }
}
);


router.post("/getCancelledRejectedQuotations", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 25,
      payment_status,
      date,
      todate,
      keyword,
      order_status,
    } = req.body;

    const parsedLimit = parseInt(limit, 10);
    const parsedPage = parseInt(page, 10);
    const offset = (parsedPage - 1) * parsedLimit;

    let queryParams = [];
    let whereConditions = [];

    // 🔍 Keyword search
    if (keyword) {
      const trimmedKeyword = keyword.trim();

      if (/^\d{10,11}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`c.contact_number_1 = $${queryParams.length}`);
      } else if (/^\d{1,9}$/.test(trimmedKeyword)) {
        queryParams.push(trimmedKeyword);
        whereConditions.push(`o.id = $${queryParams.length}`);
      } else {
        queryParams.push(`%${trimmedKeyword}%`);
        whereConditions.push(`o.sender_name ILIKE $${queryParams.length}`);
      }
    }

    // 📅 Date range
    if (date && todate) {
      queryParams.push(date, todate);
      whereConditions.push(
        `o.created_at::date BETWEEN $${queryParams.length - 1} AND $${queryParams.length}`
      );
    }

    // 💳 Payment status
    if (payment_status) {
      queryParams.push(payment_status);
      whereConditions.push(`o.status = $${queryParams.length}`);
    }

    queryParams.push("rejected", "cancelled");
    whereConditions.push(
      `o.status IN ($${queryParams.length - 1}, $${queryParams.length})`
    );



    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // 📄 Orders query
    const ordersQuery = `
      SELECT 
        o.id,
        o.customer_id,
        o.status,
        o.total_value,
        o.total_item,
        o.total_weight,
        o.currency,
        o.sender_name,
        o.sender_phone,
        o.sender_email,
        o.sender_address,
        o.sender_city,
        o.sender_postal_code,
        o.sender_country,
        o.discount,
        o.created_at,
        o.tax_percentage,
        o.tax,
        o.note,
        o.time_period,
        o.full_amount,
        c.first_name AS customer_name,
        ss.currency AS currency
      FROM quotation_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      LEFT JOIN system_settings ss ON ss.id = 1
      ${whereClause}
      ORDER BY o.created_at DESC
      LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2}
    `;

    const paginatedParams = [...queryParams, parsedLimit, offset];
    const { rows } = await pool.query(ordersQuery, paginatedParams);

    // 🔢 Total count
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM quotation_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      ${whereClause}
    `;

    const countResult = await pool.query(countQuery, queryParams);
    const total = parseInt(countResult.rows[0].total, 10);

    // 📝 Admin log (optional)
    // await insertAdminLog(req.user.id, "Viewed all orders");

    res.json({
      orders: rows,
      total,
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
    });
  } catch (err) {
    console.error("Error fetching orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});




router.post("/transfer-quotation",authenticateToken, async (req, res) => {
  const { id } = req.body

  const user = req.user
  const user_id = user.user_id
  const merchant_id = user.merchant_id
  const outlet_id = user.outlet_id

  const client = await pool.connect();

  try {
    const quotationHeader = `SELECT * FROM quotation_header WHERE id = $1`
    const quotationDetails = `SELECT * FROM quotation_details WHERE quotation_id = $1`

    const [quotationHeaderResult, quotationDetailsResult] = await Promise.all([
      pool.query(quotationHeader, [id]),
      pool.query(quotationDetails, [id])
    ])

    if (quotationHeaderResult.rows.length === 0 || quotationDetailsResult.rows.length === 0) {
      return res.status(404).json({ message: "Quotation not found" })
    }

    const header = quotationHeaderResult.rows[0]
    const details = quotationDetailsResult.rows

    await client.query("BEGIN");

    //admin merchant id
    const [adminDetails] = await Promise.all([
      adminUserDeatils(user_id)
    ])

    const username = adminDetails.username

    const orderQuery = `INSERT INTO invoice_header (user_id, customer_id, merchant_id, payment_method_id, order_status, total_value, amount_paid, total_item, total_weight, cod, payment_status, currency, sender_name, sender_phone, sender_email, sender_address, sender_city, sender_country, payment_reference,  delivery_fee, discount, tax_percentage, tax,  full_amount,  discount_type, loyalty_points_spent, bank_slip, loyalty_points_earned, inventory_deduct, sender_addrees_2) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30) RETURNING id`

    const OrderParms = [user_id, header.customer_id, merchant_id, null, 'pending', header.total_value, 0, header.total_item, 0, false, 'unpaid', header.currency, header.sender_name || '', header.sender_phone || '', header.sender_email || '', header.sender_address || '', header.sender_city || '', header.sender_country || '', header.note || '', 0, header.discount || 0, header.tax_percentage, header.tax, header.full_amount, header.discount_type, 0, '', 0, true, '']

    const orderResult = await client.query(orderQuery, OrderParms)

    if (orderResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "order not created" })
    }


    const orderItemParams = []
    const values = []

    details.forEach(async (product, i) => {

      const baseIndex = 15 * i;

      values.push(
        `($${baseIndex + 1}, $${baseIndex + 2}, $${baseIndex + 3}, $${baseIndex + 4},
                $${baseIndex + 5}, $${baseIndex + 6}, $${baseIndex + 7}, $${baseIndex + 8},
                $${baseIndex + 9}, $${baseIndex + 10}, $${baseIndex + 11}, $${baseIndex + 12},
                $${baseIndex + 13}, $${baseIndex + 14}, $${baseIndex + 15})`
      );

     
      orderItemParams.push(
        orderResult.rows[0].id,
        product.product_id ? product.product_id : null,
        product.variant_id,
        product.quantity,
        product.unit_price,
        product.total_price,
        0,
        product.is_free,                             // 8. is_free
        product.free_quantity,
        product.name || null,             // name
        product.description || null,       // description
        product.is_custom === true,         // is_custom
        product.amount_per_unit || null,   // amount_per_unit
        product.unit_type || null,
        product.discount
      );

      //inventory
      if (product.is_custom === false) {
        // console.log(product.variant_id);
        const searchInventoryQuery = `SELECT new_quantity FROM inventory WHERE variant_id = $1 AND outlet_id = $2 AND merchant_id = $3 AND status = 'active' ORDER BY inventory_id DESC LIMIT 1`;

        const insertInventoryQuery = `INSERT INTO public.inventory (
                variant_id, outlet_id, updated_by, comment, system_module, 
                previous_quantity, adjust_quantity, new_quantity, status, 
                merchant_id, user_id
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`;

        const searchInventoryResult = await client.query(searchInventoryQuery, [
          product.variant_id,
          outlet_id,
          merchant_id
        ]);

        let previous_quantity = 0;

        if (searchInventoryResult.rows.length > 0) {
          previous_quantity = searchInventoryResult.rows[0].new_quantity;
        }

        const total_free = product.unit_type == 1 ? product.free_quantity : Number(product.free_quantity) * Number(product.amount_per_unit)
        const current_qty = product.unit_type == 1 ? product.quantity : Number(product.quantity) * Number(product.amount_per_unit)
        const total_qty = current_qty + total_free

        const new_quantity = Number(previous_quantity) - Number(total_qty);

        const insertInventoryResult = await pool.query(insertInventoryQuery, [
          product.variant_id,
          outlet_id,
          username,
          `Invoice(${orderResult.rows[0].id}) stock out`,
          "stock out",
          previous_quantity,
          -total_qty,
          new_quantity,
          "active",
          merchant_id,
          user_id
        ]);

        if (insertInventoryResult.rowCount === 0) {
          await client.query("ROLLBACK");
          return res.status(400).json({ message: "Inventory not updated" })
        }
      }


    });


    //add order items 
    const orderItemQuery = `INSERT INTO invoice_details (invoice_id, product_id, variant_id, quantity, unit_price, total_price, item_weight, is_free, free_quantity, name, description, is_custom, amount_per_unit, unit_type, discount) VALUES ${values.join(',')}`


    const orderItemResult = await client.query(orderItemQuery, orderItemParams)

    if (orderItemResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Order item not added" })
    }

    if (header.discount_id) {
      
      const discountUsageQuery = `INSERT INTO discount_usage (order_id, discount_id, user_id, type) VALUES ($1, $2, $3, $4)`

      const discountUsageResult = await client.query(discountUsageQuery, [orderResult.rows[0].id, header.discount_id || null, header.customer_id, 'invoice'])

      if (discountUsageResult.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(400).json({ message: "Discount usage not added" })
      }
    }

    const updateQuotation = `UPDATE quotation_header SET status = 'transferred', invoice_id = $2 WHERE id = $1`
    const updateQuotationResult = await client.query(updateQuotation, [id, orderResult.rows[0].id])

    if (updateQuotationResult.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(400).json({ message: "Invoice not updated" })
    }

    await client.query("COMMIT");

    const module = "Invoive";
    const logMessage = `New invoice #${orderResult.rows[0].id} has been placed by user ${user_id}`;


    const adminnoti = await insertAdminLog(user_id, module, logMessage)


    return res.status(200).json({ message: "success" });
  } catch (error) {
    await client.query("ROLLBACK");
    console.log(error)
    return res.status(500).json({ message: error.message || "Internal server error" })
  } finally {
    client.release();
  }
})

router.post("/print-catelog", async (req, res) => {
  const { id } = req.body

  const client = await pool.connect();

  try {
    const quotationHeader = `SELECT * FROM quotation_header WHERE id = $1`
    const quotationDetails = `SELECT q.product_id, p.title, p.description, pm.media_url AS main_img
                              FROM quotation_details q
                              LEFT JOIN products p ON p.product_id = q.product_id
                              LEFT JOIN product_media pm ON pm.product_id = p.product_id AND pm.main = true AND pm.variant_id IS NULL 
                              WHERE q.quotation_id = $1 AND q.is_custom = false`

    const quotationDetailsResult = await pool.query(quotationDetails, [id])

    if (quotationDetailsResult.rows.length === 0) {
      return res.status(404).json({ message: "Quotation not found" })
    }

    const details = quotationDetailsResult.rows

    return res.status(200).json({ message: "success", details });
  } catch (error) {
    await client.query("ROLLBACK");
    console.log(error)
    return res.status(500).json({ message: error.message || "Internal server error" })
  } 
})













module.exports = router;
