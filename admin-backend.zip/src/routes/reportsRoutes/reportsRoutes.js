const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

// get brands active

router.get("/get-brands", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT brand_id, name 
      FROM brand
      WHERE status = 'active'
      ORDER BY name ASC
    `;

    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching brands:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// get active collections
router.get("/get-collections", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT collection_id, name
      FROM collections
      WHERE status = 'active'
      ORDER BY name ASC
    `;

    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching collections:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// filter sales reports route
router.post("/filtered-sales-report", authenticateToken, async (req, res) => {
  try {
    const { date_from, date_to, collection_ids, category_ids, product_id } =
      req.body || {};

    const merchant_id = req.user?.merchant_id;

    const parseIds = (val) => {
      if (!val && val !== 0) return [];
      if (Array.isArray(val)) return val.map(Number).filter(Number.isFinite);
      if (typeof val === "string")
        return val
          .split(",")
          .map((s) => Number(s.trim()))
          .filter(Number.isFinite);
      if (typeof val === "number") return [val];
      return [];
    };

    const collIds = parseIds(collection_ids);
    const catIds = parseIds(category_ids);
    const productId = Number(product_id);

    const allowedStatuses = [
      "confirmed",
      "completed",
      "dispatched",
      "processing",
    ];

    // ================= SALES FILTER =================
    const whereSales = [];
    const paramsSales = [];
    const addSales = (v) => {
      paramsSales.push(v);
      return paramsSales.length;
    };

    let idx = addSales(allowedStatuses);
    whereSales.push(`o.order_status = ANY($${idx}::text[])`);

    if (merchant_id) {
      idx = addSales(Number(merchant_id));
      whereSales.push(`o.merchant_id = $${idx}`);
    }

    if (date_from) {
      idx = addSales(date_from);
      whereSales.push(`o.created_at >= $${idx}::timestamp`);
    }

    if (date_to) {
      idx = addSales(date_to);
      whereSales.push(`o.created_at < ($${idx}::timestamp + interval '1 day')`);
    }

    if (collIds.length) {
      idx = addSales(collIds);
      whereSales.push(`pc.collection_id = ANY($${idx}::int[])`);
    }

    if (catIds.length) {
      idx = addSales(catIds);
      whereSales.push(`pg.category_id = ANY($${idx}::int[])`);
    }

    const WHERE_SALES_SQL = whereSales.length
      ? `WHERE ${whereSales.join(" AND ")}`
      : "";

    // ================= MAIN QUERY (UNCHANGED) =================
    const sql = `
      WITH sales_raw AS (
        SELECT
          oi.product_id,
          oi.variant_id,
          p.title AS product_title,
          pv.variant_value,
          SUM(oi.total_price)::double precision AS total_sales_amount,
          SUM(oi.quantity)::bigint AS sales_quantity,
          SUM(oi.quantity)::bigint AS order_quantity,
          MAX(o.order_id) AS latest_order_id
        FROM order_items oi
        JOIN orders o ON o.order_id = oi.order_id
        LEFT JOIN products p ON p.product_id = oi.product_id
        LEFT JOIN product_variants pv ON pv.variant_id = oi.variant_id
        LEFT JOIN product_collections pc ON pc.product_id = oi.product_id
        LEFT JOIN product_category pg ON pg.product_id = oi.product_id
        ${WHERE_SALES_SQL}
        GROUP BY oi.product_id, oi.variant_id, p.title, pv.variant_value
      ),

      invoice_sales_raw AS (
        SELECT
          idt.product_id,
          idt.variant_id,
          SUM((idt.quantity * idt.unit_price) - COALESCE(idt.discount,0))::double precision AS total_sales_amount,
          SUM(idt.quantity)::bigint AS sales_quantity,
          SUM(idt.quantity)::bigint AS order_quantity
        FROM invoice_details idt
        JOIN invoice_header ih ON ih.id = idt.invoice_id
        WHERE ih.order_status NOT IN ('cancelled','draft','hold','delete')
        GROUP BY idt.product_id, idt.variant_id
      ),

      order_returns AS (
        SELECT
          oi.product_id,
          oi.variant_id,
          SUM(oi.quantity)::bigint AS returned_items_quantity
        FROM order_items oi
        JOIN orders o ON o.order_id = oi.order_id
        WHERE o.order_status = 'returned'
        GROUP BY oi.product_id, oi.variant_id
      ),

      invoice_returns AS (
        SELECT
          idt.product_id,
          idt.variant_id,
          SUM(COALESCE(idt.return_qty,0))::bigint AS returned_items_quantity
        FROM invoice_details idt
        WHERE COALESCE(idt.return_qty,0) > 0
        GROUP BY idt.product_id, idt.variant_id
      ),

      returns_agg AS (
        SELECT
          product_id,
          variant_id,
          SUM(returned_items_quantity) AS returned_items_quantity
        FROM (
          SELECT * FROM order_returns
          UNION ALL
          SELECT * FROM invoice_returns
        ) r
        GROUP BY product_id, variant_id
      ),

      variant_totals AS (
        SELECT
          s.product_id,
          s.variant_id,
          s.product_title,
          s.variant_value,
          s.total_sales_amount + COALESCE(i.total_sales_amount,0) AS total_sales_amount,
          s.sales_quantity + COALESCE(i.sales_quantity,0) AS sales_quantity,
          s.order_quantity + COALESCE(i.order_quantity,0) AS order_quantity,
          COALESCE(r.returned_items_quantity,0) AS returned_items_quantity,
          s.latest_order_id
        FROM sales_raw s
        LEFT JOIN invoice_sales_raw i
          ON i.product_id = s.product_id
          AND i.variant_id = s.variant_id
        LEFT JOIN returns_agg r
          ON r.product_id = s.product_id
          AND r.variant_id = s.variant_id
      ),

      product_totals AS (
        SELECT
          product_id,
          MAX(product_title) AS product_title,
          SUM(total_sales_amount) AS product_total_sales_amount,
          SUM(sales_quantity) AS product_total_sales_quantity,
          SUM(order_quantity) AS product_total_order_quantity,
          SUM(returned_items_quantity) AS product_returned_items_quantity,
          MAX(latest_order_id) AS latest_order_id
        FROM variant_totals
        GROUP BY product_id
      )

      SELECT
        pt.product_id,
        pt.product_title AS title,
        pt.product_total_sales_amount,
        pt.product_total_sales_quantity,
        pt.product_total_order_quantity,
        pt.product_returned_items_quantity,
        json_agg(
          json_build_object(
            'variant_id', vt.variant_id,
            'variant_value', vt.variant_value,
            'total_sales_amount', vt.total_sales_amount,
            'sales_quantity', vt.sales_quantity,
            'order_quantity', vt.order_quantity,
            'returned_items_quantity', vt.returned_items_quantity
          )
        ) AS variants
      FROM product_totals pt
      JOIN variant_totals vt ON vt.product_id = pt.product_id
      GROUP BY pt.product_id,
               pt.product_title,
               pt.product_total_sales_amount,
               pt.product_total_sales_quantity,
               pt.product_total_order_quantity,
               pt.product_returned_items_quantity,
               pt.latest_order_id
      ORDER BY pt.latest_order_id DESC NULLS LAST;
    `;

    const result = await pool.query(sql, paramsSales);
    let products = result.rows || [];

    // ================= PRODUCT FILTER (ONLY IF SENT) =================
    if (product_id !== null && product_id !== undefined) {
      if (Number.isFinite(productId)) {
        products = products.filter((p) => Number(p.product_id) === productId);
      }
    }

    const sales_report_summary = {
      total_ordered_qty: products.reduce(
        (s, p) => s + Number(p.product_total_order_quantity || 0),
        0,
      ),
      total_sales_qty: products.reduce(
        (s, p) => s + Number(p.product_total_sales_quantity || 0),
        0,
      ),
      total_returned_qty: products.reduce(
        (s, p) => s + Number(p.product_returned_items_quantity || 0),
        0,
      ),
      total_sales_amount: products.reduce(
        (s, p) => s + Number(p.product_total_sales_amount || 0),
        0,
      ),
    };

    res.json({
      products,
      pagination: null,
      sales_report_summary,
    });
  } catch (err) {
    console.error("Error fetching filtered sales report:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
// sales summary reports
router.post("/sales-summary-card1", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      // inclusive end: < date_to + 1 day
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
    `;

    // Currency: read global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "orders_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching orders_overview:", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// summary card 2
router.post("/sales-summary-card2", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    // Merchant scope
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // ✅ Only orders with payment method = 'COD'
    where.push(`LOWER(pm.method_name) = 'cod'`);

    // Date filters (inclusive end day)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      JOIN payment_methods pm ON pm.payment_method_id = o.payment_method_id
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "cod_cash_on_delivery_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card2 (COD):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 3
router.post("/sales-summary-card3", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    // Merchant scope
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // ✅ Only orders with payment method = 'cash'
    where.push(`LOWER(pm.method_name) = 'cash'`);

    // Dates (inclusive end)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      JOIN payment_methods pm ON pm.payment_method_id = o.payment_method_id
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "store_pickup_overview", // unchanged
      currency,
      filters: { date_from: date_from || null, date_to: date_to || null },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error(
      "Error fetching sales-summary-card3 (Cash Payment Orders):",
      err,
    );
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 4
router.post("/sales-summary-card4", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    // Scope to merchant
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // Date filters (inclusive end on date_to)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // Use a CTE to grab Stripe payment_method ids (case-insensitive)
    const overviewSql = `
      WITH stripe_methods AS (
        SELECT pm.payment_method_id
        FROM payment_methods pm
        WHERE LOWER(pm.method_name) = 'stripe'
      )
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
        AND o.payment_method_id IN (SELECT payment_method_id FROM stripe_methods)
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "stripe_payment_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card4 (Stripe):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 5
router.post("/sales-summary-card5", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    // Scope to merchant
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // Dates (inclusive end on date_to)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // CTE for PayHere payment methods (case-insensitive)
    const overviewSql = `
      WITH payhere_methods AS (
        SELECT pm.payment_method_id
        FROM payment_methods pm
        WHERE LOWER(pm.method_name) = 'payhere'
      )
      SELECT
        ARRAY_AGG(o.order_id) AS order_ids,
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
        AND o.payment_method_id IN (SELECT payment_method_id FROM payhere_methods)
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "payhere_payment_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        order_ids: r.order_ids || [],
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card5 (PayHere):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 6
router.post("/sales-summary-card6", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // Join to payment_methods and match Bank Transfer variants
    const overviewSql = `
      SELECT
        ARRAY_AGG(o.order_id) AS order_ids,
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      INNER JOIN payment_methods pm
        ON pm.payment_method_id = o.payment_method_id
       AND LOWER(pm.method_name) IN ('bank', 'bank transfer', 'bank_transfer', 'banktransfer')
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "bank_transfer_payment_summary",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        order_ids: r.order_ids || [],
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card6 (Bank Transfer):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

router.get("/report-product-search", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;

  const raw = (req.query.q || req.query.search || "").toString();
  const search = raw.trim();

  // Require minimum 2 chars
  if (search.length < 2) {
    return res.status(400).json({
      success: false,
      error: "Search query must be at least 2 characters long.",
    });
  }

  try {
    /**
     * 1️⃣ Exact numeric search
     * Matches:
     * - product_id
     * - variant_id
     */
    if (/^\d+$/.test(search)) {
      const exactSql = `
        SELECT DISTINCT
          p.product_id,
          p.title,
          pv.variant_id,
          pv.barcode
        FROM products p
        LEFT JOIN product_variants pv
          ON pv.product_id = p.product_id
        WHERE p.merchant_id = $1
          AND p.status = 'active'
          AND (
            p.product_id = $2
            OR pv.variant_id = $2
          )
        ORDER BY p.title ASC
        LIMIT 20;
      `;

      const exactResult = await pool.query(exactSql, [
        merchant_id,
        Number(search),
      ]);

      if (exactResult.rows.length > 0) {
        return res.json({
          success: true,
          products: exactResult.rows,
        });
      }
    }

    /**
     * 2️⃣ Fuzzy search
     * Matches:
     * - product title
     * - product_id
     * - variant_id
     * - barcode
     * - similar_keywords
     */
    const fuzzySql = `
      SELECT DISTINCT
        p.product_id,
        p.title,
        pv.variant_id,
        pv.barcode
      FROM products p
      LEFT JOIN product_variants pv
        ON pv.product_id = p.product_id
      WHERE p.merchant_id = $1
        AND p.status = 'active'
        AND (
          LOWER(p.title) LIKE '%' || LOWER($2) || '%'
          OR CAST(p.product_id AS TEXT) LIKE '%' || $2 || '%'
          OR CAST(pv.variant_id AS TEXT) LIKE '%' || $2 || '%'
          OR LOWER(pv.barcode) LIKE '%' || LOWER($2) || '%'
          OR EXISTS (
            SELECT 1
            FROM unnest(p.similar_keywords) kw
            WHERE LOWER(kw) LIKE '%' || LOWER($2) || '%'
          )
        )
      ORDER BY p.title ASC
      LIMIT 20;
    `;

    const result = await pool.query(fuzzySql, [merchant_id, search]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No active products found matching "${search}".`,
      });
    }

    return res.json({
      success: true,
      products: result.rows,
    });
  } catch (error) {
    console.error("Product search error:", error);
    return res.status(500).json({
      success: false,
      error: "Server error while searching products.",
    });
  }
});

// moving report | slow moving fast moving products

router.post("/product-moving-report", authenticateToken, async (req, res) => {
  try {
    const {
      date_from,
      date_to,
      product_id,
      variant_id,
      sort_by = "fast_moving",
      page = 1,
      limit = 25,
    } = req.body || {};

    const offset = (page - 1) * limit;

    // ================= SORT =================
    let orderClause = "total_sold_qty DESC"; // default: fast_moving

    if (sort_by === "slow_moving") {
      orderClause = "total_sold_qty ASC";
    } else if (sort_by === "amount_high") {
      orderClause = "total_sales_amount DESC";
    } else if (sort_by === "amount_low") {
      orderClause = "total_sales_amount ASC"; // ✅ FIX ADDED
    }

    // ================= FILTERS =================
    let filters = [];
    let values = [];

    // Date filters are optional — only apply when provided
    if (date_from && date_to) {
      values.push(date_from, date_to);
      const idx = values.length;
      // Applied inside each CTE via a helper flag
    }

    if (product_id) {
      values.push(product_id);
      filters.push(`t.product_id = $${values.length}`);
    }

    if (variant_id) {
      values.push(variant_id);
      filters.push(`t.variant_id = $${values.length}`);
    }

    const filterSQL = filters.length ? `AND ${filters.join(" AND ")}` : "";

    // Build date condition for CTEs — empty string means no date restriction
    let datePlaceholders = { from: null, to: null };
    let orderDateFilter = "";
    let invoiceDateFilter = "";

    if (date_from && date_to) {
      // $1 = date_from, $2 = date_to (always first two when present)
      orderDateFilter = "AND o.created_at BETWEEN $1 AND $2";
      invoiceDateFilter = "AND ih.created_at BETWEEN $1 AND $2";
    }

    // ================= QUERY =================
    const sql = `
      WITH order_sales AS (
        SELECT
          oi.product_id,
          oi.variant_id,
          SUM(oi.total_price)::double precision AS sales_amount,
          SUM(oi.quantity)::bigint AS sold_qty
        FROM order_items oi
        JOIN orders o ON o.order_id = oi.order_id
        WHERE o.order_status IN ('confirmed','completed','dispatched','processing')
          ${orderDateFilter}
        GROUP BY oi.product_id, oi.variant_id
      ),

      invoice_sales AS (
        SELECT
          idt.product_id,
          idt.variant_id,
          SUM((idt.quantity * idt.unit_price) - COALESCE(idt.discount, 0))::double precision AS sales_amount,
          SUM(idt.quantity)::bigint AS sold_qty
        FROM invoice_details idt
        JOIN invoice_header ih ON ih.id = idt.invoice_id
        WHERE ih.order_status NOT IN ('cancelled','draft','hold','delete')
          ${invoiceDateFilter}
        GROUP BY idt.product_id, idt.variant_id
      ),

      combined AS (
        SELECT * FROM order_sales
        UNION ALL
        SELECT * FROM invoice_sales
      ),

      aggregated AS (
        SELECT
          product_id,
          variant_id,
          SUM(sales_amount) AS total_sales_amount,
          SUM(sold_qty)     AS total_sold_qty
        FROM combined
        WHERE product_id IS NOT NULL
        GROUP BY product_id, variant_id
      ),

      final_data AS (
        SELECT
          t.product_id,
          p.title,

          t.variant_id,
          pv.variant_value,
          pv.variant_type,

          m.measurement_value,

          t.total_sales_amount,
          t.total_sold_qty

        FROM aggregated t

        LEFT JOIN products p
          ON p.product_id = t.product_id

        LEFT JOIN product_variants pv
          ON pv.variant_id = t.variant_id
          AND pv.status = 'active'

        LEFT JOIN measurements m
          ON m.measurement_id = p.measurement_id

        WHERE 1=1
        ${filterSQL}
      )

      SELECT *,
        (SELECT COUNT(*) FROM final_data) AS total_count
      FROM final_data
    ORDER BY ${orderClause}
      LIMIT ${limit} OFFSET ${offset};
    `;

    const result = await pool.query(sql, values);
    const rows = result.rows || [];

    const total_count = Number(rows[0]?.total_count || 0);

    const summary = {
      total_items: total_count,
      total_pages: Math.ceil(total_count / limit),
      current_page: Number(page),
      total_sold_qty: rows.reduce(
        (s, r) => s + Number(r.total_sold_qty || 0),
        0,
      ),
      total_sales_amount: rows.reduce(
        (s, r) => s + Number(r.total_sales_amount || 0),
        0,
      ),
    };

    res.json({
      data: rows,
      summary,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
        product_id: product_id || null,
        variant_id: variant_id || null,
        sort_by,
        page,
        limit,
      },
    });
  } catch (err) {
    console.error("Error fetching moving report:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
module.exports = router;
