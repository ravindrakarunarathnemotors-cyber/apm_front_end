const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

// get brands active

router.get("/get-brands", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT brand_id, name 
      FROM brand
      WHERE status = 'active'
      ORDER BY name ASC
    `;

    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching brands:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// get active collections
router.get("/get-collections", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT collection_id, name
      FROM collections
      WHERE status = 'active'
      ORDER BY name ASC
    `;

    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (err) {
    console.error("Error fetching collections:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// filter sales reports route

// product based revenue
router.post("/filtered-sales-report", authenticateToken, async (req, res) => {
  try {
    const {
      date_from,
      date_to,
      collection_ids,
      category_ids,
      brand_ids,
      outlet_ids,
      product_ids,
    } = req.body || {};

    const merchant_id = req.user?.merchant_id;

    // =====================================================
    // HELPERS
    // =====================================================

    const parseIds = (value) => {
      if (value === null || value === undefined || value === "") {
        return [];
      }

      if (Array.isArray(value)) {
        return value.map(Number).filter(Number.isFinite);
      }

      if (typeof value === "string") {
        return value
          .split(",")
          .map((item) => Number(item.trim()))
          .filter(Number.isFinite);
      }

      if (typeof value === "number") {
        return Number.isFinite(value) ? [value] : [];
      }

      return [];
    };

    const makeVariantKey = (productId, variantId) => {
      return `${Number(productId)}:${
        variantId === null || variantId === undefined
          ? "null"
          : Number(variantId)
      }`;
    };

    const collectionIds = parseIds(collection_ids);

    const categoryIds = parseIds(category_ids);

    const brandIds = parseIds(brand_ids);

    const outletIds = parseIds(outlet_ids);

    const productIds = parseIds(product_ids);

    const allowedOrderStatuses = [
      "confirmed",
      "completed",
      "dispatched",
      "processing",
      "returned",
    ];

    // =====================================================
    // ORDER FILTERS
    // =====================================================

    const orderParams = [];

    const addOrderParam = (value) => {
      orderParams.push(value);
      return orderParams.length;
    };

    const orderConditions = [];

    let orderIndex = addOrderParam(allowedOrderStatuses);

    orderConditions.push(`o.order_status = ANY($${orderIndex}::text[])`);

    if (merchant_id) {
      orderIndex = addOrderParam(Number(merchant_id));

      orderConditions.push(`o.merchant_id = $${orderIndex}`);
    }

    if (date_from) {
      orderIndex = addOrderParam(date_from);

      orderConditions.push(`o.created_at >= $${orderIndex}::timestamp`);
    }

    if (date_to) {
      orderIndex = addOrderParam(date_to);

      orderConditions.push(`
          o.created_at <
          ($${orderIndex}::timestamp + INTERVAL '1 day')
        `);
    }

    if (collectionIds.length > 0) {
      orderIndex = addOrderParam(collectionIds);

      orderConditions.push(`
          EXISTS (
            SELECT 1
            FROM product_collections pc_filter
            WHERE pc_filter.product_id = oi.product_id
              AND pc_filter.collection_id =
                  ANY($${orderIndex}::int[])
          )
        `);
    }

    if (categoryIds.length > 0) {
      orderIndex = addOrderParam(categoryIds);

      orderConditions.push(`
          EXISTS (
            SELECT 1
            FROM product_category pg_filter
            WHERE pg_filter.product_id = oi.product_id
              AND pg_filter.category_id =
                  ANY($${orderIndex}::int[])
          )
        `);
    }

    if (brandIds.length > 0) {
      orderIndex = addOrderParam(brandIds);

      orderConditions.push(`
      EXISTS (
  SELECT 1
  FROM product_brands pb_filter
  WHERE pb_filter.product_id = oi.product_id
    AND pb_filter.brand_id = ANY($${orderIndex}::int[])
    AND pb_filter.status = 'active'
)
        `);
    }

    if (outletIds.length > 0) {
      orderIndex = addOrderParam(outletIds);

      orderConditions.push(`o.outlet_id = ANY($${orderIndex}::int[])`);
    }

    if (productIds.length > 0) {
      orderIndex = addOrderParam(productIds);

      orderConditions.push(`oi.product_id = ANY($${orderIndex}::int[])`);
    }

    const orderWhereSql =
      orderConditions.length > 0
        ? `WHERE ${orderConditions.join(" AND ")}`
        : "";

    // =====================================================
    // INVOICE FILTERS
    // Header filters run before calculation.
    // Product filters run after invoice totals are calculated.
    // =====================================================

    const invoiceParams = [];

    const addInvoiceParam = (value) => {
      invoiceParams.push(value);
      return invoiceParams.length;
    };

    const invoiceHeaderConditions = [
      `
    LOWER(COALESCE(ih.order_status, ''))
    NOT IN (
      'cancelled',
      'draft',
      'hold',
      'delete'
    )
  `,
    ];

    const invoiceItemConditions = [];

    let invoiceIndex;

    if (merchant_id) {
      invoiceIndex = addInvoiceParam(Number(merchant_id));

      invoiceHeaderConditions.push(`ih.merchant_id = $${invoiceIndex}`);
    }

    if (date_from) {
      invoiceIndex = addInvoiceParam(date_from);

      invoiceHeaderConditions.push(
        `ih.created_at >= $${invoiceIndex}::timestamp`,
      );
    }

    if (date_to) {
      invoiceIndex = addInvoiceParam(date_to);

      invoiceHeaderConditions.push(`
    ih.created_at <
    ($${invoiceIndex}::timestamp + INTERVAL '1 day')
  `);
    }

    if (outletIds.length > 0) {
      invoiceIndex = addInvoiceParam(outletIds);

      invoiceHeaderConditions.push(
        `ih.outlet_id = ANY($${invoiceIndex}::int[])`,
      );
    }

    if (collectionIds.length > 0) {
      invoiceIndex = addInvoiceParam(collectionIds);

      invoiceItemConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_collections pc_filter
      WHERE pc_filter.product_id = item.product_id
        AND pc_filter.collection_id =
            ANY($${invoiceIndex}::int[])
    )
  `);
    }

    if (categoryIds.length > 0) {
      invoiceIndex = addInvoiceParam(categoryIds);

      invoiceItemConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_category pg_filter
      WHERE pg_filter.product_id = item.product_id
        AND pg_filter.category_id =
            ANY($${invoiceIndex}::int[])
    )
  `);
    }

    if (brandIds.length > 0) {
      invoiceIndex = addInvoiceParam(brandIds);

      invoiceItemConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_brands pb_filter
      WHERE pb_filter.product_id = item.product_id
        AND pb_filter.brand_id =
            ANY($${invoiceIndex}::int[])
        AND pb_filter.status = 'active'
    )
  `);
    }

    if (productIds.length > 0) {
      invoiceIndex = addInvoiceParam(productIds);

      invoiceItemConditions.push(
        `item.product_id = ANY($${invoiceIndex}::int[])`,
      );
    }

    const invoiceHeaderWhereSql = `
  WHERE ${invoiceHeaderConditions.join(" AND ")}
`;

    const invoiceItemWhereSql =
      invoiceItemConditions.length > 0
        ? `WHERE ${invoiceItemConditions.join(" AND ")}`
        : "";
    // =====================================================
    // ORDER RETURN FILTERS
    // =====================================================

    const orderReturnParams = [];

    const addOrderReturnParam = (value) => {
      orderReturnParams.push(value);
      return orderReturnParams.length;
    };

    const orderReturnConditions = [
      `
          LOWER(COALESCE(o.order_status, ''))
          = 'returned'
        `,
    ];

    let orderReturnIndex;

    if (merchant_id) {
      orderReturnIndex = addOrderReturnParam(Number(merchant_id));

      orderReturnConditions.push(`o.merchant_id = $${orderReturnIndex}`);
    }

    if (date_from) {
      orderReturnIndex = addOrderReturnParam(date_from);

      orderReturnConditions.push(
        `o.created_at >= $${orderReturnIndex}::timestamp`,
      );
    }

    if (date_to) {
      orderReturnIndex = addOrderReturnParam(date_to);

      orderReturnConditions.push(`
          o.created_at <
          ($${orderReturnIndex}::timestamp + INTERVAL '1 day')
        `);
    }

    if (collectionIds.length > 0) {
      orderReturnIndex = addOrderReturnParam(collectionIds);

      orderReturnConditions.push(`
          EXISTS (
            SELECT 1
            FROM product_collections pc_filter
            WHERE pc_filter.product_id = oi.product_id
              AND pc_filter.collection_id =
                  ANY($${orderReturnIndex}::int[])
          )
        `);
    }

    if (categoryIds.length > 0) {
      orderReturnIndex = addOrderReturnParam(categoryIds);

      orderReturnConditions.push(`
          EXISTS (
            SELECT 1
            FROM product_category pg_filter
            WHERE pg_filter.product_id = oi.product_id
              AND pg_filter.category_id =
                  ANY($${orderReturnIndex}::int[])
          )
        `);
    }

    if (brandIds.length > 0) {
      orderReturnIndex = addOrderReturnParam(brandIds);

      orderReturnConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_brands pb_filter
      WHERE pb_filter.product_id = oi.product_id
        AND pb_filter.brand_id =
            ANY($${orderReturnIndex}::int[])
        AND pb_filter.status = 'active'
    )
  `);
    }

    if (outletIds.length > 0) {
      orderReturnIndex = addOrderReturnParam(outletIds);

      orderReturnConditions.push(
        `o.outlet_id = ANY($${orderReturnIndex}::int[])`,
      );
    }

    if (productIds.length > 0) {
      orderReturnIndex = addOrderReturnParam(productIds);

      orderReturnConditions.push(
        `oi.product_id = ANY($${orderReturnIndex}::int[])`,
      );
    }

    const orderReturnWhereSql = `WHERE ${orderReturnConditions.join(" AND ")}`;

    // =====================================================
    // INVOICE RETURN FILTERS
    // Uses return_token.date as the actual return date.
    // =====================================================

    const invoiceReturnParams = [];

    const addInvoiceReturnParam = (value) => {
      invoiceReturnParams.push(value);
      return invoiceReturnParams.length;
    };

    const invoiceReturnConditions = [
      `rt.status = 'active'`,
      `jsonb_typeof(rt.returned_items) = 'array'`,
      `
    COALESCE(
      NULLIF(return_item.item->>'return_qty', '')::numeric,
      0
    ) > 0
  `,
      `
    LOWER(COALESCE(ih.order_status, ''))
    NOT IN (
      'cancelled',
      'draft',
      'hold',
      'delete'
    )
  `,
    ];

    let invoiceReturnIndex;

    if (merchant_id) {
      invoiceReturnIndex = addInvoiceReturnParam(Number(merchant_id));

      invoiceReturnConditions.push(`ih.merchant_id = $${invoiceReturnIndex}`);
    }

    // IMPORTANT:
    // Filter by actual return-token date, not original invoice date.
    if (date_from) {
      invoiceReturnIndex = addInvoiceReturnParam(date_from);

      invoiceReturnConditions.push(
        `rt.date >= $${invoiceReturnIndex}::timestamp`,
      );
    }

    if (date_to) {
      invoiceReturnIndex = addInvoiceReturnParam(date_to);

      invoiceReturnConditions.push(`
    rt.date <
    ($${invoiceReturnIndex}::timestamp + INTERVAL '1 day')
  `);
    }

    if (collectionIds.length > 0) {
      invoiceReturnIndex = addInvoiceReturnParam(collectionIds);

      invoiceReturnConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_collections pc_filter
      WHERE pc_filter.product_id =
        NULLIF(
          return_item.item->>'product_id',
          ''
        )::int
        AND pc_filter.collection_id =
          ANY($${invoiceReturnIndex}::int[])
    )
  `);
    }

    if (categoryIds.length > 0) {
      invoiceReturnIndex = addInvoiceReturnParam(categoryIds);

      invoiceReturnConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_category pg_filter
      WHERE pg_filter.product_id =
        NULLIF(
          return_item.item->>'product_id',
          ''
        )::int
        AND pg_filter.category_id =
          ANY($${invoiceReturnIndex}::int[])
    )
  `);
    }

    if (brandIds.length > 0) {
      invoiceReturnIndex = addInvoiceReturnParam(brandIds);

      invoiceReturnConditions.push(`
    EXISTS (
      SELECT 1
      FROM product_brands pb_filter
      WHERE pb_filter.product_id =
        NULLIF(
          return_item.item->>'product_id',
          ''
        )::int
        AND pb_filter.brand_id =
          ANY($${invoiceReturnIndex}::int[])
        AND pb_filter.status = 'active'
    )
  `);
    }

    if (outletIds.length > 0) {
      invoiceReturnIndex = addInvoiceReturnParam(outletIds);

      invoiceReturnConditions.push(`
    COALESCE(
      NULLIF(
        return_item.item->>'outlet_id',
        ''
      )::int,
      ih.outlet_id
    ) = ANY($${invoiceReturnIndex}::int[])
  `);
    }

    if (productIds.length > 0) {
      invoiceReturnIndex = addInvoiceReturnParam(productIds);

      invoiceReturnConditions.push(`
    NULLIF(
      return_item.item->>'product_id',
      ''
    )::int = ANY($${invoiceReturnIndex}::int[])
  `);
    }

    const invoiceReturnWhereSql = `
  WHERE ${invoiceReturnConditions.join(" AND ")}
`;
    // =====================================================
    // ORDER QUERY
    // Reads only orders and order_items
    // =====================================================

    const orderSql = `
  WITH eligible_order_items AS (
    SELECT
    o.order_id,
o.full_amount,

-- Order value before delivery, tax and other additions.
COALESCE(o.total_value, 0)::numeric
  AS order_base_total,

      oi.product_id,
      oi.variant_id,
      oi.quantity,
      oi.total_price,

      p.title AS product_title,

      COALESCE(
        pv.variant_value,
        'Default'
      ) AS variant_value,

      SUM(
        COALESCE(oi.total_price, 0)
      ) OVER (
        PARTITION BY o.order_id
      ) AS order_items_total

    FROM order_items oi

    JOIN orders o
      ON o.order_id = oi.order_id

    LEFT JOIN products p
      ON p.product_id = oi.product_id

    LEFT JOIN product_variants pv
      ON pv.variant_id = oi.variant_id

    ${orderWhereSql}
  )

  SELECT
    product_id,
    variant_id,
    product_title,
    variant_value,

    SUM(
      COALESCE(quantity, 0)
    )::bigint AS order_quantity,

    SUM(
  CASE
    WHEN COALESCE(order_items_total, 0) > 0
    THEN
      COALESCE(order_base_total, 0)
      *
      (
        COALESCE(total_price, 0)
        / order_items_total
      )
    ELSE 0
  END
)::double precision AS order_base_amount,

    SUM(
      CASE
        WHEN COALESCE(order_items_total, 0) > 0
        THEN
          COALESCE(full_amount, 0)
          *
          (
            COALESCE(total_price, 0)
            / order_items_total
          )

        ELSE 0
      END
    )::double precision AS order_sales_amount,

    MAX(order_id)::bigint AS latest_order_id

  FROM eligible_order_items

  GROUP BY
    product_id,
    variant_id,
    product_title,
    variant_value;
`;

    // =====================================================
    // INVOICE QUERY
    // Reads only invoice_header and invoice_details
    // =====================================================

    const invoiceSql = `
  WITH all_invoice_items AS (
    SELECT
      ih.id AS invoice_id,
      ih.full_amount,

      idt.product_id,
      idt.variant_id,
      idt.quantity,
      idt.unit_price,
      idt.discount,

      p.title AS product_title,

      COALESCE(
        pv.variant_value,
        'Default'
      ) AS variant_value,

      (
        COALESCE(idt.quantity, 0)
        * COALESCE(idt.unit_price, 0)
      ) - COALESCE(idt.discount, 0)
        AS invoice_item_value,

      SUM(
        (
          COALESCE(idt.quantity, 0)
          * COALESCE(idt.unit_price, 0)
        ) - COALESCE(idt.discount, 0)
      ) OVER (
        PARTITION BY ih.id
      ) AS invoice_items_total

    FROM invoice_details idt

    JOIN invoice_header ih
      ON ih.id = idt.invoice_id

    LEFT JOIN products p
      ON p.product_id = idt.product_id

    LEFT JOIN product_variants pv
      ON pv.variant_id = idt.variant_id

    ${invoiceHeaderWhereSql}
  ),

  eligible_invoice_items AS (
    SELECT *
    FROM all_invoice_items item

    ${invoiceItemWhereSql}
  )

  SELECT
    product_id,
    variant_id,
    product_title,
    variant_value,

 SUM(
  COALESCE(quantity, 0)
)::bigint AS invoice_quantity,

SUM(
  COALESCE(quantity, 0)::numeric
  * COALESCE(unit_price, 0)::numeric
)::double precision AS invoice_base_amount,

SUM(
  CASE
        WHEN COALESCE(invoice_items_total, 0) > 0
        THEN
          COALESCE(full_amount, 0)
          *
          (
            COALESCE(invoice_item_value, 0)
            / invoice_items_total
          )

        ELSE 0
      END
    )::double precision AS invoice_sales_amount,

    MAX(invoice_id)::bigint AS latest_invoice_id

  FROM eligible_invoice_items

  GROUP BY
    product_id,
    variant_id,
    product_title,
    variant_value;
`;

    // =====================================================
    // FILTERED INVOICE ADJUSTMENT TOTALS
    // Summary-only. Existing product/variant results unchanged.
    // =====================================================

    const invoiceAdjustmentTotalsSql = `
  WITH all_invoice_items AS (
    SELECT
      ih.id AS invoice_id,

      COALESCE(ih.service_charge, 0)::numeric
        AS service_charge,

      COALESCE(ih.delivery_fee, 0)::numeric
        AS delivery_charge,

      COALESCE(ih.discount, 0)::numeric
        AS invoice_discount,

      COALESCE(
        CASE
          WHEN jsonb_typeof(ih.tax) = 'object'
          THEN NULLIF(ih.tax->>'value', '')::numeric

          WHEN jsonb_typeof(ih.tax) = 'array'
          THEN (
            SELECT COALESCE(
              SUM(
                NULLIF(tax_item->>'value', '')::numeric
              ),
              0
            )
            FROM jsonb_array_elements(ih.tax)
              AS tax_item
          )

          ELSE 0
        END,
        0
      )::numeric AS tax_amount,

      idt.product_id,
      idt.variant_id,

      COALESCE(idt.discount, 0)::numeric
        AS item_discount,

      (
        (
          COALESCE(idt.quantity, 0)::numeric
          * COALESCE(idt.unit_price, 0)::numeric
        )
        - COALESCE(idt.discount, 0)::numeric
      ) AS invoice_item_value,

      SUM(
        (
          COALESCE(idt.quantity, 0)::numeric
          * COALESCE(idt.unit_price, 0)::numeric
        )
        - COALESCE(idt.discount, 0)::numeric
      ) OVER (
        PARTITION BY ih.id
      ) AS invoice_items_total

    FROM invoice_details idt

    JOIN invoice_header ih
      ON ih.id = idt.invoice_id

    ${invoiceHeaderWhereSql}
  ),

  eligible_invoice_items AS (
    SELECT *
    FROM all_invoice_items item

    ${invoiceItemWhereSql}
  )

  SELECT
    COALESCE(
      SUM(item_discount),
      0
    )::double precision
      AS total_item_discount_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(invoice_items_total, 0) > 0
          THEN
            invoice_discount
            * (
                invoice_item_value
                / invoice_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_invoice_discount_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(invoice_items_total, 0) > 0
          THEN
            service_charge
            * (
                invoice_item_value
                / invoice_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_service_charge_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(invoice_items_total, 0) > 0
          THEN
            delivery_charge
            * (
                invoice_item_value
                / invoice_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_delivery_charge_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(invoice_items_total, 0) > 0
          THEN
            tax_amount
            * (
                invoice_item_value
                / invoice_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_tax_amount

  FROM eligible_invoice_items;
`;

    // =====================================================
    // FILTERED ORDER ADJUSTMENT TOTALS
    // Summary-only. Existing order/product logic unchanged.
    // =====================================================

    const orderAdjustmentTotalsSql = `
  WITH all_order_items AS (
    SELECT
      o.order_id,

      COALESCE(o.delivery_fee, 0)::numeric
        AS delivery_charge,

      COALESCE(o.discount, 0)::numeric
        AS order_discount,

      COALESCE(
        CASE
          WHEN jsonb_typeof(o.tax) = 'object'
          THEN NULLIF(o.tax->>'value', '')::numeric

          WHEN jsonb_typeof(o.tax) = 'array'
          THEN (
            SELECT COALESCE(
              SUM(
                NULLIF(tax_item->>'value', '')::numeric
              ),
              0
            )
            FROM jsonb_array_elements(o.tax)
              AS tax_item
          )

          ELSE 0
        END,
        0
      )::numeric AS tax_amount,

      oi.product_id,
      oi.variant_id,

      COALESCE(oi.discount, 0)::numeric
        AS item_discount,

      COALESCE(oi.total_price, 0)::numeric
        AS order_item_value,

      SUM(
        COALESCE(oi.total_price, 0)::numeric
      ) OVER (
        PARTITION BY o.order_id
      ) AS order_items_total

    FROM order_items oi

    JOIN orders o
      ON o.order_id = oi.order_id

    ${orderWhereSql}
  )

  SELECT
    COALESCE(
      SUM(item_discount),
      0
    )::double precision
      AS total_order_item_discount_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(order_items_total, 0) > 0
          THEN
            order_discount
            * (
                order_item_value
                / order_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_order_discount_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(order_items_total, 0) > 0
          THEN
            delivery_charge
            * (
                order_item_value
                / order_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_order_delivery_charge_amount,

    COALESCE(
      SUM(
        CASE
          WHEN COALESCE(order_items_total, 0) > 0
          THEN
            tax_amount
            * (
                order_item_value
                / order_items_total
              )
          ELSE 0
        END
      ),
      0
    )::double precision
      AS total_order_tax_amount

  FROM all_order_items;
`;

    // =====================================================
    // ORDER RETURNS QUERY
    // =====================================================

    const orderReturnSql = `
  WITH returned_order_items AS (
    SELECT
      o.order_id,
      oi.product_id,
      oi.variant_id,
      oi.quantity,

      COALESCE(o.total_value, 0)::numeric AS order_base_total,
      COALESCE(o.full_amount, 0)::numeric AS order_full_amount,

      COALESCE(o.delivery_fee, 0)::numeric AS delivery_charge,
      COALESCE(o.discount, 0)::numeric AS order_discount,

      COALESCE(
        CASE
          WHEN jsonb_typeof(o.tax) = 'object'
          THEN NULLIF(o.tax->>'value', '')::numeric

          WHEN jsonb_typeof(o.tax) = 'array'
          THEN (
            SELECT COALESCE(
              SUM(NULLIF(tax_item->>'value', '')::numeric),
              0
            )
            FROM jsonb_array_elements(o.tax) AS tax_item
          )

          ELSE 0
        END,
        0
      )::numeric AS tax_amount,

      COALESCE(oi.total_price, 0)::numeric AS item_value,

      SUM(
        COALESCE(oi.total_price, 0)::numeric
      ) OVER (
        PARTITION BY o.order_id
      ) AS order_items_total

    FROM order_items oi

    JOIN orders o
      ON o.order_id = oi.order_id

    ${orderReturnWhereSql}
  )

  SELECT
    product_id,
    variant_id,

    SUM(
      COALESCE(quantity, 0)
    )::bigint AS returned_quantity,

    SUM(
      CASE
        WHEN order_items_total > 0
        THEN
          order_base_total
          * (item_value / order_items_total)
        ELSE 0
      END
    )::double precision AS returned_base_amount,

    SUM(
      CASE
        WHEN order_items_total > 0
        THEN
          order_full_amount
          * (item_value / order_items_total)
        ELSE 0
      END
    )::double precision AS returned_amount,

    SUM(
      CASE
        WHEN order_items_total > 0
        THEN delivery_charge * (item_value / order_items_total)
        ELSE 0
      END
    )::double precision AS returned_delivery_charge,

    SUM(
      CASE
        WHEN order_items_total > 0
        THEN order_discount * (item_value / order_items_total)
        ELSE 0
      END
    )::double precision AS returned_discount,

    SUM(
      CASE
        WHEN order_items_total > 0
        THEN tax_amount * (item_value / order_items_total)
        ELSE 0
      END
    )::double precision AS returned_tax

  FROM returned_order_items

  GROUP BY
    product_id,
    variant_id;
`;

    // =====================================================
    // INVOICE RETURNS QUERY
    // =====================================================

    const invoiceReturnSql = `
  SELECT
    NULLIF(
      return_item.item->>'product_id',
      ''
    )::int AS product_id,

    NULLIF(
      return_item.item->>'variant_id',
      ''
    )::int AS variant_id,

    MAX(p.title) AS product_title,

    MAX(
      COALESCE(
        pv.variant_value,
        'Default'
      )
    ) AS variant_value,

    SUM(
      COALESCE(
        NULLIF(
          return_item.item->>'return_qty',
          ''
        )::numeric,
        0
      )
    )::bigint AS returned_quantity,

 SUM(
  CASE
    WHEN COALESCE(invoice_totals.invoice_items_total, 0) > 0
      AND COALESCE(idt.quantity, 0) > 0
    THEN
      COALESCE(ih.full_amount, 0)::numeric
      *
      (
        (
          (
            COALESCE(idt.quantity, 0)::numeric
            * COALESCE(idt.unit_price, 0)::numeric
          )
          - COALESCE(idt.discount, 0)::numeric
        )
        / invoice_totals.invoice_items_total
      )
      *
      (
        COALESCE(
          NULLIF(
            return_item.item->>'return_qty',
            ''
          )::numeric,
          0
        )
        / NULLIF(idt.quantity, 0)::numeric
      )

    ELSE 0
  END
)::double precision AS returned_amount,

SUM(
  COALESCE(idt.unit_price, 0)::numeric
  *
  COALESCE(
    NULLIF(
      return_item.item->>'return_qty',
      ''
    )::numeric,
    0
  )
)::double precision AS returned_base_amount,

SUM(
  CASE
    WHEN COALESCE(invoice_totals.invoice_items_total, 0) > 0
      AND COALESCE(idt.quantity, 0) > 0
    THEN
      COALESCE(ih.service_charge, 0)::numeric
      *
      (
        (
          (
            COALESCE(idt.quantity, 0)::numeric
            * COALESCE(idt.unit_price, 0)::numeric
          ) - COALESCE(idt.discount, 0)::numeric
        )
        / invoice_totals.invoice_items_total
      )
      *
      (
        COALESCE(
          NULLIF(return_item.item->>'return_qty', '')::numeric,
          0
        )
        / NULLIF(idt.quantity, 0)::numeric
      )
    ELSE 0
  END
)::double precision AS returned_service_charge,

SUM(
  CASE
    WHEN COALESCE(invoice_totals.invoice_items_total, 0) > 0
      AND COALESCE(idt.quantity, 0) > 0
    THEN
      COALESCE(ih.delivery_fee, 0)::numeric
      *
      (
        (
          (
            COALESCE(idt.quantity, 0)::numeric
            * COALESCE(idt.unit_price, 0)::numeric
          ) - COALESCE(idt.discount, 0)::numeric
        )
        / invoice_totals.invoice_items_total
      )
      *
      (
        COALESCE(
          NULLIF(return_item.item->>'return_qty', '')::numeric,
          0
        )
        / NULLIF(idt.quantity, 0)::numeric
      )
    ELSE 0
  END
)::double precision AS returned_delivery_charge,

SUM(
  CASE
    WHEN COALESCE(invoice_totals.invoice_items_total, 0) > 0
      AND COALESCE(idt.quantity, 0) > 0
    THEN
      COALESCE(ih.discount, 0)::numeric
      *
      (
        (
          (
            COALESCE(idt.quantity, 0)::numeric
            * COALESCE(idt.unit_price, 0)::numeric
          ) - COALESCE(idt.discount, 0)::numeric
        )
        / invoice_totals.invoice_items_total
      )
      *
      (
        COALESCE(
          NULLIF(return_item.item->>'return_qty', '')::numeric,
          0
        )
        / NULLIF(idt.quantity, 0)::numeric
      )
    ELSE 0
  END
)::double precision AS returned_discount,

SUM(
  CASE
    WHEN COALESCE(invoice_totals.invoice_items_total, 0) > 0
      AND COALESCE(idt.quantity, 0) > 0
    THEN
      COALESCE(
        CASE
          WHEN jsonb_typeof(ih.tax) = 'object'
          THEN NULLIF(ih.tax->>'value', '')::numeric

          WHEN jsonb_typeof(ih.tax) = 'array'
          THEN (
            SELECT COALESCE(
              SUM(NULLIF(tax_item->>'value', '')::numeric),
              0
            )
            FROM jsonb_array_elements(ih.tax) AS tax_item
          )

          ELSE 0
        END,
        0
      )
      *
      (
        (
          (
            COALESCE(idt.quantity, 0)::numeric
            * COALESCE(idt.unit_price, 0)::numeric
          ) - COALESCE(idt.discount, 0)::numeric
        )
        / invoice_totals.invoice_items_total
      )
      *
      (
        COALESCE(
          NULLIF(return_item.item->>'return_qty', '')::numeric,
          0
        )
        / NULLIF(idt.quantity, 0)::numeric
      )
    ELSE 0
  END
)::double precision AS returned_tax,
    MAX(rt.id)::bigint AS latest_return_id

  FROM return_token rt

  JOIN invoice_header ih
    ON ih.id = rt.old_inv_id

    LEFT JOIN LATERAL (
  SELECT
    SUM(
      (
        COALESCE(all_idt.quantity, 0)::numeric
        * COALESCE(all_idt.unit_price, 0)::numeric
      ) - COALESCE(all_idt.discount, 0)::numeric
    ) AS invoice_items_total
  FROM invoice_details all_idt
  WHERE all_idt.invoice_id = ih.id
) invoice_totals ON TRUE

  CROSS JOIN LATERAL
    jsonb_array_elements(
      CASE
        WHEN jsonb_typeof(rt.returned_items) = 'array'
        THEN rt.returned_items
        ELSE '[]'::jsonb
      END
    ) AS return_item(item)

  LEFT JOIN invoice_details idt
    ON idt.id =
      NULLIF(
        return_item.item->>'invoice_detail_id',
        ''
      )::bigint

  LEFT JOIN products p
    ON p.product_id =
      NULLIF(
        return_item.item->>'product_id',
        ''
      )::int

  LEFT JOIN product_variants pv
    ON pv.variant_id =
      NULLIF(
        return_item.item->>'variant_id',
        ''
      )::int

  ${invoiceReturnWhereSql}

  GROUP BY
    NULLIF(
      return_item.item->>'product_id',
      ''
    )::int,

    NULLIF(
      return_item.item->>'variant_id',
      ''
    )::int;
`;

    // Run each source independently.
    const [
      orderResult,
      invoiceResult,
      orderReturnResult,
      invoiceReturnResult,
      invoiceAdjustmentTotalsResult,
      orderAdjustmentTotalsResult,
    ] = await Promise.all([
      pool.query(orderSql, orderParams),
      pool.query(invoiceSql, invoiceParams),
      pool.query(orderReturnSql, orderReturnParams),
      pool.query(invoiceReturnSql, invoiceReturnParams),

      pool.query(invoiceAdjustmentTotalsSql, invoiceParams),

      pool.query(orderAdjustmentTotalsSql, orderParams),
    ]);

    // =====================================================
    // RETURNS MAP
    // =====================================================

    const returnMap = new Map();
    const returnAmountMap = new Map();
    const returnBaseAmountMap = new Map();
    for (const row of orderReturnResult.rows || []) {
      const key = makeVariantKey(row.product_id, row.variant_id);

      const existingReturnedQuantity = returnMap.get(key) || 0;

      returnMap.set(
        key,
        existingReturnedQuantity + Number(row.returned_quantity || 0),
      );

      const existingReturnedAmount = returnAmountMap.get(key) || 0;

      returnAmountMap.set(
        key,
        existingReturnedAmount + Number(row.returned_amount || 0),
      );

      const existingReturnedBaseAmount = returnBaseAmountMap.get(key) || 0;

      returnBaseAmountMap.set(
        key,
        existingReturnedBaseAmount + Number(row.returned_base_amount || 0),
      );
    }

    for (const row of invoiceReturnResult.rows || []) {
      const key = makeVariantKey(row.product_id, row.variant_id);

      const existingReturnedQuantity = returnMap.get(key) || 0;

      returnMap.set(
        key,
        existingReturnedQuantity + Number(row.returned_quantity || 0),
      );

      const existingReturnedAmount = returnAmountMap.get(key) || 0;

      returnAmountMap.set(
        key,
        existingReturnedAmount + Number(row.returned_amount || 0),
      );

      const existingReturnedBaseAmount = returnBaseAmountMap.get(key) || 0;

      returnBaseAmountMap.set(
        key,
        existingReturnedBaseAmount + Number(row.returned_base_amount || 0),
      );
    }

    // =====================================================
    // VARIANT MAP
    // =====================================================

    const variantMap = new Map();

    // Add order values only.
    for (const row of orderResult.rows || []) {
      const key = makeVariantKey(row.product_id, row.variant_id);

      variantMap.set(key, {
        product_id: Number(row.product_id),

        variant_id:
          row.variant_id === null || row.variant_id === undefined
            ? null
            : Number(row.variant_id),

        product_title: row.product_title || "",

        variant_value: row.variant_value || "Default",

        order_quantity: Number(row.order_quantity || 0),

        order_base_amount: Number(row.order_base_amount || 0),

        order_sales_amount: Number(row.order_sales_amount || 0),
        invoice_quantity: 0,
        invoice_sales_amount: 0,
        invoice_base_amount: 0,

        latest_order_id: Number(row.latest_order_id || 0),

        latest_invoice_id: 0,
        latest_return_id: 0,
      });
    }

    // Add invoice values only.
    for (const row of invoiceResult.rows || []) {
      const key = makeVariantKey(row.product_id, row.variant_id);

      const existingVariant = variantMap.get(key);

      if (existingVariant) {
        existingVariant.invoice_quantity = Number(row.invoice_quantity || 0);

        existingVariant.invoice_base_amount = Number(
          row.invoice_base_amount || 0,
        );

        existingVariant.invoice_sales_amount = Number(
          row.invoice_sales_amount || 0,
        );

        existingVariant.latest_invoice_id = Number(row.latest_invoice_id || 0);

        if (!existingVariant.product_title) {
          existingVariant.product_title = row.product_title || "";
        }

        if (!existingVariant.variant_value) {
          existingVariant.variant_value = row.variant_value || "Default";
        }
      } else {
        variantMap.set(key, {
          product_id: Number(row.product_id),

          variant_id:
            row.variant_id === null || row.variant_id === undefined
              ? null
              : Number(row.variant_id),

          product_title: row.product_title || "",

          variant_value: row.variant_value || "Default",

          order_quantity: 0,
          order_base_amount: 0,
          order_sales_amount: 0,

          invoice_quantity: Number(row.invoice_quantity || 0),

          invoice_base_amount: Number(row.invoice_base_amount || 0),

          invoice_sales_amount: Number(row.invoice_sales_amount || 0),

          latest_order_id: 0,

          latest_invoice_id: Number(row.latest_invoice_id || 0),

          latest_return_id: 0,
        });
      }
    }

    // =====================================================
    // ADD RETURN-ONLY VARIANTS
    // Ensures a product returned today appears even when
    // its original invoice was created on an earlier date.
    // =====================================================

    for (const row of invoiceReturnResult.rows || []) {
      const key = makeVariantKey(row.product_id, row.variant_id);

      if (!variantMap.has(key)) {
        variantMap.set(key, {
          product_id: Number(row.product_id),

          variant_id:
            row.variant_id === null || row.variant_id === undefined
              ? null
              : Number(row.variant_id),

          product_title: row.product_title || "",

          variant_value: row.variant_value || "Default",

          order_quantity: 0,
          order_base_amount: 0,
          order_sales_amount: 0,

          invoice_quantity: 0,
          invoice_base_amount: 0,
          invoice_sales_amount: 0,

          latest_order_id: 0,
          latest_invoice_id: 0,

          latest_return_id: Number(row.latest_return_id || 0),
        });
      } else {
        const existingVariant = variantMap.get(key);

        existingVariant.latest_return_id = Math.max(
          Number(existingVariant.latest_return_id || 0),
          Number(row.latest_return_id || 0),
        );
      }
    }

    // =====================================================
    // PRODUCT MAP
    // Original response structure is retained.
    // =====================================================

    const productMap = new Map();

    for (const variant of variantMap.values()) {
      const variantKey = makeVariantKey(variant.product_id, variant.variant_id);

      const returnedQuantity = returnMap.get(variantKey) || 0;

      const returnedAmount = returnAmountMap.get(variantKey) || 0;

      const returnedBaseAmount = returnBaseAmountMap.get(variantKey) || 0;

      // Net sales amount:
      // order sales + invoice sales - invoice return amount
      const totalSalesAmount =
        variant.order_sales_amount + variant.invoice_sales_amount;

      const totalSalesQuantity =
        variant.order_quantity + variant.invoice_quantity;

      // Original variant response structure.
      const formattedVariant = {
        variant_id: variant.variant_id,

        variant_value: variant.variant_value,

        total_sales_amount: totalSalesAmount,

        sales_quantity: totalSalesQuantity,

        order_quantity: variant.order_quantity,

        // Allocated orders.total_value before additions.
        order_base_amount: Number(variant.order_base_amount || 0),

        order_sales_amount: variant.order_sales_amount,

        order_sales_quantity: variant.order_quantity,

        invoice_sales_amount: variant.invoice_sales_amount,
        invoice_sales_quantity: variant.invoice_quantity,

        invoice_quantity: variant.invoice_quantity,

        // Gross item amount before discounts, tax,
        // service charges and invoice-level additions.
        invoice_base_amount: variant.invoice_base_amount,
        returned_base_amount: returnedBaseAmount,
        returned_items_quantity: returnedQuantity,
        returned_sales_amount: returnedAmount,
      };

      if (!productMap.has(variant.product_id)) {
        productMap.set(variant.product_id, {
          product_id: variant.product_id,

          title: variant.product_title,

          product_total_sales_amount: 0,
          product_total_sales_quantity: 0,
          product_returned_base_amount: 0,

          product_total_order_quantity: 0,
          product_order_base_amount: 0,
          product_order_sales_amount: 0,
          product_order_sales_quantity: 0,

          product_invoice_sales_amount: 0,
          product_invoice_base_amount: 0,
          product_invoice_sales_quantity: 0,
          product_invoice_quantity: 0,

          product_returned_items_quantity: 0,

          product_returned_sales_amount: 0,
          latest_order_id: 0,
          latest_invoice_id: 0,
          latest_return_id: 0,

          variants: [],
        });
      }

      const product = productMap.get(variant.product_id);

      // Combined order + invoice values.
      product.product_total_sales_amount += totalSalesAmount;

      product.product_total_sales_quantity += totalSalesQuantity;

      // Order values only.
      product.product_total_order_quantity += variant.order_quantity;

      product.product_order_base_amount += Number(
        variant.order_base_amount || 0,
      );

      product.product_order_sales_amount += variant.order_sales_amount;
      product.product_order_sales_quantity += variant.order_quantity;

      // Invoice values only.
      // Base amount before discounts, tax, service charges
      // and other invoice-level additions.
      product.product_invoice_base_amount += variant.invoice_base_amount;
      product.product_invoice_sales_amount += variant.invoice_sales_amount;
      product.product_invoice_sales_quantity += variant.invoice_quantity;

      product.product_invoice_quantity += variant.invoice_quantity;

      // Returns.
      // Returns.
      product.product_returned_items_quantity += returnedQuantity;
      product.product_returned_base_amount += returnedBaseAmount;

      product.product_returned_sales_amount += returnedAmount;

      product.latest_order_id = Math.max(
        product.latest_order_id,
        variant.latest_order_id,
      );

      product.latest_invoice_id = Math.max(
        product.latest_invoice_id,
        variant.latest_invoice_id,
      );
      product.latest_return_id = Math.max(
        product.latest_return_id,
        Number(variant.latest_return_id || 0),
      );

      product.variants.push(formattedVariant);
    }

    // =====================================================
    // FINAL PRODUCTS
    // Exact original response field names.
    // =====================================================

    const products = Array.from(productMap.values())
      .map((product) => ({
        product_id: product.product_id,

        title: product.title,

        product_total_sales_amount: product.product_total_sales_amount,

        product_total_sales_quantity: product.product_total_sales_quantity,

        product_total_order_quantity: product.product_total_order_quantity,

        product_order_base_amount: product.product_order_base_amount,

        product_order_sales_amount: product.product_order_sales_amount,
        product_returned_base_amount: product.product_returned_base_amount,

        product_order_sales_quantity: product.product_order_sales_quantity,

        product_invoice_base_amount: product.product_invoice_base_amount,

        product_invoice_sales_amount: product.product_invoice_sales_amount,

        product_invoice_sales_quantity: product.product_invoice_sales_quantity,

        product_invoice_quantity: product.product_invoice_quantity,

        product_returned_items_quantity:
          product.product_returned_items_quantity,

        product_returned_sales_amount: product.product_returned_sales_amount,

        variants: product.variants.sort(
          (a, b) => Number(a.variant_id || 0) - Number(b.variant_id || 0),
        ),

        _latest_activity_id: Math.max(
          product.latest_order_id,
          product.latest_invoice_id,
          product.latest_return_id,
        ),
      }))
      .sort((a, b) => b._latest_activity_id - a._latest_activity_id)
      .map(({ _latest_activity_id, ...product }) => product);

    // =====================================================
    // ORIGINAL SUMMARY STRUCTURE
    // =====================================================

    const invoiceAdjustmentTotals =
      invoiceAdjustmentTotalsResult.rows?.[0] || {};

    const orderAdjustmentTotals = orderAdjustmentTotalsResult.rows?.[0] || {};

    // Invoice discounts.
    const invoiceItemDiscount = Number(
      invoiceAdjustmentTotals.total_item_discount_amount || 0,
    );

    const invoiceHeaderDiscount = Number(
      invoiceAdjustmentTotals.total_invoice_discount_amount || 0,
    );

    // Order discounts.
    const orderItemDiscount = Number(
      orderAdjustmentTotals.total_order_item_discount_amount || 0,
    );

    const orderHeaderDiscount = Number(
      orderAdjustmentTotals.total_order_discount_amount || 0,
    );

    // Use transaction-level discounts only.
    // invoice_details.discount and order_items.discount may already contain
    // the same discount distributed to item rows, so adding both causes duplication.
    const totalItemDiscount = 0;

    const totalInvoiceDiscount = invoiceHeaderDiscount + orderHeaderDiscount;

    // Service charge comes from invoices only.
    const totalServiceCharge = Number(
      invoiceAdjustmentTotals.total_service_charge_amount || 0,
    );

    // Delivery charge comes from orders only.
    const totalDeliveryCharge = Number(
      orderAdjustmentTotals.total_order_delivery_charge_amount || 0,
    );

    // Tax comes from invoices and orders.
    const totalInvoiceTax = Number(
      invoiceAdjustmentTotals.total_tax_amount || 0,
    );

    const totalOrderTax = Number(
      orderAdjustmentTotals.total_order_tax_amount || 0,
    );

    const totalTax = totalInvoiceTax + totalOrderTax;

    const returnedOrderDelivery = (orderReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_delivery_charge || 0),
      0,
    );

    const returnedOrderDiscount = (orderReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_discount || 0),
      0,
    );

    const returnedOrderTax = (orderReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_tax || 0),
      0,
    );

    const returnedInvoiceService = (invoiceReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_service_charge || 0),
      0,
    );

    const returnedInvoiceDelivery = (invoiceReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_delivery_charge || 0),
      0,
    );

    const returnedInvoiceDiscount = (invoiceReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_discount || 0),
      0,
    );

    const returnedInvoiceTax = (invoiceReturnResult.rows || []).reduce(
      (sum, row) => sum + Number(row.returned_tax || 0),
      0,
    );

    const grossInvoiceDelivery = Number(
      invoiceAdjustmentTotals.total_delivery_charge_amount || 0,
    );

    const netServiceCharge = totalServiceCharge - returnedInvoiceService;

    const netDeliveryCharge =
      totalDeliveryCharge +
      grossInvoiceDelivery -
      returnedOrderDelivery -
      returnedInvoiceDelivery;

    const netDiscount =
      totalItemDiscount +
      totalInvoiceDiscount -
      returnedOrderDiscount -
      returnedInvoiceDiscount;

    const netTax = totalTax - returnedOrderTax - returnedInvoiceTax;

    const netAdditionalAmount =
      netServiceCharge + netDeliveryCharge + netTax - netDiscount;

    const totalReturnedBaseAmount = products.reduce(
      (sum, product) => sum + Number(product.product_returned_base_amount || 0),
      0,
    );

    const totalReturnedSalesAmount = products.reduce(
      (sum, product) =>
        sum + Number(product.product_returned_sales_amount || 0),
      0,
    );

    const sales_report_summary = {
      total_ordered_qty: products.reduce(
        (sum, product) =>
          sum + Number(product.product_total_order_quantity || 0),
        0,
      ),

      total_sales_qty: products.reduce(
        (sum, product) =>
          sum + Number(product.product_total_sales_quantity || 0),
        0,
      ),

      total_returned_qty: products.reduce(
        (sum, product) =>
          sum + Number(product.product_returned_items_quantity || 0),
        0,
      ),

      // Total allocated orders.total_value before
      // delivery, tax and other additions.
      total_order_base_amount: products.reduce(
        (sum, product) => sum + Number(product.product_order_base_amount || 0),
        0,
      ),

      // Total quantity × unit_price before discounts,
      // taxes, service charges and other additions.
      total_invoice_base_amount:
        products.reduce(
          (sum, product) =>
            sum + Number(product.product_invoice_base_amount || 0),
          0,
        ) - totalReturnedBaseAmount,

      total_base_amount:
        products.reduce(
          (sum, product) =>
            sum +
            Number(product.product_order_base_amount || 0) +
            Number(product.product_invoice_base_amount || 0),
          0,
        ) - totalReturnedBaseAmount,

      total_sales_amount:
        products.reduce(
          (sum, product) =>
            sum + Number(product.product_total_sales_amount || 0),
          0,
        ) - totalReturnedSalesAmount,

      total_item_discount_amount: 0,

      total_invoice_discount_amount: netDiscount,

      total_discount_amount: netDiscount,

      total_service_charge_amount: netServiceCharge,

      total_delivery_charge_amount: netDeliveryCharge,

      total_tax_amount: netTax,

      total_additional_amount: netAdditionalAmount,

      total_net_adjustment_amount: netAdditionalAmount,

      returned_service_charge_amount: returnedInvoiceService,

      returned_delivery_charge_amount:
        returnedOrderDelivery + returnedInvoiceDelivery,

      returned_discount_amount: returnedOrderDiscount + returnedInvoiceDiscount,

      returned_tax_amount: returnedOrderTax + returnedInvoiceTax,
    };

    return res.status(200).json({
      products,
      pagination: null,
      sales_report_summary,
    });
  } catch (error) {
    console.error("Error fetching filtered sales report:", error);

    return res.status(500).json({
      error: "Internal server error",
      details: error.message,
    });
  }
});

// sales summary reports
router.post("/sales-summary-card1", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      // inclusive end: < date_to + 1 day
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
    `;

    // Currency: read global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "orders_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching orders_overview:", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// summary card 2
router.post("/sales-summary-card2", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    // Merchant scope
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // ✅ Only orders with payment method = 'COD'
    where.push(`LOWER(pm.method_name) = 'cod'`);

    // Date filters (inclusive end day)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      JOIN payment_methods pm ON pm.payment_method_id = o.payment_method_id
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "cod_cash_on_delivery_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card2 (COD):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 3
router.post("/sales-summary-card3", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // Build WHERE with safe positional params
    const where = [];
    const params = [];
    let i = 1;

    // Merchant scope
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // ✅ Only orders with payment method = 'cash'
    where.push(`LOWER(pm.method_name) = 'cash'`);

    // Dates (inclusive end)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    const overviewSql = `
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      JOIN payment_methods pm ON pm.payment_method_id = o.payment_method_id
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "store_pickup_overview", // unchanged
      currency,
      filters: { date_from: date_from || null, date_to: date_to || null },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error(
      "Error fetching sales-summary-card3 (Cash Payment Orders):",
      err,
    );
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 4
router.post("/sales-summary-card4", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    // Scope to merchant
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // ✅ Exclude cancelled orders
    where.push(`o.order_status != 'cancelled'`);

    // Date filters (inclusive end on date_to)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // Use a CTE to grab Stripe payment_method ids (case-insensitive)
    const overviewSql = `
      WITH stripe_methods AS (
        SELECT pm.payment_method_id
        FROM payment_methods pm
        WHERE LOWER(pm.method_name) = 'stripe'
      )
      SELECT
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
        AND o.payment_method_id IN (SELECT payment_method_id FROM stripe_methods)
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "stripe_payment_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card4 (Stripe):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 5
router.post("/sales-summary-card5", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    // Scope to merchant
    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    // Dates (inclusive end on date_to)
    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // CTE for PayHere payment methods (case-insensitive)
    const overviewSql = `
      WITH payhere_methods AS (
        SELECT pm.payment_method_id
        FROM payment_methods pm
        WHERE LOWER(pm.method_name) = 'payhere'
      )
      SELECT
        ARRAY_AGG(o.order_id) AS order_ids,
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      WHERE ${where.join(" AND ")}
        AND o.payment_method_id IN (SELECT payment_method_id FROM payhere_methods)
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "payhere_payment_overview",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        order_ids: r.order_ids || [],
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card5 (PayHere):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// card 6
router.post("/sales-summary-card6", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user?.merchant_id;
    if (!merchant_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    const { date_from, date_to } = req.body || {};

    // WHERE + params
    const where = [];
    const params = [];
    let i = 1;

    where.push(`o.merchant_id = $${i++}`);
    params.push(merchant_id);

    if (date_from) {
      where.push(`o.created_at >= $${i++}::date`);
      params.push(date_from);
    }
    if (date_to) {
      where.push(`o.created_at < ($${i++}::date + INTERVAL '1 day')`);
      params.push(date_to);
    }

    // Join to payment_methods and match Bank Transfer variants
    const overviewSql = `
      SELECT
        ARRAY_AGG(o.order_id) AS order_ids,
        COUNT(*)::BIGINT AS total_orders_qty,
        COALESCE(SUM(o.full_amount), 0)::NUMERIC(12,2) AS total_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'paid')::BIGINT AS paid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'paid'), 0)::NUMERIC(12,2) AS paid_order_value,

        COUNT(*) FILTER (WHERE o.payment_status = 'unpaid')::BIGINT AS unpaid_orders_qty,
        COALESCE(SUM(o.full_amount) FILTER (WHERE o.payment_status = 'unpaid'), 0)::NUMERIC(12,2) AS unpaid_order_value
      FROM orders o
      INNER JOIN payment_methods pm
        ON pm.payment_method_id = o.payment_method_id
       AND LOWER(pm.method_name) IN ('bank', 'bank transfer', 'bank_transfer', 'banktransfer')
      WHERE ${where.join(" AND ")}
    `;

    // Currency: global system_settings, fallback LKR
    const currencySql = `
      SELECT COALESCE(currency, 'LKR') AS currency
      FROM system_settings
      LIMIT 1
    `;

    const [overviewRes, currencyRes] = await Promise.all([
      pool.query(overviewSql, params),
      pool.query(currencySql),
    ]);

    const r = overviewRes.rows[0] || {};
    const currency = (currencyRes.rows[0]?.currency || "LKR").toString();

    res.json({
      success: true,
      title_key: "bank_transfer_payment_summary",
      currency,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
      },
      data: {
        order_ids: r.order_ids || [],
        total_orders_qty: Number(r.total_orders_qty || 0),
        total_order_value: Number(r.total_order_value || 0),
        paid_orders_qty: Number(r.paid_orders_qty || 0),
        paid_order_value: Number(r.paid_order_value || 0),
        unpaid_orders_qty: Number(r.unpaid_orders_qty || 0),
        unpaid_order_value: Number(r.unpaid_order_value || 0),
      },
    });
  } catch (err) {
    console.error("Error fetching sales-summary-card6 (Bank Transfer):", err);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

router.get("/report-product-search", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;

  const raw = (req.query.q || req.query.search || "").toString();
  const search = raw.trim();

  // Require minimum 2 chars
  if (search.length < 2) {
    return res.status(400).json({
      success: false,
      error: "Search query must be at least 2 characters long.",
    });
  }

  try {
    /**
     * 1️⃣ Exact numeric search
     * Matches:
     * - product_id
     * - variant_id
     */
    if (/^\d+$/.test(search)) {
      const exactSql = `
        SELECT DISTINCT
          p.product_id,
          p.title,
          pv.variant_id,
          pv.barcode
        FROM products p
        LEFT JOIN product_variants pv
          ON pv.product_id = p.product_id
        WHERE p.merchant_id = $1
          AND p.status = 'active'
          AND (
            p.product_id = $2
            OR pv.variant_id = $2
          )
        ORDER BY p.title ASC
        LIMIT 20;
      `;

      const exactResult = await pool.query(exactSql, [
        merchant_id,
        Number(search),
      ]);

      if (exactResult.rows.length > 0) {
        return res.json({
          success: true,
          products: exactResult.rows,
        });
      }
    }

    /**
     * 2️⃣ Fuzzy search
     * Matches:
     * - product title
     * - product_id
     * - variant_id
     * - barcode
     * - similar_keywords
     */
    const fuzzySql = `
      SELECT DISTINCT
        p.product_id,
        p.title,
        pv.variant_id,
        pv.barcode
      FROM products p
      LEFT JOIN product_variants pv
        ON pv.product_id = p.product_id
      WHERE p.merchant_id = $1
        AND p.status = 'active'
        AND (
          LOWER(p.title) LIKE '%' || LOWER($2) || '%'
          OR CAST(p.product_id AS TEXT) LIKE '%' || $2 || '%'
          OR CAST(pv.variant_id AS TEXT) LIKE '%' || $2 || '%'
          OR LOWER(pv.barcode) LIKE '%' || LOWER($2) || '%'
          OR EXISTS (
            SELECT 1
            FROM unnest(p.similar_keywords) kw
            WHERE LOWER(kw) LIKE '%' || LOWER($2) || '%'
          )
        )
      ORDER BY p.title ASC
      LIMIT 20;
    `;

    const result = await pool.query(fuzzySql, [merchant_id, search]);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No active products found matching "${search}".`,
      });
    }

    return res.json({
      success: true,
      products: result.rows,
    });
  } catch (error) {
    console.error("Product search error:", error);
    return res.status(500).json({
      success: false,
      error: "Server error while searching products.",
    });
  }
});

// moving report | slow moving fast moving products

router.post("/product-moving-report", authenticateToken, async (req, res) => {
  try {
    const {
      date_from,
      date_to,
      product_id,
      variant_id,
      sort_by = "fast_moving",
      page = 1,
      limit = 25,
    } = req.body || {};

    const offset = (page - 1) * limit;

    // ================= SORT =================
    let orderClause = "total_sold_qty DESC"; // default: fast_moving

    if (sort_by === "slow_moving") {
      orderClause = "total_sold_qty ASC";
    } else if (sort_by === "amount_high") {
      orderClause = "total_sales_amount DESC";
    } else if (sort_by === "amount_low") {
      orderClause = "total_sales_amount ASC"; // ✅ FIX ADDED
    }

    // ================= FILTERS =================
    let filters = [];
    let values = [];

    // Date filters are optional — only apply when provided
    if (date_from && date_to) {
      values.push(date_from, date_to);
      const idx = values.length;
      // Applied inside each CTE via a helper flag
    }

    if (product_id) {
      values.push(product_id);
      filters.push(`t.product_id = $${values.length}`);
    }

    if (variant_id) {
      values.push(variant_id);
      filters.push(`t.variant_id = $${values.length}`);
    }

    const filterSQL = filters.length ? `AND ${filters.join(" AND ")}` : "";

    // Build date condition for CTEs — empty string means no date restriction
    let datePlaceholders = { from: null, to: null };
    let orderDateFilter = "";
    let invoiceDateFilter = "";

    if (date_from && date_to) {
      // $1 = date_from, $2 = date_to (always first two when present)
      orderDateFilter = "AND o.created_at BETWEEN $1 AND $2";
      invoiceDateFilter = "AND ih.created_at BETWEEN $1 AND $2";
    }

    // ================= QUERY =================
    const sql = `
      WITH order_sales AS (
        SELECT
          oi.product_id,
          oi.variant_id,
          SUM(oi.total_price)::double precision AS sales_amount,
          SUM(oi.quantity)::bigint AS sold_qty
        FROM order_items oi
        JOIN orders o ON o.order_id = oi.order_id
        WHERE o.order_status IN ('confirmed','completed','dispatched','processing')
          ${orderDateFilter}
        GROUP BY oi.product_id, oi.variant_id
      ),

      invoice_sales AS (
        SELECT
          idt.product_id,
          idt.variant_id,
          SUM((idt.quantity * idt.unit_price) - COALESCE(idt.discount, 0))::double precision AS sales_amount,
          SUM(idt.quantity)::bigint AS sold_qty
        FROM invoice_details idt
        JOIN invoice_header ih ON ih.id = idt.invoice_id
        WHERE ih.order_status NOT IN ('cancelled','draft','hold','delete')
          ${invoiceDateFilter}
        GROUP BY idt.product_id, idt.variant_id
      ),

      combined AS (
        SELECT * FROM order_sales
        UNION ALL
        SELECT * FROM invoice_sales
      ),

      aggregated AS (
        SELECT
          product_id,
          variant_id,
          SUM(sales_amount) AS total_sales_amount,
          SUM(sold_qty)     AS total_sold_qty
        FROM combined
        WHERE product_id IS NOT NULL
        GROUP BY product_id, variant_id
      ),

      final_data AS (
        SELECT
          t.product_id,
          p.title,

          t.variant_id,
          pv.variant_value,
          pv.variant_type,

          m.measurement_value,

          t.total_sales_amount,
          t.total_sold_qty

        FROM aggregated t

        LEFT JOIN products p
          ON p.product_id = t.product_id

        LEFT JOIN product_variants pv
          ON pv.variant_id = t.variant_id
          AND pv.status = 'active'

        LEFT JOIN measurements m
          ON m.measurement_id = p.measurement_id

        WHERE 1=1
        ${filterSQL}
      )

      SELECT *,
        (SELECT COUNT(*) FROM final_data) AS total_count
      FROM final_data
    ORDER BY ${orderClause}
      LIMIT ${limit} OFFSET ${offset};
    `;

    const result = await pool.query(sql, values);
    const rows = result.rows || [];

    const total_count = Number(rows[0]?.total_count || 0);

    const summary = {
      total_items: total_count,
      total_pages: Math.ceil(total_count / limit),
      current_page: Number(page),
      total_sold_qty: rows.reduce(
        (s, r) => s + Number(r.total_sold_qty || 0),
        0,
      ),
      total_sales_amount: rows.reduce(
        (s, r) => s + Number(r.total_sales_amount || 0),
        0,
      ),
    };

    res.json({
      data: rows,
      summary,
      filters: {
        date_from: date_from || null,
        date_to: date_to || null,
        product_id: product_id || null,
        variant_id: variant_id || null,
        sort_by,
        page,
        limit,
      },
    });
  } catch (err) {
    console.error("Error fetching moving report:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
module.exports = router;
