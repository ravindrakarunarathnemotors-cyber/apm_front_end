const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

const { insertNotification } = require("../../models/notificationsUpdater");

/** Accept object or JSON string; null if empty; throw on invalid JSON (for generic JSONB) */
function toJsonb(val, field) {
  if (val === undefined || val === null || val === "") return null;
  if (typeof val === "object") return val;
  if (typeof val === "string") {
    try {
      return JSON.parse(val);
    } catch {
      throw new Error(`Invalid JSON for ${field}`);
    }
  }
  throw new Error(`Unsupported type for ${field}`);
}

/** Normalize IDs to a JSONB array of integers (for target_collections/categories/brands) */
function toIdArrayJsonb(val, field) {
  if (val === undefined || val === null || val === "") return null;

  let arr = val;
  if (typeof val === "string") {
    // allow comma-separated "1,2,3" or JSON "[1,2,3]"
    if (val.trim().startsWith("[")) {
      try {
        arr = JSON.parse(val);
      } catch {
        throw new Error(`Invalid JSON array for ${field}`);
      }
    } else {
      arr = val
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);
    }
  }

  if (!Array.isArray(arr)) arr = [arr];

  const out = arr.map((n) => {
    const num = Number(n);
    if (!Number.isFinite(num) || !Number.isInteger(num) || num < 0) {
      throw new Error(`All ${field} must be integer IDs`);
    }
    return num;
  });

  return out; // pg driver will serialize arrays/objects for jsonb params
}

router.post("/add-product-discounts", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const { main_discount_type, prod_discount_method, discount_title } =
      req.body;

    // helper: safe INT or NULL (throws if not integer)
    const intOrNull = (v, field) => {
      if (v === undefined || v === null || v === "") return null;
      const n = Number(v);
      if (!Number.isInteger(n)) {
        throw new Error(`${field} must be an integer`);
      }
      return n;
    };

    // helper: coerce to integer[] (throws if not all integers)
    // Returns [] when value is null/undefined -> '{}'::int[] in PG
    const toIntArray = (v, field) => {
      if (v == null) return [];
      if (!Array.isArray(v)) {
        throw new Error(`${field} must be an array of integers`);
      }
      const arr = v.map((n) => {
        const x = Number(n);
        if (!Number.isInteger(x)) {
          throw new Error(`${field} must be an array of integers`);
        }
        return x;
      });
      return arr;
    };

    // scope: allow 'product' or 'order'
    if (
      !["product", "order"].includes((main_discount_type || "").toLowerCase())
    ) {
      return res
        .status(422)
        .json({ error: "main_discount_type must be 'product' or 'order'" });
    }

    // optional title length cap
    if (discount_title && String(discount_title).length > 125) {
      return res
        .status(422)
        .json({ error: "discount_title must be ≤ 125 chars" });
    }

    // product methods check (if provided)
    if (
      prod_discount_method &&
      !["general", "code", "buyxgety"].includes(prod_discount_method)
    ) {
      return res.status(422).json({
        error: "prod_discount_method must be one of: general | code | buyxgety",
      });
    }

    await client.query("BEGIN");

    // JSONB targets — collections/categories/brands are ID arrays
    const target_products = toJsonb(
      req.body.target_products,
      "target_products"
    ); // optional, free-form JSONB
    const target_collections = toIdArrayJsonb(
      req.body.target_collections,
      "target_collections"
    );
    const target_categories = toIdArrayJsonb(
      req.body.target_categories,
      "target_categories"
    );
    const target_brands = toIdArrayJsonb(
      req.body.target_brands,
      "target_brands"
    );

    // BXGY quantities — plain INT columns
    const customer_buys_qty = intOrNull(
      req.body.customer_buys_qty,
      "customer_buys_qty"
    );
    const customer_gets_qty = intOrNull(
      req.body.customer_gets_qty,
      "customer_gets_qty"
    );

    // Check if payment_method column exists (public.discounts)
    const paymentColCheck = await client.query(
      `
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'discounts'
        AND column_name = 'payment_method'
      `
    );
    const hasPaymentMethodCol = paymentColCheck.rowCount > 0;

    // Prepare payment_method only if column exists
    const payment_method = hasPaymentMethodCol
      ? toIntArray(req.body.payment_method, "payment_method")
      : null; // ignored if column absent

    // Build the shared params (through bxgy_max_limit)
    const baseParams = [
      // 1  main_discount_type
      main_discount_type ?? null,

      // 2-5 targeting
      target_products,
      target_collections,
      target_categories,
      target_brands,

      // 6-9 product discount core
      req.body.prod_discount_method ?? null,
      req.body.discount_title ?? null,
      req.body.discount_value_type ?? null, // 'percentage' | 'fixed'
      req.body.discount_value ?? null, // NUMERIC

      // 10-12 purchase limits
      req.body.min_max_purchase_discount_limits ?? null, // BOOLEAN
      req.body.min_purchase_amount ?? null, // NUMERIC
      req.body.max_discount_amount ?? null, // NUMERIC

      // 13-14 eligibility
      req.body.customer_eligibility ?? null, // 'all' | 'new' | 'existing'
      req.body.is_guest_allowed ?? null, // BOOLEAN

      // 15-17 usage limits
      req.body.usage_limit_total ?? null, // INTEGER
      req.body.unlimited_usage ?? null, // BOOLEAN
      req.body.usage_limit_per_account ?? null, // INTEGER

      // 18-19 date range
      req.body.start_date ?? null, // TIMESTAMPTZ
      req.body.end_date ?? null, // TIMESTAMPTZ

      // 20-23 code/bxgy payloads
      req.body.discount_code == null
        ? null
        : String(req.body.discount_code).slice(0, 12),
      customer_buys_qty, // INTEGER
      customer_gets_qty, // INTEGER
      req.body.bxgy_max_limit ?? null, // INTEGER
    ];

    let sql;
    let params;

    if (hasPaymentMethodCol) {
      // With payment_method column
      sql = `
        INSERT INTO discounts (
          main_discount_type,
          target_products,
          target_collections,
          target_categories,
          target_brands,
          prod_discount_method,
          discount_title,
          discount_value_type,
          discount_value,
          min_max_purchase_discount_limits,
          min_purchase_amount,
          max_discount_amount,
          customer_eligibility,
          is_guest_allowed,
          usage_limit_total,
          unlimited_usage,
          usage_limit_per_account,
          start_date,
          end_date,
          discount_code,
          customer_buys_qty,
          customer_gets_qty,
          bxgy_max_limit,
          order_discount_method,
          payment_method
        ) VALUES (
          $1, $2, $3, $4, $5,
          $6, $7, $8, $9,
          $10, $11, $12,
          $13, $14,
          $15, $16, $17,
          $18, $19,
          $20, $21, $22, $23,
          $24, $25
        )
        RETURNING *;
      `;
      params = [
        ...baseParams,
        null, // order_discount_method (ALWAYS NULL here)
        payment_method, // integer[]
      ];
    } else {
      // Without payment_method column
      sql = `
        INSERT INTO discounts (
          main_discount_type,
          target_products,
          target_collections,
          target_categories,
          target_brands,
          prod_discount_method,
          discount_title,
          discount_value_type,
          discount_value,
          min_max_purchase_discount_limits,
          min_purchase_amount,
          max_discount_amount,
          customer_eligibility,
          is_guest_allowed,
          usage_limit_total,
          unlimited_usage,
          usage_limit_per_account,
          start_date,
          end_date,
          discount_code,
          customer_buys_qty,
          customer_gets_qty,
          bxgy_max_limit,
          order_discount_method
        ) VALUES (
          $1, $2, $3, $4, $5,
          $6, $7, $8, $9,
          $10, $11, $12,
          $13, $14,
          $15, $16, $17,
          $18, $19,
          $20, $21, $22, $23,
          $24
        )
        RETURNING *;
      `;
      params = [
        ...baseParams,
        null, // order_discount_method (ALWAYS NULL here)
      ];
    }

    const { rows } = await client.query(sql, params);
    await client.query("COMMIT");

    // ---- After commit: write admin log + notification (non-blocking to main response)
    try {
      const userId =
        (req.user && (req.user.user_id || req.user.id)) ||
        (req.auth && (req.auth.user_id || req.auth.id)) ||
        null;

// --- SIMPLE ADMIN LOG BLOCK (REPLACE WITH THIS) ---
const created = rows[0];

(function doPostCommitWork() {
  (async () => {
    try {
      const userId =
        req.user?.user_id ||
        req.user?.id ||
        req.auth?.user_id ||
        req.auth?.id ||
        null;

      const discountId = created?.discount_id ?? "N/A";
      const discountTitle = created?.discount_title ?? "Untitled Discount";
      const discountCode = created?.discount_code ?? "N/A";
      const discountType = created?.main_discount_type ?? "discount";
      const prodMethod = created?.prod_discount_method ?? "N/A";

      // 🔥 SIMPLE detailed phrase to be inserted into admin_log.log
      const phrase = `New ${discountType} discount created: ID=${discountId}, Title="${discountTitle}", Code=${discountCode}, Method=${prodMethod}`;

      // insert admin log (simple)
      await insertAdminLog(userId, "discounts", phrase);

      // notification (unchanged)
      const notifMsg = `New product discount created: "${discountTitle}" (ID: ${discountId}), method: ${prodMethod}`;
      await insertNotification(
        userId,
        "Discounts",
        "New Product Discount Added",
        notifMsg,
        "Website Notification",
        "Unread"
      );
    } catch (err) {
      console.error("post-commit log error:", err?.message || err);
    }
  })();
})();
// --- END SIMPLE ADMIN LOG BLOCK ---


    } catch (notifyErr) {
      console.error(
        "Post-commit log/notification error:",
        notifyErr.message || notifyErr
      );
    }

    return res.status(201).json({ ok: true, data: rows[0] });
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch (_) {}
    return res
      .status(400)
      .json({ ok: false, error: err.message || "insert failed" });
  } finally {
    client.release();
  }
});

// add order discount

router.post("/add-order-discounts", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const body = req.body;
    const userId = req.user?.user_id || null; // ✅ get user_id from token

    // Normalize payment_method → integer[]
    const normalizePaymentMethod = (payment_method) => {
      let tmp = [];
      if (Array.isArray(payment_method)) tmp = payment_method;
      else if (typeof payment_method === "string") {
        const s = payment_method.trim();
        if (s) tmp = s.startsWith("[") ? JSON.parse(s) : s.split(",");
      } else if (payment_method != null) tmp = [].concat(payment_method);
      const ints = tmp.map(Number).filter((n) => Number.isInteger(n) && n > 0);
      return ints.length ? Array.from(new Set(ints)) : null;
    };
    const pmArray = normalizePaymentMethod(body.payment_method);

    await client.query("BEGIN");

    // Detect if payment_method column exists
    const colCheck = await client.query(
      `SELECT 1
       FROM information_schema.columns
       WHERE table_schema='public' AND table_name='discounts' AND column_name='payment_method'`
    );
    const hasPaymentMethodCol = colCheck.rowCount > 0;

    let rows;
    if (hasPaymentMethodCol) {
      // INSERT including payment_method
      const sql = `
        INSERT INTO discounts (
          main_discount_type, discount_title, discount_value_type, discount_value,
          min_max_purchase_discount_limits, min_purchase_amount, max_discount_amount,
          customer_eligibility, is_guest_allowed,
          usage_limit_total, unlimited_usage, usage_limit_per_account,
          status, start_date, end_date,
          discount_code, order_discount_method, payment_method
        ) VALUES (
          $1,$2,$3,$4,
          $5,$6,$7,
          $8,$9,
          $10,$11,$12,
          $13,$14,$15,
          $16,$17,$18::int[]
        ) RETURNING *;
      `;
      rows = (
        await client.query(sql, [
          body.main_discount_type ?? null,
          body.discount_title ?? null,
          body.discount_value_type ?? null,
          body.discount_value ?? null,
          body.min_max_purchase_discount_limits ?? null,
          body.min_purchase_amount ?? null,
          body.max_discount_amount ?? null,
          body.customer_eligibility ?? null,
          body.is_guest_allowed ?? null,
          body.usage_limit_total ?? null,
          body.unlimited_usage ?? null,
          body.usage_limit_per_account ?? null,
          body.status ?? null,
          body.start_date ?? null,
          body.end_date ?? null,
          body.discount_code == null
            ? null
            : String(body.discount_code).slice(0, 12),
          body.order_discount_method ?? null,
          pmArray,
        ])
      ).rows;
    } else {
      // INSERT without payment_method column
      const sql = `
        INSERT INTO discounts (
          main_discount_type, discount_title, discount_value_type, discount_value,
          min_max_purchase_discount_limits, min_purchase_amount, max_discount_amount,
          customer_eligibility, is_guest_allowed,
          usage_limit_total, unlimited_usage, usage_limit_per_account,
          status, start_date, end_date,
          discount_code, order_discount_method
        ) VALUES (
          $1,$2,$3,$4,
          $5,$6,$7,
          $8,$9,
          $10,$11,$12,
          $13,$14,$15,
          $16,$17
        ) RETURNING *;
      `;
      rows = (
        await client.query(sql, [
          body.main_discount_type ?? null,
          body.discount_title ?? null,
          body.discount_value_type ?? null,
          body.discount_value ?? null,
          body.min_max_purchase_discount_limits ?? null,
          body.min_purchase_amount ?? null,
          body.max_discount_amount ?? null,
          body.customer_eligibility ?? null,
          body.is_guest_allowed ?? null,
          body.usage_limit_total ?? null,
          body.unlimited_usage ?? null,
          body.usage_limit_per_account ?? null,
          body.status ?? null,
          body.start_date ?? null,
          body.end_date ?? null,
          body.discount_code == null
            ? null
            : String(body.discount_code).slice(0, 12),
          body.order_discount_method ?? null,
        ])
      ).rows;
    }

    await client.query("COMMIT");

// --- REPLACEMENT: admin log (single phrase) + notification (fixed) ---
const created = rows[0] ?? null;

try {
  // determine user who performed the action
  const userId =
    (req.user && (req.user.user_id || req.user.id)) ||
    (req.auth && (req.auth.user_id || req.auth.id)) ||
    null;

  // values (prefer DB row, fallback to request body)
  const discountId = created?.discount_id ?? null;
  const discountCode = created?.discount_code ?? body?.discount_code ?? 'N/A';
  const discountTitle = created?.discount_title ?? body?.discount_title ?? 'Untitled Discount';
  const discountType = created?.main_discount_type ?? body?.main_discount_type ?? 'discount';

  const prodMethod = created?.prod_discount_method ?? body?.prod_discount_method ?? null;
  const orderMethod = created?.order_discount_method ?? body?.order_discount_method ?? null;

  // friendly method string
  let methodStr = 'N/A';
  if (prodMethod && orderMethod) methodStr = `${prodMethod} / ${orderMethod}`;
  else if (prodMethod) methodStr = String(prodMethod);
  else if (orderMethod) methodStr = String(orderMethod);

  // build single-line phrase for admin_log.log (keeps schema unchanged)
  const logPhrase = `New ${discountType} discount created — ID: ${discountId ?? 'N/A'}, Title: ${String(
    discountTitle
  )}, Code: ${String(discountCode)}, Method: ${methodStr}`;

  console.log('ADMIN LOG PHRASE:', logPhrase, 'userId:', userId);

  // insert into admin_log using your existing helper (unchanged signature)
  await insertAdminLog(userId, 'discounts', logPhrase);
  console.log('Admin log inserted for discount id=', discountId);

  // build notification message (use same method string)
  const notifMsg = `New discount: "${discountTitle}" (ID: ${discountId ?? 'N/A'}), method: ${methodStr}`;

  // insert notification if helper exists
  if (typeof insertNotification === 'function') {
    try {
      await insertNotification(
        userId,
        'Discounts',
        'New Discount Added',
        notifMsg,
        'Website Notification',
        'Unread'
      );
      console.log('Notification inserted for discount id=', discountId);
    } catch (notifErr) {
      console.error('insertNotification error:', notifErr && (notifErr.message || notifErr));
    }
  } else {
    console.warn('insertNotification is not a function; skipping notification.');
  }
} catch (err) {
  console.error('Post-commit log/notification error:', err && (err.message || err));
}
// --- END REPLACEMENT ---


    return res.status(201).json({ ok: true, data: rows[0] });
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {}
    console.error("Error inserting discount:", err);
    return res
      .status(400)
      .json({ ok: false, error: err.message || "insert failed" });
  } finally {
    client.release();
  }
});

// fetch active payment methods

router.get("/active-payment-methods", authenticateToken, async (req, res) => {
  try {
    const sql = `
      SELECT 
        payment_method_id,
        -- adapt the column below if your table uses a different name field
        method_name
      FROM payment_methods
      WHERE COALESCE(status, 'inactive') = 'active' AND web_show IS TRUE
      ORDER BY method_name ASC;
    `;

    const { rows } = await pool.query(sql);
    return res.status(200).json({ ok: true, data: rows });
  } catch (err) {
    console.error("Fetch active payment methods failed:", err);
    return res.status(500).json({ ok: false, error: "Server error" });
  }
});

// product search
router.post("/discount-prod-search", authenticateToken, async (req, res) => {
  try {
    const raw = (req.body.q ?? "").toString().trim();
    const limit = Math.min(parseInt(req.body.limit, 10) || 20, 50);
    const offset = Math.max(parseInt(req.body.offset, 10) || 0, 0);

    if (!raw) {
      return res.status(400).json({ error: "Missing field: q" });
    }

    const isNumeric = /^[0-9]+$/.test(raw);

    // Text search must have ≥ 2 characters
    if (!isNumeric && raw.length < 2) {
      return res.status(422).json({
        error: "Please provide at least 2 characters for text search.",
      });
    }

    let sql;
    let params;

    if (isNumeric) {
      // Search by product_id OR title containing digits
      sql = `
        SELECT product_id, title
        FROM products
        WHERE (product_id = $1 OR title ILIKE $2)
        ORDER BY product_id DESC
        LIMIT $3 OFFSET $4;
      `;
      params = [Number(raw), `%${raw}%`, limit, offset];
    } else {
      // Text search by title
      sql = `
        SELECT product_id, title
        FROM products
        WHERE title ILIKE $1
        ORDER BY product_id DESC
        LIMIT $2 OFFSET $3;
      `;
      params = [`%${raw}%`, limit, offset];
    }

    const result = await pool.query(sql, params);
    return res.json({
      success: true,
      count: result.rows.length,
      data: result.rows,
    });
  } catch (err) {
    console.error("❌ Product search error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// brand fetch

router.get("/discount-brand-fetch", authenticateToken, async (req, res) => {
  try {
    const page = parseInt(req.body.page, 10) || 1;
    const limit = parseInt(req.body.limit, 10) || 20;
    const offset = (page - 1) * limit;

    const sql = `
      SELECT brand_id, name
      FROM brand
      WHERE LOWER(COALESCE(status, 'inactive')) = 'active'
      ORDER BY name ASC
      LIMIT $1 OFFSET $2;
    `;

    const result = await pool.query(sql, [limit, offset]);

    // total count for pagination
    const countResult = await pool.query(
      `SELECT COUNT(*) AS total FROM brand WHERE LOWER(COALESCE(status, 'inactive')) = 'active';`
    );

    const total = parseInt(countResult.rows[0].total, 10) || 0;
    const totalPages = Math.ceil(total / limit);

    res.json({
      success: true,
      page,
      limit,
      total,
      totalPages,
      items: result.rows,
    });
  } catch (err) {
    console.error("Error fetching brands:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// collection fetch

router.get(
"/discount-collections-fetch",
  authenticateToken,
  async (req, res) => {
    try {
      const merchantId = req.user?.merchant_id;
      if (!merchantId) {
        return res
          .status(403)
          .json({ error: "Merchant context missing in token" });
      }

      // Optional pagination (defaults)
      const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
      const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
      const offset = (page - 1) * limit;

      const sql = `
      SELECT collection_id, name
      FROM collections
      WHERE merchant_id = $1
        AND LOWER(COALESCE(status, 'inactive')) = 'active'
      ORDER BY name ASC
      LIMIT $2 OFFSET $3;
    `;

      const { rows } = await pool.query(sql, [merchantId, limit, offset]);

      // total for pagination (optional)
      const { rows: countRows } = await pool.query(
        `SELECT COUNT(*)::int AS total
       FROM collections
       WHERE merchant_id = $1
         AND LOWER(COALESCE(status, 'inactive')) = 'active';`,
        [merchantId]
      );

      res.json({
        success: true,
        page,
        limit,
        total: countRows[0]?.total ?? 0,
        items: rows,
      });
    } catch (err) {
      console.error("Active collections fetch error:", err);
      res.status(500).json({ error: "Internal server error" });
    }
  }
);

// discount table fetch
router.all("/discounts-table-fetch", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    // Accept from GET (querystring) or POST (body)
    const src = req.method === "GET" ? req.query : req.body || {};
    const page = Math.max(1, parseInt(src.page, 10) || 1);
    const perPageRaw = parseInt(src.per_page, 10);
    const perPage = Math.min(Math.max(1, perPageRaw || 25), 100);

    // Normalize filters
    const filters = src.filters || {};
    const type = (filters.type || src.type || "").toString().toLowerCase(); // 'order' | 'product'
    const state = (filters.state || src.state || "").toString().toLowerCase(); // 'active' | 'inactive' | 'scheduled' | 'expired'

    // Enforce: only allow up to two filters: (type) and (state)
    const chosen = [];
    if (type === "order" || type === "product")
      chosen.push({ k: "type", v: type });
    if (["active", "inactive", "scheduled", "expired"].includes(state))
      chosen.push({ k: "state", v: state });
    if (chosen.length > 2) {
      return res.status(422).json({
        ok: false,
        error: "Only up to two filters are allowed (type and state).",
      });
    }

    // Build WHERE conditions for the data query
    const where = [];
    const params = [];
    const add = (sqlFrag, val) => {
      params.push(val);
      const sql = sqlFrag.replace(/\$\?/g, () => `$${params.length}`);
      where.push(sql);
    };

    if (type) add("main_discount_type = $?", type);

    // ---- State filter logic ----
    if (state === "active") {
      where.push(
        `LOWER(COALESCE(status::text, '')) IN ('true','t','1','active')`
      );
    } else if (state === "inactive") {
      where.push(
        `LOWER(COALESCE(status::text, '')) IN ('false','f','0','inactive','')`
      );
    } else if (state === "scheduled") {
      where.push(`start_date IS NOT NULL AND start_date > NOW()`);
    } else if (state === "expired") {
      where.push(`end_date IS NOT NULL AND end_date < NOW()`);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    // Pagination
    const offset = (page - 1) * perPage;

    // ---------- Counts (respect current "type" filter only) ----------
    const countWhere = [];
    const countParams = [];
    const addCount = (sqlFrag, val) => {
      countParams.push(val);
      const sql = sqlFrag.replace(/\$\?/g, () => `$${countParams.length}`);
      countWhere.push(sql);
    };
    if (type) addCount("main_discount_type = $?", type);

    const baseCountWhereSql = countWhere.length
      ? `WHERE ${countWhere.join(" AND ")}`
      : "";

    // Reusable snippets for counts
    const activeConds = `LOWER(COALESCE(status::text, '')) IN ('true','t','1','active')`;
    const inactiveConds = `LOWER(COALESCE(status::text, '')) IN ('false','f','0','inactive','')`;
    const scheduledConds = `start_date IS NOT NULL AND start_date > NOW()`;
    const expiredConds = `end_date IS NOT NULL AND end_date < NOW()`;

    const withExtra = (extraSql) =>
      [
        baseCountWhereSql,
        extraSql
          ? baseCountWhereSql
            ? `AND ${extraSql}`
            : `WHERE ${extraSql}`
          : "",
      ]
        .join(" ")
        .trim();

    const allCountSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${baseCountWhereSql};
    `;
    const activeCountSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${withExtra(activeConds)};
    `;
    const inactiveCountSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${withExtra(inactiveConds)};
    `;
    const scheduledCountSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${withExtra(scheduledConds)};
    `;
    const expiredCountSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${withExtra(expiredConds)};
    `;

    const [
      { rows: allCntRows },
      { rows: actCntRows },
      { rows: inactCntRows },
      { rows: schCntRows },
      { rows: expCntRows },
    ] = await Promise.all([
      client.query(allCountSql, countParams),
      client.query(activeCountSql, countParams),
      client.query(inactiveCountSql, countParams),
      client.query(scheduledCountSql, countParams),
      client.query(expiredCountSql, countParams),
    ]);

    const counts = {
      all: Number(allCntRows[0]?.cnt || 0),
      active: Number(actCntRows[0]?.cnt || 0),
      inactive: Number(inactCntRows[0]?.cnt || 0),
      scheduled: Number(schCntRows[0]?.cnt || 0),
      expired: Number(expCntRows[0]?.cnt || 0),
    };

    // Count total (for current filters: type + optional state)
    const countSql = `
      SELECT COUNT(*)::bigint AS cnt
      FROM discounts
      ${whereSql};
    `;
    const { rows: countRows } = await client.query(countSql, params);
    const total = Number(countRows[0]?.cnt || 0);
    const totalPages = Math.max(1, Math.ceil(total / perPage));

    // Data query — return only required columns (stable response shape)
    const dataSql = `
      SELECT
        discount_id,
        main_discount_type,
        discount_title,
        discount_code,
        discount_value_type,
        order_discount_method,
        prod_discount_method,
        status
      FROM discounts
      ${whereSql}
      ORDER BY discount_id DESC
      LIMIT $${params.length + 1}
      OFFSET $${params.length + 2};
    `;
    const dataParams = [...params, perPage, offset];
    const { rows } = await client.query(dataSql, dataParams);

    // Map rows to override discount_title for code-based discounts
    const mappedRows = rows.map((row) => {
      if (row.order_discount_method === "code") {
        return {
          ...row,
          discount_title: row.discount_code || row.discount_title,
        };
      }
      return row;
    });

    return res.json({
      ok: true,
      page,
      per_page: perPage,
      total,
      total_pages: totalPages,
      filters: chosen.reduce((acc, { k, v }) => ({ ...acc, [k]: v }), {}),
      counts,
      data: mappedRows,
    });
  } catch (err) {
    console.error("search discounts error:", err);
    return res
      .status(400)
      .json({ ok: false, error: err.message || "failed to fetch discounts" });
  } finally {
    client.release();
  }
});

// ✅ Simple route: update discount status by ID (from payload)
router.put("/discounts-status", authenticateToken, async (req, res) => {
  try {
    const { discount_id, status } = req.body;

    if (
      !discount_id ||
      !["active", "inactive"].includes(status?.toLowerCase())
    ) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid discount_id or status." });
    }

    const result = await pool.query(
      `UPDATE discounts
       SET status = $1
       WHERE discount_id = $2
       RETURNING discount_id, status`,
      [status.toLowerCase(), discount_id]
    );

    if (result.rowCount === 0) {
      return res
        .status(404)
        .json({ success: false, message: "Discount not found." });
    }

    res.json({
      success: true,
      message: "Discount status updated successfully.",
      data: result.rows[0],
    });
  } catch (err) {
    console.error("Error updating discount status:", err);
    res.status(500).json({ success: false, message: "Internal server error." });
  }
});

// update discount routes

//fetch discount details..

// 📦 GET: Fetch single discount by ID
// =========================
router.get("/discount-fetch-prefill/:id",authenticateToken, async (req, res) => {
    const discountId = parseInt(req.params.id, 10);
    if (!Number.isInteger(discountId) || discountId <= 0) {
      return res
        .status(400)
        .json({ success: false, error: "Invalid discount_id" });
    }

    try {
      const sql = `
      SELECT
        d.discount_id,
        d.main_discount_type,                  -- 'product' | 'order'
        d.discount_title,
        d.discount_value_type,                 -- 'percentage' | 'fixed'
        d.discount_value,

        -- Purchase limits / caps
        d.min_max_purchase_discount_limits,
        d.min_purchase_amount,
        d.max_discount_amount,

        -- Eligibility
        d.customer_eligibility,                -- 'all' | 'new' | 'existing'
        d.is_guest_allowed,

        -- Usage limits (NOTE: renamed column)
        d.usage_limit_total,
        d.unlimited_usage,                     -- <- renamed from usage_limit_per_customer
        d.usage_limit_per_account,

        -- Dates
        d.start_date,
        d.end_date,

        -- Codes / BXGY (kept for completeness)
        d.discount_code,
        d.customer_buys_qty,
        d.customer_gets_qty,
        d.bxgy_max_limit,

        -- Methods / scope
        d.order_discount_method,               -- 'general' | 'code' | 'shipping' | 'payment_method'
        d.prod_discount_method,                -- if product-scoped

        -- Targeting (JSONB)
        d.target_products,
        d.target_collections,
        d.target_categories,
        d.target_brands,

        -- Payment method (INTEGER FK in your schema)
        d.payment_method,

        -- Lifecycle
        d.status                               -- you mentioned this column exists
      FROM discounts d
      WHERE d.discount_id = $1
      LIMIT 1;
    `;

      const result = await pool.query(sql, [discountId]);

      if (result.rowCount === 0) {
        return res
          .status(404)
          .json({ success: false, error: "Discount not found" });
      }

       const currencyQuery = `
        SELECT currency
        FROM system_settings
        LIMIT 1;
      `;
      const currencyResult = await pool.query(currencyQuery);
      const systemSettings = currencyResult.rows[0] || { currency: null };

      // Optionally coalesce JSONB fields to [] for safer front-end handling
      const row = result.rows[0];
      const data = {
        ...row,
        target_products: row.target_products ?? [],
        target_collections: row.target_collections ?? [],
        target_categories: row.target_categories ?? [],
        target_brands: row.target_brands ?? [],
          currency: systemSettings.currency,
      };

      return res.json({ success: true, data });
    } catch (err) {
      console.error("Error fetching discount:", err);
      return res.status(500).json({
        success: false,
        error: "Server error while fetching discount",
      });
    }
  }
);

// update product discount route

router.put("/update-product-discount/:id",authenticateToken, async (req, res) => {
    const client = await pool.connect();
    try {
      const discountId = Number(req.params.id);
      if (!Number.isInteger(discountId) || discountId <= 0) {
        return res
          .status(400)
          .json({ ok: false, error: "Invalid discount id" });
      }

      // --- helpers reused / local ---
      const intOrNull = (v, field) => {
        if (v === undefined || v === null || v === "") return null;
        const n = Number(v);
        if (!Number.isInteger(n))
          throw new Error(`${field} must be an integer`);
        return n;
      };
      const toIntArray = (v, field) => {
        if (v == null) return [];
        if (!Array.isArray(v))
          throw new Error(`${field} must be an array of integers`);
        const arr = v.map((n) => {
          const x = Number(n);
          if (!Number.isInteger(x))
            throw new Error(`${field} must be an array of integers`);
          return x;
        });
        return arr;
      };
      const hasOwn = (obj, key) =>
        Object.prototype.hasOwnProperty.call(obj || {}, key);

      // NOTE: toJsonb and toIdArrayJsonb are assumed to exist in your codebase,
      // as they were in the original route. They are not modified here.

      await client.query("BEGIN");

      // Fetch current row (to return unchanged response if needed)
      const curRes = await client.query(
        `SELECT * FROM discounts WHERE discount_id = $1 FOR UPDATE`,
        [discountId]
      );
      if (curRes.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "Discount not found" });
      }
      const currentRow = curRes.rows[0];

      // Check if payment_method column exists
      const paymentColCheck = await client.query(
        `
      SELECT 1
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'discounts'
        AND column_name = 'payment_method'
      `
      );
      const hasPaymentMethodCol = paymentColCheck.rowCount > 0;

      // ---------- VALIDATE ONLY PROVIDED FIELDS ----------
      const b = req.body || {};

      if (hasOwn(b, "main_discount_type")) {
        const v = String(b.main_discount_type || "").toLowerCase();
        if (!["product", "order"].includes(v)) {
          throw new Error("main_discount_type must be 'product' or 'order'");
        }
      }

      if (hasOwn(b, "discount_title")) {
        if (b.discount_title && String(b.discount_title).length > 125) {
          throw new Error("discount_title must be ≤ 125 chars");
        }
      }

      if (hasOwn(b, "prod_discount_method")) {
        const m = b.prod_discount_method;
        if (m && !["general", "code", "buyxgety"].includes(m)) {
          throw new Error(
            "prod_discount_method must be one of: general | code | buyxgety"
          );
        }
      }

      // ---------- NORMALIZE ONLY PROVIDED KEYS & BUILD SET LIST ----------
      const setCols = [];
      const setVals = [];
      const whereDiffParts = [];

      const add = (col, val) => {
        setCols.push(`"${col}" = $${setVals.length + 1}`);
        setVals.push(val);
        whereDiffParts.push(`"${col}" IS DISTINCT FROM $${setVals.length}`);
      };

      // 1) Simple scalars (validate only if present)
      if (hasOwn(b, "main_discount_type"))
        add("main_discount_type", b.main_discount_type ?? null);
      if (hasOwn(b, "prod_discount_method"))
        add("prod_discount_method", b.prod_discount_method ?? null);
      if (hasOwn(b, "order_discount_method"))
        add("order_discount_method", b.order_discount_method ?? null);
      if (hasOwn(b, "discount_title"))
        add("discount_title", b.discount_title ?? null);
      if (hasOwn(b, "discount_value_type"))
        add("discount_value_type", b.discount_value_type ?? null);
      if (hasOwn(b, "discount_value"))
        add("discount_value", b.discount_value ?? null);
      if (hasOwn(b, "min_max_purchase_discount_limits"))
        add(
          "min_max_purchase_discount_limits",
          b.min_max_purchase_discount_limits ?? null
        );
      if (hasOwn(b, "min_purchase_amount"))
        add("min_purchase_amount", b.min_purchase_amount ?? null);
      if (hasOwn(b, "max_discount_amount"))
        add("max_discount_amount", b.max_discount_amount ?? null);
      if (hasOwn(b, "customer_eligibility"))
        add("customer_eligibility", b.customer_eligibility ?? null);
      if (hasOwn(b, "is_guest_allowed"))
        add("is_guest_allowed", b.is_guest_allowed ?? null);
      if (hasOwn(b, "usage_limit_total"))
        add("usage_limit_total", b.usage_limit_total ?? null); // keep for backward-compat; can omit if you removed from UI
      if (hasOwn(b, "unlimited_usage"))
        add("unlimited_usage", b.unlimited_usage ?? null);
      if (hasOwn(b, "usage_limit_per_account"))
        add("usage_limit_per_account", b.usage_limit_per_account ?? null);
      if (hasOwn(b, "start_date")) add("start_date", b.start_date ?? null);
      if (hasOwn(b, "end_date")) add("end_date", b.end_date ?? null);

      if (hasOwn(b, "discount_code")) {
        const code =
          b.discount_code == null ? null : String(b.discount_code).slice(0, 12);
        add("discount_code", code);
      }

      if (hasOwn(b, "customer_buys_qty"))
        add(
          "customer_buys_qty",
          intOrNull(b.customer_buys_qty, "customer_buys_qty")
        );
      if (hasOwn(b, "customer_gets_qty"))
        add(
          "customer_gets_qty",
          intOrNull(b.customer_gets_qty, "customer_gets_qty")
        );
      if (hasOwn(b, "bxgy_max_limit"))
        add("bxgy_max_limit", intOrNull(b.bxgy_max_limit, "bxgy_max_limit"));

      // 2) JSONB / arrays (use your helpers)
      // ==== IMPORTANT: intentionally DO NOT update these columns even if provided ====
      // target_products, target_collections, target_categories, target_brands
      // If you want to return an error when these keys are present, replace the ignore below with an error response.
      if (
        hasOwn(b, "target_products") ||
        hasOwn(b, "target_collections") ||
        hasOwn(b, "target_categories") ||
        hasOwn(b, "target_brands")
      ) {
        // Intentionally ignore provided values for the above columns so they remain unchanged.
        // Optionally log or collect warnings here if needed.
        // e.g. console.warn("Ignored update for target_* columns in request body.");
      }

      if (hasPaymentMethodCol && hasOwn(b, "payment_method")) {
        add("payment_method", toIntArray(b.payment_method, "payment_method"));
      }

      if (setCols.length === 0) {
        await client.query("ROLLBACK");
        return res
          .status(400)
          .json({ ok: false, error: "No updatable fields in request body" });
      }

      // ---------- UPDATE only if something actually changes ----------
      const sql = `
      UPDATE discounts
      SET ${setCols.join(", ")}
      WHERE discount_id = $${setVals.length + 1}
        AND (${whereDiffParts.join(" OR ")})
      RETURNING *;
    `;
      const params = [...setVals, discountId];

      const updRes = await client.query(sql, params);

      if (updRes.rowCount === 0) {
        // No actual changes (all provided values equal to existing)
        await client.query("COMMIT");
        return res.status(200).json({
          ok: true,
          unchanged: true,
          data: currentRow,
        });
      }

      const updated = updRes.rows[0];

      await client.query("COMMIT");

    // --- SIMPLE ADMIN LOG & NOTIFICATION BLOCK (REPLACE WITH THIS) ---
(async () => {
  try {
    const userId =
      req.user?.user_id ||
      req.user?.id ||
      req.auth?.user_id ||
      req.auth?.id ||
      null;

    const discountId = updated?.discount_id ?? "N/A";
    const discountTitle = updated?.discount_title ?? "Untitled Discount";
    const discountMethod = updated?.prod_discount_method ?? "N/A";

    // 🔥 Simple readable phrase for admin_log.log
    const phrase = `Product discount updated: ID=${discountId}, Title="${discountTitle}", Method=${discountMethod}`;

    // Write admin log
    await insertAdminLog(userId, "discounts", phrase);

    // Send notification (unchanged)
    const message = `Product discount updated: "${discountTitle}" (ID: ${discountId})`;
    await insertNotification(
      userId,
      "Discounts",
      "Product Discount Updated",
      message,
      "Website Notification",
      "Unread"
    );
  } catch (err) {
    console.error("Post-commit update log error:", err?.message || err);
  }
})();
// --- END SIMPLE ADMIN LOG & NOTIFICATION BLOCK ---

      return res.status(200).json({ ok: true, data: updated });
    } catch (err) {
      try {
        await client.query("ROLLBACK");
      } catch (_) {}
      return res
        .status(400)
        .json({ ok: false, error: err.message || "update failed" });
    } finally {
      client.release();
    }
  }
);

// update order route

// UPDATE: Order Discount
router.put("/update-order-discount/:id", authenticateToken, async (req, res) => {
    const client = await pool.connect();
    try {
      const discountId = Number(req.params.id);
      if (!Number.isInteger(discountId) || discountId <= 0) {
        return res
          .status(400)
          .json({ ok: false, error: "Invalid discount id" });
      }

      // --- helpers ---
      const hasOwn = (obj, key) =>
        Object.prototype.hasOwnProperty.call(obj || {}, key);

      // Keep semantics close to your /add route: accept array | string | single value -> int[]
      const normalizePaymentMethod = (payment_method) => {
        if (payment_method == null || payment_method === "") return null; // don't change by default
        let tmp = [];
        if (Array.isArray(payment_method)) tmp = payment_method;
        else if (typeof payment_method === "string") {
          const s = payment_method.trim();
          if (s) tmp = s.startsWith("[") ? JSON.parse(s) : s.split(",");
        } else tmp = [].concat(payment_method);
        const ints = tmp
          .map(Number)
          .filter((n) => Number.isInteger(n) && n > 0);
        return Array.from(new Set(ints));
      };

      // Optional: light validators mirroring your style
      const validateIfPresent = {
        main_discount_type(v) {
          if (v == null) return;
          const s = String(v).toLowerCase();
          if (!["order", "product"].includes(s)) {
            throw new Error("main_discount_type must be 'order' or 'product'");
          }
        },
        discount_title(v) {
          if (v && String(v).length > 125) {
            throw new Error("discount_title must be ≤ 125 chars");
          }
        },
        discount_code(v) {
          if (v == null) return;
          if (String(v).length > 12) {
            throw new Error("discount_code must be ≤ 12 chars");
          }
        },
        start_end_dates({ start_date, end_date }) {
          if (start_date && end_date) {
            const sd = new Date(start_date);
            const ed = new Date(end_date);
            if (!isNaN(sd) && !isNaN(ed) && ed < sd) {
              throw new Error("end_date must be on/after start_date");
            }
          }
        },
      };

      await client.query("BEGIN");

      // Lock current row so we can detect no-op updates safely
      const curRes = await client.query(
        `SELECT * FROM discounts WHERE discount_id = $1 FOR UPDATE`,
        [discountId]
      );
      if (curRes.rowCount === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ ok: false, error: "Discount not found" });
      }
      const currentRow = curRes.rows[0];

      // Detect if payment_method column exists
      const colCheck = await client.query(
        `SELECT 1
       FROM information_schema.columns
       WHERE table_schema='public' AND table_name='discounts' AND column_name='payment_method'`
      );
      const hasPaymentMethodCol = colCheck.rowCount > 0;

      // ---------- VALIDATE ONLY PROVIDED FIELDS ----------
      const b = req.body || {};
      validateIfPresent.main_discount_type(b.main_discount_type);
      validateIfPresent.discount_title(b.discount_title);
      validateIfPresent.discount_code(b.discount_code);
      validateIfPresent.start_end_dates({
        start_date: b.start_date,
        end_date: b.end_date,
      });

      // ---------- BUILD DYNAMIC UPDATE ----------
      const setCols = [];
      const setVals = [];
      const whereDiffParts = [];
      const add = (col, val) => {
        setCols.push(`"${col}" = $${setVals.length + 1}`);
        setVals.push(val);
        whereDiffParts.push(`"${col}" IS DISTINCT FROM $${setVals.length}`);
      };

      // Scalars (order-discount related; align with your ADD route)
      if (hasOwn(b, "main_discount_type"))
        add("main_discount_type", b.main_discount_type ?? null);
      if (hasOwn(b, "discount_title"))
        add("discount_title", b.discount_title ?? null);
      if (hasOwn(b, "discount_value_type"))
        add("discount_value_type", b.discount_value_type ?? null);
      if (hasOwn(b, "discount_value"))
        add("discount_value", b.discount_value ?? null);
      if (hasOwn(b, "min_max_purchase_discount_limits"))
        add(
          "min_max_purchase_discount_limits",
          b.min_max_purchase_discount_limits ?? null
        );
      if (hasOwn(b, "min_purchase_amount"))
        add("min_purchase_amount", b.min_purchase_amount ?? null);
      if (hasOwn(b, "max_discount_amount"))
        add("max_discount_amount", b.max_discount_amount ?? null);
      if (hasOwn(b, "customer_eligibility"))
        add("customer_eligibility", b.customer_eligibility ?? null);
      if (hasOwn(b, "is_guest_allowed"))
        add("is_guest_allowed", b.is_guest_allowed ?? null);
      if (hasOwn(b, "usage_limit_total"))
        add("usage_limit_total", b.usage_limit_total ?? null); // kept for backward compat
      if (hasOwn(b, "unlimited_usage"))
        add("unlimited_usage", b.unlimited_usage ?? null);
      if (hasOwn(b, "usage_limit_per_account"))
        add("usage_limit_per_account", b.usage_limit_per_account ?? null);
      if (hasOwn(b, "status")) add("status", b.status ?? null);
      if (hasOwn(b, "start_date")) add("start_date", b.start_date ?? null);
      if (hasOwn(b, "end_date")) add("end_date", b.end_date ?? null);
      if (hasOwn(b, "order_discount_method"))
        add("order_discount_method", b.order_discount_method ?? null);

      if (hasOwn(b, "discount_code")) {
        const code =
          b.discount_code == null ? null : String(b.discount_code).slice(0, 12);
        add("discount_code", code);
      }

      // Optional payment_method (int[]) if column exists
      if (hasPaymentMethodCol && hasOwn(b, "payment_method")) {
        const arr = normalizePaymentMethod(b.payment_method);
        // Note: use explicit cast to int[] like your ADD route for consistent typing
        setCols.push(`"payment_method" = $${setVals.length + 1}::int[]`);
        setVals.push(arr);
        whereDiffParts.push(
          `"payment_method" IS DISTINCT FROM $${setVals.length}::int[]`
        );
      }

      if (setCols.length === 0) {
        await client.query("ROLLBACK");
        return res
          .status(400)
          .json({ ok: false, error: "No updatable fields in request body" });
      }

      const sql = `
      UPDATE discounts
      SET ${setCols.join(", ")}
      WHERE discount_id = $${setVals.length + 1}
        AND (${whereDiffParts.join(" OR ")})
      RETURNING *;
    `;
      const params = [...setVals, discountId];

      const updRes = await client.query(sql, params);

      if (updRes.rowCount === 0) {
        // No actual changes (all provided values equal to existing)
        await client.query("COMMIT");
        return res.status(200).json({
          ok: true,
          unchanged: true,
          data: currentRow,
        });
      }

      const updated = updRes.rows[0];

      await client.query("COMMIT");

      // --- SIMPLE ADMIN LOG & NOTIFICATION BLOCK (REPLACE WITH THIS) ---
(async () => {
  try {
    const userId =
      req.user?.user_id ||
      req.user?.id ||
      req.auth?.user_id ||
      req.auth?.id ||
      null;

    const discountId = updated?.discount_id ?? "N/A";
    const discountTitle = updated?.discount_title ?? "Untitled Discount";
    const discountMethod = updated?.order_discount_method ?? "N/A";

    // 🔥 Simple detailed phrase for admin_log.log
    const phrase = `Order discount updated: ID=${discountId}, Title="${discountTitle}", Method=${discountMethod}`;

    // Write admin log
    await insertAdminLog(userId, "discounts", phrase);

    // Send notification (unchanged)
    const message = `Order discount updated: "${discountTitle}" (ID: ${discountId})`;
    await insertNotification(
      userId,
      "Discounts",
      "Order Discount Updated",
      message,
      "Website Notification",
      "Unread"
    );
  } catch (err) {
    console.error("Post-commit update log error:", err?.message || err);
  }
})();
// --- END SIMPLE ADMIN LOG & NOTIFICATION BLOCK ---

      return res.status(200).json({ ok: true, data: updated });
    } catch (err) {
      try {
        await client.query("ROLLBACK");
      } catch (_) {}
      return res
        .status(400)
        .json({ ok: false, error: err.message || "update failed" });
    } finally {
      client.release();
    }
  }
);

// duplicate the discount row for the sent id from the payload

router.post("/duplicate-discount", authenticateToken, async (req, res) => {
  const { discount_id } = req.body;
  if (!discount_id) {
    return res.status(400).json({ error: "discount_id is required in body" });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // 1) Lock + set original inactive, return full row for duplication
    const updSql = `
      UPDATE discounts
      SET status = 'inactive'
      WHERE discount_id = $1
      RETURNING
        discount_id,
        main_discount_type,
        target_products,
        target_collections,
        target_categories,
        target_brands,
        prod_discount_method,
        discount_title,
        discount_value_type,
        discount_value,
        min_max_purchase_discount_limits,
        min_purchase_amount,
        max_discount_amount,
        customer_eligibility,
        is_guest_allowed,
        usage_limit_total,
        unlimited_usage,
        usage_limit_per_account,
        start_date,
        end_date,
        discount_code,
        bxgy_max_limit,
        order_discount_method,
        status,
        customer_buys_qty,
        customer_gets_qty,
        payment_method
    `;
    const { rows: updRows } = await client.query(updSql, [discount_id]);
    if (updRows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "discount not found" });
    }
    const src = updRows[0];

    // 2) Decide new row values
    const newStatus = "active"; // or 'draft' if you prefer
    const newCode = src.discount_code
      ? `${src.discount_code}-copy-${Date.now()}`
      : null; // set your own logic if discount_code required

    // 3) Insert the duplicate row (explicit column list, excludes discount_id)
    const insSql = `
      INSERT INTO discounts (
        main_discount_type,
        target_products,
        target_collections,
        target_categories,
        target_brands,
        prod_discount_method,
        discount_title,
        discount_value_type,
        discount_value,
        min_max_purchase_discount_limits,
        min_purchase_amount,
        max_discount_amount,
        customer_eligibility,
        is_guest_allowed,
        usage_limit_total,
        unlimited_usage,
        usage_limit_per_account,
        start_date,
        end_date,
        discount_code,
        bxgy_max_limit,
        order_discount_method,
        status,
        customer_buys_qty,
        customer_gets_qty,
        payment_method
      )
      VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26
      )
      RETURNING discount_id
    `;

    const insParams = [
      src.main_discount_type,
      src.target_products,
      src.target_collections,
      src.target_categories,
      src.target_brands,
      src.prod_discount_method,
      src.discount_title,
      src.discount_value_type,
      src.discount_value,
      src.min_max_purchase_discount_limits,
      src.min_purchase_amount,
      src.max_discount_amount,
      src.customer_eligibility,
      src.is_guest_allowed,
      src.usage_limit_total,
      src.unlimited_usage,
      src.usage_limit_per_account,
      src.start_date,
      src.end_date,
      newCode,
      src.bxgy_max_limit,
      src.order_discount_method,
      newStatus,
      src.customer_buys_qty,
      src.customer_gets_qty,
      src.payment_method,
    ];

    const { rows: insRows } = await client.query(insSql, insParams);
    const newId = insRows[0].discount_id;

    await client.query("COMMIT");
    return res.status(201).json({
      message: "Discount duplicated. Original set to inactive.",
      original_id: src.discount_id,
      new_id: newId,
      new_discount_code: newCode,
      new_status: newStatus,
    });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);
    return res
      .status(500)
      .json({ error: "Failed to duplicate discount", details: err.message });
  } finally {
    client.release();
  }
});

// target brands,collections, products fetch
router.post("/discount-targets", authenticateToken, async (req, res) => {
  const { discount_id } = req.body;

  if (!discount_id) {
    return res.status(400).json({ error: "discount_id is required" });
  }

  const query = `
    SELECT
      d.discount_id,

      COALESCE((
        SELECT json_agg(json_build_object('id', p.product_id, 'title', p.title))
        FROM unnest(d.target_products) AS pid
        JOIN products p ON p.product_id = pid
      ), '[]'::json) AS products,

      COALESCE((
        SELECT json_agg(json_build_object('id', c.collection_id, 'name', c.name))
        FROM unnest(d.target_collections) AS cid
        JOIN collections c ON c.collection_id = cid
      ), '[]'::json) AS collections,

      COALESCE((
        SELECT json_agg(json_build_object('id', cat.category_id, 'name', cat.name))
        FROM unnest(d.target_categories) AS catid
        JOIN categories cat ON cat.category_id = catid
      ), '[]'::json) AS categories,

      COALESCE((
        SELECT json_agg(json_build_object('id', b.brand_id, 'name', b.name))
        FROM unnest(d.target_brands) AS bid
        JOIN brand b ON b.brand_id = bid
      ), '[]'::json) AS brands

    FROM discounts d
    WHERE d.discount_id = $1;
  `;

  try {
    const { rows } = await pool.query(query, [discount_id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: "Discount not found" });
    }

    const data = rows[0];
    return res.json({
      discount_id: data.discount_id,
      products: data.products,
      collections: data.collections,
      categories: data.categories,
      brands: data.brands,
    });
  } catch (error) {
    console.error("Error fetching discount targets:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// check discount code match

router.post("/check-discount-code", authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const { discount_code } = req.body;

    // Validate input
    if (!discount_code || discount_code.toString().trim().length < 2) {
      return res.status(400).json({
        ok: false,
        error: "Discount code must be at least 2 characters.",
      });
    }

    const codeToCheck = discount_code.toString().trim();

    // Query to check if code exists (case-insensitive)
    const { rows } = await client.query(
      `SELECT 1 FROM discounts WHERE LOWER(discount_code) = LOWER($1) LIMIT 1`,
      [codeToCheck]
    );

    const matched = rows.length > 0;

    return res.json({ ok: true, matched });
  } catch (err) {
    console.error("check discount code error:", err);
    return res
      .status(500)
      .json({
        ok: false,
        error: err.message || "Failed to check discount code",
      });
  } finally {
    client.release();
  }
});



// fetch system currency 

router.get("/currency", async (req, res) => {
  try {
    const result = await pool.query("SELECT currency FROM system_settings LIMIT 1");

    let rows = [];

    if (Array.isArray(result)) rows = Array.isArray(result[0]) ? result[0] : result;
    else if (result?.rows) rows = result.rows;

    if (!rows.length) return res.status(404).json({ error: "No settings found" });

    res.json({ currency: rows[0].currency });
  } catch (err) {
    console.error("Currency fetch error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});





module.exports = router;
