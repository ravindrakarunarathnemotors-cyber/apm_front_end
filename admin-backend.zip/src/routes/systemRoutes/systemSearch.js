const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertNotification } = require("../../models/notificationsUpdater");

router.get("/search", authenticateToken, async (req, res) => {
  const { q = "", filter = "", page = 1 } = req.query;
  const { merchant_id } = req.user;

  if (!q.trim()) return res.status(400).json({ message: "Query required" });

  const currentPage = parseInt(page) || 1;
  const pageSize = 25;
  const offset = (currentPage - 1) * pageSize;

  const searchTerm = `%${q.trim()}%`;
  const exactSearchTerm = q.trim();
  const isExactIdSearch = /^\d+$/.test(exactSearchTerm); // True if q is all digits

  const groupedResults = {};

  try {
    const allowedFilters = [
      "Products",
      "Customers",
      "Orders",
      "Menu",
      "Quotations",
      "Invoices",
    ];
    const normalizedFilter =
      allowedFilters.find((f) => f.toLowerCase() === filter.toLowerCase()) ||
      "";

    // PRODUCTS
    if (!normalizedFilter || normalizedFilter === "Products") {
      const productQuery = `
    SELECT p.product_id, p.title, p.status
    FROM products p
  WHERE p.merchant_id = $2 AND (
  LOWER(p.title) LIKE LOWER($1)
  OR p.product_id::text = $3
  OR EXISTS (
    SELECT 1
    FROM unnest(p.similar_keywords) kw
    WHERE LOWER(kw) LIKE LOWER($1)
  )
)

    LIMIT $4 OFFSET $5
  `;

      const variantQuery = `
    SELECT 
      p.product_id,
      p.title AS product_title,
      pv.variant_id,
      pv.variant_type,
      pv.variant_value,
      pv.barcode,
      pv.status AS variant_status
    FROM product_variants pv
    JOIN products p ON pv.product_id = p.product_id
   WHERE p.merchant_id = $2 AND (
  LOWER(pv.variant_type) LIKE LOWER($1)
  OR LOWER(pv.variant_value) LIKE LOWER($1)
  OR LOWER(pv.barcode) LIKE LOWER($1)
  OR EXISTS (
    SELECT 1
    FROM unnest(p.similar_keywords) kw
    WHERE LOWER(kw) LIKE LOWER($1)
  )
  ${isExactIdSearch ? "OR pv.variant_id::text = $1" : ""}
)

    LIMIT $3 OFFSET $4
  `;

      const productParams = [
        searchTerm,
        merchant_id,
        exactSearchTerm,
        pageSize,
        offset,
      ];
      const variantParams = isExactIdSearch
        ? [exactSearchTerm, merchant_id, pageSize, offset]
        : [searchTerm, merchant_id, pageSize, offset];

      const [products, variants] = await Promise.all([
        pool.query(productQuery, productParams),
        pool.query(variantQuery, variantParams),
      ]);

      const productMap = {};
      products.rows.forEach((p) => {
        if (!productMap[p.product_id]) {
          productMap[p.product_id] = {
            product_id: p.product_id,
            title: p.title,
            status: p.status,
            variants: [],
          };
        }
      });

      variants.rows.forEach((v) => {
        if (!productMap[v.product_id]) {
          productMap[v.product_id] = {
            product_id: v.product_id,
            title: v.product_title,
            variants: [],
          };
        }
        productMap[v.product_id].variants.push({
          variant_id: v.variant_id,
          variant_type: v.variant_type,
          variant_value: v.variant_value,
          status: v.variant_status,
        });
      });

      groupedResults.Products = Object.values(productMap);
    }

    // CUSTOMERS
    if (!normalizedFilter || normalizedFilter === "Customers") {
      const customerQuery = `
        SELECT customer_id, first_name, last_name, email, city
        FROM customer
        WHERE (
          LOWER(first_name || ' ' || COALESCE(last_name, '') || ' ' || COALESCE(email, '') || ' ' || COALESCE(city, '')) LIKE LOWER($1)
          OR customer_id::text = $2
        )
        LIMIT $3 OFFSET $4
      `;
      const customerResult = await pool.query(customerQuery, [
        searchTerm,
        exactSearchTerm,
        pageSize,
        offset,
      ]);
      groupedResults.Customers = customerResult.rows;

      const customerIds = customerResult.rows.map((c) => c.customer_id);
      if (customerIds.length > 0) {
        const orderQuery = `
        SELECT 
          order_id,
          customer_id,
          payment_status,
          cod,
          tracking_id
        FROM orders
        WHERE customer_id = ANY($1::int[])
      `;
        const orderResult = await pool.query(orderQuery, [customerIds]);
        groupedResults.OrdersFromCustomers = orderResult.rows;
      }
    }

    // ORDERS
    if (!normalizedFilter || normalizedFilter === "Orders") {
      const orderQuery = `
        SELECT 
          o.order_id, 
          o.customer_id, 
          o.payment_status, 
          o.cod,
          c.first_name,
          c.last_name,
          c.email
        FROM orders o
        LEFT JOIN customer c ON o.customer_id = c.customer_id
        WHERE o.order_id::text = $1 OR o.order_id::text LIKE $2
        LIMIT $3 OFFSET $4
      `;
      const orderResult = await pool.query(orderQuery, [
        exactSearchTerm,
        searchTerm,
        pageSize,
        offset,
      ]);
      groupedResults.Orders = orderResult.rows;
    }

    // QUOTATIONS
    if (!normalizedFilter || normalizedFilter === "Quotations") {
      const quotationQuery = `
    SELECT DISTINCT
      q.id,
      q.status,
      q.total_value,
      q.currency,
      q.sender_name,
      q.sender_email
    FROM quotation_header q
    LEFT JOIN quotation_details d 
      ON q.id = d.quotation_id
    WHERE q.merchant_id = $2
    AND (
      -- Header searches
      q.id::text = $3
      OR q.id::text LIKE $1
      OR LOWER(q.sender_name) LIKE LOWER($1)
      OR LOWER(q.sender_email) LIKE LOWER($1)

      -- Product / Variant search
      OR d.product_id::text = $3
      OR d.variant_id::text = $3
    )
    ORDER BY q.id DESC
    LIMIT $4 OFFSET $5
  `;

      const quotationParams = [
        searchTerm,
        merchant_id,
        exactSearchTerm,
        pageSize,
        offset,
      ];

      const quotationResult = await pool.query(quotationQuery, quotationParams);

      groupedResults.Quotations = quotationResult.rows;
    }

    // INVOICES
    if (!normalizedFilter || normalizedFilter === "Invoices") {
      const invoiceQuery = `
    SELECT DISTINCT
      i.id,
      i.order_status,
      i.payment_status,
      i.total_value,
      i.currency,
      i.sender_name,
      i.sender_email
    FROM invoice_header i
    LEFT JOIN invoice_details d 
      ON i.id = d.invoice_id
    WHERE i.merchant_id = $2
    AND (
      -- Header searches
      i.id::text = $3
      OR i.id::text LIKE $1
      OR LOWER(i.sender_name) LIKE LOWER($1)
      OR LOWER(i.sender_email) LIKE LOWER($1)

      -- Product / Variant search
      OR d.product_id::text = $3
      OR d.variant_id::text = $3
    )
    ORDER BY i.id DESC
    LIMIT $4 OFFSET $5
  `;

      const invoiceParams = [
        searchTerm,
        merchant_id,
        exactSearchTerm,
        pageSize,
        offset,
      ];

      const invoiceResult = await pool.query(invoiceQuery, invoiceParams);

      groupedResults.Invoices = invoiceResult.rows;
    }

    // MENU
    if (!normalizedFilter || normalizedFilter === "Menu") {
      const menuQuery = `
        SELECT id, name, route, parent_id
        FROM uimenudata
        WHERE LOWER(name || ' ' || COALESCE(route, '')) LIKE LOWER($1)
        LIMIT $2 OFFSET $3
      `;
      const menuResult = await pool.query(menuQuery, [
        searchTerm,
        pageSize,
        offset,
      ]);

      const parentIds = [
        ...new Set(menuResult.rows.map((r) => r.parent_id).filter(Boolean)),
      ];

      let parentMap = {};
      if (parentIds.length > 0) {
        const parentQuery = `
          SELECT id, name
          FROM uimenudata
          WHERE id = ANY($1::int[])
        `;
        const parentResult = await pool.query(parentQuery, [parentIds]);
        parentMap = parentResult.rows.reduce((acc, row) => {
          acc[row.id] = row.name;
          return acc;
        }, {});
      }

      // Remove duplicates
      const seen = new Set();
      const enrichedMenus = [];

      for (const menu of menuResult.rows) {
        const key = `${menu.name}-${menu.parent_id}`;
        if (!seen.has(key)) {
          seen.add(key);
          enrichedMenus.push({
            ...menu,
            parent_name: parentMap[menu.parent_id] || null,
          });
        }
      }

      groupedResults.Menu = enrichedMenus;
    }

    groupedResults.pagination = {
      currentPage,
      pageSize,
    };

    return res.json(groupedResults);
  } catch (error) {
    console.error("Search error:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// system notificationa

/**
 * GET /notifications?page=1
 * Fetch notifications for logged-in user (from token), grouped by module,
 * ordered most recent first, paginated (10 per page)
 */

/**
 * Convert UTC timestamp to Sri Lanka local time and calculate precise "time ago"
 */
const timeAgoSriLanka = (dbDate) => {
  const dbTime = new Date(dbDate); // use DB time directly

  const now = new Date();
  let diffSeconds = Math.floor((now.getTime() - dbTime.getTime()) / 1000);

  if (diffSeconds < 60) return `${diffSeconds} sec ago`;

  const days = Math.floor(diffSeconds / 86400);
  diffSeconds %= 86400;

  const hours = Math.floor(diffSeconds / 3600);
  diffSeconds %= 3600;

  const minutes = Math.floor(diffSeconds / 60);
  const seconds = diffSeconds % 60;

  let result = "";
  if (days > 0) result += `${days} day${days > 1 ? "s" : ""} `;
  if (hours > 0) result += `${hours} hr `;
  if (minutes > 0) result += `${minutes} min `;
  if (days === 0 && hours === 0 && minutes === 0) result += `${seconds} sec `;

  return result.trim() + " ago";
};

router.get("/admin-notifications", authenticateToken, async (req, res) => {
  try {
    const session_user_id = req.user?.user_id;
    if (!session_user_id) {
      return res.status(401).json({
        success: false,
        error: "Unauthorized: user_id missing in token",
      });
    }

    const page = parseInt(req.query.page, 10) || 1;
    const limit = 10;
    const offset = (page - 1) * limit;

    const query = `
      SELECT notification_id, user_id, module, event_type, channel, message_template, status, created_at, updated_at
      FROM notifications
      WHERE user_id = $1 OR user_id IS NULL
      ORDER BY
        CASE WHEN status = 'Unread' THEN 1 ELSE 0 END DESC,
        created_at DESC
      LIMIT $2 OFFSET $3
    `;
    const { rows } = await pool.query(query, [session_user_id, limit, offset]);

    // Group notifications by module
    const grouped = rows.reduce((acc, notif) => {
      if (!acc[notif.module]) acc[notif.module] = [];

      acc[notif.module].push({
        notification_id: notif.notification_id,
        module: notif.module, // ✅ explicitly keep module
        event_type: notif.event_type,
        channel: notif.channel,
        message_template: notif.message_template,
        status: notif.status,
        created_at: notif.created_at,
        updated_at: notif.updated_at,
        time_ago: timeAgoSriLanka(notif.created_at),
      });

      return acc;
    }, {});

    // Count for pagination
    const countQuery = `
      SELECT COUNT(*) FROM notifications 
      WHERE user_id = $1 OR user_id IS NULL
    `;
    const { rows: countRows } = await pool.query(countQuery, [session_user_id]);
    const total = parseInt(countRows[0].count, 10);
    const totalPages = Math.ceil(total / limit);

    res.status(200).json({
      success: true,
      page,
      totalPages,
      totalNotifications: total,
      data: grouped,
    });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// mark viewed notifications as read

router.patch("/mark-read", authenticateToken, async (req, res) => {
  try {
    const user_id = req.user?.user_id;
    const { notification_ids, is_viewed } = req.body; // is_viewed -> map to status

    if (!user_id) {
      return res.status(401).json({ success: false, error: "Unauthorized" });
    }

    // must be a non-empty array of numbers
    const ids = Array.isArray(notification_ids)
      ? notification_ids.map(Number).filter(Number.isFinite)
      : [];
    if (ids.length === 0) {
      return res
        .status(400)
        .json({ success: false, error: "notification_ids[] required" });
    }

    // Decide status to set
    let statusToSet = "Read";
    if (typeof is_viewed === "boolean") {
      statusToSet = is_viewed ? "Read" : "Unread";
    }

    // ✅ Allow updating notifications where user_id matches OR is NULL (global)
    const sql = `
      UPDATE notifications
      SET status = $3,
          updated_at = NOW()
      WHERE (user_id = $1 OR user_id IS NULL)
        AND notification_id = ANY($2::int[])
    `;

    const { rowCount } = await pool.query(sql, [user_id, ids, statusToSet]);

    if (rowCount === 0) {
      return res.status(404).json({
        success: false,
        error: "No matching notifications for this user/ids",
      });
    }

    return res.status(200).json({
      success: true,
      message: `Notifications marked as ${statusToSet}`,
      updated_count: rowCount,
      updated_ids: ids, // optional: include which ones were updated
    });
  } catch (error) {
    console.error("Error updating notifications:", error);
    return res
      .status(500)
      .json({ success: false, error: "Internal Server Error" });
  }
});

// GET unread notifications count

// GET unread notifications count + IDs
router.get("/unread-count", authenticateToken, async (req, res) => {
  try {
    const user_id = req.user?.user_id;

    let query;
    let params = [];

    if (user_id) {
      // Get unread notifications for this user (including global ones)
      query = `
        SELECT notification_id
        FROM notifications
        WHERE (user_id = $1 OR user_id IS NULL) 
          AND status = 'Unread'
      `;
      params = [user_id];
    } else {
      // No user context: get all unread notifications
      query = `
        SELECT notification_id
        FROM notifications
        WHERE status = 'Unread'
      `;
    }

    const { rows } = await pool.query(query, params);

    const unreadIds = rows.map((row) => row.notification_id);

    res.status(200).json({
      success: true,
      unreadCount: unreadIds.length,
      unreadIds, // array of notification IDs
    });
  } catch (error) {
    console.error("Error fetching unread notifications count:", error);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

// tester
router.post("/test-insert", async (req, res) => {
  try {
    const { user_id, module, event_type, message_template, channel, status } =
      req.body;

    if (!user_id || !module || !event_type || !message_template || !channel) {
      return res.status(400).json({
        success: false,
        error:
          "Missing required fields: user_id, module, event_type, message_template, channel",
      });
    }

    // Insert into DB
    await insertNotification(
      user_id,
      module,
      event_type,
      message_template,
      channel,
      status,
    );

    res.status(201).json({
      success: true,
      message: "Notification inserted successfully",
      data: {
        user_id,
        module,
        event_type,
        message_template,
        channel,
        status: status || "Pending",
      },
    });
  } catch (error) {
    console.error("Error in test-insert route:", error);
    res.status(500).json({ success: false, error: "Internal Server Error" });
  }
});

module.exports = router;
