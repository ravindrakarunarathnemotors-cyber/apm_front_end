const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
/**
 * POST /system-logs
 * Body:
 *  {
 *    page?: number (default 1),
 *    limit?: number (ignored; we enforce 25/page),
 *    id?: number,                      // filter by log id
 *    logname?: string,                 // filter by module (ILIKE)
 *    description?: string,             // filter by log text (ILIKE)
 *    log_at?: string (YYYY-MM-DD)      // filter by date (date only)
 *  }
 */
router.post("/system-logs", authenticateToken, async (req, res) => {
  try {
    const {
      page = 1,
      // limit is intentionally ignored to enforce 25/page
      id,
      logname, // maps to sl.module
      description, // maps to sl.log
      log_at, // date only
    } = req.body;

    const parsedPage =
      Number.isFinite(+page) && +page > 0 ? parseInt(page, 10) : 1;
    const parsedLimit = 25; // enforce 25 per page (as requested)
    const offset = (parsedPage - 1) * parsedLimit;

    const whereConditions = [];
    const params = [];

    if (id) {
      params.push(id);
      whereConditions.push(`sl.id = $${params.length}`);
    }

    if (description) {
      params.push(`%${description}%`);
      whereConditions.push(`sl.log ILIKE $${params.length}`);
    }

    if (logname) {
      params.push(`%${logname}%`);
      whereConditions.push(`sl.module ILIKE $${params.length}`);
    }

    if (log_at) {
      // "date" is a quoted identifier in this table; always reference as sl."date"
      params.push(log_at);
      whereConditions.push(`sl."date"::date = $${params.length}`);
    }

    const whereClause = whereConditions.length
      ? `WHERE ${whereConditions.join(" AND ")}`
      : "";

    // Main paginated query with user name join
    const dataSql = `
      SELECT
        sl.id,
        sl.user_id,
        u.first_name,
        u.last_name,
        sl.module,
        sl.log,
        sl."date" AS log_at
      FROM public.system_log sl
      LEFT JOIN public.users u ON u.user_id = sl.user_id
      ${whereClause}
      ORDER BY sl."date" DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
    const dataParams = [...params, parsedLimit, offset];
    const { rows } = await pool.query(dataSql, dataParams);

    // Count for pagination
    const countSql = `
      SELECT COUNT(*)::int AS total
      FROM public.system_log sl
      ${whereClause}
    `;
    const { rows: countRows } = await pool.query(countSql, params);
    const total = countRows[0]?.total ?? 0;

    res.json({
      logs: rows, // array of records with user names
      total, // total matching rows
      totalPages: Math.ceil(total / parsedLimit),
      currentPage: parsedPage,
      pageSize: parsedLimit,
    });
  } catch (error) {
    console.error("Error fetching system logs:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/system-logs/modules", authenticateToken, async (req, res) => {
  try {
    const { q, limit } = req.query;

    const params = [];
    const where = [
      `module IS NOT NULL`,
      `TRIM(module) <> ''`,
      q ? `module ILIKE $${params.push(`%${q}%`)}` : null,
    ]
      .filter(Boolean)
      .join(" AND ");

    // Case-insensitive unique list, keep a representative original-cased value
    const sql = `
      SELECT MIN(TRIM(module)) AS module
      FROM public.system_log
      WHERE ${where}
      GROUP BY LOWER(TRIM(module))
      ORDER BY LOWER(MIN(TRIM(module)))
      LIMIT $${params.push(Number(limit) > 0 ? Number(limit) : 100)}
    `;

    const { rows } = await pool.query(sql, params);
    res.json({ modules: rows.map((r) => r.module) });
  } catch (error) {
    console.error("Error fetching unique modules:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
