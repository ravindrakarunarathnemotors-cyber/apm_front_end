const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();

// GET /api/orders/status-counts
router.get("/order-summary", authenticateToken, async (req, res) => {
  try {
    const merchantId =
      req.user?.merchant_id ?? req.user?.merchantId ?? req.merchant_id ?? null;

    if (!merchantId) {
      return res.status(401).json({
        error: "Unauthorized: merchant_id missing from token",
      });
    }

    const { range = "monthly", start_date, end_date } = req.query;

    let startDate = new Date();
    let endDate = new Date();

    // ✅ CUSTOM RANGE
    if (range === "custom" && start_date && end_date) {
      startDate = new Date(start_date);
      endDate = new Date(end_date);

      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(23, 59, 59, 999);
    } else {
      // ✅ EXISTING BEHAVIOR (unchanged)
      endDate.setHours(23, 59, 59, 999);

      if (range === "today") {
        startDate.setHours(0, 0, 0, 0);
      } else if (range === "weekly") {
        startDate.setDate(endDate.getDate() - 6);
      } else if (range === "monthly") {
        startDate.setDate(endDate.getDate() - 29);
      } else if (range === "3months") {
        startDate.setMonth(endDate.getMonth() - 3);
      } else if (range === "6months") {
        startDate.setMonth(endDate.getMonth() - 6);
      } else if (range === "annual") {
        startDate.setFullYear(endDate.getFullYear() - 1);
      }
    }

    const startISO = startDate.toISOString().slice(0, 10);
    const endISO = endDate.toISOString().slice(0, 10);

    const sql = `
      -- 1️⃣ Orders logic (UNCHANGED)
      WITH order_counts AS (
        SELECT
          COUNT(*) FILTER (WHERE o.order_status = 'pending')   ::int AS pending,
          COUNT(*) FILTER (WHERE o.order_status = 'confirmed') ::int AS confirmed,
          COUNT(*) FILTER (WHERE o.order_status = 'completed') ::int AS completed,
          COUNT(*) FILTER (WHERE o.order_status = 'returned')  ::int AS returned,
          COUNT(*)                                            ::int AS total
        FROM orders o
        WHERE o.merchant_id = $1
          AND o.created_at >= $2
          AND o.created_at < ($3::date + INTERVAL '1 day')
      ),

      -- 2️⃣ Inventory snapshot (UNCHANGED logic, date-aware)
      inv_snapshot AS (
        SELECT
          pv.variant_id,
          COALESCE(pv.reorder_level, 0) AS reorder_level,
          COALESCE(inv.current_stock, 0) AS current_stock
        FROM products p
        JOIN product_variants pv
          ON pv.product_id = p.product_id
         AND pv.status = 'active'

        LEFT JOIN LATERAL (
          SELECT i.new_quantity AS current_stock
          FROM inventory i
          WHERE i.variant_id  = pv.variant_id
            AND i.merchant_id = p.merchant_id
            AND i.status = 'active'
            AND i.last_updated >= $2
            AND i.last_updated < ($3::date + INTERVAL '1 day')
          ORDER BY i.last_updated DESC NULLS LAST, i.inventory_id DESC
          LIMIT 1
        ) inv ON TRUE

        WHERE p.merchant_id = $1
      ),

      -- 3️⃣ Low-stock counts (ONLY low_stock_total FIXED)
      inv_counts AS (
        SELECT
          COUNT(*) FILTER (
            WHERE reorder_level > 0
              AND current_stock <= reorder_level
          )::int AS reached,

          COUNT(*) FILTER (
            WHERE reorder_level > 0
              AND current_stock > reorder_level
              AND current_stock <= reorder_level * 2
          )::int AS near_to_reach,

          COUNT(*) FILTER (
            WHERE reorder_level > 0
              AND current_stock < reorder_level
          )::int AS strictly_below,

          COUNT(DISTINCT variant_id) FILTER (
            WHERE reorder_level > 0
              AND current_stock > 0
              AND current_stock <= reorder_level * 2
          )::int AS low_stock_total
        FROM inv_snapshot
      )

      SELECT
        json_build_object(
          'pending',   oc.pending,
          'confirmed', oc.confirmed,
          'completed', oc.completed,
          'returned',  oc.returned,
          'total',     oc.total
        ) AS orders,
        json_build_object(
          'reached',         ic.reached,
          'near_to_reach',   ic.near_to_reach,
          'low_stock_total', ic.low_stock_total,
          'strictly_below',  ic.strictly_below
        ) AS inventory
      FROM order_counts oc, inv_counts ic;
    `;

    const { rows } = await pool.query(sql, [merchantId, startISO, endISO]);

    const out = rows[0] || {
      orders: {
        pending: 0,
        confirmed: 0,
        completed: 0,
        returned: 0,
        total: 0,
      },
      inventory: {
        reached: 0,
        near_to_reach: 0,
        low_stock_total: 0,
        strictly_below: 0,
      },
    };

    res.json(out);
  } catch (err) {
    console.error("Dashboard overview error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});
// recent orders view

router.get("/recent-orders-list", authenticateToken, async (req, res) => {
  try {
    const merchantId =
      req.user?.merchant_id ?? req.user?.merchantId ?? req.merchant_id ?? null;

    if (!merchantId) {
      return res
        .status(401)
        .json({ error: "Unauthorized: merchant_id missing from token" });
    }

    const rawLimit = Number(req.query.limit);

    const lim = Number.isFinite(rawLimit)
      ? Math.max(1, Math.min(100, rawLimit))
      : 20;

    // If your schema uses "customers" (plural), change "customer c" to "customers c"
    const sql = `
      SELECT
        o.order_id,
        o.total_value::float8 AS total_value, -- cast to float for JS number (pg otherwise returns NUMERIC as string)
        o.order_status,
        o.currency,
        c.first_name,
        c.last_name
      FROM orders o
      JOIN customer c ON c.customer_id = o.customer_id
      WHERE o.merchant_id = $1
      ORDER BY o.created_at DESC, o.order_id DESC
      LIMIT $2
    `;

    const { rows } = await pool.query(sql, [merchantId, lim]);
    return res.json(rows);
  } catch (err) {
    console.error("Recent orders error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// fetch recent reviews

// ✅ GET recent 10 product reviews
router.get("/recent-reviews-list", async (req, res) => {
  try {
    const query = `
      SELECT review_id, customer_name AS client, comment, review AS rating
      FROM product_reviews
      ORDER BY created_at DESC
      LIMIT 14;
    `;
    const { rows } = await pool.query(query);
    res.json(rows);
  } catch (error) {
    console.error("Error fetching recent reviews:", error);
    res.status(500).json({ error: "Failed to fetch recent reviews" });
  }
});

// fetch the lowest stock variants/product

// GET /variants-low-stock
router.get("/recent-stock-list", authenticateToken, async (req, res) => {
  const { merchant_id } = req.user;

  try {
    const querySQL = `
      SELECT
        p.title AS product_title,
        pv.variant_value,
        COALESCE(inv.current_stock, 0) AS current_stock,
        pv.reorder_level,
        CASE
          WHEN COALESCE(inv.current_stock, 0) <= 0 THEN 'out_of_stock'
          WHEN COALESCE(inv.current_stock, 0) <= COALESCE(pv.reorder_level, 0) THEN 'reorder_level_reached'
          ELSE 'low_stock'
        END AS stock_status
      FROM products p
      JOIN product_variants pv ON pv.product_id = p.product_id
      LEFT JOIN LATERAL (
        SELECT i.new_quantity AS current_stock
        FROM inventory i
        WHERE i.variant_id = pv.variant_id
          AND i.merchant_id = p.merchant_id
          AND i.status = 'active'
        ORDER BY i.last_updated DESC NULLS LAST, i.inventory_id DESC
        LIMIT 1
      ) inv ON true
      WHERE p.merchant_id = $1
      ORDER BY COALESCE(inv.current_stock, 0) ASC
      LIMIT 15
    `;

    const result = await pool.query(querySQL, [merchant_id]);

    res.json({
      success: true,
      results: result.rows,
    });
  } catch (error) {
    console.error("Error fetching low-stock variants:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// fetch the details for order return and delivered chart

// POST route to fetch orders with status "completed" and "returned"
// router.post('/delivery-insights', async (req, res) => {
//   try {
//     const { delivery_partner_id: rawPartnerId, start_date, end_date, range } = req.body;

//     // Normalize partner id: treat null/undefined/'' as "no filter"; otherwise use Number(...)
//     const partnerId =
//       rawPartnerId === null || rawPartnerId === undefined || rawPartnerId === ''
//         ? null
//         : Number(rawPartnerId);
//     const hasPartnerFilter = partnerId !== null && !Number.isNaN(partnerId);

//     console.log('received:', req.body, { normalized_partnerId: partnerId, hasPartnerFilter });

//     let baseQuery = `
//       SELECT COUNT(*) AS count, order_status
//       FROM orders
//       WHERE order_status IN ('completed', 'returned')
//     `;
//     const values = [];
//     let index = 1;

//     // Only apply partner filter when provided (not null)
//     if (hasPartnerFilter) {
//       baseQuery += ` AND delivery_partner_id = $${index}`;
//       values.push(partnerId);
//       index++;
//     }

//     // Determine date range
//     let finalStartDate = start_date;
//     let finalEndDate = end_date;

//     if (range === 'week') {
//       const now = new Date();
//       const end = now.toISOString().split('T')[0];
//       const start = new Date(now);
//       start.setDate(now.getDate() - 7);
//       finalStartDate = start.toISOString().split('T')[0];
//       finalEndDate = end;
//     } else if (range === 'month') {
//       const now = new Date();
//       const end = now.toISOString().split('T')[0];
//       const start = new Date(now);
//       start.setDate(now.getDate() - 30);
//       finalStartDate = start.toISOString().split('T')[0];
//       finalEndDate = end;
//     }

//     if (finalStartDate && finalEndDate) {
//       baseQuery += ` AND created_at BETWEEN $${index} AND $${index + 1}`;
//       values.push(finalStartDate, finalEndDate);
//       index += 2;
//     }

//     // Group by order_status for total count
//     const totalQuery = baseQuery + ` GROUP BY order_status`;
//     const totalResult = await pool.query(totalQuery, values);

//     const totalCount = { completed: 0, returned: 0 };
//     totalResult.rows.forEach(row => {
//       totalCount[row.order_status] = parseInt(row.count, 10);
//     });

//     let dayWiseCounts = null;
//     let monthWiseCounts = null;

//     // Week day-wise counts
//     if (range === 'week') {
//       let dayQuery = `
//         SELECT TO_CHAR(created_at, 'Dy') AS day_name, order_status, COUNT(*) AS count
//         FROM orders
//         WHERE order_status IN ('completed', 'returned')
//       `;
//       const dayValues = [];
//       let dayIndex = 1;

//       if (hasPartnerFilter) {
//         dayQuery += ` AND delivery_partner_id = $${dayIndex}`;
//         dayValues.push(partnerId);
//         dayIndex++;
//       }

//       dayQuery += ` AND created_at BETWEEN $${dayIndex} AND $${dayIndex + 1}`;
//       dayValues.push(finalStartDate, finalEndDate);
//       dayIndex += 2;

//       dayQuery += ` GROUP BY day_name, order_status ORDER BY MIN(created_at)`;

//       const dayResult = await pool.query(dayQuery, dayValues);

//       const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
//       dayWiseCounts = {};
//       weekDays.forEach(day => {
//         dayWiseCounts[day] = { completed: 0, returned: 0 };
//       });

//       dayResult.rows.forEach(row => {
//         const day = row.day_name.trim();
//         const status = row.order_status;
//         if (dayWiseCounts[day]) {
//           dayWiseCounts[day][status] = parseInt(row.count, 10);
//         }
//       });
//     }

//     // Month-wise counts
//     if (range === 'month') {
//       let monthQuery = `
//         SELECT TO_CHAR(created_at, 'Month') AS month_name, order_status, COUNT(*) AS count
//         FROM orders
//         WHERE order_status IN ('completed', 'returned')
//       `;
//       const monthValues = [];
//       let monthIndex = 1;

//       if (hasPartnerFilter) {
//         monthQuery += ` AND delivery_partner_id = $${monthIndex}`;
//         monthValues.push(partnerId);
//         monthIndex++;
//       }

//       monthQuery += ` AND created_at BETWEEN $${monthIndex} AND $${monthIndex + 1}`;
//       monthValues.push(finalStartDate, finalEndDate);
//       monthIndex += 2;

//       monthQuery += ` GROUP BY month_name, order_status ORDER BY MIN(created_at)`;

//       const monthResult = await pool.query(monthQuery, monthValues);

//       const months = [
//         'January', 'February', 'March', 'April', 'May', 'June',
//         'July', 'August', 'September', 'October', 'November', 'December'
//       ];

//       monthWiseCounts = {};
//       months.forEach(m => {
//         monthWiseCounts[m] = { completed: 0, returned: 0 };
//       });

//       monthResult.rows.forEach(row => {
//         const month = row.month_name.trim();
//         const status = row.order_status;
//         if (monthWiseCounts[month]) {
//           monthWiseCounts[month][status] = parseInt(row.count, 10);
//         }
//       });
//     }

//     return res.json({
//       success: true,
//       total_count: totalCount,
//       appliedFilters: {
//         delivery_partner_id: hasPartnerFilter ? partnerId : null,
//         start_date: finalStartDate || null,
//         end_date: finalEndDate || null
//       },
//       day_wise_counts: dayWiseCounts,
//       month_wise_counts: monthWiseCounts
//     });

//   } catch (error) {
//     console.error('Error fetching order count:', error);
//     res.status(500).json({ success: false, message: 'Server Error' });
//   }
// });

router.post("/delivery-insights", async (req, res) => {
  try {
    const {
      delivery_partner_id: rawPartnerId,
      start_date,
      end_date,
      range,
    } = req.body;

    // Normalize partner id
    const partnerId =
      rawPartnerId === null || rawPartnerId === undefined || rawPartnerId === ""
        ? null
        : Number(rawPartnerId);
    const hasPartnerFilter = partnerId !== null && !Number.isNaN(partnerId);

    console.log("received:", req.body, {
      normalized_partnerId: partnerId,
      hasPartnerFilter,
    });

    // Determine date range
    let finalStartDate = start_date;
    let finalEndDate = end_date;

    if (range === "week") {
      const now = new Date();
      const end = now.toISOString().split("T")[0];
      const start = new Date(now);
      start.setDate(now.getDate() - 7);
      finalStartDate = start.toISOString().split("T")[0];
      finalEndDate = end;
    } else if (range === "month") {
      const now = new Date();
      const end = now.toISOString().split("T")[0];
      const start = new Date(now);
      start.setDate(now.getDate() - 30);
      finalStartDate = start.toISOString().split("T")[0];
      finalEndDate = end;
    }

    // Make end date inclusive by adding one day
    const endDateObj = new Date(finalEndDate);
    endDateObj.setDate(endDateObj.getDate() + 1);
    const finalEndDateInclusive = endDateObj.toISOString().split("T")[0];

    // ---------------------------
    // TOTAL COUNTS
    // ---------------------------
    let baseQuery = `
      SELECT COUNT(*) AS count, order_status
      FROM orders
      WHERE order_status IN ('completed', 'returned')
    `;
    const values = [];
    let index = 1;

    if (hasPartnerFilter) {
      baseQuery += ` AND delivery_partner_id = $${index}`;
      values.push(partnerId);
      index++;
    }

    if (finalStartDate && finalEndDate) {
      baseQuery += `
        AND (
          (order_status = 'completed' AND delivery_completed_date >= $${index} AND delivery_completed_date < $${
            index + 1
          })
          OR
          (order_status = 'returned' AND returned_date >= $${index} AND returned_date < $${
            index + 1
          })
        )
      `;
      values.push(finalStartDate, finalEndDateInclusive);
      index += 2;
    }

    baseQuery += ` GROUP BY order_status`;

    const totalResult = await pool.query(baseQuery, values);
    const totalCount = { completed: 0, returned: 0 };
    totalResult.rows.forEach((row) => {
      totalCount[row.order_status] = parseInt(row.count, 10);
    });

    // ---------------------------
    // WEEKLY DAY-WISE COUNTS
    // ---------------------------
    let dayWiseCounts = null;
    if (range === "week") {
      let dayQuery = `
        SELECT 
          TO_CHAR(COALESCE(delivery_completed_date, returned_date), 'Dy') AS day_name,
          order_status,
          COUNT(*) AS count
        FROM orders
        WHERE order_status IN ('completed', 'returned')
      `;
      const dayValues = [];
      let dayIndex = 1;

      if (hasPartnerFilter) {
        dayQuery += ` AND delivery_partner_id = $${dayIndex}`;
        dayValues.push(partnerId);
        dayIndex++;
      }

      dayQuery += `
        AND (
          (order_status = 'completed' AND delivery_completed_date >= $${dayIndex} AND delivery_completed_date < $${
            dayIndex + 1
          })
          OR
          (order_status = 'returned' AND returned_date >= $${dayIndex} AND returned_date < $${
            dayIndex + 1
          })
        )
      `;
      dayValues.push(finalStartDate, finalEndDateInclusive);
      dayIndex += 2;

      dayQuery += ` GROUP BY day_name, order_status ORDER BY MIN(COALESCE(delivery_completed_date, returned_date))`;

      const dayResult = await pool.query(dayQuery, dayValues);

      const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
      dayWiseCounts = {};
      weekDays.forEach((day) => {
        dayWiseCounts[day] = { completed: 0, returned: 0 };
      });

      dayResult.rows.forEach((row) => {
        const day = row.day_name.trim();
        const status = row.order_status;
        if (dayWiseCounts[day]) {
          dayWiseCounts[day][status] = parseInt(row.count, 10);
        }
      });
    }

    // ---------------------------
    // MONTH-WISE COUNTS
    // ---------------------------
    let monthWiseCounts = null;
    if (range === "month") {
      let monthQuery = `
        SELECT 
          TO_CHAR(COALESCE(delivery_completed_date, returned_date), 'Month') AS month_name,
          order_status,
          COUNT(*) AS count
        FROM orders
        WHERE order_status IN ('completed', 'returned')
      `;
      const monthValues = [];
      let monthIndex = 1;

      if (hasPartnerFilter) {
        monthQuery += ` AND delivery_partner_id = $${monthIndex}`;
        monthValues.push(partnerId);
        monthIndex++;
      }

      monthQuery += `
        AND (
          (order_status = 'completed' AND delivery_completed_date >= $${monthIndex} AND delivery_completed_date < $${
            monthIndex + 1
          })
          OR
          (order_status = 'returned' AND returned_date >= $${monthIndex} AND returned_date < $${
            monthIndex + 1
          })
        )
      `;
      monthValues.push(finalStartDate, finalEndDateInclusive);
      monthIndex += 2;

      monthQuery += ` GROUP BY month_name, order_status ORDER BY MIN(COALESCE(delivery_completed_date, returned_date))`;

      const monthResult = await pool.query(monthQuery, monthValues);

      const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
      ];

      monthWiseCounts = {};
      months.forEach((m) => {
        monthWiseCounts[m] = { completed: 0, returned: 0 };
      });

      monthResult.rows.forEach((row) => {
        const month = row.month_name.trim();
        const status = row.order_status;
        if (monthWiseCounts[month]) {
          monthWiseCounts[month][status] = parseInt(row.count, 10);
        }
      });
    }

    // ---------------------------
    // RESPONSE
    // ---------------------------
    return res.json({
      success: true,
      total_count: totalCount,
      appliedFilters: {
        delivery_partner_id: hasPartnerFilter ? partnerId : null,
        start_date: finalStartDate || null,
        end_date: finalEndDate || null,
      },
      day_wise_counts: dayWiseCounts,
      month_wise_counts: monthWiseCounts,
    });
  } catch (error) {
    console.error("Error fetching delivery insights:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
});

// router.post('/delivery-insights', async (req, res) => {
//   try {
//     const { delivery_partner_id: rawPartnerId, start_date, end_date, range } = req.body;

//     const partnerId =
//       rawPartnerId === null || rawPartnerId === undefined || rawPartnerId === ''
//         ? null
//         : Number(rawPartnerId);
//     const hasPartnerFilter = partnerId !== null && !Number.isNaN(partnerId);

//     console.log('received:', req.body, { normalized_partnerId: partnerId, hasPartnerFilter });

//     // Determine date range
//     let finalStartDate = start_date;
//     let finalEndDate = end_date;

//     if (range === 'week') {
//       const now = new Date();
//       const end = now.toISOString().split('T')[0];
//       const start = new Date(now);
//       start.setDate(now.getDate() - 7);
//       finalStartDate = start.toISOString().split('T')[0];
//       finalEndDate = end;
//     } else if (range === 'month') {
//       const now = new Date();
//       const end = now.toISOString().split('T')[0];
//       const start = new Date(now);
//       start.setDate(now.getDate() - 30);
//       finalStartDate = start.toISOString().split('T')[0];
//       finalEndDate = end;
//     }

//     // ---------------------------
//     // TOTAL COUNTS (completed/returned)
//     // ---------------------------
//     let baseQuery = `
//       SELECT COUNT(*) AS count, order_status
//       FROM orders
//       WHERE order_status IN ('completed', 'returned')
//     `;
//     const values = [];
//     let index = 1;

//     if (hasPartnerFilter) {
//       baseQuery += ` AND delivery_partner_id = $${index}`;
//       values.push(partnerId);
//       index++;
//     }

//     if (finalStartDate && finalEndDate) {
//       baseQuery += `
//         AND (
//           (order_status = 'completed' AND delivery_completed_date BETWEEN $${index} AND $${index + 1})
//           OR
//           (order_status = 'returned' AND returned_date BETWEEN $${index} AND $${index + 1})
//         )
//       `;
//       values.push(finalStartDate, finalEndDate);
//       index += 2;
//     }

//     baseQuery += ` GROUP BY order_status`;

//     const totalResult = await pool.query(baseQuery, values);
//     const totalCount = { completed: 0, returned: 0 };
//     totalResult.rows.forEach(row => {
//       totalCount[row.order_status] = parseInt(row.count, 10);
//     });

//     // ---------------------------
//     // WEEKLY DAY-WISE COUNTS
//     // ---------------------------
//     let dayWiseCounts = null;
//     if (range === 'week') {
//       let dayQuery = `
//         SELECT
//           TO_CHAR(COALESCE(delivery_completed_date, returned_date), 'Dy') AS day_name,
//           order_status,
//           COUNT(*) AS count
//         FROM orders
//         WHERE order_status IN ('completed', 'returned')
//       `;
//       const dayValues = [];
//       let dayIndex = 1;

//       if (hasPartnerFilter) {
//         dayQuery += ` AND delivery_partner_id = $${dayIndex}`;
//         dayValues.push(partnerId);
//         dayIndex++;
//       }

//       dayQuery += `
//         AND (
//           (order_status = 'completed' AND delivery_completed_date BETWEEN $${dayIndex} AND $${dayIndex + 1})
//           OR
//           (order_status = 'returned' AND returned_date BETWEEN $${dayIndex} AND $${dayIndex + 1})
//         )
//       `;
//       dayValues.push(finalStartDate, finalEndDate);
//       dayIndex += 2;

//       dayQuery += ` GROUP BY day_name, order_status ORDER BY MIN(COALESCE(delivery_completed_date, returned_date))`;

//       const dayResult = await pool.query(dayQuery, dayValues);

//       const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
//       dayWiseCounts = {};
//       weekDays.forEach(day => {
//         dayWiseCounts[day] = { completed: 0, returned: 0 };
//       });

//       dayResult.rows.forEach(row => {
//         const day = row.day_name.trim();
//         const status = row.order_status;
//         if (dayWiseCounts[day]) {
//           dayWiseCounts[day][status] = parseInt(row.count, 10);
//         }
//       });
//     }

//     // ---------------------------
//     // MONTH-WISE COUNTS
//     // ---------------------------
//     let monthWiseCounts = null;
//     if (range === 'month') {
//       let monthQuery = `
//         SELECT
//           TO_CHAR(COALESCE(delivery_completed_date, returned_date), 'Month') AS month_name,
//           order_status,
//           COUNT(*) AS count
//         FROM orders
//         WHERE order_status IN ('completed', 'returned')
//       `;
//       const monthValues = [];
//       let monthIndex = 1;

//       if (hasPartnerFilter) {
//         monthQuery += ` AND delivery_partner_id = $${monthIndex}`;
//         monthValues.push(partnerId);
//         monthIndex++;
//       }

//       monthQuery += `
//         AND (
//           (order_status = 'completed' AND delivery_completed_date BETWEEN $${monthIndex} AND $${monthIndex + 1})
//           OR
//           (order_status = 'returned' AND returned_date BETWEEN $${monthIndex} AND $${monthIndex + 1})
//         )
//       `;
//       monthValues.push(finalStartDate, finalEndDate);
//       monthIndex += 2;

//       monthQuery += ` GROUP BY month_name, order_status ORDER BY MIN(COALESCE(delivery_completed_date, returned_date))`;

//       const monthResult = await pool.query(monthQuery, monthValues);

//       const months = [
//         'January', 'February', 'March', 'April', 'May', 'June',
//         'July', 'August', 'September', 'October', 'November', 'December'
//       ];

//       monthWiseCounts = {};
//       months.forEach(m => {
//         monthWiseCounts[m] = { completed: 0, returned: 0 };
//       });

//       monthResult.rows.forEach(row => {
//         const month = row.month_name.trim();
//         const status = row.order_status;
//         if (monthWiseCounts[month]) {
//           monthWiseCounts[month][status] = parseInt(row.count, 10);
//         }
//       });
//     }

//     // ---------------------------
//     // RESPONSE
//     // ---------------------------
//     return res.json({
//       success: true,
//       total_count: totalCount,
//       appliedFilters: {
//         delivery_partner_id: hasPartnerFilter ? partnerId : null,
//         start_date: finalStartDate || null,
//         end_date: finalEndDate || null
//       },
//       day_wise_counts: dayWiseCounts,
//       month_wise_counts: monthWiseCounts
//     });

//   } catch (error) {
//     console.error('Error fetching delivery insights:', error);
//     res.status(500).json({ success: false, message: 'Server Error' });
//   }
// });

// fetch top customers with orders and customer details

router.get("/top-customers", authenticateToken, async (req, res) => {
  try {
    const { merchant_id } = req.user || {};
    if (!merchant_id) {
      return res
        .status(400)
        .json({ message: "merchant_id missing from token" });
    }

    const sql = `
      SELECT
        o.customer_id,
        COUNT(*)::int AS order_count,
        c.first_name,
        c.last_name,
        c.contact_number_1,
        c.picture,
        c.status
      FROM orders o
      JOIN customer c ON c.customer_id = o.customer_id
      WHERE o.merchant_id = $1
      GROUP BY
        o.customer_id,
        c.first_name, c.last_name, c.contact_number_1, c.picture, c.status
      ORDER BY order_count DESC, c.first_name ASC, c.last_name ASC
      LIMIT 15
    `;

    const { rows } = await pool.query(sql, [merchant_id]);
    return res.json({ data: rows });
  } catch (err) {
    console.error("GET /analytics/top-customers error:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// sales data

// POST route to get order counts by week and month
router.post("/order-stats", authenticateToken, async (req, res) => {
  try {
    const merchant_id = req.user.merchant_id; // From JWT token
    const { range } = req.body; // "weekly" or "monthly"

    const statuses = [
      "pending",
      "confirmed",
      "processing",
      "dispatched",
      "completed",
      "cancelled",
      "returned",
    ];

    const weekDays = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];

    let responseData = { success: true };

    // ---------- WEEKLY DATA ----------
    if (range === "weekly") {
      // Initialize structure with zeros
      const weekResult = {};
      weekDays.forEach((day) => {
        weekResult[day] = {};
        statuses.forEach((status) => {
          weekResult[day][status] = 0;
        });
      });

      const weekQuery = `
        SELECT
          UPPER(to_char(created_at, 'DY')) as day,
          order_status,
          COUNT(*) as order_count
        FROM orders
        WHERE merchant_id = $1
          AND created_at >= (CURRENT_DATE - INTERVAL '6 days')
        GROUP BY day, order_status;
      `;

      const weekData = await pool.query(weekQuery, [merchant_id]);

      // Populate actual values
      weekData.rows.forEach((row) => {
        if (weekResult[row.day]) {
          weekResult[row.day][row.order_status] = parseInt(row.order_count);
        }
      });

      responseData.week = weekResult;
    }

    // ---------- MONTHLY DATA ----------
    if (range === "monthly") {
      // Initialize structure with zeros
      const monthResult = {};
      months.forEach((month) => {
        monthResult[month] = {};
        statuses.forEach((status) => {
          monthResult[month][status] = 0;
        });
      });

      const monthQuery = `
        SELECT
          to_char(created_at, 'Mon') AS month,
          order_status,
          COUNT(*) AS order_count
        FROM orders
        WHERE merchant_id = $1
          AND created_at >= date_trunc('year', CURRENT_DATE)
        GROUP BY month, order_status;
      `;

      const monthData = await pool.query(monthQuery, [merchant_id]);

      // Populate actual values
      monthData.rows.forEach((row) => {
        if (monthResult[row.month]) {
          monthResult[row.month][row.order_status] = parseInt(row.order_count);
        }
      });

      responseData.month = monthResult;
    }

    res.json(responseData);
  } catch (error) {
    console.error("Error fetching order stats:", error);
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// router.post("/product-sales-range-report", authenticateToken, async (req, res) => {
//   try {
//     const {
//       date_from,
//       date_to,
//       collection_ids,
//       category_ids,
//       product_id,
//       range
//     } = req.body || {};

//     const merchant_id = req.user?.merchant_id;

//     const parseIds = (val) => {
//       if (!val && val !== 0) return [];
//       if (Array.isArray(val)) return val.map(Number).filter(Number.isFinite);
//       if (typeof val === "string")
//         return val.split(",").map((s) => Number(s.trim())).filter(Number.isFinite);
//       if (typeof val === "number") return [val];
//       return [];
//     };

//     const collIds = parseIds(collection_ids);
//     const catIds = parseIds(category_ids);
//     const productId = Number(product_id);

//     const allowedStatuses = [
//       "confirmed",
//       "completed",
//       "dispatched",
//       "processing",
//     ];

//     // decide grouping
//     let timeGroup = "day";
//     if (range === "weekly") timeGroup = "week";
//     if (range === "monthly") timeGroup = "month";

//     // ================= FILTER =================
//     const where = [];
//     const params = [];

//     const add = (v) => {
//       params.push(v);
//       return params.length;
//     };

//     let idx = add(allowedStatuses);
//     where.push(`o.order_status = ANY($${idx}::text[])`);

//     if (merchant_id) {
//       idx = add(Number(merchant_id));
//       where.push(`o.merchant_id = $${idx}`);
//     }

//     if (date_from) {
//       idx = add(date_from);
//       where.push(`o.created_at >= $${idx}::timestamp`);
//     }

//     if (date_to) {
//       idx = add(date_to);
//       where.push(`o.created_at < ($${idx}::timestamp + interval '1 day')`);
//     }

//     if (collIds.length) {
//       idx = add(collIds);
//       where.push(`pc.collection_id = ANY($${idx}::int[])`);
//     }

//     if (catIds.length) {
//       idx = add(catIds);
//       where.push(`pg.category_id = ANY($${idx}::int[])`);
//     }

//     const WHERE_SQL = where.length ? `WHERE ${where.join(" AND ")}` : "";

//     // ================= QUERY =================
//     const sql = `
//       WITH sales_data AS (
//         SELECT
//           oi.product_id,
//           p.title,
//           date_trunc('${timeGroup}', o.created_at) AS period,

//           SUM(oi.total_price)::double precision AS total_sales_amount,
//           SUM(oi.quantity)::bigint AS sales_quantity,
//           SUM(oi.quantity)::bigint AS order_quantity

//         FROM order_items oi
//         JOIN orders o ON o.order_id = oi.order_id
//         LEFT JOIN products p ON p.product_id = oi.product_id
//         LEFT JOIN product_collections pc ON pc.product_id = oi.product_id
//         LEFT JOIN product_category pg ON pg.product_id = oi.product_id

//         ${WHERE_SQL}

//         GROUP BY oi.product_id, p.title, period
//       ),

//       returns_data AS (
//         SELECT
//           oi.product_id,
//           date_trunc('${timeGroup}', o.created_at) AS period,
//           SUM(oi.quantity)::bigint AS returned_items_quantity
//         FROM order_items oi
//         JOIN orders o ON o.order_id = oi.order_id
//         WHERE o.order_status = 'returned'
//         GROUP BY oi.product_id, period
//       )

//       SELECT
//         s.period,
//         s.product_id,
//         s.title,

//         s.total_sales_amount AS product_total_sales_amount,
//         s.sales_quantity AS product_total_sales_quantity,
//         s.order_quantity AS product_total_order_quantity,
//         COALESCE(r.returned_items_quantity,0) AS product_returned_items_quantity

//       FROM sales_data s
//       LEFT JOIN returns_data r
//       ON r.product_id = s.product_id
//       AND r.period = s.period

//       ORDER BY s.period DESC;
//     `;

//     const result = await pool.query(sql, params);

//     let products = result.rows || [];

//     // optional product filter
//     if (product_id !== null && product_id !== undefined) {
//       if (Number.isFinite(productId)) {
//         products = products.filter((p) => Number(p.product_id) === productId);
//       }
//     }

//     // summary
//     const sales_report_summary = {
//       total_ordered_qty: products.reduce(
//         (s, p) => s + Number(p.product_total_order_quantity || 0),
//         0
//       ),
//       total_sales_qty: products.reduce(
//         (s, p) => s + Number(p.product_total_sales_quantity || 0),
//         0
//       ),
//       total_returned_qty: products.reduce(
//         (s, p) => s + Number(p.product_returned_items_quantity || 0),
//         0
//       ),
//       total_sales_amount: products.reduce(
//         (s, p) => s + Number(p.product_total_sales_amount || 0),
//         0
//       ),
//     };

//     res.json({
//       range,
//       products,
//       sales_report_summary,
//     });

//   } catch (err) {
//     console.error("Error fetching range sales report:", err);
//     res.status(500).json({ error: "Internal server error" });
//   }
// });

router.post("/dashboard-cards-range", authenticateToken, async (req, res) => {
  try {
    const { range, start_date, end_date } = req.body || {};
    const merchant_id = req.user?.merchant_id;

    let dateCondition = "";

    //  CUSTOM RANGE (NEW)
    if (range === "custom" && start_date && end_date) {
      dateCondition = `
    created_at >= '${start_date}'::date
    AND created_at < ('${end_date}'::date + INTERVAL '1 day')
  `;
    }

    //  EXISTING LOGIC (UNCHANGED BEHAVIOR)
    else if (range === "today") {
      dateCondition = `
    created_at >= CURRENT_DATE
    AND created_at < CURRENT_DATE + INTERVAL '1 day'
  `;
    } else {
      let interval = "7 days";

      if (range === "monthly") interval = "1 month";
      if (range === "3months") interval = "3 months";
      if (range === "6months") interval = "6 months";
      if (range === "annual") interval = "12 months";

      dateCondition = `created_at >= NOW() - interval '${interval}'`;
    }
    const sql = `
    WITH active_clients AS (
      SELECT COUNT(user_id) AS client_count
      FROM users
      WHERE status = 'Active'
      ${merchant_id ? "AND merchant_id = $1" : ""}
      AND ${dateCondition}
    ),

    sales_from_orders AS (
      SELECT
        COALESCE(SUM(o.full_amount),0) AS total_sales
      FROM orders o
          WHERE o.order_status = ANY(ARRAY['confirmed','completed','dispatched','processing'])
          AND ${dateCondition.replaceAll("created_at", "o.created_at")}
          ${merchant_id ? "AND o.merchant_id = $1" : ""}
        ),

    invoice_stats AS (
      SELECT
      COUNT(DISTINCT ih.id) AS invoice_count,

      COALESCE(
        SUM(
         ih.full_amount
          - COALESCE(idt_return.returned_amount, 0)
        ),
        0
      ) AS total_invoice_value,
      COALESCE(
        SUM((idt.quantity * idt.unit_price) - COALESCE(idt.discount,0)),
        0
      ) AS invoice_sales,

      COALESCE(SUM(COALESCE(idt.return_qty, 0)), 0) AS invoice_returns
            FROM invoice_header ih
            LEFT JOIN invoice_details idt
              ON ih.id = idt.invoice_id
              LEFT JOIN (
        SELECT 
          invoice_id,
          SUM(COALESCE(return_qty,0) * COALESCE(unit_price,0)) AS returned_amount
        FROM invoice_details
        GROUP BY invoice_id
      ) idt_return
  ON ih.id = idt_return.invoice_id
      WHERE ${dateCondition.replaceAll("created_at", "ih.created_at")}
      ${merchant_id ? "AND ih.merchant_id = $1" : ""}
     AND ih.order_status NOT IN ('cancelled','draft','hold','delete')
    )

    SELECT
      (SELECT client_count FROM active_clients) AS client_count,
    (SELECT invoice_returns FROM invoice_stats) AS invoice_returns,

    (
      COALESCE((SELECT total_sales FROM sales_from_orders),0) +
      COALESCE((SELECT total_invoice_value FROM invoice_stats),0)
    ) AS total_sales_amount,

      (SELECT invoice_count FROM invoice_stats) AS invoice_count,
      (SELECT total_invoice_value FROM invoice_stats) AS total_invoice_value
    `;

    const params = merchant_id ? [Number(merchant_id)] : [];

    const result = await pool.query(sql, params);

    const data = result.rows?.[0] || {
      client_count: 0,
      invoice_returns: 0,
      total_sales_amount: 0,
      invoice_count: 0,
      total_invoice_value: 0,
    };

    res.json({
      range,
      clientCount: Number(data.client_count || 0),
      totalSalesAmount: Number(data.total_sales_amount || 0),
      invoiceReturns: Number(data.invoice_returns || 0),

      // Newly added fields
      invoiceCount: Number(data.invoice_count || 0),
      totalInvoiceValue: Number(data.total_invoice_value || 0),
    });
  } catch (err) {
    console.error("Dashboard card stats error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// GET all dashboard widgets
router.get("/dashboard-widgets", async (req, res) => {
  try {
    const result = await pool.query(`
  SELECT 
    widget_id, 
    name, 
    package,
    "show" AS is_enabled
  FROM dashboard_widgets
  ORDER BY widget_id ASC
`);

    res.status(200).json({
      success: true,
      widgets: result.rows,
    });
  } catch (error) {
    console.error("Error fetching dashboard widgets:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch dashboard widgets",
    });
  }
});

// dashboard status toggle
router.put("/dashboard-widget-toggle", async (req, res) => {
  const client = await pool.connect();

  try {
    const widgets = req.body; // array [{ widget_id, is_enabled }]

    if (!Array.isArray(widgets)) {
      return res.status(400).json({
        success: false,
        message: "Invalid payload format",
      });
    }

    await client.query("BEGIN");

    for (const w of widgets) {
      await client.query(
        `
        UPDATE dashboard_widgets
        SET "show" = $1
        WHERE widget_id = $2
        `,
        [w.is_enabled, w.widget_id],
      );
    }

    await client.query("COMMIT");

    res.status(200).json({
      success: true,
      message: "Dashboard widgets updated successfully",
    });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("Error updating dashboard widgets:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update dashboard widgets",
    });
  } finally {
    client.release();
  }
});

// recent invoices

router.get("/recent-invoices", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        o.id AS invoice,
        c.first_name AS client,
        o.payment_status,
        o.total_value AS amount
      FROM invoice_header o
      LEFT JOIN customer c ON o.customer_id = c.customer_id
      WHERE o.order_status NOT IN ('hold', 'draft', 'delete', 'cancelled')
      ORDER BY o.created_at DESC
      LIMIT 20
    `;

    const { rows } = await pool.query(query);

    res.json({ orders: rows });
  } catch (err) {
    console.error("Error fetching recent orders:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// moving report..

router.post("/top-selling-products", authenticateToken, async (req, res) => {
  try {
    const { filter = "today" } = req.body;

    // ================= DATE RANGE FROM FILTER =================
    const now = new Date();
    let dateFrom;

    switch (filter) {
      case "today":
        dateFrom = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case "weekly":
        dateFrom = new Date(now);
        dateFrom.setDate(now.getDate() - 7);
        break;
      case "monthly":
        dateFrom = new Date(now);
        dateFrom.setMonth(now.getMonth() - 1);
        break;
      case "3month":
        dateFrom = new Date(now);
        dateFrom.setMonth(now.getMonth() - 3);
        break;
      case "6month":
        dateFrom = new Date(now);
        dateFrom.setMonth(now.getMonth() - 6);
        break;
      case "annual":
        dateFrom = new Date(now);
        dateFrom.setFullYear(now.getFullYear() - 1);
        break;
      default:
        dateFrom = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }

    const allowedOrderStatuses = [
      "confirmed",
      "completed",
      "dispatched",
      "processing",
    ];

    const sql = `
      WITH order_sales AS (
        SELECT
          oi.product_id,
          p.title AS product_title,
          SUM(oi.total_price)::double precision AS sales_amount,
          SUM(oi.quantity)::bigint AS sold_qty
        FROM order_items oi
        JOIN orders o ON o.order_id = oi.order_id
        LEFT JOIN products p ON p.product_id = oi.product_id
        WHERE o.order_status = ANY($1::text[])
          AND o.created_at >= $2::timestamp
        GROUP BY oi.product_id, p.title
      ),

      invoice_sales AS (
        SELECT
          idt.product_id,
          p.title AS product_title,
          SUM((idt.quantity * idt.unit_price) - COALESCE(idt.discount, 0))::double precision AS sales_amount,
          SUM(idt.quantity)::bigint AS sold_qty
        FROM invoice_details idt
        JOIN invoice_header ih ON ih.id = idt.invoice_id
        LEFT JOIN products p ON p.product_id = idt.product_id
        WHERE ih.order_status NOT IN ('cancelled', 'draft', 'hold', 'delete')
          AND ih.created_at >= $2::timestamp
        GROUP BY idt.product_id, p.title
      ),

      combined AS (
        SELECT product_id, product_title, sales_amount, sold_qty FROM order_sales
        UNION ALL
        SELECT product_id, product_title, sales_amount, sold_qty FROM invoice_sales
      )

      SELECT
        c.product_id,
        MAX(c.product_title) AS title,

        -- ✅ ADDED measurement
        m.measurement_value,

        SUM(c.sales_amount)::double precision AS total_sales_amount,
        SUM(c.sold_qty)::bigint AS total_sold_qty

      FROM combined c

      LEFT JOIN products p
        ON p.product_id = c.product_id

      LEFT JOIN measurements m
        ON m.measurement_id = p.measurement_id

      WHERE c.product_id IS NOT NULL

      GROUP BY c.product_id, m.measurement_value

      ORDER BY total_sold_qty DESC, total_sales_amount DESC
      LIMIT 20;
    `;

    const result = await pool.query(sql, [allowedOrderStatuses, dateFrom]);
    const products = result.rows || [];

    const summary = {
      total_products: products.length,
      total_sold_qty: products.reduce(
        (s, p) => s + Number(p.total_sold_qty || 0),
        0,
      ),
      total_sales_amount: products.reduce(
        (s, p) => s + Number(p.total_sales_amount || 0),
        0,
      ),
    };

    res.json({ products, summary, filter });
  } catch (err) {
    console.error("Error fetching top selling products:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// upcoming leaves

// GET Upcoming Approved Leaves
// GET Upcoming Leaves (exclude today, limit 25)
router.get("/upcoming-leaves", authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        l.leave_id,
        l.employee_id,
        e.first_name,
        e.last_name,
        l.leave_type_id,
        l.from_date,
        l.to_date,
        l.reason,
        l.status,
        l.paid_status,
        l.duration_type,
        l.created_at
      FROM leaves l
      INNER JOIN employees e 
        ON e.employee_id = l.employee_id
      WHERE 
        l.status = 'Approved'
        AND l.from_date > CURRENT_DATE   -- ❌ exclude today
      ORDER BY l.from_date ASC           -- 📅 nearest first
      LIMIT 25                           -- 🔢 only 25 records
    `;

    const { rows } = await pool.query(query);

    return res.status(200).json({
      success: true,
      count: rows.length,
      data: rows,
    });
  } catch (error) {
    console.error("Error fetching upcoming leaves:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch upcoming leaves",
    });
  }
});

module.exports = router;
