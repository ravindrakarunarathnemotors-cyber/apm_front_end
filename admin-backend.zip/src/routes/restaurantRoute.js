const express = require("express");
const router = express.Router();
const authenticateToken = require("../middleware/authMiddleware");
const {  getProductSearch, getRawMaterialSearch, saveRecipe, allRecipe, add_raw_material_stock, getAllkitchen, getProductSearchkitchen, getIngredientsforProducts, relaseProducts, allProductionSheet, assignProductsToKitchen, removeKitchenProduct, getKitchenProducts, getCookisdisplayid, getKotDisplay, saveCookistillid, unaasignProducts, ingredientsInventory, createSheet } = require("../controllers/recipeController");

//recipe
router.get("/recipe/getProductSearch", authenticateToken, getProductSearch);

router.get("/recipe/getRawMaterialSearch", authenticateToken, getRawMaterialSearch);

router.post("/recipe/saveRecipe", authenticateToken, saveRecipe);

router.post("/recipe/allRecipe", authenticateToken, allRecipe);



// raw material
router.post("/rawmaterial/add_raw_material_stock", authenticateToken, add_raw_material_stock);

router.post("/rawmaterial/ingredientsInventory", authenticateToken, ingredientsInventory);

//kitchen
router.get("/kitchen/getAllkitchen", authenticateToken, getAllkitchen);

router.get("/kitchen/getProductSearchkitchen", authenticateToken, getProductSearchkitchen);

router.post("/kitchen/getIngredientsforProducts", authenticateToken, getIngredientsforProducts);

router.post("/kitchen/relaseProducts", authenticateToken, relaseProducts);

router.post("/kitchen/allProductionSheet", authenticateToken, allProductionSheet); 

router.post("/kitchen/assignProducts", authenticateToken, assignProductsToKitchen);

router.post("/kitchen/removeKitchenProduct", authenticateToken, removeKitchenProduct);

router.get("/kitchen/getKitchenProducts/:kitchen_id", authenticateToken, getKitchenProducts);

router.get("/kitchen/getCookisdisplayid",  getCookisdisplayid);

router.get("/kitchen/getKotDisplay",  getKotDisplay);

router.post("/kitchen/saveCookistillid",  saveCookistillid);

router.post("/kitchen/unaasignProducts", authenticateToken, unaasignProducts);

//sheet
router.post("/sheet/createSheet", authenticateToken, createSheet);

module.exports = router;