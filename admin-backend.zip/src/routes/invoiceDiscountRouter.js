const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");
const { autodiscountCheck, autodeliverydiscountCheck, autodpmethoddiscountCheck, autodbuyxdiscountCheck } = require("../controllers/invoiceDiscount");


const router = express.Router();


//invoice discount
router.post("/autodiscountcheck", authenticateToken, autodiscountCheck)

router.post("/autodeliverdiscount", authenticateToken, autodeliverydiscountCheck)

router.post("/autodpmethoddiscount", authenticateToken, autodpmethoddiscountCheck)

router.post("/autodbuyxdiscount", authenticateToken, autodbuyxdiscountCheck)


module.exports = router