const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/product-trends", authenticateToken, async (req, res) => {
  try {
    const { type } = req.query;

    let query = '';

    if (type === 'daily') {
      query = `
        SELECT 
          TO_CHAR(created_at::date, 'YYYY-MM-DD') AS label,
          COUNT(*) FILTER (WHERE status = 'active') AS active,
          COUNT(*) FILTER (WHERE status = 'inactive') AS inactive
        FROM products
        WHERE created_at >= NOW() - INTERVAL '30 days'
        GROUP BY created_at::date
        ORDER BY created_at::date;
      `;
    } else if (type === 'weekly') {
      query = `
        SELECT 
          TO_CHAR(DATE_TRUNC('week', created_at), 'YYYY-MM-DD') AS label,
          COUNT(*) FILTER (WHERE status = 'active') AS active,
          COUNT(*) FILTER (WHERE status = 'inactive') AS inactive
        FROM products
        WHERE created_at >= NOW() - INTERVAL '12 weeks'
        GROUP BY DATE_TRUNC('week', created_at)
        ORDER BY DATE_TRUNC('week', created_at);
      `;
    } else {
      return res.status(400).json({ error: "Invalid type. Use 'daily' or 'weekly'" });
    }

    const { rows } = await pool.query(query);
    res.json({ trends: rows });

  } catch (error) {
    console.error("Error fetching product trends:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get('/product-stats', authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT 
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status = 'active') AS active,
        COUNT(*) FILTER (WHERE status = 'inactive') AS inactive
      FROM products;
    `;
    const { rows } = await pool.query(query);
    res.json(rows[0]);
  } catch (error) {
    console.error("Error fetching product stats:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.get('/inventory-adjustments', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        DATE(last_updated) AS date,
        system_module,
        SUM(adjust_quantity) AS total_adjustment
      FROM inventory
      WHERE status = 'active'
      GROUP BY date, system_module
      ORDER BY date ASC;
    `);

   
    const grouped = {};

    result.rows.forEach((row) => {
      const date = row.date.toISOString().split('T')[0];
      if (!grouped[date]) {
        grouped[date] = { date, 'stock in': 0, 'stock out': 0 };
      }
      grouped[date][row.system_module] = parseInt(row.total_adjustment, 10);
    });

    const response = Object.values(grouped);
    res.json(response);
  } catch (err) {
    console.error('Error fetching inventory data:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});




module.exports = router;