const express = require("express");
const pool = require("../config/db");
const authenticateToken = require("../middleware/authMiddleware");


const router = express.Router();

router.post("/parcel-timeline",authenticateToken, async (req, res) => {
  const { parcel_id } = req.body;
  const user = req.user;
  const user_id = user.user_id;

  if (!user_id || !parcel_id) {
    return res.status(400).json({ message: "user_id and parcel_id are required" });
  }

  try {
    // Query to get parcel timeline (logs)
    const timelineQuery = `
      SELECT * FROM logs 
      WHERE user_id = $1 AND parcel_id = $2 
      ORDER BY date DESC
    `;

    // Query to get parcel details
    const parcelQuery = `
      SELECT id, deliveryfee, paymenttype, deliverystatus, pickupby, hubid, 
             recipientaddress, recipientname, recipientmobile, remark
      FROM parcels 
      WHERE clientid = $1 AND id = $2
    `;

    // Run both queries in parallel
    const [timelineResult, parcelResult] = await Promise.all([
      pool.query(timelineQuery, [user_id, parcel_id]),
      pool.query(parcelQuery, [user_id, parcel_id]),
    ]);

    // Check if data is available
    if (timelineResult.rows.length === 0 && parcelResult.rows.length === 0) {
      return res.status(404).json({ message: "No data found for the given user and parcel" });
    }

    res.json({
      timeline: timelineResult.rows,
      parcelDetails: parcelResult.rows.length > 0 ? parcelResult.rows[0] : null,
    });

  } catch (error) {
    console.error("Error fetching parcel timeline:", error);
    res.status(500).json({ message: "Server error" });
  }
});


router.post("/update-remark",authenticateToken, async (req, res) => {
  const {  parcel_id, remark } = req.body;

  const user = req.user;
  const user_id = user.user_id;


  if (!user_id || !parcel_id || !remark) {
    return res.status(400).json({ message: "user_id, parcel_id, and remark are required" });
  }

  try {
    // Update and return the updated row
    const updateQuery = `
      UPDATE parcels 
      SET remark = $1 
      WHERE clientId = $2 AND id = $3
      
    `;

    const { rows, rowCount } = await pool.query(updateQuery, [remark, user_id, parcel_id]);

    if (rowCount === 0) {
      return res.status(404).json({ message: "Parcel not found or unauthorized access" });
    }

    res.status(200).json({ message: "Parcel remark updated successfully", parcel: rows[0] });

  } catch (error) {
    console.error("Error updating parcel remark:", error);
    res.status(500).json({ message: "Server error" });
  }
});





module.exports = router;
