const express = require("express");
const pool = require("../../config/db");
const authenticateToken = require("../../middleware/authMiddleware");
const router = express.Router();
const { insertAdminLog } = require("../../models/userLogs");

const updateTransactionRecord = async ({
  client,
  amount,
  account_id,
  category_id,
  transaction_type,
  note,
  by_user_id,
  payer_payee_id,
  outlet_id,
  log_module,
  log_message,
}) => {
  try {
    const newAmount = Number(amount);

    if (newAmount <= 0) {
      throw new Error("Amount must be greater than 0");
    }

    /* =========================
       1️⃣ GET CURRENT BALANCE
    ========================= */

    const balanceRes = await client.query(
      `SELECT balance FROM accounts WHERE id = $1`,
      [account_id],
    );

    const prevBalance = Number(balanceRes.rows[0].balance || 0);

    /* =========================
       2️⃣ INSERT TRANSACTION
    ========================= */

    const insertRes = await client.query(
      `
  INSERT INTO transactions (
  transaction_type,
  category_id,
  transaction_date,
  amount,
  note,
  account_id,
  payer_payee_id,
  outlet_id,
  status,
  reference_id,
  transaction_fee,
  "by"
)
VALUES ($1,$2,NOW(),$3,$4,$5,$6,$7,'active',NULL,0,$8)
      RETURNING *
      `,
      [
        transaction_type,
        category_id,
        newAmount,
        note || null,
        account_id,
        payer_payee_id || null,
        outlet_id || null,
        by_user_id,
      ],
    );

    const newTransaction = insertRes.rows[0];

    /* =========================
       3️⃣ UPDATE ACCOUNT BALANCE
    ========================= */

    let newBalance = prevBalance;

    if (transaction_type === "income") {
      newBalance = prevBalance + newAmount;

      await client.query(
        `UPDATE accounts SET balance = balance + $1 WHERE id = $2`,
        [newAmount, account_id],
      );
    }

    if (transaction_type === "expense") {
      newBalance = prevBalance - newAmount;

      await client.query(
        `UPDATE accounts SET balance = balance - $1 WHERE id = $2`,
        [newAmount, account_id],
      );
    }

    /* =========================
       4️⃣ INSERT ACCOUNT STATEMENT
    ========================= */

    const statementType = transaction_type === "income" ? "credit" : "debit";

    await client.query(
      `
      INSERT INTO account_statement (
        account_id,
        transaction_type,
        amount,
        reference,
        payer_payee,
        "by",
        prev_balance,
        balance,
        status
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'Active')
      `,
      [
        account_id,
        statementType,
        newAmount,
        note || null,
        payer_payee_id || null,
        by_user_id,
        prevBalance,
        newBalance,
      ],
    );

    /* =========================
       5️⃣ ADMIN LOG
    ========================= */

    await insertAdminLog(
      by_user_id,
      log_module || "TRANSACTION_CREATE",
      log_message || `Transaction created | Amount: ${newAmount}`,
    );

    return {
      success: true,
      transaction: newTransaction,
      message: "Transaction inserted successfully",
    };
  } catch (error) {
    throw error;
  }
};

module.exports = updateTransactionRecord;
