// src/util/log.js
const pino = require('pino');

const log = pino({
  level: process.env.LOG_LEVEL || 'info',
  redact: ['password', 'token', 'authorization', '*.password', 'req.headers.authorization'],
  transport: process.env.NODE_ENV !== 'production'
    ? { target: 'pino-pretty', options: { colorize: true } }
    : undefined,
});

module.exports = { log };