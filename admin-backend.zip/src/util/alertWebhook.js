// src/util/alertWebhook.js
const { log } = require('./log');

const sendSlackAlert = async ({ title, message, level = 'error', details = {} }) => {
  const webhookUrl = process.env.SLACK_WEBHOOK_URL;

  // ← Add this guard
  if (!webhookUrl || webhookUrl.includes('YOUR') || webhookUrl === '') {
    log.warn({ title, message }, 'Slack alert skipped — SLACK_WEBHOOK_URL not configured');
    return;
  }

  if (!webhookUrl) {
    log.warn('SLACK_WEBHOOK_URL not set — skipping Slack alert');
    return;
  }

  const emoji = level === 'error' ? '🚨' : level === 'warn' ? '⚠️' : 'ℹ️';
  const env   = process.env.NODE_ENV || 'unknown';

  const body = {
    text: `${emoji} *[${env.toUpperCase()}] ${title}*`,
    attachments: [
      {
        color: level === 'error' ? '#FF0000' : level === 'warn' ? '#FFA500' : '#36A64F',
        fields: [
          { title: 'Message',   value: message,                 short: false },
          { title: 'Timestamp', value: new Date().toISOString(), short: true  },
          ...Object.entries(details).map(([k, v]) => ({
            title: k,
            value: String(v).slice(0, 500),
            short: true,
          })),
        ],
      },
    ],
  };

  try {
    const res = await fetch(webhookUrl, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    });
    if (!res.ok) log.warn({ status: res.status }, 'Slack alert HTTP error');
  } catch (err) {
    log.error({ err }, 'Failed to send Slack alert');
  }
};

module.exports = { sendSlackAlert };