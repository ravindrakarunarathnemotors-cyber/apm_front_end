const crypto = require('crypto')

// Encryption setup
const algorithm = "aes-256-cbc";
const key = Buffer.from(process.env.ENCRYPTION_KEY);
const iv = Buffer.from(process.env.ENCRYPTION_IV);

// Encrypt a single order_id 
function encryptId(id) {
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(id.toString(), "utf8", "hex");
    encrypted += cipher.final("hex");
    return encrypted;
}

// Decrypt (if you ever need to get back original ID)
function decryptId(encryptedId) {
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    let decrypted = decipher.update(encryptedId, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
}

//base64
module.exports = { encryptId, decryptId };