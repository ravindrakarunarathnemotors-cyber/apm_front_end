const pool = require("./config/db");

let io;

const initSocket = (server) => {
    const { Server } = require("socket.io");

    io = new Server(server, {
        cors: {
            origin: [
                "http://localhost:3001",
                process.env.FRONTEND_URL,
            ],
            credentials: true,
        },
    });

    async function getDisplaysByTill(tillId) {
        try {
            const sql = `
      SELECT display_id
      FROM device_management
      WHERE device_id = $1
    `;

            const { rows } = await pool.query(sql, [tillId]);

            if (rows.length === 0) {
                console.log("No display ids found for till:", tillId);
                return null;
            }

            let displayIds = rows[0].display_id;

            // If jsonb array → return first element
            if (Array.isArray(displayIds)) {
                return displayIds.length > 0 ? displayIds[0] : null;
            }

            // If single value → return directly
            return displayIds;

        } catch (error) {
            console.error("DB error:", error);
            return null;
        }
    }




    io.on("connection", (socket) => {
        console.log("Socket connected:", socket.id);

        socket.on("register_device", ({ type, id }) => {
            const room = `${type}:${id}`;
            socket.join(room);
            console.log(`Joined room: ${room}`);
        });

        socket.on("add_to_cart", async ({ item, tillId }) => {
            // console.log("add_to_cart", item, tillId)
            try {
                const displayId = await getDisplaysByTill(tillId);

                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("cart_update", {
                    action: "ADD_ITEM",
                    item,
                    from_till: tillId
                });

            } catch (err) {
                console.error(err);
            }
        });

        socket.on("clear_cart", async ({ tillId }) => {
            try {
                const displayId = await getDisplaysByTill(tillId);
                console.log("clear items")
                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("clear_cart_update", {
                    action: "clear_ITEM",
                    from_till: tillId
                });

            } catch (err) {
                console.error(err);
            }
        });


        socket.on("add_to_cart_side", async ({ subtotal, finalTotal, totalTax, tillId }) => {
            // console.log("add_to_cart_side")
            try {
                const displayId = await getDisplaysByTill(tillId);

                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("cart_update_side", {
                    action: "payment",
                    from_till: tillId,
                    subtotal,
                    finalTotal,
                    totalTax
                });

            } catch (err) {
                console.error(err);
            }

        });

        socket.on("other_detils", async ({ discount, discountPaymentMethod, taxEnabled, taxFields, tillId }) => {
            console.log("other_detils")

            try {
                const displayId = await getDisplaysByTill(tillId);

                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("cart_update_other_detils", {
                    action: "ADD_ITEM",
                    from_till: tillId,
                    discount,
                    discountPaymentMethod,
                    taxEnabled,
                    taxFields
                });

            } catch (err) {
                console.error(err);
            }
        });

        socket.on("buyxDiscont", async ({ buyxDiscont, tillId }) => {
            console.log("buyxDiscont")

            try {
                const displayId = await getDisplaysByTill(tillId);

                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("update_buyxDiscont", {
                    action: "payment",
                    from_till: tillId,
                    buyxDiscont
                });

            } catch (err) {
                console.error(err);
            }

        });

        socket.on("display_to_pos_customer", async ({ selectedCustomer, tillId }) => {
            try {
                const displayId = await getDisplaysByTill(tillId);
                console.log("display_to_pos_customer", selectedCustomer, tillId, displayId)
                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`till:${displayId}`).emit("display_to_pos_customer_update", {
                    selectedCustomer,
                    from_till: tillId
                });

            } catch (err) {
                console.error(err);
            }
        });

        socket.on("postodispsplaycustomer", async ({ customer, tillId }) => {
            try {
                const displayId = await getDisplaysByTill(tillId);
                console.log("postodispsplaycustomer", customer, tillId, displayId)
                if (!displayId) {
                    console.log("No display mapped to this till");
                    return;
                }

                io.to(`display:${displayId}`).emit("postodispsplaycustomer_update", {
                    customer,
                    from_till: tillId
                });

            } catch (err) {
                console.error(err);
            }
        });



        socket.on("disconnect", () => {
            console.log("Socket disconnected:", socket.id);
        });
    });
};

const getIO = () => {
    if (!io) {
        throw new Error("Socket.io not initialized");
    }
    return io;
};

module.exports = { initSocket, getIO };